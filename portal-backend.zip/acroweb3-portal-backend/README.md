# Portal Backend

Il backend del portale è un rest service che fornice al frontend:

- data del server
- configurazione. A partire dall'host chiamante (url del portale) ritorna:
    - dati per autentica: tutti i parametri di connessione all'identity server (keycloak), compreso realm e client id utilizzato per l'autentica
    - skin: oggetto che contiene tutti i valori delle variabili CSS necessarie al frontend per personalizzare la vista.
- applicazioni del portale: elenco di applicazioni che formeranno il menù del portale. Per ogni applicazione viene specificato l'elenco dei ruoli consentiti all'utente nel quest'ultimo ne abbia accesso (un utente ha accesso ad una applicazione se e solo se ha almeno un ruolo assegnato ad esso all'interno dell'identity server)

## Servizi verso altri backend

Il portal espone verso gli altri backend i seguenti servizi

### Notifiche vie WebSocket


### "Risoluzione" authentication issuer

### Log attività

