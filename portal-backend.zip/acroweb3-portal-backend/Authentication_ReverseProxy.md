# Cose da fare per autentica con reverse proxy

- implemetazione idp_client in admin
    - gestione invio mail
    - gestione validazione mail (occorrerà aggiunre end point alle api)
    - gestione dati utente e ruoli nei vari campi props
- gestione autentcazione:
    - gestire errori nel caso i dati utente ed i ruoli non siano presenti nei campi props


# parametrizzazione autentica

## variabili ambiente

- AUTH_HEADER_NAME: nome dell'header che contiene i dati di autentica:
    - "HTTP_AUTHORIZATION" per OIDC
    - "..." per reverse proxy (nome header che contiene il CF dell'utente)
- AUTH_HEADER_PREFIX: prefisso da eliminare nel valore dell'header
    - "bearer " per OIDC
    - "" per reverse proxy
- DRF_AUTH_CLASS: componente per gestione dell'autentica
    - "acroweb3_portal.auth.PortalAuthentication" per OIDC
    - "acroweb3_portal.auth.PortalAuthenticationReverseProxy" per Reverse Proxy

## configurazione portale

basta aggiungere nel campo json Auth di portalConfig un attributo 

        type: "none"

il frontend, quando trova questo attributo ed il suo valore è diverso da "oidc" disabilita l'autentica, altrimenti la imposta come OIDC.
