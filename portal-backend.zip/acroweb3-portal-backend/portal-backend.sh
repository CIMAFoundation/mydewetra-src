#!/bin/bash

# Apply database migrations
echo "Apply database migrations"
python manage.py migrate auth --noinput
python manage.py migrate --noinput
# python manage.py migrate sessions --noinput
# python manage.py migrate acroweb3_portal --noinput
# python manage.py migrate activity_book --database=activity --noinput

# Start server
INTERFACE="0.0.0.0"
if [ $# -eq 1 ]; then
    INTERFACE=$1
fi

echo "Starting server on interface ${INTERFACE}"
#gunicorn acroweb3.wsgi:application  --bind ${INTERFACE}:8000
daphne -b ${INTERFACE} -p 8000 acroweb3_portal.asgi:application