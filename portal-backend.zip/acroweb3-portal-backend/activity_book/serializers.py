__doc__ = """
Description:
    This module contains the serializers for the activity_book app.
    The serializers are used to serialize the data of the models.

Classes:
    SessionSerializer: Serializer for the Session model.
    ActivitySerializer: Serializer for the Activity model.
"""
from rest_framework import serializers

from activity_book.models import Activity, Session

class SessionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Session
        fields = '__all__'

class ActivitySerializer(serializers.ModelSerializer):
    #session = SessionSerializer(read_only=True)    
    class Meta:
        model = Activity
        fields = ['date', 'application', 'activity']
