__doc__ = """
Description:
    This module contains the views for the activity_book app.
    The views are used to handle the requests and responses of the activity_book app.

Classes:
    ExternalActivityWriterView: Class to handle the external activity writer view.
    SessionListPagination: Class to handle the session list pagination.
    ActivityBookSessionView: Class to handle the activity book session view.

Attributes:
    _logger: Logger object to log the messages.

"""


from rest_framework import status, viewsets
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.pagination import PageNumberPagination

from acroweb3 import AcrowebException
from acroweb3_api import get_logger
from acroweb3_portal.settings import ACROWEB3_APP_NAME
from acroweb3_portal.websocket import WSConsumer

from activity_book.manager import ActivityManager
from activity_book.models import Session, Activity

from drf_yasg.utils import swagger_auto_schema
from drf_yasg.openapi import Schema

from activity_book.serializers import ActivitySerializer, SessionSerializer

import datetime

_logger = get_logger(__name__)


class ExternalActivityWriterView(viewsets.ViewSet):
    """
    Description:
        Class to handle the external activity writer view.
    
    Methods:
        session: Method to open/close a session.
        create: Method to create an activity.
    Attributes:
        permission_classes: List of permission classes.
    """
    permission_classes = [permissions.IsAuthenticated]
    
    @action(detail=False, methods=['post','delete'])
    def session(self, request):
        """
        Description:
            open/close a session
            if the request method is post, it tries to create a session and logs the activity.
            else, it tries to close a session and logs the activity.
        
        Args:
            request: Request object.
        
        Returns:
            Response object.
        
        Raises:
            AcrowebException: If an error occurs.
                """
        user = request.user.user
        portal = request.user.portal
        address = request.get_host()
        domain = request.user.domain        
        if request.method == 'post':
            ActivityManager().create_session(user, portal, domain, address, 'login')            
            #notify portal
            notified_count = WSConsumer.notify_portal(portal, f'{user} logged in')
            _logger.debug(f'notified {notified_count} clients that {user} logged in')
        else:
            ActivityManager().close_session(user, portal, address)
            notified_count = WSConsumer.notify_portal(portal, f'{user} logged out')
            _logger.debug(f'notified {notified_count} clients that {user} logged out')
        return Response()
        

    @swagger_auto_schema(
        request_body= Schema(
            type='object', 
            properties={
                'activity': Schema(type='str', description='Activity object')
            }
        )
    )
    def create(self, request):
        """
        Description:
            create an activity
            It tries to create an activity and logs the activity.

        Args:
            request: Request object.
        
        Returns:
            Response object.
        
        Raises:
            Response: If the request body is invalid.
                """
        body = request.data
        if not all(f in body for f in ['activity']):
            return Response('invalid body', status=status.HTTP_400_BAD_REQUEST)
        
        user = request.user.user
        domain = request.user.domain
        portal = request.user.portal
        address = request.get_host()

        try:
            activity = ActivityManager().create(user, portal, domain, address, ACROWEB3_APP_NAME, body['activity'])
        except AcrowebException as e:
            return Response(str(e), status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response({'id': activity.id})


class SessionListPagination(PageNumberPagination):
    """
    Description:
        Class to handle the session list pagination.
        
    Attributes:
        page_size: Number of items per page.
        page_size_query_param: Query parameter to get the page size.
        max_page_size: Maximum number of items per page.
    
    """
    page_size = 10
    page_size_query_param = 'page_size'
    max_page_size = 20

    

class ActivityBookSessionView(viewsets.ReadOnlyModelViewSet):
    """
    Description:
        Class to handle the activity book session view.
    
    Attributes:
        permission_classes: List of permission classes.
        serializer_class: Serializer class.
        pagination_class: Pagination class.
    
    Methods:
        get_queryset: Method to get the query set.
        retrieve: Method to retrieve the activities of a session.
    """
    # permission_classes = [permissions.IsAuthenticated]    
    serializer_class = SessionSerializer
    pagination_class = SessionListPagination
    
    def get_queryset(self):
        """
        Description:
            get the query set
            It tries to get the sessions of the user.
        
        Args:
            None

        Returns:
            Session queryset filtered by domain and date range.

        Raises:
            None
        """
        domain = 'cima' #self.request.user.domain
        dt_to_str = self.request.query_params.get('to')
        dt_from_str = self.request.query_params.get('from')
        dt_to = datetime.datetime.utcnow() if dt_to_str is None else datetime.datetime.fromisoformat(dt_to_str)
        dt_from = dt_to - datetime.timedelta(days=10) if dt_from_str is None else datetime.datetime.fromisoformat(dt_from_str)
        return Session.objects.filter(domain=domain, date__range=(dt_from, dt_to)).order_by('-date')

    @swagger_auto_schema(responses={200: ActivitySerializer(many=True)})
    def retrieve(self, request, *args, **kwargs):
        """
        Description:
            retrieve the activities of a session
            It tries to get the activities of a session.
        
        Args:
            request: Request object.
            args: Arguments.
            kwargs: Keyword arguments.
        
        Returns:
            Response object.
        
        Raises:
            None
        """
        instance = self.get_object()
        activities = []
        for a in instance.activities.all():
            activities.append(ActivitySerializer(instance=a).data)
        return Response(activities)
        