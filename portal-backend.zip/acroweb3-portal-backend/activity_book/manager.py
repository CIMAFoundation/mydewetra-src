__doc__ = """   
Description:
    This module contains the ActivityManager class which is responsible for managing the activities and sessions of the users.
    The ActivityManager class is used to create, close and manage the activities and sessions of the users.

Attributes:
    _logger: Logger object to log the messages.

Classes:
    ActivityManager: Class to manage the activities and sessions of the users.
"""
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
import datetime
from django.db import DatabaseError, transaction
from acroweb3 import AcrowebException
from acroweb3_portal.websocket import WSConsumer
from activity_book.models import Activity, Session
from acroweb3_api import get_logger

_logger = get_logger(__name__)

class ActivityManager():
    """
    Description:
        Class to manage the activities and sessions of the users.
    
    Methods:
        __close_session: Method to close a session.
        create_session: Method to create a session.
        close_session: Method to close a session.
        create: Method to create an activity.
    
    """

    def __close_session(self, s):
        """
        Description:
            close a session
        
        Args:
            s: Session object to close.
        
        Returns:
            None
        """
        s.closed = datetime.datetime.utcnow()
        s.save()


    def create_session(self, user, portal, domain, address, reason):
        """
        Description:
            create a session
            It tries to create a session and logs the activity.


        Args:
            user: User object.
            portal: Portal object.
            domain: Domain object.
            address: Address object.
            reason: Reason for creating the session.
        
        Returns:
            Session object
        
        Raises:
            DatabaseError: If there is an error while creating the session.
        """

        try:
            with transaction.atomic():
                new_session = Session.objects.create(
                                    username=user, 
                                    portal=portal,
                                    domain=domain,
                                    address=address)

                Activity.objects.create(
                                    session=new_session,
                                    application='portal',
                                    activity=reason)

                _logger.debug(f'created session {new_session.id}: user: {user}')

                return new_session

        except DatabaseError as e:
            _logger.error('', exc_info=e)
            return None


    def close_session(self, username, portal, address):
        """
        Description:
            close a session
        
        Args:
            username: Username of the user.
            portal: Portal object.
            address: Address object.
        
        Returns:
            None
        
        Raises:
            AcrowebException: If there is an error while closing the session.
        """
        opened_sessions = Session.objects.filter(
                            username=username,
                            portal=portal,
                            address=address, 
                            closed=None)
        for s in opened_sessions:
            self.__close_session(s)


    def create(self, user, portal, domain, address, app, text):
        """
        Description:
            create an activity.
            If there is no opened session, it creates a new session and then creates the activity.
            If there is more than one opened session, it closes the older ones and keeps the newest one.
        
        Args:
            user: User object.
            portal: Portal object.
            domain: Domain object.
            address: Address object.
            app: Application name.
            text: Activity text.
        
        Returns:
            Activity object
        
        Raises:
            AcrowebException: If there is an error while creating the activity.
        """
        #get last opened session order by creation date
        opened_sessions = Session.objects.filter(
                            username=user, 
                            portal=portal,
                            address=address, 
                            closed=None).order_by('-date')
        
        session = None

        if not opened_sessions.exists():
            # if cannot find an opened session, then create a new one
            _logger.debug('Cannot find opened session during activity creation... Opening a new session')
            session = self.create_session(user, portal, domain, address, 'session created')
            if session is None:
                raise AcrowebException('Error creating session')

        else:

            if(len(opened_sessions) > 1):
                # if found more than one session, the close the older ones and keep the the newest
                _logger.warning('Found more than one opened session during activity creation... Closing the older ones')
                for i in range(1,len(opened_sessions)):
                    self.__close_session(opened_sessions[i])

            session = opened_sessions[0]
        

        activity = Activity.objects.create(
                            session=session,
                            application=app,
                            activity=text)

        WSConsumer.notify_portal(portal, f'{user}: {text}')

        return activity


