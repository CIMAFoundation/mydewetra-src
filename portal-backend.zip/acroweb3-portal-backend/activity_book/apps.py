from django.apps import AppConfig


class ActivityBookConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'activity_book'
