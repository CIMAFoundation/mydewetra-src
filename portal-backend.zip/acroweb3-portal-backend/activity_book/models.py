__doc__ = """
Description:
    This module contains the models for the activity_book app.
    The models are used to store the activities and sessions of the users.

Classes:
    Session: Model to store the session details.
    Activity: Model to store the activity details.
"""

from django.db import models

from django.db import models
from django.db.models.deletion import CASCADE

class Session(models.Model):    
    address = models.CharField(max_length=255)
    username = models.CharField(max_length=255)
    portal = models.CharField(max_length=255)
    domain = models.TextField()
    date = models.DateTimeField(auto_now_add=True)
    closed = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f'{self.username}@{self.domain} - {self.date}'

class Activity(models.Model):
    session = models.ForeignKey(Session, on_delete=models.CASCADE, related_name='activities')
    date = models.DateTimeField(auto_now_add=True)
    application = models.TextField(blank=True)
    activity = models.TextField(blank=True)
    
    def __str__(self):
        return f'{self.date} - {self.application} - {self.activity}'


