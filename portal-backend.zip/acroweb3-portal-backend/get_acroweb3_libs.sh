#!/bin/bash

cp ../../framework/acroweb3-api-lib/dist/acroweb3_api-latest.tar.gz lib/
cp ../../framework/acroweb3-lib/dist/acroweb3-latest.tar.gz lib/

source .venv/bin/activate
pip uninstall acroweb3
pip uninstall acroweb3-api

pip install ./lib/acroweb3-latest.tar.gz
pip install ./lib/acroweb3_api-latest.tar.gz