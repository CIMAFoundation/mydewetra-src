#!/bin/bash
set -e

echo "Creating database: acroweb3-portal-dev"
createdb -U $POSTGRES_USER acroweb3-portal-dev

echo "enable postgis extension"
psql -U $POSTGRES_USER -d acroweb3-portal-dev -c "CREATE EXTENSION postgis;"

echo "Restoring database: acroweb3-portal-dev"
pg_restore -U $POSTGRES_USER -d acroweb3-portal-dev /docker-entrypoint-initdb.d/acroweb3-portal-dev.backup