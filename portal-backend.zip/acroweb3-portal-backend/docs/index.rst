.. Acroweb3 Portal Backend documentation master file, created by
   sphinx-quickstart on Tue Jul 16 10:46:12 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Acroweb3 Portal Backend documentation
=====================================
.. image:: _static/img/logocima.png


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   acroweb3_portal
   activity_book
   manage


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


Github Repository
-----------------
.. toctree::
   :maxdepth: 1

   Github Repository <https://github.com/CIMAFoundation/acroweb3-portal-backend>