activity\_book.migrations package
=================================

Submodules
----------

activity\_book.migrations.0001\_initial module
----------------------------------------------

.. automodule:: activity_book.migrations.0001_initial
   :members:
   :undoc-members:
   :show-inheritance:

activity\_book.migrations.0002\_session\_closed module
------------------------------------------------------

.. automodule:: activity_book.migrations.0002_session_closed
   :members:
   :undoc-members:
   :show-inheritance:

activity\_book.migrations.0003\_alter\_session\_closed module
-------------------------------------------------------------

.. automodule:: activity_book.migrations.0003_alter_session_closed
   :members:
   :undoc-members:
   :show-inheritance:

activity\_book.migrations.0004\_session\_portal module
------------------------------------------------------

.. automodule:: activity_book.migrations.0004_session_portal
   :members:
   :undoc-members:
   :show-inheritance:
