acroweb3\_portal.migrations package
===================================

Submodules
----------

acroweb3\_portal.migrations.0001\_initial module
------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0001_initial
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0002\_auto\_20211011\_1445 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0002_auto_20211011_1445
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0003\_remove\_application\_enabled module
---------------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0003_remove_application_enabled
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0004\_portalconfig module
-----------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0004_portalconfig
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0005\_portalconfig\_hosts module
------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0005_portalconfig_hosts
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0006\_auto\_20211026\_1242 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0006_auto_20211026_1242
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0007\_auto\_20211026\_1243 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0007_auto_20211026_1243
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0008\_auto\_20211108\_1455 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0008_auto_20211108_1455
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0009\_widget\_title module
------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0009_widget_title
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0010\_alter\_widget\_settings module
----------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0010_alter_widget_settings
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0011\_dashboardsettings module
----------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0011_dashboardsettings
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0012\_domain module
-----------------------------------------------

.. automodule:: acroweb3_portal.migrations.0012_domain
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0013\_auto\_20220310\_1032 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0013_auto_20220310_1032
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0014\_rename\_id\_domain\_name module
-----------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0014_rename_id_domain_name
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0015\_auto\_20220401\_0906 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0015_auto_20220401_0906
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0016\_auto\_20220401\_1408 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0016_auto_20220401_1408
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0017\_domain\_apps module
-----------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0017_domain_apps
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0018\_auto\_20220404\_1310 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0018_auto_20220404_1310
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0019\_domaingroup\_portal module
------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0019_domaingroup_portal
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0020\_auto\_20220805\_0746 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0020_auto_20220805_0746
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0021\_application\_props module
-----------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0021_application_props
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0022\_auto\_20230707\_1047 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0022_auto_20230707_1047
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0023\_auto\_20230706\_0725 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0023_auto_20230706_0725
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0024\_auto\_20230711\_0651 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0024_auto_20230711_0651
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0025\_application\_icon\_svg module
---------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0025_application_icon_svg
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0026\_auto\_20240213\_0853 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0026_auto_20240213_0853
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0027\_auto\_20240229\_1547 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0027_auto_20240229_1547
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0028\_auto\_20240305\_1511 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0028_auto_20240305_1511
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0029\_auto\_20240305\_1541 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0029_auto_20240305_1541
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0030\_auto\_20240328\_1035 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0030_auto_20240328_1035
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.migrations.0031\_auto\_20240411\_1048 module
-------------------------------------------------------------

.. automodule:: acroweb3_portal.migrations.0031_auto_20240411_1048
   :members:
   :undoc-members:
   :show-inheritance:

