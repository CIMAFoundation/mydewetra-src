acroweb3\_portal package
========================



.. toctree::
   :maxdepth: 4

   acroweb3_portal.admin_app
   acroweb3_portal.tests


acroweb3\_portal.admin module
-----------------------------

.. automodule:: acroweb3_portal.admin
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.apps module
----------------------------

.. automodule:: acroweb3_portal.apps
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.asgi module
----------------------------

.. automodule:: acroweb3_portal.asgi
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.auth module
----------------------------

.. automodule:: acroweb3_portal.auth
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.db\_router module
----------------------------------

.. automodule:: acroweb3_portal.db_router
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.internal\_views module
---------------------------------------

.. automodule:: acroweb3_portal.internal_views
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.models module
------------------------------

.. automodule:: acroweb3_portal.models
   :members:

acroweb3\_portal.prova module
-----------------------------

.. automodule:: acroweb3_portal.prova
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.serializers module
-----------------------------------

.. automodule:: acroweb3_portal.serializers
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.settings module
--------------------------------

.. automodule:: acroweb3_portal.settings
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.urls module
----------------------------

.. automodule:: acroweb3_portal.urls
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.views module
-----------------------------

.. automodule:: acroweb3_portal.views
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.websocket module
---------------------------------

.. automodule:: acroweb3_portal.websocket
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.wsgi module
----------------------------

.. automodule:: acroweb3_portal.wsgi
   :members:
   :undoc-members:
   :show-inheritance:
