activity\_book package
======================



.. toctree::
   :maxdepth: 4



activity\_book.admin module
---------------------------

.. automodule:: activity_book.admin
   :members:
   :undoc-members:
   :show-inheritance:

activity\_book.apps module
--------------------------

.. automodule:: activity_book.apps
   :members:
   :undoc-members:
   :show-inheritance:

activity\_book.manager module
-----------------------------

.. automodule:: activity_book.manager
   :members:
   :undoc-members:
   :show-inheritance:

activity\_book.models module
----------------------------

.. automodule:: activity_book.models
   :members:

activity\_book.serializers module
---------------------------------

.. automodule:: activity_book.serializers
   :members:

activity\_book.views module
---------------------------

.. automodule:: activity_book.views
   :members:
   :undoc-members:
   :show-inheritance:

