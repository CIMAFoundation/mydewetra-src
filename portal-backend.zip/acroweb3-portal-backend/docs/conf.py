# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information
import os
import sys
import django
import subprocess

sys.path.insert(0, os.path.abspath('..'))

os.environ['DJANGO_SETTINGS_MODULE'] = 'acroweb3_portal.settings'
django.setup()

def get_latest_tag():
    try:
        tag = subprocess.check_output(['git', 'describe', '--tags', '--abbrev=0']).strip().decode('utf-8')
        return tag
    except subprocess.CalledProcessError:
        return '0.0.0'




project = 'Acroweb3 Portal Backend'
copyright = '2024, Alessandro Burastero'
author = 'Alessandro Burastero'
version = get_latest_tag()
release = version           



# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = ['sphinx.ext.autodoc', 'sphinx.ext.todo', 'sphinx.ext.viewcode', 'sphinx.ext.napoleon']


latex_engine = 'pdflatex'

latex_elements = {
    'papersize': 'a4paper',  # Dimensione del foglio
    'pointsize': '10pt',     # Dimensione del carattere, aumentato per migliorare la leggibilità
    'preamble': r'''
        \usepackage{graphicx}
        \usepackage{fancyhdr}
        \usepackage{geometry}
        \geometry{top=2.5cm, bottom=2.5cm, left=1.5cm, right=1.0cm}
        \setlength{\headheight}{14pt}
        \fancypagestyle{plain}{
            \fancyhf{}
            \fancyhead[L]{\includegraphics[width=2cm]{logocima.png}}  % Intestazione con logo a sinistra
            \renewcommand{\headrulewidth}{0.5pt}  % Linea di intestazione
            \fancyfoot[C]{\today}  % Piè di pagina centrale con data corrente
            \fancyfoot[R]{\thepage}  % Piè di pagina a destra con numero di pagina
        }
        \pagestyle{plain}
        \setlength{\parskip}{1em}  % Spaziatura tra i paragrafi
        \setlength{\parindent}{0em}  % Nessuna indentazione dei paragrafi
    ''',
    'figure_align': 'H',  # Allineamento delle figure
}




templates_path = ['_templates']
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store', 'acroweb3_portal.migrations.rst','activity_book.migrations.rst']



# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = 'sphinx_rtd_theme'
html_static_path = ['_static']



autodoc_member_order = 'bysource'

# rimuove i metodi __init__ e __str__ dalle classi nella documentazione autogenerata 
autodoc_default_options = {
      'exclude-members': 'basename, description, detail, name, suffix, is_valid, DoesNotExist, MultipleObjectsReturned, id, objects'
  }
