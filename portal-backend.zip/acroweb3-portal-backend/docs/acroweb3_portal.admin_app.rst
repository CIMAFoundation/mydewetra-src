acroweb3\_portal.admin\_app package
===================================


acroweb3\_portal.admin\_app.idp\_client module
----------------------------------------------

.. automodule:: acroweb3_portal.admin_app.idp_client
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.admin\_app.idp\_db module
------------------------------------------

.. automodule:: acroweb3_portal.admin_app.idp_db
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.admin\_app.idp\_keycloak module
------------------------------------------------

.. automodule:: acroweb3_portal.admin_app.idp_keycloak
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.admin\_app.import\_roles\_in\_db module
--------------------------------------------------------

.. automodule:: acroweb3_portal.admin_app.import_roles_in_db
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.admin\_app.init\_portal module
-----------------------------------------------

.. automodule:: acroweb3_portal.admin_app.init_portal
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.admin\_app.internal\_views module
--------------------------------------------------

.. automodule:: acroweb3_portal.admin_app.internal_views
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.admin\_app.permissions module
----------------------------------------------

.. automodule:: acroweb3_portal.admin_app.permissions
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.admin\_app.prv module
--------------------------------------

.. automodule:: acroweb3_portal.admin_app.prv
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.admin\_app.serializers module
----------------------------------------------

.. automodule:: acroweb3_portal.admin_app.serializers
   :members:
   :undoc-members:
   :show-inheritance:

acroweb3\_portal.admin\_app.views module
----------------------------------------

.. automodule:: acroweb3_portal.admin_app.views
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: acroweb3_portal.admin_app
   :members:
   :undoc-members:
   :show-inheritance:
