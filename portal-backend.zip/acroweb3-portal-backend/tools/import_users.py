import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "acroweb3_portal.settings")
import django
django.setup()

from acroweb3_portal.models import Domain, PortalConfig, UserData, ApplicationRole, Application
import csv

from django.db import transaction

csv_dir = os.path.join(os.path.dirname(__file__), 'users')

def import_users():
    #get all files in the csv dir
    files = os.listdir(csv_dir)

    users = {}
    for file in files:
        if file.endswith('.csv'):
            print(f'Reading {file}')
            with open(os.path.join(csv_dir, file), 'r') as f:
                reader = csv.DictReader(f, delimiter=';')
                for row in reader:
                    username = row['username'] if row['username'] and row['username'] != 'NA' else f"TO_CHANGE. {row['first_name']} - {row['last_name']}"
                    username = username.lower()
                    if username not in users:
                        users[username] = {
                            'first_name': row['first_name'],
                            'last_name': row['last_name'],
                            'email': row['email'],
                            'domain': row['domain'],
                            'portal': None,
                            'roles': {},
                        }
                    application_id = row['Applicazione']
                    if application_id not in users[username]['roles']:
                        users[username]['roles'][application_id] = []
                    roles = row['roles'].split(',')
                    users[username]['roles'][application_id] += roles


    with transaction.atomic():
        for username, user_data in users.items():
            
            #get the domain
            try:
                domain = Domain.objects.get(name=user_data['domain'])
            except Domain.DoesNotExist:
                print(f'\tDomain {user_data["domain"]} does not exist. User: {username} not imported')
                continue


            #check if the user already exists
            try:
                UserData.objects.get(username=username, domain__portal=domain.portal)
                print(f'\tUser {username} already exists. User not imported')
                continue
            except UserData.DoesNotExist:
                pass

            app_roles = []
            for app_id in user_data['roles']:

                #get the application
                try:
                    app = Application.objects.get(pk=app_id)
                except Application.DoesNotExist:
                    print(f'\tApplication {app_id} does not exist. Application skipped for user {username}')
                    continue

                #get the application roles
                for role in user_data['roles'][app_id]:
                    #get the role
                    try:
                        app_role = ApplicationRole.objects.get(name=role, application=app)
                    except ApplicationRole.DoesNotExist:
                        print(f'\tRole {role} does not exist. User: {username} imported without this role')
                        continue
                    app_roles.append(app_role)

            #create the user
            user = UserData(
                username=username,
                first_name=user_data['first_name'],
                last_name=user_data['last_name'],
                email=user_data['email'],
                domain=domain,
                portal=domain.portal,
            )
            user.save()
            #add the role to the user
            user.roles.set(app_roles)

if __name__ == '__main__':
    import_users()                        