__doc__ = """
Description:
    ASGI config for cbe project.
    If settings.ACTIVATE_WS is True, it will also activate the websocket.
    Else it will not activate the websocket.
    The websocket is used for the notification system.

Attributes:
    - application: ProtocolTypeRouter object
    - router_data: dict
    - WSConsumer: WSConsumer object
    - WSTokenAuthMiddleware: WSTokenAuthMiddleware object
    - WSNotifier: WSNotifier object

"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'acroweb3_portal.settings')
django.setup()

from channels.routing import ProtocolTypeRouter, URLRouter
from django.urls import re_path
from django.core.asgi import get_asgi_application
from django.conf import settings
from acroweb3_api import get_logger

_logger = get_logger(__name__)

router_data = {
    "http": get_asgi_application()
}

if settings.ACTIVATE_WS:
    _logger.info('Websocket ACTIVATED')
    from acroweb3_portal.websocket import WSConsumer, KafkaWSNotifier, SentinelWSNotifier, WSTokenAuthMiddleware, WSNotifier, NewAcqWSNotifier
    router_data['websocket'] = WSTokenAuthMiddleware(
        URLRouter(
            [re_path(r'public/ws/notifier', WSConsumer.as_asgi())]
        )
    )
    # set the main notifier
    if settings.EXECUTE_KAFKA_LISTENER:
        _logger.info('Kafka Listener ACTIVATED')
        WSConsumer.notifier_listener.append(KafkaWSNotifier())
    
    # set the sentinel notifier
    if settings.EXECUTE_SENTINEL_LISTENER:
        _logger.info('Sentinel Listener ACTIVATED')
        WSConsumer.notifier_listener.append(SentinelWSNotifier())

    # set the newacq notifier
    if settings.EXECUTE_NEWACQ_LISTENER:
        _logger.info('Newacq Listener ACTIVATED')
        WSConsumer.notifier_listener.append(NewAcqWSNotifier())


    if len(WSConsumer.notifier_listener) == 0:
        _logger.info('Default Notifier ACTIVATED')
        WSConsumer.notifier_listener.append(WSNotifier())
    
else:
    _logger.info('Websocket NOT activated')

application = ProtocolTypeRouter(router_data)
