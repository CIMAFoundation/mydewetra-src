__doc__ = '''
Created on Feb 5, 2020

@author: doy

Description: 
    websocket consumer for acroweb3 portal

    This module is responsible for handling websocket connections and notifications.
    It is used by the acroweb3-portal-backend to notify web clients of events.
    It is also used by the acroweb3-portal-backend to notify web clients of events.
    
Classes:
    WSTokenAuthMiddleware: Custom token auth middleware
    WSConsumer: Notifier for web clients
    WSNotifier: CBC listening class

Functions:
    - _get_portal_config_by_host: Get portal config by host

Attributes:
    - _logger: Logger object    
'''
from channels.generic.websocket import JsonWebsocketConsumer
from typing import List
from urllib.parse import parse_qs
from acroweb3_portal.auth import get_auth_component, get_portal_config_by_host
from acroweb3_api import get_logger
from acroweb3 import broker
from acroweb3.portal_tools import build_portal_notification
from acroweb3.portal_tools import parse_notification_body
from acroweb3.sentinel.client import SentinelClient, SentinelListener
from acroweb3.dds.client import NewAcqClient, NewAcqListener
from fnmatch import fnmatch
import uuid
from django.conf import settings
from channels.db import database_sync_to_async
import json
import os

_logger = get_logger(__name__)


@database_sync_to_async
def _get_portal_config_by_host(host):
    return get_portal_config_by_host(host)


class WSTokenAuthMiddleware:
    """
    Description:
            Custom token auth middleware

    Functions:
        __init__: Constructor
        __call__: Call function
    """

    def __init__(self, inner):
        self.inner = inner

    async def __call__(self, scope, receive, send):
        """
        Description:
            Call function, used to validate the token
            It tries to get the host from the headers, then it gets the portal config by host
            else it logs an error and returns the inner function
            If the portal config is not found, it logs an error and returns the inner function
            else it gets the issuer from the portal config
            If the token is not found, it logs an error and returns the inner function
            else it gets the token from the query string
            If the path is not found, it logs an error and returns the inner function
            else it gets the path from the query string

        Args:
            scope: Scope
            receive: Receive
            send: Send

        Returns:
            await self.inner(scope, receive, send)

        Raises:
            Exception: If the token is not found, it logs an error and returns the inner function
        """

        try:
            # get the host
            host = None
            for h in scope['headers']:
                if h[0].decode() == 'origin' or h[0].decode() == 'host':
                    host = h[1].decode()
                    break
            if host is None:
                scope['error'] = f'cannot find host header in {scope["headers"]}'
                _logger.warning(scope['error'])
                return await self.inner(scope, receive, send)
            cfg = await _get_portal_config_by_host(host)

            # if 'type' not in cfg or cfg['type']=='oidc':

            issuer = cfg.auth["issuer"] if 'issuer' in cfg.auth else None

            # validate the token
            qs = scope["query_string"].decode("utf8")
            parsed = parse_qs(qs)

            # retrieve access token
            if 'token' not in parsed:
                scope['error'] = 'invalid ws connection request: no token found'
                _logger.warning(scope['error'])
                return await self.inner(scope, receive, send)
            token = parsed['token'][0]
            if not token:
                scope['error'] = 'invalid ws connection request: empty token'
                _logger.warning(scope['error'])
                return await self.inner(scope, receive, send)

            # retrieve path
            if 'path' not in parsed:
                scope['error'] = 'invalid ws connection request: no path found'
                _logger.warning(scope['error'])
                return await self.inner(scope, receive, send)
            scope['path_filter'] = parsed['path'][0]

            token_info = get_auth_component().validate_token(token, issuer)
            scope['user'] = token_info['preferred_username']
            scope['portal'] = cfg.id
            _logger.info(
                f"WS client connection: user {scope['user']}, portal {scope['portal']}, path: {scope['path_filter']}"
            )
        except Exception as e:
            scope['error'] = f'received invalid ws connection request: {str(e)}'
            _logger.warning(scope['error'])

        return await self.inner(scope, receive, send)


class WSConsumer(JsonWebsocketConsumer):
    """
    Description:
            Notifier for web clients

    Functions:
        connect: Connect function
        match: Match function
        disconnect: Disconnect function
        notify: Notify function
        notify_portal: Notify portal function

    Attributes:
        notifier_listener: None
    """

    notifier_listener: list = []

    def connect(self):
        """
        Description:
            Connect function, used to connect to the websocket
            It logs the connection request
            If the user is not found, it logs an error and returns the accept function
            If the notifier listener is None, it logs a message and creates a new CmdNotifierlistener
            It adds the notifier to the notifier listener
            It accepts the connection

        Args:
            self: Self

        Returns:
            self.accept()
            self.send(text_data=msg, close=4001)

        Raises:
            Exception: If the user is not found, it logs an error and returns the accept function
        """
        _logger.info('connection requested: ')
        if not 'user' in self.scope or not 'portal' in self.scope:
            _logger.info('user not found')
            self.accept()
            msg = self.scope['error'] if 'error' in self.scope else 'unknown error'
            self.send(text_data=msg, close=4001)
            return

        for nl in WSConsumer.notifier_listener:
            nl.add_notifier(self)

        self.accept()

    def match(self, portal, path):
        """
        Description:    
            Match function, used to match the portal and path
            It gets the path filter from the scope
            If the path filter is None or empty or the portal is None or empty, it returns False
            else it returns the result of the fnmatch function

        Args:
            portal: Portal
            path: Path

        Returns:
            fnmatch function
        """
        # return True
        my_path = self.scope['path_filter'] if 'path_filter' in self.scope else None
        my_portal = self.scope['portal'] if 'portal' in self.scope else None
        if my_path is None or len(my_path) == 0 or my_portal is None or len(my_portal) == 0:
            return False
        return \
            fnmatch(path, my_path) \
            and \
            (fnmatch(portal, my_portal) or portal == '__ALL__')

    def disconnect(self, close_code):
        """
        Description:
            Disconnect function, used to disconnect from the websocket
            It logs the disconnect request
            If the notifier listener is None, it logs a message and creates a new CmdNotifierlistener
            It removes the notifier from the notifier listener

        Args:
            self: Self  
            close_code: Close code

        Returns:
            None    

        Raises:
            Exception: If the notifier listener is None, it logs a message and creates a new CmdNotifierlistener
        """
        _logger.info(f'disconnect. {close_code}')

        for nl in WSConsumer.notifier_listener:
            nl.remove_notifier(self)

    @staticmethod
    def notify(portal: str, path: str, obj: dict) -> int:
        """
        Description:
            Notify function, used to notify the portal, path and object
            If the settings activate ws is True, it logs a message and creates a new CmdNotifierlistener
            It returns the result of the notify function

        Args:
            portal: Portal
            path: Path
            obj: Object

        Returns:
            notify function
        """
        if not settings.ACTIVATE_WS:
            _logger.info(f'NOTIFICATION NOT ENABLED. portal: {portal} - path: {path} - obj: {obj}')
            return 0
        if WSConsumer.notifier_listener is None:
            _logger.error('notifier not set during notify')
            return -1

        count = 0
        for nl in WSConsumer.notifier_listener:
            count += nl.notify(portal, path, obj)

        return count

    @staticmethod
    def notify_portal(portal: str, text: str) -> int:
        """
        Description:
            Notify portal function, used to notify the portal and text
            It returns the result of the notify function

        Args:
            portal: Portal
            text: Text

        Returns:
            notify function

        Raises:
            Exception: If the portal is not found, it logs an error and returns the notify function
        """
        path, obj = build_portal_notification(portal, 'portal', text)
        return WSConsumer.notify(portal, path, obj)


class WSNotifier():
    '''
    Description:
        base web socket notifier class

    Functions:
        __init__: Constructor
        add_notifier: Add notifier function
        remove_notifier: Remove notifier function
        on_message: On message function
        notify: Notify function

    Attributes:
        __notifiers: None

    '''

    def __init__(self):
        '''
        Description:
            Constructor, used to build the web socket notifier
            It logs a message and connects to the broker
            It starts a new thread to subscribe to the broker

        Args:
            self: Self

        Returns:
            None

        Raises:
            Exception: If the broker is not found, it logs an error and returns the subscribe function
        '''
        _logger.debug('building web socket notifier')
        self.__notifiers: list[WSConsumer] = []

    def add_notifier(self, notifier: WSConsumer):
        """
        Description:
            Add notifier function, used to add a notifier
            It appends the notifier to the list of notifiers

        Args:
            notifier: WSConsumer

        Returns:
            None

        Raises:
            Exception: If the notifier is not found, it logs an error and returns the append function
        """
        self.__notifiers.append(notifier)

    def remove_notifier(self, notifier: WSConsumer):
        """
        Description:
            Remove notifier function, used to remove a notifier
            It removes the notifier from the list of notifiers

        Args:
            notifier: WSConsumer

        Returns:
            None

        Raises:
            Exception: If the notifier is not found, it logs an error and returns the remove function
        """
        _logger.debug(f'remove_notifier: pre len: {len(self.__notifiers)}')
        if notifier in self.__notifiers:
            self.__notifiers.remove(notifier)
        _logger.debug(f'remove_notifier: post len: {len(self.__notifiers)}')

    def notify(self, portal: str, path: str, obj: dict) -> int:
        """
        Description:
            Notify function, used to notify the portal, path and object
            It logs a message and initializes the notified count
            It iterates over the notifiers
            If the notifier matches the portal and path, it sends the json object
            It increments the notified count
            It logs a message and returns the notified count

        Args:
            - portal: Portal
            - path: Path
            - obj: Object

        Returns:
            notified_count

        Raises:
            Exception: If the notifier matches the portal and path, it sends the json
        """
        notified_count = 0
        for notifier in self.__notifiers:
            try:
                if notifier.match(portal, path):
                    notifier.send_json(obj)
                    notified_count += 1
            except Exception as e:
                _logger.exception('', exc_info=e)

        _logger.debug(f'sent {notified_count} notifications to portal {portal}. path: {path}')

        return notified_count


class KafkaWSNotifier(WSNotifier, broker.BrokerSubscriber):
    '''
    Description:
        web socket notifier class as kakfa broker subscriber

    Functions:
        __init__: Constructor
        on_message: On message function

    '''

    def __init__(self):
        '''
        Description:
            Constructor, used to build the web socket notifier
            It logs a message and connects to the broker
            It starts a new thread to subscribe to the broker

        Args:
            self: Self

        Returns:
            None

        Raises:
            Exception: If the broker is not found, it logs an error and returns the subscribe function
        '''
        # call the WSNotifier parent constructor
        super().__init__()
        broker_connection = broker.get_kafka_broker()
        topic = os.environ.get('ACROWEB3_KAFKA_NOTIFIER_TOPIC', None)
        if topic is None:
            _logger.error(
                'no ACROWEB3_KAFKA_NOTIFIER_TOPIC found in environment')
            return
        if broker_connection is None:
            _logger.error('no kafka broker connection')
            return
        broker_connection.subscribe(self, topic, str(uuid.uuid4()))

    def on_message(self, obj: object, body: str, routing_key: str) -> None:
        """
        Description:
            On message function, used to notify the offset, object and body
            It logs a message and parses the notification body
            If the path is not found, it logs a warning and returns None
            If the object is not found, it logs a warning and returns None
            It notifies the portal, path and body

        Args:
            - offset: Offset
            - obj: Object
            - body: Body

        Returns:
            None

        Raises:
            Exception: If the path is not found, it logs a warning and returns None
        """

        if obj is None:
            _logger.warning('received empty notification object')
        portal, path, body = parse_notification_body(obj)
        if path is not None and obj is not None:
            c = self.notify(portal, path, body)
            _logger.debug(f'notified {c} connections')


class SentinelWSNotifier(WSNotifier, SentinelListener):
    '''
    Description:
        web socket notifier class as rabbitmq broker subscriber

    Functions:
        __init__: Constructor
        on_message: On message function

    '''

    def __init__(self):
        # call the SentinelListener constructor
        WSNotifier.__init__(self)
        notify_only_exceedings = os.environ.get('ACROWEB3_SENTINEL_NOTIFY_ONLY_EXCEEDINGS', 'false').lower() in ['true', '1', 't', 'y', 'yes']
        SentinelListener.__init__(self, None, None, only_with_exceedings=notify_only_exceedings)

        sentinel_client = SentinelClient('')
        sentinel_client.add_sentinel_listener(self)

    def callback(self, data: dict, routing_key: str):
        try:
            # portal, path, body = parse_notification_body(obj)
            _logger.debug(f'SentinelWSNotifier: routing-key: {routing_key} - data len: {len(data)}')
            if data is not None:                
                c = self.notify('__ALL__', routing_key, data)
                _logger.debug(f'SentinelWSNotifier: notified {c} connections with routing key {routing_key}')
        except Exception as e:
            _logger.exception('', exc_info=e)



class NewAcqWSNotifier(WSNotifier, NewAcqListener):
    '''
    Description:
        web socket notifier class as rabbitmq broker subscriber

    Functions:
        __init__: Constructor
        on_message: On message function

    '''

    def __init__(self):
        # call the SentinelListener constructor
        WSNotifier.__init__(self)
        NewAcqListener.__init__(self)

        client = NewAcqClient()
        client.add_newacq_listener(self)

    def callback(self, data: dict, routing_key: str):
        try:
            # portal, path, body = parse_notification_body(obj)
            _logger.debug(f'NewAcqWSNotifier: routing-key: {routing_key} - data: {data}')
            # if data is a list, we notify each element
            if not isinstance(data, list):
                data = [data]
            data_ids = [d['dataid'] for d in data if 'dataid' in d]
            c = self.notify('__ALL__', 'newacq', data_ids)
            _logger.debug(f'NewAcqWSNotifier: notified {c} connections with routing key {routing_key}')
        except Exception as e:
            _logger.exception('', exc_info=e)
