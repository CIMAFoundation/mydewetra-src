__doc__ = """

Description:
    This file contains the models for the portal app.

Classes:
    - ApplicationCategory: This class is a model for the application category.
    - Application: This class is a model for the application.
    - ApplicationRole: This class is a model for the application role.
    - PortalConfig: This class is a model for the portal config.
    - DomainGroup: This class is a model for the domain group.
    - Domain: This class is a model for the domain.
    - UserData: This class is a model for the user data.
    - DashboardSettings: This class is a model for the dashboard settings.
    - WidgetType: This class is a model for the widget type.
    - Widget: This class is a model for the widget.
    - WidgetInstance: This class is a model for the widget instance.
    - DomainWidgetSettings: This class is a model for the domain widget settings.
    - UserWidgetSettings: This class is a model for the user widget settings.
"""

from typing import Collection, Iterable, Optional
from django.db import models
from django.db.models.deletion import CASCADE
from django.core.exceptions import ValidationError
from django.utils import timezone


class ApplicationCategory(models.Model):
    id = models.CharField(max_length=255, primary_key=True)
    category = models.CharField(max_length=255)
    title = models.TextField()
    order = models.IntegerField(default=0, null=True, blank=True)

    def __str__(self):
        return self.category


class Application(models.Model):
    id = models.CharField(max_length=255, primary_key=True)
    category = models.ForeignKey(
        ApplicationCategory, on_delete=models.CASCADE, related_name='content')
    text = models.CharField(max_length=255)
    title = models.TextField()
    always_visible = models.BooleanField(default=False)

    icon = models.CharField(max_length=255)
    icon_svg = models.TextField(
        null=True, blank=True,
        default=None,
        help_text='SVG icon'
    )

    link = models.CharField(max_length=255)
    props = models.JSONField(null=True, blank=True)

    def __str__(self):
        return self.title


class ApplicationRole(models.Model):
    application = models.ForeignKey(
        Application, on_delete=CASCADE, related_name='roles')
    name = models.CharField(max_length=255)
    descr = models.TextField(null=True, blank=True)
    # set application rand name unique together

    class Meta:
        unique_together = ('application', 'name',)

    def __str__(self):
        return f'{self.name} - {self.application}'


class PortalConfig(models.Model):
    id = models.CharField(max_length=255, primary_key=True)
    hosts = models.TextField()
    auth = models.JSONField()
    skin = models.JSONField()

    partner_svg = models.TextField(
        null=True, blank=True,
        default=None,
        help_text='Partner SVG icon'
    )

    owner_svg = models.TextField(
        null=True, blank=True,
        default=None,
        help_text='Owner SVG icon'
    )

    desktop_logo_svg = models.TextField(
        null=True, blank=True,
        default=None,
        help_text='Desktop SVG icon'
    )

    mobile_logo_svg = models.TextField(
        null=True, blank=True,
        default=None,
        help_text='Mobile SVG icon'
    )

    favicon_svg = models.TextField(
        null=True, blank=True,
        default=None,
        help_text='Favicon SVG icon'
    )

    background_svg = models.TextField(
        null=True, blank=True,
        default=None,
        help_text='Background SVG pattern'
    )

    apps_config = models.JSONField(
        null=True, blank=True,
        default=[{"app": "", "options": {"title":"", "logo_name":""}}],
        help_text='Apps Config'
    )

    credits = models.JSONField(
        null=True, blank=True,
        default=[{"label": "", "content": ""}],
        help_text='Credits'
    )


    def __str__(self) -> str:
        return str(self.id)


class DomainGroup(models.Model):
    name = models.CharField(max_length=255)
    portal = models.ForeignKey(
        PortalConfig, on_delete=CASCADE, related_name='groups')
    descr = models.TextField()
    date = models.DateTimeField(auto_now_add=True)
    img = models.BinaryField(null=True, blank=True)
    color = models.CharField(max_length=255)


class Domain(models.Model):
    name = models.CharField(max_length=255)
    portal = models.ForeignKey(
        PortalConfig, on_delete=CASCADE, related_name='domains')
    descr = models.TextField()
    lon1 = models.FloatField()
    lon2 = models.FloatField()
    lat1 = models.FloatField()
    lat2 = models.FloatField()
    date = models.DateTimeField(auto_now_add=True)
    props = models.JSONField(null=True, blank=True)
    img = models.BinaryField(null=True, blank=True)
    apps = models.ManyToManyField(
        Application, related_name='domains', blank=True)
    groups = models.ManyToManyField(
        DomainGroup, related_name='domains', blank=True)

    class Meta:
        unique_together = ('name', 'portal',)

    def __str__(self):
        return f'{self.descr}@{self.portal.id}'


class UserData(models.Model):
    username = models.CharField(max_length=255)
    first_name = models.CharField(max_length=255, null=True, blank=True)
    last_name = models.CharField(max_length=255, null=True, blank=True)
    email = models.CharField(max_length=255, null=True, blank=True)
    email_enabled = models.BooleanField(default=False)
    creation_date = models.DateTimeField(default=timezone.now)
    phone_nr = models.CharField(max_length=255, null=True, blank=True)
    phone_enabled = models.BooleanField(default=False)
    color = models.CharField(max_length=255, default='#264654')
    domain = models.ForeignKey(
        Domain, on_delete=CASCADE, related_name='users', null=True, blank=True)
    portal = models.ForeignKey(
        PortalConfig, on_delete=CASCADE, related_name='users', null=True, blank=True)
    extra_domains = models.ManyToManyField(
        Domain, related_name='extra_users', blank=True)
    roles = models.ManyToManyField(
        ApplicationRole, related_name='users', blank=True)
    props = models.JSONField(null=True, blank=True)
    img = models.BinaryField(null=True, blank=True)

    def __str__(self):
        return f'{self.username}@{self.domain.name}@{self.domain.portal.id}'

    def validate_unique(self, exclude: Collection[str] | None = ...) -> None:
        if UserData.objects.filter(username__iexact=self.username, domain__portal_id=self.domain.portal.id).exclude(id=self.id).exists():
            raise ValidationError(
                f'User {self.username} already exists in this portal')

    def save(self, *args, **kwargs) -> None:
        self.validate_unique()
        return super(UserData, self).save(*args, **kwargs)


class DashboardSettings(models.Model):
    portal = models.ForeignKey(
        PortalConfig, on_delete=CASCADE, related_name='dashboards')    
    domain = models.ForeignKey(
        Domain, on_delete=CASCADE, related_name='dashboards', null=True, blank=True)
    user = models.ForeignKey(
        UserData, on_delete=CASCADE, related_name='dashboards', null=True, blank=True)
    settings = models.JSONField(null=True, blank=True)

    def __str__(self):
        return f'Dashboard {self.portal} (Domain: {self.domain} - User: {self.user})'


class WidgetType(models.Model):
    name = models.CharField(max_length=255, primary_key=True)
    descr = models.TextField()

    def __str__(self):
        return self.name


class Widget(models.Model):
    name = models.CharField(max_length=255, primary_key=True)
    title = models.CharField(max_length=255)
    widget_type = models.ForeignKey(
        WidgetType, on_delete=CASCADE, related_name='widgets')
    data_url = models.CharField(max_length=255)
    settings = models.JSONField(null=True, blank=True)

    def __str__(self):
        return self.name

class WidgetInstance(models.Model):
    widget = models.ForeignKey(Widget, on_delete=CASCADE)
    portal = models.ForeignKey(
        PortalConfig, on_delete=CASCADE, related_name='widget_instances')
    settings = models.JSONField(null=True, blank=True)
    disallowed_domains = models.ManyToManyField(
        Domain, related_name='disallowed_widgets', blank=True)

    def __str__(self):
        return f'{self.widget.name}@{self.portal}'


class DomainWidgetSettings(models.Model):
    domain = models.ForeignKey(
        Domain, on_delete=CASCADE, related_name='widget_settings')
    widget_instance = models.ForeignKey(
        WidgetInstance, on_delete=models.CASCADE, related_name='domain_settings')
    settings = models.JSONField(null=True, blank=True)

    def __str__(self):
        return f'{self.domain}@{self.widget_instance}'

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['domain', 'widget_instance'], name='unique_domain_widget_settings')
        ]


class UserWidgetSettings(models.Model):
    user = models.ForeignKey(
        UserData, on_delete=CASCADE, related_name='widget_settings')
    widget_instance = models.ForeignKey(
        WidgetInstance, on_delete=models.CASCADE, related_name='user_settings')
    settings = models.JSONField(null=True, blank=True)

    def __str__(self):
        return f'{self.user}@{self.widget_instance}'

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'widget_instance'], name='unique_user_widget_settings')
        ]


class UserAppSettings(models.Model):
    user = models.ForeignKey(
        UserData, on_delete=CASCADE, related_name='app_settings')
    app = models.ForeignKey(
        Application, on_delete=models.CASCADE, related_name='user_settings')
    key = models.CharField(max_length=255, default='default')
    data = models.JSONField(null=True, blank=True)
    #unique together user and app and key
    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'app', 'key'], name='unique_user_app_settings')
        ]

    def __str__(self):
        return f'{self.user}@{self.app} - {self.key}'