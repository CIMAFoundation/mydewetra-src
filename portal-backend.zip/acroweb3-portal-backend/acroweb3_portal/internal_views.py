'''
Created on Oct 22, 2019

@author: doy

Description:
    This file contains the internal views for the portal.
    The internal views are used to manage the portal data.

Classes:
    - IssuerView: This class is a viewset for the issuer.
    - AuthenticateView: This class is a viewset for the authentication.
    - InternalDomainView: This class is a viewset for the internal domain.
    - WSPushView: This class is a viewset for the web socket push.
    - InternalActivityWriterView: This class is a viewset for the internal activity writer.

Attributes:
    - _logger: Logger object
'''
from rest_framework import status, viewsets, mixins
from rest_framework.response import Response
from acroweb3_portal.auth import get_auth_component, get_portal_config_by_host
from acroweb3_portal.models import Domain
from acroweb3_portal.serializers import DomainSerializer
from acroweb3_portal.websocket import WSConsumer
from rest_framework.decorators import action
from acroweb3.portal_tools import parse_notification_body
from acroweb3_api import get_host_by_request, get_logger
from acroweb3_api.auth import AcrowebAuthData
from activity_book.manager import ActivityManager
from acroweb3 import AcrowebException

_logger = get_logger(__name__)

class IssuerView(viewsets.ViewSet):
    """
    Description:
        This class is a viewset for the issuer.
    
    Functions:
        - list: This function is used to get the issuer.
    
    Raises:
        - Response object: If portal is not found in the request param.
        
    Returns:    
        - Response object
    """
    def list(self, request):
        host = request.GET['host'] if 'host' in request.GET else get_host_by_request(request)
        try:
            cfg = get_portal_config_by_host(host)
            return Response({
                'issuer': cfg.auth['issuer'] if 'issuer' in cfg.auth else None,
                'portal': cfg.id
            })
        except Exception as e:
            print(f'ERROR for host {host}:{str(e)}')
            return Response({
                    'error': str(e)
                }, status=status.HTTP_500_INTERNAL_SERVER_ERROR) 


class AuthenticateView(viewsets.ViewSet):
    """
    Description:
        This class is a viewset for the authentication.
    
    Functions:
        - create: This function is used to create the authentication.
    
    Raises:
        - Response object: If the body is invalid.
    
    Returns:
        - Response object
    """
    def create(self, request):         
        body = request.data
        if not all([f in body for f in ['access_token', 'host', 'client_id']]):
            return Response('invalid body', status=status.HTTP_400_BAD_REQUEST)        
        
        #validate token and build authentication data
        try:
            chosen_domain = body['chosen_domain'] if 'chosen_domain' in body else None
            data:AcrowebAuthData = get_auth_component().validate_token_and_build_auth_data(body['access_token'], body['host'], body['client_id'], chosen_domain=chosen_domain)
        except AcrowebException as e:
            return Response(str(e), status=status.HTTP_401_UNAUTHORIZED)
        except Exception as e:
            return Response(str(e), status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        return Response(data.to_dict())


class InternalDomainView(viewsets.GenericViewSet, mixins.RetrieveModelMixin):
    """
    Description:
        This class is a viewset for the internal domain.
        
    Attributes:
        queryset: Queryset object
        serializer_class: Serializer
    
    Returns:
        - Response object
    """
    queryset = Domain.objects.all()    
    serializer_class = DomainSerializer


class WSPushView(viewsets.ViewSet):
    """
    Description:
        This class is a viewset for the web socket push.
    
    Functions:
        - create: This function is used to create the web socket push.
    
    Raises:
        - Response object: If the body is invalid.
        
    Returns:
        - Response object
    """
    def create(self, request):
        notification_body = request.data
        portal, path, obj = parse_notification_body(notification_body)
        if portal is None or path is None or obj is None:
            return Response('invalid body', status=status.HTTP_400_BAD_REQUEST)
        notified_count = WSConsumer.notify(portal, path, obj)
        return Response(notified_count);


class InternalActivityWriterView(viewsets.ViewSet):
    """
    Description:
        This class is a viewset for the internal activity writer.
        
    Functions:
        - open_session: This function is used to open/close a session.
        - close_session: This function is used to open/close a session.
        - create: This function is used to create the activity.
    """    

    @action(detail=False, methods=['post'])
    def open_session(self, request):
        """
        Description:
            This function is used to open a session.

        Args:
            - request: Request object

        Returns:
            - Response object
        
        Raises:
            - Response object: If the body is invalid.
        
        """
        address = request.get_host()
        body = request.data
        if not all(f in body for f in ['user', 'portal', 'domain']):
            return Response('invalid body', status=status.HTTP_400_BAD_REQUEST)
        user = body['user']
        portal = body['portal']
        domain = body['domain']
        session = ActivityManager().create_session(user, portal, domain, address, 'new session')
        return Response({'id': session.id})


    @action(detail=False, methods=['delete'])
    def close_session(self, request):
        """
        Description:
            This function is used to close a session.
        
        Args:
            - request: Request object

        Returns:
            - Response object
        
        Raises:
            - Response object: If the query params "user" and "portal" are required.
        """
        address = request.get_host()
        user = request.query_params.get('user')
        portal = request.query_params.get('portal')
        if user is None or portal is None:
            return Response('query params "user" and "portal" required', status=status.HTTP_400_BAD_REQUEST)
        ActivityManager().close_session(user, portal, address)
        return Response('ok')


    def create(self, request):
        """
        Description:
            This function is used to create an activity.
            Try to create an activity and return the id.

        Args:
            - request: Request object
        
        Returns:
            - Response object
        
        Raises:
            - Response object: If the body is invalid.
        """
    
        body = request.data
        if not all(f in body for f in ['user', 'portal', 'domain', 'app', 'text']):
            return Response('invalid body', status=status.HTTP_400_BAD_REQUEST)
        try:
            activity = ActivityManager().create(body['user'], body['portal'], body['domain'], request.get_host(), body['app'], body['text'])
        except Exception as e:
            _logger.error('', exc_info=e)
            return Response(str(e), status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response({'id': activity.id})



