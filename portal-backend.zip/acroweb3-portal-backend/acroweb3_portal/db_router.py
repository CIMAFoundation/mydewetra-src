"""
Description: 
        This file contains the database router for the activity_book app.

Classes:
        - ActivityRouter: This class is a database router for the activity_book app.

"""
class ActivityRouter:
    """
    Description:
        This class is a database router for the activity_book app.
        
    Functions:
        - db_for_read: This function is used to get the database for read.
        - db_for_write: This function is used to get the database for write.
        - allow_relation: This function is used to allow relation.
        - allow_migrate: This function is used to allow migration.
    
    Attributes:
        - route_app_labels: list
    """
    route_app_labels = {'activity_book'}

    def db_for_read(self, model, **hints):
        """
        Description:
            This function is used to get the database for read.

        Args:
            - model: Model object
            - hints: dict
        
        Returns:
            - str
        """
        if model._meta.app_label in self.route_app_labels:
            return 'activity'
        return None

    def db_for_write(self, model, **hints):
        """
        Description:
            This function is used to get the database for write.
        
        Args:
            - model: Model object
            - hints: dict
        
        Returns:
            - str
        """
        if model._meta.app_label in self.route_app_labels:
            return 'activity'
        return None

    def allow_relation(self, obj1, obj2, **hints):
        """
        Description:
            This function is used to allow relation.

        Args:
            - obj1: Model object
            - obj2: Model object
            - hints: dict
        
        Returns:
            - bool
        """
        if (obj1._meta.app_label in self.route_app_labels or
                obj2._meta.app_label in self.route_app_labels):
            return True
        return None

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        """
        Description:
            This function is used to allow migration.
        
        Args:
            - db: str
            - app_label: str
            - model_name: str
            - hints: dict
        
        Returns:
            - bool
        
        Raises:
            - None
        """
        if app_label in self.route_app_labels:
            return db == 'activity'
        return None