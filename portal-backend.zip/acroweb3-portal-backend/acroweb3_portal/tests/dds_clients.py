'''
Created on Apr 14, 2020

@author: doy
'''
from acroweb3.dds import DDSError
from acroweb3.dds.router import DDSClientRouter
import time
import os
from dotenv import load_dotenv


if __name__ == '__main__':
    
    layer_id = 'RAINMAP_ITALY'
    t2 =  time.time() #1624008630
    t1 = t2 - 1*86400
    
    serie_id = 'autpor.dusts'
    
    load_dotenv()
    
    dds_server = [
        {'url':os.environ.get('TEST_DDSTEST_URL'), 'user':os.environ.get('TEST_DDSTEST_USER'), 'password':os.environ.get('TEST_DDSTEST_PASSWORD')},
        {'url':os.environ.get('TEST_DDS_URL'), 'user':os.environ.get('TEST_DDS_USER'), 'password':os.environ.get('TEST_DDS_PASSWORD')},
    ]


    for dds in dds_server:
        url = dds['url']
        user = dds['user']
        password = dds['password']
        
        print(f'\n\n------------------------------------------------------ {url}\n')
         
        print('--------------------- MAP\n')
         
        client = DDSClientRouter().get_dds_map_client(url, user, password)
 
        supported_datas = client.supported()
        for d in supported_datas:
            if d==layer_id:
                print(f'FOUND!!! {d} --> {supported_datas[d]}')
                break;
             
        print('\nPROPERTIES')
        prop = client.properties(layer_id)
        for attr in prop['layerProperties']['attributes']:
            if 'visible' in attr and attr['visible'] != 'false':
                print(attr['name'])
                if not isinstance(attr['entries'], list):  attr['entries'] = [attr['entries']]
                print(f'\ttype: {attr["type"]}')
                print('\tentries:')
                for entry in attr['entries']:
                    print(f'\t\t{entry["value"]}')
                    if 'referredValues' in entry and entry['referredValues']:
                        print('\t\t\treferred values')
                        if not isinstance(entry['referredValues']['entry'], list):  entry['referredValues']['entry'] = [entry['referredValues']['entry']]
                        for rv in entry['referredValues']['entry']:
                            print(f'\t\t\t\t{rv["key"]} --> {rv["value"]}')
                print(f'\tselected entry: {attr["selectedEntry"]["value"]}')
                 
         
        print('\nAVAILABLES')
        dates = client.availability(prop, t1, t2)
        for d in dates:
            print(f'\t{d["description"]} --> TS: {d["date"]} - ID: {d["id"]}')
             
             
        print('\nPUBBLICATIONS')
        for d in dates:
            pub_result = client.publish(prop, d, t1, t2)
            print(f"\t{d['description']} --> {pub_result['layerid']} ({pub_result['layertype']})")
            style = client.getLayerStyle(pub_result['layerid'])
            print(f'\t\tstyle: {style}')
            bbox = client.getLayerBBox(pub_result['layerid'])
            print(f'\t\tBBOX: {bbox}')
            break;
            
            
            
        print('\n--------------------- SERIE\n')
        
        
        client = DDSClientRouter().get_dds_serie_client(url, user, password)

        supported_datas = client.supported()
        for d in supported_datas:
            if d==serie_id:
                print(f'FOUND!!! {d} --> {supported_datas[d]}')
                break;
            
            
        print(f'\nPROPERTIES')
        prop = client.properties(serie_id)
        for p in prop:
            print(f'{p} --> {prop[p]}')
        fidField = prop['fidField']
        
        print(f'\nCOMPATIBLES:')
        compatibles = client.compatibles(serie_id)
        for c in compatibles:
            print(f"\t{c['descr']}")
        
        print(f'\nAVAILABLES:')
        availability = client.availability(serie_id, t1, t2)
        print(availability)
        
        print(f'\nFEATURES')
        features = client.featuresDDS(serie_id, t1, t2, {})
        for f in features['features']:
            print(f)
            fid = f['properties'][fidField]
            print(f'\t{fid}:')
            try:
                series = client.series(serie_id, fid, t1, t2)
                if not isinstance(series, list): series = [series] 
                for serie in series:
                    print(f"\t\t{serie['values']}")
                break
            except DDSError as e:
                print(f'\t\tDDS ERROR: %s'%(str(e)))

