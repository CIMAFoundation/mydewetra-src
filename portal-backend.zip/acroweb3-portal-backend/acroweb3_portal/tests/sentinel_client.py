__doc__ ='''
Created on Apr 14, 2020
@author: doy


Description:
    This file contains the viewset for the community data.
    The community data viewset is used to get the community data from the IDP.
    The community data includes the users, domains and groups.
'''
from acroweb3.sentinel.client import SentinelClient
import time
import os
from dotenv import load_dotenv


if __name__ == '__main__':
    
    load_dotenv()
    
    sentinel_server = os.environ.get('SENTINEL_URL')

    client = SentinelClient(sentinel_server)

    aggr_data = client.aggregated_data('regions_it', 'Dewetra%Default', 'national_PLUVIOMETRO', 2)    
    for data in aggr_data:
        print(f"{data['featureId']} --> {len(data['values'])} values")


    thrs  = client.thr_by_group('national_PLUVIOMETRO')

    for thr in thrs:
        print(f"{thr['layer']}.{thr['fid']}.{thr['name']} = {thr['value']}")

    pass
