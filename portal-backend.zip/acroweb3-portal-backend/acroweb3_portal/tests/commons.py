
from acroweb3_portal.models import Application, ApplicationCategory, DashboardSettings\
    , PortalConfig, UserWidgetSettings, Widget, WidgetInstance, WidgetType

def init_db():
        cat1 = ApplicationCategory.objects.create(
            id='menu-cat1',
            category='cat1',
            descr='first category'
        )            
        Application.objects.create(
            id = 'app1',
            category = cat1,
            name = 'application one',
            descr = 'application one',
            icon = 'app1',
            link = '/app1',
        )

        cat2 = ApplicationCategory.objects.create(
            id='menu-cat2',
            category='cat2',
            descr='second category')
        Application.objects.create(
            id = 'app2',
            category = cat2,
            name = 'application two',
            descr = 'application two',
            icon = 'app2',
            link = '/app2',
        )


        cfg1 = PortalConfig.objects.create(
            id = 'portal1',
            hosts = 'portal1.com',
            auth = {'auth': 'portal1-keycloak'},
            skin = {'color': 'red'}
        )
        cfg2 = PortalConfig.objects.create(
            id = 'portal2',
            hosts = 'portal2.com',
            auth = {'auth': 'portal2-keycloak'},
            skin = {'color': 'blue'}            
        )

        DashboardSettings.objects.create(
            portal = cfg1,
            settings = {'settings': 'portal1.ALL'}
        )
        DashboardSettings.objects.create(
            portal = cfg1,
            domain = 'domain1',
            settings = {'settings': 'portal1.domain1.ALL'}
        )
        DashboardSettings.objects.create(
            portal = cfg1,
            domain = 'domain1',
            user = 'user1',
            settings = {'settings': 'portal1.domain1.user1'}
        )
        DashboardSettings.objects.create(
            portal = cfg2,
            domain = 'domain2',
            settings = {'settings': 'portal2.domain2.ALL'}            
        )

        wt1 = WidgetType.objects.create(
            name = 'type1',
            descr = 'type one'
        )
        w1 =Widget.objects.create(
            name = 'widget1',
            descr = 'widget 1',
            widget_type = wt1,
            data_url = '/app1/widget1',
            settings = {'settings': 'widget1.ALL'}
        )
        wi1 = WidgetInstance.objects.create(
            widget = w1,
            portal = cfg1,
            settings = {'settings': 'widget1.portal1.ALL'}
        )       
        UserWidgetSettings.objects.create(
            user = 'user1',
            widget_instance = wi1,
            settings = {'settings': 'widget1.portal1.user1'}
        )
