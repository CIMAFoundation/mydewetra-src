
__doc__ = """
Description:
    This file contains the admin configuration for the acroweb3_portal app.

Classes:
    - Acroweb3Admin: This class is a base class for the admin configuration.
    - ApplicationAdmin: This class is an admin configuration for the Application model.
    - UserDataAdmin: This class is an admin configuration for the UserData model.
"""
import urllib

from django import forms
from django.contrib import admin
from django.db import models
from django.utils.html import format_html
from django_json_widget.widgets import JSONEditorWidget

from acroweb3_portal.models import (Application, ApplicationCategory,
                                    DashboardSettings, Domain, PortalConfig,
                                    UserData, UserWidgetSettings, Widget,
                                    WidgetInstance, WidgetType, DomainWidgetSettings, 
                                    UserAppSettings)


class Acroweb3Admin(admin.options.ModelAdmin):
    save_as = True
    list_max_show_all = 1000
    list_per_page = 200
    search_fields = ['name']
    formfield_overrides = {
        # fields.JSONField: {'widget': JSONEditorWidget}, # if django < 3.1
        models.JSONField: {'widget': JSONEditorWidget},
    }


@admin.register(Application)
class ApplicationAdmin(Acroweb3Admin):
    search_fields = ['id']
    list_filter = ('category', )
    list_display = ('icon_svg_view', 'id', 'title', 'category', 'link')
    list_display_links = ('icon_svg_view', 'id', 'title')

    readonly_fields = ['icon_svg_view']

    def icon_svg_view(self, obj):
        if not obj.icon_svg:
            return None
        svg_encoded = urllib.parse.quote(obj.icon_svg)
        url = f'data:image/svg+xml;utf8,{svg_encoded}'

        return format_html(f'<img src="{url}" width="30" height="30" style="background-color:white" />')

    icon_svg_view.short_description = 'Icon'


@admin.register(UserData)
class UserDataAdmin(Acroweb3Admin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'domain',)
    list_display_links = ('username', 'email', 'first_name', 'last_name',)
    list_filter = ('domain', )

    filter_horizontal = ('roles', 'extra_domains',)
    readonly_fields = ['img_view']
    search_fields = ['username', 'email', 'first_name', 'last_name']

    def img_view(self, obj):
        if not obj.img:
            return None
        url = f'data:image/png;base64,{obj.img}'
        return format_html(f'<img src="{url}" width="30" height="30" style="background-color:white" />')


admin.autodiscover()
# admin.site.register(Application, Acroweb3Admin)
admin.site.register(ApplicationCategory, Acroweb3Admin)
admin.site.register(PortalConfig, Acroweb3Admin)
admin.site.register(WidgetType, Acroweb3Admin)
admin.site.register(Widget, Acroweb3Admin)
admin.site.register(WidgetInstance, Acroweb3Admin)
admin.site.register(UserWidgetSettings, Acroweb3Admin)
admin.site.register(DomainWidgetSettings, Acroweb3Admin)
admin.site.register(DashboardSettings, Acroweb3Admin)
admin.site.register(Domain, Acroweb3Admin)
admin.site.register(UserAppSettings, Acroweb3Admin)
