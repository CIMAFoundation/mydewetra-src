"""acroweb3 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.contrib import admin
from django.urls import path, re_path
from django.urls.conf import include
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from rest_framework import permissions
from rest_framework.routers import DefaultRouter
from acroweb3_portal.admin_app.internal_views import CommunityDataView
from acroweb3_portal.admin_app.views import AdminApplicationsView, AdminConfigView, AdminDomainGroupView, AdminDomainsView, \
    AdminRolesView, AdminUploadView, AdminUsersView, AdminApplicationsUpdateView
from acroweb3_portal.internal_views import AuthenticateView, InternalDomainView, IssuerView, WSPushView, InternalActivityWriterView
from acroweb3_portal.views import ApplicationCategoryView, DashboardSettingsView, ImageView, \
    PortalConfigView, ServerTimeView, UserImagesView, WidgetView, TranslationView, UserAppSettingsView
from acroweb3_api.views import acroweb3_to_portal_urls
from acroweb3_api.admin_auth import bypass_admin_login
from activity_book.views import ActivityBookSessionView, ExternalActivityWriterView
from django.views.static import serve 
import os

#router for public api
public_router = DefaultRouter()
public_router.register('now', ServerTimeView, basename='servertime')
public_router.register('image', ImageView, basename='image')
public_router.register('user-images', UserImagesView, basename='user-images')
public_router.register('user-data', UserImagesView, basename='user-data')
public_router.register('applications', ApplicationCategoryView, basename='applications')
public_router.register('config', PortalConfigView, basename='config')
public_router.register('widget', WidgetView, basename='widget')
public_router.register('dashboard', DashboardSettingsView, basename='dashboard')
public_router.register('activity', ExternalActivityWriterView, basename='activity')
public_router.register('activitybook', ActivityBookSessionView, basename='activitybook')
public_router.register('auth', AuthenticateView, basename='auth')
public_router.register('translate',TranslationView,basename='translate')
public_router.register('userappsettings',UserAppSettingsView,basename='userappsettings')

#/<str:portal>/<str:app>/<str:language>
#router for private api
private_router = DefaultRouter()
private_router.register('issuer', IssuerView, basename='issuer')
private_router.register('domain', InternalDomainView, basename='domain')
private_router.register('activity', InternalActivityWriterView, basename='activity')
private_router.register('notify', WSPushView, basename='notify')
private_router.register('auth', AuthenticateView, basename='auth')
private_router.register('community', CommunityDataView, basename='community')

#router for acroweb admin api
acroweb_admin_router = DefaultRouter()
acroweb_admin_router.register('config', AdminConfigView, basename='config')
acroweb_admin_router.register('users', AdminUsersView, basename='users')
acroweb_admin_router.register('upload-image', AdminUploadView, basename='upload-image')
acroweb_admin_router.register('roles', AdminRolesView, basename='roles')
acroweb_admin_router.register('domains', AdminDomainsView, basename='domains')
acroweb_admin_router.register('apps', AdminApplicationsView, basename='apps')
acroweb_admin_router.register('appswrite', AdminApplicationsUpdateView, basename='appswrite')
acroweb_admin_router.register('groups', AdminDomainGroupView, basename='groups')


# openapi schema view
schema_view = get_schema_view(
   openapi.Info(
      title="Acroweb3 portal backend api",
      default_version='v1',
      description="Acroweb3 Portal backend API",
      terms_of_service="https://www.acrotec.it",
      contact=openapi.Contact(email="info@acrtoec.it"),
      license=openapi.License(name="BSD License"),
   ),
   public=True,
   permission_classes=[permissions.AllowAny],
)

urlpatterns = [
    re_path(r'^public/docs/swagger(?P<format>\.json|\.yaml)$', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    re_path(r'^public/docs/swagger/$', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    re_path(r'^public/docs/redoc/$', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),

    path('public/prometheus/', include('django_prometheus.urls')),

    # re_path(r'^admin/login/', bypass_admin_login, name='bypass_admin_login'),
    # re_path(r'^admin/', admin.site.urls),

    path('public/acroweb/', include(public_router.urls)),

    path('public/acroweb_admin/', include(acroweb_admin_router.urls)),

    path('private/', include(private_router.urls)),

    re_path(r'^public/static/(?P<path>.*)$', serve, {'document_root': settings.STATIC_ROOT}), 
]

if settings.PUT_DJANGO_INSIDE_REVERSE_PROXY:
    urlpatterns += re_path(r'^admin/login/', bypass_admin_login, name='bypass_admin_login'),
    urlpatterns += re_path(r'^admin/', admin.site.urls),
else:
    urlpatterns += re_path(r'^django_admin/portal/', admin.site.urls),    


urlpatterns += acroweb3_to_portal_urls('public')

urlpatterns += staticfiles_urlpatterns()