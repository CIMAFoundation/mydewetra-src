__doc__ = """
Created on Oct 22, 2019
@author: doy

Description:
    This file contains the views for the portal.
    The views are used to get the portal data.

Classes:
    - ServerTimeView: This class is a viewset for the server time.
    - UserImagesView: This class is a viewset for the user images.
    - ApplicationCategoryView: This class is a viewset for the application category.
    - ImageView: This class is a viewset for the image.
    - PortalConfigView: This class is a viewset for the portal config.
    - DashboardSettingsView: This class is a viewset for the dashboard settings.
    - WidgetView: This class is a viewset for the widget.
    - TranslationView: This class is a viewset for the translation.

Functions:
    - get_host_by_request: This function is used to get the host by request.
    - get_logger: This function is used to get the logger.
    - get_portal_config_by_host: This function is used to get the portal config by host.

"""
import json
import time
import urllib
import urllib.parse

import requests
from acroweb3_api import get_host_by_request, get_logger
from acroweb3_api.auth import AcrowebAuthData
from django.db.models import Prefetch, Q, Value, BooleanField
from django.db.models.expressions import Case, When
from django.http import HttpResponse
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from acroweb3_portal.admin_app import get_domain_img_url, get_user_img_url
from acroweb3_portal.auth import get_portal_config_by_host
from acroweb3_portal.models import (Application, ApplicationCategory, Domain,
                                    DomainGroup, PortalConfig, UserData, WidgetInstance,
                                    UserWidgetSettings, DomainWidgetSettings,UserAppSettings)
from acroweb3_portal.serializers import ApplicationCategorySerializer
from acroweb3_portal.settings import GIT_TOKEN, GIT_TRANSLATION_URL, GIT_USER
from acroweb3_portal.admin_app.permissions import am_i_cross_coordinator

_logger = get_logger(__name__)


class ServerTimeView(viewsets.ViewSet):
    """
    Description:
        server time resource
    
    Functions:
        list: This function is used to get the server time.
    """

    def list(self, request):
        """
        server time resource
        """
        return Response({"time": int(round(time.time() * 1000))})


class UserImagesView(viewsets.ViewSet):
    """
    Description:
        user images resource
    
    Attributes:
        permission_classes: List of permission classes
    
    Functions:
        _domain_data_from_db_domain: This function is used to get the domain data from the database domain.
        list: This function is used to get the user images.

    """
    permission_classes = [permissions.IsAuthenticated]

    def _domain_data_from_db_domain(self, db_domain):
        """
        Description:
            This function is used to get the domain data from the database domain.
        
        Args:
            - db_domain: Database domain object
        
        Returns:
            - dict
        """
        return {
            "id": db_domain.id,
            "name": db_domain.name,
            "descr": db_domain.descr,
            "color": db_domain.props["color"]
            if db_domain.props and "color" in db_domain.props
            else None,
            "image": get_domain_img_url(db_domain),
            "lon1": db_domain.lon1,
            "lon2": db_domain.lon2,
            "lat1": db_domain.lat1,
            "lat2": db_domain.lat2,
            "props": db_domain.props,
        }

    def list(self, request):
        """
        Description:
            This function is used to get the user images.
        
        Attributes:
            - auth_data: AcrowebAuthData object
            - user: Database user object
            - domains: List of database domain objects
            - allowed_domains: List of allowed domains
            - current_domain: Current domain
            - data: dict
        Args:
            - request: Request object
        
        Returns:
            - Response object
        """
        auth_data: AcrowebAuthData = request.user
        user = auth_data.db_user

        # get all domains in database with name in auth_data.allowed_domains
        domains = Domain.objects.filter(
            name__in=auth_data.allowed_domains, portal_id=auth_data.portal
        )

        # domains = Domain.objects.filter(name=auth_data.domain, portal_id=auth_data.portal)
        allowed_domains = [self._domain_data_from_db_domain(user.domain)]
        current_domain = None
        for domain in domains:
            if domain.id != user.domain_id:
                allowed_domains.append(self._domain_data_from_db_domain(domain))
            if domain.name == auth_data.domain:
                current_domain = self._domain_data_from_db_domain(domain)

        if current_domain is None:
            return Response(
                f"CRITICAL ERROR: cannot find domain {auth_data.domain}",
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
        
        roles = {}
        for r in user.roles.all():
            if r.application_id not in roles:
                roles[r.application_id] = []
            roles[r.application_id].append(r.name)

        # domain = domains[0] if domains.exists() else None
        data = {
            "userColor": user.color,
            "userImage": get_user_img_url(user),
            "domainColor": current_domain["color"],
            "domainImage": current_domain["image"],
            "domainName": current_domain["name"],
            "firstName": auth_data.user_first_name if hasattr(auth_data, "user_first_name") else auth_data.user,
            "lastName": auth_data.user_last_name if hasattr(auth_data, "user_last_name") else "",
            "domainLon1": current_domain["lon1"],
            "domainLon2": current_domain["lon2"],
            "domainLat1": current_domain["lat1"],
            "domainLat2": current_domain["lat2"],
            "domainProp": current_domain["props"],
            "allowedDomains": allowed_domains,
            "currentDomain": current_domain,
            "coordinatedDomains": auth_data.coordinated_domains,
            "roles": roles,
        }
        return Response(data)


class ApplicationCategoryView(viewsets.ReadOnlyModelViewSet):
    """
    Description:
        application category resource
    
    Attributes:
        permission_classes: List of permission classes
    
    Functions:
        get_queryset: This function is used to get the queryset.
    
    """
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = ApplicationCategorySerializer

    def get_queryset(self):
        """
        Description:
            This function is used to get the queryset.
        
        Attributes:
            - auth_data: AcrowebAuthData object
            - domains: List of database domain objects
            - apps_id: List of application ids
        
        Returns:
            - Queryset
        
        Raises:
            - Response object: If domain is not found in the database.
        """
        auth_data: AcrowebAuthData = self.request.user
        domains = Domain.objects.filter(
            name=auth_data.domain, portal_id=auth_data.portal
        )
        if domains.exists():
            apps_id = [a.id for a in domains[0].apps.all()]
            return ApplicationCategory.objects.prefetch_related(
                Prefetch("content", queryset=Application.objects.filter(id__in=apps_id))
            )

        message = (
            f"cannot find domain in DB: {auth_data.domain}, portal: {auth_data.portal}"
        )

        _logger.warning(message)

        return ApplicationCategory.objects.all()


class ImageView(viewsets.ViewSet):
    """
    Description:
        image resource
    
    Attributes:
        permission_classes: List of permission classes
    
    Functions:
        - user: This function is used to get the user image.
        - domain: This function is used to get the domain image.
        - group: This function is used to get the group image.
    """
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=False, methods=["get"])
    def user(self, request, *args, **kwargs):
        """
        Description: 
            This function is used to get the user image.
        
        Attributes:
            - auth_data: AcrowebAuthData object
            - username: Username
            - users: List of database user objects
            - user: Database user object
        
        Return
            - HttpResponse object
        
        Raises:
            - Response object: If user is not found in the database.
        """
        auth_data: AcrowebAuthData = self.request.user
        username = (
            request.GET["username"] if "username" in request.GET else auth_data.user
        )
        users = UserData.objects.filter(
            username=username, domain__portal_id=auth_data.portal
        )
        if not users.exists():
            return Response(
                f"cannot find user {username}", status=status.HTTP_404_NOT_FOUND
            )
        if len(users) != 1:
            return Response(
                f"CRITICAL ERROR: found multiple {username}",
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
        user = users[0]
        return HttpResponse(user.img, content_type="image/png")

    @action(detail=False, methods=["get"])
    def domain(self, request, *args, **kwargs):
        """
        Description:
            This function is used to get the domain image.
        
        Attributes:
            - auth_data: AcrowebAuthData object
            - domain_id: Domain id
            - domain: Database domain object
        
        Args:
            - request: Request object

        Return:
            - HttpResponse object
        
        Raises:
            - Response object: If domain is not found in the database.
        """
        auth_data: AcrowebAuthData = self.request.user
        domain_id = (
            request.GET["domain"] if "domain" in request.GET else auth_data.domain
        )
        domain = Domain.objects.get(id=domain_id)
        return HttpResponse(domain.img, content_type="image/png")

    @action(detail=False, methods=["get"])
    def group(self, request, *args, **kwargs):
        """
        Description:
            This function is used to get the group image.
        
        Attributes:
            - group_id: Group id
        
        Args:
            - request: Request object
        
        Return:
            - HttpResponse object
        """
        if "group" not in request.GET:
            return Response(
                f"cannot find group in parameters", status=status.HTTP_400_BAD_REQUEST
            )
        group_id = request.GET["group"]
        group = DomainGroup.objects.get(id=group_id)
        return HttpResponse(group.img, content_type="image/png")


class PortalConfigView(viewsets.ViewSet):
    """
    Description:
        portal config resource
    
    Functions:
        list: This function is used to get the portal config.

        """

    def list(self, request):
        """
        Description:
                portal config resource
        
        Args: 
            - request: Request object

        Returns:
            - Response object
        
        Raises:
            - Response object: If an error occurs.
        """

        try:
            host = get_host_by_request(request)
            cfg = get_portal_config_by_host(host)
        except Exception as e:
            return Response(
                {"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        if 'users' in cfg.auth: # remove users from auth config
            cfg.auth.pop('users')

        return Response(
            {
                "authConfig": cfg.auth,
                "skin": cfg.skin,
                "apps_config": cfg.apps_config,
                "background_src": f'data:image/svg+xml;utf8,{urllib.parse.quote(str(cfg.background_svg))}' if cfg.background_svg is not None else None,
                "logos": {
                    "partner": cfg.partner_svg,
                    "owner": cfg.owner_svg,
                    "desktop": cfg.desktop_logo_svg,
                    "mobile": cfg.mobile_logo_svg,
                    "favicon_src": f'data:image/svg+xml;utf8,{urllib.parse.quote(str(cfg.favicon_svg))}' if cfg.favicon_svg is not None else None,
                    "credits": cfg.credits,
                },
            }
        )


class DashboardSettingsView(viewsets.ViewSet):
    """
    Description:
        dashboard settings resource

    Functions:
        list: This function is used to get the dashboard settings.
    
    Attributes:
        permission_classes: List of permission classes

    """

    permission_classes = [permissions.IsAuthenticated]

    def list(self, request):
        """
        Description:
            dashboard settings resource
        
        Args:
            - request: Request object
        
        Returns:
            - Response object

        Raises:
            - Response object: If an error occurs.
                """

        username = request.user.user
        domain_name = request.user.domain

        try:
            host = get_host_by_request(request)
            cfg = get_portal_config_by_host(host)
        except Exception as e:
            return Response(
                {"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        #all dashboard settings defined for the portal
        dashboards = cfg.dashboards.all()

        if dashboards.all() is None:
            return Response(
                {"error": f"no dashboard settings defined for {cfg}"},
                status=status.HTTP_404_NOT_FOUND,
            )

        # search user specific settings
        for dashboard_settings in dashboards:
            if (
                dashboard_settings.user is not None
                and dashboard_settings.user.username == username
                and (
                    dashboard_settings.domain is None
                    or dashboard_settings.domain.name == domain_name
                )
            ):
                return Response(dashboard_settings.settings)

        # search domain specific settings
        for dashboard_settings in dashboards:
            if (
                dashboard_settings.user is None
                and dashboard_settings.domain is not None
                and dashboard_settings.domain.name == domain_name
            ):
                return Response(dashboard_settings.settings)


        for dashboard_settings in dashboards:
            if dashboard_settings.user is None and dashboard_settings.domain is None:
                return Response(dashboard_settings.settings)

        return Response(
            {
                "error": f"default dashboard settings not found for {cfg}. User: {username}. Domain: {domain_name}"
            },
            status=status.HTTP_404_NOT_FOUND,
        )



class WidgetView(viewsets.ViewSet):
    """
    Description:
        widget resource
    
    Attributes:
        permission_classes: List of permission classes
    
    Functions:
        list: This function is used to get all allowed widgets with specific settings for the user.
        save_widget_settings: This function is used to save user settings for a widget.
    """
    permission_classes = [permissions.IsAuthenticated]

    def list(self, request):
        """
        Description:
              return all allowed widgets with specific settings for the user
        
        Args:
            - request: Request object
        
        Returns:
            - Response object
        
        Raises:
            - Response object: If an error occurs.
        """

        username = request.user.user
        domain_name = request.user.domain

        try:
            host = get_host_by_request(request)
            cfg: PortalConfig = get_portal_config_by_host(host)
        except Exception as e:
            return Response(
                {"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        # Prefetch related objects with filtering
        user_settings_prefetch = Prefetch(
            'user_settings',
            queryset=UserWidgetSettings.objects.filter(user__username=username)
        )

        domain_settings_prefetch = Prefetch(
            'domain_settings',
            queryset=DomainWidgetSettings.objects.filter(domain__name=domain_name)
        )

        # Annotate widget_instances with a boolean field that indicates whether a user is allowed to see it
        widget_instances = (
            cfg.widget_instances
            .exclude(disallowed_domains__name=domain_name)
            .prefetch_related(user_settings_prefetch)
            .prefetch_related(domain_settings_prefetch)
            .select_related('widget', 'widget__widget_type')
        )

        res = []
        for wi in widget_instances:
            user_settings = wi.user_settings.first().settings if wi.user_settings.exists() else None
            domain_settings = wi.domain_settings.first().settings if wi.domain_settings.exists() else None

            obj = {
                "id": wi.id,
                "name": wi.widget.name,
                "title": wi.widget.title,
                "type": wi.widget.widget_type.name,
                "dataUrl": wi.widget.data_url,
                "widgetSettings": wi.widget.settings,
                "widgetInstanceSettings": wi.settings,
                "domainSettings": domain_settings,
                "userSettings": user_settings,
            }

            res.append(obj)

        return Response(res)

    @action(
        detail=False,
        methods=["patch"],
        url_path="settings/(?P<widget_instance_id>[^/.]+)",
    )
    def save_widget_settings(self, request, widget_instance_id):
        """
        Description:
                save user settings for a widget

        Args:
            - request: Request object
            - widget_instance_id: Widget instance id

        Returns:
            - Response object
        
        Raises:
            - Response object: If an error occurs.
        """
        user = request.user.db_user
        data = request.data

        obj, _ = UserWidgetSettings.objects.get_or_create(
            user=user, widget_instance_id=widget_instance_id
        )
        obj.settings = data
        obj.save()

        return Response({"settings": data})

    # get all my domains with allowed flag for a widget
    @action(
        detail=False,
        methods=["get"],
        url_path="mydomains/(?P<widget_instance_id>[^/.]+)",
    )
    def mydomains(self, request, widget_instance_id):
        """
        Description:
                return all allowed domains for a widget

        Args:
            - request: Request object
            - widget_instance_id: Widget instance id

        Returns:
            - Response object
        
        Raises:
            - Response object: If an error occurs.
        """
        user = request.user.db_user

        # the user must be ad administrator or a cross-coordinator of the admin application
        if not am_i_cross_coordinator(request, user):
            return Response({"error": "You are not authorized to perform this action"}, status=status.HTTP_403_FORBIDDEN)

        db_widget_instance = WidgetInstance.objects.get(id=widget_instance_id)

        domains = list(user.extra_domains.all()) + [user.domain]
        disallowed_domains = db_widget_instance.disallowed_domains.all()

        res = []
        for db_domain in domains:
            is_disallowed = db_domain in disallowed_domains
            res.append({
                "id": db_domain.id,
                "name": db_domain.name,
                "descr": db_domain.descr,
                "color": db_domain.props["color"] if db_domain.props and "color" in db_domain.props else None,
                "image": get_domain_img_url(db_domain),
                'allowed' : not is_disallowed,
            })
            

        return Response(res)


    @action(
        detail=False,
        methods=["patch"],
        url_path="allow_domain/(?P<widget_instance_id>[^/.]+)/(?P<domain_id>[^/.]+)",
    )
    def allow_domain(self, request, widget_instance_id, domain_id):
        """
        Description:
                disallow domain for a widget

        Args:
            - request: Request object
            - widget_instance_id: Widget instance id
            - domain_id: Domain id

        Returns:
            - Response object
        
        Raises:
            - Response object: If an error occurs.
        """
        user = request.user.db_user
        data = request.data

        # the user must be ad administrator or a cross-coordinator of the admin application
        if not am_i_cross_coordinator(request, user):
            return Response({"error": "You are not authorized to perform this action"}, status=status.HTTP_403_FORBIDDEN)

        #if data is a string, convert it to a float, else if it a dict the the 'allowed' key is a string
        allowed = None
        if isinstance(data, str):
            allowed = data.lower() in ['true', '1', 't', 'y', 'yes']
        elif isinstance(data, dict) and 'allowed' in data:
            allowed = data['allowed'].lower() in ['true', '1', 't', 'y', 'yes']

        if allowed is None:
            return Response({"error": "Invalid request body"}, status=status.HTTP_400_BAD_REQUEST)


        db_domain = Domain.objects.get(id=domain_id)
        db_widget_instance = WidgetInstance.objects.get(id=widget_instance_id)

        if allowed:

            # if the domain is in the db_widget_instance.disallowed_domains, remove it
            if db_widget_instance.disallowed_domains.filter(id=domain_id).exists():
                db_widget_instance.disallowed_domains.remove(db_domain)

        else:
            if not db_widget_instance.disallowed_domains.filter(id=domain_id).exists():
                db_widget_instance.disallowed_domains.add(db_domain)

        return Response({"allowed": allowed})
    

class TranslationView(viewsets.GenericViewSet):
    """
    Description:
            Translation view
    
    Functions:
        translate: This function is used to return translation json
        
    """

    @action(
        detail=False,
        methods=["get"],
        url_path="(?P<portal>.+)/(?P<app>.+)/(?P<language>.+)",
    )
    def translate(self, request, portal, app, language):
        """
        Description:
                Return translation json

        Args:
            - request: Request object
            - portal: Portal name
            - app: Application name
            - language: Language name
        
        Returns:
            - Response object
        
        Raises:
            - Exception: If an error occurs.
        """
        try:
            # creates header with user credentials
            headers = {
                "Authorization": f"Bearer {GIT_TOKEN}",
                "User-Agent": f"{GIT_USER}",
                "Accept": "application/vnd.github.raw",
            }

            # creates request url
            url = f"{GIT_TRANSLATION_URL}{portal.lower()}/{app.lower()}/{language.lower()}/{language.lower()}.json"

            # exec request
            result = requests.get(url, headers=headers, timeout=5)

            # return content if request success
            if result.status_code == 200:
                ret = json.loads(result.content)
            else:
                ret = {}
        except Exception as ex:
            _logger.error(ex)
        return Response(ret)


class UserAppSettingsView(viewsets.ViewSet):
    """
    Description:
        user app settings resource
    
    Attributes:
        permission_classes: List of permission classes
    
    Functions:
        list: This function is used to get the user app settings.
    """
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=False, methods=['get', 'put'], url_path="(?P<app_id>[^/.]+)")
    def get_settings(self, request, app_id):
        user:UserData = request.user.db_user
        #get the key from the request
        key = request.GET.get('key', 'default')

        if request.method == 'PUT':
            #get the settings from the request
            settings = request.data
            #save the settings
            obj, _ = UserAppSettings.objects.get_or_create(user=user, app_id=app_id, key=key)
            obj.data = settings
            obj.save()
            return Response(settings)
        
        qs = UserAppSettings.objects.filter(user=user, app_id=app_id, key=key)
        if qs.exists():
            return Response(qs[0].data)
        else:
            return Response({})
        