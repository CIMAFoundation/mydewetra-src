__doc__ = """
Description:
    This file contains the serializers for the admin app.

Classes:
    - ApplicationSerializer: This class is a serializer for the application.
    - ApplicationCategorySerializer: This class is a serializer for the application category.
    - DomainSerializer: This class is a serializer for the domain.

Functions:
    - get_enabled: This function gets the enabled status.
    - get_roles: This function gets the roles.
    - get_icon_url: This function gets the icon URL.
    - get_request_db_user_data: This function gets the request database user data.
"""

import urllib
import urllib.parse

from rest_framework import serializers

from acroweb3_portal.admin_app import get_request_db_user_data
from acroweb3_portal.models import Application, ApplicationCategory, Domain


class ApplicationSerializer(serializers.ModelSerializer):
    enabled = serializers.SerializerMethodField()
    roles = serializers.SerializerMethodField()
    icon_url = serializers.SerializerMethodField()

    class Meta:
        model = Application
        fields = ('id', 'category', 'text', 'title',
                  'icon', 'icon_url', 'icon_svg', 'link', 'props', 'enabled', 'roles')

    def get_enabled(self, obj):
        request = self.context['request']
        db_user = get_request_db_user_data(request)
        # check if db_user has role for this application
        return obj.always_visible or db_user.roles.filter(application_id=obj.id).exists()

    def get_roles(self, obj):
        request = self.context['request']
        db_user = get_request_db_user_data(request)
        # get all role names for this application
        return db_user.roles.filter(application_id=obj.id).values_list('name', flat=True).distinct()

    def get_icon_url(self, obj):
        """
        Returns the icon as a URL-encoded SVG data URL
        """
        if not obj.icon_svg:
            return None

        svg_encoded = urllib.parse.quote(obj.icon_svg)
        return f'data:image/svg+xml;utf8,{svg_encoded}'


class ApplicationCategorySerializer(serializers.ModelSerializer):
    content = ApplicationSerializer(many=True, read_only=True)

    class Meta:
        model = ApplicationCategory
        fields = '__all__'


class DomainSerializer(serializers.ModelSerializer):
    class Meta:
        model = Domain
        fields = '__all__'
