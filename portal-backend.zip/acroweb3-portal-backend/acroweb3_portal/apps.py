from django.apps import AppConfig


class Acroweb3Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'acroweb3_portal'
