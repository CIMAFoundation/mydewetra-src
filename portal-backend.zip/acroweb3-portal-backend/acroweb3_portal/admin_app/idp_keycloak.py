__doc__ = """

Description:
    This module implements the IDPClient interface for Keycloak.
    The KeycloakIDPClient class is a concrete implementation of the IDPClient interface.
    It uses the keycloak python client to interact with the Keycloak server.

    Attributes:
        - keycloak_cache: A dictionary that stores the KeycloakIDPClient instances for each issuer.
        - _logger: A logger object for logging messages.

    Functions:
        - _keycloack_exception_handler: A decorator that catches KeycloakError exceptions and raises AcrowebException exceptions.

    Classes:
        - KeycloakIDPClient: A concrete implementation of the IDPClient interface for Keycloak.
        """
from datetime import datetime
import json
from typing import List
from acroweb3_portal.admin_app.idp_client import AdminUserData, IDPClient
from acroweb3_api.auth import AcrowebAuthData
from keycloak import KeycloakAdmin
from keycloak.exceptions import KeycloakError
from acroweb3 import AcrowebException
from acroweb3_api import get_logger
from acroweb3_portal import settings

_logger = get_logger(__name__)

keycloak_cache = {}


def _keycloack_exception_handler(func):
    """
    Description:
        Try-except decorator that catches KeycloakError exceptions and raises AcrowebException exceptions.
        Also logs the caught exception.

    Args:
        - func: The function to be decorated.
    
    Returns:
        - The decorated function.
    
    Raises:
        - AcrowebException: If a KeycloakError exception is caught.
    """
    def try_except_wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except KeycloakError as e:
            _logger.error(f'KeycloackError: {e.response_code} -> {e.error_message}', exc_info=e)
            msg = e.error_message
            try:
                d = json.loads(e.error_message)
                for key in d:
                    if 'error' in key.lower():
                        msg = d[key]
                        break
            except:
                pass
            raise AcrowebException(msg)
    return try_except_wrapper

class KeycloakIDPClient(IDPClient):
    """
    Description:
        A concrete implementation of the IDPClient interface for Keycloak.
        It uses the keycloak python client to interact with the Keycloak server.

    Attributes:
        - keycloak_admin: A KeycloakAdmin object that is used to interact with the Keycloak server.
        - cache: A dictionary that stores the KeycloakIDPClient instance's cache.

    Functions:
        - __init__: Initializes the KeycloakIDPClient object.
        - user_exists: Checks if a user exists.
        - create_user: Creates a user.  
        - delete_user: Deletes a user.  
        - reset_user_password: Resets a user's password.    
    """
    @_keycloack_exception_handler
    def __init__(self, auth_data: AcrowebAuthData) -> None:
        """
        Description:
            Initializes the KeycloakIDPClient object.
            The method initializes the KeycloakAdmin object and the cache dictionary.
            So that the KeycloakIDPClient object can interact with the Keycloak server.
            
        Args:
            - auth_data: An AcrowebAuthData object that contains the authentication data.
        
        Returns:
            - None
        
        Raises:
            - AcrowebException: If a KeycloakError exception is caught.
        """
        super().__init__(auth_data)
        auth_url = self.issuer[:self.issuer.find('/auth/')] + '/auth/'
        realm = self.issuer.split('/')[-2] if self.issuer.endswith('/') else self.issuer.split('/')[-1] 
        username_env_variable=f'IDP_ADMIN_USER_{auth_data.portal}'
        password_env_variable=f'IDP_ADMIN_PWD_{auth_data.portal}'
        username = settings.env(username_env_variable, default=settings.env('IDP_ADMIN_USER_ALL'))
        password = settings.env(password_env_variable, default=settings.env('IDP_ADMIN_PWD_ALL'))
        self.keycloak_admin = KeycloakAdmin(server_url=auth_url,        
            username=username,
            password=password,
            realm_name=realm,
            verify=True)

        if self.issuer not in keycloak_cache:
            keycloak_cache[self.issuer] = {}
        self.cache = keycloak_cache[self.issuer]
        
    
    @_keycloack_exception_handler
    def __get_keycloack_user_id(self, username, remove_from_cache=False):
        """
        Description:
            Gets the Keycloak user id for a given username.
            If the user id is not in the cache, it is fetched from the Keycloak server.
            Else, it is fetched from the cache.

        Args:
            - username: The username.
            - remove_from_cache: A boolean that indicates if the user id should be removed from the cache.
        
        Returns:
            - The Keycloak user id.
        
        Raises:
            - AcrowebException: If a KeycloakError exception is caught.
        """
        cache_key = f'USERID_{username}'
        if cache_key not in self.cache:
            o = self.keycloak_admin.get_user_id(username)
            _logger.debug(f'getting keycloak id for username {username}')
            self.cache[cache_key] = o
        ret = self.cache[cache_key]
        if remove_from_cache:
            del self.cache[cache_key]
        return ret


    @_keycloack_exception_handler
    def user_exists(self, username: str):
        """
        Description:
            Checks if a user exists.
            The method checks if a user exists in the Keycloak server.

        Args:
            - username: The username.

        Returns:
            - A boolean that indicates if the user exists.

        Raises:
            - AcrowebException: If a KeycloakError exception is caught.
        """

        return self.keycloak_admin.get_user_id(username) is not None

    @_keycloack_exception_handler
    def create_user(self, username: str, email: str, firstName: str, lastName: str, domain: str):
        """
        Description:
            Creates a user.
            The method creates a user in the Keycloak server.
        
        Args:
            - username: The username.
            - email: The email.
            - firstName: The first name.
            - lastName: The last name.
            - domain: The domain name.
            
        Returns:
            - None
        
        Raises:
            - AcrowebException: If a KeycloakError exception is caught.
        """
        client_id = self.keycloak_admin.get_client_id('portal')
        keycloak_role = self.keycloak_admin.get_client_role(client_id, role_name=domain)
        user_id = self.keycloak_admin.create_user(exist_ok=False, payload={
            'username': username,
            'firstName': firstName,
            'lastName': lastName,
            'email': email,
            'requiredActions': ['UPDATE_PASSWORD', 'VERIFY_EMAIL'],
            'enabled': True
        })
        self.keycloak_admin.assign_client_role(user_id=user_id, client_id=client_id, roles=keycloak_role)
        self.keycloak_admin.send_verify_email(user_id=user_id)

    @_keycloack_exception_handler
    def delete_user(self, username: str):
        """
        Description:
            Deletes a user.
            The method deletes a user from the Keycloak server.
        
        Args:
            - username: The username.
            
        Returns:
            - None
        
        Raises:
            - AcrowebException: If a KeycloakError exception is caught.
        """
        user_id_keycloak = self.__get_keycloack_user_id(username, remove_from_cache=True)
        self.keycloak_admin.delete_user(user_id_keycloak)        

    @_keycloack_exception_handler
    def reset_user_password(self, username: str, new_password: str = None):
        """
        Description:
            Resets a user's password.
            The method resets a user's password in the Keycloak server.
            If a new password is provided, the user's password is updated.
        
        Args:
            - username: The username.
            - new_password: The new password.
        
        Returns:
            - None
        
        Raises:
            - AcrowebException: If a KeycloakError exception is caught.
        """
        user_id_keycloak = self.__get_keycloack_user_id(username)
        self.keycloak_admin.set_user_password(user_id=user_id_keycloak, password=new_password)
        self.keycloak_admin.send_update_account(user_id=user_id_keycloak, payload=['UPDATE_PASSWORD'])
        