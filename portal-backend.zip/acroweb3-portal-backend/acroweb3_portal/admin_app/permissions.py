__doc__ = """
Description:
    This file contains the permissions for the admin app.

Functions:
    - am_i_administrator: This function checks if the user is an administrator.
    - am_i_coordinator: This function checks if the user is a coordinator.
    - IsCoordinatorPermission: This class is a permission class for the coordinator.
    - IsAdministratorPermission: This class is a permission class for the administrator.
"""

from rest_framework import permissions
from acroweb3_portal.auth import get_auth_component
from acroweb3_portal.models import UserData
from acroweb3_portal.admin_app import get_request_db_user_data

def am_i_administrator(request, db_user=None):
    """
    Description:
        This function checks if the user is an administrator.
    
    Args:
        - request: Request object
    
    Returns:
        - bool
    
    Raises:
        - Exception: Error getting user data: {e}
    """
    if db_user is None:
        db_user = get_request_db_user_data(request)
    return db_user.roles.filter(application_id='admin', name='administrator').exists()

def am_i_cross_coordinator(request, db_user=None):
    """
    Description:
        This function checks if the user is a cross-coordinator.
    
    Args:
        - request: Request object
    
    Returns:
        - bool
    
    Raises:
        - Exception: Error getting user data: {e}
    
    """
    if db_user is None:
        db_user = get_request_db_user_data(request)
    return db_user.roles.filter(application_id='admin', name__in=['administrator','cross-coordinator']).exists()

def am_i_coordinator(request, db_user=None):
    """
    Description:
        This function checks if the user is a coordinator.
    
    Args:
        - request: Request object
    
    Returns:
        - bool
    
    Raises:
        - Exception: Error getting user data: {e}
    
    """
    if db_user is None:
        db_user = get_request_db_user_data(request)
    #user is a coordinato if he's administrotor, cross-coordinator, or coordinator and the current domain is his primary domain
    roles = ['administrator', 'cross-coordinator']
    if db_user.domain.name == request.user.domain:
        roles.append('coordinator')    
    return db_user.roles.filter(application_id='admin', name__in=roles).exists()        


class IsCoordinatorPermission(permissions.IsAuthenticated):
    def has_permission(self, request, view):
        """ 
        Description:
            This function checks if the user is a coordinator.
            
        Args:
            - request: Request object
            - view: View object
        
        Returns:
            - bool
        
        Raises:
            - None
        """
        return am_i_coordinator(request)

class IsAdministratorPermission(permissions.IsAuthenticated):
    def has_permission(self, request, view):
        """
        Description:
            This function checks if the user is an administrator.
            
        Args:
            - request: Request object
            - view: View object
        
        Returns:
            - bool
        
        Raises:
            - None
        
        """
        return am_i_administrator(request)        