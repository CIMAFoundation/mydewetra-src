__doc__ = """
Description:
    This file contains the serializers for the admin app.

Classes:
    - DomainSerializerForList: This class is a serializer for the domain list.
    - ApplicationSerializerForWriter: This class is a serializer for the application writer.
    - ApplicationSerializerForList: This class is a serializer for the application list.
    - DomainSerializerForRetrieve: This class is a serializer for the domain retrieve.
    - DomainSerializerForWriter: This class is a serializer for the domain writer.
    - DomainGroupSerializer: This class is a serializer for the domain group.
    - CommunityDomainSerializer: This class is a serializer for the community domain.
    - CommunityDomainGroupSerializer: This class is a serializer for the community domain group.

Examples:
    >>> from acroweb3_portal.admin_app.serializers import DomainSerializerForList
    >>> from acroweb3_portal.models import Domain
    >>> domain = Domain.objects.get(id=1)
    >>> serializer = DomainSerializerForList(domain)
    >>> serializer.data
    
    """

from rest_framework import serializers
from acroweb3_portal.admin_app import get_domain_img_url, get_group_img_url
from acroweb3_portal.models import Application, Domain, DomainGroup
from acroweb3_api.auth import AcrowebAuthData
from acroweb3_api import get_logger
import urllib

_logger = get_logger(__name__)


def _get_domain_color(obj:Domain) -> str:
    if obj.props and 'color' in obj.props:
        return obj.props['color']
    return '#264654'


class DomainSerializerForList(serializers.ModelSerializer):
    imgUrl = serializers.SerializerMethodField()
    color = serializers.SerializerMethodField()
    class Meta:
        model = Domain
        fields = ['id', 'name', 'descr', 'imgUrl', 'color']

    def get_imgUrl(self, obj):
        return get_domain_img_url(obj)

    def get_color(self, obj):
        return _get_domain_color(obj)
    

class ApplicationSerializerForWriter(serializers.ModelSerializer):
    #define the fields name and descr that can be written
    class Meta:
        model = Application
        fields = ['id', 'category', 'text', 'title', 'icon', 'icon_svg', 'link', 'props']

    #override the create method to manually set the link value
    def create(self, validated_data):
        #check if the application already exists
        if Application.objects.filter(id=validated_data['id']).exists():
            raise serializers.ValidationError('Application already exists')
        _logger.debug(f'Creating application {validated_data["id"]}')
        validated_data['link'] = f'/{validated_data["id"]}'
        # validated_data['text'] = validated_data.pop('name')
        # validated_data['title'] = validated_data.pop('descr')
        return super().create(validated_data)

    #override the update method to manually set the link value
    def update(self, instance, validated_data):        
        # validated_data['link'] = f'/{validated_data["id"]}'
        # validated_data['text'] = validated_data.pop('name')
        # validated_data['title'] = validated_data.pop('descr')
        _logger.debug(f'Updating application {validated_data["id"]}')
        return super().update(instance, validated_data)
    
    #override delete method to delete all roles for this application
    def delete(self, instance):
        _logger.debug(f'Deleting application {instance.id}')
        instance.roles.all().delete()
        return super().delete(instance)


class ApplicationSerializerForList(serializers.ModelSerializer):
    icon_url = serializers.SerializerMethodField()
    category = serializers.SerializerMethodField()

    class Meta:
        model = Application
        fields = ['id', 'text', 'title', 'category', 'icon', 'icon_url', 'icon_svg', 'props', 'link']

    def get_category(self, obj):
        return obj.category.category if obj.category else None

    def get_icon_url(self, obj):
        """
        Returns the icon as a URL-encoded SVG data URL
        """
        if not obj.icon_svg:
            return None

        svg_encoded = urllib.parse.quote(obj.icon_svg)
        return f'data:image/svg+xml;utf8,{svg_encoded}'



class DomainSerializerForRetrieve(serializers.ModelSerializer):
    apps = ApplicationSerializerForList(many=True, read_only=True)
    imgUrl = serializers.SerializerMethodField()
    color = serializers.SerializerMethodField()
    class Meta:
        model = Domain
        fields = ['id', 'name', 'descr', 'lon1', 'lon2', 'lat1', 'lat2', 'date', 'props', 'imgUrl', 'color', 'apps']

    def get_imgUrl(self, obj):
        return get_domain_img_url(obj)

    def get_color(self, obj):
        return _get_domain_color(obj)


class DomainSerializerForWriter(serializers.ModelSerializer):
    class Meta:
        model = Domain
        fields = ['id', 'name', 'descr', 'lon1', 'lon2', 'lat1', 'lat2', 'props']

    def create(self, validated_data):
        auth_data:AcrowebAuthData = self.context['request'].user
        validated_data['portal_id'] = auth_data.portal
        return super().create(validated_data)


class DomainGroupSerializer(serializers.ModelSerializer):
    imgUrl = serializers.SerializerMethodField()

    class Meta:
        model = DomainGroup
        fields = ['id', 'name', 'descr', 'color', 'date', 'imgUrl']

    def get_imgUrl(self, obj):
        return get_group_img_url(obj)

    def create(self, validated_data):
        auth_data:AcrowebAuthData = self.context['request'].user
        validated_data['portal_id'] = auth_data.portal
        return super().create(validated_data)
    

class CommunityDomainSerializer(DomainSerializerForList):
    groups = DomainGroupSerializer(many=True, read_only=True)

    class Meta(DomainSerializerForList.Meta):
        fields = DomainSerializerForList.Meta.fields + ['groups']


class CommunityDomainGroupSerializer(DomainGroupSerializer):
    domains = DomainSerializerForList(many=True, read_only=True)

    class Meta(DomainGroupSerializer.Meta):
        fields = DomainGroupSerializer.Meta.fields + ['domains']