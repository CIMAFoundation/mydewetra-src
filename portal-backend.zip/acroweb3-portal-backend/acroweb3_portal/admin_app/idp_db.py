__doc__ = """

Description: 
    IDP client for the Acroweb3 portal backend that uses the database as the identity provider.

Classes:
    DBIDPClient: IDP client for the Acroweb3 portal backend that uses the database as the identity provider.

Attributes:
    _logger (Logger): Logger for the module.

Functions:
    None


"""
from acroweb3_portal.admin_app.idp_client import IDPClient
from acroweb3_api.auth import AcrowebAuthData
from acroweb3_api import get_logger

_logger = get_logger(__name__)

class DBIDPClient(IDPClient):
    """
    Description: 
            IDP client for the Acroweb3 portal backend that uses the database as the identity provider.

    Methods:
        __init__(self, auth_data: AcrowebAuthData): Constructor for the DBIDPClient class.
        user_exists(self, username: str) -> bool: Checks if a user exists.
        create_user(self, username: str, email: str, firstName: str, lastName: str, domain: str): Creates a user.
        delete_user(self, username: str): Deletes a user.
        reset_user_password(self, username: str, new_password: str = None): Resets a user's password.

"""
    def __init__(self, auth_data: AcrowebAuthData) -> None:
        """
        Description:
            Constructor for the DBIDPClient class.
        
        Args:
            auth_data (AcrowebAuthData): The authentication data.
        
        Returns:
            None
        """
        super().__init__(auth_data)


    def user_exists(self, username: str) -> bool:
        """
        Description:
            Nothing to do. The user exists.. :).
        
        Args:
            username (str): The username.
        
        Returns:
            bool: True if the user exists, False otherwise.
        
        Raises:
            None
        """
        return True

    def create_user(self, username: str, email: str, firstName: str, lastName: str, domain: str):
        """
        Description:
            Nothing to do.
        
        Args:
            username (str): The username.
            email (str): The email.
            firstName (str): The first name.
            lastName (str): The last name.
            domain (str): The domain.
        
        Returns:
            None
        Raises:
            None
        """
        pass

    def delete_user(self, username: str):
        """
        Description:
            Nothing to do.

        Args:
            username (str): The username.

        Returns:
            None

        Raises:
            None
        """
        pass


    def reset_user_password(self, username: str, new_password: str = None):
        """
        Description:
            Nothing to do.
        """
        #OK
        #nothing to do
        pass
        