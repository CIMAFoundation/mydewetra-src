
from acroweb3_portal.models import Domain, DomainGroup, UserData


def get_domain_img_url(obj:Domain) -> str:
    if obj.img is not None:
        return f'/image/domain/?domain={obj.id}'
    return None

def get_group_img_url(obj:DomainGroup) -> str:
    if obj.img is not None:
        return f'/image/group/?group={obj.id}'
    return None

def get_user_img_url(obj:UserData) -> str:
    if obj.img is not None:
        return f'/image/user/?username={obj.username}'
    return None


def get_request_db_user_data(request):
    if request.user.db_user:
        return request.user.db_user
    return UserData.objects.get(username__iexact=request.user.user, domain__portal_id=request.user.portal)