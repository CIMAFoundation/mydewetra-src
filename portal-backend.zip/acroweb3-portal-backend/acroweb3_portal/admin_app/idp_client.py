__doc__ = '''

Description: 
        This module provides the interface for the IDP client.
        The IDP client is the interface to the Identity Provider (IDP) that manages the users.
        The IDP client is responsible for the following tasks:
            - get the list of users
            - get the user data
            - update the user data
            - create a new user
            - delete a user
            - reset the user password
            - create a domain
            - delete a domain
            
Classes:

    AdminUserData
    IDPClient

Functions:
    getIDPClient(auth_data:AcrowebAuthData) -> IDPClient
        return the IDP client for the given auth data

Attributes:
    idp_clients: dict
        '''


import abc
from datetime import datetime
from typing import List
from acroweb3_api.auth import AcrowebAuthData
from acroweb3_api import get_logger
from acroweb3_portal.admin_app import get_user_img_url
from acroweb3_portal.models import PortalConfig, UserData
from django.utils.module_loading import import_string
from acroweb3_portal.settings import IDP_CLIENT_COMPONENT

_logger = get_logger(__name__)

class AdminUserData():
    """
    Description:
        This class represents the user data for the admin interface.
        The user data is used to display the user information in the admin interface.
        The user data is also used to update the user information in the IDP.

    Attributes:
        username: str
        firstName: str
        lastName: str
        email: str
        creationDate: datetime
        phone: str
        db_user : UserData

    Methods:
        to_dict() -> dict
            return the user data as a dictionary
        set_from_db(user:UserData)
            set the user data from the database user data
        create_db_user() -> UserData
            create a new database user data
        update_db_user(user:UserData)
            update the database user data
        set_from_props(props:dict)
            set the user data from the properties
        
    """

    def __init__(self, username:str=None, firstName:str=None, lastName:str=None, email:str=None, creationDate:datetime=None, phone: str=None, db_user:UserData=None):
        if db_user is not None:
            self.set_from_db(db_user)
        else:
            self.username = username
            self.firstName = firstName
            self.lastName = lastName
            self.email = email
            self.emailEnabled = False
            self.date = creationDate
            self.phoneNr = phone
            self.phoneEnabled = False
            self.imgUrl = None
            self.domain = None
            self.color = '#264654'

    def to_dict(self):
        return vars(self)
    
    def set_from_db(self, user:UserData):
        self.username = user.username
        self.firstName = user.first_name
        self.lastName = user.last_name
        self.email = user.email
        self.emailEnabled = user.email_enabled
        self.date = user.creation_date                
        self.phoneNr = user.phone_nr
        self.phoneEnabled = user.phone_enabled
        self.imgUrl = get_user_img_url(user)
        self.domain = user.domain.name
        self.color = user.color

    def create_db_user(self):
        user = UserData()
        user.username = self.username
        self.update_db_user(user)
        return user
        
    def update_db_user(self, user:UserData):
        user.first_name = self.firstName
        user.last_name = self.lastName
        user.email = self.email
        user.email_enabled = self.emailEnabled
        user.phone_nr = self.phoneNr
        user.phone_enabled = self.phoneEnabled
        user.color = self.color        


    def set_from_props(self, props:dict):
        if props is not None:
            for attr in props:
                try:
                    if hasattr(self, attr):
                        setattr(self, attr, props[attr])
                except Exception as e:
                    _logger.error('cannot set user attribute from DB data', exc_info=e)

class IDPClient(metaclass=abc.ABCMeta):
    """
    Description:
        This class is the interface for the IDP client.
        The IDP client is the interface to the Identity Provider (IDP) that manages the users.
        The IDP client is responsible for the following tasks:
            - create a new user
            - delete a user
            - reset the user password
    
    Attributes:
        auth_data: AcrowebAuthData
        cfg: PortalConfig
        issuer: str
    
    Methods:
        user_exists(username: str)
            check if user exists
        create_user(username: str, email:str, firstName: str, lastName: str, domain: str)
            create a new user
        delete_user(username: str)
            delete an user
        reset_user_password(username: str, new_password:str=None)
            rest user password
    """

    def __init__(self, auth_data:AcrowebAuthData) -> None:
        self.auth_data:AcrowebAuthData = auth_data
        self.cfg = PortalConfig.objects.get(pk=auth_data.portal)
        self.issuer = self.cfg.auth['issuer'] if 'issuer' in self.cfg.auth else None


    @abc.abstractmethod
    def user_exists(self, username: str):
        '''
        check if user exists
        '''
        

    @abc.abstractmethod
    def create_user(self, username: str, email:str, firstName: str, lastName: str, domain: str):
        '''
        create a new user
        '''


    @abc.abstractmethod
    def delete_user(self, username: str):
        '''
        delete an user
        '''

    @abc.abstractmethod
    def reset_user_password(self, username: str, new_password:str=None):
        '''
        reset user password
        '''
    
idp_clients = {}

def getIDPClient(auth_data:AcrowebAuthData) -> IDPClient:
    """
    Description:
        return the IDP client for the given auth data
    
    Arguments:
        auth_data: AcrowebAuthData
            the authentication data
    
    Returns:
        IDPClient
            the IDP client
    
    Raises:
        None
    """
    component_class = import_string(IDP_CLIENT_COMPONENT)
    component = component_class(auth_data)
    return component
    # cache_key = component.issuer
    # if cache_key not in idp_clients:
    #     idp_clients[cache_key] = component
    #     _logger.debug(f'create IDP client from {component.issuer}')
    # return idp_clients[cache_key]
