__doc__ = """
Description:
    This file contains the viewset for the community data.
    The community data viewset is used to get the community data from the IDP.
    The community data includes the users, domains and groups.
    
Classes:
    - CommunityDataView: This class is a viewset for the community data.

"""

from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from acroweb3_portal.admin_app.idp_client import AdminUserData
from acroweb3_portal.admin_app.serializers import CommunityDomainGroupSerializer, CommunityDomainSerializer
from acroweb3_portal.models import Domain, DomainGroup, UserData

class CommunityDataView(viewsets.ViewSet):
    """
    Description:
            This class is a viewset for the community data.
            The community data viewset is used to get the community data from the IDP.
            The community data includes the users, domains and groups.
    
    Functions:
            - list: This function is used to get the list of users from the IDP.
            - domains: This function is used to get the list of domains from the IDP.
            - groups: This function is used to get the list of groups from the IDP.
            - user_domains: This function is used to get the list of domains of a user from the IDP.
    """
    def list(self, request):
        """
        Description:
            This function is used to get the list of users from the IDP.

        Args:
            - request: Request object

        Returns:
            - Response object
        
        Raises:
            - Response object: If portal is not found in the request param.
        """
        if 'portal' not in request.GET:
            return Response(f'cannot find portal in request param', status=status.HTTP_400_BAD_REQUEST)
        portal = request.GET['portal']    
        users = UserData.objects.filter(domain__portal_id=portal)
        return Response([AdminUserData(db_user=u).to_dict() for u in users])


    @action(detail=False, methods=['get'])
    def domains(self, request):
        """
        Description:
            This function is used to get the list of domains from the IDP.
        
        Args:
            - request: Request object

        Returns:
            - Response object
        
        Raises:
            - Response object: If portal is not found in the request param.
        """
        if 'portal' not in request.GET:
            return Response(f'cannot find portal in request param', status=status.HTTP_400_BAD_REQUEST)
        portal = request.GET['portal']    
        domains = Domain.objects.filter(portal_id=portal)
        return Response([CommunityDomainSerializer(d).data for d in domains]) 


    @action(detail=False, methods=['get'])
    def groups(self, request):

        """
        Description:
            This function is used to get the list of groups from the IDP.

        Args:
            - request: Request object
        
        Returns:
            - Response object
        
        Raises:
            - Response object: If portal is not found in the request param. 
        """

        if 'portal' not in request.GET:
            return Response(f'cannot find portal in request param', status=status.HTTP_400_BAD_REQUEST)
        portal = request.GET['portal']    
        groups = DomainGroup.objects.filter(portal_id=portal)
        return Response([CommunityDomainGroupSerializer(g).data for g in groups]) 

    #action for get user domains
    @action(detail=False, methods=['get'])
    def user_domains(self, request):
        """
        Description:
            This function is used to get the list of domains of a user from the IDP.
        
        Args:
            - request: Request object
        
        Returns:    
            - Response object
        
        Raises: 
            - Response object: If portal or user is not found in the request param.
        """
        if 'portal' not in request.GET:
            return Response(f'cannot find portal in request param', status=status.HTTP_400_BAD_REQUEST)
        portal = request.GET['portal']    
        if 'user' not in request.GET:
            return Response(f'cannot find user in request param', status=status.HTTP_400_BAD_REQUEST)
        user = request.GET['user']    
        
        db_user = UserData.objects.filter(username__iexact=user, domain__portal_id=portal).first()
        if not db_user:
            return Response(f'cannot find user {user} in portal {portal}', status=status.HTTP_404_NOT_FOUND)
        
        data = {
            'primary': CommunityDomainSerializer(db_user.domain).data,
            'extra': [CommunityDomainSerializer(d).data for d in db_user.extra_domains.all()]
        }

        return Response(data)