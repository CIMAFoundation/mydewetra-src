__doc__= """
Description:
    This file contains the viewset for the admin app.
    The admin app viewset is used to manage the users, roles, domains and applications.

Classes:
    - AdminConfigView: This class is a viewset for the admin config.
    - AdminUsersView: This class is a viewset for the admin users.
    - AdminUploadView: This class is a viewset for the admin upload.
    - AdminRolesView: This class is a viewset for the admin roles.
    - AdminDomainsView: This class is a viewset for the admin domains.
    - AdminApplicationsUpdateView: This class is a viewset for the admin applications update.
    - AdminApplicationsView: This class is a viewset for the admin applications.
    - AdminDomainGroupView: This class is a viewset for the admin domain group.
    
Functions:
    - get_request_db_user_data: This function gets the user data from the request.
    - get_domain_img_url: This function gets the domain image url.
    - get_group_img_url: This function gets the group image url.
    - get_user_img_url: This function gets the user image url.

"""
    
from asyncio.log import logger
from acroweb3_portal.admin_app import get_domain_img_url, get_group_img_url, get_user_img_url
from acroweb3_portal.admin_app.idp_client import IDPClient, getIDPClient, AdminUserData
from rest_framework import viewsets, status, permissions, mixins
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.parsers import MultiPartParser
from acroweb3_api.auth import AcrowebAuthData
from acroweb3_portal.admin_app.permissions import IsAdministratorPermission, IsCoordinatorPermission, am_i_administrator, am_i_coordinator
from acroweb3_portal.admin_app.serializers import ApplicationSerializerForList, DomainGroupSerializer, DomainSerializerForList, \
    DomainSerializerForRetrieve, DomainSerializerForWriter, ApplicationSerializerForWriter
from acroweb3_portal.admin_app import get_request_db_user_data
from acroweb3_portal.models import Application, Domain, DomainGroup, PortalConfig, UserData, ApplicationRole
from acroweb3 import AcrowebException
from acroweb3_api import get_logger
from django.db.models import Q
from django.db import transaction

from acroweb3_portal.settings import MAX_IMAGE_SIZE

_logger = get_logger(__name__)

def _am_i_admin_or_coordinator_of_the_same_domain(request, db_user: UserData):
    if not am_i_coordinator(request):
        return False
    if not am_i_administrator(request):
        if db_user.domain.name != request.user.domain:
            return False
    return True

class AdminConfigView(viewsets.ViewSet):
    '''
    Description:
        This class is a viewset for the admin config.
    
    Functions:
        - list: This function returns the configuration.

    Attributes:
        - permission_classes: List of permissions

    '''
    permission_classes = [permissions.IsAuthenticated]

    def list(self, request):
        cfg = {
            'coordinator': am_i_coordinator(request),
            'administrator': am_i_administrator(request)
        }
        return Response(cfg)


class AdminUsersView(viewsets.ViewSet):
    '''

    Description:
        This class is a viewset for the admin users.
    
    Functions:
        - list: This function returns the list of users.
        - me: This function returns the user data.
        - user: This function returns the user data.
        - save: This function saves the user data.
        - delete: This function deletes the user data.
        
    Attributes:
        - permission_classes: List of permissions
    
    '''
    permission_classes = [permissions.IsAuthenticated]

    def list(self, request):
        """
        Description:
            This function returns the list of users.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        auth_data = request.user
        if 'role' in request.GET and 'app' in request.GET:

            #role must be at least coordinator
            if not am_i_coordinator(request):
                return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)
            
            #get the application role from the db
            app_role = ApplicationRole.objects.get(application_id=request.GET['app'], name=request.GET['role'])
            #get users from app_role that have the domain equals to auth_data.domain  or in extra_domains
            users = app_role.users.filter(Q(domain_id=auth_data.domain_data['id']) | Q(extra_domains__id=auth_data.domain_data['id'])).distinct('username')
        else:
            if not am_i_administrator(request):
                users = UserData.objects.filter(Q(domain__name=auth_data.domain) | Q(extra_domains__name=auth_data.domain)).distinct('username')
            else:
                users = UserData.objects.filter(domain__portal_id=auth_data.portal)
        return Response([AdminUserData(db_user=u).to_dict() for u in users])
    

    @action(detail=False, methods=['get'])
    def me(self, request):
        """
        Description:
            This function returns the user data.
        
        Args:
            - request: Request object
            
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        db_user = get_request_db_user_data(request)

        return Response(AdminUserData(db_user=db_user).to_dict())
    

    @action(detail=False, methods=['get'])
    def user(self, request):
        """
        Description:
            This function returns the user data.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        auth_data = request.user
        if 'username' not in request.GET:
            return Response(f'cannot find username in request param', status=status.HTTP_400_BAD_REQUEST)
        username = request.GET['username']
        user = UserData.objects.get(username__iexact=username, domain__portal_id=auth_data.portal)
        return Response(AdminUserData(db_user=user).to_dict())


    @action(detail=False, methods=['post', 'put'])
    def save(self, request):
        """
        Description:
            This function saves the user data.
            If the request method is post, it creates a new user.
            If the request method is put, it updates the user data.
            
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        auth_data:AcrowebAuthData = request.user
        user_data = request.data
        if not all([f in user_data for f in ['username', 'firstName', 'email']]):
            return Response(f'cannot find enough data in request body', status=status.HTTP_400_BAD_REQUEST)
        
        # username = user_data['username']
        # email = user_data['email']
        # firstName = user_data['firstName']
        # lastName = user_data['lastName'] if 'lastName' in user_data else None
        admin_user = AdminUserData()
        admin_user.set_from_props(user_data)

        client = getIDPClient(auth_data)
        
        if request.method.lower() == 'post':
            domain_id = request.GET['domain'] if 'domain' in request.GET else auth_data.domain_data['id']
            
            #role must be at least coordinator
            if not am_i_coordinator(request):
                return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)
            #only administrator can create users in other domains    
            if not am_i_administrator(request) and str(domain_id) != str(auth_data.domain_data['id']):
                return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

            domain = Domain.objects.get(pk=request.GET['domain'])

            #create userdata in db
            with transaction.atomic():
                #create user in idp
                if not client.user_exists(admin_user.username):
                    client.create_user(admin_user.username, admin_user.email, admin_user.firstName, admin_user.lastName, domain.name)

                db_user = admin_user.create_db_user()
                db_user.domain = domain
                db_user.save()
                db_user.roles.add(ApplicationRole.objects.get(application_id='admin', name='user'))
                db_user.save()

        if request.method.lower() == 'put':

            #i can update only myself
            if admin_user.username.lower() != str(auth_data.user).lower():
                return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

            #update userdata in db
            with transaction.atomic():
                db_user = UserData.objects.get(username__iexact=admin_user.username, domain_id=auth_data.domain_data['id'])
                admin_user.update_db_user(db_user)
                db_user.save()

        return Response('')
    
            
    @action(detail=False, methods=['delete'])
    def delete(self, request):
        """
        Description:
            This function deletes the user data.

        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        auth_data = request.user
        if 'username' not in request.GET:
            return Response(f'cannot find username in request param', status=status.HTTP_400_BAD_REQUEST)
        username = request.GET['username']
        client = getIDPClient(auth_data)

        db_user = UserData.objects.get(username__iexact=username, domain__portal_id=auth_data.portal)

        #i must be administrator or coordinator of the same domain
        if not am_i_coordinator(request, db_user):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

        with transaction.atomic():
            client.delete_user(username)
            db_user.delete()

        return Response('')


    @action(detail=False, methods=['put'])
    def resetpassword(self, request):
        """
        Description:
            This function resets the user password.
            
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        auth_data = request.user
        if 'username' not in request.GET:
            return Response(f'cannot find username in request param', status=status.HTTP_400_BAD_REQUEST)
        username = request.GET['username']

        client = getIDPClient(auth_data)

        db_user = UserData.objects.get(username__iexact=username, domain__portal_id=auth_data.portal)

        #i must be administrator or coordinator of the same domain
        if username != request.user.user and not am_i_coordinator(request, db_user):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

        new_password = request.data['password'] if request.data and 'password' in request.data else None
        client.reset_user_password(username, new_password)
        return Response('')


    @action(detail=False, methods=['patch'])
    def props(self, request):
        """
        Description:
              This function updates the user properties.
                If the request method is patch, it updates the user properties.
                So the user can update his phoneNr, phoneEnabled, emailEnabled and color.
                Else it returns a response with the user properties.    
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        portal_id = request.user.portal
        props = request.data
        if 'username' not in request.GET:
            return Response(f'cannot find username in request param', status=status.HTTP_400_BAD_REQUEST)
        username = request.GET['username']

        #i can update only myself
        if str(username).lower() != str(request.user.user).lower():
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

        users = UserData.objects.filter(username__iexact=username, domain__portal_id=portal_id)
        if not users.exists():
            return Response(f'cannot find user {username}', status=status.HTTP_404_NOT_FOUND)
        if len(users)!=1:
            raise AcrowebException(f'CRITICAL ERROR: found multiple {username}')
        user = users[0]
        
        if 'phoneNr' in props:
            user.phone_nr = props.pop('phoneNr')
        if 'phoneEnabled' in props:
            user.phone_enabled = props.pop('phoneEnabled')
        if 'emailEnabled' in props:
            user.email_enabled = props.pop('emailEnabled')
        if 'color' in props:
            user.color = props.pop('color')
        
        if user.props is None: 
            user.props={}            
        
        user.props.update(props)    
        user.save()
        return Response(user.props)

    @action(detail=False, methods=['delete'])
    def avatar(self, request):
        """
        Description:
            This function deletes the user avatar.
            If the request method is delete, it deletes the user avatar.
            Else it returns a response with the user avatar.
            
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        auth_data:AcrowebAuthData = request.user
        users = UserData.objects.filter(username__iexact=auth_data.user, portal_id=auth_data.portal)
        if not users.exists():
            return Response(f'cannot find user {auth_data.user}', status=status.HTTP_404_NOT_FOUND)
        if len(users)!=1:
            return Response(f'CRITICAL ERROR: found multiple {auth_data.user}', status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        user = users[0]
        user.img = None
        user.save()
        return Response('')

    @action(detail=False, methods=['get'])
    def roles(self, request):
        """
        Description:
            This function returns the user roles.
            If the request method is get, it returns the user roles.
            Else it returns a response with the user roles.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        if 'username' not in request.GET or 'app' not in request.GET:
            return Response(f'cannot find username and app in request param', status=status.HTTP_400_BAD_REQUEST)
        username = request.GET['username']
        app = request.GET['app']
        auth_data = request.user

        #only coordinator can see roles of other users
        if not am_i_coordinator(request) and str(auth_data.user).lower() != str(username).lower():
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

        user = UserData.objects.get(username__iexact=username, domain__portal_id=auth_data.portal)
        app_roles = ApplicationRole.objects.filter(application_id=app)
        user_roles = user.roles.filter(application_id=app).values_list('name', flat=True)

        ret_value = [{'id':r.name, 'descr':r.descr, 'selected':r.name in user_roles} for r in app_roles]
        return Response(ret_value)
    
    @action(detail=False, methods=['put', 'delete'])
    def role(self, request):
        """
        Description:
            This function updates the user roles.
            If the request method is put, it adds the user roles.
            If the request method is delete, it deletes the user roles.
            Else it returns a response with the user roles.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        auth_data = request.user

        if 'username' not in request.GET or 'app' not in request.GET or 'role' not in request.GET :
            return Response(f'cannot find username and app and role in request param', status=status.HTTP_400_BAD_REQUEST)
        username = request.GET['username']
        app = request.GET['app']
        role = request.GET['role']

        #for admin only administrator can manage admin role
        if app=='admin' and role=='administrator' and not am_i_administrator(request):
            return Response(f'only administrators can manage administrator role', status=status.HTTP_403_FORBIDDEN)

        db_user = UserData.objects.get(username__iexact=username, domain__portal_id=auth_data.portal)
        db_role = ApplicationRole.objects.get(application_id=app, name=role)
        

        #i must be administrator or coordinator of the same domain
        if not am_i_coordinator(request):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

        if request.method.lower() == 'put':            
            db_user.roles.add(db_role)
            db_user.save()

        if request.method.lower() == 'delete':
            db_user.roles.remove(db_role)
            db_user.save()

        return Response('')
    
    @action(detail=False, methods=['get', 'put', 'delete'])
    def domains(self, request):
        """ 
        Description:
            This function returns the user domains.
            If the request method is get, it returns the user domains.
            If the request method is put, it adds the user domains.
            If the request method is delete, it deletes the user domains.
            Else it returns a response with the user domains.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        auth_data = request.user
        if 'username' not in request.GET:
            return Response(f'cannot find username in request param', status=status.HTTP_400_BAD_REQUEST)
        username = request.GET['username']

        db_user = UserData.objects.get(username__iexact=username, domain__portal_id=auth_data.portal)

        if request.method.lower() == 'get':
            domains = db_user.extra_domains.all()
            ret_value = [DomainSerializerForList(db_user.domain).data] + [DomainSerializerForList(d).data for d in domains]
            return Response(ret_value)
        
        #i must be administrator or coordinator of the same domain
        if not am_i_coordinator(request):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

        if 'domain' not in request.GET:
            return Response(f'cannot find domain in request param', status=status.HTTP_400_BAD_REQUEST)
        domain = request.GET['domain']
        db_domain = Domain.objects.get(id=domain)

        if request.method.lower() == 'put':
            db_user.extra_domains.add(db_domain)
            db_user.save()

        if request.method.lower() == 'delete':
            db_user.extra_domains.remove(db_domain)
            db_user.save()

        return Response('')



class AdminUploadView(viewsets.ViewSet):
    """
    Description:
        This class is a viewset for the admin upload.
    
    Functions:
        - user: This function uploads the user image.
        - domain: This function uploads the domain image.
        - group: This function uploads the group image.
        - __set_img: This function sets the image.

    Attributes:
        - permission_classes: List of permissions
        - parser_classes: List of parsers
    """
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = (MultiPartParser, )

    def __set_img(self, request, obj):
        """
        Description:
            This function sets the image.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        if 'file' not in request.FILES:
            return Response(f'cannot find image in request', status=status.HTTP_400_BAD_REQUEST)
        image = request.FILES['file']
        image_bytes = image.read()

        from PIL import Image
        import io
        im = Image.open(io.BytesIO(image_bytes))

        if im.mode == 'RGBA':
            im = im.convert('RGB')

        _logger.debug(f'original size: {im.size}. {len(image_bytes)} bytes')

        max_size = max(im.size)
        if max_size > MAX_IMAGE_SIZE:
            perc_reduction = MAX_IMAGE_SIZE / max_size
            new_size = [int(i*perc_reduction) for i in im.size]
            im = im.resize(new_size)
            _logger.debug(f'resized to: {im.size}')

        with io.BytesIO() as output:
            im.save(output, format="JPEG", optimize=True, quality=50)
            image_bytes = output.getvalue()

        obj.img = image_bytes
        obj.save()

        _logger.debug(f'saved size: {im.size}. {len(image_bytes)} bytes')

        return Response('')

    @action(detail=False, methods=['post'])
    def user(self, request, *args, **kwargs):
        """
        Description:
            This function uploads the user image.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        auth_data:AcrowebAuthData = request.user
        db_user = get_request_db_user_data(request)
        r:Response = self.__set_img(request, db_user)
        r.data = get_user_img_url(db_user)
        return r

    @action(detail=False, methods=['post'])
    def domain(self, request, *args, **kwargs):
        """
        Description:
            This function uploads the domain image.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        if 'domain' not in request.GET:
            return Response(f'cannot find domain in parameters', status=status.HTTP_400_BAD_REQUEST)
        domain_id = request.GET['domain']
        domain = Domain.objects.get(id=domain_id)
        r:Response = self.__set_img(request, domain)
        r.data =  get_domain_img_url(domain)
        return r

    @action(detail=False, methods=['post'])
    def group(self, request, *args, **kwargs):
        """
        Description:
            This function uploads the group image.
            If the request method is post, it uploads the group image.
            Else it returns a response with the group image.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        if 'group' not in request.GET:
            return Response(f'cannot find group in parameters', status=status.HTTP_400_BAD_REQUEST)
        group_id = request.GET['group']
        group = DomainGroup.objects.get(id=group_id)
        r:Response = self.__set_img(request, group)
        r.data = get_group_img_url(group)
        return r


class AdminRolesView(viewsets.ViewSet):
    """
    Description:
        This class is a viewset for the admin roles.
        
    Functions:
        - list: This function returns the list of roles.
        - create: This function creates a new role.
        - destroy: This function deletes a role.
    
    Attributes:
        - permission_classes: List of permissions
        """
    permission_classes = [permissions.IsAuthenticated]

    def list(self, request):
        """
        Description:
            This function returns the list of roles.
            If the request method is get, it returns the list of roles.
            Else it returns a response with the list of roles.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        #role must be at least coordinator
        if not am_i_coordinator(request):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

        if 'app' in request.GET:            
            app = request.GET['app']
            roles = ApplicationRole.objects.filter(application_id=app)
            ret_value = [{'id': r.name, 'descr': r.descr} for r in roles]
            return Response(ret_value)
        
        return Response(f'invalid request params', status=status.HTTP_400_BAD_REQUEST)
    
    def create(self, request):
        """
        Description:
            This function creates a new role.
            If the request method is post, it creates a new role.
            Else it returns a response with the list of roles.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        #role must be administrator        
        if not am_i_administrator(request):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

        if 'app' not in request.GET:
            return Response(f'invalid request params', status=status.HTTP_400_BAD_REQUEST)

        app = request.GET['app']

        #get name and descr from request body
        if 'id' not in request.data or 'descr' not in request.data:
            return Response(f'invalid request params', status=status.HTTP_400_BAD_REQUEST)
        name = request.data['id']
        descr = request.data['descr']

        #check if role already exists
        if ApplicationRole.objects.filter(application_id=app, name=name).exists():
            return Response(f'role already exists', status=status.HTTP_400_BAD_REQUEST)

        role = ApplicationRole(application_id=app, name=name, descr=descr)
        role.save()

        roles = ApplicationRole.objects.filter(application_id=app)

        return Response([{'id': r.name, 'descr': r.descr} for r in roles])
    
    def destroy(self, request, pk=None):
        """
        Description:
            This function deletes a role.
            If the request method is delete, it deletes a role.
        
        Args:
            - request: Request object
            - pk: Primary key
            
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        #role must be administrator        
        if not am_i_administrator(request):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)

        if 'app' not in request.GET:
            return Response(f'invalid request params', status=status.HTTP_400_BAD_REQUEST)

        app = request.GET['app']

        #check if role exists
        if not ApplicationRole.objects.filter(application_id=app, name=pk).exists():
            return Response(f'role does not exists', status=status.HTTP_400_BAD_REQUEST)

        role = ApplicationRole.objects.get(application_id=app, name=pk)
        role.delete()

        roles = ApplicationRole.objects.filter(application_id=app)

        return Response([{'id': r.name, 'descr': r.descr} for r in roles])



class AdminDomainsView(viewsets.ModelViewSet):
    """
    Description:
        This class is a viewset for the admin domains.
    
    Functions:
        - get_queryset: This function returns the queryset.
        - destroy: This function deletes a domain.
        - get_serializer_class: This function returns the serializer class.
    
    Attributes:
        - permission_classes: List of permissions
    
    """
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """
        Description:
            This function returns the queryset.
            If the request user is an administrator, it returns the queryset of all domains.
            Else it returns the queryset of the domain.
        
        Args:
            - self: Self object

        Returns:
            - QuerySet: QuerySet object
        
        Raises:
            - None
        """

        auth_data:AcrowebAuthData = self.request.user
        if am_i_administrator(self.request):
            return Domain.objects.filter(portal_id=auth_data.portal)
        return Domain.objects.filter(name__in=auth_data.allowed_domains)
    
    def destroy(self, request, *args, **kwargs):
        """
        Description:
            This function deletes a domain.
            If the request method is delete, it deletes a domain.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
            
        Raises:
            - None
        """
        if not am_i_administrator(request):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)
        auth_data:AcrowebAuthData = self.request.user
        instance = self.get_object()        
        db_domain = Domain.objects.get(id=auth_data.domain_data['id'])
        domain_users = db_domain.users.all()
        if len(domain_users)>1:
            return Response(f'Cannot delete non empty domains. All users except the coordinator must be removed.', status=status.HTTP_403_FORBIDDEN)
    
        return super().destroy(request, *args, **kwargs)

    def get_serializer_class(self):
        """
        Description:
            This function returns the serializer class.
        
        Args:
            - self: Self object
        
        Returns:
            - Serializer: Serializer object
        
        Raises:
            - None
        """
        if self.action == 'list':
            return DomainSerializerForList
        if self.action == 'retrieve':
            return DomainSerializerForRetrieve
        return DomainSerializerForWriter


    @action(detail=False, methods=['delete'], url_path='image/(?P<domain_id>[^/.]+)')
    def image(self, request, domain_id):
        """
        Description:
            Clears the image associated with a domain.

        Args:
            request (HttpRequest): The HTTP request object.
            domain_id (int): The ID of the domain.

        Returns:
            Response: An empty response.
        """
        domain = Domain.objects.get(id=domain_id)
        domain.img = None
        domain.save()
        return Response('')
    

    @action(detail=False, methods=['put', 'delete'], url_path='app/(?P<domain_id>[^/.]+)')    
    def app(self, request, domain_id):
        """
        Description:
            Adds or removes an app from a domain.
            If the request method is put, it adds the app to the domain.
            If the request method is delete, it removes the app from the domain.
        
        Args:
            - request: Request object
            - domain_id: Domain ID
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        if not am_i_administrator(request):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)
        if 'app' not in request.GET:
            return Response(f'cannot find app in request param', status=status.HTTP_400_BAD_REQUEST)
        app = request.GET['app']
        domain = Domain.objects.get(pk=domain_id)
        if request.method.lower() == 'put':
            domain.apps.add(app)
        if request.method.lower() == 'delete':
            domain.apps.remove(app)            
        return Response('')


    @action(detail=False, methods=['put', 'delete'])    
    def coordinator(self, request):
        """
        Description:
            Adds or removes a coordinator from a domain.
            If the request method is put, it adds the coordinator to the domain.
            If the request method is delete, it removes the coordinator from the domain.
        
        Args:
            - request: Request object
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        if not am_i_administrator(request):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)
        if 'username' not in request.GET:
            return Response(f'cannot find username in request param', status=status.HTTP_400_BAD_REQUEST)
        username = request.GET['username']
        # auth_data = request.user
        db_user = UserData.objects.get(username__iexact=username, domain__portal_id=request.user.portal)
        db_role = ApplicationRole.objects.get(application_id='admin', name='coordinator')

        if request.method.lower() == 'put':
            db_user.roles.add(db_role)

        if request.method.lower() == 'delete':
            db_user.roles.remove(db_role)

        return Response('')
    

    @action(detail=False, methods=['get'], url_path='users/(?P<domain_id>[^/.]+)')
    def users(self, request, domain_id):
        """
        Description:
            This function returns the users of a domain.
            
        Args:
            - request: Request object
            - domain_id: Domain ID
            
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        if not am_i_coordinator(request):
            return Response(f'operation not permitted', status=status.HTTP_403_FORBIDDEN)
        coordinators = UserData.objects.filter(domain_id=domain_id, roles__application_id='admin', roles__name='coordinator')
        users = UserData.objects.filter(domain_id=domain_id)
        return Response({
            'users': [AdminUserData(db_user=u).to_dict() for u in users],
            'coordinators': [AdminUserData(db_user=u).to_dict() for u in coordinators]
        })        
    


class AdminApplicationsUpdateView(mixins.CreateModelMixin, mixins.DestroyModelMixin, mixins.UpdateModelMixin, viewsets.GenericViewSet):
    """
    Description:
        This class is a viewset for the admin applications update.

    Functions:
        - get_queryset: This function returns the queryset.
        - get_serializer_class: This function returns the serializer class.
    
    Attributes:
        - permission_classes: List of permissions
    """

    permission_classes = [IsAdministratorPermission]
    queryset = Application.objects.all()
    serializer_class = ApplicationSerializerForWriter


class AdminApplicationsView(mixins.ListModelMixin, viewsets.GenericViewSet):  
    """
    Description:
        This class is a viewset for the admin applications.
    
    Functions:
        - get_queryset: This function returns the queryset.
        - get_serializer_class: This function returns the serializer class.
    
    Attributes:
        - permission_classes: List of permissions
    
    """
    permission_classes = [IsCoordinatorPermission]
    queryset = Application.objects.all()
    serializer_class = ApplicationSerializerForList


class AdminDomainGroupView(viewsets.ModelViewSet): 
    """
    Description:
        This class is a viewset for the admin domain group.
    
    Functions:
        - get_queryset: This function returns the queryset.
        - domains: This function returns the domains.
        - image: This function deletes the image.
        - domain: This function adds or removes a domain.
    
    Attributes:
        - permission_classes: List of permissions
        - serializer_class: Serializer class
    """        
    permission_classes = [IsAdministratorPermission]
    serializer_class = DomainGroupSerializer

    def get_queryset(self):
        """
        Description:
            This function returns the queryset.
            If the request user is an administrator, it returns the queryset of all domain groups.
            Else it returns the queryset of the domain group.
        
        Args:
            - self: Self object
        
        Returns:
            - QuerySet: QuerySet object
        
        Raises:
            - None
        """
        auth_data:AcrowebAuthData = self.request.user
        return PortalConfig.objects.get(id=auth_data.portal).groups.all()

    @action(detail=False, methods=['get'], url_path='domains/(?P<group_id>[^/.]+)')
    def domains(self, request, group_id):
        """
        Description:
            This function returns the domains of a domain group.
        
        Args:
            - request: Request object
            - group_id: Group ID
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        
        """
        group = DomainGroup.objects.get(pk=group_id)
        return Response([DomainSerializerForList(d).data for d in group.domains.all()])

    @action(detail=False, methods=['delete'], url_path='image/(?P<group_id>[^/.]+)')
    def image(self, request, group_id):
        """
        Description:
            This function deletes the image associated with a domain group.
        
        Args:
            - request: Request object
            - group_id: Group ID
        
        Returns:
            - Response: Response object
            
        Raises:
            - None
        """
        group = DomainGroup.objects.get(pk=group_id)
        group.img = None
        group.save()
        return Response('')


    @action(detail=False, methods=['put', 'delete'], url_path='domain/(?P<group_id>[^/.]+)')    
    def domain(self, request, group_id):
        """
        Description:
            This function adds or removes a domain from a domain group.
            If the request method is put, it adds the domain to the domain group.
            If the request method is delete, it removes the domain from the domain group.
        
        Args:
            - request: Request object
            - group_id: Group ID
        
        Returns:
            - Response: Response object
        
        Raises:
            - None
        """
        if 'domain' not in request.GET:
            return Response(f'cannot find domain in request param', status=status.HTTP_400_BAD_REQUEST)
        domain = request.GET['domain']
        group = DomainGroup.objects.get(pk=group_id)
        if request.method.lower() == 'put':
            group.domains.add(domain)
        if request.method.lower() == 'delete':
            group.domains.remove(domain)
        return Response('')