__doc__ = """
Description:
    This file contains the authentication component for the portal.

Classes:
    - AuthenticationComponent: This class is an abstract class for the authentication component.
    - AuthDomainSerializer: This class is a serializer for the domain.
    - PortalAuthentication: This class is an authentication component for the portal.
    - PortalAuthenticationReverseProxy: This class is an authentication component for the portal with reverse proxy.

Attributes:
    - _logger: Logger object

"""
from asyncio.log import logger
from typing import Tuple

from jwt import PyJWKClient
import jwt
import abc
from acroweb3_portal.models import Domain, PortalConfig, UserData, ApplicationRole
from acroweb3 import AcrowebException
from acroweb3_api.auth import AcrowebOAuth2Authentication, AcrowebAuthData
from acroweb3_api import get_logger, AcrowebUserNotFoundException
from rest_framework import serializers
from rest_framework.settings import api_settings
import os
from datetime import datetime
from django.db.models import Prefetch


_logger = get_logger(__name__)

class AuthDomainSerializer(serializers.ModelSerializer):
    class Meta:
        model = Domain
        fields = '__all__'


class AuthenticationComponent(metaclass=abc.ABCMeta):
    """
    Description:
        This class is an abstract class for the authentication component.
            
    Functions:
        - _build_auth_data: This function builds the authentication data.
        - validate_token: This function validates the token.
        - validate_token_and_build_auth_data: This function validates the token and builds the authentication data.
            
    
    """
    def _build_auth_data(self, portal, username, app_id, chosen_domain):
        """
        Description:
            This function builds the authentication data.
            If the chosen domain is not allowed, it uses the default domain.
            Else, it uses the chosen domain.
        
        Args:
            - portal: Portal
            - username: Username
            - app_id: Application ID
            - chosen_domain: Chosen domain
                
        Returns:
            - auth_data: AcrowebAuthData object
            
        Raises:
            - AcrowebUserNotFoundException: cannot find user "{username}" for portal "{portal}"
        """

        _logger.debug(f'portal: {portal}, username: {username}, app_id: {app_id}, chosen_domain: {chosen_domain}')

        
        try:
            # Prefetch roles that match either condition (app_id or 'admin')
            roles_prefetch = Prefetch(
                'roles',
                queryset=ApplicationRole.objects.filter(application__id__in=[app_id, 'admin']),
                to_attr='prefetched_roles'
            )
            # Get the user with related domain.portal and prefetched roles
            db_user = UserData.objects.select_related('domain__portal')\
                .prefetch_related(roles_prefetch)\
                .get(username__iexact=str(username), domain__portal_id=portal)
            # Get the roles for the application and admin
            roles = [role.name for role in db_user.prefetched_roles if role.application.id == app_id]
            admin_roles = [role.name for role in db_user.prefetched_roles if role.application.id == 'admin']
        except UserData.DoesNotExist:
            # _logger.warning(f'cannot find user "{username}" for portal "{portal}"')
            raise AcrowebUserNotFoundException(f'cannot find user "{username}" for portal "{portal}"')

        
        domains_dict = {d.name: d for d in db_user.extra_domains.all()}
        domains_dict[db_user.domain.name] = db_user.domain
        allowed_domains = [d for d in domains_dict.keys()]        
        if chosen_domain is None or chosen_domain not in allowed_domains:
            _logger.warning(f'domain {chosen_domain} not allowed for user {username}. Using default domain: {db_user.domain.name}')
            chosen_domain = db_user.domain.name
        
        auth_data = AcrowebAuthData(username, portal, chosen_domain, roles)

        auth_data.allowed_domains = allowed_domains
        auth_data.user_first_name = db_user.first_name
        auth_data.user_last_name = db_user.last_name
        auth_data.domain_data = AuthDomainSerializer(domains_dict[chosen_domain]).data
        if 'cross-coordinator' in admin_roles or 'admin' in admin_roles:
            auth_data.coordinated_domains = allowed_domains
        elif 'coordinator' in admin_roles:
            auth_data.coordinated_domains = [db_user.domain.name]
        

        # save db_user in auth_data
        auth_data.db_user = db_user     

        return auth_data
           
            
    @abc.abstractmethod
    def validate_token(access_token, issuer, client_id=None):
        """
        Description:
            This function validates the token.
            
        Args:
            - access_token: Access token
            - issuer: Issuer
            - client_id: Client ID
        
        Returns:
            - token_info: Token information
        """
        pass

    @abc.abstractmethod
    def validate_token_and_build_auth_data(self, access_token, host, client_id, chosen_domain=None) -> AcrowebAuthData:
        """
        Description:
            This function validates the token and builds the authentication data.
        
        Args:
            - access_token: Access token
            - host: Host
            - client_id: Client ID
            - chosen_domain: Chosen domain
            
        Returns:
            - auth_data: AcrowebAuthData object
        
        Raises:
            - AcrowebException: cannot find config for host {host}
            - AcrowebException: found more tha one configuration ({len(configurations)}) for host {host}

        """
        pass


def get_auth_component() -> AuthenticationComponent:
    """
    Description:
        This function gets the authentication component.
    
    Returns:
        - auth_component: AuthenticationComponent object

    Raises:
        - AcrowebException: Authentication component not defined
    """

    if len(api_settings.DEFAULT_AUTHENTICATION_CLASSES)==0:
        raise AcrowebException('Authentication component not defined')
    auth_component_class = api_settings.DEFAULT_AUTHENTICATION_CLASSES[0]
    auth_component = auth_component_class()
    return auth_component


def get_portal_config_by_host(host) -> PortalConfig:
    """
    Description:
        This function is used to retrive the portal configuration for a particular host.

    Args:
        - host: str
    
    Returns:
        - configurations[0]: PortalConfig object
    """
    configurations = PortalConfig.objects.filter(hosts__contains = host)
    if not configurations.exists():
        raise AcrowebException(f'cannot find config for host {host}') 
    if len(configurations)>1:
        raise AcrowebException(f'found more tha one configuration ({len(configurations)}) for host {host}') 
    return configurations[0]

def get_portal_and_issuer_by_host(host) -> Tuple[str, str]:
    """
    Description:
        This function gets the portal and issuer by host.
    
    Args:
        - host: str
    
    Returns:
        - cfg.id: str
        - issuer: str
    """
    cfg = get_portal_config_by_host(host)
    issuer = cfg.auth["issuer"] if 'issuer' in cfg.auth else None
    return cfg.id, issuer



class PortalAuthentication(AcrowebOAuth2Authentication, AuthenticationComponent):
    """
    Description:
        This class is an authentication component for the portal.
    
    Functions:
        - validate_token: This function validates the token.
        - validate_token_and_build_auth_data: This function validates the token and builds the authentication data.
    """
    def validate_token(self, access_token, issuer, client_id=None):
        """
        Description:
            This function validates the token.
            
        Args:
            - access_token: Access token
            - issuer: Issuer
            - client_id: Client ID
        
        Returns:
            - token_info: Token information
        
        Raises:
            - AcrowebException: {str(e)}
        """
        url = f'{issuer}/protocol/openid-connect/certs'
        jwks_client = PyJWKClient(url)
        signing_key = jwks_client.get_signing_key_from_jwt(access_token)
        audience = ['account', client_id] if client_id is not None else ['account']
        token_info = jwt.decode(access_token, 
            audience=audience,
            key=signing_key.key, 
            algorithms=["RS256"])
        return token_info

    def validate_token_and_build_auth_data(self, access_token, host, client_id, chosen_domain=None) -> AcrowebAuthData:
        """
        Description:
            This function validates the token and builds the authentication data.
        
        Args:
            - access_token: Access token
            - host: Host
            - client_id: Client ID
            - chosen_domain: Chosen domain
        
        Returns:
            - auth_data: AcrowebAuthData object

        Raises:
            - AcrowebException: {str(iae)}
            - AcrowebException: {str(e)}
        """
        portal, issuer = get_portal_and_issuer_by_host(host)
        try:
            token_info = self.validate_token(access_token, issuer, 'portal')
        except jwt.exceptions.InvalidAudienceError as iae:
            token_info = jwt.decode(access_token, options={"verify_signature": False})
            # _logger.debug(f'{str(iae)}: {client_id} not in {token_info["aud"]}')
            raise AcrowebException(str(iae))
        except Exception as e:
            # _logger.error(f'error deconding access token', exc_info=e)
            raise AcrowebException(str(e))

        #get user id from token information
        username  = token_info['preferred_username']

        app_id = client_id[:-4] if client_id.endswith('_api') else client_id

        auth_data = self._build_auth_data(portal, username, app_id, chosen_domain)

        return auth_data

        



class PortalAuthenticationReverseProxy(AcrowebOAuth2Authentication, AuthenticationComponent):
    """
    Description:
        This class is an authentication component for the portal with reverse proxy.
        
    Functions:
        - validate_token: This function validates the token.
        - validate_token_and_build_auth_data: This function validates the token and builds the authentication data.
    """
    def validate_token(self, access_token, issuer, client_id=None):
        """
        Description:
            This function validates the token.
        
        Args:
            - access_token: Access token
            - issuer: Issuer
            - client_id: Client ID
        
        Returns:
            - token_info: Token information
        
        Raises:
            - AcrowebException: {str(e)}
        """
        return {'preferred_username': access_token}

    def validate_token_and_build_auth_data(self, access_token, host, client_id, chosen_domain=None) -> AcrowebAuthData:
        """
        Description:
            This function validates the token and build auth data.

        Args: 
            - access_token: Access token
            - host: Host
            - client_id: Client ID
            - chosen_domain: Chosen domain
        
        Returns:
            - auth_data:

        Raises:
            - AcrowebException: {str(iae)}
            - AcrowebException: {str(e)}
        """
        cfg = get_portal_config_by_host(host)
        auth_data = cfg.auth
        app_id = client_id[:-4] if client_id.endswith('_api') else client_id

        if 'type' in auth_data and auth_data['type'] == 'from-config':

            username, password = str(access_token).split(':')
            if not username or not password:
                raise AcrowebException('Invalid access token')
            
            # authentication from configuration
            if not auth_data or 'users' not in auth_data:
                raise AcrowebException('Invalid configuration')
            users = auth_data['users']
            if not isinstance(users, list) or not all(isinstance(u, dict) for u in users):
                raise AcrowebException('Invalid configuration')
            for u in users:
                if 'username' in u and 'password' in u and 'expire-date' in u:
                    # check if expire-date is in the future
                    if u['username'] == username:
                        expire_date : datetime = datetime.strptime(u['expire-date'], '%Y-%m-%d')
                        if expire_date < datetime.now():
                            raise AcrowebException(f'User {u["username"]} expired')
                        if u['password'] != password:
                            raise AcrowebException(f'Invalid password for user {username}')
                        db_username = u['db-username'] if 'db-username' in u else username
                        return self._build_auth_data(cfg.id, db_username, app_id, chosen_domain)

            raise AcrowebException(f'Invalid user: {username}')

        else:

            username = str(access_token)
            return self._build_auth_data(cfg.id, username, app_id, chosen_domain)

    
    #override the authenticate method to set the db_user int request.user if it is not present
    def authenticate(self, request):
        """
        Description:
            This function authenticates the user.
        
        Args:
            - request: Request object
        
        Returns:
            - user: User object
            - auth: Auth object
        """
        user, auth = super().authenticate(request)
        if os.environ.get('ACROWEB_LOCAL_AUTH_DATA_JSON_FILE', None) is not None:
            _logger.warning(f'AUTHENTICATE: rebuild user data for local authentication: {auth}')
            user = self.validate_token_and_build_auth_data(auth, 'localhost', 'admin', chosen_domain=user.domain)
        return user, auth

