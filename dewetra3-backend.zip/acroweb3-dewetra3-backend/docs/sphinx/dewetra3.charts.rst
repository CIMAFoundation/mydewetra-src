dewetra3.charts package
=======================

Submodules
----------

dewetra3.charts.views module
----------------------------

.. automodule:: dewetra3.charts.views
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dewetra3.charts
   :members:
   :undoc-members:
   :show-inheritance:
