# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html


import os
import sys
# import
import django
# Imposta la variabile di ambiente DJANGO_SETTINGS_MODULE sul tuo modulo settings di Django
os.environ['DJANGO_SETTINGS_MODULE'] = 'dewetra3.settings'

# Aggiungi la directory del tuo progetto Django al percorso di ricerca dei moduli di Python
sys.path.insert(0, os.path.abspath('../../'))
django.setup()


# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = 'Dewetra 3'
copyright = '2024, Dario Rubado'
author = 'Dario Rubado'
release = '0.3.14'

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = ['sphinx.ext.autodoc', 'sphinx.ext.todo', 'sphinx.ext.viewcode',
              'sphinx.ext.napoleon', 'sphinx_rtd_theme', 'rst2pdf.pdfbuilder']

templates_path = ['_templates']
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']


# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = 'sphinx_rtd_theme'
html_static_path = ['_static']

# from root path
# sphinx-apidoc -o docs/sphinx/ .
# make clean
# make html
# make latexpdf
# open _build/html/index.html
