.. Dewetra 3 documentation master file, created by
   sphinx-quickstart on Mon Jun 17 15:28:40 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Dewetra 3's documentation!
=====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   dewetra3
   manage
   version


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
