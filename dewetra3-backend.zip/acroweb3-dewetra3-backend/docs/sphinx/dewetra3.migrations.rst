dewetra3.migrations package
===========================

Submodules
----------

dewetra3.migrations.0001\_initial module
----------------------------------------

.. automodule:: dewetra3.migrations.0001_initial
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.migrations.0002\_layer\_enabled module
-----------------------------------------------

.. automodule:: dewetra3.migrations.0002_layer_enabled
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.migrations.0003\_auto\_20240213\_1503 module
-----------------------------------------------------

.. automodule:: dewetra3.migrations.0003_auto_20240213_1503
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.migrations.0004\_alter\_server\_user module
----------------------------------------------------

.. automodule:: dewetra3.migrations.0004_alter_server_user
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.migrations.0005\_alter\_server\_password module
--------------------------------------------------------

.. automodule:: dewetra3.migrations.0005_alter_server_password
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.migrations.0006\_auto\_20240227\_0944 module
-----------------------------------------------------

.. automodule:: dewetra3.migrations.0006_auto_20240227_0944
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.migrations.0007\_tool module
-------------------------------------

.. automodule:: dewetra3.migrations.0007_tool
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.migrations.0008\_tool\_icon module
-------------------------------------------

.. automodule:: dewetra3.migrations.0008_tool_icon
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dewetra3.migrations
   :members:
   :undoc-members:
   :show-inheritance:
