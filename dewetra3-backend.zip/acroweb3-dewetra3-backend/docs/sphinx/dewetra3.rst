dewetra3 package
================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   dewetra3.migrations
   dewetra3.dds
   dewetra3.sentinel
   dewetra3.tools
   dewetra3.charts
   dewetra3.test
   dewetra3.widget

Submodules
----------

dewetra3.admin module
---------------------

.. automodule:: dewetra3.admin
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.asgi module
--------------------

.. automodule:: dewetra3.asgi
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.models module
----------------------

.. automodule:: dewetra3.models
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.serializers module
---------------------------

.. automodule:: dewetra3.serializers
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.settings module
------------------------

.. automodule:: dewetra3.settings
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.urls module
--------------------

.. automodule:: dewetra3.urls
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.views module
---------------------

.. automodule:: dewetra3.views
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.wsgi module
--------------------

.. automodule:: dewetra3.wsgi
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dewetra3
   :members:
   :undoc-members:
   :show-inheritance:
