dewetra3.widget package
=======================

Submodules
----------

dewetra3.widget.service module
------------------------------

.. automodule:: dewetra3.widget.service
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.widget.tests module
----------------------------

.. automodule:: dewetra3.widget.tests
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.widget.views module
----------------------------

.. automodule:: dewetra3.widget.views
   :members:
   :undoc-members:
   :show-inheritance:

dewetra3.widget.widget module
-----------------------------

.. automodule:: dewetra3.widget.widget
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dewetra3.widget
   :members:
   :undoc-members:
   :show-inheritance:
