# gestione creazione movie asincrona

```mermaid
sequenceDiagram
    participant fe as dew3 frontend
    participant be as dew3 backend
    participant pbws as portal backend web socket

    fe->>be: create movie task runner
    create participant tr as movie task runner
    be->>+tr: create movie task runner
    tr->>tr: create task id
    tr->>tr: publish layer
    tr-->>be: task_id,layer_pubblication_result
    be-->>fe: task_id,layer_pubblication_result
    fe->>fe: show layer
    fe->>pbws: subscribe to path [task_id]
    fe->>be: start task [task_id]
    be->>be: get task runner by [task_id]
    be->>tr: start task
    tr-->>be: ok
    be-->>fe: ok

    loop for each layer
        tr->>tr: publish layer
        alt task finished
            tr-->>pbws: publish publication result
            pbws-->>fe: publication result
            fe->>fe: show layer
        end
    end

    tr->>pbws: publish task finished
    pbws-->>fe: task finished
    tr->>-tr: end
```

## movie task runner

Di fatto è un pubblcatore di layer che nel costruttore prende una lista di "LayerData" ordinati secondo l'"ordine della movie", pubblica il primo layer, e lo ritorna immediatamente. 

Al momento dell'avvio del task, pubblica gli altri layer in modo sincrono (nel senso che prima di pubblicare il successivo aspetta che il corrente abbia terminato), ed invia il risutato della pubblicazione al web socket.

La sua esecuzione avviene in un thread separato.