# Prima installazione

Creare un nuovo database  

Effettuare la migrazione

    python manage.py migrate

Creare super user per Admin  

    python manage.py createsuperuser

Installare i requirements
    pip install -r requirements.txt

#Primo avvio

Per utilizzare l applicazione in locale sono disponibili due modalità
    -stand alone
    -docker compose

Per lanciare l applicazione stand alone:
    
    python manage.py runserver

Per lanciare l applicazione con docker compose

    docker-compose /docker-compose/docker-compose.yml up



Ora si può procedere alla configurazione del DB.