# DEWETRA3-BACKEND

![Schema](images/architecture.png)

**Dewetra3-backend** contiene i dati e le configurazioni necessarie all applicazione Dewetra3 per la visualizzazione dei vari layer.

**Dewetra3-backend** è un'applicazione implementata sulla base del framework **ACROWEB3** (<https://github.com/CIMAFoundation/acroweb3-server-api-lib>) ed utilizza i servizi messi a disposizione dall'infrastruttura per tutte le operazioni di autentica, ottenimento dei permessi utente e notifiche verso il portale.

Nell'infrastruttura di **Kubernetes** l'applicativo è identificato con il nome di **dewetra3-backend** ed è configurato per l'esecuzione di un solo container per linea.

## Data Model 

![Schema](images/data-model.png)

## Api Documentation pdf

[Download](dewetra3-api-documentation.pdf)

## Code Description

[Download](dewetra3-code-description.pdf)