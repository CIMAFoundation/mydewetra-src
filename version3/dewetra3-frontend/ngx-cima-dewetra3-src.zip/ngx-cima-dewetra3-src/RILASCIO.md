## Rilasciare Nuova Versione Applicazione

### Nel repo dei sorgenti dell'applicativo
- Cambiare numero di versione nel package.json
- Effettuare una build di test per verificare che non ci siano errori
  `ng build @cima/TUAAPPLICAZIONE`
- Se si ha a disposizione script automatizzato - eseguirlo - diversamente...

### Nel repo della build dell'applicativo

- Cancellare completamente la vecchia build
- Inserire la build nuova
- Committare con messaggio uguale a numero di versione "vX.X.X" esempio v1.0.2
- Taggare il commint con il numero di versione "vX.X.X" esempio v1.0.2
- Effettuare il Push

### Nel repo del portale

- Aggiornare numero di versione della nostra applicazione nel package.json
- Se non lo si possiede installare "rimraf" con il comando
  `sudo npm i -g rimraf`
- Azzerare e reinstallare tutte le dipendenze con il comando
  `npm run restore`
- Lanciare il portale per verivicare che l'aggiornamento sia andato a buon fine
  `npm start`
- Fare il push sul branch "main" specificando nel messaggio del commit nome dell'applicazione e numero della versione (ex. "Kumale v1.0.2"). In questo modo si scatena la action su github per la pubblicazione di una nuova versione del portale aggiornata.

#### SE NUOVA APPLICAZIONE
- Creare Applicazione su Django
- Su KeyCloack creare un Client e un ruolo User per l'applicazione
- Su KeyCloack assegnare ruolo User ad un utente
- Nel repo del portale aggiornare il routing in app.routing.module
  `{
    path: 'reporter',
    loadChildren: () =>
    import('@cima/reporter').then((m) => m.CimaReporterModule),
    },`
- Nel repo del portale aggiungere all'angular.json gli assets della libreria
  `{
                "glob": "**/*",
                "input": "./node_modules/@cima/admin/assets",
                "output": "./assets/admin"
              },`
