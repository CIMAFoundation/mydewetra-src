import { NgModule } from '@angular/core';

import { CimaCommonsModule } from '@cima/commons';

import { SharedModule } from '../shared/shared.module';

import { CreditsRoutingModule } from './credits-routing.module';

import { CreditsPageComponent } from './credits-page/credits-page.component';
import { TorComponent } from './tor/tor.component';
import { PrivacyComponent } from './privacy/privacy.component';

@NgModule({
  declarations: [TorComponent, PrivacyComponent, CreditsPageComponent],
  imports: [SharedModule, CimaCommonsModule, CreditsRoutingModule],
})
export class CreditsModule {}
