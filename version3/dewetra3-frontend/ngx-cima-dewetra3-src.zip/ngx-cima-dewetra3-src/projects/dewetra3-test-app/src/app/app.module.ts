import {APP_INITIALIZER, LOCALE_ID, NgModule} from '@angular/core';
import {ServiceWorkerModule} from '@angular/service-worker';

import {
  APP_CONFIG,
  AuthGuard,
  AuthService,
  CimaCommonsModule,
  CimaConfigService,
  PortalService,
  SkinService,
  StorageService,
  authConfigFactory,
  getAuthConfig,
  storageFactory,
} from '@cima/commons';

import {environment} from '../environments/environment';

import {AppRoutingModule} from './app-routing.module';

import {CoreModule} from './core/core.module';
import {SharedModule} from './shared/shared.module';

import {HTTP_INTERCEPTORS, HttpClient, provideHttpClient, withInterceptorsFromDi} from '@angular/common/http';
import {OAuthModuleConfig, OAuthStorage} from 'angular-oauth2-oidc';
import {AppComponent} from './app.component';

import {registerLocaleData} from '@angular/common';
import localeItExtra from '@angular/common/locales/extra/it';
import localeIt from '@angular/common/locales/it';
import {TimepickerService} from '@cima/commons';
import {TranslateModule} from "@ngx-translate/core";
import {DynamicModule} from 'ng-dynamic-component';


registerLocaleData(localeIt, 'it-IT', localeItExtra);

@NgModule({
  declarations: [AppComponent],
  imports: [
    CoreModule.forRoot(environment),
    AppRoutingModule,
    SharedModule,
    CimaCommonsModule.forRoot(environment),
    DynamicModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      // Register the ServiceWorker as soon as the app is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000',
    }),
    TranslateModule.forRoot({
      defaultLanguage: 'en',
    })
  ],
  providers: [
    AuthGuard,
    SkinService,
    {
      provide: OAuthModuleConfig,
      useFactory: authConfigFactory,
      deps: [CimaConfigService],
    },
    {provide: OAuthStorage, useFactory: storageFactory},
    {
      provide: APP_INITIALIZER,
      useFactory: getAuthConfig,
      deps: [HttpClient, AuthService, CimaConfigService, SkinService],
      multi: true,
    },
    {
      provide: LOCALE_ID,
      deps: [PortalService],
      useFactory: (portalService: PortalService) => portalService.getLanguage(),
    },
    provideHttpClient(withInterceptorsFromDi()),

    TimepickerService,
    StorageService,
    {
      provide: APP_CONFIG,
      useValue: environment,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
}
