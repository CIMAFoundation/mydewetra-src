import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { Dewetra3LayerEvent, BaseLayerManager, Dewetra3MapClick } from '@cima/dewetra3-core';


@Component({
  selector: 'charts-modal',
  template: `
  @for(manager of modalData.managers; track manager.getLayerModel().id) {
    <mat-tab-group>
      <mat-tab  [label]="manager.getLayerModel().name">
        <dewetra3-punctual-chart-wrapper [manager]="manager" [clickData]="modalData.clickData" [dateFrom]="dateFrom" [dateTo]="dateTo"></dewetra3-punctual-chart-wrapper>
     </mat-tab>
  </mat-tab-group>
  }
  `,
  styleUrls: [],
})
export class ChartsModalComponent {

  public dateFrom = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
  public dateTo = new Date();

  constructor(
    public dialogRef: MatDialog,
    @Inject(MAT_DIALOG_DATA) public modalData: { managers: BaseLayerManager[]; clickData: Dewetra3MapClick }
  ) {

  }
}


@Component({
  selector: 'feature-charts-modal',
  template: `
    <mat-tab-group>
      <mat-tab  [label]="modalData.clickData.layer.getLayerModel().name">
        <dewetra3-series-chart-wrapper [clickData]="modalData.clickData" [dateFrom]="dateFrom" [dateTo]="dateTo"></dewetra3-series-chart-wrapper>
     </mat-tab>
  </mat-tab-group>

  `,
  styleUrls: [],
})
export class FeatureChartsModalComponent {

  public dateFrom = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
  public dateTo = new Date();

  constructor(
    public dialogRef: MatDialog,
    @Inject(MAT_DIALOG_DATA) public modalData: {  clickData: Dewetra3LayerEvent }
  ) {

  }
}

@Component({
  selector: 'legend-modal',
  template: `
    <mat-tab-group>
      <mat-tab  [label]="modalData.manager.getLayerModel().name">
        <dewetra3-legend-wrapper [manager]="modalData.manager"></dewetra3-legend-wrapper>
     </mat-tab>
  </mat-tab-group>

  `,
  styleUrls: [],
})
export class LegendModalComponent {



  constructor(
    public dialogRef: MatDialog,
    @Inject(MAT_DIALOG_DATA) public modalData: {  manager: BaseLayerManager }
  ) {

  }
}
