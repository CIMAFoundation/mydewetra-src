import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cima-tor',
  templateUrl: './tor.component.html',
  styleUrls: ['./tor.component.scss'],
})
export class TorComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
