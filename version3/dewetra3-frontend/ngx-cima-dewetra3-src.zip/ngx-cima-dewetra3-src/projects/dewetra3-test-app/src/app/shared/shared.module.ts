import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { CimaCommonsModule } from '@cima/commons';

const _MODULES = [
  CommonModule,
  ReactiveFormsModule,
  RouterModule,
  CimaCommonsModule,
];

@NgModule({
  declarations: [],
  imports: [_MODULES],
  exports: [_MODULES],
})
export class SharedModule {}
