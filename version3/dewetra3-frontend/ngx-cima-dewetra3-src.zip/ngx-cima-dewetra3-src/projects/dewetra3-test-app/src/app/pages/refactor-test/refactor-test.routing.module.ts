import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RefactorTestComponent } from './refactor-test.component';

const routes: Routes = [
    {
        path: '',
        component: RefactorTestComponent,
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class RefactorRoutingModule { }
