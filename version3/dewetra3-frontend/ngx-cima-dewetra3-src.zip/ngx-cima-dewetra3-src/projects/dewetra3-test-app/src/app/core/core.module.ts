import {
  ModuleWithProviders,
  NgModule,
  Optional,
  SkipSelf,
} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

const _CORE = [BrowserModule, BrowserAnimationsModule];

@NgModule({
  declarations: [],
  imports: [_CORE],
  exports: [_CORE],
})
export class CoreModule {
  static forRoot(environment: any): ModuleWithProviders<CoreModule> {
    return {
      ngModule: CoreModule,
      providers: [
        {
          provide: 'env',
          useValue: environment,
        },
      ],
    };
  }

  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error(
        'DemoCoreModule is already loaded. Import it in the AppModule only'
      );
    }
  }
}
