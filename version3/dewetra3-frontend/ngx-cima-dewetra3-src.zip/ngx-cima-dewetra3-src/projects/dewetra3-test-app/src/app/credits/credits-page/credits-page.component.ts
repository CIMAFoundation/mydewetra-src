import { Component, AfterViewInit } from '@angular/core';
import {CimaConfigService, FaviconService, PortalService} from '@cima/commons';

@Component({
  selector: 'cima-credits-page',
  templateUrl: './credits-page.component.html',
  styleUrls: ['./credits-page.component.scss'],
})
export class CreditsPageComponent implements AfterViewInit {
  constructor(
    private portalService: PortalService,
    private faviconService: FaviconService,
    private configService: CimaConfigService
  ) {}

  credits: any[]
  ngAfterViewInit(): void {
    this.portalService.setTitle(`Credits`);
    this.faviconService.setPortalFavicon();
    this.configService.getStaticCredits().subscribe((credits) => {
      this.credits = credits;
    }   );
  }
}
