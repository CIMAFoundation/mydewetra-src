import { Component } from '@angular/core';

import { Observable } from 'rxjs';

import { AuthService } from '@cima/commons';

@Component({
  selector: 'app-root',
  template: `
    <splash-screen></splash-screen>
    <router-outlet></router-outlet>
  `,
})
export class AppComponent {
  isUserAuthenticated$: Observable<boolean>;
  isDoneLoading$: Observable<boolean>;
  token$: Observable<any>;

  constructor(private authService: AuthService) {
    this.isUserAuthenticated$ = this.authService.isAuthenticated$;
    this.isDoneLoading$ = this.authService.isDoneLoading$;
    this.token$ = this.authService.token$;
  }
}
