import * as L from "leaflet";
import { AfterViewInit, Component } from "@angular/core";
import { GeoJsonObject } from 'geojson';

@Component({
    standalone: true,
    selector: "test-map-component",
    template: `
    <div id="map" style="height: 300px; width: 300px"></div>
    `,
    styles: [],
})
export class TestComponent  {
    constructor() {
    }

}
