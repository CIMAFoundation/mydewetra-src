import { AfterViewInit, Component, ViewChild, signal } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, forkJoin } from 'rxjs';
import { ChartsModalComponent, FeatureChartsModalComponent, LegendModalComponent } from './charts-modal.component';
import { PropertiesModalComponent } from './properties-modal.component';
import { Dewetra3LayerEvent, BaseLayerManager, Dewetra3MapClick, Dewetra3MapComponent, LayerManagerFactory, LayerWithViewProps, PropertiesComponentFactory, ViewProps } from '@cima/dewetra3-core';

@Component({
  selector: 'app-refactor-test',
  template: `
  <dewetra3-map-component
    #dewetra3Map
    [layers]="layers"
    (onMapInfo)="onMapInfo($event)"
    (onLayerEvent)="onLayerEvent($event)"
    style="height: 500px;width: 1200px">
  </dewetra3-map-component>
  <br>
  <button (click)="doThingsOnMap()">Do things on map</button>
  <button (click)="showInfos = !showInfos">Info {{ showInfos }}</button>
  <br>
  <button (click)="showPunctual = !showPunctual">punctualSerie {{ showPunctual }}</button>
  <br>
  <p>{{dateFrom.toDateString()}} -  {{dateTo.toString()}}</p>
  <br>
  @for ( layer of layers; track layer.layer.getLayerModel().id) {
    - {{ layer.layer.getName() }}
    <button (click)="showProperties(layer.layer)">Show Properties</button>
    <button (click)="showLayerLegend(layer.layer)">Show Legend</button>
    <span> layer.loading: {{layer.layer.isLoading$() | async}}</span>
    @if (showInfos){
        <dewetra3-info-wrapper *ngIf="clickData" [manager]="layer.layer" [clickData]="clickData" ></dewetra3-info-wrapper>
        <dewetra3-punctual-chart-wrapper *ngIf="clickData" [manager]="layer.layer" [clickData]="clickData" [dateFrom]="dateFrom" [dateTo]="dateTo"></dewetra3-punctual-chart-wrapper>
    }
    <br>
  }@empty {
    <p>No layers</p>
  }
  `,
  styleUrls: []
})
export class RefactorTestComponent implements AfterViewInit {
  @ViewChild('dewetra3Map') dewetra3Map: Dewetra3MapComponent;

  public showInfos = false;
  public showPunctual = false;

  public layers: LayerWithViewProps[] = [];

  public clickData: Dewetra3MapClick | null = null;

  // public dateFrom = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
  // public dateTo = new Date();
  public dateFrom = new Date('2024-03-01');
  public dateTo = new Date('2024-03-31 10:59:59 ');

  constructor(
    public managerFactory: LayerManagerFactory,
    public propertiesFactory: PropertiesComponentFactory,
    public modal: MatDialog,
    public http: HttpClient

  ) {

    // 269 dds
    // 125 mappa pioggia
    // 293 termometri
    // 248 pluviometri
    // 295 series
    // 301 status radar
    // 274 confini regionali
    // 303 warnings

    const layers = ['274'];



    const layerObservables = layers.map(id => this.loadLayerById(id));

    forkJoin(layerObservables).subscribe((loadedLayers: any[]) => {
      loadedLayers.map((layer: any) => {
        const layerInstance = this.managerFactory.create(layer);
        const layerWithVisualisationOptions = {
          layer, viewProps$: new BehaviorSubject<ViewProps>({
            opacity: 1,
            visibility: true,
            showInLayerList: true
          })
        };
        this.layers = [layerWithVisualisationOptions, ...this.layers]
        console.log('Loaded layerInstance', layerInstance);

      })
    });

    // const layer = this.managerFactory.create(DDS_LAYER)
    // this.layers.push(layer);
  }

  async ngAfterViewInit() {

    // date from 3 days ago
    const date = new Date();
    date.setDate(date.getDate() - 3);



    setTimeout(async () => {
      for (const layer of this.layers) {
        layer.layer.applyDefaultProperties(this.dateFrom, this.dateTo);

        this.layers = [...this.layers];
      }
    }, 3000);
  }

  setLayer() {

    //return [...this.layers];

  }

  loadLayerById(id: string) {
    return this.http.get('http://localhost:8000/dewapi/layers/' + id + '/');
  }


  showProperties(layer: BaseLayerManager) {
    this.modal.open(PropertiesModalComponent, {
      width: '95vw',
      height: '85vw',
      data: {
        manager: layer,
      }
    });
  }

  showPunctualChart(clickData: Dewetra3MapClick | null = null) {
    this.modal.open(ChartsModalComponent, {
      width: '95vw',
      height: '85vw',
      hasBackdrop: false,
      data: {
        managers: this.layers.filter(layer => layer.layer.hasPunctualSeries()),
        clickData
      }
    });
  }

  showSensorChart(event: Dewetra3LayerEvent) {

    this.modal.open(FeatureChartsModalComponent, {
      width: '95vw',
      height: '85vw',
      data: {
        clickData: event
      }
    });
  }

  showLayerLegend(layer: BaseLayerManager) {
    this.modal.open(LegendModalComponent, {
      width: '95vw',
      height: '85vw',
      data: {
        manager: layer
      }
    });
  }

  onMapInfo(event: Dewetra3MapClick | null) {

    this.clickData = event;

    console.log('clickData', this.clickData);

    if (this.showPunctual) {
      this.showPunctualChart(this.clickData);
    }
  }

  onLayerEvent(event: Dewetra3LayerEvent) {
    console.log('layerEvent', event);

    switch (event.type) {
      case 'click':
        this.showSensorChart(event);
        break;
      case 'mouseover':
        break;
      case 'mouseout':
        break;
    }
  }

  doThingsOnMap() {
    this.dewetra3Map.mapInstance.fitBounds([[42, 13], [43, 14]]);
  }

}
