import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RefactorTestComponent} from './refactor-test.component';
import {PropertiesModalComponent} from './properties-modal.component';
import {RefactorRoutingModule} from './refactor-test.routing.module';
import {ChartsModalComponent, FeatureChartsModalComponent, LegendModalComponent} from './charts-modal.component';


import {Dewetra3LegendModule, Dewetra3MapModule} from '@cima/dewetra3-core';
import {Dewetra3InfoModule} from '@cima/dewetra3-core';
import {Dewetra3PropertieModule} from '@cima/dewetra3-core';
import {Dewetra3ChartsModule} from '@cima/dewetra3-core';
import {MatDialogModule} from '@angular/material/dialog';
import {MatTabsModule} from '@angular/material/tabs';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import {MatCommonModule, MatOptionModule} from '@angular/material/core';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatLabel, MatSelectModule} from '@angular/material/select';
import {CimaCommonsModule} from "@cima/commons";

const _MAT_MODULES = [
  MatOptionModule,
  MatCommonModule,
  MatProgressSpinnerModule,
  MatSelectModule,
  MatLabel,
  MatDialogModule,
  MatTabsModule

];

@NgModule({ declarations: [
        RefactorTestComponent,
        PropertiesModalComponent,
        ChartsModalComponent,
        FeatureChartsModalComponent,
        LegendModalComponent
    ], imports: [CommonModule,
        RefactorRoutingModule,
        Dewetra3MapModule,
        Dewetra3InfoModule,
        Dewetra3PropertieModule,
        Dewetra3ChartsModule,
        Dewetra3LegendModule,
        ..._MAT_MODULES,
        CimaCommonsModule], providers: [provideHttpClient(withInterceptorsFromDi())] })
export class RefactorTestModule {
}
