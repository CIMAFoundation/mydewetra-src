import {Component, Inject} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog} from '@angular/material/dialog';
import {BaseLayerManager} from '@cima/dewetra3-core';


@Component({
  selector: 'properties-modal',
  template: `
    <cima-dialog-title [hasCloseButton]="true">
      {{ modalData.manager.getName() }}
    </cima-dialog-title>
    <div>
      <dewetra3-properties-wrapper [manager]="modalData.manager"></dewetra3-properties-wrapper>
    </div>
  `,
  styleUrls: [],
})
export class PropertiesModalComponent {
  constructor(
    public dialogRef: MatDialog,
    @Inject(MAT_DIALOG_DATA) public modalData: { manager: BaseLayerManager; }
  ) {
  }
}
