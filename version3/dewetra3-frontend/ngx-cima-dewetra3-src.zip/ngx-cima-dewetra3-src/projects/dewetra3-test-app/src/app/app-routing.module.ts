import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {
  AuthGuard,
  NotFoundComponent,
  PortalContainerComponent,
  PortalContainerNoSidenavComponent,
} from '@cima/commons';
import {TestComponent} from './test.component';
import {ReportPrintPage} from '@cima/dewetra3';

const routes: Routes = [
  {
    path: '',
    component: PortalContainerComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'credits',
        loadChildren: () =>
          import('./credits/credits.module').then((m) => m.CreditsModule),
      },
      {
        path: '',
        loadChildren: () =>
          import('@cima/dewetra3').then((m) => m.CimaDewetra3Module),
      },
      {
        path: 'test',
        component: TestComponent
      },
      {
        path: 'test-refactor',
        loadChildren: () => import('./pages/refactor-test/refactor-test.module').then(m => m.RefactorTestModule)
      }

    ],
  },


  {
    path: '',
    component: PortalContainerNoSidenavComponent,
    canActivate: [AuthGuard],
    children: [
      // {
      //   path: 'dewetra3',
      //   loadChildren: () =>
      //     import('@cima/dewetra3').then((m) => m.CimaDewetra3Module),
      // },
    ],
  },
  {
    path: 'report',
    component: ReportPrintPage,
  },

  {
    path: '404',
    component: NotFoundComponent,
  },

  {
    path: '**',
    redirectTo: '',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {enableTracing: false, useHash: true})],
  exports: [RouterModule],
})
export class AppRoutingModule {
}
