
export const DDS_LAYER = {
    "id": 269,
    "server": {
        "id": 1,
        "url": "http://localhost:8000/dewapi/server/1/proxy/",
        "name": "ddscima",
        "descr": "Dewetra Data Server at Cima Foundation"
    },
    "source": {
        "id": 14,
        "name": "ARPA-SIMC",
        "icon": "source_default"
    },
    "category": "forecast",
    "event": null,
    "hazards": [
        {
            "id": 1,
            "name": "flood",
            "icon": "hazard_default"
        }
    ],
    "geoscale": "Italia",
    "tags": [
        {
            "id": 45,
            "name": "DEV",
            "icon": "tag_default"
        }
    ],
    "inspirethemes": [
        {
            "id": 1,
            "name": "unknown",
            "icon": null
        }
    ],
    "dracategories": [
        {
            "id": 1,
            "name": "unknown",
            "icon": null
        }
    ],
    "paths": [
        {
            "id": 5,
            "path": "simple",
            "hierarchy": "meteorological models"
        }
    ],
    "infomanager": null,
    "legendmanager": null,
    "metadatamanager": null,
    "propertiesmanager": {
        "id": 1,
        "component": "DDSLayerPropertiesComponent",
        "props": {}
    },
    "layermanager": {
        "id": 3,
        "component": "DDSWMSLayerManager",
        "props": {}
    },
    "chartmanager": {
        "id": 1,
        "component": "DDSChartComponent",
        "props": {}
    },
    "mapmanager": {
        "id": 1,
        "component": "DDSWMSMapComponent",
        "props": {}
    },
    "related": [],
    "icon": "meteo_models",
    "name": "COSMO-5M",
    "descr": "COSMO-5M",
    "dataid": "COSMO_I5",
    "thumb": null,
    "lonw": 6,
    "lone": 18,
    "lats": 30,
    "latn": 50,
    "enabled": true,
    "customprops": null,
    "roles": []
} as any;

export const STATIC_LAYER = {
    "id": 31,
    "server": {
        "id": 5,
        "name": "Geoserver geonode",
        "descr": "Geoserver geonode",
        "url": "https://geodata.cimafoundation.org/geoserver/wms"
    },
    "source": {
        "id": 4,
        "name": "unknown",
        "icon": "source_default"
    },
    "category": "static",
    "event": null,
    "hazards": [],
    "geoscale": "Italia",
    "tags": [
        {
            "id": 23,
            "name": "Unità Amministrative",
            "icon": "tag_default"
        }
    ],
    "inspirethemes": [
        {
            "id": 1,
            "name": "unknown",
            "icon": null
        }
    ],
    "dracategories": [
        {
            "id": 1,
            "name": "unknown",
            "icon": null
        }
    ],
    "paths": [
        {
            "id": 20,
            "path": "simple",
            "hierarchy": "Confini Amministrativi"
        }
    ],
    "layertype": "StaticLayer",
    "related": [],
    "icon": "province",
    "name": "Confini Provinciali 2016",
    "descr": "Confini Provinciali 2016",
    "dataid": "CIMA:cmprov2016_wgs84_1",
    "thumb": null,
    "lonw": 6.5388786024,
    "lone": 19.6137381161,
    "lats": 35.2169136966,
    "latn": 47.1358216211,
    "enabled": true,
    "customprops": null,
    "roles": []
} as any;

export const WMST_LAYER = {
    "id": 301,
    "server": {
        "id": 24,
        "name": "Geoserver GFM",
        "descr": "Geoserver GFM",
        "url": "https://geoserver.gfm.eodc.eu/geoserver/gfm/wms"
    },
    "source": {
        "id": 4,
        "name": "unknown",
        "icon": "source_default"
    },
    "category": "static",
    "event": null,
    "hazards": [],
    "geoscale": "Italia",
    "tags": [
        {
            "id": 23,
            "name": "Unità Amministrative",
            "icon": "tag_default"
        }
    ],
    "inspirethemes": [
        {
            "id": 1,
            "name": "unknown",
            "icon": null
        }
    ],
    "dracategories": [
        {
            "id": 1,
            "name": "unknown",
            "icon": null
        }
    ],
    "paths": [
        {
            "id": 20,
            "path": "simple",
            "hierarchy": "Confini Amministrativi"
        }
    ],
    //"layertype": "WMSTLayer",
    "layertype": "WMSTCapabilitiesLayer",
    "related": [],
    "icon": "province",
    "name": "WMS-T Example",
    "descr": "Confini Provinciali 2016",
    "dataid": "observed_flood_extent_group_layer",
    "thumb": null,
    "lonw": 6.5388786024,
    "lone": 19.6137381161,
    "lats": 35.2169136966,
    "latn": 47.1358216211,
    "enabled": true,
    "customprops": null,
    "roles": []
} as any;

export const PUVIOMETER_LAYER = {
    "id": 248,
    "server": {
        "id": 1,
        "name": "ddscima",
        "descr": "Dewetra Data Server at Cima Foundation",
        "url": "https://dds-test.cimafoundation.org/dds"
    },
    "source": {
        "id": 7,
        "name": "Regioni",
        "icon": "source_default"
    },
    "category": "observation",
    "event": null,
    "hazards": [],
    "geoscale": "Italia",
    "tags": [
        {
            "id": 45,
            "name": "DEV",
            "icon": "tag_default"
        }
    ],
    "inspirethemes": [
        {
            "id": 1,
            "name": "unknown",
            "icon": null
        }
    ],
    "dracategories": [
        {
            "id": 1,
            "name": "unknown",
            "icon": null
        }
    ],
    "paths": [
        {
            "id": 22,
            "path": "simple",
            "hierarchy": "stations.sensors"
        }
    ],
    "infomanager": null,
    "legendmanager": {
        "id": 6,
        "component": "SensorsLegendComponent",
        "props": {
            "default": {
                "legend": [
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#555",
                        "label": "n.p.",
                        "value": [],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(85,85,85, .1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#cbcbcb",
                        "label": "n.d.",
                        "value": [],
                        "textcolor": "#000000",
                        "color_rgba": "rgba(203,203,203, .1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#ffffff",
                        "label": "0",
                        "value": [
                            0,
                            1.99
                        ],
                        "textcolor": "#000000",
                        "color_rgba": "rgba(255,255,255, .1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#e1ffe1",
                        "label": "2",
                        "value": [
                            2,
                            4.99
                        ],
                        "textcolor": "#000000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#c8ffc8",
                        "label": "5",
                        "value": [
                            5,
                            9.9
                        ],
                        "textcolor": "#000000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#50f050",
                        "label": "10",
                        "value": [
                            10,
                            14.9
                        ],
                        "textcolor": "#000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#1eb41e",
                        "label": "15",
                        "value": [
                            15,
                            19.9
                        ],
                        "textcolor": "#000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#0f8c0f",
                        "label": "20",
                        "value": [
                            20,
                            24.9
                        ],
                        "textcolor": "#000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#0f640f",
                        "label": "25",
                        "value": [
                            25,
                            29.9
                        ],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#0f3c0f",
                        "label": "30",
                        "value": [
                            30,
                            39.9
                        ],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#ffff00",
                        "label": "40",
                        "value": [
                            40,
                            49.9
                        ],
                        "textcolor": "#000000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#dcdc00",
                        "label": "50",
                        "value": [
                            50,
                            59.9
                        ],
                        "textcolor": "#000000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#b9b900",
                        "label": "60",
                        "value": [
                            60,
                            69.9
                        ],
                        "textcolor": "#000000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#969600",
                        "label": "70",
                        "value": [
                            70,
                            79.9
                        ],
                        "textcolor": "#000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#737300",
                        "label": "80",
                        "value": [
                            80,
                            89.9
                        ],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#505000",
                        "label": "90",
                        "value": [
                            90,
                            99.9
                        ],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#ff0000",
                        "label": "100",
                        "value": [
                            100,
                            124.9
                        ],
                        "textcolor": "#000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#dc0000",
                        "label": "125",
                        "value": [
                            125,
                            149.9
                        ],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#b90000",
                        "label": "150",
                        "value": [
                            150,
                            174.9
                        ],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#960000",
                        "label": "175",
                        "value": [
                            175,
                            199.9
                        ],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#ff80ff",
                        "label": "200",
                        "value": [
                            200,
                            299.9
                        ],
                        "textcolor": "#000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#f000f0",
                        "label": "300",
                        "value": [
                            300,
                            399.9
                        ],
                        "textcolor": "#000",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#b700b7",
                        "label": "400",
                        "value": [
                            400,
                            499.9
                        ],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": "",
                        "color": "#780078",
                        "label": "500",
                        "value": [
                            500,
                            599.9
                        ],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(255,255,255,1)"
                    },
                    {
                        "mu": "mm",
                        "dec": 1,
                        "sign": ">",
                        "color": "#080b78",
                        "label": "500",
                        "value": [
                            600,
                            9999
                        ],
                        "textcolor": "#ffffff",
                        "color_rgba": "rgba(255,255,255,1)"
                    }
                ]
            }
        }
    },
    "metadatamanager": null,
    "chartmanager": {
        "id": 1,
        "component": "SentinelLayer",
        "props": {}
    },
    "mapmanager": {
        "id": 1,
        "component": "SentinelLayer",
        "props": {}
    },

    "propertiesmanager": {
        "id": 4,
        "component": "SentinelLayer",
        "props": {
            "id": "id",
            "data": "data",
            "attributes": [
                {
                    "name": "aggregation",
                    "type": "List",
                    "descr": "Cumulative Range",
                    "value": "3",
                    "entries": [
                        {
                            "descr": "last 1 h",
                            "value": "1",
                            "referredValues": null
                        },
                        {
                            "descr": "last 3 h",
                            "value": "3",
                            "referredValues": null
                        },
                        {
                            "descr": "last 6 h",
                            "value": "6",
                            "referredValues": null
                        },
                        {
                            "descr": "last 12 h",
                            "value": "12",
                            "referredValues": null
                        },
                        {
                            "descr": "last 24 h",
                            "value": "24",
                            "referredValues": null
                        },
                        {
                            "descr": "last 48 h",
                            "value": "48",
                            "referredValues": null
                        },
                        {
                            "descr": "last 72 h",
                            "value": "72",
                            "referredValues": null
                        }
                    ],
                    "visible": "true",
                    "selectedEntry": {
                        "descr": "last 1 h",
                        "value": "1",
                        "referredValues": null
                    }
                }
            ],
            "description": "description",
            "longDescription": "longDescription"
        }
    },
    "layermanager": {
        "id": 26,
        "component": "SentinelLayer",
        "props": null
    },
    "related": [],
    "icon": "weather_stations",
    "name": "PLUVIOMETRI",
    "descr": "Pluviometri",
    "dataid": "2;national_PLUVIOMETRO;italy.sensor.rainfall;sensors.pluvio",
    "thumb": null,
    "lonw": 6,
    "lone": 18,
    "lats": 30,
    "latn": 50,
    "enabled": true,
    "layertype": "SentinelLayer",
    "customprops": {
        "2": {
            "chart_id": "sensors.pluvio",
            "serie_id": "all.sensor.rainfall",
            "threshold_group": "national_PLUVIOMETRO"
        },
        "5": {
            "chart_id": "sensors.thermo",
            "serie_id": "all.sensor.thermometers",
            "threshold_group": "national_TERMOMETRO"
        }
    },
    "roles": []
} as any;

const FLOODPROOFS = {
    "id": 295,
    "server": {
        "id": 20,
        "url": "https://dds.cimafoundation.org/dds",
        "name": "ddscima-OLD",
        "descr": "Dewetra Data Server at Cima Foundation-OLD"
    },
    "source": {
        "id": 7,
        "name": "Regioni",
        "icon": "source_default"
    },
    "category": "observation",
    "event": null,
    "hazards": [],
    "geoscale": "Italia",
    "tags": [
        {
            "id": 45,
            "name": "DEV",
            "icon": "tag_default"
        }
    ],
    "inspirethemes": [
        {
            "id": 1,
            "name": "unknown",
            "icon": null
        }
    ],
    "dracategories": [
        {
            "id": 1,
            "name": "unknown",
            "icon": null
        }
    ],
    "paths": [
        {
            "id": 22,
            "path": "simple",
            "hierarchy": "stations.sensors"
        }
    ],
    "infomanager": null,
    "legendmanager": {
        "id": 7,
        "component": "FloodproofLegendComponent",
        "props": {
            "default": {
                "alpha": "80",
                "field": "maxvalue",
                "width": 15,
                "height": 15,
                "legend": [
                    {
                        "name": "undefined",
                        "type": "threshold",
                        "alpha": "80",
                        "color": "#cbcbcb",
                        "descr": 1,
                        "field": "maxvalue",
                        "label": "2",
                        "shape": "square",
                        "severity": 1,
                        "textcolor": "#1c0606",
                        "stroke_alpha": "80",
                        "stroke_color": "#000000",
                        "stroke_width": "2"
                    },
                    {
                        "name": "no exceedings",
                        "type": "threshold",
                        "alpha": "FF",
                        "color": "#ffffff",
                        "descr": 1,
                        "field": "maxvalue",
                        "label": "2",
                        "shape": "square",
                        "severity": 1,
                        "textcolor": "#1c0606",
                        "stroke_alpha": "80",
                        "stroke_color": "#000000",
                        "stroke_width": "2"
                    },
                    {
                        "thr": "Q_ALLARME",
                        "name": "thr_1",
                        "type": "threshold",
                        "alpha": "FF",
                        "color": "#FFFF00",
                        "descr": 1,
                        "field": "maxvalue",
                        "label": "2",
                        "shape": "triangle",
                        "severity": 1,
                        "textcolor": "#150606",
                        "stroke_alpha": "80",
                        "stroke_color": "#000000",
                        "stroke_width": "2"
                    },
                    {
                        "thr": "Q_ALLERTA",
                        "name": "thr_2",
                        "type": "threshold",
                        "alpha": "FF",
                        "color": "#FF0000",
                        "descr": 1,
                        "field": "maxvalue",
                        "label": "2",
                        "shape": "triangle",
                        "severity": 2,
                        "textcolor": "#051a05",
                        "stroke_alpha": "80",
                        "stroke_color": "#000000",
                        "stroke_width": "2"
                    },
                    {
                        "name": "undef",
                        "type": "value",
                        "alpha": "FF",
                        "color": "#cbcbcb",
                        "descr": 1,
                        "field": "maxvalue",
                        "label": "2",
                        "shape": "square",
                        "value": -9999,
                        "severity": 2,
                        "textcolor": "#021802",
                        "stroke_alpha": "80",
                        "stroke_color": "F000",
                        "stroke_width": "2"
                    },
                    {
                        "name": "no rain",
                        "type": "value",
                        "alpha": "FF",
                        "color": "#00FFFF",
                        "descr": 1,
                        "field": "maxvalue",
                        "label": "2",
                        "shape": "square",
                        "value": -7777,
                        "severity": 2,
                        "textcolor": "#1f211f",
                        "stroke_alpha": "80",
                        "stroke_color": "#000000",
                        "stroke_width": "2"
                    },
                    {
                        "name": "no meteo model",
                        "type": "value",
                        "alpha": "FF",
                        "color": "#4d5d53",
                        "descr": 1,
                        "field": "maxvalue",
                        "label": "2",
                        "shape": "square",
                        "value": -6666,
                        "severity": 2,
                        "textcolor": "#00FF00",
                        "stroke_alpha": "80",
                        "stroke_color": "#000000",
                        "stroke_width": "2"
                    },
                    {
                        "name": "run now",
                        "type": "value",
                        "alpha": "FF",
                        "color": "#b1d0ca",
                        "descr": 1,
                        "field": "maxvalue",
                        "label": "2",
                        "shape": "square",
                        "value": -5555,
                        "severity": 2,
                        "textcolor": "#00FF00",
                        "stroke_alpha": "80",
                        "stroke_color": "#000000",
                        "stroke_width": "2"
                    }
                ]
            }
        }
    },
    "metadatamanager": null,
    "propertiesmanager": null,
    "layermanager": {
        "id": 27,
        "component": "FloodProofManager",
        "props": null
    },
    "layertype": "FloodPROOFSLayer",
    "related": [],
    "icon": "weather_stations",
    "name": "FloodProof-GaugeObservation",
    "descr": "FloodProof-GaugeObservation",
    "dataid": "italy.floodproofs.gaugeobservation",
    "thumb": null,
    "lonw": 6,
    "lone": 18,
    "lats": 30,
    "latn": 50,
    "enabled": true,
    "customprops": {
        "2": {
            "chart_id": "sensors.pluvio",
            "serie_id": "all.sensor.rainfall",
            "threshold_group": "national_PLUVIOMETRO"
        },
        "5": {
            "chart_id": "sensors.thermo",
            "serie_id": "all.sensor.thermometers",
            "threshold_group": "national_TERMOMETRO"
        }
    },
    "roles": []
} as any;
