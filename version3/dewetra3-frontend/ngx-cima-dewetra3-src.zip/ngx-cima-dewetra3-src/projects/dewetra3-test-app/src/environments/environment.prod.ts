const protocol = window.location.protocol;
const hostname = window.location.hostname;
let port = window.location.port ? `:${window.location.port}` : '';

const wsProtocol = protocol === 'https:' ? 'wss:' : 'ws:';

export const environment = {
  title: 'Dewetra3',
  production: true,
  fakeData: false,
  debug: true,
  server: {
    baseUrl: `${protocol}//${hostname}${port}/api`,
    configEndpoint: `/acroweb`,
    wsEndpoint: `${wsProtocol}//${hostname}${port}/ws/notifier/`,
  },
};
