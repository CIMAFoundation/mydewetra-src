// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const DOMAIN: string = 'bricks-developers-access.cimafoundation.org';
//const DOMAIN: string = 'localhost';

export const environment = {
  title: 'Dewetra3',
  production: false,
  fakeData: false,
  debug: true,
  //devUser: 'alessandro.casasola@cimafoundation.onmicrosoft.com',
  //devUser: 'mirko.dandrea@cimafoundation.org',
  devUser: 'dario.rubado@cimafoundation.org',
  server: {
    baseUrl: `${DOMAIN === 'localhost' ? 'http' : 'https'}://${DOMAIN}/api`,
    configEndpoint: '/acroweb',
    //wsEndpoint: `${DOMAIN === 'localhost' ? 'ws' : 'wss'}://${DOMAIN}/api/ws/notifier/`,
    wsEndpoint: 'https://bricks-developers-access.cimafoundation.org/api/ws/notifier/',
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invoeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
