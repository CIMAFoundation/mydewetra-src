import { Component, Input } from '@angular/core';
import { TimepickerService, TimepickerValue } from '@cima/commons';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import {
  SENTINELLayerData,
  SENTINELLayerManager
} from '../../../managers/sentinel/sentinel.manager';
import { WARNINGSLayerManagerProperties } from '../../../managers/sentinel/warnings.manager';


@Component({
  selector: 'dewetra3-sentinel-warnings-pluviometer-properties',
  template: `
    <ng-template #loader>
      <div class="w-100 h-100 d-flex justify-content-center align-items-center">
        <mat-progress-bar mode="indeterminate"></mat-progress-bar>
      </div>
    </ng-template>

    @if (manager) {
      <div class="manager-event-wrap d-flex col-12 col-md-6 m-auto py-3 flex-column">
        @if (properties$ | async; as managerProperties) {
          <!-- check if properties$ is available -->
          <div class="d-flex justify-content-center">
            @if (managerProperties.aggregationsList; as aggregationsLevel) {
              <!-- check if ddsProperties is available -->
              <mat-form-field class="mx-1 flex-fill">
                <mat-label>{{ 'DEWETRA3CORE.AGGREGATIONS' | translate }}</mat-label>
                <mat-select [value]="properties.aggregationSelected" (selectionChange)="selectAggregation( $event)">
                  @for (aggregation of aggregationsLevel; track $index) {
                    <!-- loop through entries -->
                    <mat-option [value]="aggregation">{{ aggregation }}</mat-option>
                  }
                </mat-select>
              </mat-form-field>
            }
          </div>

          @if (managerProperties.minimumExceedingList.length > 0) {
            <div class="d-flex justify-content-center">
              <mat-form-field class="mx-1 flex-fill">
                <mat-label>{{ "DEWETRA3CORE.MINIMUM_EXCEEDING" | translate }}</mat-label>
                <mat-select [value]="managerProperties.minimumExceedingSelected"
                            (selectionChange)="selectExceeding($event)">
                  @for (minimumExceeding of manager.getLayerModel().propertiesmanager.props.minimumExceedingList; track $index) {
                    <!-- loop through entries -->
                    <mat-option [value]="minimumExceeding">{{ minimumExceeding }}</mat-option>
                  }
                </mat-select>
              </mat-form-field>
            </div>
          }
          @if (managerProperties.maximumTemporalAggregationList.length > 0) {
            <div class="d-flex justify-content-center">
              <mat-form-field class="mx-1 flex-fill">
                <mat-label>{{ "DEWETRA3CORE.MAXIMUM_TEMPORAL_AGGREGATIONS" | translate }}</mat-label>
                <mat-select [value]="managerProperties.maximumTemporalAggregationSelected"
                            (selectionChange)="selectTemporalAggregations($event)">
                  @for (temporalAggregation of manager.getLayerModel().propertiesmanager.props.maximumTemporalAggregationList; track $index) {
                    <!-- loop through entries -->
                    <mat-option [value]="temporalAggregation">{{ transformSecondsToHours(temporalAggregation) }}
                    </mat-option>
                  }
                </mat-select>
              </mat-form-field>
            </div>
          }
        }
        <div class="d-flex justify-content-center">
          <button mat-raised-button class="bg-success w-100" color="primary" (click)="apply()">
            {{ 'DEWETRA3APP.APPLY' | translate }}
          </button>
        </div>
      </div>
    }

  `,
  styles: [
    'manager-event-wrap { float: left }'
  ]
})
export class SENTINELWarningsPluviometerPropertiesComponent {

  @Input() manager!: SENTINELLayerManager;

  properties$!: Observable<WARNINGSLayerManagerProperties>;

  layerData$!: Observable<SENTINELLayerData>;

  layerData: SENTINELLayerData = null;

  properties: WARNINGSLayerManagerProperties = null;

  timepickerValue = new BehaviorSubject<TimepickerValue | null>(null);

  aggregationSelected: string = null;
  minimumExceedingSelected: string = null;
  maximumTemporalAggregationSelected: string = null;

  constructor(private timePicker: TimepickerService) {
    this.timePicker.timepickerValue$.subscribe(timepickerValue => this.timepickerValue.next(timepickerValue));
  }

  transformSecondsToHours(seconds: number): string {
    const hours = Math.floor(seconds / 3600);
    // const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h`;
  }

  ngOnInit(): void {
    this.properties$ = this.manager.getProperties$().pipe(
      //@ts-ignore
      tap((data) => {
        this.properties = data as WARNINGSLayerManagerProperties;
      })
    );
  }

  /**
   * Handles the selection of an aggregation value.
   *
   * @param $event - The event object containing the selected value.
   */
  selectAggregation($event: any) {
    this.aggregationSelected = $event.value;
  }

  selectExceeding($event: any) {
    this.minimumExceedingSelected = $event.value;
  }

  selectTemporalAggregations($event: any) {
    this.maximumTemporalAggregationSelected = $event.value;
  }

  async apply() {
    const timePickerValue = this.timepickerValue.value;
    if (timePickerValue === null) {
      return;
    }
    const dateFrom = timePickerValue?.from;
    const dateTo = timePickerValue?.to === 'now' ? new Date() : timePickerValue.to;

    const newProperties = {
      ...this.properties, ...{
        aggregationSelected: (this.aggregationSelected === null) ? this.properties.aggregationSelected : this.aggregationSelected,
        minimumExceedingSelected: (this.minimumExceedingSelected === null) ? this.properties.minimumExceedingSelected : this.minimumExceedingSelected,
        maximumTemporalAggregationSelected: (this.maximumTemporalAggregationSelected === null) ? this.properties.maximumTemporalAggregationSelected : this.maximumTemporalAggregationSelected
      },
      dateFrom,
      dateTo
    };

    this.manager.applyProperties(newProperties);
  }

}
