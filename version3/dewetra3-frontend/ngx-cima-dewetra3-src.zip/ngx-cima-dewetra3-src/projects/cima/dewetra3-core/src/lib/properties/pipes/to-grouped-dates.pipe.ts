import { Pipe, PipeTransform } from '@angular/core';
import { DDSLayerAvailability } from '../../models/layer-availability';

@Pipe({
  name: 'toGroupedDates',
})
export class AvailabilityToGroupedDatesPipe implements PipeTransform {
  transform(availability: DDSLayerAvailability[]): any {
    const modelDates = Array.from(
      availability.reduce((data, entry) => {
        const dates = entry.id.split(';');
        if (dates.length == 2) {
          data.add(dates[0])
        }
        return data;
      }, new Set<string>())
    );

    return {
      modelDates: modelDates,
      availability
    };
  }
}
