import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { DynamicModule } from 'ng-dynamic-component';
import { DDSLayerInfoComponent } from './components/dds/ddslayer-info.component';
import { DebugInfoComponent } from './components/debug/debug-info.components';
import { WMSLayerInfoComponent } from './components/wms/wms-info.component';
import { WMSTCopernicusLayerInfoComponent } from './components/wmst/wmst-coperrnicus-info.component';
import { WMSTLayerInfoComponent } from './components/wmst/wmst-info.component';
import { InfoWrapperComponent } from './components/wrapper/info-wrapper.component';
import { DDSWMSCustomInfoComponent } from './components/dds/dds-custom-info.component';

const _COMPONENTS = [
  InfoWrapperComponent,
  DDSLayerInfoComponent,
  WMSLayerInfoComponent,
  DebugInfoComponent,
  WMSTCopernicusLayerInfoComponent,
  WMSTLayerInfoComponent,
  DDSWMSCustomInfoComponent,
];

@NgModule({
  declarations:[_COMPONENTS],
  imports: [CommonModule, DynamicModule, TranslateModule],
  exports: [_COMPONENTS],
})
export class Dewetra3InfoModule {}
