import { Component, Input, OnDestroy, computed, effect, inject, signal } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Observable, Subscription } from 'rxjs';
import { DDSLayerManager } from '../../../managers/dds/dds.manager';
import { Dewetra3MapClick, WMSInfoResponse } from '../../../models/models';
import { getCustomInfoProperties } from '../../../utils/utils';
interface SerieInfoCustomProperties {
  layer_info: LayerInfo;
}
interface LayerInfo {
  fields: Field[];
  filtered: string[];
  translation_prefix: string;
}

interface Field {
  mu: string;
  type: string;
  digit: string;
  field: string;
  label: string;
  order: string;
  factor?: string;
}

@Component({
  selector: 'dewetra3-dds-wms-custom-info',
  template: `
    <div *ngIf="manager">
      <h4 class="mb-1">{{ manager.getName() }}</h4>
      <span *ngIf="infoEventsSignal() as info">
        <strong>
          <span *ngIf="info?.wmsData?.timeStamp">{{ parseTimeStamp(info?.wmsData?.timeStamp) }}</span>
        </strong>
        <ul>
          <li *ngFor="let v of featuresProperties()">
            <span translate>{{ transformToDewetra3Translation(v) }}</span>
            <span style="min-width: 30px;"></span>
            <span>{{ getFeatureProperty(v) }} </span>
          </li>
        </ul>
      </span>
    </div>
  `,
  styles: [
    `
      .label {
        font-weight: bold;
        color: var(--dewetra-orange);
      }
      h4 {
        font-size: 1rem;
        margin: 0;
      }
      ul {
        list-style-type: none;
        padding: 0;
      }
      li {
        display: flex;
        justify-content: space-between;
        padding: 0.5rem 0;
      }
    `,
  ],
})
export class DDSWMSCustomInfoComponent implements OnDestroy {
  @Input() manager!: DDSLayerManager;
  @Input() infoEvents$!: Observable<{ wmsData: WMSInfoResponse } | null>;
  @Input() clickData: Dewetra3MapClick;

  public infoEventsSignal = signal<{ wmsData: WMSInfoResponse } | null>(null);
  private translateService = inject(TranslateService);
  private translationPrefix = signal('DEWETRA3');
  private filteredFields = signal<string[]>([]);
  private fields = signal<Field[]>([]);
  private subscription: Subscription | null = null;

  constructor() {
    // Automatically update the signal when `infoEvents$` emits a new value
    effect(() => {
      if (this.subscription) {
        this.subscription.unsubscribe();
      }
      this.subscription = this.infoEvents$.subscribe((info) => this.infoEventsSignal.set(info));
    });

    effect(
      () => {
        if (this.infoEventsSignal()) {
          const properties: SerieInfoCustomProperties = getCustomInfoProperties(this.manager.getLayerModel()) || {
            layer_info: { fields: [], filtered: [], translation_prefix: 'DEWETRA3' },
          };

          this.translationPrefix.set(properties.layer_info.translation_prefix || 'DEWETRA3');
          this.filteredFields.set(properties.layer_info.filtered || []);
          this.fields.set(properties.layer_info.fields || []);
        }
      },
      { allowSignalWrites: true }
    );
  }

  featuresProperties = computed(() => {
    const properties = this.infoEventsSignal()?.wmsData?.features?.[0]?.properties || {};
    return Object.keys(properties).filter((key) => !this.filteredFields().includes(key));
  });

  getFeatureProperty(key: string) {
    const field = this.fields().find((f) => f.field === key);
    const rawValue = this.infoEventsSignal()?.wmsData?.features?.[0]?.properties[key];
    return field ? this.transformField(field, rawValue) : rawValue;
  }

  transformToDewetra3Translation(key: string) {
    const field = this.fields().find((f) => f.field === key);
    if (field) return this.translateService.instant(`${this.translationPrefix()}.${field.label}`.toUpperCase());
    const txt = `${this.translationPrefix()}.${key}`.toUpperCase();
    return this.translateService.instant(txt);
  }

  transformField(field: Field, value: any) {
    if (value == null) return '';

    switch (field.type) {
      case 'number': {
        const num = Number(value);
        return isNaN(num) ? value : num.toFixed(parseInt(field.digit ?? '0')) + ` ${field.mu ?? ''}`;
      }
      case 'date':
        return new Date(value).toLocaleDateString();
      case 'multiply': {
        const numMult = Number(value);
        return isNaN(numMult)
          ? value
          : (numMult * parseFloat(field.factor ?? '1')).toFixed(parseInt(field.digit ?? '0')) + ` ${field.mu ?? ''}`;
      }
      default:
        return value;
    }
  }

  parseTimeStamp(timeStamp: string): string {
    return new Date(timeStamp).toLocaleString();
  }

  // Clean up the subscription to prevent memory leaks
  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }
}
