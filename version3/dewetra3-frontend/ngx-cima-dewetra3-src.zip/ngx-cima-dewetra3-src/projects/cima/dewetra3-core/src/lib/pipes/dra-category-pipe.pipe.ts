import { Pipe, PipeTransform } from '@angular/core';
import { LayerDraCategory, LayerModel } from '../models/dewetra3-layer';

@Pipe({
  name: 'draCategoryPipe'
})
export class DraCategoryPipePipe implements PipeTransform {

  transform(layers: LayerModel[], args: LayerDraCategory[]): LayerModel[] {
    if (layers && layers.length >= 0 && args && args.length > 0) {
      layers = layers.filter((layer: LayerModel) => {
        const argsId = args.map((category: LayerDraCategory) => category.id);
        const draCategoriesId = layer.dracategories?.map((category: LayerDraCategory) => category.id);
        return draCategoriesId.some((id) => argsId.includes(id));
      });
      return layers as LayerModel[];
    } else {
      //console.log('DRA categoy: no layers or no args', layers, args)
      return layers as LayerModel[];
    }
  }
}
