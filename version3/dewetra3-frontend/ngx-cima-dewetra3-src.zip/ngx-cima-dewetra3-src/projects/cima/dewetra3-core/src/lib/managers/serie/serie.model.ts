import { Geometry } from "geojson"

export interface Compatibles {
  compatibles: Compatible[]
}

export interface Compatible {
  categoriesLabel: string
  descr: string
  descrField: string
  fidField: string
  id: string
  layer: string
  measure: string
  type: string
  valuesLabel: string
}

export interface SerieFeature {
  geometry: Geometry;
  properties: SerieFeatureProperties;
  type: FeatureType;
  id: string;
}

enum FeatureType {
  Feature = "Feature",
}

export interface SerieFeatureProperties {
  DATI_DA: string
}
