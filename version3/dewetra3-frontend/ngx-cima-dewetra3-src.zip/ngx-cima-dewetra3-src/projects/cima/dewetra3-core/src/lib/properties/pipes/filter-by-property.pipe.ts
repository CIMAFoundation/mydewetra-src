import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterByProperty',
  pure: false
})
export class FilterByPropertyPipe implements PipeTransform {
  transform(items: any[], filter: any): any {
    if (!items || !filter) {
      return items;
    }
    Object.keys(filter).forEach(key => {
      items = items.filter(item => item[key] === filter[key])
    })
    return  items;
  }
}
