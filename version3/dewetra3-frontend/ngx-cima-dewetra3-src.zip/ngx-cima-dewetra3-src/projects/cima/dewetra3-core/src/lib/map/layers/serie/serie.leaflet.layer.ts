import * as L from 'leaflet';

import { SERIELayerData, SERIELayerManagerProperties } from '../../../managers/serie/serie.manager';
import { BaseLayer } from '../base/base.layer';

import { buildSVGIcon, buildSVGShape, getLayerMapProperties } from '../../../utils/utils';

import { Feature, Point } from 'geojson';
import { BaseDewetra3LayerEventData, Dewetra3LayerEventWithData } from '../../../managers/base/base.manager';
import { LayerDataContainer } from '../../../models/models';
import { CustomPropertiesSeries } from '../../../models/serie';

export interface SerieLayerEventData extends BaseDewetra3LayerEventData {
  feature: any;
}

export class SerieLayerLeafletLayer extends BaseLayer {
  private sectionLayer: L.GeoJSON;

  override bringToFront(): void {
    this.sectionLayer?.bringToFront();
  }
  override bringToBack(): void {
    this.sectionLayer?.bringToBack();
  }
  override async updateMapLayer(data: LayerDataContainer): Promise<void> {
    const dataLayer = data.data as SERIELayerData;
    const properties = data.properties as unknown as SERIELayerManagerProperties;
    if (this.sectionLayer) {
      this.map.removeLayer(this.sectionLayer);
    }

    this.sectionLayer = L.geoJSON(dataLayer.sections, {
      pointToLayer: (feature, latlng) => {
        return this.featureStyle(feature, latlng);
      },
      onEachFeature: (feature, layer) => {
        layer.on({
          click: (evt) => this.emitLayerEvent('click', evt.target.feature),
          mouseover: (evt) => this.emitLayerEvent('mouseover', evt.target.feature),
          mouseout: (evt) => this.emitLayerEvent('mouseout', evt.target.feature),
        });
      },
    });
    this.map.addLayer(this.sectionLayer);
  }

  private emitLayerEvent(type: 'click' | 'mouseover' | 'mouseout', feature: any) {
    const data: SerieLayerEventData = { feature };
    const event = { type, layer: this.layer, data } as Dewetra3LayerEventWithData;
    this.onLayerEvent.emit(event);
  }

  override _remove(): void {
    this.map.removeLayer(this.sectionLayer);
  }
  override setOpacity(opacity: number): void {
    this.sectionLayer.setStyle({ opacity });
  }
  override setVisible(visible: boolean): void {
    if (visible) {
      this.map.addLayer(this.sectionLayer);
    } else {
      this.map.removeLayer(this.sectionLayer);
    }
  }

  private featureStyle(feature: Feature<Point, any>, latlng: L.LatLng) {
    const legendPropertiesDefault = (getLayerMapProperties(this.layer.getLayerModel()) as CustomPropertiesSeries).default;
    const { field: propToCheck, height, width, legend } = legendPropertiesDefault;
    let value: any = feature.properties[propToCheck];
    const trend = feature.properties.trend;

    const getLegendStyle = (legendItem: any) => ({
      fillColor: legendItem.color,
      fillColorAlpha: legendItem.alpha,
      strokeColor: legendItem.stroke_color,
      strokeAlpha: legendItem.stroke_alpha,
      strokeWidth: legendItem.stroke_width,
      shape: legendItem.shape,
    });

    const createMarker = (legendItem: any) => {
      const { fillColor, fillColorAlpha, strokeColor, strokeAlpha, strokeWidth, shape } = getLegendStyle(legendItem);
      const icon = buildSVGShape(
        shape,
        fillColor,
        fillColorAlpha,
        strokeColor,
        strokeAlpha,
        strokeWidth,
        width.toString(),
        height.toString(),
        trend
      );
      return L.marker(latlng, { icon: buildSVGIcon(icon) });
    };

    // Default legend if value is undefined or maxvalue is not present
    if (value === null || value === undefined || !feature?.properties?.maxvalue) {
      return createMarker(legend[0]);
    }

    // Handle thresholds
    const thresholds = legend.filter((item: any) => item.type === 'threshold');

    const exceedings = thresholds.filter(
      (item: any) =>
        feature.properties[item.thr] !== '-9999' &&
        feature.properties[item.thr] !== '' &&
        value >= parseFloat(feature.properties[item.thr])
    );

    if (exceedings.length > 0) {
      const maxSeverity = exceedings.reduce((prev, current) => (prev.severity > current.severity ? prev : current));
      return createMarker(maxSeverity);
    }

    // Handle exact value matches
    const valueMatches = legend.filter((item: any) => item.type === 'value' && item.value === value);
    if (valueMatches.length > 0) {
      return createMarker(valueMatches[0]);
    }

    // Default fallback
    return createMarker(legend[1]);
  }

  override getBounds(): L.LatLngBounds {
    return this.sectionLayer?.getBounds();
  }
}
