
import { inject, Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Pipe({
  name: 'replacePlaceholder'
})
export class ReplacePlaceholderPipe implements PipeTransform {
  //  "title": "{{DEWETRA3CORE.SEZIONE}}: {{SEZIONE}} ",
  transform(value: string, properties: any,): string {
    const translateService = inject(TranslateService);

    return value.replace(/{{(.*?)}}/g, (_, key) => {
      const trimmedKey = key.trim();
      if (trimmedKey.startsWith('DEWETRA3CORE.') || trimmedKey.startsWith('DEWETRA3.')) {
        return translateService.instant(trimmedKey) || '';
      }
      return properties[trimmedKey] || '';
    });
  }
}
