import {HttpClient} from '@angular/common/http';
import {AuthService, CimaEnvironment} from '@cima/commons';
import * as L from 'leaflet';
import {uniqueId} from 'lodash-es';
import cloneDeep from 'lodash-es/cloneDeep';
import {BehaviorSubject, distinctUntilChanged, filter, firstValueFrom, map, Observable, of, Subscription} from 'rxjs';
import {webSocket, WebSocketSubject} from 'rxjs/webSocket';
import {LayerModel} from '../../models/dewetra3-layer';

import {computed, signal, WritableSignal} from '@angular/core';
import {
  BaseLayerManagerData,
  BaseLayerManagerProperties,
  BaseMapInfoResult,
  BasePunctualSeriesResult,
  BaseSeriesResult,
  LayerDataContainer,
  ViewProps,
} from '../../models/models';
import {MovieStatus} from '../../models/movie';

export interface LayerWithViewProps {
  layer: BaseLayerManager;
  viewProps$: BehaviorSubject<ViewProps>;
}

export interface BaseDewetra3LayerEventData {
}

export type LayerEventType = 'click' | 'mouseover' | 'mouseout' | 'loaded' | 'removed';

export interface Dewetra3LayerCommonEvent {
  type: LayerEventType;
  layer: BaseLayerManager;
}

export interface Dewetra3LayerEventWithData extends Dewetra3LayerCommonEvent {
  type: 'click' | 'mouseout' | 'mouseover';
  data?: BaseDewetra3LayerEventData;
}

export interface Dewetra3LayerLifecycleEvent extends Dewetra3LayerCommonEvent {
  type: 'loaded' | 'removed';
}

export type Dewetra3LayerEvent = Dewetra3LayerEventWithData | Dewetra3LayerLifecycleEvent;

/**
 * Abstract base class for layer managers.
 */
export abstract class BaseLayerManager {
  public data$ = new BehaviorSubject<LayerDataContainer>(null);

  public uuid: string;

  protected watchSubscription: Subscription;

  protected movieSubscription: Subscription;

  protected movieBaseStatus: MovieStatus = {
    available: false,
    status: 'idle',
    taskId: '',
    progressMap: {
      frames: [],
      currentIndex: 0,
      canProceed: false,
    },
  };

  protected currentMovieState: WritableSignal<MovieStatus> = signal(this.movieBaseStatus);

  public movieStatus = computed((): string => this.currentMovieState().status);

  constructor(
    protected env: CimaEnvironment,
    protected auth: AuthService,
    protected http: HttpClient,
    protected layerModel: LayerModel
  ) {
    this.uuid = uniqueId(this.layerModel.name.toLowerCase().trim().split(' ').join('') + '_');
  }

  /**
   * Retrieves the default properties for the layer manager.
   * @param dateFrom The start date.
   * @param dateTo The end date.
   * @returns A promise that resolves to the default properties.
   */
  protected abstract getDefaultProperties(dateFrom: Date, dateTo: Date): Promise<BaseLayerManagerProperties>;

  /**
   * Retrieves the data for the layer using the specified properties.
   * @param properties The properties for the layer.
   * @returns A promise that resolves to the layer data.
   */
  protected abstract getLayerData(properties: BaseLayerManagerProperties): Promise<BaseLayerManagerData>;

  /**
   * Sets the default properties for the layer manager and updates the layer.
   * @param dateFrom
   * @param dateTo
   */
  public async applyDefaultProperties(dateFrom: Date, dateTo: Date): Promise<void> {
    const properties = await this.getDefaultProperties(dateFrom, dateTo);
    this.applyProperties(properties);
  }

  /**
   * Asyncronosouly loads the layer using the specified properties.
   * @param properties The properties for the layer.
   * @returns A promise that resolves when the layer is loaded.
   */

  public async applyProperties(properties: BaseLayerManagerProperties): Promise<void> {
    this.postActivityLog('', 'layer-loaded');

    this.setLoading(properties);
    try {
      const data = await this.getLayerData(properties);
      this.setData(data);
    } catch (error) {
      const errorString = error instanceof Error ? error.message : String(error);
      this.setError(errorString);
    }
  }

  /**
   * Retrieves the layer model associated with the manager.
   * @returns The layer model.
   */
  public getLayerModel(): LayerModel {
    return this.layerModel;
  }

  /**
   * Connects to a WebSocket with the specified path.
   * @param path The path to connect to.
   * @returns An observable WebSocket subject.
   */
  public getWebSocket(path: string): WebSocketSubject<any> {
    const token = this.auth.accessToken;
    const wsEndpoint = this.env.server.wsEndpoint;
    let url = `${wsEndpoint}?path=${path}&token=${token}`;
    return webSocket(url);
  }

  /**
   * Retrieves the properties as an observable stream. It clones the properties to prevent mutation.
   * @returns An observable stream of the layer properties.
   */
  public getProperties$(): Observable<BaseLayerManagerProperties> {
    return this.data$.asObservable().pipe(
      filter((data) => !!data),
      map((data) => data.properties),
      distinctUntilChanged(),
      map((properties) => cloneDeep(properties))
    );
  }

  /**
   * Sets the loading status and properties for the layer.
   * @param properties The properties for the layer.
   */
  protected setLoading(properties?: BaseLayerManagerProperties) {
    this.postActivityLog('', 'layer-loading');

    this.data$.next({
      ...this.data$.value,
      properties: properties || this.data$.value?.properties,
      status: 'loading',
      error: null,
    });
  }

  /**
   * Sets the error status and message for the layer.
   * @param error The error message.
   */
  protected async setError(error: string) {
    //@ts-ignore
    if (typeof error !== 'string') error = 'An error occurred ' + (error.message || '');

    this.postActivityLog(error, 'layer-error');

    this.data$.next({
      ...this.data$.value,
      status: 'error',
      error: error,
    });
  }

  /**
   * Retrieves the layer data as an observable stream.
   * @returns An observable stream of the layer data.
   */
  public getData$(): Observable<LayerDataContainer> {
    return this.data$.asObservable().pipe(
      filter((data) => !!data),
      distinctUntilChanged()
    );
  }

  /**
   * Sets the data for the LayerManager.
   *
   * @param data The data to be set.
   */
  protected async setData(data: BaseLayerManagerData) {
    const newData = {
      ...this.data$.value,
      status: 'loaded',
      error: null as string,
      data: data,
    };

    this.data$.next(newData as LayerDataContainer);
  }

  /**
   * Retrieves the loading status as an observable stream.
   * @returns An observable stream of the loading status.
   */
  public isLoading$(): Observable<boolean> {
    return this.data$.asObservable().pipe(
      filter((data) => !!data),
      map((data) => data.status === 'loading'),
      distinctUntilChanged()
      // tap((loading) => {console.log('Loading: ', loading)})
    );
  }

  /**
   * Retrieves the error message as an observable stream.
   * @returns An observable stream of the error message.
   */
  public getError$(): Observable<string> {
    return this.data$.asObservable().pipe(
      filter((data) => !!data),
      filter((data) => data.status === 'error'),
      map((data) => data.error),
      distinctUntilChanged()
      // tap((error) => {console.log('Error: ', error)})
    );
  }

  /**
   * Retrieves the error status as an observable stream.
   * @returns An observable stream of the error status.
   */
  public hasError$(): Observable<boolean> {
    return this.data$.asObservable().pipe(
      filter((data) => !!data),
      map((data) => data.status === 'error'),
      distinctUntilChanged()
      // tap((error) => {console.log('Error: ', error)})
    );
  }

  /**
   * Destroys the layer manager, unsubscribing from any active subscriptions and clearing the data.
   */
  public destroy(): void {
    if (this.watchSubscription) {
      this.watchSubscription.unsubscribe();
    }
    if (this.movieSubscription) {
      this.movieSubscription.unsubscribe();
    }
    this.data$.next(null);
    this.data$.complete();
    this.postActivityLog('Layer destroyed', 'layer-removed');
    console.info(`Layer ${this.layerModel.name} destroyed`);
  }

  /**
   * Updates the date range for the layer.
   * @param dateFrom The start date.
   * @param dateTo The end date.
   */
  public setDateRange(dateFrom: Date, dateTo: Date | 'now'): void {
    const resolvedDateTo = dateTo === 'now' ? new Date() : dateTo;

    try {
      if (dateTo === 'now') {
        this.watch();
      } else {
        this.stopWatch();
        this.postActivityLog(`from ${dateFrom.toISOString()} to ${dateTo.toISOString()}`, 'layer-loaded');
      }
    } catch (error) {
      console.error(`Error in ${dateTo === 'now' ? 'watch' : 'stopWatch'}():`, error);
    }

    const oldProperties = this.data$.value?.properties || {};
    const newProperties = {
      ...oldProperties,
      dateFrom,
      dateTo: resolvedDateTo,
    };
    this.applyProperties(newProperties);
  }

  /**
   * Retrieves the name of the layer.
   * @returns The name of the layer.
   */
  public getName(): string {
    return this.layerModel.name;
  }

  /**
   * Retrieves the name_i18n of the layer.
   * @returns The name_i18n of the layer.
   */
  public getName_i18n(): string {
    return this.layerModel.name_i18n;
  }

  /**
   * Retrieves the description of the layer.
   * @returns The description of the layer.
   */
  public getDescription(): string {
    return this.layerModel.descr;
  }

  public getLayerBounds(): [number, number][] {
    const model = this.layerModel;
    const latn = model.latn || 90;
    const lonw = model.lonw || -180;
    const lats = model.lats || -90;
    const lone = model.lone || 180;
    return [
      [latn, lonw],
      [lats, lone],
    ];
  }

  /**
   * Sends an HTTP GET request to the specified URL and returns the response as an Observable.
   *
   * @param url - The URL to send the request to.
   * @param params - The parameters to include in the request.
   * @returns An Observable that emits the response data.
   */
  public getExternal<T>(url: string, params?: any): Observable<T> {
    return this.http.get<T>(url, {params: params});
  }

  /**
   * Sends a POST request to an external API.
   *
   * @param url - The URL of the API endpoint.
   * @param payload - The data to be sent in the request body.
   * @returns An Observable that emits the response data of type T.
   */
  public postExternal<T>(url: string, payload: any): Observable<T> {
    return this.http.post<T>(url, payload);
  }

  /**
   * Logs an activity to the server.
   *
   * @param message - The message to be logged.
   */
  public async postActivityLog(message: string, type: string = 'log'): Promise<void> {
    const dataid = this.layerModel.dataid;
    const id = this.layerModel.id;
    message = `${type};layer;${id}:${dataid}:${message}`;
    let server = this.env.server.baseUrl + '/dewetra3/commons/log/';
    const result = await firstValueFrom(this.http.post<any>(server, {message}));
    if (result.status === 'error') {
      console.error('Error logging activity');
    }
    if (result.status === 'success') {
      console.log(message);
    }
  }

  /**
   * Checks if the manager has map-info capabilities.
   * If the manager has map-info capabilities, it should override this method and return true.
   * It should also override the getInfo$ method to provide the map-info functionality.
   *
   * @returns {boolean} True if the manager has information, false otherwise.
   */
  public hasMapInfo(): boolean {
    return false;
  }

  public getLayerDetail$(): Observable<string> {
    return of('');
  }

  public getLayerDownloadUrl$(): Observable<string> {
    return of('');
  }

  /**
   * Checks if the manager has punctual series capabilities.
   * If the manager has punctual series capabilities, it should override this method and return true.
   * It should also override the getPunctualSeries$ method to provide the punctual series functionality.
   *
   * @returns {boolean} True if the manager has punctual series, false otherwise.
   */
  public hasPunctualSeries(): boolean {
    return false;
  }

  /**
   * Checks if the manager has series capabilities.
   * If the manager has series capabilities, it should override this method and return true.
   * It should also override the getSeries$ method to provide the series functionality.
   *
   * @returns {boolean} True if the manager has series, false otherwise.
   */
  public hasSeries(): boolean {
    return false;
  }

  /**
   * Retrieves information about a specific location on the map.
   * @param latlng The latitude and longitude of the location.
   * @returns An observable that emits the information about the location.
   */
  public getInfo$(latlng: L.LatLng): Observable<BaseMapInfoResult> {
    throw new Error('Method not implemented.');
  }

  /**
   * Retrieves the punctual series for the given latitude and longitude.
   * @param latLng The latitude and longitude coordinates.
   * @returns An observable that emits the punctual series data.
   */
  public getPunctualSeries$(latLng: L.LatLng, dateFrom: Date, dateTo: Date): Observable<BasePunctualSeriesResult> {
    throw new Error('Method not implemented.');
  }

  /**
   * Retrieves the series for the given event data.
   * @param eventData The event data.
   * @param dateFrom The start date.
   * @param dateTo The end date.
   * @returns An observable that emits the series data.
   */
  public getSeries$(eventData: BaseDewetra3LayerEventData, dateFrom: Date, dateTo: Date): Observable<BaseSeriesResult> {
    throw new Error('Method not implemented.');
  }

  /**
   * Retrieves the series for the given event data.
   * @param eventData The event data.
   * @returns An observable that emits the series data.
   */
  public getLayerEventInfo$(eventData: BaseDewetra3LayerEventData): Observable<BaseSeriesResult> {
    throw new Error('Method not implemented.');
  }

  /**
   * Watches the layer for updates.
   */
  public watch() {
    console.info('Not implemented');
  }

  /**
   * Stops watching the layer for updates.
   */
  public stopWatch() {
    console.info('Not implemented');
  }

  /**
   * Checks if the manager has movie capabilities.
   * If the manager has movie capabilities, it should override this method and return true.
   * It should also override the next and previous methods to provide the movie functionality.
   *
   * @returns {boolean} True if the manager has movie capabilities, false otherwise.
   */
  public hasMovie$(): Observable<boolean> {
    return of(false);
  }

  /**
   * Forward the movie.
   */
  public next() {
    console.info('Not implemented');
  }

  /**
   * Backwards the movie.
   */
  public previous() {
    console.info('Not implemented');
  }

  /**
   * Play the movie.
   */
  public play() {
    console.info('Not implemented');
  }

  /**
   * Stops the movie.
   */
  public stop() {
    console.info('Not implemented');
  }
}
