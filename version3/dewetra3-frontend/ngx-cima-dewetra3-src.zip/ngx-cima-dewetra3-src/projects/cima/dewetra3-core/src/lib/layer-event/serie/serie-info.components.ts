import { Component, computed, effect, inject, Input, signal } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { BaseDewetra3LayerEventData, BaseLayerManager } from '../../managers/base/base.manager';
import { getCustomInfoProperties } from '../../utils/utils';

interface SerieInfoCustomProperties {
  layer_info: LayerInfo;
}

interface LayerInfo {
  fields: Field[];
  filtered: string[];
  translation_prefix: string;
}

interface Field {
  mu: string;
  type: string;
  digit: string;
  field: string;
  format?: string;
  label: string;
  order: string;
  factor?: string;
}

@Component({
  selector: 'dewetra3-serie-info',
  template: `
    <div *ngIf="layerEventState()">
      <h2>{{ title() }}</h2>
      <h4>{{ subtitle() }}</h4>
      <ul>
        <li *ngFor="let v of featuresProperties()">
          <span translate>{{ transformToDewetra3Translation(v) }}</span>
          <span style="min-width: 30px;"></span>
          <span>{{ getFeatureProperty(v) }} </span>
        </li>
      </ul>
    </div>
  `,
  styles: [
    `
      h2 {
        font-size: 1.5rem;
        font-weight: bold;
        margin: 0;
      }
      h4 {
        font-size: 1rem;
        margin: 0;
      }
      ul {
        list-style-type: none;
        padding: 0;
      }
      li {
        display: flex;
        justify-content: space-between;
        padding: 0.5rem 0;
      }
    `,
  ],
})
export class SERIEInfoComponent {
  @Input() manager!: BaseLayerManager;
  @Input() set layerEvent(value: BaseDewetra3LayerEventData | null) {
    this.layerEventState.set(value);
  }
  @Input() infoEvents$!: Observable<any>;

  private translateService = inject(TranslateService);
  private translationPrefix = signal('DEWETRA3');
  private customInfoProperties = signal<SerieInfoCustomProperties | null>(null);
  private filteredFields = signal<string[]>([]);
  private fields = signal<Field[]>([]);
  public layerEventState = signal<BaseDewetra3LayerEventData | null | any>(null);

  constructor() {
    // Effetto reattivo che aggiorna i dati quando cambia `layerEvent`
    effect(
      () => {
        if (this.layerEventState()) {
          const properties = getCustomInfoProperties(this.manager.getLayerModel()) || {
            layer_info: { fields: [], filtered: [], translation_prefix: 'DEWETRA3' },
          };
          this.customInfoProperties.set(properties);
          this.translationPrefix.set(properties.layer_info.translation_prefix || 'DEWETRA3');
          this.filteredFields.set(properties.layer_info.filtered || []);
          this.fields.set(properties.layer_info.fields || []);
        }
      },
      { allowSignalWrites: true }
    );
  }

  title = computed(() => this.layerEventState()?.feature?.properties.DATI_DA || '');

  subtitle = computed(() => '');

  featuresProperties = computed(() => {
    const properties = this.layerEventState()?.feature?.properties || {};
    return Object.keys(properties).filter((key) => !this.filteredFields().includes(key));
  });

  getFeatureProperty(key: string) {
    const field = this.fields().find((f) => f.field.toUpperCase() === key.toUpperCase());

    const rawValue = this.layerEventState()?.feature?.properties[key];
    return field ? this.transformField(field, rawValue) : rawValue;
  }

  transformToDewetra3Translation(key: string) {
    const txt = `${this.translationPrefix()}.${key}`.toUpperCase();
    return this.translateService.instant(txt);
  }

  transformField(field: Field, value: string) {
    if (!value) return '';

    switch (field.type) {
      case 'number':
        return parseFloat(value).toFixed(parseInt(field.digit));
      case 'date':
        //TODO:  field.format is a valid date format from db
        //field.format = field.format || 'yyyy-MM-dd';
        // value example: 2023-10-01T00:00:00.000Z
        const date = new Date(value).toLocaleDateString();
        if (date === 'Invalid Date') {
          return value;
        }
        return date;

      case 'multiply':
        return (
          (parseFloat(value) * parseFloat(field.factor || '1')).toFixed(parseInt(field.digit)) + ` ${field.mu || ''}`
        );
      default:
        return value;
    }
  }
}
