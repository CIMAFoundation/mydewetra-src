import { Component, Input } from '@angular/core';
import { BaseLayerManager } from '../../../managers/base/base.manager';

@Component({
  selector: 'dewetra3-sentinel-legend',
  template: `
    <div class="legend">
      <div class="legend-title"></div>
      <div class="legend-content">
        @if (manager.getLayerModel().legendmanager.props; as legendProps) { @for (legendItem of
        legendProps.default.legend; track $index) {
        <div class="legend-item">
          <div class="legend-item-color" [style.background-color]="legendItem.color">
            <div class="legend-item-label" [style.color]="legendItem.textcolor">
              {{ legendItem.label }} {{ legendItem.mu }}
            </div>
          </div>
        </div>
        } }
      </div>
    </div>
  `,
  styleUrls: [],
})
export class SENTINELLegendComponent {
  @Input() manager!: BaseLayerManager;
}
