import { BehaviorSubject, Observable, Subscription, filter, switchMap, tap } from 'rxjs';
import { BaseLayerManager, Dewetra3LayerLifecycleEvent, LayerWithViewProps } from '../../../managers/base/base.manager';
import { BaseLayerManagerProperties, LayerDataContainer, ViewProps } from '../../../models/models';
// Import DDSLayerManagerProperties if it exists

import { EventEmitter } from '@angular/core';
import { Dewetra3LayerCommonEvent } from '../../../managers/base/base.manager';


/**
 * Represents a base layer in the map.
 */
export abstract class BaseLayer {
  /**
   * Creates a new instance of the BaseLayer class.
   * @param map The Leaflet map instance.
   * @param layer The base layer manager.
   */

  protected layerData$: Observable<LayerDataContainer>;
  protected subscription: Subscription;
  protected viewPropsSubscription: Subscription;
  protected layer!: BaseLayerManager;
  protected viewProps$!: BehaviorSubject<ViewProps>;

  constructor(
    protected map: L.Map,
    layerWithProps: LayerWithViewProps,
    protected onLayerEvent: EventEmitter<Dewetra3LayerCommonEvent> // notify the map component of layer events
  ) {
    this.layer = layerWithProps.layer;
    this.viewProps$ = layerWithProps.viewProps$;

    this.layerData$ = this.layer.getData$();
    // construct the layer
    this.subscription = this.layerData$
      .pipe(
        filter((data) => !!data),
        filter((data) => data.status === 'loaded'),
        switchMap((data) => this.updateMapLayer(data)),
        tap(() =>
          this.onLayerEvent.emit({
            type: 'loaded',
            layer: this.layer,
          } as Dewetra3LayerLifecycleEvent)
        )
      )
      .subscribe();

    this.viewPropsSubscription = this.viewProps$.subscribe((props) => {
      this?.setOpacity(props.opacity);
      this?.setVisible(props.visibility);
    });

    
  }

  /**
   * Brings the layer to the front.
   */
  abstract bringToFront(): void;

  /**
   * Brings the layer to the back.
   */
  abstract bringToBack(): void;

  /**
   *
   */
  abstract updateMapLayer(data: LayerDataContainer): Promise<void>;

  /**
   * Removes the layer from the map.
   */
  abstract _remove(): void;

  public remove() {
    this._remove();
    this.subscription.unsubscribe();
    this.viewPropsSubscription.unsubscribe();

    this.onLayerEvent.emit({
      type: 'removed',
      layer: this.layer,
    });
  }

  /**
   * Sets the opacity of the layer.
   * @param opacity The opacity value (0-1).
   */
  abstract setOpacity(opacity: number): void;

  /**
   * Sets the visibility of the layer.
   * @param visible The visibility flag.
   */
  abstract setVisible(visible: boolean): void;

  /**
   * Retrieves information about the layer based on the map click event.
   * @param infoEvent The map click event data.
   * @returns An observable that emits the map information result.
   */
  //abstract getInfo$(infoEvent: Dewetra3MapInfoClickData): Observable<BaseMapInfoResult>;

  abstract getBounds(): L.LatLngBounds;

  public zoomOnLayer() {
    const bounds = this.getBounds();
    this.map.fitBounds(bounds);
  }
}
