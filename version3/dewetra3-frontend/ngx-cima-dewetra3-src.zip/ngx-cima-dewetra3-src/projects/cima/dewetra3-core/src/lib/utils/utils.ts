import { TranslateService } from '@ngx-translate/core';
import {
  endOfMonth,
  endOfWeek,
  format,
  getHours,
  setHours,
  setMilliseconds,
  setMinutes,
  setSeconds,
  startOfDay,
  startOfMonth,
  startOfWeek,
  startOfYear,
  subDays,
} from 'date-fns';
import * as L from 'leaflet';
import moment, { Moment } from 'moment';
import { LayerModel } from '../models/dewetra3-layer';
import { DDSLayerAvailability } from '../models/layer-availability';
import { SentinelFeatureProperties, SentinelValueAndExceedingMergedData } from '../models/sentinel';

/**
 * Converts a Date object or the string 'now' to seconds.
 * If the input is 'now', the current date and time will be used.
 * @param date - The Date object or the string 'now'.
 * @returns The number of seconds since the Unix epoch.
 */
export function dateToSeconds(date: Date | 'now'): number {
  if (date === 'now') {
    date = new Date();
  }

  if (typeof date === 'string') {
    date = new Date(date);
  }

  return Math.round(date.getTime() / 1000);
}

/**
 * Converts a Date object or the string 'now' to ISO format.
 * If the input is 'now', the current date and time will be used.
 * @param date - The Date object or the string 'now'.
 * @returns The ISO formatted string representation of the date.
 */
export function dateToIsoFormat(date: Date | 'now'): string {
  if (date === 'now') {
    date = new Date();
  }
  return date.toISOString().split('.')[0];
}

export function getCustomPropertiesByKey(model: LayerModel, key: string | number): any {
  const customProperties = model.customprops;
  if (!customProperties) {
    return null;
  }
  if (typeof customProperties === 'object' && customProperties.hasOwnProperty(key)) {
    return customProperties[key];
  } else {
    return null;
  }
}

export function getCustomProperties(model: LayerModel): any {
  return model.customprops;
}

export function getCustomPropertiesObjectKeys(model: LayerModel): string[] {
  return Object.keys(model.customprops);
}

export function getCustomChartProperties(model: LayerModel): any {
  const properties = model.chartmanager?.props;
  return properties || {};
}

export function getCustomInfoProperties(model: LayerModel): any {
  const properties = model.infomanager?.props;
  return properties || {};
}

export function getLegendProperties(model: LayerModel): any {
  const properties = model.legendmanager?.props;
  return properties || {};
}

export function getLayerMapProperties(model: LayerModel): any {
  const properties = model.mapmanager?.props;
  return properties || {};
}

export function buildSVGIcon(svg: string) {
  let iconUrl = 'data:image/svg+xml;base64,' + btoa(svg);
  return L.icon({ iconUrl: iconUrl });
}

export function nearestMid(date: Date): Date {
  const dateTo = new Date(date);
  const now = new Date();

  // Controlla se la differenza è inferiore a -1 giorno
  if (dateTo.getTime() - now.getTime() < -86400000) {
    // Nessuna modifica
  } else {
    // Sottrae 8 ore
    dateTo.setUTCHours(dateTo.getUTCHours() - 8);
  }

  // Imposta ora a 12 o 0 in base all'orario corrente
  dateTo.setUTCHours(dateTo.getUTCHours() > 12 ? 12 : 0, 0, 0, 0);

  return dateTo;
}

export function buildSVGShape(
  shape: string,
  color: string,
  fillColorAlpha: string = 'FF',
  strokeColor: string = '#000000',
  strokeAlpha: string = '#FF',
  strokeWidth: string = '2',
  width: string = '15',
  height: string = '15',
  direction: number
) {
  // Combine color with alpha
  const fillColor = color + fillColorAlpha;

  // SVG templates
  const shapes = {
    triangleDown: `<svg id="triangleDown" fill="${fillColor}" width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 490 490">
      <polygon stroke="${strokeColor}" stroke-opacity="${strokeAlpha}" stroke-width="${strokeWidth}" points="245,456.701 490,33.299 0,33.299"/>
    </svg>`,
    triangleUp: `<svg id="triangleUp" fill="${fillColor}" width="${width}" height="${height}" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path stroke="${strokeColor}" stroke-opacity="${strokeAlpha}" stroke-width="${strokeWidth}" d="M21.9,19.3l-9-15.6c-0.1-0.1-0.2-0.2-0.3-0.3c-0.5-0.3-1.1-0.2-1.4,0.3l-9,15.6C2,19.4,2,19.6,2,19.8c0,0.6,0.4,1,1,1h18c0.2,0,0.3,0,0.5-0.1C22,20.4,22.1,19.8,21.9,19.3z"/>
    </svg>`,
    square: `<svg id="square" fill="${fillColor}" width="${width}" height="${height}" viewBox="0 0 15 15" xmlns="http://www.w3.org/2000/svg">
      <rect width="${width}" height="${height}" fill="${fillColor}" stroke="${strokeColor}" stroke-opacity="${strokeAlpha}" stroke-width="${strokeWidth}"/>
    </svg>`,
    circle: `<svg id="circle" viewBox="0 0 15 15" xmlns="http://www.w3.org/2000/svg">
      <circle r="${width}" fill="${fillColor}" stroke="${strokeColor}" stroke-opacity="${strokeAlpha}" stroke-width="${strokeWidth}"/>
    </svg>`,
    triangleV2Down: `<svg id="triangleV2Down" viewBox="0 0 15 15" xmlns="http://www.w3.org/2000/svg">
      <polygon fill="${fillColor}" stroke="${strokeColor}" stroke-width="${strokeWidth}" vector-effect="non-scaling-stroke" points="0,0 7,15 15,0"/>
    </svg>`,
    triangleV2Up: `<svg id="triangleV2Up" viewBox="0 0 15 15" xmlns="http://www.w3.org/2000/svg">
      <polygon fill="${fillColor}" stroke="${strokeColor}" stroke-width="${strokeWidth}" vector-effect="non-scaling-stroke" points="0,15 7,0 15,15"/>
    </svg>`,
  };

  // Determine shape
  if (shape === 'triangle') {
    switch (direction) {
      case -1:
        return shapes.triangleDown;
      case 0:
        return shapes.square;
      case 1:
        return shapes.triangleUp;
    }
  } else if (shape === 'square') {
    return shapes.square;
  } else if (shape === 'circle') {
    return shapes.circle;
  }

  return '';
}

// export function getWMSLayerInfoUrlFromMap(
//   wmsUrl: string,
//   map: L.Map,
//   layer: L.TileLayer.WMS,
//   latlngPoint: L.LatLng
// ): string {
//   const point = latlngPoint;
//   const size = map.getSize();
//   const bounds = map.getBounds();

//   //load data from server
//   return getWMSLayerInfoUrl(wmsUrl, point, layer.wmsParams.layers);
// }

export interface WMSInfoOptions {
  version?: '1.1.1' | '1.3.0';
  bufferDeg?: number; // gradi di buffer attorno al punto
  widthPx?: number; // dimensione in pixel (orizzontale)
  heightPx?: number; // dimensione in pixel (verticale)
  featureCount?: number;
  infoFormat?: string;
  crs?: string; // es. 'EPSG:4326'
  extraParams?: Record<string, string | number>;
}

export function getWMSLayerInfoUrl(
  baseUrl: string,
  point: L.LatLng,
  layerName: string,
  opts: WMSInfoOptions = {}
): string {
  const {
    version = '1.3.0',
    bufferDeg = 1,
    widthPx = 301,
    heightPx = 301,
    featureCount = 10,
    infoFormat = 'application/json',
    crs = 'EPSG:4326',
    extraParams = {},
  } = opts;

  // 1) bounding box con buffer
  const south = point.lat - bufferDeg;
  const north = point.lat + bufferDeg;
  const west = point.lng - bufferDeg;
  const east = point.lng + bufferDeg;

  // 2) bbox string in base a versione e CRS
  //    - per WMS 1.3.0 + EPSG:4326: lat,lon order
  //    - altrimenti: lon,lat order
  let bbox: string;
  if (version === '1.3.0' && crs === 'EPSG:4326') {
    bbox = [south, west, north, east].join(',');
  } else {
    bbox = [west, south, east, north].join(',');
  }

  // 3) coordinate del pixel di interrogazione (centro)
  const i = Math.floor(widthPx / 2);
  const j = Math.floor(heightPx / 2);

  // 4) costruzione URL in modo sicuro
  const url = new URL(baseUrl);
  const params = url.searchParams;

  params.set('request', 'GetFeatureInfo');
  params.set('service', 'WMS');
  params.set('version', version);
  params.set('layers', layerName);
  params.set('query_layers', layerName);
  params.set('bbox', bbox);
  params.set('width', widthPx.toString());
  params.set('height', heightPx.toString());
  params.set(version === '1.3.0' ? 'crs' : 'srs', crs);
  params.set(version === '1.3.0' ? 'i' : 'x', i.toString());
  params.set(version === '1.3.0' ? 'j' : 'y', j.toString());
  params.set('feature_count', featureCount.toString());
  params.set('info_format', infoFormat);

  // 5) eventuali params addizionali
  for (const [k, v] of Object.entries(extraParams)) {
    params.set(k, String(v));
  }

  return url.toString();
}

/**
 * Generates a custom template function that replaces variables in a template string with their corresponding values from a data object.
 * @param templateString The template string containing variables to be replaced.
 * @param settings Optional settings object.
 * @returns A function that accepts a data object and returns the template string with variables replaced.
 */
//const compiledTemplate = customTemplate("Hello, ${name}! You are ${age} years old.");
//const result = compiledTemplate({ name: "Alice", age: 30 });
export function customTemplate(templateString: string, settings?: any): (data: any) => string {
  return (data: any) => {
    // Regular expression to match variables in the template
    const variableRegex = /\${(.*?)}/g;

    // Replace variables in the template with their corresponding values from the data object
    return templateString.replace(variableRegex, (match, variable) => {
      // Use the variable as a key to access its corresponding value in the data object
      return data[variable.trim()];
    });
  };
}

export function parseUnixTimestampOrDateFormatted(dateStr: string): Moment {
  if (/^\d{13}$/.test(dateStr)) {
    // timestamp in millisecondi → parsalo in UTC direttamente
    return moment.utc(parseInt(dateStr, 10));
  } else if (/^\d{12}$/.test(dateStr)) {
    // 'YYYYMMDDHHmm' già in UTC → parsalo in UTC
    return moment.utc(dateStr, 'YYYYMMDDHHmm');
  } else {
    return moment.invalid();
  }
}

export function metersToKilometers(meters: number): number {
  return meters / 1000;
}

export function kilometersToMeters(kilometers: number): number {
  return kilometers * 1000;
}

export function metersToFeet(meters: number): number {
  return meters * 3.28084;
}

export function feetToMeters(feet: number): number {
  return feet / 3.28084;
}

export function metersToMiles(meters: number): number {
  return meters * 0.000621371;
}

export function milesToMeters(miles: number): number {
  return miles / 0.000621371;
}

export function kilometersToSquareKilometers(kilometers: number): number {
  return kilometers * 1000000;
}
export function kilometersToHectares(kilometers: number): number {
  return kilometers * 100;
}

export function kilometersToSquareMiles(kilometers: number): number {
  return kilometers * 0.386102;
}

export function squareMetersToSquareKilometers(squareMeters: number): number {
  return squareMeters / 1000000;
}

export function mergeExceedingAndValue(
  sentinelFeatureProperties: SentinelFeatureProperties
): Map<number, SentinelValueAndExceedingMergedData> {
  const valuesMap = new Map<number, SentinelValueAndExceedingMergedData>();

  //case of aggregations
  if (sentinelFeatureProperties?.values) {
    sentinelFeatureProperties.values.map((value) => {
      valuesMap.set(value.p, {
        type: value.a,
        value: value.v,
        timestamp_v: value.t,
        sev: -1,
      });
    });
    return valuesMap;
  }

  if (sentinelFeatureProperties?.v) {
    //case of warnings
    if (sentinelFeatureProperties?.v?.length == 0) return valuesMap;

    sentinelFeatureProperties?.v.map((value) => {
      valuesMap.set(value.p, {
        type: value.a,
        value: value.v,
        timestamp_v: value.t,
        sev: -1,
      });
    });

    if (sentinelFeatureProperties?.e?.length == 0) return valuesMap;

    sentinelFeatureProperties?.e.map((value) => {
      const toks = value.name.split('_');
      const period = extractPeriodInSeconds(toks[toks.length - 1]);
      const sevName = toks[toks.length - 2];
      valuesMap.set(period, {
        value: value.v,
        timestamp_e: value.t,
        thr_id: value.id,
        sevName: sevName,
        sev: value.sev,
      });
    });

    return valuesMap;
  }
  return valuesMap;
}

/**
 *
 * @param value
 * @param properties
 * @param translateService
 * @returns
 */
export function replacePlaceholders(
  value: string,
  properties: Record<string, any>,
  translateService: TranslateService
): string {
  return value?.replace(/{{(.*?)}}/g, (_, key) => {
    const trimmedKey = key.trim();
    // Use the property value if it exists, otherwise use the translation
    return properties[trimmedKey] || translateService.instant(trimmedKey) || '';
  });
}

export function transformStringToTranslatablePlaceholder(string: string): string {
  // Replace spaces with underscores and convert to lowercase
  const transformedString = string.replace(/\s+/g, '_').toUpperCase();
  // Add double curly braces around the transformed string
  return `{{${transformedString}}}`;
}

export function transformStringToTranslatable(string: string): string {
  // Replace spaces with underscores and convert to lowercase
  const transformedString = string.replace(/\s+/g, '_').toUpperCase();
  // Add double curly braces around the transformed string
  return `${transformedString}`;
}

// Utility to extract and convert the last token (e.g., "1h") to seconds
export function extractPeriodInSeconds(name: string): number | undefined {
  // Match the last token in the name that indicates a time period (e.g., "1h", "3m")
  const match = name.match(/(\d+)([hms])$/);
  if (!match) return undefined;

  const value = parseInt(match[1]); // The numeric part, e.g., 1 or 3
  const unit = match[2]; // The unit part, e.g., 'h', 'm', 's'

  // Convert to seconds based on the unit
  switch (unit) {
    case 'h':
      return value * 3600;
    case 'm':
      return value * 60;
    case 's':
      return value;
    default:
      return undefined;
  }
}

export function buildDateOnPreFormat(time_builder: string, date: Date, formatPath?: string): string {
  switch (time_builder) {
    case 'nearestMid': {
      const roundedMinutes = date.getMinutes() < 30 ? 0 : 30;
      date = setMinutes(date, roundedMinutes);
      date = setSeconds(date, 0);
      date = setMilliseconds(date, 0);
      return format(date, "yyyy-MM-dd'T00:00:00Z'");
    }

    case 'nearestMidNightOrMidDay': {
      const hour = getHours(date);
      const targetHour = hour < 12 ? 0 : 12;
      date = setHours(startOfDay(date), targetHour);
      date = setMinutes(date, 0);
      date = setSeconds(date, 0);
      date = setMilliseconds(date, 0);
      return format(date, formatPath || "yyyy-MM-dd'T00:00:00Z'");
    }

    case 'nearestMidNight': {
      date = setHours(startOfDay(date), 0);
      return format(date, formatPath || "yyyy-MM-dd'T00:00:00Z'");
    }

    case 'nearestMidDay': {
      date = setHours(startOfDay(date), 12);

      return format(date, formatPath || "yyyy-MM-dd'T00:00:00Z'");
    }

    case 'nearestMidMonth': {
      date = startOfMonth(date);
      return format(date, "yyyy-MM-dd'T'T00:00:00Z'");
    }

    case 'nearestMidYear': {
      date = startOfYear(date);
      return format(date, "yyyy-MM-dd'T'HH:mm:ss'Z'");
    }

    case 'firstDayWeek': {
      date = startOfWeek(date, { weekStartsOn: 1 });
      return format(date, "yyyy-MM-dd'T'HH:mm:ss'Z'");
    }

    case 'lastDayWeek': {
      date = endOfWeek(date, { weekStartsOn: 1 });
      return format(date, "yyyy-MM-dd'T'HH:mm:ss'Z'");
    }

    case 'firstDayMonth': {
      date = startOfMonth(date);
      return format(date, "yyyy-MM-dd'T'HH:mm:ss'Z'");
    }

    case 'lastDayMonth': {
      date = endOfMonth(date);
      return format(date, "yyyy-MM-dd'T'HH:mm:ss'Z'");
    }

    case 'nearestHour': {
      date = setMinutes(date, 0);
      date = setSeconds(date, 0);
      date = setMilliseconds(date, 0);
      return format(date, "yyyy-MM-dd'T'HH:mm:ss'Z'");
    }

    case 'midnightDayBefore': {
      date = setHours(startOfDay(date), 0);
      date = setMinutes(date, 0);
      date = setSeconds(date, 0);
      date = setMilliseconds(date, 0);
      date = subDays(date, 1);
      return format(date, formatPath || "yyyy-MM-dd'T'HH:mm:ss'Z'");
    }

    default:
      return date.toISOString();
  }
}

export function degrees2meters(lon: number, lat: number): [number, number] {
  var x = (lon * 20037508.34) / 180;
  var y = Math.log(Math.tan(((90 + lat) * Math.PI) / 360)) / (Math.PI / 180);
  y = (y * 20037508.34) / 180;
  return [x, y];
}

interface DatePattern {
  regex: RegExp;
  extractor: (match: RegExpMatchArray) => Date;
}

export function parseDateFromDescription(desc: string): Date | null {
  const patterns: DatePattern[] = [
    // Match: Run: 2025-04-17 1300
    {
      regex: /(\d{4})[-\/](\d{2})[-\/](\d{2})[^\d]?(\d{2})(\d{2})/,
      extractor: ([, y, m, d, hh, mm]) =>
        new Date(Date.UTC(Number(y), Number(m) - 1, Number(d), Number(hh), Number(mm))),
    },
    // Match: 17/04/2025 13:00
    {
      regex: /(\d{2})[-\/](\d{2})[-\/](\d{4})[^\d]?(\d{2}):?(\d{2})/,
      extractor: ([, d, m, y, hh, mm]) =>
        new Date(Date.UTC(Number(y), Number(m) - 1, Number(d), Number(hh), Number(mm))),
    },
    // Match: 20250417 1300 (senza separatori)
    {
      regex: /(\d{4})(\d{2})(\d{2})[^\d]?(\d{2})(\d{2})/,
      extractor: ([, y, m, d, hh, mm]) =>
        new Date(Date.UTC(Number(y), Number(m) - 1, Number(d), Number(hh), Number(mm))),
    },

    // Match: 17 aprile 2025 ore 13:00 (sperimentale, richiede mapping mese)
    {
      regex: /(\d{1,2})\s+([a-zé]+)\s+(\d{4})\s+ore\s+(\d{2}):(\d{2})/i,
      extractor: ([, d, monthName, y, hh, mm]) => {
        const monthMap: { [key: string]: number } = {
          gennaio: 0,
          febbraio: 1,
          marzo: 2,
          aprile: 3,
          maggio: 4,
          giugno: 5,
          luglio: 6,
          agosto: 7,
          settembre: 8,
          ottobre: 9,
          novembre: 10,
          dicembre: 11,
          //inglese
          january: 0,
          february: 1,
          march: 2,
          april: 3,
          may: 4,
          june: 5,
          july: 6,
          august: 7,
          september: 8,
          october: 9,
          november: 10,
          december: 11,
          //spagnolo
          enero: 0,
          febrero: 1,
          abril: 3,
          mayo: 4,
          junio: 5,
          julio: 6,
          septiembre: 8,
          octubre: 9,
          noviembre: 10,
          diciembre: 11,
          //francese
          janvier: 0,
          février: 1,
          mars: 2,
          avril: 3,
          mai: 4,
          juin: 5,
          juillet: 6,
          août: 7,
          septembre: 8,
          octobre: 9,
          décembre: 11,
        };
        const m = monthMap[monthName.toLowerCase()];
        if (m === undefined) throw new Error('Mese non valido');
        return new Date(Date.UTC(Number(y), m, Number(d), Number(hh), Number(mm)));
      },
    },
  ];

  for (const pattern of patterns) {
    const match = desc.match(pattern.regex);
    if (match) {
      try {
        return pattern.extractor(match);
      } catch (e) {
        console.warn('Parsing fallito per pattern:', pattern.regex, e);
        continue;
      }
    }
  }

  return null; // Nessun match trovato
}

export function groupByDateRunDate(availability: DDSLayerAvailability[]): Record<string, DDSLayerAvailability[]> {
  return availability.reduce((grouped: Record<string, DDSLayerAvailability[]>, entry) => {
    const [modelDate] = entry.id.split(';'); // oppure usa `entry.date` se preferisci

    if (modelDate) {
      if (!grouped[modelDate]) {
        grouped[modelDate] = [];
      }
      grouped[modelDate].push(entry);
    }

    return grouped;
  }, {});
}
