import * as L from 'leaflet';

export interface Dewetra3MapClick {
  latLng: L.LatLng;
  map?: L.Map;
}

export interface BaseMapInfoResult {
  latLng: L.LatLng;
}

export class BasePunctualSeriesResult {
  status: 'loading' | 'loaded' | 'error';
  error?: string;
}

export class BaseSeriesResult {
  status: 'loading' | 'loaded' | 'error';
  error?: string;
}

export interface ViewProps {
  opacity: number;
  visibility: boolean;
  showInLayerList: boolean;
}

export interface WMSInfoResponse {
  type: string;
  features: WMSInfoFeature[];
  totalFeatures: string;
  numberReturned: number;
  timeStamp: string;
  crs?: Crs;
}

interface WMSInfoFeature {
  type: string;
  id: string;
  geometry?: any;
  properties: WMSInfoProperties;
}

interface Crs {
  id: number;
  type: string;
  properties: { code: string };
}

export interface Dewetra3Icon {
  name: string;
  value: string;
}

interface WMSInfoProperties {
  GRAY_INDEX?: number;

  [key: string]: string | number;
}

export interface BaseLayerManagerData {}

export interface BaseLayerManagerProperties {
  dateTo: Date;
  dateFrom: Date;
}

export interface LayerDataContainer {
  readonly status: 'loading' | 'loaded' | 'error';
  readonly error?: string;
  readonly properties: BaseLayerManagerProperties;
  readonly data: BaseLayerManagerData;
}
export interface PastMeasurement {
  type: string;
  layer: L.Layer;
  polylineLength?: number;
  polygonArea?: number;
  polygonPerimeter?: number;
}

export interface StaticLayerMapInfoResult extends BaseMapInfoResult {
  wmsData: any;
}
