import * as L from 'leaflet';
import {
  WMSTCapabilitiesLayerData,
  WMSTCapabilitiesManagerProperties,
} from '../../../managers/wmst/wmst-capabilities.manager';
import { LayerDataContainer } from '../../../models/models';
import { BaseLayer } from '../base/base.layer';

export class WMSTCapabilitiesLayerLeaflet extends BaseLayer {
  private wmsLayer: L.TileLayer.WMS | null = null;

  bringToFront(): void {
    this.wmsLayer?.bringToFront();
  }

  bringToBack(): void {
    this.wmsLayer?.bringToBack();
  }

  override async updateMapLayer(layerData: LayerDataContainer): Promise<void> {
    const data = layerData.data as WMSTCapabilitiesLayerData;
    const properties = layerData.properties as WMSTCapabilitiesManagerProperties;

    // Remove the existing layer if present
    if (this.wmsLayer) {
      this.map.removeLayer(this.wmsLayer);
      this.wmsLayer = null;
    }

    properties.wmsparams = properties.wmsparams || {};

    const params = {
      layers: data.layerid,
      format: 'image/png',
      //@ts-ignore Time properties for WMST Layer
      time: data.formattedDate,
      transparent: true,
      opacity: 1,
    };

    // Merge additional WMS parameters or add 
    Object.keys(properties.wmsparams).forEach((key) => {
      (params as any)[key] = properties.wmsparams[key];
    });

    // Create and add the new WMS layer
    this.wmsLayer = L.tileLayer.wms(data.serverUrl, params);

    this.map.addLayer(this.wmsLayer);
  }

  _remove(): void {
    if (this.wmsLayer) {
      this.map.removeLayer(this.wmsLayer);
      this.wmsLayer = null;
    }
  }

  setOpacity(opacity: number): void {
    this.wmsLayer?.setOpacity(opacity);
  }

  setVisible(visible: boolean): void {
    if (!this.wmsLayer) return;

    if (visible && !this.map.hasLayer(this.wmsLayer)) {
      this.map.addLayer(this.wmsLayer);
    } else if (!visible && this.map.hasLayer(this.wmsLayer)) {
      this.map.removeLayer(this.wmsLayer);
    }
  }

  override getBounds(): L.LatLngBounds {
    const model = this.layer.getLayerModel();
    return L.latLngBounds(
      L.latLng(model.latn ?? 90, model.lonw ?? -180),
      L.latLng(model.lats ?? -90, model.lone ?? 180)
    );
  }
}
