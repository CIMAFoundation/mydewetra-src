import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCommonModule, MatOptionModule } from "@angular/material/core";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatLabel, MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { CimaCommonsModule } from '@cima/commons';
import { Dewetra3MapModule } from '../lib/map/map.module';
import { Dewetra3InfoModule } from '../lib/info/info.module';
import { Dewetra3PropertieModule } from '../lib/properties/properties.module';
import { Dewetra3ChartsModule } from '../lib/charts/charts.module';
import { Dewetra3LegendModule } from '../lib/legend/legend.module';
import { Dewetra3PipesModule } from '../lib/pipes/pipes.module';
import { Dewetra3LayerEventModule } from './layer-event/layer-event.module';


const _MAT_MODULES = [
  MatOptionModule,
  MatCommonModule,
  MatProgressSpinnerModule,
  MatSelectModule,
  MatLabel,
  MatTabsModule
];

const _MODULES = [
  Dewetra3MapModule,
  Dewetra3InfoModule,
  Dewetra3PropertieModule,
  Dewetra3ChartsModule,
  Dewetra3LegendModule,
  Dewetra3PipesModule,
  Dewetra3LayerEventModule
];


@NgModule({
  declarations: [
  ],
  imports: [
    CommonModule,
    FormsModule,
    CimaCommonsModule,
    ..._MAT_MODULES,
    ..._MODULES
  ],
  exports: [
    ..._MODULES
  ]
})
export class Dewetra3CoreModule { }
