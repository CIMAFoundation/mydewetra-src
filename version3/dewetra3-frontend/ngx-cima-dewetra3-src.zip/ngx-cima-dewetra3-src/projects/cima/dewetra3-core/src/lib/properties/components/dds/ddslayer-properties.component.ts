import { Component, inject, Input } from '@angular/core';
import { MatSelectChange } from '@angular/material/select';
import { TimepickerService, TimepickerValue } from '@cima/commons';
import { differenceInHours, format } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';
import { BehaviorSubject, combineLatest, firstValueFrom, from, Observable, switchMap, tap } from 'rxjs';
import { DDSLayerData, DDSLayerManager, DDSLayerManagerProperties } from '../../../managers/dds/dds.manager';
import { DDSLayerAvailability } from '../../../models/layer-availability';
import { DDSAttribute, DDSLayerProperties } from '../../../models/layer-properties';
import { LayerDataContainer } from '../../../models/models';
import { AvailabilityToGroupedDatesPipe } from '../../pipes/to-grouped-dates.pipe';

@Component({
  selector: 'lib-ddslayer-properties',
  templateUrl: './ddslayer-properties.component.html',
  styleUrls: ['./ddslayer-properties.component.scss'],
})
export class DDSLayerPropertiesComponent {
  @Input() manager!: DDSLayerManager;

  selectedModelDate: any = null;
  selectedReference: any = null;
  groups: [] = null;
  
  properties$: BehaviorSubject<DDSLayerManagerProperties> = new BehaviorSubject<DDSLayerManagerProperties>(null);
  availability$: Observable<DDSLayerAvailability[]>;
  timepickerValue = new BehaviorSubject<TimepickerValue | null>(null);
  loading = false;

  private _timePickerService: TimepickerService = inject(TimepickerService);
  private availabilityToGroupedDatesPipe = new AvailabilityToGroupedDatesPipe();

  private defaultProperties: DDSLayerProperties;

  ngOnInit(): void {
    this._timePickerService.timepickerValue$.subscribe((timepickerValue) => this.timepickerValue.next(timepickerValue));
    this.manager.defaultDDPropertiesRequest().subscribe((properties) => {
      this.defaultProperties = properties as DDSLayerProperties;
    });
    this.manager.getProperties$().subscribe((properties) => {
        this.properties$.next(properties as DDSLayerManagerProperties)
    });

    this.availability$ = this.properties$.asObservable().pipe(
      switchMap((properties: DDSLayerManagerProperties) => {
        const ddsProperties = properties as DDSLayerManagerProperties;
        return from(
          this.manager.getAvailability(ddsProperties.ddsProperties, ddsProperties.dateFrom, ddsProperties.dateTo)
        );
      }),
      tap((availability: DDSLayerAvailability[]) => {
        console.log('availability', availability);
        this.preselectGroupedDates(availability);
      }),
      tap(() => (this.loading = false)),
      tap((availability: DDSLayerAvailability[]) => this.preselectGroupedDates(availability))
    );
  }

  async preselectGroupedDates(availability: DDSLayerAvailability[]) {
    this.groups = this.availabilityToGroupedDatesPipe.transform(availability).modelDates;
    // [TODO] this try to do the same without async/await
    const data = await firstValueFrom(this.manager.getData$());
    const ddsLayerData = data.data as DDSLayerData;
    const lastTwoElements = ddsLayerData.published.layerid.split('_').slice(-2);
    this.selectedModelDate = this.groups.find((g) => g === lastTwoElements[0]);
    this.selectedReference = availability.find((a) => a.id === lastTwoElements.join(';'));
  }

  selectEntry(properties: DDSLayerProperties, attr: DDSAttribute, newEntry: MatSelectChange) {
    // @ts-ignore
    attr.selectedEntry = attr.entries?.find((e) => e.value == newEntry.value);

    const timePickerValue = this.timepickerValue.value;
    if (timePickerValue === null) {
      return;
    }

    this.updateAttributeVisibility(properties);
    const updatedProperties = {
      ...this.properties$.getValue(),
      properties: properties,
    }
    this.properties$.next(updatedProperties);
  }

  updateAttributeVisibility(properties?: DDSLayerProperties) {
    // first, set all attributes to default visibility using the default properties
    const attrs = properties.layerProperties.attributes;
    const defaultAttrs = this.defaultProperties.layerProperties.attributes;
    defaultAttrs.forEach((defaultAttr) => {
      const attr = attrs.find((a) => a.name === defaultAttr.name);
      if (attr) {
        attr.visible = defaultAttr.visible;
      }
    });

    // check for time accumulation
    let timeAccumulate = false;
    
    attrs.forEach((prop) => {
      if (prop.descr === 'Variable') {
        const referredValues = prop.selectedEntry.referredValues;
        const entries = Array.isArray(referredValues.entry) ? referredValues.entry : [referredValues.entry];
        if (entries.length > 0) {
          entries.forEach((entry: any) => {
            if (entry.key === 'cumulate' && entry.value === '1') {
              timeAccumulate = true;
            }
          });
        }
      }
      if (prop.descr === 'Cumulative Range') {
        prop.visible = timeAccumulate ? 'true' : 'false';
      }
    });

    // check for disabled attributes by selected entries defining 'disables'
    // e.g. 'disables=attr1;attr2'
    // if the entry is selected, the corresponding attribute is disabled
    // and the default value is set to this entry
    const disabledAttrs: string[] = [];
    for(let attr of attrs) {
      const entry = attr.selectedEntry?.referredValues?.entry;
      let disablesEntry = null;
      if (!entry) { continue; }
      if (Array.isArray(entry)) {
        // find the entry with key 'disables'
        disablesEntry = entry.find((e: any) => e.key === 'disables');
      } else {
        if (entry.key === 'disables') {
          disablesEntry = entry;
        }
      }

      if(disablesEntry){
        const toBeDisabled = disablesEntry.value.split(';');
        toBeDisabled.forEach(d => disabledAttrs.push(d));
      }
    }

    // set the visibility of the attributes to false if they are in the disabledAttrs array
    attrs.forEach((attr) => {
      if (disabledAttrs.includes(attr.name)) {
        attr.visible = 'false';

        //[TODO] Ugly workaround to set the default value of the attribute to the selected entry
        // this is needed because the backends does not set the default flag to the entries
        // the feature should be implemented in the acroweb library (acroweb3/dds/client_2.py)
        const entry = this.defaultProperties.layerProperties.attributes.find((a) => a.name === attr.name).selectedEntry;
        if (entry) {
          attr.selectedEntry = entry;
        }
      } 
    });
  }

  async publishLayer(ddsProps: DDSLayerProperties, item: DDSLayerAvailability) {
    const timePickerValue = this.timepickerValue.value;
    if (timePickerValue === null) {
      return;
    }

    const dateFrom = timePickerValue.from;
    const dateTo = timePickerValue.to === 'now' ? new Date() : timePickerValue.to;

    const movieAllowed = await this.manager.movieAllowed(ddsProps);

    const properties = {
      ddsProperties: ddsProps,
      item: item,
      dateFrom,
      dateTo,
      isMovieAllowed: movieAllowed,
    };

    this.manager.applyProperties(properties);
  }

  formattedRunDate(dateString: string) {
    if (!dateString) {
      return '';
    }
    const date = new Date(parseInt(dateString));
    return date ? format(toZonedTime(date, 'UTC'), 'dd/MM/yyyy HH:mm ') + '(UTC)' : '';
  }

  formatDDSEntry(entry: DDSLayerAvailability) {
    if (!entry) {
      return '';
    }

    const dateRef = new Date(parseInt(entry.date));
    const runDate = new Date(parseInt(entry.id.split(';')[0]));

    const distance = differenceInHours(dateRef, runDate);

    return entry.date
      ? format(toZonedTime(new Date(entry.date), 'UTC'), 'dd/MM/yyyy HH:mm') + ' (UTC) ( +' + distance + ' hours )'
      : entry.description;
  }
}
