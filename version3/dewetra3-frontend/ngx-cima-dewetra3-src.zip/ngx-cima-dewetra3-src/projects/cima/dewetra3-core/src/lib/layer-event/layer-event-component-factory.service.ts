import { Injectable } from '@angular/core';
import { LayerModel } from '../models/dewetra3-layer';
import { SENTINELInfoComponent } from './sentinel/sentinel-info.components';
import { WARNINGSInfoComponent } from './sentinel/warnings-info.components';
import { SERIEInfoComponent } from './serie/serie-info.components';


@Injectable({
  providedIn: 'root'
})
export class LayerEventComponentFactory {
  static DEFAULT_COMPONENTS = {
    'SENTINELInfoComponent': SENTINELInfoComponent,
    'WARNINGSInfoComponent': WARNINGSInfoComponent,
    'SERIEInfoComponent': SERIEInfoComponent,
  };

  private _registry: Map<string, any> = new Map(Object.entries(LayerEventComponentFactory.DEFAULT_COMPONENTS))

  constructor() { }

  set(name: string, component: any) {
    this._registry.set(name, component);
  }

  create(layerModel: LayerModel): any {
    const klass = this._registry.get(layerModel.infomanager.component);
    return klass;
  }
}
