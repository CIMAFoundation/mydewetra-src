import { Injectable } from '@angular/core';
import { LayerModel } from '../models/dewetra3-layer';
import { DDSLayerPropertiesComponent } from './components/dds/ddslayer-properties.component';
import { SENTINELWarningsPluviometerPropertiesComponent } from './components/sentinel/warnings-pluviometer-properties.component';
import { DDSLayerObservationPropertiesComponent } from './components/dds-observation/ddslayer-observation-properties.component';
import { SENTINELPropertiesComponent } from './components/sentinel/sentinel-properties.component';


@Injectable({
  providedIn: 'root'
})
export class PropertiesComponentFactory {
  static DEFAULT_PROPERTIES_COMPONENTS = {
    'DDSLayerPropertiesComponent': DDSLayerPropertiesComponent,
    'DDSLayerObservationPropertiesComponent': DDSLayerObservationPropertiesComponent,
    // 'WMSTLayerPropertiesComponent': WMSTLayerPropertiesComponent,
    'SENTINELLayerPropertiesComponent': SENTINELPropertiesComponent,
    'SENTINELWarningsPluviometerPropertiesComponent': SENTINELWarningsPluviometerPropertiesComponent,
  };

  private _registry: Map<string, any> = new Map(Object.entries(PropertiesComponentFactory.DEFAULT_PROPERTIES_COMPONENTS))

  constructor() { }

  set(name: string, component: any) {
    this._registry.set(name, component);
  }

  create(layerModel: LayerModel): any {
    const klass = this._registry.get(layerModel.propertiesmanager.component);
    return klass;
  }
}
