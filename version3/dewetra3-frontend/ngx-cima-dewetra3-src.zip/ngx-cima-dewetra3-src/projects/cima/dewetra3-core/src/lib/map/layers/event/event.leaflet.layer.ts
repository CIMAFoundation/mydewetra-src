import * as L from "leaflet";
import { BaseMapInfoResult } from "../../../models/models";
import { LayerDataContainer } from "../../../models/models";
import { BaseLayer } from "../base/base.layer";
import { CustomWMSParams } from "../../../models/leaflet";

export class EventLayerLeaflet extends BaseLayer {
  private wmsLayer: L.TileLayer.WMS;

  bringToFront(): void {
    this.wmsLayer?.bringToFront();
  }

  bringToBack(): void {
    this.wmsLayer?.bringToBack();
  }

  override async updateMapLayer(data: LayerDataContainer): Promise<void> {
    if (this.wmsLayer) {
      this.map?.removeLayer(this.wmsLayer);
    }
    const layerModel = this.layer.getLayerModel();
    const layerId = layerModel?.dataid;
    this.wmsLayer = L.tileLayer.wms(layerModel.server.url, {
      layers: layerId,
      format: 'image/png',
      transparent: true,
      opacity: 1,
    });
    this.map?.addLayer(this.wmsLayer);
  }

  _remove(): void {
    this.map?.removeLayer(this.wmsLayer);
  }

  setOpacity(opacity: number): void {
    this.wmsLayer?.setOpacity(opacity);
  }

  setVisible(visible: boolean): void {
    if (this.wmsLayer === undefined) {
      return;
    }
    if (visible) {
      this.map?.addLayer(this.wmsLayer);
    } else {
      this.map?.removeLayer(this.wmsLayer);
    }
  }

  override getBounds(): L.LatLngBounds {
    const model = this.layer.getLayerModel();
    const latn = model.latn || 90;
    const lonw = model.lonw || -180;
    const lats = model.lats || -90;
    const lone = model.lone || 180;
    return L.latLngBounds(L.latLng(latn, lonw), L.latLng(lats, lone));
  }

}
