import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatCommonModule, MatOptionModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { CimaCommonsModule } from '@cima/commons';
import { DynamicModule } from 'ng-dynamic-component';
import { DDSLayerPropertiesComponent } from './components/dds/ddslayer-properties.component';
import { PropertiesWrapperComponent } from './components/wrapper/properties-wrapper.component';
import { FilterByModelDatePipe } from './pipes/filter-by-model-date.pipe';
import { FilterByPropertyPipe } from './pipes/filter-by-property.pipe';
import { AvailabilityToGroupedDatesPipe } from './pipes/to-grouped-dates.pipe';
import { MatLabel, MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { SENTINELWarningsPluviometerPropertiesComponent } from './components/sentinel/warnings-pluviometer-properties.component';
import { SENTINELPropertiesComponent } from './components/sentinel/sentinel-properties.component';
import { DDSLayerObservationPropertiesComponent } from './components/dds-observation/ddslayer-observation-properties.component';


const _MAT_MODULES = [
  MatOptionModule,
  MatCommonModule,
  MatProgressSpinnerModule,
  MatSelectModule,
  MatLabel,
  MatTabsModule
];

const _COMPONENTS = [
  PropertiesWrapperComponent,
  DDSLayerPropertiesComponent,
  DDSLayerObservationPropertiesComponent,
  SENTINELPropertiesComponent,
  SENTINELWarningsPluviometerPropertiesComponent,
  FilterByModelDatePipe,
  FilterByPropertyPipe,
  AvailabilityToGroupedDatesPipe,
];


@NgModule({
  declarations: _COMPONENTS,
  imports: [
    CommonModule,
    DynamicModule,
    CimaCommonsModule,
    ..._MAT_MODULES
  ],
  exports: _COMPONENTS

})
export class Dewetra3PropertieModule { }


