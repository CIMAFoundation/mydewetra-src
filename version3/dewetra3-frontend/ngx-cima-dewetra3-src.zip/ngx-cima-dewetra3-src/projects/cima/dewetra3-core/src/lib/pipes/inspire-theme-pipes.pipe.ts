import { Pipe, PipeTransform } from '@angular/core';
import { LayerModel, LayerInspireTheme } from '../models/dewetra3-layer';

@Pipe({
  name: 'inspireThemePipes'
})
export class InspireThemePipesPipe implements PipeTransform {

  transform(layers: LayerModel[], args: LayerInspireTheme[]): LayerModel[] {
    if (layers && layers.length >= 0 && args && args.length > 0) {
      layers = layers.filter((layer: LayerModel) => {
        const argsId = args.map((theme: LayerInspireTheme) => theme.id);
        const inspireThemesId = layer.inspirethemes?.map((theme: LayerInspireTheme) => theme.id);
        return inspireThemesId.some((id) => argsId.includes(id));
      });
      return layers as LayerModel[];
    } else {
      //console.log('InspireThemePipesPipe: no layers or no args', layers, args)
      return layers as LayerModel[];
    }

  }
}
