export interface SentinelResponse {
  crs: CRS;
  features: SentinelFeature[];
  type: string;
}

export interface CRS {
  properties: Properties;
  type: string;
}

export interface Properties {
  name: string;
}


export interface Feature {
  geometry: Geometry;
  properties: { [key: string]: number[] | number | null | string };
  type: FeatureType;
}

export interface Geometry {
  coordinates: number[];
  type: GeometryType;
}

export enum GeometryType {
  Point = "Point",
}

export enum FeatureType {
  Feature = "Feature",
}

export interface SentinelFeature {
  geometry: Geometry;
  properties: SentinelFeatureProperties;
  type: FeatureType;
}

export interface Event {
  dateRef: string;
  db: number;
  id: number;
  lastValue: number;
  /** Data di overflow (uguale a dateRef in questo caso) */
  overflowDatetime: string;
  overflowValue: number;
  /** Periodo di campionamento in secondi */
  period: number;
  sensor: number;
  sensorClass: number;
  /** Gruppo del sensore, es. "Dewetra%Default" */
  sensorGroup: string;
  severity: number;
  station: number;
  thrId: number;
  thresholdGroup: string;
  thresholdName: string;
  thresholdType: string; // potresti sostituirlo con 'max'|'min' ecc.
  thresholdValue: number;
  ts: string;
}

export interface SentinelFeatureProperties {
  seriestate?: string
  stid: number
  st: string
  nthr: number
  e: SentinelExceedingFeatureProperties[]
  s: number
  v: SentinelValueFeatureProperties[]
  db: number
  mu: string
  aggr?: Aggregations
  severity?: number
  event?: Event
  values?: SentinelValueFeatureProperties[]// only for aggregated
}

export interface SentinelFeaturePropertiesUpdate {
  s: number
  db: number
  e: SentinelExceedingFeatureProperties[]
  v: SentinelValueFeatureProperties[]
}

export interface SentinelExceedingFeatureProperties {
  v: number,
  t: number,
  id: number,
  name: string,
  sev: number,

}

export interface SentinelValueFeatureProperties {
  v: number,
  t: number,
  p: number,
  a: string,
}

// merged values and exceeding
export interface SentinelValueAndExceedingMergedData {
  type?: string;
  value?: number;
  timestamp_e?: number;
  timestamp_v?: number;
  sevName?: string;
  thr_id?: number;
  sev?: number;
}

export interface SentinelSensorInfoResponse {
  mergedId: number
  sensorId: number
  dbId: number
  classId: string;
  stationId: number
  stationName: string
  stationSupplierId: number
  stationSupplierName: string
  sensorDescr: string
  measureUnit: MeasureUnit
  lon: number
  lat: number
  aggregations: Aggregations
  groups: string[]
}

export interface MeasureUnit {
  name: string
}

export interface Aggregations {
  catchments_it: string[]
  municipalities_it_topoieti: string[]
  regions_it: string[]
  municipalities_it: string[]
  warningareas_it: string[]
  districts_it: string[],

  [key: string]: any[];
}


// INTERFACE FOR SENTINEL SENSORS
export interface CustomPropertiesSentinelSensor {
  default: LegendTypeSentinelSensor
}

export interface LegendTypeSentinelSensor {
  legend: LegendItemSentinelSensor[]
}

export interface LegendItemSentinelSensor {
  mu: string
  dec: number
  sign: string
  color: string
  label: string
  value: number[]
  textcolor: string
  color_rgba: string
}


// INTERFACE FOR WARNINGS
export interface CustomPropertiesWarnings {
  default: LegendTypeWarnings
}

export interface LegendTypeWarnings {
  legend: LegendItemWarnings[]
}

export interface LegendItemWarnings {
  name: string
  type: string
  color: string
  fillColor: string
  descr: number
  label: string
  radius: number
  weight: number
  opacity: number
  severity: number
  fillOpacity: number
}

