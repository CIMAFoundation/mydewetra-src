import { Component, Input } from '@angular/core';
import { Observable } from 'rxjs';
import { DDSLayerManager } from '../../../managers/dds/dds.manager';
import { Dewetra3MapClick } from '../../../models/models';

@Component({
  selector: 'dewetra3-ddslayer-info',
  template: `
    <div *ngIf="manager">
      <h4 class="mb-1">{{ manager.getName() }}</h4>

      <span *ngIf="infoEvents$ | async as info">
        <!-- Timestamp generale, se ti serve -->
        <!--
    <strong *ngIf="info?.wmsData?.timeStamp">
      {{ parseTimeStamp(info.wmsData.timeStamp) }}
    </strong>
    -->

        <!-- Ciclo su tutte le feature -->
        <div class="mt-2" *ngIf="info?.wmsData?.features as features">
          <div *ngFor="let feat of features; let idx = index" class="feature-block mb-3">
            <!-- <h5>Feature {{ idx + 1 }} ({{ feat.geometry.type }})</h5> -->

            <ng-container *ngIf="feat.properties as props">
              <!-- Valore principale -->
              <div>
                <span *ngIf="props.GRAY_INDEX !== undefined || props.VALUE !== undefined" class="label me-2"
                  >{{ 'DEWETRA3CORE.VALUE' | translate }}:</span
                >
                <span *ngIf="props.GRAY_INDEX !== undefined">
                  {{ parseValue(props.GRAY_INDEX) }}
                  {{ manager.getSelectedVariableMeasureUnit$() | async }}
                </span>
                <span *ngIf="props.GRAY_INDEX === undefined && props.VALUE !== undefined">
                  {{ parseValue(props.VALUE) }}
                  {{ manager.getSelectedVariableMeasureUnit$() | async }}
                </span>
              </div>

              <!-- Tutte le altre proprietà -->
              <div class="mt-2">
                <span class="label me-2">{{ 'DEWETRA3CORE.OTHER_PROPERTIES' | translate }}:</span>
                <ul class="ps-3">
                  <li *ngFor="let entry of getAdditionalProperties(props, ['GRAY_INDEX', 'VALUE'])">
                    <strong>{{ entry[0] | translate }}:</strong> {{ entry[1] }}
                  </li>
                </ul>
              </div>
              
            </ng-container>
          </div>
        </div>
      </span>
    </div>
  `,
  styles: ['.label { font-weight: bold; color: var(--dewetra-orange); }', 'ul {list-style-type: disc;}'],
})
export class DDSLayerInfoComponent {
  @Input() manager!: DDSLayerManager;
  @Input() infoEvents$!: Observable<any>;
  @Input() clickData: Dewetra3MapClick;

  parseTimeStamp(timeStamp: string): string {
    return new Date(timeStamp).toLocaleString();
  }

  parseValue(value: number): string {
    return value.toFixed(2).toString();
  }

  getAdditionalProperties(props: Record<string, any>, excludeKeys: string[] = []): [string, any][] {
    return Object.entries(props).filter(([key, value]) => !excludeKeys.includes(key));
  }
}
