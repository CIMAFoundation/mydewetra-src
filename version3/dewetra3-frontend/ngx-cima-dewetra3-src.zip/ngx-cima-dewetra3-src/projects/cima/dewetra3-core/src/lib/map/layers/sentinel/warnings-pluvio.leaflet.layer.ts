import * as L from 'leaflet';
import { BaseDewetra3LayerEventData, Dewetra3LayerEventWithData } from '../../../managers/base/base.manager';
import { SENTINELLayerData } from '../../../managers/sentinel/sentinel.manager';
import { WARNINGSLayerManagerProperties } from '../../../managers/sentinel/warnings.manager';
import { LayerDataContainer } from '../../../models/models';
import { CustomPropertiesWarnings, SentinelFeature } from '../../../models/sentinel';
import { extractPeriodInSeconds, getLayerMapProperties } from '../../../utils/utils';
import { BaseLayer } from '../base/base.layer';

interface WarningsPluvioLayerEventData extends BaseDewetra3LayerEventData {
  feature: any;
}

interface LegendItem {
  name: string;
  type: string;
  color: string;
  descr: number;
  label: string;
  radius: number;
  weight: number;
  opacity: number;
  severity: number;
  fillColor: string;
  fillOpacity: number;
}

export class WarningsPluvioLayerLeaflet extends BaseLayer {
  private featureLayer: L.GeoJSON;

  private LayerModel = this.layer.getLayerModel();

  override bringToFront(): void {
    this.featureLayer?.bringToFront();
  }
  override bringToBack(): void {
    this.featureLayer?.bringToBack();
  }
  override async updateMapLayer(data: LayerDataContainer): Promise<void> {
    const dataLayer = data.data as SENTINELLayerData;
    const properties = data.properties as WARNINGSLayerManagerProperties;

    if (this.featureLayer) {
      this.map.removeLayer(this.featureLayer);
    }

    console.log('updateMapLayer:', this.layer.getName());

    this.featureLayer = L.geoJSON(dataLayer.sentinelResponse, {
      filter: (feature) => {
        return this.featureFilter(feature as SentinelFeature, properties);
      },

      pointToLayer: (feature, latLng) => {
        return this.returnMarker(feature as SentinelFeature, latLng, properties);
      },
      onEachFeature: (feature, layer) => {
        layer.on({
          click: (evt) => this.emitLayerEvent('click', evt.target.feature),
          mouseover: (evt) => this.emitLayerEvent('mouseover', evt.target.feature),
          mouseout: (evt) => this.emitLayerEvent('mouseout', evt.target.feature),
        });
        this.styler(feature as SentinelFeature, layer, properties);
      },
    });

    this.featureLayer.eachLayer((layer: L.Layer) => {
      this.featureInFront(layer);
    });

    this.map?.addLayer(this.featureLayer);
  }

  private emitLayerEvent(type: 'click' | 'mouseover' | 'mouseout', feature: any) {
    if (type === 'mouseover' && feature.geometry.type === 'MultiPolygon') return;

    const data: WarningsPluvioLayerEventData = { feature };
    const event = { type, layer: this.layer, data } as Dewetra3LayerEventWithData;
    this.onLayerEvent.emit(event);
  }

  override _remove(): void {
    if (!this.map || !this.featureLayer) return;
    this.map?.removeLayer(this.featureLayer);
  }

  override setOpacity(opacity: number): void {
    this.featureLayer?.setStyle({ opacity, fillOpacity: opacity });
  }

  override setVisible(visible: boolean): void {
    if (!this.map || !this.featureLayer) return;
    if (visible) {
      this.map?.addLayer(this.featureLayer);
    } else {
      this.map?.removeLayer(this.featureLayer);
    }
  }

  featureInFront(layer: L.Layer) {
    //@ts-ignore
    if (layer?.feature?.properties?.e && layer?.feature?.properties?.e.length > 0) {
      //@ts-ignore
      layer?.bringToFront();
    } else {
      //@ts-ignore
      layer?.bringToBack();
    }
  }

  featureFilter(feature: SentinelFeature, properties: WARNINGSLayerManagerProperties) {
    if (feature?.geometry?.type !== 'Point') return true;

    const customProperties = getLayerMapProperties(this.layer.getLayerModel()) as CustomPropertiesWarnings;
    if (!feature.properties || !feature.properties.v || feature.properties.v.length == 0) {
      return false;
    }
    if (!feature.properties || !feature.properties.e) {
      return false;
    }
    let values = feature.properties.v;
    let exceedings = feature.properties.e;
    let maximumTemporalAggregation = parseInt(properties.maximumTemporalAggregationSelected);
    let minimumExceeding = parseInt(properties.minimumExceedingSelected);

    if (minimumExceeding === 0) {
      return true;
    }

    return (
      exceedings.filter(
        (e) => e.sev >= minimumExceeding && extractPeriodInSeconds(e.name.split('_')[2]) <= maximumTemporalAggregation
      ).length > 0
    );
  }

  returnMarker(feature: SentinelFeature, latlng: L.LatLng, properties: WARNINGSLayerManagerProperties) {
    return L.circleMarker(latlng);
  }

  styler(feature: SentinelFeature, layer: L.Layer, properties: WARNINGSLayerManagerProperties) {
    if (feature.geometry.type === 'Point') {
      this.pointStyle(feature, layer, properties);
    } else {
      this.featureStyle(feature, layer, properties);
    }
  }

  pointStyle(feature: SentinelFeature, layer: L.Layer, properties: WARNINGSLayerManagerProperties) {
    const customProperties = getLayerMapProperties(this.layer.getLayerModel()) as CustomPropertiesWarnings;

    let markerProperties = customProperties.default.legend[0];

    //check if feature has v and v is an array with at least one element or return a circle marker gray
    if (!feature?.properties?.v || !feature?.properties?.v?.length) {
      //@ts-ignore
      return layer.setStyle(markerProperties);
    }

    let values = feature.properties.v;
    let exceedings = feature.properties.e;
    let maximumTemporalAggregation = parseInt(properties.maximumTemporalAggregationSelected);
    // let minimumExceeding =  parseInt(properties.minimumExceedingSelected);
    values = values.filter((v) => v.p <= maximumTemporalAggregation);
    exceedings = exceedings.filter((e) => {
      let hours = parseInt(e.name.split('_')[2].replace('h', '')) * 60 * 60;
      return hours <= maximumTemporalAggregation;
    });

    if (exceedings.length == 0) {
      // no exceedings found but there are values
      let maxValue = values.reduce((prev, current) => (prev.v > current.v ? prev : current));
      if (maxValue.v > 0) {
        markerProperties = customProperties.default.legend[2];
      } else {
        markerProperties = customProperties.default.legend[1];
      }
    } else {
      //get the highest severity
      let maxSeverity = exceedings.reduce((prev, current) => (prev.sev > current.sev ? prev : current));
      let legendItem = customProperties.default.legend.filter((legend) => legend.severity == maxSeverity.sev)[0];
      markerProperties = legendItem;
    }

    //@ts-ignore
    layer.setStyle(markerProperties);
  }

  featureStyle(feature: SentinelFeature, layer: L.Layer, properties: WARNINGSLayerManagerProperties) {
    const customProperties = getLayerMapProperties(this.layer.getLayerModel()) as CustomPropertiesWarnings;
    let featureProperties: LegendItem = customProperties?.default?.legend[0]; // gray color
    if (!feature?.properties?.values || feature?.properties?.values?.length == 0) {
      //@ts-ignore
      layer.setStyle(featureProperties);
      return;
    }
    if (feature?.properties?.severity >= 0) {
      featureProperties = customProperties?.default?.legend.filter(
        (legend) => legend?.severity == feature?.properties?.severity
      )[0]; //severity color
    } else {
      const haveRain = feature?.properties?.values.filter((value) => value.v > 0);
      if (haveRain && haveRain.length > 0) {
        featureProperties = customProperties?.default?.legend[2]; //rain -  green color
      } else {
        featureProperties = customProperties?.default?.legend[1]; //no rain - white color
      }
    }

    //@ts-ignore
    layer.setStyle({
      color: featureProperties.fillColor,
      fillColor: featureProperties.fillColor,
      fillOpacity: featureProperties.fillOpacity,
      opacity: featureProperties.opacity,
      weight: featureProperties.weight,
    });
  }

  override getBounds(): L.LatLngBounds {
    return this.featureLayer?.getBounds();
  }
}
