import { Component, inject, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { BehaviorSubject, combineLatest, filter, switchMap } from 'rxjs';
import { Dewetra3LayerEvent, Dewetra3LayerEventWithData } from '../../../managers/base/base.manager';
import { ChartComponentFactory } from '../../chart-component-factory.service';

@Component({
  selector: 'dewetra3-series-chart-wrapper',
  template: `
    @if (component) { @if (chartEvents$ | async; as chartEvent) { @if (chartEvent.status === 'loaded') {
    <ndc-dynamic
      [ndcDynamicComponent]="component"
      [ndcDynamicInputs]="{ clickData, chartEvents$, dateFrom, dateTo}"
    ></ndc-dynamic>
    } @else if (chartEvent.status === 'error') {
    <div class="alert alert-danger" role="alert">
      {{ chartEvent.error }}
    </div>
    } @else if (chartEvent.status === 'loading') {
    <!--<span>LOADING</span>-->
    <div class="w-100 h-100 d-flex justify-content-center align-items-center flex-column">
      <mat-spinner></mat-spinner>
      <div class="my-2">{{ 'DEWETRA3CORE.LOADING' | translate }}...</div>
    </div>
    } } @else {
    <div class="w-100 h-100 d-flex justify-content-center align-items-center flex-column">
      <mat-spinner></mat-spinner>
      <div class="my-2">{{ 'DEWETRA3CORE.WAITING_FOR_DATA' | translate }}...</div>
    </div>
    } } @else {
    <span>{{ 'DEWETRA3CORE.COMPONENT_NOT_DEFINED' | translate }}</span>
    }
  `,
  styleUrls: [],
})
export class SeriesChartWrapperComponent implements OnInit {
  private dateFrom$ = new BehaviorSubject<Date | null>(null);

  private _translateService: TranslateService = inject(TranslateService);
  private _chartFactory: ChartComponentFactory = inject(ChartComponentFactory);

  @Input() set dateFrom(date: Date) {
    this.dateFrom$.next(date);
  }

  get dateFrom() {
    return this.dateFrom$.getValue();
  }

  private dateTo$ = new BehaviorSubject<Date | null>(null);

  @Input() set dateTo(date: Date) {
    this.dateTo$.next(date);
  }

  get dateTo() {
    return this.dateTo$.getValue();
  }

  private event = new BehaviorSubject<Dewetra3LayerEventWithData | null>(null);

  @Input() set clickData(eventData: Dewetra3LayerEvent) {
    if (eventData.type !== 'click') {
      return;
    }
    this.event.next(eventData);
  }

  public get clickData() {
    return this.event.getValue();
  }

  public chartEvents$ = combineLatest([this.event, this.dateFrom$, this.dateTo$]).pipe(
    filter(([eventData, dateFrom, dateTo]) => !!eventData && !!dateFrom && !!dateTo),
    switchMap(([eventData, dateFrom, dateTo]) => eventData.layer.getSeries$(eventData.data, dateFrom, dateTo))
  );
  public component!: any;

  ngOnInit(): void {
    this.component = this._chartFactory.create(this.event.getValue().layer.getLayerModel());
  }
}
