import {Component, Input} from '@angular/core';
import {BaseLayerManager} from '../../../managers/base/base.manager';

@Component({
  selector: 'dewetra3-geoserver-legend',
  template: `
    <div class="legend">
      <div class="legend-title"></div>
      <div class="legend-content">
        <img
          src="{{manager.getLayerModel().server.url}}?service=WMS&request=GetLegendGraphic&format=image/png&width=20&height=20&layer={{manager.getLayerModel().dataid}}"
          alt="{{'DEWETRA3APP.LEGENDA' | translate}}"/>
      </div>
    </div>
  `,
  styleUrls: [],
})
export class GeoserverLegendComponent {

  @Input() manager!: BaseLayerManager;

  constructor() {

  }
}
