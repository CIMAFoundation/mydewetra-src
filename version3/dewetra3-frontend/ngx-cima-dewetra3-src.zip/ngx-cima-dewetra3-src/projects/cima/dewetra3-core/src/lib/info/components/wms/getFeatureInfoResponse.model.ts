export interface GetFeatureInfoResponse {
  wmsData: WmsData
  latLng: LatLng
}

export interface WmsData {
  type: string
  features: Feature[]
  totalFeatures: string
  numberReturned: number
  timeStamp: string
  crs: Crs
}

export interface Feature {
  type: string
  id: string
  geometry: Geometry
  geometry_name: string
  properties: Properties
}

export interface Geometry {
  type: string
  coordinates: number[][][][]
}

export interface Properties {
  fid: number
  COD_RIP: number
  COD_REG: number
  DEN_REG: string
  Shape_Leng: number
  Shape_Area: number
}

export interface Crs {
  type: string
  properties: Properties2
}

export interface Properties2 {
  name: string
}

export interface LatLng {
  lat: number
  lng: number
}
