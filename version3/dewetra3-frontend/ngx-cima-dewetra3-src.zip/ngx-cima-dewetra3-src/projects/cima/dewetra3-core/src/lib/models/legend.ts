export interface DewapiLayerStyleResponse {
  legend: Legend[]
}

export interface Legend {
  color: string
  quantity: string
  opacity: string
  label: string
}
