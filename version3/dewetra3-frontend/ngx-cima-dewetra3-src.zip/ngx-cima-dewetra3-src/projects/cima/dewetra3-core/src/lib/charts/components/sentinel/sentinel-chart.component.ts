import {AfterViewInit, Component, Input} from '@angular/core';
import {MatTabChangeEvent} from '@angular/material/tabs';
import * as Plotly from 'plotly.js-dist-min';
import {Observable, tap} from 'rxjs';
import {filter, map, startWith, switchMap} from 'rxjs/operators';
import * as uiid from 'uuid';
import {
  SENTINELGetSeriesResult,
  SENTINELLayerManager,
  SENTINELSerieResultData,
  SENTINELSerieResultDataAggregatedFeature
} from '../../../managers/sentinel/sentinel.manager';
import {Dewetra3LayerCommonEvent} from '../../../managers/base/base.manager';


@Component({
  selector: 'sentinel-chart',
  template: `
    @if (loadingChart$ | async) {
      <div>
        {{ 'DEWETRA3CORE.WAITING_FOR_DATA' | translate }}...
      </div>
      <div class="w-100 h-100 d-flex justify-content-center align-items-center flex-column">
        <mat-progress-bar mode="indeterminate"></mat-progress-bar>
      </div>
    }

    @switch (seriesResult?.type) {
      @case ('chart') {
        <div class="d-flex justify-content-between align-items-center p-2">
          <div>
            <span class="fw-bold"> {{ seriesResultData?.sensorInfo?.stationName }} </span>
            <span class="text-muted"> {{ seriesResultData?.sensorInfo?.stationSupplierName }} </span>
          </div>
        </div>
        <mat-tab-group (selectedTabChange)="onTabChange($event)" [selectedIndex]="selectedIndex">
          @for (sensor of getSerieResultDataForStation().stationSensor; track $index) {
            <mat-tab [label]="sensor.sensorDescr"></mat-tab>
          }
        </mat-tab-group>
      }
      @case ('table') {
        <div>
          <warnings-pluvio-aggregated-table [clickData]="clickData"
                                            [sensors]="getSerieResultDataForAggregatedFeature().sensors"></warnings-pluvio-aggregated-table>
        </div>
      }
      @default {
        <!--          <div>
                    {{ 'DEWETRA3CORE.NO_DATA' | translate }}
                  </div>-->
      }
    }
    <div class="p-2">
      <div [id]="chartId" class="rounded-2 chart-wrapper overflow-hidden"></div>
    </div>
  `,
  styles: ['.chart-wrapper {height: calc(100vh - 300px);}', '.chart-wrapper {width: 100%;}']
})
export class SENTINELChartComponent implements AfterViewInit {
  @Input() clickData: Dewetra3LayerCommonEvent;
  @Input() chartEvents$!: Observable<SENTINELGetSeriesResult>;
  @Input() dateFrom!: Date;
  @Input() dateTo!: Date;

  public chartId = uiid.v4();
  public loadingChart$!: Observable<boolean>;
  public seriesResult: SENTINELGetSeriesResult = null;
  public seriesResultData: SENTINELSerieResultData = null;
  public selectedIndex = 0;

  onTabChange(event: MatTabChangeEvent) {
    this.loadChartBySensor(this.getSerieResultDataForStation().stationSensor[event.index]);
  }

  async plotChart(chart: any) {
    await Plotly.purge(this.chartId);

    if (!chart.layout) {
      chart.layout = {};
    }
    chart.layout.autosize = true;

    const config = {responsive: true};


    return await Plotly.newPlot(this.chartId, chart.data, chart.layout, config);
  }

  async loadChartBySensor(sensor: any) {
    const layer = this.clickData.layer as SENTINELLayerManager;
    const data = await layer.loadChartBySensor('json', sensor, this.dateFrom, this.dateTo)
    await this.plotChart(data);
  }

  setTabIndex() {
    this.selectedIndex = this.getSerieResultDataForStation().stationSensor.findIndex((sensor: any, i: number) => sensor.sensorDescr === this.getSerieResultDataForStation().sensorInfo.sensorDescr);
  }

  getSerieResultDataForStation() {
    return this.seriesResult.data as SENTINELSerieResultData;
  }

  getSerieResultDataForAggregatedFeature() {
    return this.seriesResult.data as SENTINELSerieResultDataAggregatedFeature;
  }

  ngAfterViewInit(): void {

    this.loadingChart$ = this.chartEvents$.pipe(
      filter(data => !!data && data.status === 'loaded'),
      switchMap(async (data) => {// .chart .info .station | sensors
        this.seriesResult = data;
        this.seriesResultData = this.seriesResult.data as SENTINELSerieResultData;
        if (this.seriesResult.type === 'chart') {
          const done = await this.plotChart((this.seriesResult.data as SENTINELSerieResultData).chart);
          this.setTabIndex();
        }
      }),
      map(() => false),
      startWith(true)
    )
  }
}

