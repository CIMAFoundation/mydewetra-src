import { Component, Input } from '@angular/core';
import { BaseLayerManager } from '../../managers/base/base.manager';


@Component({
  selector: 'not-enabled-chart',
  template: `
      <div>
        <h2>{{manager.getLayerModel()?.chartmanager?.props?.title | translate}}</h2>
        <p>
          {{manager.getLayerModel()?.chartmanager?.props?.description | translate}}
        </p>
      </div>
  `,
  styles: ['']
})
export class NotEnabledChartComponent {
  @Input() manager: BaseLayerManager;

  public component!: any;

}
