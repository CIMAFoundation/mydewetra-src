import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LinkMetadataComponent } from './component/link/link-metadata.component';



@NgModule({
  declarations: [
    LinkMetadataComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    LinkMetadataComponent
  ]
})
export class MetadataModule { }
