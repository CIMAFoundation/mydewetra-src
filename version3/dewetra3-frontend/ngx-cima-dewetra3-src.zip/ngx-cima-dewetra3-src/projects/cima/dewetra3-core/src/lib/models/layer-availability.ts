import { DDSLayerProperties } from './layer-properties';

export interface DDSLayerAvailabilityRequest {
  props?: DDSLayerProperties;
  from: number;
  to: number;
}

export interface DDSLayerAvailability {
  date: string;
  description: string;
  id: string;
}

export interface DDSLayerPublishRequest {
  props?: DDSLayerProperties;
  data?: DDSLayerAvailability;
  from: number;
  to: number;
}

export interface DDSLayerPublishResponse {
  layerid: string;
  layertype: 'VECTOR' | 'RASTER';
}

export interface DDSLayerPublishResponseMovieMessage extends DDSLayerPublishResponse {
  status?: 'completed';
  item: DDSLayerAvailability;
}
