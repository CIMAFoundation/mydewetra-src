import { AfterViewInit, Component, Input } from '@angular/core';
import { BehaviorSubject, forkJoin, map } from 'rxjs';
import { SENTINELAggreWithouGeom, SENTINELLayerManager } from '../../../../managers/sentinel/sentinel.manager';
import { WARNINGSLayerManager, WARNINGSLayerManagerProperties } from '../../../../managers/sentinel/warnings.manager';

import { getLayerMapProperties } from 'projects/cima/dewetra3-core/src/public-api';
import { Dewetra3LayerCommonEvent } from '../../../../managers/base/base.manager';
import {
  CustomPropertiesSentinelSensor,
  SentinelFeature,
  SentinelValueFeatureProperties,
} from '../../../../models/sentinel';

@Component({
  selector: 'sentinel-aggregated-table',
  template: `
    <table>
      <thead>
        <tr>
          <th>Stazione</th>
          <th>Comuni (Topoieti)</th>
          <th>15 Minuti</th>
          <th>30 Minuti</th>
          <th>1 Ora</th>
          <th>3 Ore</th>
          <th>6 Ore</th>
          <th>12 Ore</th>
          <th>18 Ore</th>
          <th>24 Ore</th>
          <th>36 Ore</th>
        </tr>
      </thead>
      <tbody>
        @for(raw of matrix$| async; track raw) {
        <tr>
          <td>{{ raw['st'] }}</td>
          <td>{{ raw['municList'] }}</td>
          <td [ngStyle]="raw['900']['color']">{{ raw['900']['value'] }}</td>
          <td [ngStyle]="raw['1800']['color']">{{ raw['1800']['value'] }}</td>
          <td [ngStyle]="raw['3600']['color']">{{ raw['3600']['value'] }}</td>
          <td [ngStyle]="raw['10800']['color']">{{ raw['10800']['value'] }}</td>
          <td [ngStyle]="raw['21600']['color']">{{ raw['21600']['value'] }}</td>
          <td [ngStyle]="raw['43200']['color']">{{ raw['43200']['value'] }}</td>
          <td [ngStyle]="raw['64800']['color']">{{ raw['64800']['value'] }}</td>
          <td [ngStyle]="raw['86400']['color']">{{ raw['86400']['value'] }}</td>
          <td [ngStyle]="raw['129600']['color']">{{ raw['129600']['value'] }}</td>
        </tr>
        }
      </tbody>
    </table>
  `,
  styleUrls: ['../warnings-tables/warnings-pluvio-aggregated.component.scss'],
})
export class SentinelAggregatedTableComponent implements AfterViewInit {
  @Input() clickData: Dewetra3LayerCommonEvent;
  @Input() sensors: SentinelFeature[];
  @Input() aggregateFeatureWithoutGeom: SENTINELAggreWithouGeom[];
  layer: WARNINGSLayerManager;
  cumulatedValueList: number[] = [];
  matrix$: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);

  COLOR_DICT: any = {
    0: 'black',
    1: 'yellow',
    2: 'orange',
    3: 'red',
    4: 'blue',
  };

  PERIOD_DICT: number[] = [900, 1800, 3600, 10800, 21600, 43200, 64800, 86400, 129600];

  trasformToMatrix(
    sensors: SentinelFeature[],
    districtWithoutGeom: SENTINELAggreWithouGeom[],
    municipalitiesWithoutGeom: SENTINELAggreWithouGeom[]
  ): any[] {
    const matrix: any[] = [];

    sensors.forEach((sensor) => {
      const raw: { [key: string]: any } = {}; // Change the type of raw
      raw['st'] = sensor.properties.st;

      const distrits_id = sensor.properties?.aggr?.districts_it;
      const municipalities_id = sensor.properties?.aggr?.municipalities_it_topoieti;

      districtWithoutGeom.forEach((aggr) => {
        if (distrits_id?.includes(aggr.id.toString())) {
          raw['st'] += ' - (' + aggr.name + ')';
        }
      });

      raw['municList'] = '';
      municipalitiesWithoutGeom.forEach((aggr) => {
        if (municipalities_id?.includes(aggr.id.toString())) {
          raw['municList'] += aggr.name + ', ';
        }
      });

      this.PERIOD_DICT.forEach((period) => {
        const value = this.getValueByPeriod(sensor, period);
        raw[period] = {};
        raw[period]['value'] = value ? value.v : 'na';
        raw[period]['color'] = this.getColorFromValue(raw[period]['value']);
        raw[period]['exceeding'] = sensor.properties.e.filter((e) => {
          return e.name.split('_')[2] === this.transformToHour(period);
        });
        if (raw[period]['exceeding'] && raw[period]['exceeding'].length > 0) {
          raw[period]['exceedingSeverity'] = Math.max(...raw[period]['exceeding'].map((e: any) => e.sev));
          raw[period]['exceedingColor'] = this.getColorFromSeverity(raw[period]['exceedingSeverity']);
        } else {
          raw[period]['exceedingSeverity'] = 0;
          raw[period]['exceedingColor'] = this.getColorFromSeverity(0);
        }
      });
      matrix.push(raw);
    });

    return matrix;
  }

  getValueByPeriod(sensor: SentinelFeature, period: number): SentinelValueFeatureProperties {
    return sensor.properties.v.filter((v) => v.p == period)[0];
  }

  getColorFromValue(value: number): any {
    const customProperties = getLayerMapProperties(this.layer.getLayerModel()) as CustomPropertiesSentinelSensor;
    const legendProperties = customProperties.default;

    if (value == 0 || value == null || !legendProperties.legend[0]?.color) {
      return '#000000';
    }
    let color = legendProperties.legend[0].color;
    if (value !== null && typeof value === 'number') {
      //iterate over the legend properties
      legendProperties.legend.filter((legend: any, index: number) => {
        if (value >= legend.value[0] && value <= legend.value[1]) {
          color = legend.color;
        }
      });
    }
    return color;
  }

  getColorFromSeverity(severity: any): any {
    return { color: this.COLOR_DICT[severity] };
  }

  transformToHour(value: number): string {
    switch (value) {
      case 900:
        return '15m';
      case 1800:
        return '30m';
      case 3600:
        return '1h';
      case 10800:
        return '3h';
      case 21600:
        return '6h';
      case 43200:
        return '12h';
      case 64800:
        return '18h';
      case 86400:
        return '24h';
      case 129600:
        return '36h';
      default:
        return '';
    }
  }

  ngAfterViewInit(): void {
    this.layer = this.clickData.layer as SENTINELLayerManager;

    const municipalities = this.layer.loadAggreatedLayerWithoutGeom('municipalities_it');
    const districts = this.layer.loadAggreatedLayerWithoutGeom('districts_it');

    forkJoin([municipalities, districts])
      .pipe(
        map(([municipalities, districts]) => {
          return this.trasformToMatrix(this.sensors, districts, municipalities);
        })
      )
      .subscribe((matrix) => {
        this.matrix$.next(matrix);
      });
    this.cumulatedValueList = (
      this.layer.data$.getValue().properties as WARNINGSLayerManagerProperties
    ).cumulatedValueList;
  }
}
