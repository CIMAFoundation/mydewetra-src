import { Pipe, PipeTransform } from '@angular/core';
import { LayerModel } from '../models/dewetra3-layer';



@Pipe({
  name: 'coveragePipe'
})
export class CoveragePipePipe implements PipeTransform {

  transform(layers: LayerModel[], args: string): LayerModel[] {
    if (layers && layers.length >= 0 && args && args.length > 0) {
      layers = layers.filter((layer: LayerModel) => {
        return layer.geoscale == args;
      });
      return layers as LayerModel[];
    } else {
      return layers as LayerModel[];
    }

  }

}
