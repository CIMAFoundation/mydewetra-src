import { GeoJsonObject } from 'geojson';
import { firstValueFrom } from 'rxjs';
import { DDSLayerPublishResponse } from '../../models/layer-availability';
import { WMSInfoResponse } from '../../models/models';
import { dateToSeconds } from '../../utils/utils';
import { DDSLayerData, DDSLayerManager, DDSLayerManagerProperties, DDSLayerMapInfoResult, DDSLayerPunctualSeriesResult } from './dds.manager';




export interface DDSWFSLayerData extends DDSLayerData {
  geoJson: GeoJsonObject | GeoJsonObject[];
}

export interface DDSWFSLayerMapInfoResult extends DDSLayerMapInfoResult {
  wmsData: WMSInfoResponse;
}

export interface DDSWFSLayerPunctualSeriesResult extends DDSLayerPunctualSeriesResult {
  data: any;
}



export class DDSWFSLayerManager extends DDSLayerManager {


  override async getLayerData(properties: DDSLayerManagerProperties): Promise<DDSWFSLayerData> {
    const publishRequest = {
      props: properties.ddsProperties,
      data: properties.item,
      from: dateToSeconds(properties.dateFrom),
      to: dateToSeconds(properties.dateTo),
    };
    const published = await this.rePublishData(publishRequest);
    const wfsData = await this.loadGeoJsonDataFromWFSService(published);
    const data = {
      serverUrl: this.layerModel.server.url + '/wms',
      published,
      geoJson: wfsData,
    } as DDSWFSLayerData;

    return data;
  }

  private async loadGeoJsonDataFromWFSService(published: DDSLayerPublishResponse): Promise<any> {

    const params = {
      srsName: 'EPSG:4326',
      request: 'GetFeature',
      version: '1.0.0',
      outputFormat: 'json',
      typeName: published.layerid,
    };

    return firstValueFrom(this.http.get(this.getLayerModel().server.url + '/wfs', { params }))

  }


  public override hasPunctualSeries(): boolean {
    return false;
  }



}
