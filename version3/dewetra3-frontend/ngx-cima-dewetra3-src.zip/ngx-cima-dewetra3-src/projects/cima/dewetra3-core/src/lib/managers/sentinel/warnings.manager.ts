import { BaseLayerManagerProperties } from '../../models/models';
import { SENTINELLayerManager, SENTINELLayerManagerProperties } from './sentinel.manager';

export interface WARNINGSLayerManagerProperties extends SENTINELLayerManagerProperties {
  aggregationsList: string[];
  aggregationSelected: string;
  minimumExceedingList: string;
  minimumExceedingSelected: string;
  maximumTemporalAggregationList: string[];
  maximumTemporalAggregationSelected: string;
}

export class WARNINGSLayerManager extends SENTINELLayerManager {
  override async getDefaultProperties(dateFrom: Date, dateTo: Date): Promise<BaseLayerManagerProperties> {
    const aggregationsList = await this.loadAggregationList();

    let minimumExceedingList = '0';
    let minimumExceedingSelected = '0';
    let hasMinimumExceedingProp = this.getLayerModel()?.propertiesmanager?.props?.minimumExceedingList ? true : false;
    if (hasMinimumExceedingProp) {
      minimumExceedingList = this.getLayerModel().propertiesmanager.props.minimumExceedingList;
      minimumExceedingSelected = this.getLayerModel().propertiesmanager.props.minimumExceedingSelected;
    }

    let maximumTemporalAggregationList = [];
    let maximumTemporalAggregationSelected = '0';
    let hasMaximumTemporalAggregationProp = this.getLayerModel()?.propertiesmanager?.props
      ?.maximumTemporalAggregationList
      ? true
      : false;
    if (hasMaximumTemporalAggregationProp) {
      maximumTemporalAggregationList = this.getLayerModel().propertiesmanager.props.maximumTemporalAggregationList;
      maximumTemporalAggregationSelected =
        this.getLayerModel().propertiesmanager.props.maximumTemporalAggregationSelected;
    }

    return {
      aggregationSelected: 'none',
      aggregationsList: aggregationsList,
      minimumExceedingList: minimumExceedingList,
      minimumExceedingSelected: minimumExceedingSelected,
      maximumTemporalAggregationList: maximumTemporalAggregationList,
      maximumTemporalAggregationSelected: maximumTemporalAggregationSelected,
      dateFrom,
      dateTo,
    } as WARNINGSLayerManagerProperties;
  }
}
