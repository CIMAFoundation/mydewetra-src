import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DynamicModule } from 'ng-dynamic-component';
import { SENTINELInfoComponent } from './sentinel/sentinel-info.components';
import { LayerEventWrapperComponent } from './wrapper/layer-event-wrapper.component';
import { WARNINGSInfoComponent } from './sentinel/warnings-info.components';
import { SERIEInfoComponent } from './serie/serie-info.components';


const _COMPONENTS = [
  SENTINELInfoComponent,
  LayerEventWrapperComponent,
  WARNINGSInfoComponent,
  SERIEInfoComponent
];



@NgModule({
  declarations: [_COMPONENTS],
  imports: [
    CommonModule,
    DynamicModule,
  ],
  exports: [
    _COMPONENTS
  ]
})
export class Dewetra3LayerEventModule { }
