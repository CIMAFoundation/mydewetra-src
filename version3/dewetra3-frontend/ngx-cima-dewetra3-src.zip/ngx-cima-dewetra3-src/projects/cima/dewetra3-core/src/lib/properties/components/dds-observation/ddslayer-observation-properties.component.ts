import { Component, inject, Input } from '@angular/core';
import { MatSelectChange } from '@angular/material/select';
import { TimepickerService, TimepickerValue } from '@cima/commons';
import { format } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';
import { BehaviorSubject, combineLatest, from, Observable, switchMap, tap } from 'rxjs';
import { DDSLayerData, DDSLayerManager, DDSLayerManagerProperties } from '../../../managers/dds/dds.manager';
import { DDSLayerAvailability } from '../../../models/layer-availability';
import { DDSAttribute, DDSLayerProperties } from '../../../models/layer-properties';
import { LayerDataContainer } from '../../../models/models';

@Component({
  selector: 'lib-ddslayer-observation-properties',
  templateUrl: './ddslayer-observation-properties.component.html',
  styleUrls: ['./ddslayer-observation-properties.component.scss'],
})
export class DDSLayerObservationPropertiesComponent {
  @Input() manager!: DDSLayerManager;

  selectedModelDate: any = null;
  selectedReference: any = null;
  groups: [] = null;
  loadedDDSLayerData: DDSLayerData = null;
  properties$!: Observable<DDSLayerManagerProperties>;
  managerProperties: DDSLayerManagerProperties = null;
  availability$: Observable<DDSLayerAvailability[]>;
  availability: DDSLayerAvailability[];
  timepickerValue = new BehaviorSubject<TimepickerValue | null>(null);
  loading = false;

  private _timePickerService: TimepickerService = inject(TimepickerService);

  ngOnInit(): void {
    this._timePickerService.timepickerValue$.subscribe((timepickerValue) => this.timepickerValue.next(timepickerValue));

    this.properties$ = this.manager.getProperties$().pipe(
      tap((properties) => {
        this.updateAttributeVisibility();
      })
    ) as unknown as Observable<DDSLayerManagerProperties>;

    this.availability$ = combineLatest([
      this.manager.getProperties$() as Observable<DDSLayerManagerProperties>,
      this.manager.getData$(),
    ]).pipe(
      switchMap(([properties, data]: [DDSLayerManagerProperties, LayerDataContainer]) => {
        const ddsProperties = properties as DDSLayerManagerProperties;
        this.loadedDDSLayerData = data.data as DDSLayerData;
        console.log('loadedDDSLayerData', this.loadedDDSLayerData);
        return from(
          this.manager.getAvailability(ddsProperties.ddsProperties, ddsProperties.dateFrom, ddsProperties.dateTo)
        );
      }),
      tap((availability: DDSLayerAvailability[]) => {
        console.log('availability', availability);
        this.preselectGroupedDates(availability);
      }),
      tap(() => (this.loading = false))
    );

    // this.properties$.subscribe(() => this.updateAttributeVisibility());
  }

  preselectGroupedDates(availability: DDSLayerAvailability[]) {
    this.availability = availability;
    const lastTwoElements = this.loadedDDSLayerData.published.layerid.split('_').slice(-2);
    let selected = availability.find((a) => a.id === lastTwoElements[0] + ';' + lastTwoElements[1]);
    if (!selected) {
      selected = availability.find((a) => a.id === lastTwoElements[0]);
    }
    this.selectedReference = selected;
  }

  selectEntry(properties: DDSLayerProperties, attr: DDSAttribute, newEntry: MatSelectChange) {
    // @ts-ignore
    attr.selectedEntry = attr.entries?.find((e) => e.value == newEntry.value);

    const timePickerValue = this.timepickerValue.value;
    if (timePickerValue === null) {
      return;
    }

    this.loading = true;

    this.availability$ = from(this.manager.getAvailability(properties, timePickerValue.from, timePickerValue.to)).pipe(
      tap(() => (this.loading = false))
    );

    this.updateAttributeVisibility();
  }

  updateAttributeVisibility() {
    let timeAccumulate = false;
    if (!this.managerProperties) return;
    this.managerProperties.ddsProperties.layerProperties.attributes.forEach((prop) => {
      if (prop.descr === 'Variable') {
        const referredValues = prop.selectedEntry.referredValues;
        const entries = Array.isArray(referredValues.entry) ? referredValues.entry : [referredValues.entry];
        if (entries.length > 0) {
          entries.forEach((entry: any) => {
            if (entry.key === 'cumulate' && entry.value === '1') {
              timeAccumulate = true;
            }
          });
        }
      }
      if (prop.descr === 'Cumulative Range') {
        prop.visible = timeAccumulate ? 'true' : 'false';
      }
    });
  }

  formatObservationEntry(entry: DDSLayerAvailability) {
    if (!entry) {
      return '';
    }
    return entry.date
      ? format(toZonedTime(new Date(entry.date), 'UTC'), 'dd/MM/yyyy HH:mm ') + '(UTC)'
      : entry.description;
  }

  async publishLayer(ddsProps: DDSLayerProperties, item: DDSLayerAvailability) {
    const timePickerValue = this.timepickerValue.value;

    if (timePickerValue === null) {
      return;
    }

    const dateFrom = timePickerValue?.from;
    const dateTo = timePickerValue.to === 'now' ? new Date() : timePickerValue.to;

    const movieAllowed = await this.manager.movieAllowed(ddsProps);

    const properties = {
      ddsProperties: ddsProps,
      item: item,
      dateFrom,
      dateTo,
      isMovieAllowed: movieAllowed,
    };

    this.manager.applyProperties(properties);
  }
}
