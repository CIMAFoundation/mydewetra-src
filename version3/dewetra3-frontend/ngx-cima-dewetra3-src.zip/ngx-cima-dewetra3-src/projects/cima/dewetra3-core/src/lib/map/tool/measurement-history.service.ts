import {Injectable} from '@angular/core';
import {PastMeasurement} from "../../models/models";


@Injectable()
export class MeasurementHistoryService {
  private _history: PastMeasurement[] = [];

  get history(): PastMeasurement[] {
    return this._history;
  }

  set history(measurements: PastMeasurement[]) {
    this._history = measurements;
  }

  add(measurement: PastMeasurement): void {
    this._history.push(measurement);
  }

  clear(): void {
    this._history = [];
  }
}
