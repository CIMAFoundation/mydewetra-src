import { Component, inject, Input } from '@angular/core';
import { Observable } from 'rxjs';
import { BaseDewetra3LayerEventData, BaseLayerManager } from '../../managers/base/base.manager';
import { TranslateService } from "@ngx-translate/core";
import { mergeExceedingAndValue } from '../../utils/utils';
import { SentinelValueAndExceedingMergedData } from '../../models/sentinel';
import { orderBy } from 'lodash-es';

// {
//   "v": 113.1,
//   "t": 1715160720,
//   "id": 42694,
//   "name": "TH_ord_1h",
//   "sev": 1
// }

//in case of feature .values



@Component({
  selector: 'dewetra3-warnings-info',
  template: `
    <div *ngIf="manager && layerEvent">
      <span *ngIf="layerEvent.feature.geometry.type === 'Point'">
        <h2>{{ layerEvent?.feature?.properties?.st }}</h2>
        <h4>{{ parseTime() }}</h4>
        <ul>
          @for(p of periods; track p){

              <li [ngStyle]="{color: THR_COLORS.get(mergedValuesAndThrs.get(p).sev)}">
                <span >{{ parsePeriod(p)}}</span>
                <span style="min-width: 30px;"></span>
                <span>{{ mergedValuesAndThrs.get(p).value }} {{ layerEvent?.feature?.properties?.mu }}</span>
              </li>

          }

        </ul>
      </span>
      <span *ngIf="layerEvent.feature.geometry.type === 'MultiPoligon'">
        <h2>{{ layerEvent?.feature?.properties?.name }}</h2>

      </span>
    </div>
  `,
  styles: `
    h2 {
      font-size: 1.5rem;
      font-weight: bold;
      margin: 0;
    }

    h4 {
      font-size: 1rem;
      margin: 0;
    }

    ul {
      list-style-type: none;
      padding: 0;
    }

    li {
      display: flex;
      justify-content: space-between;
      padding: 0.5rem 0;
    }
  `
})
export class WARNINGSInfoComponent {
  @Input() manager!: BaseLayerManager;
  @Input() infoEvents$!: Observable<any>;
  @Input() layerEvent: BaseDewetra3LayerEventData | any;

  translate:TranslateService = inject(TranslateService);

  periods: number[] = [];
  mergedValuesAndThrs: Map<number, SentinelValueAndExceedingMergedData>;

  THR_COLORS: Map<number, string> = new Map([
    [-1, 'white'],
    [0, 'green'],
    [1, 'yellow'],
    [2, 'orange'],
    [3, 'red'],
    [4, 'blue']
  ]);

  getPeriods() {
    return Array.from(mergeExceedingAndValue(this.layerEvent.feature.properties).keys());
  }

  parseTime(): string {
    const time = this.mostRecentTime() * 1000;
    return new Date(time).toLocaleString();
  }

  parsePeriod(period: number): string {
    if (period === 0) {
      return this.translate.instant('DEWETRA3CORE.LAST');
    }

    if(isNaN(period)){
      return (this.mergedValuesAndThrs.get(period).sevName)?this.mergedValuesAndThrs.get(period).sevName:'';
    }

    return this.translate.instant('DEWETRA3CORE.LAST') + ' ' + period / 60 / 60 + ' h';
  }

  mostRecentTime() {
    if (!this.layerEvent.feature.properties.v) return 0;
    let mostRecent = 0;
    this.layerEvent.feature.properties.v.forEach((v: any) => {
      if (v.t > mostRecent) {
        mostRecent = v.t;
      }
    });
    return mostRecent;
  }

  initializeLayerEventValues() {
    if (this.layerEvent?.feature?.properties) {
      this.mergedValuesAndThrs = mergeExceedingAndValue(this.layerEvent.feature.properties);
      this.periods = Array.from(this.mergedValuesAndThrs.keys()).sort((a, b) => a - b);
    }
  }

  ngOnChanges() {
    this.initializeLayerEventValues();

  }



}


