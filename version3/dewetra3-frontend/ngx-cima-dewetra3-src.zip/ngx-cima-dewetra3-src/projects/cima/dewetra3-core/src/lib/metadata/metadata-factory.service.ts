import { Injectable } from '@angular/core';
import { LayerModel } from '../models/dewetra3-layer';
import { LinkMetadataComponent } from './component/link/link-metadata.component';


@Injectable({
  providedIn: 'root'
})
export class MetadataComponentFactory {
  static DEFAULT_METADATA_COMPONENTS = {
    'LinkMetadataComponent': LinkMetadataComponent,//better to add a field in layer model
    'CustomMetadataComponent': LinkMetadataComponent,//TODO
  };
  
  private _registry: Map<string, any> = new Map(Object.entries(MetadataComponentFactory.DEFAULT_METADATA_COMPONENTS))

  constructor() { }

  set(name: string, component: any) {
    this._registry.set(name, component);
  }

  create(layerModel: LayerModel): any {
    const klass = this._registry.get(layerModel.metadatamanager.component);
    return klass;
  }
}
