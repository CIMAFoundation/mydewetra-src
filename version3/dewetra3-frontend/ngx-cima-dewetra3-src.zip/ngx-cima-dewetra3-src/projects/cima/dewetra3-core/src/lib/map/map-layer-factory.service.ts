import { EventEmitter, Injectable } from '@angular/core';
import * as L from 'leaflet';
import { LayerModel } from '../models/dewetra3-layer';
import { LayerWithViewProps } from "../managers/base/base.manager";
import { DDSWFSLayerLeaflet } from './layers/dds/dds.wfs.leaflet.layer';
import { DDSWMSLayerLeaflet } from './layers/dds/dds.wms.leaflet.layer';
import { SentinelLayerLeaflet } from './layers/sentinel/sentinel.leaflet.layer';
import { WarningsPluvioLayerLeaflet } from './layers/sentinel/warnings-pluvio.leaflet.layer';
import { SerieLayerLeafletLayer } from './layers/serie/serie.leaflet.layer';
import { StaticLayerLeaflet } from "./layers/static/static.leaflet.layer";
import { WMSTCapabilitiesLayerLeaflet } from './layers/wmst/wmst-capabilities.leaflet.layer';
import { WMSTLayerLeaflet } from './layers/wmst/wmst.leaflet.layer';
import { WarningsHydroLayerLeaflet } from './layers/sentinel/warnings-hydro.leaflet.layer';


@Injectable({
  providedIn: 'root'
})
export class MapLayerFactory {
  static DEFAULT_MAP_LAYERS = {
    'DDSWMSMapComponent': DDSWMSLayerLeaflet,
    'DDSWFSMapComponent': DDSWFSLayerLeaflet,
    'SENTINELMapComponent': SentinelLayerLeaflet,
    'StaticMapComponent': StaticLayerLeaflet,
    'WMSTMapComponent': WMSTLayerLeaflet,//remove? could be covered bt WMSTCapabilitiesMapComponent
    'WMSTCapabilitiesMapComponent': WMSTCapabilitiesLayerLeaflet,
    'SeriesMapComponent': SerieLayerLeafletLayer,
    'WarningsPluvioLayerLeaflet': WarningsPluvioLayerLeaflet,
    'WarningsHydroLayerLeaflet': WarningsHydroLayerLeaflet
  };

  private _registry: Map<string, any> = new Map(Object.entries(MapLayerFactory.DEFAULT_MAP_LAYERS))

  constructor() { }

  set(name: string, component: any) {
    this._registry.set(name, component);
  }

  create(
    layerModel: LayerModel,
    map: L.Map,
    layerWithViewProps: LayerWithViewProps,
    onLayerEvent: EventEmitter<any>
  ): any {
    let klass = this._registry.get(layerModel.mapmanager.component);

    if (!klass) {
      throw new Error(`Map layer for ${layerModel.mapmanager.component} not found in registry`);
    }
    const component = new klass(
      map,
      layerWithViewProps,
      onLayerEvent,
    );

    return component;
  }
}
