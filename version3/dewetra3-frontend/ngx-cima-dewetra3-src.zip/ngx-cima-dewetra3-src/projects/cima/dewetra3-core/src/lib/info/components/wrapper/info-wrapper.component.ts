import {Component, Input} from '@angular/core';
import {BaseLayerManager} from '../../../managers/base/base.manager';
import {InfoComponentFactory} from '../../info-component-factory.service';
import {BehaviorSubject, Observable, combineLatest, filter, switchMap} from 'rxjs';
import {BaseMapInfoResult, Dewetra3MapClick} from '../../../models/models';

@Component({
  selector: 'dewetra3-info-wrapper',
  template: `
    @if (component) {
      <div class="info-wrapper">
        <ndc-dynamic
          [ndcDynamicComponent]="component"
          [ndcDynamicInputs]="{manager, clickData, infoEvents$}"
        ></ndc-dynamic>
      </div>
    }
  `,
  styleUrls: ['./info-wrapper.component.scss']
})
export class InfoWrapperComponent {
  private manager$ = new BehaviorSubject<BaseLayerManager | null>(null);

  @Input() set manager(manager: BaseLayerManager) {
    this.manager$.next(manager);
  };

  public get manager() {
    return this.manager$.getValue();
  }

  private clickData$ = new BehaviorSubject<Dewetra3MapClick | null>(null);

  @Input() set clickData(clickData: Dewetra3MapClick) {
    this.clickData$.next(clickData);
  };

  public get clickData() {
    return this.clickData$.getValue();
  }

  public infoEvents$ = combineLatest([this.manager$, this.clickData$]).pipe(
    filter(([manager, clickData]) => !!manager && !!clickData),
    switchMap(([manager, clickData]) => manager.getInfo$(clickData.latLng))
  );

  public component!: any;


  constructor(
    private infoFactory: InfoComponentFactory
  ) {
  }

  ngOnInit(): void {
    this.component = this.infoFactory.create(this.manager.getLayerModel());
  }
}
