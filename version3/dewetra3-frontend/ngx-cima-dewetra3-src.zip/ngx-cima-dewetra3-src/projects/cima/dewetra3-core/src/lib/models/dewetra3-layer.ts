interface NameIconModel {
  id: number;
  name: string;
  icon: string;
}

interface NameDescrModel {
  id: number;
  name: string;
  descr: string;
}

interface ManagerComponent {
  id: number;
  component: string;
  props: any;
}

export interface LayerSource extends NameIconModel {
}

export interface LayerEvent extends NameDescrModel {
}

export interface LayerHazard extends NameIconModel {
}

export interface LayerEventData {
  id: number;
  event: LayerEvent;
  hazard?: LayerHazard;
  date: Date;
  lat: number;
  lon: number;
  datatype: string;
}

export interface LayerTag extends NameIconModel {
}

export interface LayerInspireTheme extends NameIconModel {
}

export interface LayerDraCategory extends NameIconModel {
}

export interface LayerPath {
  id: number;
  path: string;
  hierarchy: string;
}

export interface LayerServer extends NameDescrModel {
  id: number;
  url: string;
  token: string;
}

export interface LayerInfoManager extends ManagerComponent {
}

export interface LayerLegendManager extends ManagerComponent {
}

export interface LayerPropertiesManager extends ManagerComponent {
}

export interface LayerMetadataManager extends ManagerComponent {
}

export interface LayerManager extends ManagerComponent {
}

export interface ChartManager extends ManagerComponent {
}

export interface MapManager extends ManagerComponent {
}

export interface LayerModel {
  // the mapping can be overridden at application level,
  // manager, chart, info, legend, properties, metadata can be overridden in the customprops field
  id?: number;
  server: LayerServer;
  source: LayerSource;
  category: string;
  event?: LayerEvent;
  hazards?: LayerHazard[];
  geoscale: string;
  tags: LayerTag[];
  inspirethemes: LayerInspireTheme[];
  dracategories: LayerDraCategory[];
  translatedName?: string; // used in magic search
  paths: LayerPath[];
  roles: number[];
  icon: string;
  name: string;
  name_i18n: string;
  descr: string;
  dataid: string;
  thumb: string;
  lonw: number;
  lone: number;
  lats: number;
  latn: number;
  customprops: any;
  related: number[];
  is_mine?: boolean;

  infomanager: LayerInfoManager;
  legendmanager: LayerLegendManager;
  propertiesmanager: LayerPropertiesManager;
  metadatamanager: LayerMetadataManager;
  layermanager: LayerManager;
  chartmanager: ChartManager;
  mapmanager: MapManager;
}

export interface layerCategoryModel {
  id: number;
  name: string;
}
