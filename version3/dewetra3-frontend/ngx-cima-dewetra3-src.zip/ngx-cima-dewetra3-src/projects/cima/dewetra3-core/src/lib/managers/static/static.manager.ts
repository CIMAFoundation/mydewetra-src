
import { Observable, map, shareReplay } from "rxjs";
import { BaseLayerManagerData, BaseLayerManagerProperties, BaseMapInfoResult, LayerDataContainer, StaticLayerMapInfoResult, WMSInfoResponse } from "../../models/models";

import { getWMSLayerInfoUrl, } from "../../utils/utils";
import { BaseLayerManager } from "../base/base.manager";


export interface StaticLayerManagerProperties extends BaseLayerManagerProperties { }

export interface StaticLayerData extends LayerDataContainer {
  dataid: string;
}

export class StaticWMSLayerManager extends BaseLayerManager {
  override async getDefaultProperties(dateFrom: Date, dateTo: Date): Promise<BaseLayerManagerProperties> {
    return {
      dateFrom, dateTo
    }
  }

  async getLayerData(properties: BaseLayerManagerProperties): Promise<BaseLayerManagerData> {
    return {};
  }

  public override getInfo$(latlng: L.LatLng): Observable<BaseMapInfoResult> {

    const dataId = this.getLayerModel().dataid;

    const url = getWMSLayerInfoUrl(
      this.getLayerModel().server.url,
      latlng,
      dataId
    );
    return this.getExternal<WMSInfoResponse>(url).pipe(
      map((data) => ({ wmsData: data, latLng: latlng } as StaticLayerMapInfoResult)),
      shareReplay()
    );
  }
}

