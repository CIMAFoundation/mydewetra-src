import { Injectable } from '@angular/core';
import { LayerModel } from '../models/dewetra3-layer';
import { TimeSeriesChartComponent } from './components/timseries/timeseries-chart.component';
import { SENTINELChartComponent } from './components/sentinel/sentinel-chart.component';
import { SERIESChartComponent } from './components/serie/series-chart.component';
import { WARNINGSPLUVIOChartComponent } from './components/sentinel/warning-pluvio-chart.component';
import { NotEnabledChartComponent } from './components/not-enabled.component';
import { SERIESItalyChartComponent } from './components/serie/series-italy-chart.component';
import { TimeSeriesPropertiesChartComponent } from './components/timseries/timeseries-properties-chart.component';


@Injectable({
  providedIn: 'root'
})
export class ChartComponentFactory {
  static DEFAULT_CHART_COMPONENTS = {
    'TimeSeriesChartComponent': TimeSeriesChartComponent,
    'TimeSeriesPropertiesChartComponent': TimeSeriesPropertiesChartComponent,
    'SENTINELChartComponent': SENTINELChartComponent,
    'SERIESChartComponent': SERIESChartComponent,
    'SERIESItalyChartComponent': SERIESItalyChartComponent,
    'WARNINGSPLUVIOChartComponent': WARNINGSPLUVIOChartComponent,
    'NotEnabledChartComponent': NotEnabledChartComponent
  };

  private _registry: Map<string, any> = new Map(Object.entries(ChartComponentFactory.DEFAULT_CHART_COMPONENTS))

  constructor() { }

  set(name: string, component: any) {
    this._registry.set(name, component);
  }

  create(layerModel: LayerModel): any {
    //[TODO] -> add ChartComponent
    const klass = this._registry.get(layerModel.chartmanager.component);
    //console.log("layerType", layerModel.chartmanager.component, klass);
    if (!klass) {
      throw new Error(`Component for ${layerModel.chartmanager.component} not found in registry`);
    }
    return klass;
  }
}

