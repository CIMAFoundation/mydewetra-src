import { AfterViewInit, Component, inject, Input } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import * as Plotly from 'plotly.js-dist-min';
import { Observable } from 'rxjs';
import { filter, map, startWith, switchMap } from 'rxjs/operators';
import * as uiid from 'uuid';

import { Compatible, Compatibles } from '../../../managers/serie/serie.model';

import {
  SERIEGetSeriesResult,
  SERIELayerEventData,
  SERIELayerManagerProperties,
  SERIESLayerManager,
} from '../../../managers/serie/serie.manager';

import { TranslateService } from '@ngx-translate/core';
import { Dewetra3LayerEventWithData } from '../../../managers/base/base.manager';
import { getCustomChartProperties, replacePlaceholders, transformStringToTranslatable } from '../../../utils/utils';

interface FeatureProperties {
  ID: string;
  SEZIONE: string;
  'NOME IDROM': string;
  NOME_BACIN: string;
  DATI_DA: string;
  NOME_DOMIN: string;
  COMUNE: string;
  PROV: string;
  REGIONE: string;
  BACINO: string;
  LON: string;
  LAT: string;
  AREA: string;
  CORR_TIME: string;
  CN: string;
  THR1: string;
  THR2: string;
  THR3: string;
  ALERTZONE: string;
  Q_ALLARME: string;
  Q_ARANCION: string;
  Q_ALLERTA: string;
  'Fonte Q_so': string;
  StimaQoss: string;
  QUAL1_5: string;
  CALIBRATO: string;
  Err_Rel_Qp: string;
  NashSut: string;
  FonteSdD: string;
  maxvalue: number;
  trend: number;
  run: string;
  obs: number;
}

@Component({
  selector: 'series-chart',
  template: `
    @if (loadingChart$ | async) {
    <div>{{ 'DEWETRA3CORE.LOADING_CHART' | translate }}...</div>
    <div class="w-100 h-100 d-flex justify-content-center align-items-center flex-column">
      <mat-progress-bar mode="indeterminate"></mat-progress-bar>
    </div>
    } @if (seriesResult?.data) {
    <div class="chart-title">
      {{ getTitle() }}
    </div>
    <div class="chart-subtitle">
      {{ getSubtitle() }}
    </div>
    } @if (seriesResult?.data) {
    <mat-tab-group (selectedTabChange)="onSerieChange($event)" [selectedIndex]="selectedCompatibleIndex">
      @for (compatible of compatibles.compatibles; track $index) {
      <mat-tab [label]="seriesLabel(compatible) | translate">
        <mat-tab-group (selectedTabChange)="onTypeChartChange($event)" [selectedIndex]="selectedTypeIndex">
          @for (type of compatible.type.split(';'); track $index) {
          <mat-tab [label]="chartLabel(compatible, type) | translate"></mat-tab>
          }
        </mat-tab-group>
      </mat-tab>
      }
    </mat-tab-group>
    }
    <div class="p-2">
      @if (errorMessage) {
      <div class="alert alert-danger text-center">
        {{ errorMessage }}
      </div>
      }@else {
      <div [id]="chartId" class="rounded-2 chart-wrapper overflow-hidden"></div>
      }
    </div>
  `,
  styles: ['.chart-wrapper {height: calc(100vh - 300px);}', '.chart-wrapper {width: 100%;}'],
})
export class SERIESChartComponent implements AfterViewInit {
  @Input() clickData: Dewetra3LayerEventWithData;
  @Input() chartEvents$!: Observable<SERIEGetSeriesResult>;
  @Input() dateFrom!: Date;
  @Input() dateTo!: Date;

  public chartId = uiid.v4();
  public loadingChart$!: Observable<boolean>;
  public component!: any;
  public seriesResult: SERIEGetSeriesResult = null;
  public compatibles: Compatibles;
  public selectedCompatible: Compatible;
  public selectedCompatibleIndex: number = 0;
  public selectedType: string;
  public selectedTypeIndex: number = 0;
  public featureProperties: FeatureProperties;
  private translateService = inject(TranslateService);
  errorMessage: string | null = null;

  getTitle() {
    const title = getCustomChartProperties(this.clickData.layer.getLayerModel())?.title;
    const titlePiped = replacePlaceholders(title, this.featureProperties, this.translateService);
    const fallback = `${this.translateService.instant('DEWETRA3CORE.SEZIONE')} : ${this.featureProperties.DATI_DA} `;
    return titlePiped || fallback;
  }

  getSubtitle() {
    const subtitle = getCustomChartProperties(this.clickData.layer.getLayerModel())?.subtitle;
    const subtitlePiped = replacePlaceholders(subtitle, this.featureProperties, this.translateService);
    const fallback = `${this.translateService.instant('DEWETRA3CORE.BACINO')} : ${this.featureProperties.BACINO} `;
    return subtitlePiped || fallback;
  }

  seriesLabel(compatible: Compatible) {
    return transformStringToTranslatable(compatible.descr);
  }

  chartLabel(compatiple: Compatible, type: string) {
    return transformStringToTranslatable(compatiple.descr + ' - ' + type);
  }

  onSerieChange(event: MatTabChangeEvent) {
    this.selectedCompatible = this.compatibles.compatibles[event.index];
    this.selectedTypeIndex = 0;
    this.loadChartByCompatibles();
  }

  onTypeChartChange(event: MatTabChangeEvent) {
    this.selectedTypeIndex = event.index;
    this.loadChartByCompatibles();
  }

  async plotChart(chart: any) {
    await Plotly.purge(this.chartId);
    return await Plotly.newPlot(this.chartId, chart);
  }

  async loadChartByCompatibles() {
    const layer = this.clickData.layer as SERIESLayerManager;
    this.selectedType =
      this.selectedCompatible.type.indexOf(';') > -1
        ? this.selectedCompatible.type.split(';')[this.selectedTypeIndex]
        : this.selectedCompatible.type;
    const data = await layer.loadChartByCompatible(
      'json',
      this.clickData.data as SERIELayerEventData,
      this.selectedCompatible,
      this.selectedType,
      this.dateFrom,
      this.dateTo
    );
    await this.plotChart(data);
  }

  setTabIndex() {
    // this.selectedCompatible = this.compatibles.compatibles.find((compatible: Compatible, i: number) => compatible.descr === this.seriesResult.data.compatibles);
    // this.selectedType = this.seriesResult.data.type;
    // this.selectedTypeIndex = this.selectedCompatible.type.split(';').findIndex((type: string, i: number) => type === this.seriesResult.data.type);
  }

  ngAfterViewInit(): void {
    //@ts-ignore
    this.featureProperties = this.clickData.data.feature.properties as FeatureProperties;

    this.clickData.layer.getProperties$().subscribe((data) => {
      const properties = data as SERIELayerManagerProperties;
      this.compatibles = properties.compatibles;
      // filter compatibles by available customprops
      if (Object.keys(this.clickData.layer.getLayerModel().customprops).length > 0) {
        const availableCompatibles = Object.keys(this.clickData.layer.getLayerModel().customprops);
        this.compatibles.compatibles = this.compatibles.compatibles.filter((compatible) =>
          availableCompatibles.includes(compatible.id)
        );
      }

      this.selectedCompatible = this.compatibles.compatibles.filter(
        (compatible: Compatible) => compatible.id == this.clickData.layer.getLayerModel().dataid
      )[0];
      this.selectedCompatibleIndex = this.compatibles.compatibles.findIndex(
        (compatible: Compatible) => compatible.id == this.clickData.layer.getLayerModel().dataid
      );
    });

    this.loadingChart$ = this.chartEvents$.pipe(
      filter((data) => !!data),
      switchMap(async (data) => {
        // .chart
        if (data.status === 'error') {
          this.errorMessage = data.error || 'Errore generico durante il caricamento del grafico.';
          return false;
        }

        if (data.status === 'loaded') {
          this.errorMessage = null;
          this.seriesResult = data;
          const done = await this.plotChart(data.data.chart[0]);

          this.clickData.layer.postActivityLog(
            'chartid:' +
              this.selectedType +
              ' serieid:' +
              this.selectedCompatible.id +
              ' featureid:' +
              //@ts-ignore
              this.clickData.data.feature.properties[this.selectedCompatible.fidField],
            'chart-loaded'
          );
          return done;
        }

        return true; // assume loading
      }),
      map(() => false),
      startWith(true)
    );
  }
}
