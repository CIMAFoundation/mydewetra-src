import { Pipe, PipeTransform } from '@angular/core';
import { LayerModel } from '../models/dewetra3-layer';


@Pipe({
  name: 'layerByStringPipe'
})
export class LayerByStringPipePipe implements PipeTransform {

  transform(layers: LayerModel[], args: string): LayerModel[] {
    if (layers && layers.length >= 0 && args && args.length > 0) {
      layers = layers.filter((layer: LayerModel) => {
        return (layer.name.toLowerCase().includes(args.toLowerCase()) || layer.descr.toLowerCase().includes(args.toLowerCase()));
      });
      return layers as LayerModel[];
    } else {
      //console.log('by text: no layers or no args', layers, args)
      return layers as LayerModel[];
    }

  }

}
