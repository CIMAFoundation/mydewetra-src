import { WMSParams } from 'leaflet';

export interface CustomWMSParams extends WMSParams {
  bbox?: string;
  info_format?: string;
  feature_count?: number;
  i?: number;
  j?: number;
  x?: number;
  y?: number;
  crs?: string;
  srs?: string;
  query_layers?: string;
}

export interface MapPosition {
  center: L.LatLng;
  zoom: number;
}
