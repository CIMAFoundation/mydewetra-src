import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {CimaCommonsModule} from '@cima/commons';
import {DynamicModule} from 'ng-dynamic-component';
import {PunctualSeriesChartWrapperComponent} from './components/wrapper/punctual-series-chart-wrapper.component';
import {SeriesChartWrapperComponent} from './components/wrapper/series-chart-wrapper.component';
import {TimeSeriesChartComponent} from './components/timseries/timeseries-chart.component';
import {SENTINELChartComponent} from './components/sentinel/sentinel-chart.component';
import {MatCommonModule, MatOptionModule} from '@angular/material/core';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatLabel, MatSelectModule} from '@angular/material/select';
import {MatDialogModule} from '@angular/material/dialog';
import {MatTabsModule} from '@angular/material/tabs';
import {SERIESChartComponent} from './components/serie/series-chart.component';
import { WARNINGSPLUVIOChartComponent } from './components/sentinel/warning-pluvio-chart.component';
import { WARNINGSPLUVIOAggregatedTableComponent } from './components/sentinel/warnings-tables/warnings-pluvio-aggregated.component';
import { NotEnabledChartComponent } from './components/not-enabled.component';
import { SentinelAggregatedTableComponent } from './components/sentinel/sentinel-tables/sentinel-aggregated.component';
import { SERIESItalyChartComponent } from './components/serie/series-italy-chart.component';
import { TimeSeriesPropertiesChartComponent } from './components/timseries/timeseries-properties-chart.component';


const _MAT_MODULES = [
  MatOptionModule,
  MatCommonModule,
  MatProgressSpinnerModule,
  MatSelectModule,
  MatLabel,
  MatDialogModule,
  MatTabsModule
];

const _COMPONENTS = [
  WARNINGSPLUVIOChartComponent,
  WARNINGSPLUVIOAggregatedTableComponent,
  SentinelAggregatedTableComponent,
  PunctualSeriesChartWrapperComponent,
  SeriesChartWrapperComponent,
  TimeSeriesChartComponent,
  TimeSeriesPropertiesChartComponent,
  SENTINELChartComponent,
  SERIESChartComponent,
  SERIESItalyChartComponent,
  NotEnabledChartComponent
]


@NgModule({
  declarations: [
    ..._COMPONENTS
  ],
  imports: [
    CommonModule,
    DynamicModule,
    CimaCommonsModule,
    ..._MAT_MODULES
  ],
  exports: [
    ..._COMPONENTS
  ]

})
export class Dewetra3ChartsModule { }
