import { FeatureCollection, GeoJsonObject } from 'geojson';
import { Observable, catchError, filter, forkJoin, map, of, startWith, switchMap } from 'rxjs';
import { firstValueFrom } from 'rxjs/internal/firstValueFrom';
import { BaseDewetra3LayerEventData } from '../../managers/base/base.manager';
import {
  BaseLayerManagerData,
  BaseLayerManagerProperties,
  BasePunctualSeriesResult,
  LayerDataContainer,
} from '../../models/models';

import { format } from 'date-fns';
import {
  dateToSeconds,
  getCustomChartProperties,
  getCustomPropertiesByKey,
  parseUnixTimestampOrDateFormatted,
} from '../../utils/utils';
import { BaseLayerManager } from '../base/base.manager';
import { Compatible, Compatibles } from './serie.model';

export interface SERIELayerManagerProperties extends BaseLayerManagerProperties {
  compatibles: Compatibles;
}

export interface SERIELayerData extends BaseLayerManagerData {
  sections: GeoJsonObject | GeoJsonObject[];
}

export interface SERIELayerEventData extends BaseDewetra3LayerEventData {
  feature: any;
}

export interface SERIEGetSeriesResult extends BasePunctualSeriesResult {
  status: 'loading' | 'loaded' | 'error';
  data: SERIESerieResultData;
}

export interface SERIESerieResultData {
  chart: Plotly.Data[] | any;
  compatibles: Compatibles;
}

export interface SERIEGetSerieResultData {
  chart: Plotly.Data[] | any;
  compatibles: Compatibles;
}

interface ChartTypeDictionary {
  [key: string]: string;
}

const dictOldChartTypes: ChartTypeDictionary = {
  DeterministicHydrogramChart: 'floodproofs.deterministic',
  NwpGfsDeterministicHydrogramsChart: 'floodproofs.nwpgfsdeterministic',
  MaximumHydrogramChart: 'floodproofs.maximum',
  ProbabilisticHydrogramChart: 'floodproofs.probabilistic',
  DeterministicHydrogramLevelChart: 'floodproofs.deterministic.level',
  MaximumLevelHydrogramChart: 'floodproofs.maximum.level',
  ProbabilisticLevelHydrogramChart: 'floodproofs.probabilistic.level',
  MultiDeterministicHydrogramChart: 'floodproofs.multideterministic',
  NwpGfsProbabilisticHydrogramsChart: 'floodproofs.nwpgfsprobabilistic',
  NwpGfsMaximumHydrogramChart: 'floodproofs.nwpgfsmaximum',
};

export class SERIESLayerManager extends BaseLayerManager {
  protected get<T>(url: string, params?: any): Observable<T> {
    let server = this.env.server.baseUrl + '/dewetra3/';
    return this.http.get<T>(server + url, { params: params });
  }

  protected post<T>(url: string, body?: any, params?: any): Observable<T> {
    let server = this.env.server.baseUrl + '/dewetra3/';
    return this.http.post<T>(server + url, body, { params: params });
  }

  public async loadSections(dateFrom: Date, dateTo: Date | 'now'): Promise<GeoJsonObject | GeoJsonObject[]> {
    const properties = await firstValueFrom(
      this.get<GeoJsonObject | GeoJsonObject[]>(
        'ddsapi/floodproof/layer/' + this.getLayerModel().id + '/' + dateToSeconds(dateTo) + '/'
      )
    );
    return properties;
  }

  async loadCompatibles(): Promise<Compatibles> {
    const compatibles = await firstValueFrom(
      this.get<Compatibles>('ddsapi/floodproof/compatibles/' + this.getLayerModel().id + '/')
    );
    return compatibles;
  }

  compatibles: Compatibles;

  async loadChart(
    type: string,
    eventData: SERIELayerEventData,
    layerData: LayerDataContainer,
    dateFrom: Date,
    dateTo: Date
  ): Promise<any> {
    const featureProperties = eventData.feature.properties;
    const serie_id = this.getLayerModel().dataid;
    const chartIdFromModel = getCustomPropertiesByKey(this.getLayerModel(), serie_id)?.chart_id;

    const chart_id = chartIdFromModel.indexOf(';') > -1 ? chartIdFromModel.split(';')[0] : chartIdFromModel;
    const chartProperties = getCustomChartProperties(this.getLayerModel());
    const properties = layerData.properties as SERIELayerManagerProperties;
    const compatibles = properties.compatibles;
    const selectedCompatible = compatibles.compatibles.filter((compatible: Compatible) => compatible.id == serie_id)[0];
    const feature_id = eventData.feature.properties[selectedCompatible.fidField];

    this.postActivityLog('chartid:' + chart_id + ' serieid:' + serie_id + ' featureid:' + feature_id, 'chart-loaded');

    const params = {
      layer_id: this.getLayerModel().id.toString(),
      serie_id: serie_id,
      feature_id: feature_id,
      chart_id: chart_id,
      dt1: dateToSeconds(dateFrom).toString(),
      dt2: dateToSeconds(dateTo).toString(),
    };

    return await firstValueFrom(
      this.post<any>(
        'chartapi/dds_' + type + '/',
        { feature: featureProperties, chart_properties: chartProperties[chart_id] },
        params
      )
    ); // json or img
  }

  async loadChartByCompatible(
    type: string,
    eventData: SERIELayerEventData,
    compatible: Compatible,
    chart_id: string,
    dateFrom: Date,
    dateTo: Date
  ): Promise<any> {
    const featureProperties = eventData.feature.properties;
    const serie_id = compatible.id;
    const fidField = compatible.fidField;
    const chartProperties = getCustomChartProperties(this.getLayerModel());
    const feature_id = eventData.feature.properties[fidField];

    chart_id = chart_id ? dictOldChartTypes[chart_id] : chart_id; // compatibility with old chart types definition

    this.postActivityLog('chartid:' + chart_id + 'serieid:' + serie_id + 'featureid:' + feature_id, 'chart-loaded');

    const params = {
      layer_id: this.getLayerModel().id.toString(),
      serie_id: serie_id,
      feature_id: feature_id,
      chart_id: chart_id,
      dt1: dateToSeconds(dateFrom).toString(),
      dt2: dateToSeconds(dateTo).toString(),
    };

    return await firstValueFrom(
      this.post<any>(
        'chartapi/dds_' + type + '/',
        { feature: featureProperties, chart_properties: chartProperties[chart_id] },
        params
      )
    ); // json or img
  }

  async getDefaultProperties(dateFrom: Date, dateTo: Date): Promise<BaseLayerManagerProperties> {
    const compatibles = await this.loadCompatibles();
    return {
      compatibles: compatibles,
      dateFrom,
      dateTo,
    } as SERIELayerManagerProperties;
  }

  async getLayerData(properties: BaseLayerManagerProperties): Promise<SERIELayerData> {
    const sections = await this.loadSections(properties.dateFrom, properties.dateTo);
    return {
      sections: sections,
    } as SERIELayerData;
  }

  public override getSeries$(
    eventData: SERIELayerEventData,
    dateFrom: Date,
    dateTo: Date
  ): Observable<SERIEGetSeriesResult> {
    return this.data$.pipe(
      switchMap((layerData: LayerDataContainer) => {
        const chart = this.loadChart('json', eventData, layerData, dateFrom, dateTo);

        return forkJoin([chart]).pipe(
          map((chart) => {
            return {
              status: 'loaded',
              data: {
                chart: chart,
              },
            } as SERIEGetSeriesResult;
          }),
          startWith({ status: 'loading' } as SERIEGetSeriesResult),
          catchError((error) => {
            const errorMessage = `Error retrieving series for layer ${this.layerModel.name}. Status ${error.status}`;
            return of({ status: 'error', error: errorMessage } as SERIEGetSeriesResult);
          })
        );
      })
    );
  }

  public override getLayerDetail$(): Observable<string> {
    return this.data$.pipe(
      filter((ld) => !!ld && !!ld.data && !!ld.properties),
      map((ld) => {
        const data = ld.data as SERIELayerData;
        const sections = data.sections as FeatureCollection;
        const features = Array.isArray(sections.features) ? sections.features : [];

        if (ld.status === 'loading') {
          return 'LOADING_LAYER';
        }

        if (ld.status === 'error') {
          return ld.error || 'ERROR_READING_LAYER';
        }

        if (features.length === 0) {
          return 'NO_SECTIONS';
        }

        // ② >=1 feature (non >1)
        const first = features[0].properties || {};
        const runRaw = first.run;
        const runMmRaw = first.run_mm;

        const dateToRaw = (ld.properties as SERIELayerManagerProperties).dateTo;

        // ③ parsing più robusto
        const dRun = parseUnixTimestampOrDateFormatted(runRaw);
        const dModel = parseUnixTimestampOrDateFormatted(runMmRaw);

        const isValidRun = dRun.isValid && typeof dRun.format === 'function';
        const isValidModel = dModel.isValid && typeof dModel.format === 'function';

        if (isValidRun && isValidModel) {
          return `Run: ${dRun.format('YYYY/MM/DD HH:mm')} - Meteo Model: ${dModel.format('YYYY/MM/DD HH:mm')}`;
        }

        if (isValidRun) {
          return `Run: ${dRun.format('YYYY/MM/DD HH:mm')} `;
        }

        // fallback sulla proprietà dateTo
        return `Data di validità: ${format(dateToRaw, 'dd/MM/yyyy HH:mm')}`;
      }),
      // ④ catturo eventuali eccezioni e restituisco un fallback
      catchError((err) => {
        console.error('Errore in getLayerDetail$', err);
        return of('ERROR_READING_LAYER');
      })
    );
  }
}
