import {Component, Input, inject} from '@angular/core';
import {BaseLayerManager} from '../../../managers/base/base.manager';
import {LegendItemTypeSeries} from '../../../models/serie';
import {buildSVGShape} from '../../../utils/utils';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'dewetra3-floodproof-legend',
  template: `
    <div class="legend">
      <div class="legend-title"></div>
      <div class="legend-content">
        @if (manager.getLayerModel().legendmanager.props; as legendProps) {
          @for (legendItem of legendProps.default.legend; track $index) {
            <div class="legend-item">
              <div class="legend-item-color">
                <div class="legend-item-label">{{ legendItem.label }}</div>
                <div class="legend-item-icon" [innerHTML]="buildImage(legendItem)"></div>
              </div>
            </div>
          }
        }
      </div>
    </div>
  `,
  styleUrls: [],
})
export class FLOODPROOFSLegendComponent {

  @Input() manager!: BaseLayerManager;

  sanitaizer = inject(DomSanitizer);

  buildImage(legendItem: LegendItemTypeSeries) {
    const unSanitazedHml = buildSVGShape(legendItem.shape, legendItem.color, legendItem.alpha, legendItem.stroke_color, legendItem.stroke_alpha, legendItem.stroke_width, '20', '20', 1);
    return this.sanitaizer.bypassSecurityTrustHtml(unSanitazedHml);
  }

}
