import { AfterViewInit, ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';

import { BaseLayerManager } from '../../../managers/base/base.manager';
import { LegendComponentFactory } from '../../legend-component-factory.service';

@Component({
  selector: 'dewetra3-legend-wrapper',
  template: `
    <ng-container *ngIf="component">
          <ndc-dynamic
            [ndcDynamicComponent]="component"
            [ndcDynamicInputs]="{manager}"
        ></ndc-dynamic>

    </ng-container>
  `,
  styleUrls: []
})
export class LegendWrapperComponent implements AfterViewInit {
  @Input() manager: BaseLayerManager;

  public component!: any;

  constructor(
    private propertiesFactory: LegendComponentFactory,
    private cdr: ChangeDetectorRef
  ) { }

  ngAfterViewInit(): void {
    this.component = this.propertiesFactory.create(this.manager.getLayerModel());
    this.cdr.detectChanges();
  }


}
