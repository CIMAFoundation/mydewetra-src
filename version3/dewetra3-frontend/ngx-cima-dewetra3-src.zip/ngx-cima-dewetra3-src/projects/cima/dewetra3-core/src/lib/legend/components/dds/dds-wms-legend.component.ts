import { Component, effect, Input, OnInit, signal } from '@angular/core';
import { DDSLayerData, DDSLayerManager } from '../../../managers/dds/dds.manager';
import { DewapiLayerStyleResponse } from '../../../models/legend';

@Component({
  selector: 'dewetra3-dds-wms-legend',
  template: `
    <div class="legend">
      <div class="legend-title"></div>

      @if (loading()) {
        <div class="d-flex w-100 align-items-center justify-content-center py-2">
          <mat-spinner></mat-spinner>
        </div>
      }

      @if(wmsLegendUrl()){
        <div class="legend-content">
          <img [src]="wmsLegendUrl()" alt="Legenda"/>
        </div>
      }

      @if (errorMessage()) {
        <div class="error-message">{{ errorMessage() }}</div>
      }

    </div>
  `,
  styleUrls: [],
})
export class DDSWMSLegendComponent implements OnInit {
  @Input() manager!: DDSLayerManager;

  legend = signal<DewapiLayerStyleResponse>({ legend: [] });
  loading = signal<boolean>(false);
  errorMessage = signal<string>('');
  wmsLegendUrl = signal<string>('');

  constructor() {
    effect(
      () => {
        if (!this.manager) return;

        this.loading.set(true);
        this.errorMessage.set('');

        this.manager.getData$().subscribe({
          next: async (data) => {
            try {
              const layerData = data?.data as DDSLayerData;
              if (layerData?.published?.layerid) {
                this.wmsLegendUrl.set(
                  `${layerData.serverUrl}?service=WMS&request=GetLegendGraphic&format=image/png&width=20&height=20&layer=${layerData.published.layerid}`
                );
                return;
              }

              this.errorMessage.set('Nessuna legenda disponibile.');
            } catch (error) {
              console.error('Errore nel caricamento della legenda', error);
              this.errorMessage.set('Impossibile caricare la legenda.');
            } finally {
              this.loading.set(false);
            }
          },
          error: (err) => {
            console.error('Errore nel recupero dei dati della legenda', err);
            this.errorMessage.set('Errore nel recupero dei dati.');
            this.loading.set(false);
          },
        });
      },
      { allowSignalWrites: true } // Allow writing to signals inside the effect
    );
  }

  ngOnInit(): void {}
}
