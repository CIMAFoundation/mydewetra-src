import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { AuthService, CimaEnvironment } from '@cima/commons';
import { LayerModel } from '../models/dewetra3-layer';
import { LayerDataContainer } from '../models/models';
import { BaseLayerManager } from './base/base.manager';
import { DDSWFSLayerManager } from './dds/dds.wfs.manager';
import { DDSWMSLayerManager } from './dds/dds.wms.manager';
import { ForecastDDSWMSLayerManager } from './dds/forecast.dds.wms.manager';
import { ObservationDDSWMSLayerManager } from './dds/observation.dds.wms.manager';
import { RainMapDDSLayerManager } from './dds/rainmap.wms.manager';
import { SENTINELLayerManager } from './sentinel/sentinel.manager';
import { WARNINGSLayerManager } from './sentinel/warnings.manager';
import { SERIESLayerManager } from './serie/serie.manager';
import { StaticWMSLayerManager } from './static/static.manager';
import { WMSTCapabilitiesManager } from './wmst/wmst-capabilities.manager';
import { WMSTLayerManager } from './wmst/wmst.manager';

@Injectable({
  providedIn: 'root',
})
export class LayerManagerFactory {
  static DEFAULT_MANAGERS = {
    DDSWMSLayerManager: DDSWMSLayerManager,
    DDSWFSLayerManager: DDSWFSLayerManager,
    STATICWMSLayerManager: StaticWMSLayerManager,
    WMSTLayer: WMSTLayerManager,
    WMSTCapabilitiesLayer: WMSTCapabilitiesManager,
    SENTINELLayerManager: SENTINELLayerManager,
    SERIESLayerManager: SERIESLayerManager,
    WARNINGSLayerManager: WARNINGSLayerManager,
    RainMapDDSLayerManager: RainMapDDSLayerManager,
    ObservationDDSWMSLayerManager: ObservationDDSWMSLayerManager,
    ForecastDDSWMSLayerManager: ForecastDDSWMSLayerManager,
  };

  private _registry: Map<string, any> = new Map(Object.entries(LayerManagerFactory.DEFAULT_MANAGERS));
  //@Inject('env') private env: CimaEnvironment

  constructor(private http: HttpClient, @Inject('env') private env: CimaEnvironment, private auth: AuthService) {}

  set(name: string, component: any) {
    this._registry.set(name, component);
  }

  create(layerModel: LayerModel, data?: LayerDataContainer): BaseLayerManager {
    let klass = this._registry.get(layerModel.layermanager.component);

    if (!klass) {
      throw new Error(`Manager for ${layerModel.layermanager.component} not found in registry`);
    }

    const component = new klass(this.env, this.auth, this.http, layerModel);

    if (data) {
      component.data$.next(data);
    }

    return component;
  }
}
