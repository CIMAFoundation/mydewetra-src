
export interface DDSLayerProperties {
  layerProperties: DDSLayerProperty;
}

export interface DDSLayerProperty {
  attributes?: DDSAttribute[];
  data?: string;
  description?: string;
  id: string;
  longDescription?: string;
}

export interface DDSAttribute {
  descr?: string;
  entries?: Entry | Entry[];
  name: string;
  selectedEntry: Entry;
  type?: string;
  visible?: string;
}

export interface Entry {
  descr?: string;
  referredValues?: ReferrableValue;
  value: string;
}

export interface ReferrableValue {
  entry: ReferrableValues | ReferrableValues[];
}
export interface ReferrableValues {
  key: string;
  value: string;
}

export interface FolderView {
  id: string;
  name: string;
  descr: string;
  choices: Choice[];
}

export interface Choice {
  id: string;
  name: string;
  descr: string;
  choices?: Choice[];
  //opened?: boolean;
  layers?: number[];
}
