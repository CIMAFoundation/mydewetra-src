import * as L from 'leaflet';
import { WMSTLayerData, WMSTLayerManagerProperties } from '../../../managers/wmst/wmst.manager';
import { LayerDataContainer } from '../../../models/models';
import { BaseLayer } from '../base/base.layer';

export class WMSTLayerLeaflet extends BaseLayer {
  private wmsLayer: L.TileLayer.WMS;

  bringToFront(): void {
    this.wmsLayer?.bringToFront();
  }

  bringToBack(): void {
    this.wmsLayer?.bringToBack();
  }

  override async updateMapLayer(layerData: LayerDataContainer): Promise<void> {
    const data = layerData.data as WMSTLayerData;
    const properties = layerData.properties as WMSTLayerManagerProperties;

    if (this.wmsLayer) {
      this.map?.removeLayer(this.wmsLayer);
    }

    properties.wmsparams = properties.wmsparams || {};

    const params = {
      layers: data.layerid,
      format: 'image/png',
      //@ts-ignore Time properties for WMST Layer
      time: data.formattedDate, // TODO to format as descibed in customProperties
      version: '1.3.0',
      transparent: true,
      opacity: 1,
    };
    // Merge additional WMS parameters
    Object.keys(properties.wmsparams).forEach((key) => {
      (params as any)[key] = properties.wmsparams[key];
    });

    // Create and add the new WMS layer
    this.wmsLayer = L.tileLayer.wms(data.serverUrl, params);

    this.map?.addLayer(this.wmsLayer);
  }

  _remove(): void {
    this.map?.removeLayer(this.wmsLayer);
  }

  setOpacity(opacity: number): void {
    this.wmsLayer?.setOpacity(opacity);
  }

  setVisible(visible: boolean): void {
    if (!this.wmsLayer || !this.map) return;

    if (visible) {
      this.map.addLayer(this.wmsLayer);
    } else {
      this.map.removeLayer(this.wmsLayer);
    }
  }

  override getBounds(): L.LatLngBounds {
    const model = this.layer?.getLayerModel();
    const latn = model?.latn || 90;
    const lonw = model?.lonw || -180;
    const lats = model?.lats || -90;
    const lone = model?.lone || 180;
    return L.latLngBounds(L.latLng(latn, lonw), L.latLng(lats, lone));
  }
}
