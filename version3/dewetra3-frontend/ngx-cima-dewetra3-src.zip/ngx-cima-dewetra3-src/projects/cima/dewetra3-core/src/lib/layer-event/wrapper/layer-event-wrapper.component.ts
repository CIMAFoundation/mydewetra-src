import { Component, Input } from '@angular/core';
import { BehaviorSubject, combineLatest, filter, switchMap } from 'rxjs';
import { BaseDewetra3LayerEventData, BaseLayerManager } from '../../managers/base/base.manager';
import { LayerEventComponentFactory } from '../layer-event-component-factory.service';

@Component({
  selector: 'dewetra3-layer-event-wrapper',
  template: `
    @if (component){
        <ndc-dynamic
            [ndcDynamicComponent]="component"
            [ndcDynamicInputs]="{manager, layerEvent, infoEvents$}"
        ></ndc-dynamic>
    }
  `,

  styleUrls: []
})
export class LayerEventWrapperComponent {
  private manager$ = new BehaviorSubject<BaseLayerManager | null>(null);
  @Input() set manager(manager: BaseLayerManager) {
    this.manager$.next(manager);
  };
  public get manager() {
    return this.manager$.getValue();
  }

  private layerEvent$ = new BehaviorSubject<BaseDewetra3LayerEventData | null>(null);
  @Input() set layerEvent(layerEvent: BaseDewetra3LayerEventData) {
    this.layerEvent$.next(layerEvent);
  };
  public get layerEvent() {
    return this.layerEvent$.getValue();
  }

  public infoEvents$ = combineLatest([this.manager$, this.layerEvent$]).pipe(
    filter(([manager, layerEvent]) => !!manager && !!layerEvent),
    switchMap(([manager, layerEvent]) => manager.getLayerEventInfo$(layerEvent))
  );

  public component!: any;


  constructor(
    private infoFactory: LayerEventComponentFactory

  ) { }

  ngOnInit(): void {
    this.component = this.infoFactory.create(this.manager.getLayerModel());
  }
}
