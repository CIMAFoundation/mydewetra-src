import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { CoveragePipePipe } from './coverage-pipe.pipe';
import { DraCategoryPipePipe } from './dra-category-pipe.pipe';
import { HazardPipesPipe } from './hazard-pipes.pipe';
import { InspireThemePipesPipe } from './inspire-theme-pipes.pipe';
import { LayerByStringPipePipe } from './layer-by-string-pipe.pipe';
import { ReversePipe } from './reverse.pipe';
import { TagPipesPipe } from './tag-pipes.pipe';
import { FilterByPunctualSeriesPipe } from './manager-by-type.pipe';
import { ReplacePlaceholderPipe } from './replace-placeholder.pipe';



const _PIPES = [
  ReversePipe,
  TagPipesPipe,
  LayerByStringPipePipe,
  CoveragePipePipe,
  DraCategoryPipePipe,
  HazardPipesPipe,
  InspireThemePipesPipe,
  FilterByPunctualSeriesPipe,
  ReplacePlaceholderPipe
];


@NgModule({
  declarations: _PIPES,
  imports: [
    CommonModule
  ],
  exports: _PIPES
})
export class Dewetra3PipesModule { }
