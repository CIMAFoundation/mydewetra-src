import { AfterViewInit, Component, Input } from '@angular/core';
import { Observable, map } from 'rxjs';
import { BaseLayerManager } from '../../../managers/base/base.manager';
import { Dewetra3MapClick } from '../../../models/models';

@Component({
  selector: 'dewetra3-wmst-copernicus-info',
  template: `
    <div *ngIf="manager">
      <h4 class="mb-1">{{ manager.getName() }}</h4>

      <ng-container *ngIf="infoToDisplay$ | async as info">
        @for (obj of info; track obj.id_render || $index) { @if (obj.type ===
        'layer_tab') {
        <div class="efas_tab"></div>
        } @else if (obj.type === 'table') {
        <div class="efas_table">
          <table class="table table-bordered">
            <caption class="text-gray-200">
              {{
                obj.title
              }}
            </caption>
            <thead>
              <tr>
                <th *ngFor="let headCol of obj.data.header">{{ headCol }}</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let row of obj.data.rows">
                <td *ngFor="let field of row">
                  @if (field?.toString().includes('.gif')) {
                  <img
                    style="width: 30px"
                    [src]="
                      'https://www.efas.eu/efas_frontend/assets/img/' + field
                    "
                  />
                  } @else {
                  <span>{{ field }}</span>
                  }
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        } @else if (obj.type === 'image') {
        <div class="efas_image" >
          <p class="text-gray-200">{{ obj.title }}</p>
          <img
            [src]="obj.data.url"
            [style.width.px]="obj.data.width"
            [style.height.px]="obj.data.height"
          />
        </div>

        } @else if (obj.type === 'square') {
        <div class="efas_square">
          <table class="table table-bordered">
            <caption class="text-gray-200">
              {{
                obj.title
              }}
            </caption>
            <thead class="thead">
              <tr>
                <th *ngFor="let headCol of obj.data.header">{{ headCol }}</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let row of obj.data.rows">
                <td class="td"
                  *ngFor="let field of row"
                  [style.backgroundColor]="
                    field.background_color !== 'None'
                      ? '#' + field.background_color
                      : 'transparent'
                  "
                >
                  <span *ngIf="field.value !== 'None'">{{ field.value }}</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        } @else {
        <div>Unsupported type: {{ obj.type }}</div>
        } }
      </ng-container>
    </div>
  `,
  styles: [
    `
      .label {
        font-weight: bold;
        color: var(--dewetra-orange);
      }

      /*===============================================*/
      /*====================TABELLA====================*/
      /*===============================================*/

      table {
        font-size: 1em;
        border-collapse: collapse;
        width: 100%;
        background-color: white;
      }

      thead{
        background-color:rgb(230, 144, 16);
      }

      td{
        border: 1px solid #ddd;
        color: black;
      }
      
      .efas_image {
        background-color: whitesmoke;
      }
    `,
  ],
})
export class WMSTCopernicusLayerInfoComponent implements AfterViewInit {
  @Input() manager!: BaseLayerManager;
  @Input() infoEvents$!: Observable<any>;
  @Input() clickData: Dewetra3MapClick;

  infoToDisplay$: Observable<any>;

  ngAfterViewInit(): void {
    this.infoToDisplay$ = this.infoEvents$.pipe(
      map((info: any) => {
        return info.wmsData[0];
      })
    );
  }
}
