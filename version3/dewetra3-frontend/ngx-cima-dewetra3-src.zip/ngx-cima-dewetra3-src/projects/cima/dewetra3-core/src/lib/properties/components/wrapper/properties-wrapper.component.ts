import {AfterViewInit, Component, Input, OnInit} from '@angular/core';
import {PropertiesComponentFactory} from '../../properties-component-factory.service';
import {BaseLayerManager} from '../../../managers/base/base.manager';

@Component({
  selector: 'dewetra3-properties-wrapper',
  template: `
    <ng-container *ngIf="component">
      <ndc-dynamic
        [ndcDynamicComponent]="component"
        [ndcDynamicInputs]="{manager}"
      ></ndc-dynamic>
    </ng-container>
  `,
  styleUrls: []
})
export class PropertiesWrapperComponent implements AfterViewInit {
  @Input() manager: BaseLayerManager;

  public component!: any;

  constructor(
    private propertiesFactory: PropertiesComponentFactory
  ) {
  }

  ngAfterViewInit(): void {
    this.component = this.propertiesFactory.create(this.manager.getLayerModel());
  }


}
