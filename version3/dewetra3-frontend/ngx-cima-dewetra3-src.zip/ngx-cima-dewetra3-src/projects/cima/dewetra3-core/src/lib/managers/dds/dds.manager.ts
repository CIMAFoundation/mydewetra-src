import * as Plotly from 'plotly.js';
import {
  combineLatest,
  distinctUntilChanged,
  filter,
  first,
  firstValueFrom,
  from,
  map,
  Observable,
  of,
  shareReplay,
  switchMap,
  takeWhile,
  tap,
} from 'rxjs';
import {
  DDSLayerAvailability,
  DDSLayerPublishRequest,
  DDSLayerPublishResponse,
  DDSLayerPublishResponseMovieMessage,
} from '../../models/layer-availability';
import { DDSLayerProperties } from '../../models/layer-properties';
import { DewapiLayerStyleResponse } from '../../models/legend';
import {
  BaseLayerManagerData,
  BaseLayerManagerProperties,
  BaseMapInfoResult,
  BasePunctualSeriesResult,
  LayerDataContainer,
  WMSInfoResponse,
} from '../../models/models';
import {
  dateToSeconds,
  getWMSLayerInfoUrl,
  parseUnixTimestampOrDateFormatted,
  WMSInfoOptions,
} from '../../utils/utils';
import { BaseLayerManager } from '../base/base.manager';

export interface DDSLayerManagerProperties extends BaseLayerManagerProperties {
  ddsProperties: DDSLayerProperties;
  item: DDSLayerAvailability;
  isMovieAllowed?: boolean;
}

export interface DDSLayerData extends BaseLayerManagerData {
  published: DDSLayerPublishResponse;
  serverUrl: string;
}

export interface DDSLayerMapInfoResult extends BaseMapInfoResult {
  wmsData: WMSInfoResponse;
}

export interface DDSLayerPunctualSeriesResult extends BasePunctualSeriesResult {
  data: Plotly.Data[] | any;
}

interface portalMessage {
  app: string;
  dt: string;
  text: string;
}

interface CreateMovieResponse {
  task_id: string;
  publication: DDSLayerPublishResponseMovieMessage;
}

export class DDSLayerManager extends BaseLayerManager {
  private playTimer: any = null;

  /** HTTP GET wrapper **/
  protected get<T>(url: string, params?: any): Observable<T> {
    const server = this.env.server.baseUrl + '/dewetra3/';
    return this.http.get<T>(server + url, { params });
  }

  /** HTTP POST wrapper **/
  protected post<T>(url: string, payload: any): Observable<T> {
    const server = this.env.server.baseUrl + '/dewetra3/';
    return this.http.post<T>(server + url, payload);
  }

  /** WATCH for NEWACQ via WebSocket **/
  public override watch() {
    this.stopWatch();
    console.info('watching for NEWACQ: ' + this.layerModel.dataid);
    this.watchSubscription = this.getWebSocket('portal.*')
      .pipe(
        filter((msg: portalMessage) => msg.app === 'dewetra3' && msg.text === 'NEWACQ;' + this.layerModel.dataid),
        tap(() => console.log('NEWACQ for', this.layerModel.dataid)),
        switchMap(() => this.getProperties$().pipe(first()))
      )
      .subscribe((props) => {
        const ddsProps = props as DDSLayerManagerProperties;
        ddsProps.dateTo = new Date();
        ddsProps.item = null; // reset item to force reloading
        this.applyProperties(ddsProps);
      });
  }

  public override stopWatch() {
    if (this.watchSubscription) {
      console.info('stop watching for NEWACQ: ' + this.layerModel.dataid);
      this.watchSubscription.unsubscribe();
    }
  }

  /** AVAILABILITY **/
  async getAvailability(
    properties: DDSLayerProperties,
    dateFrom: Date,
    dateTo: Date | 'now'
  ): Promise<DDSLayerAvailability[]> {
    try {
      return await firstValueFrom(
        this.post<DDSLayerAvailability[]>('ddsapi/availability/' + this.layerModel.id + '/', {
          props: properties.layerProperties,
          from: dateToSeconds(dateFrom),
          to: dateToSeconds(dateTo),
        })
      );
    } catch (err) {
      this.setError(err as string);
      return [];
    }
  }

  /** LAYER STYLE **/
  async getLayerStyle(): Promise<DewapiLayerStyleResponse> {
    const data = this.data$.value.data as DDSLayerData;
    return await firstValueFrom(
      this.get<DewapiLayerStyleResponse>(`ddsapi/layerstyle/${this.getLayerModel().id}/${data.published.layerid}/`)
    );
  }

  /** PUBLISH / REPUBLISH **/
  async publishData(req: DDSLayerPublishRequest): Promise<DDSLayerPublishResponse> {
    console.info('Publishing layer', this.layerModel.name);
    return await firstValueFrom(this.post<DDSLayerPublishResponse>(`ddsapi/publish/${this.layerModel.id}/`, req));
  }

  async rePublishData(req: DDSLayerPublishRequest): Promise<DDSLayerPublishResponse> {
    console.info('Re-publishing layer', this.layerModel.name);
    return await firstValueFrom(this.post<DDSLayerPublishResponse>(`ddsapi/republish/${this.layerModel.id}/`, req));
  }

  defaultDDPropertiesRequest(){
    return this.get<DDSLayerProperties>('ddsapi/properties/' + this.layerModel.id + '/');
  }

  async getDefaultProperties(dateFrom: Date, dateTo: Date): Promise<DDSLayerManagerProperties> {
    const ddsProps = await firstValueFrom(this.get<DDSLayerProperties>(`ddsapi/properties/${this.layerModel.id}/`));
    const avail = await this.getAvailability(ddsProps, dateFrom, dateTo);
    if (!avail.length) {
      this.setError('No data available');
      return null;
    }
    const item = avail[0];
    const movieAllowed = await this.movieAllowed(ddsProps);
    return { ddsProperties: ddsProps, item, dateFrom, dateTo, isMovieAllowed: movieAllowed };
  }

  /** GET LAYER DATA **/
  override async getLayerData(props: DDSLayerManagerProperties): Promise<DDSLayerData> {
    const availability = await this.getAvailability(props.ddsProperties, props.dateFrom, props.dateTo);
    if (!availability.length) {
      this.setError('No data available');
      return null;
    }
    // // ensure props.item still valid
    if (!availability.find((a) => a.id === props?.item?.id)) {
      props.item = availability[0];
    }
    const published = await this.rePublishData({
      props: props.ddsProperties,
      data: props.item,
      from: dateToSeconds(props.dateFrom),
      to: dateToSeconds(props.dateTo),
    });

    return { serverUrl: this.layerModel.server.url + '/wms', published } as DDSLayerData;
  }

  /** CHECK MOVIE ALLOWED **/
  async movieAllowed(ddsProps: DDSLayerProperties): Promise<boolean> {
    try {
      const resp = await firstValueFrom(
        this.post<any>('ddsapi/is_movie_allowed/', { props: ddsProps.layerProperties })
      );
      return resp.status === 'OK';
    } catch {
      return false;
    }
  }

  /** OBSERVABLE FLAG **/
  public override hasMovie$(): Observable<boolean> {
    return this.getProperties$().pipe(
      filter(
        (props): props is DDSLayerManagerProperties => !!props && !!(props as DDSLayerManagerProperties).ddsProperties
      ),
      map((p) => Boolean((p as DDSLayerManagerProperties).isMovieAllowed)),
      distinctUntilChanged()
    );
  }

  // ——————————————————————————————————————————————
  //  M O V I E   P I P E L I N E   M E T H O D S
  // ——————————————————————————————————————————————

  /** 1) create movie task **/
  private createMovieTask$(props: DDSLayerManagerProperties, data: DDSLayerData): Observable<CreateMovieResponse> {
    this.postActivityLog('', 'create_movie_task');

    // Get availability and group by date/run date
    return from(this.getAvailability(props.ddsProperties, props.dateFrom, props.dateTo)).pipe(
      tap((availList) => {
        // qui inizializzo progressMap.frames una sola volta
        const initFrames = availList.map((item) => ({
          availability: item,
          loaded: false,
          layer: undefined as DDSLayerPublishResponseMovieMessage | undefined,
        }));
        this.currentMovieState.set({
          ...this.currentMovieState(),
          progressMap: {
            frames: initFrames,
            currentIndex: 0,
            canProceed: false,
          },
        });
      }),
      map((availability) => {
        // Select the first available item or handle as needed
        const avail = availability;
        const payload = {
          props: props.ddsProperties,
          data: avail,
          from: dateToSeconds(props.dateFrom),
          to: dateToSeconds(props.dateTo),
        };
        return payload;
      }),
      switchMap((payload) =>
        // Qui riceviamo { task_id, publication }
        this.post<CreateMovieResponse>(`ddsapi/create_movie_task/${this.layerModel.id}/`, payload)
      )
    );
  }

  /** 2) start movie task **/
  private startMovieTask$(taskId: string): Observable<void> {
    this.postActivityLog('', 'start_movie_task');
    return this.get<void>(`ddsapi/start_movie_task/${taskId}/`);
  }

  /** 3) monitor movie progress **/
  private monitorMovieTask$(taskId: string): Observable<DDSLayerPublishResponseMovieMessage> {
    return this.getWebSocket(taskId).pipe(
      //tap((msg: DDSLayerPublishResponseMovieMessage) => console.log(msg)),
      takeWhile((msg: any) => msg.status !== 'completed' && msg.status !== 'error', true)
    );
  }

  public override play(): void {
    if (this.currentMovieState().status === 'playing') return;

    this.clearPlayTimer();
    this.currentMovieState.set({ ...this.currentMovieState(), status: 'loading' });

    // 1) Creo il task
    combineLatest({
      props: this.getProperties$().pipe(first()),
      data: this.getData$().pipe(first()),
    })
      .pipe(
        first(),
        switchMap(({ props, data }) =>
          this.createMovieTask$(props as DDSLayerManagerProperties, (data as LayerDataContainer).data as DDSLayerData)
        )
      )
      .subscribe({
        next: (res: CreateMovieResponse) => {
          // 2) Memorizzo taskId e pubblicazione iniziale
          this.currentMovieState.set({ ...this.currentMovieState(), taskId: res.task_id });
          this.updateMovieProgress(res.publication);

          // 3) Mi collego al monitor **prima** di partire
          this.monitorMovieTask$(res.task_id)
            .pipe(
              tap((msg: DDSLayerPublishResponseMovieMessage) => {
                // aggiorno lo stato interno
                this.updateMovieProgress(msg);
                // mostro subito il frame appena arrivato
                // const d = this.data$.value.data as DDSLayerData;
                // this.setData({ ...d, published: msg });
              }),
              takeWhile((msg) => msg.status !== 'completed' && msg.status !== 'error', true)
              //finalize(() => this.currentMovieState.set({ ...this.currentMovieState(), status: 'idle' }))
            )
            .subscribe();

          // 4) Solo dopo faccio partire il movie task
          this.startMovieTask$(res.task_id).pipe(first()).subscribe();
        },
        error: (err) => {
          err = err || 'error-creating-movie-task';
          this.setError(err as string);
        },
      });
  }

  /** STOP **/
  public override stop(): void {
    this.clearPlayTimer();
    const ms = this.currentMovieState();
    if (ms.status === 'playing' || ms.status === 'loading') {
      this.currentMovieState.set({ ...ms, status: 'idle' });
    }
  }

  /** AGGIORNA PROGRESSO SINGOLO FRAME **/
  private updateMovieProgress(msg: DDSLayerPublishResponseMovieMessage) {
    if (!msg.item) return;
    const ms = this.currentMovieState();
    const pm = ms.progressMap;
    const idx = pm.frames.findIndex((f) => f.availability.id === msg.item.id);
    if (idx < 0) return;
    pm.frames[idx].loaded = true;
    pm.frames[idx].layer = msg;
    // se il frame corrente è pronto, sblocca
    const current = pm.frames[pm.currentIndex];
    pm.canProceed = !!current?.loaded;
    this.currentMovieState.set({ ...ms, progressMap: pm });
    // avvia l’animazione se possibile
    if (ms.status !== 'playing' && pm.canProceed) {
      this.startFrameInterval();
    }
  }

  /** next/previous **/
  public override next(): void {
    this.stepFrame(1);
  }
  public override previous(): void {
    this.stepFrame(-1);
  }

  /** INTERNO: cambia frame **/
  private stepFrame(delta: 1 | -1): void {
    const ms = this.currentMovieState();
    const pm = ms.progressMap;
    let i = pm.currentIndex + delta;
    if (ms.status === 'playing' && i >= pm.frames.length) i = 0;
    if (i < 0 || i >= pm.frames.length) return;
    const frame = pm.frames[i];
    const can = !!frame.loaded;
    this.currentMovieState.set({ ...ms, progressMap: { ...pm, currentIndex: i, canProceed: can } });
    if (frame.layer) {
      const d = this.data$.value.data as DDSLayerData;
      this.setData({ ...d, published: frame.layer });
    }
  }

  /** TIMER per l’autoplay **/
  private startFrameInterval() {
    this.clearPlayTimer();
    // metti la status a “playing”
    this.currentMovieState.set({ ...this.currentMovieState(), status: 'playing' });

    // 2.a) mostra immediatamente il frame corrente
    this.showCurrentFrame();

    // 2.b) poi ogni 2 s fai next()
    this.playTimer = setInterval(() => this.next(), 2000);
  }

  /** Nuovo helper per mostrare il frame all’indice currentIndex */
  private showCurrentFrame() {
    const ms = this.currentMovieState();
    const pm = ms.progressMap;
    const frame = pm.frames[pm.currentIndex];
    if (frame.loaded && frame.layer) {
      const d = this.data$.value.data as DDSLayerData;
      this.setData({ ...d, published: frame.layer });
    }
  }

  private clearPlayTimer() {
    if (this.playTimer) {
      clearInterval(this.playTimer);
      this.playTimer = null;
    }
  }

  /** DETAIL **/
  public override getLayerDetail$(): Observable<string> {
    return this.data$.pipe(
      filter((ld) => !!ld && !!ld.data && !!ld.properties),
      map((ld) => {
        const data = ld.data as DDSLayerData;
        const p = ld.properties as DDSLayerManagerProperties;
        if (ld.status === 'error') return 'ERROR LOADING LAYER';

        const variable =
          p.ddsProperties.layerProperties.attributes?.find((a) => a.name === 'variable')?.selectedEntry?.descr ||
          'Unknown Variable';

        const parts = data.published.layerid.split('_').slice(-2);
        const dateRun = parseUnixTimestampOrDateFormatted(parts[0]);
        const dateRef = parseUnixTimestampOrDateFormatted(parts[1]);

        if (dateRun.isValid() && dateRef.isValid()) {
          return `${dateRef.format('DD/MM/YYYY HH:mm')} (Run:${dateRun.format(
            'DD/MM/YYYY HH:mm'
          )} ) &nbsp;${variable} `;
        } else if (dateRun.isValid()) {
          return `${dateRef.format('DD/MM/YYYY HH:mm')}  &nbsp;${variable}`;
        } else {
          return variable;
        }
      })
    );
  }

  public override getLayerDownloadUrl$(): Observable<string> {
    return this.data$.pipe(
      // prendi il primo valore valido di data
      filter((ld) => !!ld && !!ld.data),
      first(),
      // estrai il dato pubblicato
      map((ld) => (ld.data as DDSLayerData).published.layerid),
      // chiama l’endpoint DRF
      switchMap((ddsLayerId) =>
        of(`${this.env.server.baseUrl}/dewetra3/ddsapi/download_url/${this.layerModel.id}/${ddsLayerId}/`)
      )
    );
  }

  /** GET INFO **/
  public override getInfo$(latlng: L.LatLng): Observable<BaseMapInfoResult> {
    return this.data$.pipe(
      filter((ld): ld is LayerDataContainer & { data: DDSLayerData } => !!ld && !!ld.data),
      map((ld) => {
        const data = ld.data as DDSLayerData;
        const dataId = data.published.layerid;
        const serverUrl = this.getLayerModel().server.url;
        const props = ld.properties as DDSLayerManagerProperties;

        // 1) Definisci qui le opzioni per buffer + dimensione px
        const opts: WMSInfoOptions = {
          bufferDeg: 2,
          widthPx: 301,
          heightPx: 301,
          extraParams: {},
        };

        const url = getWMSLayerInfoUrl(serverUrl, latlng, dataId, opts);
        console.log('WMS GetFeatureInfo URL:', url);
        return url;
      }),
      switchMap((url) =>
        this.getExternal<WMSInfoResponse>(url).pipe(
          map((wmsData) => ({ wmsData } as DDSLayerMapInfoResult)),
          shareReplay(1)
        )
      )
    );
  }

  public override hasPunctualSeries(): boolean {
    return true;
  }

  /** SELECTED VARIABLE **/
  public getSelectedVariable$(): Observable<string> {
    return this.data$.pipe(
      map((ld) => (ld.properties as DDSLayerManagerProperties).ddsProperties.layerProperties),
      map((lp) => {
        const attr = lp.attributes.find((a) => ['variable', '__variable', 'operation'].includes(a.name));
        return attr?.selectedEntry?.value || '';
      })
    );
  }

  public getTemporalAggregation$(): Observable<string> {
    let temporalAggregation = '';
    return this.data$.pipe(
      map((layerData: LayerDataContainer) => {
        const props = layerData.properties as DDSLayerManagerProperties;
        return props;
      }),
      switchMap((props: DDSLayerManagerProperties) => {
        let selectedTemporalAggregation = props?.ddsProperties?.layerProperties?.attributes?.filter(
          (attr) => attr?.name === 'aggregation' || attr?.descr === 'Cumulative Range'
        )[0]?.selectedEntry?.descr;

        if (selectedTemporalAggregation) {
          temporalAggregation = selectedTemporalAggregation;
        }
        return temporalAggregation;
      })
    );
  }

  /** UNITÀ DI MISURA **/
  public getSelectedVariableMeasureUnit$(): Observable<string> {
    return this.data$.pipe(
      map((ld) => (ld.properties as DDSLayerManagerProperties).ddsProperties.layerProperties),
      map((lp) => {
        const attr = lp.attributes.find((a) => ['variable', '__variable', 'operation'].includes(a.name));
        const entry = attr?.selectedEntry;
        if (Array.isArray(entry?.referredValues?.entry)) {
          return entry.referredValues.entry.find((e) => ['measureunit', 'mu'].includes(e.key))?.value || '';
        }
        return '';
      })
    );
  }

  /** AGGREGAZIONE **/
  public getAggregation$(): Observable<string> {
    return this.data$.pipe(
      map((ld) => (ld.properties as DDSLayerManagerProperties).ddsProperties.layerProperties),
      map((lp) => {
        const attr = lp.attributes.find((a) => ['aggregation', '__aggregation'].includes(a.name));
        return attr?.selectedEntry?.value || '';
      })
    );
  }

  private cleanup(): void {
    this.clearPlayTimer();
    this.stopWatch();
  }

  public override destroy(): void {
    this.cleanup();
    // Chiama destroy della base class se esiste
    super.destroy?.();
  }
}
