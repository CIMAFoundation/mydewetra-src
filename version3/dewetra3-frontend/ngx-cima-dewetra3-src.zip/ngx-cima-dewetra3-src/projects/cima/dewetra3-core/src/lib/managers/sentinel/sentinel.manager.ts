import { FeatureCollection, GeoJsonObject } from 'geojson';
import * as Plotly from 'plotly.js';
import {
  BehaviorSubject,
  Observable,
  Subscription,
  bufferTime,
  catchError,
  delayWhen,
  filter,
  forkJoin,
  map,
  of,
  retryWhen,
  startWith,
  switchMap,
  takeLast,
  tap,
  timer,
} from 'rxjs';

import { firstValueFrom } from 'rxjs/internal/firstValueFrom';
import { BaseDewetra3LayerEventData, BaseLayerManager } from '../../managers/base/base.manager';
import {
  BaseLayerManagerData,
  BaseLayerManagerProperties,
  BasePunctualSeriesResult,
  BaseSeriesResult,
  LayerDataContainer,
} from '../../models/models';
import {
  SentinelFeature,
  SentinelFeatureProperties,
  SentinelFeaturePropertiesUpdate,
  SentinelSensorInfoResponse,
} from '../../models/sentinel';
import {
  dateToSeconds,
  getCustomChartProperties,
  getCustomPropertiesByKey,
  getCustomPropertiesObjectKeys,
} from '../../utils/utils';

export interface SENTINELLayerManagerProperties extends BaseLayerManagerProperties {
  aggregationsList: string[];
  aggregationSelected: string;
  cumulatedValueList: number[];
  cumulatedValueSelected: number;
  dateTo: Date;
  dateFrom: Date;
}

export interface SENTINELLayerData extends BaseLayerManagerData {
  sentinelResponse: GeoJsonObject | GeoJsonObject[];
  sensorClass: string;
  thresholdGroup: string;
  serieId?: string;
  sensorGroup?: string;
}

export interface SENTINELGetSeriesResult extends BasePunctualSeriesResult {
  status: 'loading' | 'loaded' | 'error';
  type?: 'table' | 'chart';
  data: SENTINELSerieResultData | SENTINELSerieResultDataAggregatedFeature;
}

export interface SENTINELAggreWithouGeom {
  id: number;
  name: string;
}

export interface SENTINELSerieResultData {
  chart: Plotly.Data[] | any;
  sensorInfo: SentinelSensorInfoResponse;
  stationSensor: SentinelSensorInfoResponse[];
}

export interface SENTINELSerieResultDataAggregatedFeature {
  sensors: SentinelFeature[];
  aggrLayerWithoutGeom?: any;
}

export interface SENTINELLayerEventData extends BaseDewetra3LayerEventData {
  feature: SentinelFeature;
}

/**
 * Manages the SENTINEL layer functionality.
 */
export class SENTINELLayerManager extends BaseLayerManager {
  protected get<T>(url: string, params?: any): Observable<T> {
    let server = this.env.server.baseUrl + '/dewetra3/';
    return this.http.get<T>(server + url, { params: params });
  }

  protected post<T>(url: string, body?: any, params?: any): Observable<T> {
    let server = this.env.server.baseUrl + '/dewetra3/';
    return this.http.post<T>(server + url, body, { params: params });
  }

  // Create a behaviour subject that emit every minute to update the sensors
  private updateSensorStore = new BehaviorSubject<SentinelFeaturePropertiesUpdate[]>([]);
  private updateSensorSubscription: Subscription;

  public override watch() {
    if (this.watchSubscription) {
      this.watchSubscription.unsubscribe();
    }

    if (this.updateSensorSubscription) {
      this.updateSensorSubscription.unsubscribe();
    }

    this.watchSubscription = this.getData$()
      .pipe(
        filter((layerData: LayerDataContainer) => {
          return layerData !== null && layerData.data !== null && layerData.data !== undefined;
        }),
        map((layerData: LayerDataContainer) => layerData.data as SENTINELLayerData),
        switchMap((layerData: SENTINELLayerData) => {
          const sensorGroup = layerData?.sensorGroup?.replace('%', '%25');
          const thresholdGroup = layerData?.thresholdGroup;
          return this.getWebSocket(`sentinel.${sensorGroup}.${thresholdGroup}`).pipe(
            retryWhen((errors) =>
              errors.pipe(
                tap((err) => console.error('WebSocket connection error:', err)),
                delayWhen(() => timer(5000)) // Retry after 5 seconds
              )
            ),
            tap((data: SentinelFeaturePropertiesUpdate[]) => {
              console.info(
                'Async Sensors: ' + `sentinel.${sensorGroup}.${thresholdGroup}` + `updated ${data.length} sensors`
              );
              // return data;
            }),
            map((data: SentinelFeaturePropertiesUpdate[]) => {
              return this.updateSensorStore.next(data);
            })
          );
        })
      )
      .subscribe();

    this.updateSensorSubscription = this.getProperties$()
      .pipe(
        filter((properties: BaseLayerManagerProperties) => properties != null), // Checks for null or undefined
        map((properties: BaseLayerManagerProperties) => {
          const sentinelProperties = properties as SENTINELLayerManagerProperties;
          return sentinelProperties.aggregationSelected;
        }),
        switchMap((aggregationSelected: string) => {
          // Dynamically choose buffer time based on the value of aggregationSelected
          const bufferDuration = aggregationSelected === 'none' ? 30000 : 60000; // 10 seconds for 'none', 60 seconds otherwise

          // Buffer the data using the determined buffer duration
          return this.updateSensorStore.pipe(bufferTime(bufferDuration));
        }),
        map((bufferedData: SentinelFeaturePropertiesUpdate[][]) => {
          return bufferedData.flatMap((d: SentinelFeaturePropertiesUpdate[]) => d);
        }),
        filter((bufferedData: SentinelFeaturePropertiesUpdate[]) => bufferedData.length > 0), // Only proceed if there's data in the buffer
        // tap((data) => {
        //   console.info('Async Sensors: loaded aggregated data');
        //   console.log(data);
        // }),
        switchMap((bufferedSensorData: SentinelFeaturePropertiesUpdate[]) => {
          // Update the sensor data
          return this.data$.pipe(
            takeLast(1), // Only take the current value of the observable
            map((layerData: LayerDataContainer) => {
              const layerDataCasted = layerData?.data as SENTINELLayerData;
              const sentinelResponse = layerDataCasted?.sentinelResponse as FeatureCollection;
              sentinelResponse?.features.map((feature: any) => {
                const updatedFeature = bufferedSensorData?.find((d) => d.s === feature.properties.s);
                if (updatedFeature) {
                  feature.properties = { ...feature?.properties, ...updatedFeature };
                }
                return feature;
              });
              layerDataCasted.sentinelResponse = sentinelResponse;
              // this.data$.next(layerDataCasted);
              this.setData(layerDataCasted);
              // return layerData;
            }),
            tap((updatedLayerData) => {
              // Emit the updated layer data
              // this.data$.next(updatedLayerData);
            })
          );
        })
      )
      .subscribe();
  }

  public override stopWatch() {
    try {
      console.info('Stop watching for NEWACQ: ' + this.layerModel.dataid);
      this.watchSubscription?.unsubscribe();
      this.updateSensorSubscription?.unsubscribe();
    } catch (e) {
      console.info('Stop stopping watch subscription: ', e);
    }
  }

  /**
   * Loads the sensors for a given date.
   * @param dateTo The date to load the sensors for.
   * @returns A promise that resolves to a GeoJsonObject representing the loaded sensors.
   */
  async loadSensors(dateTo: Date): Promise<GeoJsonObject> {
    const data = this.data$.getValue().data as SENTINELLayerData;

    const params = new URLSearchParams({
      thr_group: data.thresholdGroup,
      sensor_group: data.sensorGroup,
      dt: dateToSeconds(dateTo).toString(),
    });
    const sensors = await firstValueFrom(
      this.get<GeoJsonObject>('sentinelapi/sensors/' + data.sensorClass + '/?' + params.toString())
    );
    return sensors;
  }

  /**
   * Loads the sensors for a given class and threshold.
   * @param sensorClass The class of the sensors to load.
   * @param threshold The threshold of the sensors to load.
   * @param dateTo The date to load the sensors for.
   * @returns A promise that resolves to a GeoJsonObject representing the loaded sensors.
   */
  async loadSensorsByClassAndThreshold(
    sensorClass: string,
    threshold: string,
    sensor_group: string,
    dateTo: Date
  ): Promise<GeoJsonObject> {
    const params = new URLSearchParams({
      thr_group: threshold,
      sensor_group: sensor_group,
      dt: dateToSeconds(dateTo).toString(),
    });
    const sensors = await firstValueFrom(
      this.get<GeoJsonObject>('sentinelapi/sensors/' + sensorClass + '/?' + params.toString())
    );
    return sensors;
  }

  /**
   * Loads the aggregation list.
   * @returns A promise that resolves to an array of strings representing the aggregation list.
   */
  async loadAggregationList(): Promise<any> {
    const aggregationList = await firstValueFrom(this.get<any>('sentinelapi/aggregations/'));
    aggregationList.push('none');
    return aggregationList;
  }

  /**
   * Loads the aggregated layer for a given date.
   * @param aggr_layer The aggregation layer to load.
   * @param dateTo The date to load the aggregated layer for.
   * @returns A promise that resolves to the loaded aggregated layer.
   */
  async loadAggregatedLayer(aggr_layer: string, dateTo: Date): Promise<any> {
    const data = this.data$.getValue().data as SENTINELLayerData;

    const sensorClass = data.sensorClass;

    const params = new URLSearchParams({
      aggr_layer: aggr_layer,
      thr_group: data.thresholdGroup,
      sensor_group: data.sensorGroup,
      dt: dateToSeconds(dateTo).toString(),
    });

    const aggregatedLayer = await firstValueFrom(
      this.get<any>('sentinelapi/aggregated_layer/' + sensorClass + '/?' + params.toString())
    );
    return aggregatedLayer;
  }

  /**
   * Loads the aggregated data for a given date.
   * @param aggr_layer The aggregation layer to load.
   * @param dateTo The date to load the aggregated data for.
   * @returns A promise that resolves to the loaded aggregated data.
   */
  async loadAggregatedData(aggr_layer: string, dateTo: Date): Promise<any> {
    const data = this.data$.getValue().data as SENTINELLayerData;
    const sensorClass = data.sensorClass;

    const params = new URLSearchParams({
      aggr_layer: aggr_layer,
      thr_group: data.thresholdGroup,
      sensor_group: data.sensorGroup,
      dt: dateToSeconds(dateTo).toString(),
    });

    const aggregatedLayer = await firstValueFrom(
      this.get<any>('sentinelapi/aggregated_data/' + sensorClass + '/?' + params.toString())
    );
    return aggregatedLayer;
  }

  async loadSensorsByAggregatedFeature(feature_id: string, dateTo: Date): Promise<any> {
    const data = this.data$.getValue().data as SENTINELLayerData;
    const properties = this.data$.getValue().properties as SENTINELLayerManagerProperties;

    const sensorClass = data.sensorClass;
    const aggr_layer = properties.aggregationSelected;
    const thr_group = data.thresholdGroup;
    const sensor_group = data.sensorGroup;

    const params = new URLSearchParams({
      aggr_layer,
      thr_group,
      feature_id,
      sensor_group,
      dt: dateToSeconds(dateTo).toString(),
    });

    const sensors = await firstValueFrom(
      this.get<SentinelFeature[]>('sentinelapi/sensors_by_aggregated_feature/' + sensorClass + '/?' + params.toString())
    );
    return sensors;
  }

  async loadAggreatedLayerWithoutGeom(aggr_layer: string): Promise<SENTINELAggreWithouGeom[]> {
    const aggregatedLayer = await firstValueFrom(
      this.get<any>('sentinelapi/aggregated_layer_without_geom/' + aggr_layer + '/')
    );
    return aggregatedLayer;
  }

  /**
   * Loads the stations sensors for a given date.
   * @param sentinelFeatureProperties The properties of the sentinel feature to load the stations sensors for.
   * @returns A promise that resolves to an array of SentinelSensorInfoResponse representing the loaded stations sensors.
   */
  async loadStationsSensors(
    sentinelFeatureProperties: SentinelFeatureProperties
  ): Promise<SentinelSensorInfoResponse[]> {
    const infos = await firstValueFrom(
      this.get<SentinelSensorInfoResponse[]>(
        'sentinelapi/stations_sensors/' + sentinelFeatureProperties.stid + '/' + sentinelFeatureProperties.db + '/'
      )
    );

    const enabledSensor = getCustomPropertiesObjectKeys(this.layerModel);

    if (enabledSensor.length > 0) {
      return infos.filter((sensor) => enabledSensor.includes(sensor.classId.toString()));
    } else {
      return infos;
    }
  }

  /**
   * Loads the sensor info for a given date.
   * @param sentinelFeatureProperties The properties of the sentinel feature to load the sensor info for.
   * @returns A promise that resolves to a SentinelSensorInfoResponse representing the loaded sensor info.
   */
  async loadSensorInfo(sentinelFeatureProperties: SentinelFeatureProperties): Promise<SentinelSensorInfoResponse> {
    const properties = await firstValueFrom(
      this.get<SentinelSensorInfoResponse>(
        'sentinelapi/sensor_info/' + sentinelFeatureProperties.s + '/' + sentinelFeatureProperties.db + '/'
      )
    );
    return properties;
  }

  /**
   * Loads the chart for a given date.
   * @param type The type of the chart to load.
   * @param eventData The event data to load the chart for.
   * @param layerData The layer data to load the chart for.
   * @param dateFrom The date from to load the chart for.
   * @param dateTo The date to to load the chart for.
   * @returns A promise that resolves to the loaded chart.
   */
  async loadChart(
    type: string,
    eventData: SentinelFeature,
    layerData: LayerDataContainer,
    dateFrom: Date,
    dateTo: Date
  ): Promise<any> {
    const featureProperties = eventData.properties;
    const data = layerData.data as SENTINELLayerData;
    const thresholdGroup = data.thresholdGroup;
    const sensorClass = data.sensorClass;
    const chart_id = getCustomPropertiesByKey(this.layerModel, sensorClass)?.chart_id;
    const serie_id = getCustomPropertiesByKey(this.layerModel, sensorClass)?.serie_id;

    const chartProperties = getCustomChartProperties(this.layerModel);

    const params = {
      layer_id: this.getLayerModel().id.toString(),
      serie_id: serie_id,
      feature_id: featureProperties.s + ';' + featureProperties.db,
      chart_id,
      dt1: dateToSeconds(dateFrom).toString(),
      dt2: dateToSeconds(dateTo).toString(),
      threshold_group: thresholdGroup,
    };

    this.postActivityLog(
      'chart:' +
        type +
        ':chartid:' +
        params.chart_id +
        'serieid:' +
        params.serie_id +
        'featureid:' +
        params.feature_id +
        'thr_group:' +
        params.threshold_group,
      'chart-loaded'
    );

    return await firstValueFrom(
      this.post<any>(
        'chartapi/dds_' + type + '/',
        {
          feature: featureProperties,
          chart_properties: chartProperties[chart_id],
        },
        params
      )
    ); // json or img
  }

  /**
   * Loads the chart for a given sensor.
   * @param type The type of the chart to load.
   * @param sentinelSensor The sentinel sensor to load the chart for.
   * @param dateFrom The date from to load the chart for.
   * @param dateTo The date to to load the chart for.
   * @returns A promise that resolves to the loaded chart.
   */
  async loadChartBySensor(
    type: string,
    sentinelSensor: SentinelSensorInfoResponse,
    dateFrom: Date,
    dateTo: Date
  ): Promise<any> {
    const sensorClass = sentinelSensor.classId;
    const chartProperties = getCustomChartProperties(this.layerModel);
    const chart_id = getCustomPropertiesByKey(this.layerModel, sensorClass)?.chart_id;
    const serie_id = getCustomPropertiesByKey(this.layerModel, sensorClass)?.serie_id;

    const params = {
      layer_id: this.getLayerModel().id.toString(),
      serie_id,
      feature_id: sentinelSensor.sensorId + ';' + sentinelSensor.dbId,
      chart_id,
      dt1: dateToSeconds(dateFrom).toString(),
      dt2: dateToSeconds(dateTo).toString(),
      threshold_group: getCustomPropertiesByKey(this.layerModel, sensorClass)?.threshold_group,
    };

    this.postActivityLog(
      'chart:' +
        type +
        ':chartid:' +
        params.chart_id +
        'serieid:' +
        params.serie_id +
        'featureid:' +
        params.feature_id +
        'thr_group:' +
        params.threshold_group,
      'chart-loaded'
    );

    return await firstValueFrom(
      this.post<any>(
        'chartapi/dds_' + type + '/',
        {
          feature: sentinelSensor,
          chart_properties: chartProperties[chart_id],
        },
        params
      )
    ); // json or img
  }

  /**
   * Loads the chart for a given sensor.
   * @param type The type of the chart to load.
   * @param sentinelSensor The sentinel sensor to load the chart for.
   * @param dateFrom The date from to load the chart for.
   * @param dateTo The date to to load the chart for.
   * @returns A promise that resolves to the loaded chart.
   */
  async getDefaultProperties(dateFrom: Date, dateTo: Date): Promise<BaseLayerManagerProperties> {
    const aggregationList = await this.loadAggregationList();

    return {
      aggregationSelected: 'none',
      aggregationsList: aggregationList,
      cumulatedValueList: [0, 900, 3600, 10800, 21600, 43200, 64800, 86400, 129600],
      cumulatedValueSelected: 3600,
      dateFrom,
      dateTo,
    } as SENTINELLayerManagerProperties;
  }

  /**
   * Loads the layer for a given date.
   * @param properties The properties to load the layer for.
   * @param dateFrom The date from to load the layer for.
   * @param dateTo The date to to load the layer for.
   * @returns A promise that resolves to the loaded layer.
   */
  override async getLayerData(properties: SENTINELLayerManagerProperties): Promise<SENTINELLayerData> {
    const sensorClassId = this.layerModel.dataid.split(';')[0];
    let sensorClass = getCustomPropertiesByKey(this.layerModel, 'SENSOR_CLASS');
    if (!sensorClass) {
      sensorClass = sensorClassId;
    }

    let thresholdGroup = getCustomPropertiesByKey(this.layerModel, sensorClass)?.threshold_group;
    if (!thresholdGroup) {
      thresholdGroup = this.layerModel.dataid.split(';')[1];
    }

    let serieId = getCustomPropertiesByKey(this.layerModel, sensorClass)?.serie_id;
    if (!serieId) {
      serieId = this.layerModel.dataid.split(';')[1];
    }

    let sensorGroup = getCustomPropertiesByKey(this.layerModel, sensorClass)?.sensor_group;
    if (!sensorGroup) {
      sensorGroup = this.layerModel.dataid.split(';')[3];
    }

    if (sensorClass == undefined || thresholdGroup == undefined || serieId == undefined || sensorGroup == undefined) {
      this.setError('Missing required properties');
      throw new Error('Missing required properties');
    }

    if (properties?.aggregationSelected && properties?.aggregationSelected !== 'none') {
      const res = await this.loadAggregatedLayer(properties.aggregationSelected, properties.dateTo);

      return {
        sentinelResponse: res,
        sensorClass: sensorClass,
        thresholdGroup: thresholdGroup,
        serieId: serieId,
        sensorGroup: sensorGroup,
      } as SENTINELLayerData;
    }

    // Add a return value for cases where aggregationSelected is not provided or is 'none'
    const sentinelResponse = await this.loadSensorsByClassAndThreshold(
      sensorClass,
      thresholdGroup,
      sensorGroup,
      properties.dateTo
    );
    return {
      sentinelResponse: sentinelResponse,
      sensorClass: sensorClass,
      thresholdGroup: thresholdGroup,
      serieId: serieId,
      sensorGroup: sensorGroup,
    } as SENTINELLayerData;
  }

  /**
   * Loads the series for a given event data.
   * @param eventData The event data to load the series for.
   * @param dateFrom The date from to load the series for.
   * @param dateTo The date to to load the series for.
   * @returns An observable that resolves to the loaded series.
   */
  public override getSeries$(
    eventData: SENTINELLayerEventData,
    dateFrom: Date,
    dateTo: Date
  ): Observable<SENTINELGetSeriesResult> {
    return this.data$.pipe(
      switchMap((layerData: LayerDataContainer) => {
        if (eventData.feature.geometry.type === 'Point') {
          // "MultiPolygon" //
          const chart = this.loadChart('json', eventData.feature, layerData, dateFrom, dateTo);
          const sensorInfo = this.loadSensorInfo(eventData.feature.properties);
          const stationSensor = this.loadStationsSensors(eventData.feature.properties);

          return forkJoin([chart, sensorInfo, stationSensor]).pipe(
            map(([chart, sensorInfo, stationSensor]) => {
              return {
                status: 'loaded',
                type: 'chart',
                data: {
                  chart: chart,
                  sensorInfo: sensorInfo,
                  stationSensor: stationSensor,
                },
              } as SENTINELGetSeriesResult;
            }),
            startWith({ status: 'loading' } as SENTINELGetSeriesResult),
            catchError((error) => {
              const errorMessage = `Error retrieving series for layer ${this.layerModel.name}. Status ${error.status}`;
              return of({ status: 'error', error: errorMessage } as SENTINELGetSeriesResult);
            })
          );
        } else {
          const feature = eventData.feature as any;
          const id = feature.properties.id as string;

          const sensors = this.loadSensorsByAggregatedFeature(id, dateTo);
          return forkJoin([sensors]).pipe(
            map(([sensors]) => {
              return {
                status: 'loaded',
                type: 'table',
                data: {
                  sensors,
                } as SENTINELSerieResultDataAggregatedFeature,
              } as SENTINELGetSeriesResult;
            }),
            startWith({ status: 'loading' } as SENTINELGetSeriesResult),
            catchError((error) => {
              const errorMessage = `Error retrieving series for layer ${this.layerModel.name}. Status ${error.status}`;
              return of({ status: 'error', error: errorMessage } as SENTINELGetSeriesResult);
            })
          );
        }
      })
    );
  }

  /**
   * Loads the layer event info for a given event data.
   * @param eventData The event data to load the layer event info for.
   * @returns An observable that resolves to the loaded layer event info.
   */
  public override getLayerEventInfo$(eventData: SENTINELLayerEventData): Observable<BaseSeriesResult> {
    const sensorInfo = this.loadSensorInfo(eventData.feature.properties);
    const stationSensor = this.loadStationsSensors(eventData.feature.properties);

    return forkJoin([sensorInfo, stationSensor]).pipe(
      map(([sensorInfo, stationSensor]) => {
        return {
          sensorInfo: sensorInfo,
          stationSensor: stationSensor,
        } as any;
      }),
      catchError((error) => {
        const errorMessage = `Error retrieving infos for layer ${this.layerModel.name}. Status ${error.status}`;
        return of({ status: 'error', error: errorMessage } as BaseSeriesResult);
      })
    );
  }
}
