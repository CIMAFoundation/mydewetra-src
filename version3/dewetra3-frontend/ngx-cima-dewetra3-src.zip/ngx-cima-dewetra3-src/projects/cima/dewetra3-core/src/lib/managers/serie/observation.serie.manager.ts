import { FeatureCollection } from 'geojson';
import { Observable, catchError, filter, map, of } from 'rxjs';

import { format } from 'date-fns';
import { parseUnixTimestampOrDateFormatted } from '../../utils/utils';
import { SERIELayerData, SERIELayerManagerProperties, SERIESLayerManager } from './serie.manager';

export class ObservationSERIESLayerManager extends SERIESLayerManager {
  public override getLayerDetail$(): Observable<string> {
    return this.data$.pipe(
      filter((ld) => !!ld && !!ld.data && !!ld.properties),
      map((ld) => {
        const data = ld.data as SERIELayerData;
        const sections = data.sections as FeatureCollection;
        const features = Array.isArray(sections.features) ? sections.features : [];

        if (ld.status === 'loading') {
          return 'LOADING_LAYER';
        }

        if (ld.status === 'error') {
          return ld.error || 'ERROR_READING_LAYER';
        }

        if (features.length === 0) {
          return 'NO_SECTIONS';
        }

        // ② >=1 feature (non >1)
        const first = features[0].properties || {};
        const runRaw = first.run;

        const dateToRaw = (ld.properties as SERIELayerManagerProperties).dateTo;

        // ③ parsing più robusto
        const dRun = parseUnixTimestampOrDateFormatted(runRaw);

        const isValidRun = dRun.isValid && typeof dRun.format === 'function';

        if (isValidRun) {
          return `Run: ${dRun.format('YYYY/MM/DD HH:mm')}`;
        }

        // fallback sulla proprietà dateTo
        return `Date To: ${format(dateToRaw, 'dd/MM/yyyy HH:mm')}`;
      }),
      // ④ catturo eventuali eccezioni e restituisco un fallback
      catchError((err) => {
        console.error('Errore in getLayerDetail$', err);
        return of('ERROR_READING_LAYER');
      })
    );
  }
}
