import { LatLng } from 'leaflet';
import * as Plotly from 'plotly.js';
import { catchError, map, Observable, of, shareReplay, startWith, switchMap } from 'rxjs';
import { BaseMapInfoResult, BasePunctualSeriesResult, LayerDataContainer, WMSInfoResponse } from '../../models/models';
import { getCustomChartProperties, getCustomPropertiesByKey, getWMSLayerInfoUrl } from '../../utils/utils';

import {
  DDSLayerData,
  DDSLayerManager,
  DDSLayerManagerProperties,
  DDSLayerMapInfoResult,
  DDSLayerPunctualSeriesResult,
} from './dds.manager';

export class DDSWMSLayerManager extends DDSLayerManager {
  

  /**
   * Retrieves the base map information for the given latitude and longitude.
   * @param latlng The latitude and longitude coordinates.
   * @returns An observable that emits the base map information.
   */
  public override getInfo$(latlng: L.LatLng): Observable<BaseMapInfoResult> {
    return this.data$.pipe(
      map((layerData: LayerDataContainer) => {
        const data = layerData.data as DDSLayerData;
        const dataId = data.published.layerid;
        const serverUrl = this.getLayerModel().server.url;
        const url = getWMSLayerInfoUrl(data.serverUrl, latlng, dataId);
        return url;
      }),
      switchMap((url) =>
        this.getExternal<WMSInfoResponse>(url).pipe(
          map((data) => ({ wmsData: data } as DDSLayerMapInfoResult)),
          shareReplay()
        )
      )
    );
  }
  

  public override hasPunctualSeries(): boolean {
    return true;
  }

  /**
   * Retrieves the punctual series data for a given latitude, longitude, and date range.
   * @param latLng - The latitude and longitude coordinates.
   * @param dateFrom - The start date of the date range.
   * @param dateTo - The end date of the date range.
   * @returns An observable that emits the punctual series data.
   */
  public override getPunctualSeries$(
    latLng: LatLng,
    dateFrom: Date,
    dateTo: Date,
    properties?: DDSLayerManagerProperties
  ): Observable<BasePunctualSeriesResult> {
    // TODO: make this configurable from custom properties or custom model. It could depend from the variable selected in the properties
    if (true) {
      return this.punctualSeriesJsonChart$(latLng, dateFrom, dateTo, properties);
    } else {
      //return this.punctualSeries$(latLng, dateFrom, dateTo);
    }
  }

  private punctualSeriesJsonChart$(
    latLng: LatLng,
    dateFrom: Date,
    dateTo: Date,
    distinctDDSProperties?: DDSLayerManagerProperties
  ): Observable<DDSLayerPunctualSeriesResult> {
    const layerId = this.getLayerModel().id;

    return this.data$.pipe(
      map((layerData: LayerDataContainer) => layerData?.properties as DDSLayerManagerProperties),
      switchMap((layerProperties: DDSLayerManagerProperties) => {
        const selectedProperties = distinctDDSProperties || layerProperties;
        const chart_id = this.getChartId(selectedProperties);
        const url = `chartapi/dds_punctual_json/${layerId}/`;
        const chartProperties = getCustomChartProperties(this.getLayerModel()) || {};

        return this.post<Plotly.Data[]>(url, {
          props: selectedProperties.ddsProperties,
          chart_id,
          lat: latLng.lat,
          lon: latLng.lng,
          from: dateFrom.getTime() / 1000,
          to: dateTo.getTime() / 1000,
          feature: {},
          chart_properties: chartProperties,
        }).pipe(
          map((data) => ({ status: 'loaded', data } as DDSLayerPunctualSeriesResult)),
          startWith({ status: 'loading' } as DDSLayerPunctualSeriesResult),
          catchError((error) => this.handleError(error, distinctDDSProperties))
        );
      })
    );
  }

  private getChartId(properties: DDSLayerManagerProperties): string {
    const defaultChartId = 'timeseries.lines';
    const layerModelTimeseriesProps = getCustomPropertiesByKey(this.getLayerModel(), 'timeseries');
    const ddsLayerVariables = properties.ddsProperties?.layerProperties?.attributes?.find(
      (attr) => attr.name === 'variable'
    );
    const ddsLayerValue = ddsLayerVariables?.selectedEntry?.value;

    if (layerModelTimeseriesProps && layerModelTimeseriesProps[ddsLayerValue]?.chart_id) {
      console.log('Custom chart_id found:', layerModelTimeseriesProps[ddsLayerValue].chart_id);
      return layerModelTimeseriesProps[ddsLayerValue].chart_id;
    }
    return defaultChartId;
  }

  private handleError(
    error: any,
    distinctDDSProperties?: DDSLayerManagerProperties
  ): Observable<DDSLayerPunctualSeriesResult> {
    const errorMessage = `Error retrieving punctual series for layer ${this.getLayerModel().name}. Status ${
      error.status
    }`;
    if (distinctDDSProperties) {
      this.postActivityLog(errorMessage, 'timeseries-error');
    }
    return of({ status: 'error', error: errorMessage } as DDSLayerPunctualSeriesResult);
  }
}
function from(arg0: Promise<boolean>): any {
  throw new Error('Function not implemented.');
}
