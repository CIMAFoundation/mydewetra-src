import {CommonModule} from '@angular/common';
import {Component, Input} from '@angular/core';
import {TranslateModule} from '@ngx-translate/core';
import {BaseLayerManager} from '../../../managers/base/base.manager';

@Component({
  selector: 'dewetra3-custom-legend',
  imports: [CommonModule, TranslateModule],
  template: `
    <div class="legend">
      <div class="legend-title"></div>

      <div class="legend-content">
        @if (manager.getLayerModel().legendmanager.props; as legendProps) {
          @for (legend of legendProps.default.legend; track $index) {
            <div class="legend-item">
              <div class="legend-title">{{ legend.title }}</div>
              <div class="legende-description">{{ legend.description }}</div>
              @if (legend.imgurl) {
                <div class="legend-image">
                  <img [style.width]="legendProps?.default?.imageWidth ? legendProps?.default?.imageWidth : '100%'"
                       [src]="legend.imgurl"
                       alt="{{ 'DEWETRA3APP.LEGENDA' | translate }}"/>
                </div>
              }

              <div class="legend-image-caption">{{ legend.imagecaption }}</div>

              <div [style.width]="legend?.paletteWidth ? legend?.paletteWidth:'200px'">
                @for (legendItem of legend.palette; track $index) {
                  <div class="legend-item-color" [style.background-color]="legendItem.color">
                    <div class="legend-item-label">{{ legendItem.label }} {{ legendItem.mu }}</div>
                  </div>
                }

              </div>

            </div>
          }
        }
      </div>
    </div>
  `,
  styles: `img {
    width: 100%;
  }`,
  standalone: true,
})
export class ImageLegendComponent {
  @Input() manager!: BaseLayerManager;

  constructor() {
  }

  // {"default": {"legend": [{"title": "Place hold", "imgurl": "https://placehold.co/600x400", "palette": [{"mu": "mu", "color": "#ff45ff", "digit": "5", "label": "Neve", "value": [], "textcolor": "#040050", "background-text": "#ffffff"}, {"mu": "mu", "color": "#ffff35", "digit": "5", "label": "Neve", "value": [], "textcolor": "#020040", "background-text": "#ffffff"}, {"mu": "mu", "color": "#22ffff", "digit": "5", "label": "Neve", "value": [], "textcolor": "#000000", "background-text": "#ffffff"}, {"mu": "mu", "color": "#ff78ff", "digit": "5", "label": "Neve", "value": [], "textcolor": "#000000", "background-text": "#ffffff"}, {"mu": "mu", "color": "#ffffff", "digit": "5", "label": "Neve", "value": [], "textcolor": "#000000", "background-text": "#ffffff"}, {"mu": "mu", "color": "#ffffff", "digit": "5", "label": "Neve", "value": [], "textcolor": "#000000", "background-text": "#ffffff"}], "description": "Place hold description", "imagecaption": "Image Caption"}]}}
}
