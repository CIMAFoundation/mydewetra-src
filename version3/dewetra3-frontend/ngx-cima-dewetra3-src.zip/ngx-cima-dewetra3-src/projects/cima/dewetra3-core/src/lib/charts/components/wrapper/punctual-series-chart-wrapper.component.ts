import {Component, Input, OnInit} from '@angular/core';
import {BehaviorSubject, combineLatest, filter, switchMap} from 'rxjs';
import {BaseLayerManager} from '../../../managers/base/base.manager';
import {Dewetra3MapClick} from '../../../models/models';
import {ChartComponentFactory} from '../../chart-component-factory.service';


@Component({
  selector: 'dewetra3-punctual-chart-wrapper',
  template: `
    @if (component) {
      @if (chartEvents$ | async; as chartEvent) {
        @if (chartEvent.status === 'loaded') {
          <ndc-dynamic
            [ndcDynamicComponent]="component"
            [ndcDynamicInputs]="{ manager, chartEvents$, clickData, dateFrom, dateTo}"
          ></ndc-dynamic>
        } @else if (chartEvent.status === 'error') {
          <div class="alert alert-danger" role="alert">
            {{ chartEvent.error }}
          </div>
        } @else if (chartEvent.status === 'loading') {
          <div class="p-3 d-flex justify-content-center align-items-center flex-column">
            <mat-spinner></mat-spinner>
            <div class="my-2">{{ 'DEWETRA3CORE.LOADING' | translate }}...</div>
          </div>
        }
      } @else {
        <div class="p-3 d-flex justify-content-center align-items-center flex-column">
          <mat-spinner></mat-spinner>
          <div class="my-2">{{ 'DEWETRA3CORE.WAITING_FOR_DATA' | translate }}...</div>
        </div>
      }
    } @else {
      <span>{{ 'DEWETRA3CORE.COMPONENT_NOT_DEFINED' | translate }}</span>
    }
  `,
  styleUrls: []
})
export class PunctualSeriesChartWrapperComponent implements OnInit {

  private dateFrom$ = new BehaviorSubject<Date | null>(null);

  @Input() set dateFrom(date: Date) {
    this.dateFrom$.next(date);
  }

  get dateFrom() {
    return this.dateFrom$.getValue();
  }

  private dateTo$ = new BehaviorSubject<Date | null>(null);

  @Input() set dateTo(date: Date) {
    this.dateTo$.next(date);
  }

  get dateTo() {
    return this.dateTo$.getValue();
  }

  private manager$ = new BehaviorSubject<BaseLayerManager | null>(null);

  @Input() set manager(manager: BaseLayerManager) {
    this.manager$.next(manager);
  };

  public get manager() {
    return this.manager$.getValue();
  }

  private clickData$ = new BehaviorSubject<Dewetra3MapClick | null>(null);

  @Input() set clickData(clickData: Dewetra3MapClick) {
    this.clickData$.next(clickData);
  };

  public get clickData() {
    return this.clickData$.getValue();
  }

  public chartEvents$ = combineLatest([this.manager$, this.clickData$, this.dateFrom$, this.dateTo$]).pipe(
    filter(([manager, clickData, dateFrom, dateTo]) => !!manager && !!clickData && !!dateFrom && !!dateTo),
    switchMap(([manager, clickData, dateFrom, dateTo]) => manager.getPunctualSeries$(clickData.latLng, dateFrom, dateTo))
  );

  public component!: any;

  constructor(
    private chartFactory: ChartComponentFactory
  ) {
  }

  ngOnInit(): void {
    this.component = this.chartFactory.create(this.manager.getLayerModel());
    console.log(this.component);
  }
}
