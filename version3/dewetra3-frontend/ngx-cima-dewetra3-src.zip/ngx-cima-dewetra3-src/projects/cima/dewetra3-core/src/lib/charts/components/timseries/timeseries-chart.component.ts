import {AfterViewInit, Component, Input} from '@angular/core';
import * as Plotly from 'plotly.js-dist-min';
import {Observable} from 'rxjs';
import {filter, map, startWith, switchMap} from 'rxjs/operators';
import * as uiid from 'uuid';
import {BaseLayerManager} from '../../../managers/base/base.manager';
import {DDSLayerPunctualSeriesResult} from '../../../managers/dds/dds.manager';


@Component({
  selector: 'timeseries-chart',
  template: `
    @if (loadingChart$|async) {
      <div>
        {{ 'DEWETRA3CORE.LOADING_CHART' | translate }}...
      </div>
      <div class="d-flex justify-content-center align-items-center flex-column ">
        <mat-progress-bar mode="indeterminate"></mat-progress-bar>
      </div>
    }
    <div class="p-2">
      <div [id]="chartId" class="rounded-2 overflow-hidden"></div>
    </div>
  `,
  styles: ['']
})
export class TimeSeriesChartComponent implements AfterViewInit {
  @Input() manager: BaseLayerManager;
  @Input() chartEvents$!: Observable<DDSLayerPunctualSeriesResult>;

  public chartId = uiid.v4();
  public loadingChart$!: Observable<boolean>;
  public component!: any;
  
  ngAfterViewInit(): void {
    this.loadingChart$ = this.chartEvents$.pipe(
      filter(data => !!data && data.status === 'loaded'),
      switchMap(async (data) => {
        console.log('plotting');
        const done = await Plotly.newPlot(this.chartId, data.data);
        console.log('done', done);
        return done;
      }),
      map(() => false),
      startWith(true)
    )
  }

}
