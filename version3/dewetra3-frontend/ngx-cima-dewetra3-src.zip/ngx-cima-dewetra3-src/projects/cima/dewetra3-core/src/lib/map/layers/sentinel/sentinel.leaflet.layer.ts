import * as L from 'leaflet';
import { BaseDewetra3LayerEventData, Dewetra3LayerEventWithData } from '../../../managers/base/base.manager';
import { SENTINELLayerData, SENTINELLayerManagerProperties } from '../../../managers/sentinel/sentinel.manager';
import { LayerDataContainer } from '../../../models/models';
import { CustomPropertiesSentinelSensor, SentinelFeature } from '../../../models/sentinel';
import { getLayerMapProperties } from '../../../utils/utils';
import { BaseLayer } from '../base/base.layer';

export interface SentinelLayerEventData extends BaseDewetra3LayerEventData {
  feature: any;
}

export class SentinelLayerLeaflet extends BaseLayer {
  private featureLayer: L.GeoJSON;

  private LayerModel = this.layer.getLayerModel();

  //accumulatedValueSelected = 3600;
  accumulatedValueSelected: number = 3600 * 24;

  override bringToFront(): void {
    this.featureLayer?.bringToFront();
  }

  override bringToBack(): void {
    this.featureLayer?.bringToBack();
  }

  override async updateMapLayer(data: LayerDataContainer): Promise<void> {
    const dataLayer = data.data as SENTINELLayerData;
    const properties = data.properties as SENTINELLayerManagerProperties;

    this.accumulatedValueSelected = properties?.cumulatedValueSelected;

    if (this.featureLayer) {
      this.map.removeLayer(this.featureLayer);
    }

    console.log('updateMapLayer:', this.layer.getName());

    this.featureLayer = L.geoJSON(dataLayer.sentinelResponse, {
      filter: (feature) => {
        //
        return true;
      },

      pointToLayer: (feature, latLng) => {
        return this.returnMarker(feature as SentinelFeature, latLng);
      },
      onEachFeature: (feature, layer) => {
        layer.on({
          click: (evt) => this.emitLayerEvent('click', evt.target.feature),
          mouseover: (evt) => this.emitLayerEvent('mouseover', evt.target.feature),
          mouseout: (evt) => this.emitLayerEvent('mouseout', evt.target.feature),
        });
        this.styler(feature as SentinelFeature, layer);
      },
    });

    this.map.addLayer(this.featureLayer);
  }

  private emitLayerEvent(type: 'click' | 'mouseover' | 'mouseout', feature: any) {
    if (type === 'mouseover' && feature.geometry.type === 'MultiPolygon') return;

    const data: SentinelLayerEventData = { feature };
    const event = { type, layer: this.layer, data } as Dewetra3LayerEventWithData;
    this.onLayerEvent.emit(event);
  }

  override _remove(): void {
    this.map?.removeLayer(this.featureLayer);
  }

  override setOpacity(opacity: number): void {
    this.featureLayer?.setStyle({ opacity, fillOpacity: opacity });
  }

  override setVisible(visible: boolean): void {
    if (visible) {
      this.map?.addLayer(this.featureLayer);
    } else {
      this.map?.removeLayer(this.featureLayer);
    }
  }

  returnMarker(feature: SentinelFeature, latlng: L.LatLng) {
    return L.circleMarker(latlng);
  }

  styler(feature: SentinelFeature, layer: L.Layer) {
    if (feature?.geometry?.type === 'Point') {
      this.pointStyle(feature, layer);
    } else {
      this.featureStyle(feature, layer);
    }
  }

  pointStyle(feature: SentinelFeature, layer: L.Layer) {
    const layerAsMarker = layer as L.CircleMarker;

    //check if feature has v and v is an array with at least one element
    if (!feature.properties.v || feature.properties.v.length == 0) {
      layerAsMarker.setStyle({
        radius: 5,
        weight: 1,
        color: '#060706',
        fillColor: '#cbcbcb',
        opacity: 1,
        fillOpacity: 0.8,
      });
    }

    const cumulatedValueSelected = this.accumulatedValueSelected;

    const customProperties = getLayerMapProperties(this.layer.getLayerModel()) as CustomPropertiesSentinelSensor;

    const legendProperties = customProperties.default;

    let fillColor = legendProperties.legend[0].color;

    const vCum = feature?.properties?.v ? feature.properties.v.filter((v) => v.p === cumulatedValueSelected) : [];
    const vNotCum = feature?.properties?.v ? feature.properties.v.filter((v) => v.a !== 'SUM') : [];

    //todo when it will ready load the cumulated value from the layer properties
    let value: any = null;

    if (vCum.length > 0) {
      //search for the cumulated value
      value = vCum.filter((v) => v.p === this.accumulatedValueSelected)[0].v;
    }

    if (value > 100) {
      const valuedebugger = value;
    }

    if (value !== null && typeof value === 'number') {
      //iterate over the legend properties
      legendProperties.legend.map((legend: any, index: number) => {
        if (value >= legend.value[0] && value <= legend.value[1]) {
          fillColor = legend.color;
        }
      });
    }

    layerAsMarker.setStyle({
      radius: 5,
      weight: 1,
      color: '#060706',
      fillColor: fillColor,
      opacity: 1,
      fillOpacity: 0.8,
    });
  }

  featureStyle(feature: SentinelFeature, layer: L.Layer) {
    const layerAsGeoJsonFeature = layer as L.GeoJSON;

    const customProperties = getLayerMapProperties(this.layer.getLayerModel()) as CustomPropertiesSentinelSensor;

    const legendProperties = customProperties.default;

    let fillColor;
    const cumulatedValueSelected = this.accumulatedValueSelected;

    const vCum = feature?.properties?.values
      ? feature.properties.values.filter((v) => v.p === cumulatedValueSelected)
      : [];
    const vNotCum = feature?.properties?.values ? feature.properties.values.filter((v) => v.a !== 'SUM') : [];

    //todo when it will ready load the cumulated value from the layer properties
    let value: any = null;

    if (vCum.length > 0) {
      //search for the cumulated value
      value = vCum.filter((v) => v.p === cumulatedValueSelected)[0].v;
    }

    if (value === null) {
      fillColor = legendProperties.legend[0].color;
    }

    if (value !== null && typeof value === 'number') {
      //iterate over the legend properties
      legendProperties.legend.filter((legend: any, index: number) => {
        if (value >= legend.value[0] && value <= legend.value[1]) {
          fillColor = legend.color;
        }
      });
    }

    // @ts-ignore
    layer.setStyle({
      fillColor: fillColor,
      weight: 1,
      opacity: 1,
      color: 'black',
      fillOpacity: 0.7,
    });
  }

  override getBounds(): L.LatLngBounds {
    return this.featureLayer?.getBounds();
  }
}
