import {AfterViewInit, Component, Input} from '@angular/core';
import {MatTabChangeEvent} from '@angular/material/tabs';
import * as Plotly from 'plotly.js-dist-min';
import {Observable} from 'rxjs';
import {filter, map, startWith, switchMap} from 'rxjs/operators';
import * as uiid from 'uuid';
import {
  SENTINELGetSeriesResult,
  SENTINELSerieResultData,
  SENTINELSerieResultDataAggregatedFeature
} from '../../../managers/sentinel/sentinel.manager';
import {WARNINGSLayerManager} from '../../../managers/sentinel/warnings.manager';
import {Dewetra3LayerCommonEvent} from '../../../managers/base/base.manager';
import {SENTINELChartComponent} from './sentinel-chart.component';


@Component({
  selector: 'warning-pluvio-chart',
  template: `

    @if (loadingChart$ | async) {
      <div>
        {{ 'DEWETRA3CORE.WAITING_FOR_DATA' | translate }}...
      </div>
      <div class="w-100 h-100 d-flex justify-content-center align-items-center flex-column">
        <mat-progress-bar mode="indeterminate"></mat-progress-bar>
      </div>
    }

    @switch (seriesResult?.type) {
      @case ('chart') {
        <div class="d-flex justify-content-between align-items-center p-2">
          <div>
            <span class="fw-bold"> {{ seriesResultData?.sensorInfo?.stationName }} </span>
            <span class="text-muted"> {{ seriesResultData?.sensorInfo?.stationSupplierName }} </span>
          </div>
        </div>
        <mat-tab-group (selectedTabChange)="onTabChange($event)" [selectedIndex]="selectedIndex">
          @for (sensor of getSerieResultDataForStation().stationSensor; track $index) {
            <mat-tab [label]="sensor.sensorDescr"></mat-tab>
          }
        </mat-tab-group>
      }
      @case ('table') {
        <div>
          <warnings-pluvio-aggregated-table [clickData]="clickData"
                                            [sensors]="getSerieResultDataForAggregatedFeature().sensors"></warnings-pluvio-aggregated-table>
        </div>
      }
      @default {
        <!--          <div>
                    {{ 'DEWETRA3CORE.NO_DATA' | translate }}
                  </div>-->
      }
    }
    <div class="p-2">
      <div [id]="chartId" class="rounded-2 overflow-hidden"></div>
    </div>
  `,
  styles: ['']
})
export class WARNINGSPLUVIOChartComponent extends SENTINELChartComponent {

}
