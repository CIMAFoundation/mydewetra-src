import {Component, Input} from '@angular/core';
import {Observable} from 'rxjs';
import {BaseLayerManager} from '../../../managers/base/base.manager';
import {Dewetra3MapClick} from '../../../models/models';


@Component({
  selector: 'dewetra3-debuglayer-info',
  template: `
    <div *ngIf="manager">
      <h4 class="mb-1">{{ manager.getName() }}</h4>
      <span *ngIf="infoEvents$ | async as info">{{ info | json }}</span>
    </div>
  `,
  styleUrls: []
})
export class DebugInfoComponent {
  @Input() manager!: BaseLayerManager;
  @Input() infoEvents$!: Observable<any>;
  @Input() clickData: Dewetra3MapClick;


}
