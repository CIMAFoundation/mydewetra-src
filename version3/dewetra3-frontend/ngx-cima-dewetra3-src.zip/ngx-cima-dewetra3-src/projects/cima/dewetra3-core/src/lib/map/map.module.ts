import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Dewetra3MapComponent} from './components/dewetra3-map.component';
import {MapMeasurementToolComponent} from './tool/map-measurament-tool.component';
import {FormsModule} from '@angular/forms';
import {MatTooltip} from "@angular/material/tooltip";
import {TranslateModule} from "@ngx-translate/core";
import {CimaCommonsModule} from "@cima/commons";


@NgModule({
  declarations: [
    Dewetra3MapComponent,
    MapMeasurementToolComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    MatTooltip,
    TranslateModule,
    CimaCommonsModule
  ],
  exports: [
    Dewetra3MapComponent,
    MapMeasurementToolComponent
  ]
})
export class Dewetra3MapModule {
}
