import {AfterViewInit, Component, Input} from '@angular/core';
import {BehaviorSubject, forkJoin, map} from 'rxjs';
import {SENTINELAggreWithouGeom} from '../../../../managers/sentinel/sentinel.manager';
import {WARNINGSLayerManager, WARNINGSLayerManagerProperties} from '../../../../managers/sentinel/warnings.manager';

import {Dewetra3LayerCommonEvent} from '../../../../managers/base/base.manager';
import {SentinelFeature, SentinelValueFeatureProperties} from '../../../../models/sentinel';

@Component({
  selector: 'warnings-pluvio-aggregated-table',
  template: `
    <table class="w-100 table-dark alternate">
      <thead>
      <tr>
        <th>Stazione</th>
        <th>Comuni (Topoieti)</th>
        <th>15 Min
          <span class="order-btn" (click)="orderMatrixByProperty('900','value')"><span class="fas"
                                                                                       [ngClass]="orderProperty!='900'?'fa-filter': isAscending?'fa-sort-up':'fa-sort-down'"></span> </span>
        </th>
        <th>30 Min
          <span class="order-btn" (click)="orderMatrixByProperty('1800','value')"><span class="fas"
                                                                                        [ngClass]="orderProperty!='1800'?'fa-filter': isAscending?'fa-sort-up':'fa-sort-down'"></span> </span>
        </th>
        <th>1 Ora
          <span class="order-btn" (click)="orderMatrixByProperty('3600','value')"><span class="fas"
                                                                                        [ngClass]="orderProperty!='3600'?'fa-filter': isAscending?'fa-sort-up':'fa-sort-down'"></span> </span>
        </th>
        <th>3 Ore
          <span class="order-btn" (click)="orderMatrixByProperty('10800','value')"><span class="fas"
                                                                                         [ngClass]="orderProperty!='10800'?'fa-filter': isAscending?'fa-sort-up':'fa-sort-down'"></span> </span>
        </th>
        <th>6 Ore
          <span class="order-btn" (click)="orderMatrixByProperty('21600','value')"><span class="fas"
                                                                                         [ngClass]="orderProperty!='21600'?'fa-filter': isAscending?'fa-sort-up':'fa-sort-down'"></span> </span>
        </th>
        <th>12 Ore
          <span class="order-btn" (click)="orderMatrixByProperty('43200','value')"><span class="fas"
                                                                                         [ngClass]="orderProperty!='43200'?'fa-filter': isAscending?'fa-sort-up':'fa-sort-down'"></span> </span>
        </th>
        <th>18 Ore
          <span class="order-btn" (click)="orderMatrixByProperty('64800','value')"><span class="fas"
                                                                                         [ngClass]="orderProperty!='64800'?'fa-filter': isAscending?'fa-sort-up':'fa-sort-down'"></span> </span>
        </th>
        <th>24 Ore
          <span class="order-btn" (click)="orderMatrixByProperty('86400','value')"><span class="fas"
                                                                                         [ngClass]="orderProperty!='86400'?'fa-filter': isAscending?'fa-sort-up':'fa-sort-down'"></span> </span>
        </th>
        <th>36 Ore
          <span class="order-btn" (click)="orderMatrixByProperty('129600','value')"><span class="fas"
                                                                                          [ngClass]="orderProperty!='129600'?'fa-filter': isAscending?'fa-sort-up':'fa-sort-down'"></span> </span>
        </th>

      </tr>
      </thead>
      <tbody>
        @for (raw of matrix$| async; track raw) {
          <tr>
            <td>{{ raw['st'] }}</td>
            <td>{{ raw['municList'] }}</td>
            <td><span class="rounded badge-item"
                      [ngStyle]="raw['900']['exceedingColor']">{{ raw['900']['value'] }}</span></td>
            <td><span class="rounded badge-item"
                      [ngStyle]="raw['1800']['exceedingColor']">{{ raw['1800']['value'] }}</span></td>
            <td><span class="rounded badge-item"
                      [ngStyle]="raw['3600']['exceedingColor']">{{ raw['3600']['value'] }}</span></td>
            <td><span class="rounded badge-item"
                      [ngStyle]="raw['10800']['exceedingColor']">{{ raw['10800']['value'] }}</span></td>
            <td><span class="rounded badge-item"
                      [ngStyle]="raw['21600']['exceedingColor']">{{ raw['21600']['value'] }}</span></td>
            <td><span class="rounded badge-item"
                      [ngStyle]="raw['43200']['exceedingColor']">{{ raw['43200']['value'] }}</span></td>
            <td><span class="rounded badge-item"
                      [ngStyle]="raw['64800']['exceedingColor']">{{ raw['64800']['value'] }}</span></td>
            <td><span class="rounded badge-item"
                      [ngStyle]="raw['86400']['exceedingColor']">{{ raw['86400']['value'] }}</span></td>
            <td><span class="rounded badge-item"
                      [ngStyle]="raw['129600']['exceedingColor']">{{ raw['129600']['value'] }}</span>
            </td>
          </tr>
        }
      </tbody>
    </table>

  `,
  styleUrls: ['./warnings-pluvio-aggregated.component.scss'],
})
export class WARNINGSPLUVIOAggregatedTableComponent implements AfterViewInit {
  @Input() clickData: Dewetra3LayerCommonEvent;
  @Input() sensors: SentinelFeature[];
  @Input() aggregateFeatureWithoutGeom: SENTINELAggreWithouGeom[];
  layer: WARNINGSLayerManager;
  cumulatedValueList: number[] = [];
  matrix$: BehaviorSubject<any[]> = new BehaviorSubject<any[]>([]);

  COLOR_DICT: any = {
    0: 'black',
    1: 'yellow',
    2: 'orange',
    3: 'red',
    4: 'blue',
  };

  PERIOD_DICT: number[] = [
    900,
    1800,
    3600,
    10800,
    21600,
    43200,
    64800,
    86400,
    129600,
  ]

  trasformToMatrix(sensors: SentinelFeature[], districtWithoutGeom: SENTINELAggreWithouGeom[], municipalitiesWithoutGeom: SENTINELAggreWithouGeom[]): any[] {
    const matrix: any[] = [];

    sensors.forEach((sensor) => {
      const raw: { [key: string]: any } = {}; // Change the type of raw
      raw['st'] = sensor.properties.st;

      const distrits_id = sensor.properties?.aggr?.districts_it;
      const municipalities_id = sensor.properties?.aggr?.municipalities_it_topoieti;

      districtWithoutGeom.forEach((aggr) => {
        if (distrits_id?.includes(aggr.id.toString())) {
          raw['st'] += ' - (' + aggr.name + ')';
        }
      });

      raw['municList'] = '';
      municipalitiesWithoutGeom.forEach((aggr) => {
        if (municipalities_id?.includes(aggr.id.toString())) {
          raw['municList'] += aggr.name + ', ';
        }
      });

      this.PERIOD_DICT.forEach((period) => {
        const value = this.getValueByPeriod(sensor, period);
        raw[period] = {};
        raw[period]['value'] = (value) ? value.v : 'na';
        raw[period]['color'] = this.getColorFromValue(raw[period]['value']);
        raw[period]['exceeding'] = sensor.properties.e.filter((e) => {
          return (e.name.split('_')[2] === this.transformToHour(period))
        });
        if (raw[period]['exceeding'] && raw[period]['exceeding'].length > 0) {
          raw[period]['exceedingSeverity'] = Math.max(...raw[period]['exceeding'].map((e: any) => e.sev));
          raw[period]['exceedingColor'] = this.getColorFromSeverity(raw[period]['exceedingSeverity']);
        } else {
          raw[period]['exceedingSeverity'] = 0;
          raw[period]['exceedingColor'] = this.getColorFromSeverity(0);
        }
      });
      matrix.push(raw);
    });

    return matrix;
  }

  getValueByPeriod(sensor: SentinelFeature, period: number): SentinelValueFeatureProperties {
    return sensor.properties.v.filter((v) => v.p == period)[0];
  }

  getColorFromValue(value: number): any {
    return '#000000';
  }

  getColorFromSeverity(severity: any): any {
    //return {"color": this.COLOR_DICT[severity]};
    return {"background-color": this.COLOR_DICT[severity]};
  }

  transformToHour(value: number): string {
    switch (value) {
      case 900:
        return '15m';
      case 1800:
        return '30m';
      case 3600:
        return '1h';
      case 10800:
        return '3h';
      case 21600:
        return '6h';
      case 43200:
        return '12h';
      case 64800:
        return '18h';
      case 86400:
        return '24h';
      case 129600:
        return '36h';
      default:
        return '';
    }
  }

  isAscending = true;
  orderProperty = '';

  orderMatrixByProperty(key1: string, key2: string) {
    this.orderProperty = key1;
    this.matrix$.next(this.matrix$.value.sort((a, b) => {
      const valA = a[key1]?.[key2];
      const valB = b[key1]?.[key2];

      // 'na' is less than any other value
      const numA = isNaN(Number(valA)) ? -Infinity : Number(valA);
      const numB = isNaN(Number(valB)) ? -Infinity : Number(valB);

      let comparison = numA < numB ? -1 : numA > numB ? 1 : 0;

      // invert the comparison if the order is descending
      comparison = this.isAscending ? comparison : -comparison;

      return comparison;
    }));

    // Inverti l'ordine per la prossima chiamata
    this.isAscending = !this.isAscending;
  }


  ngAfterViewInit(): void {
    this.layer = this.clickData.layer as WARNINGSLayerManager;

    const municipalities = this.layer.loadAggreatedLayerWithoutGeom('municipalities_it');
    const districts = this.layer.loadAggreatedLayerWithoutGeom('districts_it');

    forkJoin([municipalities, districts]).pipe(
      map(([municipalities, districts]) => {
        return this.trasformToMatrix(this.sensors, districts, municipalities);
      })
    ).subscribe((matrix) => {
      this.matrix$.next(matrix);
    });
    this.cumulatedValueList = (this.layer.data$.getValue().properties as WARNINGSLayerManagerProperties).cumulatedValueList;
  }
}

