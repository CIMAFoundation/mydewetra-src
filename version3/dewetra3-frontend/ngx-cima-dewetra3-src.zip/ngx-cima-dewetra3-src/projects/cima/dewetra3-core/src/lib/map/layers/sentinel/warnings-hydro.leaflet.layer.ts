import * as L from 'leaflet';
import { SENTINELLayerData } from "../../../managers/sentinel/sentinel.manager";
import { WARNINGSLayerManagerProperties } from '../../../managers/sentinel/warnings.manager';

import { CustomPropertiesWarnings, SentinelFeature } from '../../../models/sentinel';
import { buildSVGIcon, buildSVGShape, getLayerMapProperties } from "../../../utils/utils";
import { BaseLayer } from "../base/base.layer";
import { LayerDataContainer } from "../../../models/models";

import { BaseDewetra3LayerEventData, Dewetra3LayerEventWithData, LayerEventType } from '../../../managers/base/base.manager';

interface WarningsHydroLayerEventData extends BaseDewetra3LayerEventData {
  feature: any;
}

interface LegendItem {
  name: string
  type: string
  color: string
  descr: number
  label: string
  radius: number
  weight: number
  opacity: number
  severity: number
  fillColor: string
  fillOpacity: number
}

export class WarningsHydroLayerLeaflet extends BaseLayer {
  private featureLayer: L.GeoJSON;

  private LayerModel = this.layer.getLayerModel();

  override bringToFront(): void {
    this.featureLayer?.bringToFront();
  }

  override bringToBack(): void {
    this.featureLayer?.bringToBack();
  }

  override async updateMapLayer(data: LayerDataContainer): Promise<void> {
    const dataLayer = data.data as SENTINELLayerData
    const properties = data.properties as WARNINGSLayerManagerProperties
    if (this.featureLayer) {
      this.map.removeLayer(this.featureLayer);
    }

    console.log('updateMapLayer:', this.layer.getName());

    this.featureLayer = L.geoJSON(dataLayer.sentinelResponse, {

      filter: (feature) => {
        return this.featureFilter(feature as SentinelFeature, properties);
      },

      pointToLayer: (feature, latLng) => {
        return this.returnMarker(feature as SentinelFeature, latLng, properties);
      },
      onEachFeature: (feature, layer) => {
        layer.on({
          click: evt => this.emitLayerEvent('click', evt.target.feature),
          mouseover: evt => this.emitLayerEvent('mouseover', evt.target.feature),
          mouseout: evt => this.emitLayerEvent('mouseout', evt.target.feature)
        });
      }
    });


    this.map?.addLayer(this.featureLayer);
  }

  private emitLayerEvent(type: 'click' | 'mouseover' | 'mouseout', feature: any) {
    const data: WarningsHydroLayerEventData = { feature };
    const event = { type, layer: this.layer, data } as Dewetra3LayerEventWithData;
    this.onLayerEvent.emit(event);
  }

  override _remove(): void {
    if (!this.map || !this.featureLayer) return;
    this.map?.removeLayer(this.featureLayer);
  }

  override setOpacity(opacity: number): void {
    this.featureLayer?.setStyle({ opacity, fillOpacity: opacity });
  }

  override setVisible(visible: boolean): void {
    if (!this.map || !this.featureLayer) return;
    if (visible) {
      this.map?.addLayer(this.featureLayer);
    } else {
      this.map?.removeLayer(this.featureLayer);
    }
  }

  featureInFront(layer: L.Layer) {
    //@ts-ignore
    if (layer?.feature?.properties?.e && layer?.feature?.properties?.e.length > 0) {
      //@ts-ignore
      layer?.bringToFront();
    } else {
      //@ts-ignore
      layer?.bringToBack();
    }

  }

  featureFilter(feature: SentinelFeature, properties: WARNINGSLayerManagerProperties) {

    //if (feature?.geometry?.type === 'Point') return true;
    return true;


  }

  returnMarker(feature: SentinelFeature, latlng: L.LatLng, properties: WARNINGSLayerManagerProperties) {
    return L.marker(latlng, { icon: this.buildICON(feature, L.marker(latlng), properties) });
  }


  buildICON(feature: SentinelFeature, layer: L.Layer, properties: WARNINGSLayerManagerProperties) {
    const customProperties = getLayerMapProperties(this.layer.getLayerModel()) as CustomPropertiesWarnings;

    const markerProperties = {
      undefined: customProperties.default.legend[0],
      withoutThreshold: customProperties.default.legend[1],
      withThresholdNoExceeding: customProperties.default.legend[2],
      moderate: customProperties.default.legend[3],
      allarme: customProperties.default.legend[4],
      allerta: customProperties.default.legend[5],
      max: customProperties.default.legend[6],
    };

    let shape = 'square';

    const seriestate = feature.properties?.seriestate;

    function createIcon(shapeType: string, fillColor: string, color: string, seriestate: string): any {
      const shape = buildSVGShape(shapeType, fillColor, 'FF', color, '#FF', '2', '15', '15', parseInt(seriestate));
      return buildSVGIcon(shape);
    }

    switch (feature?.properties?.seriestate) {
      case '0':
        shape = 'square';
        break;
      case '1':
        shape = 'triangle';
        break;
      case '-1':
        shape = 'triangle';
        break;
      default:
        shape = 'square';
    }

    if (!feature?.properties?.v || !feature?.properties?.v?.length) {
      return createIcon(shape, markerProperties.undefined.fillColor, markerProperties.undefined.color, seriestate);
    }

    if (feature?.properties?.e && feature?.properties?.e?.length) {
      const maxSeverity = feature.properties.e.reduce((prev: any, current: any) => (prev.sev > current.sev) ? prev : current);

      switch (maxSeverity.sev) {
        case 1:
          return createIcon(shape, markerProperties.moderate.fillColor, markerProperties.moderate.color, seriestate);
        case 2:
          return createIcon(shape, markerProperties.allarme.fillColor, markerProperties.allarme.color, seriestate);
        case 3:
          return createIcon(shape, markerProperties.allerta.fillColor, markerProperties.allerta.color, seriestate);
        case 4:
          return createIcon(shape, markerProperties.allerta.fillColor, markerProperties.max.color, seriestate);
      }
    }

    if (feature?.properties?.v || feature?.properties?.v?.length) {

      if (feature?.properties?.nthr > 0) {
        return createIcon(shape, markerProperties.withThresholdNoExceeding.fillColor, markerProperties.withThresholdNoExceeding.color, seriestate);
      }

      if (feature?.properties?.nthr === 0) {
        return createIcon(shape, markerProperties.withoutThreshold.fillColor, markerProperties.withoutThreshold.color, seriestate);
      }
    }

    return createIcon(shape, markerProperties.undefined.fillColor, markerProperties.undefined.color, seriestate);
  }

  override getBounds(): L.LatLngBounds {
    return this.featureLayer?.getBounds();
  }

}
