import {CommonModule} from '@angular/common';
import {AfterViewInit, Component, Inject, inject, Input} from '@angular/core';
import {DomSanitizer, SafeHtml} from '@angular/platform-browser';
import {map, Observable, tap} from 'rxjs';
import {BaseLayerManager} from '../../../managers/base/base.manager';
import {Dewetra3MapClick} from '../../../models/models';
import {MAT_DIALOG_DATA, MatDialog} from "@angular/material/dialog";
import {CimaCommonsModule} from "@cima/commons";
import {MatIconButton} from "@angular/material/button";
import {MatTooltip} from "@angular/material/tooltip";
import {TranslateModule} from "@ngx-translate/core";

@Component({
  selector: 'dewetra3-wmst-glofas-info',
  standalone: true,
  imports: [CommonModule, MatIconButton, MatTooltip, TranslateModule],
  template: `
    <div *ngIf="manager">
      <div class="d-flex justify-content-between align-items-center">
        <h4 class="mb-1">{{ manager.getName() }}</h4>
        <button mat-icon-button (click)="openDialog()" matTooltip="{{'DEWETRA3APP.INFO' | translate}}">
          <span class="fas fa-expand-alt"></span>
        </button>
      </div>


      <ng-container *ngIf="infoToDisplay$ | async as info">
        <strong>{{ info.name }}</strong>
        <div [innerHTML]="info.point" class="inner"></div>
        <!-- Qui mostriamo il contenuto HTML -->
      </ng-container>
    </div>
  `,
  styleUrls: ['./wmst-glofas-info.component.scss'],
})
export class WMSTGlofasLayerInfoComponent implements AfterViewInit {
  @Input() manager!: BaseLayerManager;
  @Input() infoEvents$!: Observable<any>;
  @Input() clickData: Dewetra3MapClick;

  constructor(private matDialog: MatDialog) {
  }

  infoToDisplay$: Observable<any>;
  private sanitizer = inject(DomSanitizer);

  // Funzione per sanitizzare il contenuto HTML
  sanitizeHtml(html: string): SafeHtml {
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }

  openDialog() {
    this.matDialog.open(WMSTGlofasDialogInfoComponent, {
        data: this.infoToDisplay$,
      }
    )
  }


  ngAfterViewInit(): void {
    this.infoToDisplay$ = this.infoEvents$.pipe(
      map((info: any) => {
        const key = Object.keys(info.wmsData.content)[0];
        return {
          layer_name_index: key,
          point: this.sanitizeHtml(info.wmsData.content[key].point),
          name: info.wmsData.content[key].table,
        };
      }),
      tap(() => {
        // Accrocchio per colorare le celle della tabella con il colore della classe
        setTimeout(() => {
          document.querySelectorAll('.table-forecast-result td').forEach((td: any) => {
            td.classList.forEach((cls: any) => {
              if (/^[0-9A-Fa-f]{6}$/.test(cls)) {
                td.style.backgroundColor = `#${cls}`;
              }
            });
          });
        }, 0);
      })
    );
  }
}

@Component({
  selector: 'dewetra3-wmst-glofas-dialog-info',
  standalone: true,
  imports: [CommonModule, CimaCommonsModule],
  template: `
    <cima-dialog-title>
      {{ 'DEWETRA3APP.OPEN_FULL_SCREEN' | translate }}
    </cima-dialog-title>
    <cima-dialog-content>
      <ng-container *ngIf="data | async as info">
        <strong></strong>
        <div [innerHTML]="info?.point" class="inner"></div>
        <!-- Qui mostriamo il contenuto HTML -->
      </ng-container>
    </cima-dialog-content>
  `
})
export class WMSTGlofasDialogInfoComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: Observable<any>) {
  }
}
