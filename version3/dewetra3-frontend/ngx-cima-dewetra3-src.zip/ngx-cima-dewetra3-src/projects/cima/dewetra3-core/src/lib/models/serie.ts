export interface CustomPropertiesSeries {
  default: LegendTypeSeries
}

export interface LegendTypeSeries {
  alpha: string
  field: string
  width: number
  height: number
  legend: LegendItemTypeSeries[]
}

export interface LegendItemTypeSeries {
  name: string
  type: string
  alpha: string
  color: string
  descr: number
  field: string
  label: string
  shape: string
  severity: number
  textcolor: string
  stroke_alpha: string
  stroke_color: string
  stroke_width: string
  thr?: string
  value?: number
}
