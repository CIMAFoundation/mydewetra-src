import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
    name: 'reverse',
    pure: false
})
export class ReversePipe implements PipeTransform {
    transform(elements: any[]): any[] {
        return [...elements].reverse();

    }

}
