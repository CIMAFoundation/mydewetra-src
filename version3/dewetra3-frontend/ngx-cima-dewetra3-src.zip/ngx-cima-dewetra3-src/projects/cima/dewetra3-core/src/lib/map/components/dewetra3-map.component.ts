import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnDestroy, Output } from '@angular/core';
import * as L from 'leaflet';
import {
  BehaviorSubject,
  Observable,
  Subscription,
  combineLatest,
  distinctUntilChanged,
  filter,
  map,
  switchMap,
  tap,
} from 'rxjs';
import * as uuid from 'uuid';
import { BaseLayerManager, Dewetra3LayerCommonEvent, LayerWithViewProps } from '../../managers/base/base.manager';
import { BaseMapInfoResult, Dewetra3MapClick } from '../../models/models';
import { BaseLayer } from '../layers/base/base.layer';
import { MapLayerFactory } from '../map-layer-factory.service';

const DEFAULT_BBOX: [number, number][] = [
  [32, -7],
  [52.747092, 25.345362],
];

export const BASELAYER_OPENSTREETMAP = 'OpenStreetMap';
export const BASELAYER_GOOGLEMAPS = 'Google Maps';
export const BASELAYER_GOOGLESATELLITE = 'Google Satellite';
export const BASELAYER_GOOGLEHYBRID = 'Google Hybrid';
export const BASELAYER_GOOGLETERRAIN = 'Google Terrain';

export type Dewetra3MapBaseLayers =
  | 'OpenStreetMap'
  | 'Google Maps'
  | 'Google Satellite'
  | 'Google Hybrid'
  | 'Google Terrain';

const DEFAULT_BASEMAP_LIST = [
  {
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    maxZoom: 19,
    name: BASELAYER_OPENSTREETMAP,
  },
  {
    url: 'http://{s}.google.com/vt?lyrs=m&x={x}&y={y}&z={z}',
    maxZoom: 20,
    subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
    name: BASELAYER_GOOGLEMAPS,
  },
  {
    url: 'http://{s}.google.com/vt?lyrs=s&x={x}&y={y}&z={z}',
    maxZoom: 20,
    subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
    name: BASELAYER_GOOGLESATELLITE,
  },
  {
    url: 'http://{s}.google.com/vt?lyrs=y&x={x}&y={y}&z={z}&hl=en',
    maxZoom: 20,
    subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
    name: BASELAYER_GOOGLEHYBRID,
  },
  {
    url: 'http://{s}.google.com/vt?lyrs=p&x={x}&y={y}&z={z}',
    maxZoom: 20,
    subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
    name: BASELAYER_GOOGLETERRAIN,
  },
];

export type Dewetra3MapInfoResults = Map<BaseLayerManager, Observable<BaseMapInfoResult>>;

@Component({
  selector: 'dewetra3-map-component',
  template: ` <div [id]="mapId" class="dewetra3-map"></div> `,

  styles: [
    `
      :host {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        position: relative;

        &.cross-cursor {
          .dewetra3-map {
            cursor: crosshair !important;
          }
        }
      }

      .dewetra3-map {
        flex-grow: 1;
        overscroll-behavior: none;
        width: 100%;
      }

      .leaflet-tile {
        will-change: opacity;
        transition: opacity 0.3s ease-in-out;
      }
    `,
  ],
})
export class Dewetra3MapComponent implements AfterViewInit, OnDestroy {
  mapId: string = uuid.v4();
  private map: L.Map;
  private _baseMapsLayers: { [key: string]: L.TileLayer } = {};
  private _layersControl!: L.Control.Layers;

  /**
   * Gets the instance of the map.
   * @returns The map instance.
   */
  public get mapInstance(): L.Map {
    return this.map;
  }

  private _mapPosition: { center: L.LatLng; zoom: number };
  @Input() set mapPosition(position: { center: L.LatLng; zoom: number }) {
    if (!position) return;
    if (position?.center !== this._mapPosition?.center || position?.zoom !== this._mapPosition?.zoom) {
      this._mapPosition = position;
      this.map?.setView(position.center, position.zoom);
    }
  }

  @Input() zoomControlPosition: 'topleft' | 'topright' | 'bottomleft' | 'bottomright' = 'topleft';
  @Input() hideZoomControl: boolean = false;
  @Input() hideLayersControl: boolean = false;

  @Input() set baseLayer(layerName: Dewetra3MapBaseLayers) {
    this.loadBaseMap();
    const oldBaseLayer = this._preselectedBaseMap;
    this._preselectedBaseMap = this._baseMapsLayers[layerName];

    if (this.map) {
      if (oldBaseLayer) {
        this.map.removeLayer(this._preselectedBaseMap);
      }
      this._preselectedBaseMap.addTo(this.map);
      this._preselectedBaseMap.bringToBack();
    }
  }

  @Input() set adaptToBounds(bounds: [number, number][]) {
    if (!bounds) return;
    this.map.flyToBounds(bounds as L.LatLngBoundsLiteral);
  }

  @Output() mapPositionChange = new EventEmitter<{
    center: L.LatLng;
    zoom: number;
  }>();

  @Output() mousemoveEvent = new EventEmitter<{
    cursor: L.LatLng;
  }>();

  @Output() baseLayerChange = new EventEmitter<{
    layer: L.TileLayer;
    name: Dewetra3MapBaseLayers;
  }>();

  private layers$ = new BehaviorSubject<LayerWithViewProps[]>([]);

  @Input() set layers(newLayers: LayerWithViewProps[]) {
    this.layers$.next(newLayers);
  }

  @Output() onMapInfo = new BehaviorSubject<Dewetra3MapClick | null>(null);

  @Output() onLayerEvent = new EventEmitter<Dewetra3LayerCommonEvent>();

  public somethingLoading$ = this.layers$.pipe(
    filter((layers) => !!layers && layers.length > 0),
    switchMap((layers) => combineLatest(layers.map((layer) => layer.layer.isLoading$()))),
    map((loading) => loading.some((l) => l)),
    distinctUntilChanged(),
    tap((loading) => console.log('loading', loading))
  );

  public somethigsError$ = this.layers$.pipe(
    filter((layers) => !!layers && layers.length > 0),
    switchMap((layers) => combineLatest(layers.map((layer) => layer.layer.getError$()))),
    map((error) => error.some((l) => l)),
    distinctUntilChanged(),
    tap((error) => console.log('error', error))
  );

  private layersSubscription: Subscription;
  private reorderSubscription: Subscription;
  private resizeObserver = new ResizeObserver(() => this.map?.invalidateSize(true));
  private layerComponentMap: Map<LayerWithViewProps, BaseLayer> = new Map();
  private _preselectedBaseMap: L.TileLayer;

  constructor(private elementRef: ElementRef, private mapLayerFactory: MapLayerFactory) {
    this.resizeObserver.observe(this.elementRef.nativeElement);

    this.layersSubscription = this.layers$.subscribe((newLayers) => {
      for (const layer of this.layerComponentMap.keys()) {
        if (!newLayers.includes(layer)) {
          this.removeLayer(layer);
        }
      }

      for (const layer of newLayers) {
        if (!this.layerComponentMap.has(layer)) {
          if (!this.map) {
            // if the map is not initialized yet, just keep track of the layers to be initialized
            this.layerComponentMap.set(layer, null);
            continue;
          }
          this.addLayer(layer);
        }
      }

      if (this.map) {
        this.reorderLayers();
      }
    });

    this.reorderSubscription = this.somethingLoading$.subscribe((loading) => {
      if (!loading) {
        this.reorderLayers();
      }
    });
  }

  ngAfterViewInit() {
    this.initMap();
    this.initEvents();
  }

  ngOnDestroy() {
    this.resizeObserver.disconnect();
    this.layersSubscription.unsubscribe();
    this.reorderSubscription.unsubscribe();
  }

  private reorderLayers() {
    const layers = [...this.layers$.value].reverse();
    for (let layer of layers) {
      const layerComponent = this.layerComponentMap.get(layer);
      layerComponent?.bringToFront();
    }
  }

  private loadBaseMap() {
    DEFAULT_BASEMAP_LIST.map((baseMap) => {
      if (baseMap.subdomains) {
        this._baseMapsLayers[baseMap.name] = L.tileLayer(baseMap.url, {
          maxZoom: baseMap.maxZoom,
          subdomains: baseMap.subdomains,
        });
      } else {
        this._baseMapsLayers[baseMap.name] = L.tileLayer(baseMap.url, {
          maxZoom: baseMap.maxZoom,
        });
      }
    });

    if (!this._preselectedBaseMap) {
      this._preselectedBaseMap = this._baseMapsLayers[BASELAYER_GOOGLEHYBRID];
    }
  }

  private initMap() {
    this.loadBaseMap();

    this.map = L.map(this.mapId, {
      layers: [this._preselectedBaseMap],
      zoomControl: false,
    });

    // add the scale control
    L.control.scale({ position: 'bottomright', metric: true, imperial: false }).addTo(this.map);

    if (!this.hideLayersControl) this._layersControl = L.control.layers(this._baseMapsLayers).addTo(this.map);

    // initialize the layers that were set before the map was created
    for (const layer of this.layerComponentMap.keys()) {
      if (this.layerComponentMap.get(layer) === null) {
        this.addLayer(layer);
      }
    }

    //move zoom control to top right
    if (!this.hideZoomControl) L.control.zoom({ position: this.zoomControlPosition }).addTo(this.map);

    // if the map position is not set, set the default one
    if (!this._mapPosition) {
      this.map.fitBounds(DEFAULT_BBOX as L.LatLngBoundsLiteral);
    } else {
      this.map.setView(this._mapPosition.center, this._mapPosition.zoom);
    }

    this._preselectedBaseMap.bringToBack();
  }

  initEvents() {
    this.map.on('click', (event) => this.mapClicked(event.latlng));

    this.map.on('moveend', (e: any) => {
      this._mapPosition = {
        center: this.map.getCenter(),
        zoom: this.map.getZoom(),
      };
      this.mapPositionChange.emit(this._mapPosition);
    });

    this.map.on('zoomend', (e: any) => {
      this._mapPosition = {
        center: this.map.getCenter(),
        zoom: this.map.getZoom(),
      };
      this.mapPositionChange.emit(this._mapPosition);
    });

    this.map.on('mousemove', (e: any) =>
      this.mousemoveEvent.emit({
        cursor: e.latlng,
      })
    );

    this.map.on('baselayerchange', (e: any) =>
      this.baseLayerChange.emit({
        layer: e.layer,
        name: e.name,
      })
    );
  }

  mapClicked(latlng: L.LatLng) {
    const event = {
      latLng: latlng,
      map: this.map,
    };
    this.onMapInfo.next(event);
  }

  centerMap(latlng: L.LatLng, zoom: number) {
    this.map.setView(latlng, zoom);
  }

  private addLayer(layer: LayerWithViewProps) {
    // get the leafletLayerComponent for the layer
    const layerType = layer.layer.getLayerModel();

    // create the component
    const component = this.mapLayerFactory.create(layerType, this.map, layer, this.onLayerEvent);

    // add the component to the map
    this.layerComponentMap.set(layer, component);
  }

  private removeLayer(layer: LayerWithViewProps) {
    const layerComponent = this.layerComponentMap.get(layer);
    layerComponent.remove();
    this.layerComponentMap.delete(layer);
  }

  public zoomOnLayer(layer: BaseLayerManager | LayerWithViewProps) {
    let layerComponent: BaseLayer = undefined;
    if (layer instanceof BaseLayerManager) {
      const layerWithProps = [...this.layerComponentMap.keys()].find((layerWProps) => layerWProps.layer === layer);
      if (!layerWithProps) {
        console.log('Layer not found', layer);
        return;
      }
      layerComponent = this.layerComponentMap.get(layerWithProps);
    } else {
      layerComponent = this.layerComponentMap.get(layer);
    }
    layerComponent.zoomOnLayer();
  }

  moveToLocation(lat: number, lng: number, zoom: number) {
    this.map.flyTo([lat, lng], zoom, {
      animate: true,
      duration: 2, // duration in seconds
    });
  }
}
