import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CimaCommonsModule } from '@cima/commons';
import { DynamicModule } from 'ng-dynamic-component';
import { CustomLegendComponent } from './components/custom/custom-legend.component';
import { ImageLegendComponent } from './components/custom/image-legend.component';
import { DDSLegendComponent } from './components/dds/dds-legend.component';
import { DDSWMSLegendComponent } from './components/dds/dds-wms-legend.component';
import { FLOODPROOFSLegendComponent } from './components/floodproofs/floodproofs-legend.component';
import { GeoserverLegendComponent } from './components/geoserver/geoserver-legend.component';
import { SENTINELLegendComponent } from './components/sentinel/sentinel-legend.component';
import { LegendWrapperComponent } from './components/wrapper/legend-wrapper.component';

@NgModule({
  declarations: [
    LegendWrapperComponent,
    DDSLegendComponent,
    GeoserverLegendComponent,
    SENTINELLegendComponent,
    FLOODPROOFSLegendComponent,
    CustomLegendComponent,
    DDSWMSLegendComponent,
  ],
  imports: [CommonModule, DynamicModule, CimaCommonsModule, ImageLegendComponent],
  exports: [
    LegendWrapperComponent,
    DDSLegendComponent,
    GeoserverLegendComponent,
    SENTINELLegendComponent,
    FLOODPROOFSLegendComponent,
    CustomLegendComponent,
    DDSWMSLegendComponent,
  ],
})
export class Dewetra3LegendModule {}
