import { Moment } from 'moment';
import { Observable, filter, map, shareReplay, switchMap } from 'rxjs';
import { BaseMapInfoResult, LayerDataContainer, WMSInfoResponse } from '../../models/models';
import { getWMSLayerInfoUrl, parseUnixTimestampOrDateFormatted } from '../../utils/utils';
import { DDSLayerData, DDSLayerManager, DDSLayerManagerProperties, DDSLayerMapInfoResult } from './dds.manager';
import { DDSWMSLayerManager } from './dds.wms.manager';

export class ObservationDDSWMSLayerManager extends DDSWMSLayerManager {

  public override getLayerDetail$(): Observable<string> {

    return this.data$.pipe(
      filter((layerData: LayerDataContainer) => {
        return layerData !== null && layerData.data !== null && layerData.properties !== null;
      }),
      map((layerData: LayerDataContainer) => {
        const data = layerData.data as DDSLayerData;
        const properties = layerData.properties as DDSLayerManagerProperties;

        if (layerData.status === 'error') {
          return 'ERROR LOADING LAYER';
        }

        // Safely access the variable, fallback to empty string if undefined
        const variable = properties?.ddsProperties?.layerProperties?.attributes
          ?.find(attr => attr.name === 'variable')?.selectedEntry?.descr || 'Unknown Variable';

        const splittedLayerId = data?.published?.layerid?.split('_').slice(-2);

        if (!splittedLayerId || splittedLayerId.length < 2) {
          return `${variable}`; // If the layerId structure is unexpected, return variable only
        }

        // Parse the timestamps
        const dateRun: Moment = parseUnixTimestampOrDateFormatted(splittedLayerId[0]);
        const dateRef: Moment = parseUnixTimestampOrDateFormatted(splittedLayerId[1]);

        return `${dateRef.format('DD/MM/YYYY HH:mm')}  &nbsp;{{${variable}}}`;


  
      })
    );
  }


}
