import {AfterViewInit, Component, Input} from '@angular/core';
import * as Plotly from 'plotly.js-dist-min';
import {Observable, of} from 'rxjs';
import {catchError, filter, map, startWith, switchMap, tap} from 'rxjs/operators';
import * as uuid from 'uuid';
import {BaseLayerManager} from '../../../managers/base/base.manager';
import {DDSLayerManagerProperties, DDSLayerPunctualSeriesResult} from '../../../managers/dds/dds.manager';
import {DDSAttribute, Entry} from '../../../models/layer-properties';
import {DDSWMSLayerManager} from 'projects/cima/dewetra3-core/src/public-api';
import {MatTabChangeEvent} from '@angular/material/tabs';

@Component({
  selector: 'timeseries-properties-chart',
  template: `
    <ng-container *ngIf="loadingChart$ | async; else chartContent">
      <div>
        {{ 'DEWETRA3CORE.LOADING_CHART' | translate }}...
      </div>
      <div class="d-flex justify-content-center align-items-center flex-column">
        <mat-progress-bar mode="indeterminate"></mat-progress-bar>
      </div>
    </ng-container>
    <ng-template #chartContent>
      <mat-tab-group [selectedIndex]="selectedIndex" (selectedTabChange)="onTabSelect($event)">
        <mat-tab *ngFor="let property of (entries$ | async) || []; let i = index" [label]="property.descr"></mat-tab>
      </mat-tab-group>

    </ng-template>
    <div class="p-2">
      <div [id]="chartId" class="rounded-2 time-series-chart-wrapper overflow-hidden"></div>
    </div>
  `,
  styles: ['::ng-deep{.mat-mdc-dialog-content{.time-series-chart-wrapper {height: calc(90vh - 210px)}; .time-series-chart-wrapper {width: 100%;}}}']
})
export class TimeSeriesPropertiesChartComponent implements AfterViewInit {
  @Input() manager!: BaseLayerManager;
  @Input() clickData: any;
  @Input() dateFrom!: Date;
  @Input() dateTo!: Date;
  @Input() chartEvents$!: Observable<DDSLayerPunctualSeriesResult>;

  public chartId = uuid.v4();
  public loadingChart$!: Observable<boolean>;
  public selectedIndex = 0;
  public entries$!: Observable<Entry[]>;
  private DDSLayerManagerProperties!: DDSLayerManagerProperties;
  private seriesResultData: any;

  ngAfterViewInit(): void {
    this.entries$ = this.manager.getProperties$().pipe(
      filter(data => !!data),
      map(data => this.DDSLayerManagerProperties = data as DDSLayerManagerProperties),
      map(data => {
        const entries = data.ddsProperties.layerProperties.attributes.find(attr => attr.name === 'variable')?.entries;
        return Array.isArray(entries) ? entries : [];
      })
    );

    this.loadingChart$ = this.chartEvents$.pipe(
      filter(data => !!data && data.status === 'loaded'),
      switchMap(async (data) => {
        this.seriesResultData = data;
        console.log('Plotting chart', data);
        await Plotly.newPlot(this.chartId, data.data);
        return false;
      }),
      startWith(true)
    );
  }

  onTabSelect(event: MatTabChangeEvent): void {
    const index = event.index;
    this.entries$.pipe(
      map(data => {
        const selectedProperty = data[index];
        console.log('Selected property', data);
        this.loadChartByProperty(selectedProperty);
      })
    ).subscribe();
  }

  private loadChartByProperty(property: Entry): void {
    const manager = this.manager as DDSWMSLayerManager;
    const propsCopied = JSON.parse(JSON.stringify(this.DDSLayerManagerProperties));
    propsCopied.ddsProperties.layerProperties.attributes.find((attr: DDSAttribute) => attr.name === 'variable')!.selectedEntry = property;
    propsCopied.ddsProperties.layerProperties.attributes.find((attr: DDSAttribute) => attr.name === 'variable')!.value = property.value;

    manager.getPunctualSeries$(this.clickData.latLng, this.dateFrom, this.dateTo, propsCopied).pipe(
      tap(async data => {
        if (data?.status === 'error') {
          console.error('Errore dal server:', data);
          await Plotly.purge(this.chartId);
          throw new Error(data.error || 'Errore sconosciuto'); // Propaga l'errore
        }
      }),
      filter(data => !!data && data.status === 'loaded'),
      switchMap(async (data) => {
        await Plotly.purge(this.chartId);
        console.log('Plotting property data', data);
        //@ts-ignore
        await Plotly.newPlot(this.chartId, data.data);
      }),
      catchError(error => {
        console.error('Errore gestito:', error);
        return of(null); // Restituisce un valore nullo per evitare che lo stream si interrompa
      })
    ).subscribe();
  }
}
