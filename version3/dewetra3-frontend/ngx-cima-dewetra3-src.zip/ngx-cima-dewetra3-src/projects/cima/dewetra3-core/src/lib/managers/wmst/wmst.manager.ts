import {
  BaseLayerManagerData,
  BaseLayerManagerProperties,
  BaseMapInfoResult,
  LayerDataContainer,
  WMSInfoResponse,
} from '../../models/models';

import { Observable, filter, map, shareReplay, switchMap } from 'rxjs';
import { buildDateOnPreFormat, getCustomProperties, getWMSLayerInfoUrl } from '../../utils/utils';
import { BaseLayerManager } from '../base/base.manager';

export interface WMSTLayerManagerProperties extends BaseLayerManagerProperties {
  time_builder: string;
  date_format: string;
  wmsparams: any;
}

export interface WMSTLayerData extends BaseLayerManagerData {
  layerid: string;
  serverUrl: string;
  formattedDate: string;
}

export interface WMSTMapInfoResult extends BaseMapInfoResult {
  wmsData: any;
}

export class WMSTLayerManager extends BaseLayerManager {
  override async getDefaultProperties(dateFrom: Date, dateTo: Date | 'now'): Promise<BaseLayerManagerProperties> {
    const layerCustomProperties = getCustomProperties(this.getLayerModel()) ?? {};

    const time_builder =
      typeof layerCustomProperties.time_builder === 'string' ? layerCustomProperties.time_builder : 'nearestMidNight';
    const date_format =
      typeof layerCustomProperties.date_format === 'string' ? layerCustomProperties.date_format : 'yyyy-MM-dd';
    const wmsparams = typeof layerCustomProperties.wmsparams === 'object' ? layerCustomProperties.wmsparams : {};

    return {
      dateFrom,
      dateTo,
      time_builder,
      date_format,
      wmsparams,
    } as WMSTLayerManagerProperties;
  }

  async getLayerData(properties: WMSTLayerManagerProperties): Promise<WMSTLayerData> {
    let formattedDate = buildDateOnPreFormat(properties.time_builder, properties.dateTo, properties.date_format);

    return {
      formattedDate,
      layerid: this.layerModel.dataid,
      serverUrl: this.layerModel.server.url,
    } as WMSTLayerData;
  }

  public override getInfo$(latlng: L.LatLng): Observable<WMSTMapInfoResult> {
    return this.data$.pipe(
      // 1) Assicuriamoci di avere dati + proprietà valide
      filter(
        (
          ld
        ): ld is LayerDataContainer & {
          data: WMSTLayerData;
          properties: WMSTLayerManagerProperties;
        } => !!ld && !!ld.data && !!ld.properties
      ),

      // 2) Costruiamo URL e manteniamo latlng
      map((ld) => {
        const data = ld.data;
        const props = ld.properties;
        const baseUrl = this.layerModel.server.url;
        const layerId = this.layerModel.dataid;
        const extraParams = {
          time: data.formattedDate,
          ...props.wmsparams,
        };

        const url = getWMSLayerInfoUrl(baseUrl, latlng, layerId, { extraParams });

        return { url, latlng };
      }),

      // 3) Facciamo la chiamata WMS e rimappiamo in WMSTMapInfoResult
      switchMap(({ url, latlng }) =>
        this.getExternal<WMSInfoResponse>(url).pipe(
          map((wmsData) => ({ latLng: latlng, wmsData } as WMSTMapInfoResult)),
          shareReplay(1)
        )
      )
    );
  }
}
