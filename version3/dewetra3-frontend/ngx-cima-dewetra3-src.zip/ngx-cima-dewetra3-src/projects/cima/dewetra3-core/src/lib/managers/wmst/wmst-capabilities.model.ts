export interface  WMS_CapabilitiesModel{
  WMS_Capabilities: WmsCapabilities
}

export interface WmsCapabilities {
  "@xmlns:inspire_vs": string
  "@xmlns:inspire_common": string
  "@version": string
  "@updateSequence": string
  "@xmlns": string
  "@xmlns:xlink": string
  "@xmlns:xsi": string
  "@xsi:schemaLocation": string
  Service: Service
  Capability: Capability
}

export interface Service {
  Name: string
  Title: any
  Abstract: any
  KeywordList: any
  OnlineResource: OnlineResource
  ContactInformation: ContactInformation
  Fees: string
  AccessConstraints: string
}

export interface OnlineResource {
  "@xlink:type": string
  "@xlink:href": string
}

export interface ContactInformation {
  ContactPersonPrimary: ContactPersonPrimary
  ContactPosition: string
  ContactAddress: ContactAddress
  ContactVoiceTelephone: any
  ContactFacsimileTelephone: any
  ContactElectronicMailAddress: string
}

export interface ContactPersonPrimary {
  ContactPerson: string
  ContactOrganization: string
}

export interface ContactAddress {
  AddressType: string
  Address: string
  City: string
  StateOrProvince: string
  PostCode: string
  Country: string
}

export interface Capability {
  Request: Request
  Exception: Exception
  Layer: Layer
}

export interface Request {
  GetCapabilities: GetCapabilities
  GetMap: GetMap
  GetFeatureInfo: GetFeatureInfo
}

export interface GetCapabilities {
  Format: string
  DCPType: Dcptype
}

export interface Dcptype {
  HTTP: Http
}

export interface Http {
  Get: Get
  Post: Post
}

export interface Get {
  OnlineResource: OnlineResource2
}

export interface OnlineResource2 {
  "@xlink:type": string
  "@xlink:href": string
}

export interface Post {
  OnlineResource: OnlineResource3
}

export interface OnlineResource3 {
  "@xlink:type": string
  "@xlink:href": string
}

export interface GetMap {
  Format: string[]
  DCPType: Dcptype2
}

export interface Dcptype2 {
  HTTP: Http2
}

export interface Http2 {
  Get: Get2
}

export interface Get2 {
  OnlineResource: OnlineResource4
}

export interface OnlineResource4 {
  "@xlink:type": string
  "@xlink:href": string
}

export interface GetFeatureInfo {
  Format: string[]
  DCPType: Dcptype3
}

export interface Dcptype3 {
  HTTP: Http3
}

export interface Http3 {
  Get: Get3
}

export interface Get3 {
  OnlineResource: OnlineResource5
}

export interface OnlineResource5 {
  "@xlink:type": string
  "@xlink:href": string
}

export interface Exception {
  Format: string[]
}

export interface Layer {
  Title: any
  Abstract: any
  CRS: string[]
  EX_GeographicBoundingBox: ExGeographicBoundingBox
  BoundingBox: BoundingBox
  Layer: Layer2[]
}

export interface ExGeographicBoundingBox {
  westBoundLongitude: string
  eastBoundLongitude: string
  southBoundLatitude: string
  northBoundLatitude: string
}

export interface BoundingBox {
  "@CRS": string
  "@minx": string
  "@miny": string
  "@maxx": string
  "@maxy": string
}

export interface Layer2 {
  "@queryable": string
  Name: string
  Title: string
  Abstract: string
  KeywordList?: KeywordList
  CRS: any
  EX_GeographicBoundingBox: ExGeographicBoundingBox2
  BoundingBox: BoundingBox2[]
  Style: Style
  "@opaque"?: string
  Dimension?: Dimension
  MaxScaleDenominator?: string
}

export interface KeywordList {
  Keyword: string[]
}

export interface ExGeographicBoundingBox2 {
  westBoundLongitude: string
  eastBoundLongitude: string
  southBoundLatitude: string
  northBoundLatitude: string
}

export interface BoundingBox2 {
  "@CRS": string
  "@minx": string
  "@miny": string
  "@maxx": string
  "@maxy": string
}

export interface Style {
  Name: string
  Title: string
  Abstract?: string
  LegendURL: LegendUrl
}

export interface LegendUrl {
  "@width": string
  "@height": string
  Format: string
  OnlineResource: OnlineResource6
}

export interface OnlineResource6 {
  "@xmlns:xlink": string
  "@xlink:type": string
  "@xlink:href": string
}

export interface Dimension {
  "@name": string
  "@default": string
  "@units": string
  "#text": string
}
