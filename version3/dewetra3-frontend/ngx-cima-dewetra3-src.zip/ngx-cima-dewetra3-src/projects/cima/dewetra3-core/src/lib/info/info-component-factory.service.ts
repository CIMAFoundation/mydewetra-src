import { Injectable } from '@angular/core';
import { LayerModel } from '../models/dewetra3-layer';
import { DDSLayerInfoComponent } from './components/dds/ddslayer-info.component';
import { WMSLayerInfoComponent } from './components/wms/wms-info.component';
import { DebugInfoComponent } from './components/debug/debug-info.components';
import { WMSTCopernicusLayerInfoComponent } from './components/wmst/wmst-coperrnicus-info.component';
import { WMSTLayerInfoComponent } from './components/wmst/wmst-info.component';
import { DDSWMSCustomInfoComponent } from './components/dds/dds-custom-info.component';
import { WMSTGlofasLayerInfoComponent } from './components/wmst/wmst-glofas-info.component';


 


@Injectable({
  providedIn: 'root'
})
export class InfoComponentFactory {
  static DEFAULT_INFO_COMPONENTS = {
    'DDSInfoComponent': DDSLayerInfoComponent,
    'WMSInfoComponent': WMSLayerInfoComponent,
    'SeriesInfoComponent': WMSLayerInfoComponent,
    'DebugInfoComponent': DebugInfoComponent,
    'WMSTCopernicusLayerInfoComponent':WMSTCopernicusLayerInfoComponent,
    'WMSTGlofasLayerInfoComponent': WMSTGlofasLayerInfoComponent,
    'WMSTLayerInfoComponent': WMSTLayerInfoComponent,
    'DDSWMSCustomInfoComponent': DDSWMSCustomInfoComponent
  };

  private _registry: Map<string, any> = new Map(Object.entries(InfoComponentFactory.DEFAULT_INFO_COMPONENTS))

  constructor() { }

  set(name: string, component: any) {
    this._registry.set(name, component);
  }

  create(layerModel: LayerModel): any {
    const klass = this._registry.get(layerModel.infomanager.component);
    return klass;
  }
}
