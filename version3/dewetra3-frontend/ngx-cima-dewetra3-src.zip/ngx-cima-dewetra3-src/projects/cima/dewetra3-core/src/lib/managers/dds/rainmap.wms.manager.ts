import { signal, WritableSignal } from '@angular/core';
import { Moment } from 'moment';
import { filter, map, Observable, shareReplay, switchMap } from 'rxjs';
import { BaseMapInfoResult, LayerDataContainer, WMSInfoResponse } from '../../models/models';
import {
  getWMSLayerInfoUrl,
  parseUnixTimestampOrDateFormatted,
  transformStringToTranslatablePlaceholder,
} from '../../utils/utils';

import { MovieStatus } from '../../models/movie';
import { DDSLayerData, DDSLayerManager, DDSLayerManagerProperties, DDSLayerMapInfoResult } from './dds.manager';

export class RainMapDDSLayerManager extends DDSLayerManager {
  override currentMovieState: WritableSignal<MovieStatus> = signal({
    status: 'idle',
    available: true,
    progressMap: {
      frames: [],
      currentIndex: 0,
      canProceed: false,
    },
  });

  /**
   * Retrieves the base map information for the given latitude and longitude.
   * @param latlng The latitude and longitude coordinates.
   * @returns An observable that emits the base map information.
   */
  public override getInfo$(latlng: L.LatLng): Observable<BaseMapInfoResult> {
    return this.data$.pipe(
      map((layerData: LayerDataContainer) => {
        const data = layerData.data as DDSLayerData;
        const dataId = data.published.layerid;
        const serverUrl = this.getLayerModel().server.url;
        const url = getWMSLayerInfoUrl(data.serverUrl, latlng, dataId);
        return url;
      }),
      switchMap((url) =>
        this.getExternal<WMSInfoResponse>(url).pipe(
          map((data) => ({ wmsData: data } as DDSLayerMapInfoResult)),
          shareReplay()
        )
      )
    );
  }

  public override getLayerDetail$(): Observable<string> {
    return this.data$.pipe(
      filter((layerData: LayerDataContainer) => {
        return layerData !== null && layerData.data !== null && layerData.properties !== null;
      }),
      map((layerData: LayerDataContainer) => {
        const data = layerData.data as DDSLayerData;
        const properties = layerData.properties as DDSLayerManagerProperties;

        if (layerData.status === 'error') {
          return 'ERROR LOADING LAYER';
        }

        // Safely access the variable, fallback to empty string if undefined
        const variable =
          properties?.ddsProperties?.layerProperties?.attributes?.find((attr) => attr.name === 'aggregation')?.descr ||
          'Unknown Variable';

        // Safely access the variable, fallback to empty string if undefined
        const timeRange =
          properties?.ddsProperties?.layerProperties?.attributes?.find((attr) => attr.name === 'aggregation')
            ?.selectedEntry?.descr || 'Unknown Variable';

        const splittedLayerId = data?.published?.layerid?.split('_').slice(-2);

        if (!splittedLayerId || splittedLayerId.length < 2) {
          return `${variable}`; // If the layerId structure is unexpected, return variable only
        }

        // Parse the timestamps
        const dateRunRef: Moment = parseUnixTimestampOrDateFormatted(splittedLayerId[0]);
        const dateRefFormatted: Moment = parseUnixTimestampOrDateFormatted(splittedLayerId[1]);

        const variablePlaceHolder = transformStringToTranslatablePlaceholder(variable);
        const timeRangePlaceHolder = transformStringToTranslatablePlaceholder(timeRange);

        return ` ${dateRunRef.format('DD/MM/YYYY HH:mm')} <br> ${variablePlaceHolder} (${timeRangePlaceHolder})`;
      })
    );
  }
}
