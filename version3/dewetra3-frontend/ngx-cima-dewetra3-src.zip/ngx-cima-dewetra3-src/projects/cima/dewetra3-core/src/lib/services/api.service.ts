import { HttpClient, HttpHeaders } from "@angular/common/http";
import {Inject, Injectable} from '@angular/core';
import {CimaEnvironment} from "@cima/commons";
import {BehaviorSubject, firstValueFrom, Observable, tap} from "rxjs";
import { LayerHazard, LayerModel } from "../models/dewetra3-layer";

@Injectable({
  providedIn: 'root'
})
export class Dewetra3ApiService {

  private dewapiServerURL = this.env.server.baseUrl + '/dewetra3/dewapi';
  private toolsServerURL = this.env.server.baseUrl + '/dewetra3/toolsapi';
  private floodcatServerURL = this.env.server.baseUrl + '/dewetra3/floodcatapi';

  private _layers: BehaviorSubject<LayerModel[]> = new BehaviorSubject<LayerModel[]>([]);

  private _layersFilteredByHazard: BehaviorSubject<LayerModel[]> = new BehaviorSubject<LayerModel[]>([]);

  constructor(
    @Inject('env') private env: CimaEnvironment,
    private _http: HttpClient
  ) {
    this.getLayers();
  }


  buildDewApiURL(url: string) {
    return this.dewapiServerURL + url;
  }

  proxyMe(payload: any) {
    const proxyUrl = this.dewapiServerURL + 'utils/proxy/';
  }

  proxyGeneric(url: string) {
    const proxyUrl = this.dewapiServerURL + 'utils/genericproxy/';
    return this._http.get(proxyUrl + '?url=' + url);
  }

  get<T>(url: string, params?: any, server?: string): Observable<T> {
    if (!server) server = this.dewapiServerURL;
    return this._http.get<T>(server + url, {params: params});
  }

  post<T>(url: string, payload: any, server?: string): Observable<T> {
    if (!server) server = this.dewapiServerURL;
    return this._http.post<T>(server + url, payload);
  }

  getFloodCatApi<T>(url: string, params?: any): Observable<T> {
    return this._http.get<T>(this.floodcatServerURL + url, {params: params});
  }

  postTools<T>(url: string, payload: any, server?: string): Observable<T> {
    if (!server) server = this.toolsServerURL;
    return this._http.post<T>(server + url, payload);
  }

  getPostToolsUrl(url: string) {
    return this.toolsServerURL + url;
  }

  uploadChunk(url: string, file: File, start: number, chunkSize: number, fileId: string, chunkIndex: number): Observable<any> {
    const end = Math.min(start + chunkSize, file.size);
    const isLastChunk = end === file.size;

    const chunk = file.slice(start, end);

    const formData = new FormData();
    formData.append('chunk', chunk);
    formData.append('fileId', fileId);
    formData.append('chunkIndex', chunkIndex.toString());
    formData.append('fileName', file.name);
    formData.append('fileExtension', file.name.split('.').pop());
    formData.append('isLastChunk', isLastChunk.toString());

    return this._http.post(this.getPostToolsUrl(url), formData);
  }

  async getLayers(): Promise<void> {
    const layers = await firstValueFrom(this.get<LayerModel[]>('/layers/'));
    this._layers.next(layers as LayerModel[]);
  }

  getLayers$(): Observable<LayerModel[]> {
    return this._layers.asObservable();
  }


}
