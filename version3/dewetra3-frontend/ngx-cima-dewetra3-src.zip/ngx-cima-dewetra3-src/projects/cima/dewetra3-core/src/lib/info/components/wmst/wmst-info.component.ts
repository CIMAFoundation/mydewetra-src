import {AfterViewInit, Component, Input} from '@angular/core';
import {Observable, map} from 'rxjs';

import {BaseLayerManager} from '../../../managers/base/base.manager';
import {Dewetra3MapClick} from '../../../models/models';

@Component({
  selector: 'dewetra3-wmst-info',
  template: `
    <div *ngIf="manager">
      <h4 class="mb-1">{{ manager.getName() }}</h4>

      <ng-container *ngIf="infoToDisplay$ | async as info">
        <div *ngFor="let feature of info">
          <div *ngFor="let property of feature | keyvalue">
            <span class="label">{{ property.key }}:</span><span> {{ property.value }}</span>
          </div>
        </div>
      </ng-container>
    </div>

  `,
  styles: ['.label { font-weight: bold; color: var(--dewetra-orange); }']
})
export class WMSTLayerInfoComponent implements AfterViewInit {
  @Input() manager!: BaseLayerManager;
  @Input() infoEvents$!: Observable<any>;
  @Input() clickData: Dewetra3MapClick;

  infoToDisplay$: Observable<any>;

  ngAfterViewInit(): void {
    this.infoToDisplay$ = this.infoEvents$.pipe(
      map((info: any) => {
        return info.wmsData.features.map((feature: any) => {
          return feature.properties;
        });
      })
    )
  }

}
