import { Pipe, PipeTransform } from '@angular/core';
import { LayerModel } from '../models/dewetra3-layer';
import { LayerWithViewProps } from '../managers/base/base.manager';



@Pipe({
  name: 'hasPunctualSeries'
})
export class FilterByPunctualSeriesPipe implements PipeTransform {

  transform(layers: LayerWithViewProps[]): LayerWithViewProps[] {
    if (layers && layers.length >= 0 ) {
      return layers.filter(layer => layer.layer.hasPunctualSeries());
    } else {
      return layers as LayerWithViewProps[];
    }

  }

}
