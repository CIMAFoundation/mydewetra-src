import { Component } from '@angular/core';

@Component({
  selector: 'dewetra3-metadata-link',
  template: `
    <p>METADATA LINK</p>
  `,
  styleUrls: [],
})
export class LinkMetadataComponent {

  constructor(

  ) {

  }
}
