import { Component, inject, Input } from '@angular/core';
import { TimepickerService, TimepickerValue } from '@cima/commons';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import {
  SENTINELLayerData,
  SENTINELLayerManager,
  SENTINELLayerManagerProperties
} from '../../../managers/sentinel/sentinel.manager';


@Component({
  selector: 'dewetra3-sentinel-properties',
  template: `
    <ng-template #loader>
      <div class="w-100 h-100 d-flex justify-content-center align-items-center">
        <mat-progress-bar mode="indeterminate"></mat-progress-bar>
      </div>
    </ng-template>

    @if (manager) {
      <div class="manager-event-wrap d-flex justify-content-center">
        @if (properties$ | async; as managerProperties) {
          <!-- check if properties$ is available -->
          <div class="d-flex col-6">
            @if (managerProperties.aggregationsList; as aggregationsLevel) {
              <!-- check if ddsProperties is available -->
              <mat-form-field class="mx-1 flex-fill">
                <mat-label>{{ 'DEWETRA3CORE.AGGREGATIONS' | translate }}</mat-label>
                <mat-select [value]="properties.aggregationSelected" (selectionChange)="selectAggregation( $event)">
                  @for (aggregation of aggregationsLevel; track $index) {
                    <!-- loop through entries -->
                    <mat-option [value]="aggregation">{{ aggregation }}</mat-option>
                  }
                </mat-select>
              </mat-form-field>
            }
          </div>
          <div class="d-flex col-6">
            @if (managerProperties.cumulatedValueList; as cumulatedValues) {
              <!-- check if ddsProperties is available -->
              <mat-form-field class="mx-1 flex-fill">
                <mat-label>{{ 'DEWETRA3CORE.ACCUMULATION_SELECTED' | translate }}</mat-label>
                <mat-select [value]="properties.cumulatedValueSelected" (selectionChange)="selectAccumulated( $event)">
                  @for (accumulated of cumulatedValues; track $index) {
                    <!-- loop through entries -->
                    <mat-option [value]="accumulated">{{ transformSecondsToHours(accumulated) }}</mat-option>
                  }
                </mat-select>
              </mat-form-field>
            }
          </div>
        }
      </div>
      <div class="d-flex justify-content-center">
        <button mat-raised-button color="primary" (click)="apply()">
          {{ 'DEWETRA3APP.APPLY' | translate }}
        </button>
      </div>
    }

  `,
  styles: [
    'manager-event-wrap { float: left }'
  ]
})
export class SENTINELPropertiesComponent {

  @Input() manager!: SENTINELLayerManager;

  properties$!: Observable<SENTINELLayerManagerProperties>;

  layerData$!: Observable<SENTINELLayerData>;

  layerData: SENTINELLayerData = null;

  properties: SENTINELLayerManagerProperties = null;

  timepickerValue = new BehaviorSubject<TimepickerValue | null>(null);

  aggregationSelected: string = null;
  cumulatedValueSelected: | number = null;

  private _timePickerService: TimepickerService = inject(TimepickerService);

  ngOnInit(): void {
    this._timePickerService.timepickerValue$.subscribe(timepickerValue => this.timepickerValue.next(timepickerValue));

    this.properties$ = this.manager.getProperties$().pipe(
      //@ts-ignore
      tap((data) => {
        this.properties = data as SENTINELLayerManagerProperties;
      })
    );
  }

  transformSecondsToHours(seconds: number): string {
    const hours = Math.floor(seconds / 3600);
    // const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h`;
  }

  selectAggregation($event: any) {
    this.aggregationSelected = $event.value;
  }

  selectAccumulated($event: any) {
    this.cumulatedValueSelected = $event.value;
  }

  async apply() {
    const timePickerValue = this.timepickerValue.value;
    if (timePickerValue === null) {
      return;
    }
    const dateFrom = timePickerValue?.from;
    const dateTo = timePickerValue?.to === 'now' ? new Date() : timePickerValue.to;

    const newProperties = {
      ...this.properties, ...{
        aggregationSelected: (this.aggregationSelected === null) ? this.properties.aggregationSelected : this.aggregationSelected,
        cumulatedValueSelected: (this.cumulatedValueSelected === null) ? this.properties.cumulatedValueSelected : this.cumulatedValueSelected
      },
      dateFrom,
      dateTo
    };

    await this.manager.applyProperties(newProperties);
  }
}
