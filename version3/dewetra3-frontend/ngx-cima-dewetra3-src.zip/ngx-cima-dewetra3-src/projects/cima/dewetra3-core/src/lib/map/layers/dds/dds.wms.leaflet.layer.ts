import L from 'leaflet';

import { DDSLayerData } from 'projects/cima/dewetra3-core/src/public-api';
import { BaseMapInfoResult, LayerDataContainer } from '../../../models/models';
import { BaseLayer } from '../base/base.layer';

export interface DDSMapInfoResult extends BaseMapInfoResult {
  wmsData: Record<string, unknown>;
}

export class DDSWMSLayerLeaflet extends BaseLayer {
  private wmsLayer?: L.TileLayer.WMS;

  // override async updateMapLayerOld(layerData: LayerDataContainer): Promise<void> {
  //   const data = layerData?.data as DDSLayerData;

  //   if (!data?.serverUrl || !data?.published?.layerid) {
  //     console.warn('DDSWMSLayerLeaflet: Missing required WMS parameters');
  //     return;
  //   }

  //   if (this.wmsLayer) {
  //     this.map?.removeLayer(this.wmsLayer);
  //   }

  //   this.wmsLayer = L.tileLayer.wms(data.serverUrl, {
  //     layers: data.published.layerid,
  //     format: 'image/png',
  //     transparent: true,
  //     opacity: 1.0,
  //   });

  //   this.map?.addLayer(this.wmsLayer);

  //   this.bringToFront();
  // }

  override async updateMapLayer(layerData: LayerDataContainer): Promise<void> {
    const data = layerData?.data as DDSLayerData;
    if (!data?.serverUrl || !data?.published?.layerid) {
      console.warn('DDSWMSLayerLeaflet: Missing required WMS parameters');
      return;
    }

    // 1) Crea il nuovo layer con opacità 0
    const newLayer = L.tileLayer.wms(data.serverUrl, {
      layers: data.published.layerid,
      format: 'image/png',
      transparent: true,
      opacity: 0, // parte da invisibile
      keepBuffer: 1, // mantiene in buffer i vecchi tile per il cross‐fade
    });

    // 2) Aggiungilo subito sulla mappa (sotto al vecchio)
    newLayer.addTo(this.map!);

    // 3) Quando ha caricato almeno un tile, sfuma dentro
    newLayer.once('load', () => {
      // porta l’opacità a 1: grazie al CSS di cui sopra sarà una transizione fluida
      newLayer.setOpacity(1);

      // e solo dopo aver sfumato dentro, rimuove il layer precedente
      if (this.wmsLayer) {
        this.map?.removeLayer(this.wmsLayer);
      }
      // aggiorna il riferimento
      this.wmsLayer = newLayer;

      // riportalo in primo piano se serve
      this.bringToFront();
    });
  }

  // override async updateMapLayer(layerData: LayerDataContainer): Promise<void> {
  //   const data = layerData?.data as DDSLayerData;
  //   if (!data?.serverUrl || !data?.published?.layerid) {
  //     console.warn('DDSWMSLayerLeaflet: Missing required WMS parameters');
  //     return;
  //   }

  //   // 1) Crea il nuovo layer con opacità 0
  //   const newLayer = L.tileLayer.wms(data.serverUrl, {
  //     layers: data.published.layerid,
  //     format: 'image/png',
  //     transparent: true,
  //     opacity: 0, // invisibile all’inizio
  //     keepBuffer: 2, // conserva anche i tile appena fuori vista
  //     updateWhenZooming: false,
  //     updateInterval: 200,
  //   });

  //   // 2) Aggiungilo sotto al vecchio layer
  //   newLayer.addTo(this.map!);

  //   // 3) Ad ogni tile inizia trasparente…
  //   newLayer.on('tileloadstart', (e) => {
  //     e.tile.style.opacity = '0';
  //   });

  //   // …e appena carica fai il fade-in
  //   newLayer.on('tileload', (e) => {
  //     // piccola delay per innescare correttamente la transition CSS
  //     requestAnimationFrame(() => {
  //       e.tile.style.opacity = '1';
  //     });
  //   });

  //   // 4) Quando l’intero layer ha finito di scaricare i tile visibili…
  //   newLayer.once('load', () => {
  //     // attendi la fine della fade (0.3s) poi rimuovi il vecchio
  //     setTimeout(() => {
  //       if (this.wmsLayer) {
  //         this.map?.removeLayer(this.wmsLayer);
  //       }
  //       this.wmsLayer = newLayer;
  //       this.bringToFront();
  //     }, 300);
  //   });
  // }

  override bringToFront(): void {
    this.wmsLayer?.bringToFront();
  }

  override bringToBack(): void {
    this.wmsLayer?.bringToBack();
  }

  override _remove(): void {
    if (this.wmsLayer) {
      this.map?.removeLayer(this.wmsLayer);
      this.wmsLayer = undefined;
    }
    this.subscription?.unsubscribe();
  }

  override setOpacity(opacity: number): void {
    if (this.wmsLayer) {
      this.wmsLayer.setOpacity(opacity);
    } else {
      console.warn('DDSWMSLayerLeaflet: Cannot set opacity, WMS layer is not defined');
    }
  }

  override setVisible(visible: boolean): void {
    if (!this.wmsLayer) {
      console.warn('DDSWMSLayerLeaflet: Cannot change visibility, WMS layer is not defined');
      return;
    }
    visible ? this.map?.addLayer(this.wmsLayer) : this.map?.removeLayer(this.wmsLayer);
  }

  override getBounds(): L.LatLngBounds {
    const model = this.layer?.getLayerModel();

    if (!model) {
      console.warn('DDSWMSLayerLeaflet: No layer model available, returning default bounds.');
      return L.latLngBounds(L.latLng(90, -180), L.latLng(-90, 180));
    }

    const { latn = 90, lonw = -180, lats = -90, lone = 180 } = model;
    return L.latLngBounds(L.latLng(latn, lonw), L.latLng(lats, lone));
  }
}
