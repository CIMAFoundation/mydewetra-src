import { Injectable } from '@angular/core';
import { LayerModel } from '../models/dewetra3-layer';
import { CustomLegendComponent } from './components/custom/custom-legend.component';
import { ImageLegendComponent } from './components/custom/image-legend.component';
import { DDSLegendComponent } from './components/dds/dds-legend.component';
import { DDSWMSLegendComponent } from './components/dds/dds-wms-legend.component';
import { FLOODPROOFSLegendComponent } from './components/floodproofs/floodproofs-legend.component';
import { GeoserverLegendComponent } from './components/geoserver/geoserver-legend.component';
import { SENTINELLegendComponent } from './components/sentinel/sentinel-legend.component';

@Injectable({
  providedIn: 'root',
})
export class LegendComponentFactory {
  static DEFAULT_LEGEND_COMPONENTS = {
    DDSLegendComponent: DDSLegendComponent,
    DDSWMSLegendComponent: DDSWMSLegendComponent,
    StaticWMSLegendComponent: GeoserverLegendComponent,
    SENTINELLegendComponent: SENTINELLegendComponent,
    SerieLegendComponent: FLOODPROOFSLegendComponent,
    FloodPROOFSLegendComponent: FLOODPROOFSLegendComponent,
    CustomLegendComponent: CustomLegendComponent,
    ImageLegendComponent: ImageLegendComponent,
  };

  private _registry: Map<string, any> = new Map(Object.entries(LegendComponentFactory.DEFAULT_LEGEND_COMPONENTS));

  constructor() {}

  set(name: string, component: any) {
    this._registry.set(name, component);
  }

  create(layerModel: LayerModel): any {
    const klass = this._registry.get(layerModel.legendmanager.component);
    return klass;
  }
}
