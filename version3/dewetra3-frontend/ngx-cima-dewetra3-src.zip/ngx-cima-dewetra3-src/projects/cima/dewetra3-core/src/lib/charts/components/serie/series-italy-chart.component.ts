import { AfterViewInit, Component, Input } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import * as Plotly from 'plotly.js-dist-min';
import { Observable } from 'rxjs';
import { filter, map, startWith, switchMap } from 'rxjs/operators';
import * as uiid from 'uuid';

import { Compatible, Compatibles } from '../../../managers/serie/serie.model';

import {
  SERIEGetSeriesResult,
  SERIELayerEventData,
  SERIELayerManagerProperties,
  SERIESLayerManager
} from '../../../managers/serie/serie.manager';

import { Dewetra3LayerEventWithData } from '../../../managers/base/base.manager';
import { SERIESChartComponent } from './series-chart.component';


@Component({
  selector: 'series-italy-chart',
  template: `
    @if (loadingChart$ | async) {
      <div>
        {{ 'DEWETRA3CORE.LOADING_CHART' | translate }}...
      </div>
      <div class="w-100 h-100 d-flex justify-content-center align-items-center flex-column">
        <mat-progress-bar mode="indeterminate"></mat-progress-bar>
      </div>
    }

    @if (seriesResult?.data) {
      <div class="chart-title">
        {{ getTitle() }}
      </div>
      <div class="chart-subtitle">
        {{ getSubtitle() }}
      </div>
    }

    <div class="row">
      <div class="col">
        @if(hasQUAL1_5()) {
        <span>{{ 'QUAL1_5' | translate }}:</span> <span>{{ getQUAL1_5() }}</span>
        }
      </div>
      <div class="col">
        @if(hasFonteSdD()) {
        <span>{{ 'FonteSdD' | translate }}:</span> <span>{{ getFonteSdD() }}</span>
        }
      </div>
      <div class="col">
        @if(hasCALIBRATO()) {
        <span>{{ 'CALIBRATO' | translate }}:</span> <span>{{ getCALIBRATO() }}</span>
        }
      </div>
      <div class="col">
        @if(hasErr_Rel_Qp()) {
        <span>{{ 'Err_Rel_Qp' | translate }}:</span> <span>{{ getErr_Rel_Qp() }}</span>
        }
      </div>
      <div class="col">
        @if(hasFonte_Q_so()) {
        <span>{{ 'NashSut' | translate }}:</span> <span>{{ getFonte_Q_so() }}</span>
        }
      </div>
    </div>

    @if (seriesResult?.data) {
      <mat-tab-group (selectedTabChange)="onSerieChange($event)" [selectedIndex]="selectedCompatibleIndex">
        @for (compatible of compatibles.compatibles; track $index) {
          <mat-tab [label]="compatible.descr">
            <mat-tab-group (selectedTabChange)="onTypeChartChange($event)">
              @for (type of compatible.type.split(';'); track $index) {
                <mat-tab [label]="type"></mat-tab>
              }
            </mat-tab-group>
          </mat-tab>
        }
      </mat-tab-group>
    }
    <div class="p-2">
      <div [id]="chartId" class="rounded-2 overflow-hidden"></div>
    </div>
  `,
  styles: ['']
})

export class SERIESItalyChartComponent extends SERIESChartComponent{

  hasQUAL1_5(): boolean {
    //@ts-ignore
    return this.clickData.data.feature.properties['QUAL1_5'] !== undefined
  }

  getQUAL1_5():string {
    //@ts-ignore
    return this.clickData.data.feature.properties['QUAL1_5'];
  }

  hasFonteSdD(): boolean {
    //@ts-ignore
    return this.clickData.data.feature.properties['FonteSdD'] !== undefined
  }

  getFonteSdD():string {
    //@ts-ignore
    return this.clickData.data.feature.properties['FonteSdD'];
  }

  hasCALIBRATO(): boolean {
    //@ts-ignore
    return this.clickData.data.feature.properties['CALIBRATO'] !== undefined
  }

  getCALIBRATO():string {
    //@ts-ignore
    return this.clickData.data.feature.properties['CALIBRATO'];
  }

  hasErr_Rel_Qp(): boolean {
    //@ts-ignore
    return this.clickData.data.feature.properties['Err_Rel_Qp'] !== undefined
  }

  getErr_Rel_Qp():string {
    //@ts-ignore
    return this.clickData.data.feature.properties['Err_Rel_Qp'];
  }

  hasNashSut(): boolean {
    //@ts-ignore
    return this.clickData.data.feature.properties['NashSut'] !== undefined
  }

  getNashSut():string {
    //@ts-ignore
    return this.clickData.data.feature.properties['NashSut'];
  }

  hasFonte_Q_so(): boolean {
    //@ts-ignore
    return this.clickData.data.feature.properties['Fonte Q_so'] !== undefined
  }

  getFonte_Q_so():string {
    //@ts-ignore
    return this.clickData.data.feature.properties['Fonte Q_so'];
  }

}
