import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import * as turf from '@turf/turf';
import L from 'leaflet';
import 'leaflet-draw';
import {BehaviorSubject, filter, map} from 'rxjs';
import {squareMetersToSquareKilometers} from '../../utils/utils';
import {Dewetra3MapClick, PastMeasurement} from '../../models/models';
import {MeasurementHistoryService} from "./measurement-history.service";

@Component({
  selector: 'map-measurement-tool',
  templateUrl: './map-measurement-tool.component.html',
  styleUrls: ['./map-measurement-tool.component.scss'],
  providers: [MeasurementHistoryService]
})
export class MapMeasurementToolComponent implements OnInit {

  private _layerGroup: L.LayerGroup = L.layerGroup();
  public polylineLength: number = 0;
  public polygonArea: number = 0;
  public polygonPerimeter: number = 0;
  public mu: string = '';
  public measuramentType: string = 'polyline';

  private _polygoneOptions = {
    allowIntersection: false, // Restricts shapes to simple polygons
    drawError: {
      color: '#e1e058', // Color the shape will turn when intersects
      message: '<strong>Oh snap!<strong> you can\'t draw that!' // Message that will show when intersect
    },
    shapeOptions: {
      color: '#f32727'
    }
  }
  private _polylineOptions = {
    shapeOptions: {
      stroke: true,
      color: '#ff338f',
      weight: 6,
      opacity: 0.7,
      fill: false,
      clickable: true
    },
    showLength: false,
  }

  private _polygonToolbar: L.Draw.Polygon = null;
  private _polylineToolbar: L.Draw.Polyline = null;


  @Input() isEnable$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  @Input() set isEnable(isEnable: boolean) {
    this.isEnable$.next(isEnable)
  }

  @Output() closeMeasurementTool = new EventEmitter<boolean>();

  private onMapInfo$ = new BehaviorSubject<Dewetra3MapClick | null>(null);

  @Input() set onMapInfo(dewetra3MapClick: Dewetra3MapClick) {
    this.onMapInfo$.next(dewetra3MapClick);
  }

  private map$: BehaviorSubject<L.Map> = new BehaviorSubject<L.Map>(null);

  @Input() set map(map: L.Map) {
    this.map$.next(map);
  }

  constructor(public translate: TranslateService, private measurementHistoryService: MeasurementHistoryService
  ) {

    this.map$.pipe(
      filter(map => map !== null && map !== undefined),
      map(map => {
        this.initToolbar();
        this.localizeDrawToolbar();
      })
    ).subscribe();

    this.isEnable$.pipe(
      filter(isEnable => isEnable !== null && isEnable !== undefined),
      map(isEnable => {
        if (isEnable) {
          this.drawOnMap();
        } else {
          this.clearLayers();
        }
      })
    ).subscribe();


  }

  initToolbar() {
    this._polylineToolbar = new L.Draw.Polyline(this.map$.value as L.DrawMap, this._polylineOptions)
    this._polygonToolbar = new L.Draw.Polygon(this.map$.value as L.DrawMap, this._polygoneOptions)
  }

  localizeDrawToolbar() {
    L.drawLocal.draw.handlers.polyline.tooltip = {
      start: this.translate.instant('DEWETRA3CORE.POLYLINE_START'),
      cont: this.translate.instant('DEWETRA3CORE.POLYLINE_CONTINUE'),
      end: this.translate.instant('DEWETRA3CORE.POLYLINE_END'),
    };
    L.drawLocal.draw.handlers.polygon.tooltip = {
      start: this.translate.instant('DEWETRA3CORE.POLYGON_START'),
      cont: this.translate.instant('DEWETRA3CORE.POLYGON_CONTINUE'),
      end: this.translate.instant('DEWETRA3CORE.POLYGON_END'),
    };
  }

  clearLayers() {
    this._layerGroup.clearLayers();

    if (this._polygonToolbar && this._polygonToolbar.enabled()) this._polygonToolbar.disable();
    if (this._polylineToolbar && this._polylineToolbar.enabled()) this._polylineToolbar.disable();


    this.removeHandledCreatedLayer();
  }

  drawOnMap() {

    if (!this.map$.value.hasLayer(this._layerGroup)) {
      this.map$.value.addLayer(this._layerGroup);
    }
    switch (this.measuramentType) {
      case 'polyline':
        this.drawPolyline();
        break;
      case 'polygon':
        this.drawPolygon();
        break;
    }
  }

  handleChoiceChange(value: any) {
    if (this.measuramentType === value) {
      return;
    }
    this.measuramentType = value;
    this.clearMeasure();
    this.clearLayers();
    this.drawOnMap();
  }

  drawPolyline() {
    this._polygonToolbar.disable();
    this._polylineToolbar.enable();
    this.addHandledCreatedPolyline();

  }

  drawPolygon() {
    this._polylineToolbar.disable();
    this._polygonToolbar.enable();
    this.addHandledCreatedPolygon();

  }


  addHandledCreatedPolyline() {
    this.map$.value.on(L.Draw.Event.CREATED, (e: any) => {
      const layer = e.layer;
      this._layerGroup.addLayer(layer);
      // @ts-ignore
      this.polylineLength = turf.lineDistance(layer.toGeoJSON(), 'kilometers')
      //update past5measurement
      this.addMeasure({type: 'polyline', layer, polylineLength: this.polylineLength});
    });
  }

  addHandledCreatedPolygon() {
    this.map$.value.on(L.Draw.Event.CREATED, (e: any) => {
      const layer = e.layer;
      this._layerGroup.addLayer(layer);
      this.polygonArea = squareMetersToSquareKilometers(turf.area(layer.toGeoJSON()));
      this.polygonPerimeter = turf.length(layer.toGeoJSON(), {units: 'kilometers'});
      //update past5measurement
      this.addMeasure({
        type: 'polygon',
        layer,
        polygonArea: this.polygonArea,
        polygonPerimeter: this.polygonPerimeter
      });
    });
  }

  reInitMeasure() {
    this.clearLayers();
    this.drawOnMap();
  }

  removeHandledCreatedLayer() {
    if (this.map$.value) this.map$.value.off(L.Draw.Event.CREATED);
  }

  clearMeasure() {
    this.polylineLength = 0;
    this.polygonArea = 0;
    this.polygonPerimeter = 0;
  }

  ngOnDestroy(): void {
    this.clearLayers();
    this.measurementHistoryService.history = this.past5measurement;
  }


  /*HISTORY MEASUREMENT STUFF*/

  past5measurement: PastMeasurement[] = [];

  removeExeededPast5() {
    if (this.past5measurement.length > 4) {
      //remove oldest from array
      this.past5measurement.shift();
    }
  }

  addMeasure(meas: PastMeasurement) {
    //update past5measurement
    this.removeExeededPast5()
    this.past5measurement.unshift(meas);
    //save to local storage
    //this.saveHistoryToLocalStorage()
  }

  removeMeasure(meas: PastMeasurement) {
    this.past5measurement = this.past5measurement.filter(m => m !== meas);
  }

  reloadMeasure(meas: PastMeasurement) {
    //remove current measure from map
    this._layerGroup.clearLayers()
    // reload layer on map
    this._layerGroup.addLayer(meas.layer);
    // set measure value
    if (meas.type === 'polyline') {
      this.polylineLength = meas.polylineLength;
      //switch to polyline
      this.measuramentType = 'polyline';
    } else {
      this.polygonArea = meas.polygonArea;
      this.polygonPerimeter = meas.polygonPerimeter;
      //switch to polygon
      this.measuramentType = 'polygon';
    }
    //move the measure on top
    this.removeMeasure(meas);
    this.past5measurement.unshift(meas);
    //save to local storage
  }

  ngOnInit(): void {
    this.past5measurement = this.measurementHistoryService.history;
  }


}
