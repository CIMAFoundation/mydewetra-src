import { Component, Input } from '@angular/core';
import { TranslateService } from "@ngx-translate/core";
import { Observable } from 'rxjs';
import { BaseDewetra3LayerEventData, BaseLayerManager } from '../../managers/base/base.manager';


@Component({
  selector: 'dewetra3-sentinel-info',
  template: `
    <div *ngIf="manager && layerEvent">
      <!-- <span *ngIf="infoEvents$ | async as info">{{info | json}}</span> -->
      <h2>{{ layerEvent?.feature?.properties?.st }}</h2>
      <h4>{{ parseTime() }}</h4>
      <ul>
        <li *ngFor="let v of sortedByPeriod()">
          <span *ngIf="v?.p">{{ parsePeriod(v?.p) }}</span>
          <span style="min-width: 30px;"></span>
          <span>{{ v?.v }} {{ layerEvent?.feature?.properties?.mu }}</span>
        </li>
      </ul>
    </div>
  `,
  styles: `
    h2 {
      font-size: 1.5rem;
      font-weight: bold;
      margin: 0;
    }

    h4 {
      font-size: 1rem;
      margin: 0;
    }

    ul {
      list-style-type: none;
      padding: 0;
    }

    li {
      display: flex;
      justify-content: space-between;
      padding: 0.5rem 0;
    }

  `
})
export class SENTINELInfoComponent {
  @Input() manager!: BaseLayerManager;
  @Input() infoEvents$!: Observable<any>;
  @Input() layerEvent: BaseDewetra3LayerEventData | any;

  sortedByPeriod() {

    if(this.layerEvent?.feature?.properties?.v){
      return this.layerEvent.feature.properties.v.sort((a: any, b: any) => {
        return a.p - b.p;
      });
    }

    if(this.layerEvent?.feature?.properties?.values){
      return this.layerEvent.feature.properties.values.sort((a: any, b: any) => {
        return a.p - b.p;
      });
    }

  }

  parseTime(): string {
    const time = this.mostRecentTime() * 1000;
    return new Date(time).toLocaleString();
  }

  parsePeriod(period: number): string {
    if (period === 0) {
      return this.translate.instant('DEWETRA3CORE.LAST');
    }
    return this.translate.instant('DEWETRA3CORE.LAST') + ' ' + period / 60 / 60 + ' h';
  }

  mostRecentTime() {
    let mostRecent = 0;

    if(this.layerEvent?.feature?.properties?.v){
      this.layerEvent.feature.properties.v.forEach((v: any) => {
        if (v.t > mostRecent) {
          mostRecent = v.t;
        }
      });
      return mostRecent;
    }

    if(this.layerEvent?.feature?.properties?.values){
      this.layerEvent.feature.properties.values.forEach((v: any) => {
        if (v.t > mostRecent) {
          mostRecent = v.t;
        }
      });
      return mostRecent;
    }

    return 0;

  }


  constructor(private translate: TranslateService) {
  }

}


