import { Pipe, PipeTransform } from '@angular/core';
import { LayerModel, LayerTag } from '../models/dewetra3-layer';

@Pipe({
  name: 'tagPipes',
  pure: false
})
export class TagPipesPipe implements PipeTransform {
  transform(layers: LayerModel[], tags: LayerTag[]): LayerModel[] {
    let filteredLayers: LayerModel[];
    if (layers && layers.length > 0 && tags && tags.length > 0) {
      let tagsArrayId: number[] = tags.map((tag: LayerTag) => tag.id);
      filteredLayers = layers.filter((layer: LayerModel) => {
        return layer.tags.some((tag: LayerTag) => tagsArrayId.includes(tag.id));
      });
    } else return layers;
    return filteredLayers as LayerModel[];
  }

}
