import * as L from 'leaflet';

import { BaseDewetra3LayerEventData, Dewetra3LayerEventWithData } from "../../../managers/base/base.manager";
import { DDSWFSLayerData } from '../../../managers/dds/dds.wfs.manager';
import { LayerDataContainer } from '../../../models/models';
import { BaseLayer } from '../base/base.layer';

export interface DDSWFSLayerEventData extends BaseDewetra3LayerEventData {
  feature: any;
}

export class DDSWFSLayerLeaflet extends BaseLayer {
  wfsLayer: L.GeoJSON | null = null;

  override async updateMapLayer(layerData: LayerDataContainer): Promise<void> {
    const data = layerData.data as DDSWFSLayerData;

    if (!data || !data.geoJson) {
      console.warn('DDSWFSLayerLeaflet: No valid geoJson data provided.');
      return;
    }

    if (this.wfsLayer) {
      this.map.removeLayer(this.wfsLayer);
    }

    this.wfsLayer = L.geoJSON(data.geoJson, {
      pointToLayer: (feature, latlng) => this.createPointMarker(feature, latlng),
      style: (feature) => this.getFeatureStyle(feature),
      onEachFeature: (feature, layer) => this.bindFeatureEvents(feature, layer)
    });

    this.map.addLayer(this.wfsLayer);
  }

  /**
   * Crea il marker per i punti (Point, MultiPoint)
   */
  private createPointMarker(feature: any, latlng: L.LatLng): L.Layer {
    return L.circleMarker(latlng, this.getPointStyle(feature));
  }

  /**
   * Definisce lo stile dinamico per punti, linee e poligoni
   */
  private getFeatureStyle(feature: any): L.PathOptions {
    const geometryType = feature.geometry.type;

    switch (geometryType) {
      case "LineString":
      case "MultiLineString":
        return this.getLineStyle(feature);

      case "Polygon":
      case "MultiPolygon":
        return this.getPolygonStyle(feature);

      default:
        return {}; // Non necessario per i punti
    }
  }

  /**
   * Stile per i punti
   */
  private getPointStyle(feature: any): L.CircleMarkerOptions {
    return {
      radius: 6,
      weight: 1,
      color: "#060706",
      fillColor: '#ff5733', // Arancione brillante
      opacity: 1,
      fillOpacity: 0.8
    };
  }

  /**
   * Stile per le linee
   */
  private getLineStyle(feature: any): L.PathOptions {
    return {
      color: '#0077cc', // Blu acceso
      weight: 3,
      opacity: 0.8
    };
  }

  /**
   * Stile per i poligoni
   */
  private getPolygonStyle(feature: any): L.PathOptions {
    return {
      color: '#28a745', // Verde
      weight: 2,
      fillColor: '#28a745',
      fillOpacity: 0.5
    };
  }

  /**
   * Aggiunge gli eventi alle features
   */
  private bindFeatureEvents(feature: any, layer: L.Layer) {
    layer.on({
      click: evt => this.emitLayerEvent('click', evt.target.feature),
      mouseover: evt => this.emitLayerEvent('mouseover', evt.target.feature),
      mouseout: evt => this.emitLayerEvent('mouseout', evt.target.feature)
    });
  }

  private emitLayerEvent(type: 'click' | 'mouseover' | 'mouseout', feature: any) {
    if (!this.layer) {
      console.warn('DDSWFSLayerLeaflet: Layer is not defined.');
      return;
    }
    const data: DDSWFSLayerEventData = { feature };
    const event = { type, layer: this.layer, data } as Dewetra3LayerEventWithData;
    this.onLayerEvent.emit(event);
  }

  override bringToFront() {
    this.wfsLayer?.bringToFront();
  }

  override bringToBack() {
    this.wfsLayer?.bringToBack();
  }

  override _remove() {
    if (this.wfsLayer) {
      this.map.removeLayer(this.wfsLayer);
      this.wfsLayer = null;
    }
    this.subscription?.unsubscribe();
  }

  override setOpacity(opacity: number) {
    if (this.wfsLayer) {
      this.wfsLayer.setStyle({ opacity, fillOpacity: opacity });
    }
  }

  override setVisible(visible: boolean) {
    if (!this.wfsLayer) return;
    visible ? this.map.addLayer(this.wfsLayer) : this.map.removeLayer(this.wfsLayer);
  }

  override getBounds(): L.LatLngBounds {
    if (!this.wfsLayer) {
      console.warn('DDSWFSLayerLeaflet: No bounds available, returning map bounds.');
      return this.map.getBounds();
    }
    return this.wfsLayer.getBounds();
  }
}
