import { Pipe, PipeTransform } from '@angular/core';
import { LayerHazard, LayerModel } from '../models/dewetra3-layer';



@Pipe({
  name: 'hazardPipes',
  pure: false
})
export class HazardPipesPipe implements PipeTransform {

  transform(layers: LayerModel[], args: LayerHazard[]): LayerModel[] {
    if (layers && layers.length >= 0 && args && args.length > 0) {
      layers = layers.filter((layer: LayerModel) => {
        const hazardsId = layer.hazards?.map((hazard: LayerHazard) => hazard.id);
        const argsId = args.map((hazard: LayerHazard) => hazard.id);
        return hazardsId.some((id) => argsId.includes(id));
      });
      return layers as LayerModel[];
    } else {
      //console.log('hazardPipes: no layers or no args', layers, args)
      return layers as LayerModel[];
    }

  }

}
