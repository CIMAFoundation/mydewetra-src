import { DDSLayerAvailability, DDSLayerPublishResponse } from './layer-availability';

interface MovieFrameStatus {
  availability: DDSLayerAvailability;
  layer: DDSLayerPublishResponse;
  loaded: boolean;
}

export interface MovieProgressMap {
  frames: MovieFrameStatus[];
  currentIndex: number;
  canProceed: boolean;
}

export interface MovieStatus {
  taskId?: string;
  available: boolean;
  status?: 'idle' | 'loading' | 'running' | 'error' | 'playing';
  progressMap: MovieProgressMap;
}
