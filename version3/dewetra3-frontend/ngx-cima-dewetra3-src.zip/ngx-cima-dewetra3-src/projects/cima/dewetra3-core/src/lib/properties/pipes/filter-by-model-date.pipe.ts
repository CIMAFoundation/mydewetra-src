import { Pipe, PipeTransform } from '@angular/core';
import { DDSLayerAvailability } from '../../models/layer-availability';

@Pipe({
  name: 'filterByModelDate',
})
export class FilterByModelDatePipe implements PipeTransform {
  transform(availability: DDSLayerAvailability[], date: string | null): DDSLayerAvailability[] {
    if (!date) return availability;
    return availability.filter(entry => entry.id.startsWith(date));
  }
}
