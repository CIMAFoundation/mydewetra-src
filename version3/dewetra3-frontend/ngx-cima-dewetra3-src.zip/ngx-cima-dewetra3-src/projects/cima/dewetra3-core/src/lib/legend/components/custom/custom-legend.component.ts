import {Component, Input} from '@angular/core';
import {BaseLayerManager} from '../../../managers/base/base.manager';

@Component({
  selector: 'dewetra3-custom-legend',
  template: `
    <div class="legend">
      <div class="legend-title"></div>

      <div class="legend-content">
        @if (manager.getLayerModel().legendmanager.props; as legendProps) {
          @for (legend of legendProps.default.legend;
            track $index) {
            <div class="legend-item">
              <div class="legend-title">{{ legend.title }}</div>
              <div class="legende-description">{{ legend.description }}</div>
              @if (legend.imgurl) {
                <div class="legend-image">
                  <img [style.width]="legendProps?.default?.imageWidth ? legendProps?.default?.imageWidth : '100%'"
                       [src]="legend.imgurl" alt="{{ 'DEWETRA3APP.LEGENDA' | translate }}"/>
                </div>
              }
              <div class="legend-image-caption">{{ legend.imagecaption }}</div>
              <div [style.width]="legend?.paletteWidth ? legend?.paletteWidth:'200px'">
                @for (legendItem of legend.palette; track $index) {
                  <div class="legend-item-color" [style.background-color]="legendItem.color">
                    <div class="legend-item-label" [style.color]="legendItem.textcolor">
                      {{ legendItem.label }} {{ legendItem.mu }}
                    </div>
                  </div>
                }
              </div>
            </div>
          }
        }
      </div>
    </div>
  `,
  styleUrls: [],
})
export class CustomLegendComponent {
  @Input() manager!: BaseLayerManager;

  constructor() {
  }
}
