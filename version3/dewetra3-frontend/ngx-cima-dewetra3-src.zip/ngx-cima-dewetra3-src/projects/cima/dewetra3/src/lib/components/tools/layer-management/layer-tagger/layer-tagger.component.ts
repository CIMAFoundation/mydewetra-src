import { Component, inject, input, OnInit, output, signal } from '@angular/core';
import { Tag } from '../../../../models/layer';
import { DewapiService } from '../../../../services/dewapi.service';
import { TagFilterComponent } from '../../../tag-filter/tag-filter.component';

@Component({
  selector: 'dewetra3-lm-layer-tagger',
  standalone: true,
  imports: [TagFilterComponent],
  template: `
    <div class="">
      <dewetra3-tag-filter
        [enabled]="true"
        [loading]="false"
        [layersType]="category()"
        [preSelectedTags]="preselectedTags()"
        [Tags]="tags()"
        (selectedTagsEvent)="selectedTags.emit($event)"
        [customClass]="'layer-manager'"
      >
      </dewetra3-tag-filter>
    </div>
  `,
  styleUrl: './layer-tagger.component.scss',
})
export class LayerTaggerComponent implements OnInit {
  private _dewapiService: DewapiService = inject(DewapiService);

  category = input<string>(); // Input property to set the category
  tags = signal<Tag[]>([]); // Signal to track the tags
  selectedTags = output<Tag[]>(); // Signal to track the selected tags
  preselectedTags = input<Tag[]>([]); // Signal to track the pre-selected tags

  effects() {
    console.log('LayerTaggerComponent initialized');
    console.log('Tags:', this.tags());
    console.log('Selected Tags:', this.preselectedTags());
  }

  async ngOnInit(): Promise<void> {
    const tags = await this._dewapiService.getLayerTags();

    this.tags.set(tags);
  }
}
