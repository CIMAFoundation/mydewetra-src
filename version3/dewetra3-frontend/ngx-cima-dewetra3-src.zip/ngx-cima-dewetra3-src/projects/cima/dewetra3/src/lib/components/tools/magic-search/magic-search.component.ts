import {Component, EventEmitter, inject, OnInit, Output} from '@angular/core';
import {FormControl} from '@angular/forms';
import {MatDialogRef} from '@angular/material/dialog';
import {PortalService, UserData} from '@cima/commons';
import {Dewetra3ApiService, LayerModel, MapPosition} from '@cima/dewetra3-core';
import {TranslateService} from '@ngx-translate/core';
import * as L from 'leaflet';
import {debounceTime, filter, forkJoin, map, Observable, switchMap, tap} from 'rxjs';
import {MagicSearchFeature, ResultInterface} from '../../../models/tool.model';
import {GeocodeService} from '../../../services/geocode.service';
import {LayerListService} from '../../../services/layer-list.service';
import {Dewetra3LayerStoreService} from '../../../services/layer-store.service';
import {MenuService} from '../../../services/menu.service';

@Component({
  selector: 'magic-search',
  templateUrl: 'magic-search.component.html',
  styleUrls: ['magic-search.component.scss'],
})
export class MagicSearchComponent implements OnInit {
  isLoadingGeoCode = false;
  allLayers: LayerModel[] = [];
  filteredLayers: LayerModel[] = [];
  searchText = new FormControl('');
  citiAddress = '';
  result: ResultInterface | null = null;
  preSelectedLayer: LayerModel;
  searchText$: Observable<any>;
  lastLayersSearched: string[] = [];
  allFeatures: MagicSearchFeature[] = [];
  filteredFeatures: MagicSearchFeature[] = [];

  @Output() layerSelected = new EventEmitter<LayerModel>();
  @Output() stationSelected = new EventEmitter<any>();
  @Output() locationSelected = new EventEmitter<any>();

  private _apiService: Dewetra3ApiService = inject(Dewetra3ApiService);
  private _geocodeService: GeocodeService = inject(GeocodeService);
  private _layerStore: Dewetra3LayerStoreService = inject(Dewetra3LayerStoreService);
  private _portalService: PortalService = inject(PortalService);
  private translateService: TranslateService = inject(TranslateService);
  private layerListService: LayerListService = inject(LayerListService);
  private _menuService: MenuService = inject(MenuService);
  private dialogRef: MatDialogRef<MagicSearchComponent> = inject(MatDialogRef<MagicSearchComponent>);

  constructor() {
    this._apiService.getLayers$().pipe(
      switchMap((layers) => {
        // creo un array di observable per ogni traduzione
        const translateObs = layers.map(layer =>
          this.getTranslatedOr(layer.name_i18n, layer.name).pipe(
            map(translatedName => ({
              ...layer,
              translatedName // aggiungo la proprietà tradotta
            }))
          )
        );

        // aspetta che tutte le traduzioni siano pronte
        return forkJoin(translateObs);
      })
    ).subscribe((translatedLayers) => {
      this.allLayers = translatedLayers;
      this.filteredLayers = translatedLayers;
      this.preSelectedLayer = translatedLayers[0];
      this.moveLastToTop();
    });

    //this.loadAvailableStations();

    this.searchText.valueChanges
      .pipe(
        debounceTime(300),
        map((value) => {
          this.filterLayers(value);
          this.filterFeatures(value);
          return value;
        }),
        tap((value) => {
          if (value.length <= 3) {
            this.citiAddress = '';
            this.filteredFeatures = [];
          }
        }),
        filter((value) => value.length > 3),
        //@ts-ignore
        switchMap((address: string) => {
          if (address.length < 3) {
            return [];
          }
          return this._geocodeService.geocodeAddress(address);
        }),
        tap((location: any) => {
          this.manageLocation(location);
        })
        // switchMap((addr) => this._geocodeService.searchAddress(addr)),
        // tap((loc) => this.manageLocation(loc))
      )
      .subscribe();
  }

  manageLocation(location: any) {
    switch (location.status) {
      case 'ZERO_RESULTS':
        this.citiAddress = this.translateService.instant('DEWETRA3APP.MAGIC_SEARCH.NO_RESULTS');
        break;
      case 'OVER_QUERY_LIMIT':
        this.citiAddress = this.translateService.instant('DEWETRA3APP.MAGIC_SEARCH.OVER_QUERY_LIMIT');
        break;
      case 'REQUEST_DENIED':
        this.citiAddress = this.translateService.instant('DEWETRA3APP.MAGIC_SEARCH.REQUEST_DENIED');
        break;
      case 'OK':
        this.result = location['results'][0];
        this.citiAddress = location['results'][0]?.formatted_address;
        break;
      default:
        this.citiAddress = this.translateService.instant('DEWETRA3APP.MAGIC_SEARCH.UNKNOWN_ERROR');
        break;
    }
  }

  loadResult() {
    if (this.result) {
      this.dialogRef.close();

      const center = new L.LatLng(this.result.geometry.location.lat, this.result.geometry.location.lng);
      const position: MapPosition = {
        center,
        zoom: 14,
      };

      this.locationSelected.emit(position);
    }
  }

  loadAvailableStations() {
    this._portalService
      .getUserData()
      .pipe(
        tap((userData: UserData) => {
          console.log(userData.domainProp); //magic-search-station-group
        })
      )
      .subscribe();
  }

  loadLayer(layer: LayerModel) {
    // add to last searched layers if not already present
    const index = this.lastLayersSearched.findIndex((l) => l === layer.dataid);
    if (index === -1) {
      this.lastLayersSearched.push(layer.dataid);
    } else {
      this.lastLayersSearched.splice(index, 1);
      this.lastLayersSearched.push(layer.dataid);
    }

    this.setLastLayersSearched(this.lastLayersSearched);

    this.moveLastToTop();

    this.dialogRef.close();
    this.layerListService.layerListOpened = true;
    this._layerStore.addLayer(layer);
  }

  //SET dewetra3_LAST-SEARCHED-LAYERS in local storage
  setLastLayersSearched(layers: string[]) {
    this.lastLayersSearched = layers;
    localStorage.setItem('dewetra3_LAST-SEARCHED-LAYERS', JSON.stringify(layers));
  }

  filterLayers(string: string = '') {
    this.filteredLayers = this.allLayers.filter((layer) => {
      string = string.toLowerCase();
      const nameToLowerCase = layer.name.toLowerCase();
      const nameTranslatedToLowerCase = layer.translatedName?.toLowerCase();
      const descrToLowerCase = layer.descr.toLowerCase();
      const dataIdToLowerCase = layer.dataid.toLowerCase();
      return (
        nameToLowerCase.includes(string) || descrToLowerCase.includes(string) || dataIdToLowerCase.includes(string) || nameTranslatedToLowerCase.includes(string)
      );
    });
    this.filteredLayers.length > 0 ? (this.preSelectedLayer = this.filteredLayers[0]) : null;
    /*console.log(this.filteredLayers);*/
  }

  /**
   * Filtra allFeatures in base al testo e popola filteredFeatures
   */
  filterFeatures(query: string = '') {
    const q = query.toLowerCase().trim();
    if (!q) {
      this.filteredFeatures = [];
      return;
    }

    this.filteredFeatures = this.allFeatures.filter((feat) => {
      // es. cerca in name, layer_name e nei FIDs
      const nameMatch = feat.name.toLowerCase().includes(q);
      const layerMatch = feat.layer_name.toLowerCase().includes(q);
      const fidsMatch = feat.fids.some((fid) => fid.toLowerCase().includes(q));
      return nameMatch || layerMatch || fidsMatch;
    });
  }

  moveIntoResultArray(direction: string) {
    const currentIndex = this.filteredLayers.indexOf(this.preSelectedLayer);

    const newIndex = currentIndex + (direction === 'up' ? -1 : 1);

    if (newIndex >= 0 && newIndex < this.filteredLayers.length) {
      this.preSelectedLayer = this.filteredLayers[newIndex];
    }
  }

  moveLastToTop() {
    if (this.lastLayersSearched.length > 0) {
      // find the layers in the filteredLayers array with the dataid in lastLayersSearched and move them to the top
      const layerMap = new Map(this.filteredLayers.map((layer) => [layer.dataid, layer]));
      const layersToMove = this.lastLayersSearched
        .slice()
        .reverse()
        .map((id) => layerMap.get(id))
        .filter((layer) => layer !== undefined);
      // remove the layers from the filteredLayers array
      this.filteredLayers = this.filteredLayers.filter((layer) => !this.lastLayersSearched.includes(layer.dataid));
      // add the layers to the top of the filteredLayers array
      this.filteredLayers = [...layersToMove, ...this.filteredLayers];
    }
  }

  loadFeature(feature: MagicSearchFeature) {
    // this.dialogRef.close();
    // this.stationSelected.emit(feature);
    console.log('Feature selected:', feature);
    const layerModel = this.allLayers.find((l) => l.id === feature.layer_id);

    const mapPosition: MapPosition = {
      center: new L.LatLng(feature.lat, feature.lon),
      zoom: 16,
    };
    this.locationSelected.emit(mapPosition);
    this.loadLayer(layerModel);
  }

  async ngOnInit(): Promise<void> {
    // load last searched layers from local storage
    const lastLayersSearched = localStorage.getItem('dewetra3_LAST-SEARCHED-LAYERS');
    if (lastLayersSearched) {
      this.lastLayersSearched = JSON.parse(lastLayersSearched);
    }

    this.allFeatures = await this._menuService.getAllMyFeatures$();

    this.moveLastToTop();
  }

  getTranslatedOr(key: string, fallback: string): Observable<string> {
    if (!key) {
      return this.translateService.get(fallback);
    }
    return this.translateService.get(key).pipe(
      map(translated => translated === key ? fallback : translated)
    );
  }
}
