import {NgIf} from '@angular/common';
import {Component, inject, OnInit, output, signal, ViewChild} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {MatButton, MatIconButton} from '@angular/material/button';
import {MatDialog} from '@angular/material/dialog';
import {MatStep, MatStepLabel, MatStepper, MatStepperNext, MatStepperPrevious} from '@angular/material/stepper';
import {CimaCommonsModule, FileDropComponent, SnackbarService} from '@cima/commons';
import {Dewetra3ApiService} from '@cima/dewetra3-core';
import {TranslateService} from '@ngx-translate/core';
import {MenuService} from '../../../../services/menu.service';
import {CheckDataidComponent} from '../check-dataid/check-dataid.component';
import {LayerDomainsComponent} from '../layer-domains/layer-domains.component';
import {LayerFormComponent} from '../layer-form/layer-form.component';
import {LayerTaggerComponent} from '../layer-tagger/layer-tagger.component';
import {ServerUrlComponent} from '../server-url/server-url.component';
import {UploadLayerComponent} from '../upload-layer/upload-layer.component';
import {ShapeStylerUploadComponent} from './shape-styler-upload.component';

@Component({
  selector: 'dewetra3-lm-shape-styler',
  standalone: true,
  imports: [
    MatIconButton,
    MatStepper,
    MatStep,
    MatButton,
    MatStepperPrevious,
    MatStepperNext,
    MatStepLabel,
    NgIf,
    CimaCommonsModule,
    ServerUrlComponent,
    UploadLayerComponent,
    CheckDataidComponent,
    LayerTaggerComponent,
    LayerDomainsComponent,
    LayerFormComponent,
    FormsModule,
  ],
  template: `
    <div class="py-4">
      <div class="d-flex justify-content-center">
        <div class="narrow-step-wrapper">
          <div class="d-flex flex-column justify-content-center align-items-center">
            <h3 class="text-center">
              {{ 'DEWETRA3APP.LM.STYLE_ALREADY_PRESENT' | translate }}
              {{ 'DEWETRA3APP.LM.SHAPE_STYLER_UPLOAD' | translate }}
            </h3>
            <mat-icon class="text-center" color="primary" style="font-size: 50px"></mat-icon>
          </div>

          <h3 class="text-center">
            {{ 'DEWETRA3APP.LM.STYLE_ALREADY_PRESENT_LIST' | translate }}
          </h3>

          <!-- <div class="d-flex flex-column justify-content-center align-items-center py-2">
            <mat-form-field class="w-100">
              <mat-label>{{ 'DEWETRA3APP.LM.STYLE_AVAILABLES' | translate }}</mat-label>
              <mat-select [value]="styleSelected" (selectionChange)="emitStyleSelected($event.value)">
                <mat-option *ngFor="let c of layer_styles_from_server()" [value]="c"> {{ c }} </mat-option>
              </mat-select>
            </mat-form-field>
          </div>

          <h3 class="text-center">
            {{ 'DEWETRA3APP.LM.NEW_UPLOAD_STYLE' | translate }}
          </h3>
          <div class="d-flex flex-column justify-content-center align-items-center py-2">
            <button mat-flat-button class="w-100 bg-success" (click)="openFileDialog()">Load SLD</button>
          </div> -->
          <div class="d-flex flex-column py-2">
            <div class="d-flex align-items-center">
              <mat-form-field class="flex-grow-1 me-2">
                <mat-label>{{ 'DEWETRA3APP.LM.STYLE_AVAILABLE' | translate }}</mat-label>
                <mat-select [value]="styleSelected" (selectionChange)="styleSelected.set($event.value)">
                  <mat-option *ngFor="let c of layer_styles_from_server()" [value]="c"> {{ c }}</mat-option>
                </mat-select>
              </mat-form-field>

              <!-- Pulsante icona "+" accanto al select -->
              <button mat-icon-button color="primary" (click)="openFileDialog()" aria-label="Load SLD">
                <mat-icon>add</mat-icon>
              </button>
            </div>
            <div class="d-flex flex-column justify-content-center align-items-center py-2">
              <button mat-flat-button class="w-100 bg-success" (click)="emitStyleSelected()">
                {{ 'DEWETRA3APP.LM.CONFIRM_STYLE' | translate }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styleUrl: './shape-styler.component.scss',
})
export class ShapeStylerComponent implements OnInit {
  @ViewChild(FileDropComponent) fileDropComponent: FileDropComponent;
  apiService: Dewetra3ApiService = inject(Dewetra3ApiService);
  snackbarService: SnackbarService = inject(SnackbarService);
  translateService: TranslateService = inject(TranslateService);
  menuService: MenuService = inject(MenuService);
  private _dialog: MatDialog = inject(MatDialog);

  onChoosedStyle: any = output<string>(); // Signal to track the uploaded style
  styleSelected = signal(''); // Signal to track the selected style

  layer_styles_from_server = signal<any[]>([]); // Signal to track the layer styles

  emitStyleSelected = () => {
    this.onChoosedStyle.emit(this.styleSelected());
  };

  async ngOnInit(): Promise<void> {
    // Initialize the component
    console.log('ShapeStylerComponent initialized');
    const styles = await this.menuService.getStyles('default');
    this.layer_styles_from_server.set(styles);
    console.log('Styles:', styles);
  }

  openFileDialog() {
    const dialogRef = this._dialog.open(ShapeStylerUploadComponent, {
      width: '90vw',
      height: '90vh',
      maxWidth: '1000px',
      data: {},
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('Dialog result:', result);
      this.menuService.getStyles('default').then((result) => {
        this.layer_styles_from_server.set(result);
      });
    });
  }
}
