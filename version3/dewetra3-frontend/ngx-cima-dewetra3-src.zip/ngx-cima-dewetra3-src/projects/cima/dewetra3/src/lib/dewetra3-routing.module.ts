import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import {APP_CONFIG} from '@cima/commons';

import {DEWETRA3_CONFIG} from './dewetra3.config';

import {Dewetra3AppContainerComponent} from './components/dewetra3-app-container/dewetra3-app-container.component';


const routes: Routes = [

  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {
    path: '',
    component: Dewetra3AppContainerComponent,
    children: [
      {
        path: 'home',
        loadComponent: () => import('./pages/home/home.component').then(c => c.HomeComponent)
      }
    ],
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [{provide: APP_CONFIG, useValue: DEWETRA3_CONFIG}],
})
export class Dewetra3RoutingModule {
}
