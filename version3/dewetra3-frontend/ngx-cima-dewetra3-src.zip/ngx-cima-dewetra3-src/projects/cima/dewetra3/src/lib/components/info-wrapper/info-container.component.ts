import { Component, OnDestroy } from '@angular/core';
import { Subscription } from "rxjs";

import { filter, tap } from "rxjs/operators";


@Component({
  selector: 'dewetra3-info-container',
  templateUrl: './info-container.component.html',
  styleUrls: ['./info-container.component.scss']
})
export class InfoWrapperComponent implements OnDestroy {
  private eventsSubscription: Subscription;

  constructor(
  ) {
  }

  ngOnDestroy(): void {
    this.eventsSubscription.unsubscribe();
  }
}
