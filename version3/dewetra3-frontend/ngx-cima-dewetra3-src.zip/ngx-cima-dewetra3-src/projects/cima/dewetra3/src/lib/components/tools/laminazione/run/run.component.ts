import {Component} from '@angular/core';
import {MatButton} from "@angular/material/button";

@Component({
  selector: 'laminazione-run',
  standalone: true,
  imports: [
    MatButton
  ],
  templateUrl: './run.component.html',
  styleUrl: './run.component.scss'
})
export class RunComponent {

}
