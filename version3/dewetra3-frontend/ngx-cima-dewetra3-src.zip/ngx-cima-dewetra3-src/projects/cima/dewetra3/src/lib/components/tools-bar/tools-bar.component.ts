import {Component, EventEmitter, HostListener, OnInit, Output} from '@angular/core';
//import { MatDialog } from "@angular/material/dialog";
import {MatDialog} from '@angular/material/dialog';
import {Observable, combineLatest, map, take} from 'rxjs';
import {Tool} from '../../models/tool.model';
import {ExposureAnalysisService} from '../../services/exposure-analysis.service';
import {GenericReportService} from '../../services/generic-report.service';
import {LayerListService} from '../../services/layer-list.service';
import {Dewetra3LayerStoreService, Dewetra3MapsConfig} from '../../services/layer-store.service';
import {ToolsBarService} from '../../services/tools-bar.service';
import {GenericReportDialogComponent} from '../tools/generic-report-dialog/generic-report-dialog.component';
import {MagicSearchComponent} from '../tools/magic-search/magic-search.component';
import {ToolsBarWrapperComponent} from '../tools/tools-bar-wrapper.component';

@Component({
  selector: 'dewetra3-tools-bar',
  templateUrl: './tools-bar.component.html',
  styleUrls: ['./tools-bar.component.scss'],
})
export class ToolsBarComponent implements OnInit {
  loadedLayers$ = combineLatest(this.layerStore.mapsLayers).pipe(
    map((x) => {
      return x.reduce((acc, val) => acc.concat(val), []);
    })
  );

  @Output() lastSelected: EventEmitter<string> = new EventEmitter<string>();

  @Output() locationSelected: EventEmitter<any> = new EventEmitter<any>();

  availableTools$: Observable<Tool[]>;

  featureInfo = false;

  timeSeries = false;

  measurementTool = false;

  collapsed = false;

  constructor(
    public layerListService: LayerListService,
    public layerStore: Dewetra3LayerStoreService,
    public dialog: MatDialog,
    public genericReportService: GenericReportService,
    public toolsBarService: ToolsBarService,
    public exposureAnalysisService: ExposureAnalysisService
  ) {
    this.availableTools$ = this.toolsBarService.loadAvailableTools().pipe(
      map((tools) => {
        // this.openToolDialog(tools[3])//debugging pluvio monitoring
        return tools;
      }),
      take(1)
    );
  }

  ngOnInit(): void {
    this.toggleLayerList();

    //this.openTips()
  }

  pressCount = 0;
  timer: any;

  //open magic search with double shift
  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent) {
    if (event.code === 'IntlBackslash' && !this.toolsBarService.magicSearchIsOpen) {
      event.preventDefault();
      this.toolsBarService.magicSearchIsOpen = true;
      this.openMagicSearch()
      /*      this.pressCount++;
            clearTimeout(this.timer);
            this.timer = setTimeout(() => {
                      if (this.pressCount >= 2 && !this.magicSearchOpened) {
              this.openMagicSearch()
                      }
                      this.pressCount = 0;
            }, 500);*/
    }
  }

  // }

  toggleTimeSeries() {
    this.timeSeries = !this.timeSeries;
    this.timeSeries ? this.lastSelected.emit('timeSeries') : this.lastSelected.emit('');
  }

  toggleFeatureInfo() {
    this.featureInfo = !this.featureInfo;
    this.featureInfo ? this.lastSelected.emit('featureInfo') : this.lastSelected.emit('');
  }

  toggleCrossCursor(newState: boolean) {
    console.log('toggleCrossCursor', newState);
    // get html element dewetra3-map-component
    const mapComponent = document.querySelector('dewetra3-map-component');
    // add class info-activated to dewetra3-map-component
    if (newState) mapComponent?.classList.add('cross-cursor');
    else mapComponent?.classList.remove('cross-cursor');
  }

  toggleLayerList() {
  }

  // OPEN TOOLS DIAlOG

  openReportDialog() {
    const dialogRef = this.dialog.open(GenericReportDialogComponent, {
      disableClose: false,
      hasBackdrop: true,

      //position: {right: '15px'},
      width: '1100px',
      maxWidth: '95vw',
      //minWidth: '80vw',
      height: '900px',
      //minHeight: '800px',
      maxHeight: '95vh',
      panelClass: 'generic-report-dialog-wrapper',
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
    });
  }

  openToolDialog(tool: Tool) {
    //console.log('tool', tool)

    let defaultOptions = {
      disableClose: false,
      hasBackdrop: true,
      minWidth: '95vw',
      width: '95vw',
      maxWidth: '95vw',
      height: '95vh',
      maxHeight: '95vh',
    };

    const options = Object.assign({}, defaultOptions, tool.props);

    //console.log('options', options)

    const dialogRef = this.dialog.open(ToolsBarWrapperComponent, options);
    dialogRef.componentInstance.tool = tool;
    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
    });
  }

  toggleMeasurementTool() {
    this.measurementTool = !this.measurementTool;
    this.measurementTool ? this.lastSelected.emit('measurement') : this.lastSelected.emit('');
  }

  selectTool(tool: string) {
    // switch off all tools
    //this.switchOffTools()

    // switch on selected tool
    switch (tool) {
      case 'timeSeries':
        if (this.timeSeries) {
          this.timeSeries = false;
          this.toggleCrossCursor(false);
          this.lastSelected.emit(null);
        } else {
          this.switchOffTools();
          this.toggleCrossCursor(true);
          this.toggleTimeSeries();
        }
        break;
      case 'featureInfo':
        if (this.featureInfo) {
          this.featureInfo = false;
          this.toggleCrossCursor(false);
          this.lastSelected.emit(null);
        } else {
          this.toggleCrossCursor(true);
          this.switchOffTools();
          this.toggleFeatureInfo();
        }
        break;
      case 'measurement':
        if (this.measurementTool) {
          this.measurementTool = false;
          this.lastSelected.emit(null);
        } else {
          this.switchOffTools();
          this.toggleMeasurementTool();
        }
        break;
      case 'layerDetails':
        this.toggleCrossCursor(false)
        this.switchOffTools()
        break;
      case 'exposure-analysis':
        this.lastSelected.emit('exposure-analysis');
        this.switchOffTools();
        break;
      default:
        this.switchOffTools();
        break;
    }
  }

  switchOffTools() {
    this.timeSeries = false;
    this.featureInfo = false;
    this.measurementTool = false;
  }

  openMagicSearch() {
    const dialogRef = this.dialog.open(MagicSearchComponent,
      {
        disableClose: false,
        hasBackdrop: true,

        //position: {right: '15px'},
        width: '1100px',
        maxWidth: '95vw',
        //minWidth: '80vw',
        //height: '800px',
        //minHeight: '800px',
        maxHeight: '95vh',
      });
    const sub = dialogRef.componentInstance.locationSelected.subscribe((location) => {
      console.log('location', location);
      // this.mapComponent.nativeElement.mapInstance.setView([location.lat, location.lng], 10)
      this.locationSelected.emit(location)
    })
    dialogRef.afterClosed().subscribe(result => {
      this.toolsBarService.magicSearchIsOpen = false;
      console.log('The dialog was closed');
    });
  }

  printMap() {
  }

  openNewWindow(toolUrl: string) {
    //get root url
    let rootUrl = window.location.origin;
    //open new window
    window.open(rootUrl + toolUrl, '_blank');
  }

  public mapConfigs: Dewetra3MapsConfig[] = ['1', '2h', '2v', '4'];
  public mapsConfig: Observable<Dewetra3MapsConfig> = this.layerStore.getConfig$();

  public setMapsConfig(config: Dewetra3MapsConfig) {
    this.layerStore.setConfig(config);
  }
}
