import { Component, computed, inject, Input, input, OnDestroy, OnInit, signal } from '@angular/core';
import { MatButton, MatIconButton } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltip } from '@angular/material/tooltip';
import { TranslateModule } from '@ngx-translate/core';
import { Tag } from '../../../../models/layer';
import { MenuService } from '../../../../services/menu.service';
import { LmContainerComponent } from '../lm-container/lm-container.component';

@Component({
  selector: 'dewetra3-lm-add-layer-button',
  standalone: true,
  imports: [
    // Angular Material
    MatIconModule,
    MatDialogModule,
    MatIconButton,
    TranslateModule,
    MatTooltip,
    MatButton,
  ],
  template: `
    @if (addLayerEnabled) { @if (btnType == 'small') {
    <span
      class="fas fa-plus pointer p-2"
      (click)="openDialog()"
      [matTooltip]="'DEWETRA3APP.LM.ADD_LAYER' | translate"
    ></span>
    } @else {
    <div class="add-layer-button p-2">
      <button mat-button (click)="openDialog()">
        <mat-icon>add</mat-icon>
        <span class="add-layer-button-text text-uppercase">
          {{ 'DEWETRA3APP.LM.ADD_LAYER' | translate }}
        </span>
      </button>
    </div>
    } }
  `,
  styleUrl: './add-button.component.scss',
})
export class AddButtonComponent implements OnInit, OnDestroy {
  @Input() btnType: string | 'big' | 'small' = 'big';
  private _menuService: MenuService = inject(MenuService);
  private _dialog: MatDialog = inject(MatDialog);

  category = input<string>(); // Input property to set the category
  preselectedTags = input<Tag[]>(); // Input property to set the selected tags
  userData = signal<any>(null);
  addLayerEnabled = computed(() => {
    const userData = this.userData();
    return userData && userData.is_layer_manager;
  });

  async ngOnInit(): Promise<void> {
    const userData = await this._menuService.getUserData();
    this.userData.set(userData);
  }

  openDialog(): void {
    const dialogRef = this._dialog.open(LmContainerComponent, {
      width: '90vw',
      height: '90vh',
      maxWidth: '1000px',
      data: {
        userData: this.userData(),
        category: this.category(),
        preselectedTags: this.preselectedTags(),
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('Dialog result:', result);
    });
  }

  ngOnDestroy(): void {
    console.log('AddButtonComponent destroyed');
  }
}
