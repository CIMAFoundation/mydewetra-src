import { CdkAccordion, CdkAccordionItem } from "@angular/cdk/accordion";
import { NgClass } from "@angular/common";
import { Component, computed, inject, input } from '@angular/core';
import { DewetraTimelineEvent } from '../../../models/event';
import { DewapiService } from '../../../services/dewapi.service';
import { Dewetra3LayerStoreService } from '../../../services/layer-store.service';

@Component({
  selector: 'dewetra3-event-loader',
  standalone: true,
  imports: [
    CdkAccordion,
    CdkAccordionItem,
    NgClass
  ],
  template: `

    <cdk-accordion class="example-accordion">
      <cdk-accordion-item #accordionItem="cdkAccordionItem" class="example-accordion-item">
        <div
          class="event-accordion-item-header position-relative"
          (click)="accordionItem.toggle()"
          tabindex="0"
          [attr.id]="'accordion-header'"
          [attr.aria-expanded]="accordionItem.expanded"
          [attr.aria-controls]="'accordion-body'">
          {{ event().name }}
          <span class="accordion-icon fas" [ngClass]="accordionItem.expanded ? 'fa-chevron-up' : 'fa-chevron-down'">
          </span>
        </div>
        @if (accordionItem.expanded) {
          <div
            class="layer-accordion-item-body mt-1 py-1"
            role="region"
            [style.display]="accordionItem.expanded ? '' : 'none'"
            [attr.id]="'accordion-body'"
            [attr.aria-labelledby]="'accordion-header'"
          >
            @if (event().layers.length === 0) {
              <em class="text-muted">No layers available</em>
            }

            @for (layerId of event().layers; track layer) {
              <div class="single-event-layer" (click)="loadLayer(layerId)">
                <span class="fas fa-layer-group me-1"></span> {{ layerName(layerId) }}
              </div>
            }

            <!--TODO da sostituire sopra con questo quando va-->
            <!--        @for (layer of layersObjects(); track layer) {
                      <div class="d-flex justify-content-between" (click)="layerName(layer)">
                        <span>{{ layer.name }}</span>
                      </div>
                    }-->
          </div>
        }
      </cdk-accordion-item>
    </cdk-accordion>
  `,
  styles: `
    .layer-accordion-item-body {
      border-top: 1px solid var(--dewetra-dark-bg);
    }

    .single-event-layer {
      &:hover {
        color: var(--dewetra-orange);
      }
    }

    .accordion-icon {
      position: absolute;
      right: 0px;
      top: 50%;
      transform: translateY(-50%);
    }
  `
})
export class EventLoaderComponent {
  event = input<DewetraTimelineEvent>();
  private _dewapiService: DewapiService = inject(DewapiService);
  private _dewetra3LayerStoreService: Dewetra3LayerStoreService = inject(Dewetra3LayerStoreService);

  layerName = (layerId: number) => {
    const layer = this._dewapiService.getLayerById(layerId);
    if (!layer) return 'LAYER_NOT_ALLOWED';
    return layer.name;
  };

  layer = computed(() => {
    const event = this.event();
    const layers = this._dewapiService.getLayersInSignal();
    if (!event || !layers()) return [];
    return event.layers.map((layerId) => layers().find((layer) => layer.id === layerId));
  });

  loadLayer(layerId: number) {
    const layer = this._dewapiService.getLayerById(layerId);
    this._dewetra3LayerStoreService.addLayer(layer);
  }

}
