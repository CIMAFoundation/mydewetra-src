import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Tool } from '../../../models/tool.model';

interface tool {
  route: string,
}

@Component({
  selector: 'load-route-tool',
  template: `

  `,
  styles: [``]
})

export class LoadRouteComponent {

  @Input() tool: Tool;

  constructor(private router: Router)   { }
  //navigate to the route
  ngOnInit() {
    this.router.navigate([this.tool.props.route]);
  }
}
