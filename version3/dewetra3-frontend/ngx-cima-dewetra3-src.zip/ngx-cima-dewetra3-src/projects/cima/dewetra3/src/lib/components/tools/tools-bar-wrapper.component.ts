import { Component, Input, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Tool } from '../../models/tool.model';
import { ToolsBarComponentFactory } from './tools-bar-component-factory';


@Component({
  selector: 'dewetra3-tools-bar-tool-wrapper',
  template: `
    @if (toolComponent){
        <ndc-dynamic
            [ndcDynamicComponent]="toolComponent"
            [ndcDynamicInputs]="{tool}"
        ></ndc-dynamic>
    }
  `,

  styleUrls: []
})
export class ToolsBarWrapperComponent implements OnInit {

  private tool$ = new BehaviorSubject<Tool | null>(null);
  public toolComponent!: any;

  @Input() set tool(tool: Tool) {
    this.tool$.next(tool);
  };
  public get tool() {
    return this.tool$.getValue();
  }

  constructor(
    public toolsBarFactory: ToolsBarComponentFactory
  ) { }


  ngOnInit(): void {
    this.toolComponent = this.toolsBarFactory.create(this.tool.component);
  }

}
