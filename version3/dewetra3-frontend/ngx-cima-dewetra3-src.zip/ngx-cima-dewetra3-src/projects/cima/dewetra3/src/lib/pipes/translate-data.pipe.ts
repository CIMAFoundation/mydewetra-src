import {Pipe, PipeTransform} from '@angular/core';
import {TranslateService} from "@ngx-translate/core";
import {map, Observable, of} from "rxjs";

@Pipe({
  name: 'translateDataOr',
  standalone: true,
  pure: false
})
export class TranslateDataOrPipe implements PipeTransform {
  constructor(private translate: TranslateService) {
  }

  transform(key: string, fallback: string): Observable<string> {
    if (!key) return of(fallback);

    return this.translate.get(key).pipe(
      map(translated => translated === key ? fallback : translated)
    );
  }
}
