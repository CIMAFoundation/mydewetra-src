import {CommonModule} from '@angular/common';
import {Component, input, output, signal, ViewChild, WritableSignal} from '@angular/core';
import {MatButtonModule} from '@angular/material/button';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatListOption, MatSelectionList, MatSelectionListChange} from "@angular/material/list";
import {FormsModule} from "@angular/forms";
import {TranslateModule} from "@ngx-translate/core";

@Component({
  selector: 'dewetra3-lm-layer-domains',
  standalone: true,
  imports: [CommonModule, MatCheckboxModule, MatFormFieldModule, MatButtonModule, MatSelectionList, MatListOption, FormsModule, TranslateModule],
  template: `
    <div>
      <h2>{{ 'DEWETRA3APP.LM.SELECT_DOMAINS' | translate }}</h2>
      <p><em>{{ 'DEWETRA3APP.LM.DOMAINS_TIP' | translate }}</em></p>
      <div class="list-wrapper px-2">
        <mat-selection-list (selectionChange)="toggleInList()" #domainsList>
          @for (domain of coordinated_domains(); track domain) {
            <mat-list-option
              [value]="domain"
              [selected]="domains().includes(domain)">{{ domain }}
            </mat-list-option>
          }

        </mat-selection-list>
      </div>


    </div>






  `,
  styleUrl: './layer-domains.component.scss',
})
export class LayerDomainsComponent {
  //[checked]="domains().includes(domain)"

  readonly coordinated_domains = input<string[]>([]);
  readonly domains: WritableSignal<string[]> = signal([]);
  selectedDomains = output<string[]>();


  @ViewChild('domainsList') domainsList: MatSelectionList;

  toggleInList(): void {
    const selected = this.domainsList.selectedOptions.selected.map(option => option.value);
    this.domains.set(selected);
    this.selectedDomains.emit(selected);
  }

  protected readonly Array = Array;
}
