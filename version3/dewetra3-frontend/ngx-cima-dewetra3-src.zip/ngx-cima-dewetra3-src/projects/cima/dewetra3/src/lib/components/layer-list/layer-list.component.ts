import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { Component, EventEmitter, inject, Input, OnDestroy, OnInit, Output, ViewContainerRef } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import {
  BaseLayerManager,
  LayerWithViewProps,
  MetadataComponentFactory,
  replacePlaceholders,
} from '@cima/dewetra3-core';
import { BehaviorSubject, first, map, Subscription } from 'rxjs';

import { GenericReportService } from '../../services/generic-report.service';
import { LayerListService } from '../../services/layer-list.service';

import { TranslateService } from '@ngx-translate/core';
import { Dewetra3LayerStoreService } from '../../services/layer-store.service';
import { InfoWrapperComponent } from '../info-wrapper/info-container.component';
import { LegendModalComponent } from './LegendModalComponent';
import { PropertiesModalComponent } from './PropertiesModalComponent';

@Component({
  selector: 'dewetra3-layer-list',
  templateUrl: './layer-list.component.html',
  styleUrls: ['./layer-list.component.scss'],
})
export class LayerListComponent implements OnInit, OnDestroy {
  @Input() cdkDropListId: string;
  @Input() cdkDropListConnectedTo: string[];

  dragPosition = { x: 350, y: 8 };

  layerListOpened: boolean = true;

  public loadedLayers$: BehaviorSubject<LayerWithViewProps[]> = new BehaviorSubject<LayerWithViewProps[]>([]);

  private loadedLegendsDialogs: MatDialogRef<any>[] = [];

  private legendDialogCounter = 0;
  private _timeServiceSubscription = Subscription.EMPTY;

  @Input() set layers(value: LayerWithViewProps[]) {
    this.loadedLayers$.next(value);
    console.log('layers', value);
  }

  public get layers(): LayerWithViewProps[] {
    return this.loadedLayers$.value;
  }

  @Output() onDrop = new EventEmitter<CdkDragDrop<LayerWithViewProps>>();

  @Output() onZoomToLayer = new EventEmitter<[number, number][]>();
  @Output() OnMouseOverLayer = new EventEmitter<LayerWithViewProps>();
  @Output() OnMouseOutLayer = new EventEmitter<LayerWithViewProps>();

  public layerListService: LayerListService = inject(LayerListService);
  public layerChooserService: Dewetra3LayerStoreService = inject(Dewetra3LayerStoreService);
  public dialog: MatDialog = inject(MatDialog);
  public genericReportService: GenericReportService = inject(GenericReportService);
  public storeService: Dewetra3LayerStoreService = inject(Dewetra3LayerStoreService);
  private viewContainerRef: ViewContainerRef = inject(ViewContainerRef);
  private MetadataComponentFactory = inject(MetadataComponentFactory);
  private _translationService = inject(TranslateService);

  ngOnInit(): void {}

  ngOnDestroy(): void {
    this._timeServiceSubscription.unsubscribe();
  }

  // updateLayers(time: any) {
  //   console.log('update layers', time);
  //   this.storeService.updateLayers(time);
  // }

  removeLayer(layer: LayerWithViewProps) {
    this.closeLegend(layer.layer);
    this.storeService.removeLayer(layer);
  }

  drop(event: CdkDragDrop<LayerWithViewProps>) {
    this.onDrop.emit(event);
  }

  loadLegend(layer: BaseLayerManager) {
    this.legendDialogCounter++;

    // check if legend is already open and close it
    if (this.loadedLegendsDialogs.find((item) => item.componentRef.instance.modalData.manager.uuid === layer.uuid)) {
      this.closeLegend(layer);
      this.loadedLegendsDialogs = this.loadedLegendsDialogs.filter(
        (item) => item.componentRef.instance.modalData.manager.uuid !== layer.uuid
      );
      return;
    }

    let width = '300px';
    const model = layer?.getLayerModel?.();

    if (model?.legendmanager?.props?.default?.dialogWidth) {
      width = model.legendmanager.props.default.dialogWidth;
    }

    //console.log('w', layer.getLayerModel())

    let dialog = this.dialog.open(LegendModalComponent, {
      viewContainerRef: this.viewContainerRef,
      hasBackdrop: false,
      position: {
        right: 50 + this.legendDialogCounter * 10 + 'px',
        top: 90 + this.legendDialogCounter * 10 + 'px',
      },
      width: width,
      minWidth: width,
      maxWidth: width,
      data: {
        manager: layer,
      },
    });

    this.loadedLegendsDialogs.push(dialog);

    dialog.afterClosed().subscribe(() => {
      this.legendDialogCounter > 1 ? this.legendDialogCounter-- : (this.legendDialogCounter = 0);
      // remove legend from loadedLegendsDialogs
      this.loadedLegendsDialogs = this.loadedLegendsDialogs.filter(
        (item) => item.componentRef.instance.modalData.manager.uuid !== layer.uuid
      );
      console.log('after all closed', this.loadedLegendsDialogs);
    });
  }

  closeLegend(layer: BaseLayerManager) {
    console.log('close legend', this.loadedLegendsDialogs);
    let dialog = this.loadedLegendsDialogs.find(
      (item) => item.componentRef.instance.modalData.manager.uuid === layer.uuid
    );
    if (dialog) {
      dialog.close();
    }
  }

  checkIfLayerLegendIsOpen(layer: BaseLayerManager) {
    return this.loadedLegendsDialogs.find((item) => item.componentRef.instance.modalData.manager.uuid === layer.uuid);
  }

  loadProperties(layer: BaseLayerManager): void {
    this.dialog.open(PropertiesModalComponent, {
      viewContainerRef: this.viewContainerRef,
      width: '95vw',
      //height: '85vw',
      data: {
        manager: layer,
      },
    });
  }

  onOpacityChange($event: Event, layer: LayerWithViewProps) {
    const value = ($event.target as HTMLInputElement).value;
    layer.viewProps$.next({
      ...layer.viewProps$.value,
      opacity: parseFloat(value),
    });
  }

  onVisibilityChange(visibility: boolean, layer: LayerWithViewProps) {
    layer.viewProps$.next({
      ...layer.viewProps$.value,
      visibility: visibility,
    });
  }

  loadGetFeatureInfo() {
    const dialogRef = this.dialog.open(InfoWrapperComponent, {
      viewContainerRef: this.viewContainerRef,
      hasBackdrop: false,
      position: { right: '0px' },
      width: '30vw',
      maxWidth: '30vw',
      minWidth: '30vw',
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('Info closed');
    });
  }

  convertLayerDetailsToHtml(layerDetails: string) {
    // search for &NBSP; and replace with <br>
    return layerDetails.replace(/&nbsp;/g, '<br>');
  }

  zoomToLayer(layer: LayerWithViewProps) {
    const bounds = layer.layer.getLayerBounds();
    this.onZoomToLayer.emit(bounds);
  }

  hasMetadata(layer: LayerWithViewProps) {
    return layer.layer.getLayerModel().metadatamanager?.component;
  }

  getLayerDetails(layer: LayerWithViewProps) {
    return layer.layer
      .getLayerDetail$()
      .pipe(map((layerDetails: string) => replacePlaceholders(layerDetails, {}, this._translationService)));
  }

  onDownload(layer: LayerWithViewProps) {
    layer.layer
      .getLayerDownloadUrl$()
      .pipe(first()) // prendi una sola emissione e completa
      .subscribe({
        next: (url) => {
          if (!url) {
            console.error('URL di download non disponibile');
            return;
          }
          const a = document.createElement('a');
          //@ts-ignore
          a.href = url;
          a.setAttribute('download', ''); // nome dal server o dall'header
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        },
        error: (err) => {
          console.error('Download fallito:', err);
          // qui puoi mostrare un toast o un alert
        },
      });
  }

  loadMetadata(layer: LayerWithViewProps) {
    const metadata = layer.layer.getLayerModel().metadatamanager;
    if (!metadata) return;

    if (metadata.component == 'LinkMetadataComponent') {
      // open link in new tab
      window.open(metadata.props.url, '_blank');
    } else {
      // open metadata in new dialog
      const klass = this.MetadataComponentFactory.create(layer.layer.getLayerModel());
      const component = klass;
      const dialogRef = this.dialog.open(component, {
        viewContainerRef: this.viewContainerRef,
        hasBackdrop: false,
        position: { right: '0px' },
        width: '30vw',
        maxWidth: '30vw',
        minWidth: '30vw',
        data: {
          manager: layer.layer.getLayerModel().metadatamanager,
          layer: layer.layer,
        },
      });
      dialogRef.afterClosed().subscribe((result) => {
        console.log('Metadata closed');
      });
    }
  }

  legendItems: any = [];
}
