import {Component} from '@angular/core';
import {MatTab, MatTabGroup} from "@angular/material/tabs";

@Component({
  selector: 'laminazione-charts',
  standalone: true,
  imports: [
    MatTabGroup,
    MatTab
  ],
  templateUrl: './charts.component.html',
  styleUrl: './charts.component.scss'
})
export class ChartsComponent {

}
