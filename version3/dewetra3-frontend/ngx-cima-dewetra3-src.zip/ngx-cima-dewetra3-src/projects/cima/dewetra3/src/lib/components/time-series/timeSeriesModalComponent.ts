import {Component, inject, Inject} from "@angular/core";
import {MAT_DIALOG_DATA, MatDialog} from "@angular/material/dialog";
import {TimepickerService} from "@cima/commons";
import {Dewetra3MapClick, LayerWithViewProps} from "@cima/dewetra3-core";
import {Observable} from "rxjs";

@Component({
  selector: 'time-series-modal',
  template: `

    <cima-dialog-title [hasCloseButton]="true">
      <div class="d-flex align-items-center">
        <span class="fas fa-chart-line me-2"></span>
        {{ 'DEWETRA3APP.TIME_SERIES' | translate }}
      </div>
    </cima-dialog-title>
    <mat-dialog-content>
      <mat-tab-group>
        @for (layer of modalData.layers$ | async  | hasPunctualSeries; track layer.layer.getLayerModel().id) {
          <mat-tab [label]="layer.layer.getLayerModel().name">
            <dewetra3-punctual-chart-wrapper
              [manager]="layer.layer"
              [clickData]="modalData.clickData"
              [dateFrom]="dateFrom" [dateTo]="dateTo">
            </dewetra3-punctual-chart-wrapper>
          </mat-tab>
        }
      </mat-tab-group>
    </mat-dialog-content>


  `,
  styleUrls: [],
})
export class TimeSeriesModalComponent {

  private _timePickerService: TimepickerService = inject(TimepickerService);

  private timePickerValue = this._timePickerService.getTimepickerValue();

  public dateTo = (this.timePickerValue.to === 'now') ? new Date() : new Date(this.timePickerValue.to);
  public dateFrom = new Date(this.timePickerValue.from);

  constructor(
    public dialogRef: MatDialog,
    @Inject(MAT_DIALOG_DATA) public modalData: {
      layers$: Observable<LayerWithViewProps[]>;
      clickData: Dewetra3MapClick
    }
  ) {

  }
}
