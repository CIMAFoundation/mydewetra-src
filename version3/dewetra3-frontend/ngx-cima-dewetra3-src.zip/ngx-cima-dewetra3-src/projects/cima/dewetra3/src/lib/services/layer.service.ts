import {Inject, Injectable} from '@angular/core';

import {
  ChartManager,
  Dewetra3ApiService,
  LayerInfoManager,
  LayerLegendManager,
  LayerManager,
  LayerMetadataManager,
  LayerModel,
  LayerPropertiesManager,
  LayerServer,
  LayerSource,
  MapManager,
} from '@cima/dewetra3-core';

import {CimaEnvironment} from '@cima/commons';

@Injectable({
  providedIn: 'root',
})
/**
 * TODO partial implemented layer services
 */
export class LayerService {
  private mostUsedTags: any = null;

  private baseLayer: LayerModel = {
    name: '',
    name_i18n: '',
    descr: '',
    server: {} as LayerServer,
    source: {} as LayerSource,
    category: '',
    event: undefined,
    hazards: [],
    geoscale: '',
    tags: [],
    inspirethemes: [],
    dracategories: [],
    paths: [],
    icon: '',
    dataid: '',
    thumb: '',
    lonw: 0,
    lone: 0,
    lats: 0,
    latn: 0,
    customprops: {},
    related: [],
    roles: [],


    infomanager: {} as LayerInfoManager,
    legendmanager: {} as LayerLegendManager,
    propertiesmanager: {} as LayerPropertiesManager,
    metadatamanager: {} as LayerMetadataManager,
    layermanager: {} as LayerManager,
    chartmanager: {} as ChartManager,
    mapmanager: {} as MapManager,
  };

  constructor(
    //@Inject('APP_CONFIG') private APP_CONFIG: AppConfig,
    @Inject('env') private env: CimaEnvironment,
    private _api: Dewetra3ApiService //private _translate: TranslateService
  ) {
  }

  generateLayerObject(layer: any) {
    return {
      ...this.baseLayer,
      ...layer,
    };
  }

  /**
   * Per ottenere i dati supportati dalla movie
   * @param serverId
   * @param okCallback
   * @param koCallback
   */
  getSupportedMovie(serverId: any) {
    return this._api.get('ddsmap/supportedmovie/' + serverId + '/');
  }

  /**
   * Per creare la movie di un dato
   * @param serverId
   * @param dataId
   * @param okCallback
   * @param koCallback
   */
  createMovie(serverId: any, dataId: any) {
    return this._api.get('ddsmap/createmovie/' + serverId + '/' + dataId + '/');
  }

  /**
   * Per ricavare la movie già esistente di un dato
   * @param serverId
   * @param dataId
   * @param okCallback
   * @param koCallback
   */
  getMovie(serverId: any, dataId: any) {
    return this._api.get('ddsmap/getmovie/' + serverId + '/' + dataId + '/');
  }

  /**
   * Per ricavare i valori di una determinata timeline in una movie
   * @param serverId
   * @param timelineId
   * @param okCallback
   * @param koCallback
   */
  getMovieTimeline(serverId: any, dataId: any, timelineId: any) {
    return this._api.get('ddsmap/getmovietimeline/' + serverId + '/' + dataId + '/' + timelineId + '/');
  }
}
