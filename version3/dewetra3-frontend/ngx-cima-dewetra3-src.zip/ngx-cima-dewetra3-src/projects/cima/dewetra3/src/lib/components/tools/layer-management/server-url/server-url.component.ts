import {CommonModule} from '@angular/common';
import {Component, effect, inject, input, output, signal} from '@angular/core';
import {MatButton} from '@angular/material/button';
import {MatFormField, MatLabel} from '@angular/material/form-field';
import {MatInput} from '@angular/material/input';
import {LayerModel, LayerServer} from '@cima/dewetra3-core';
import {TranslateModule, TranslateService} from '@ngx-translate/core';
import {MenuService} from '../../../../services/menu.service';
import {MatProgressSpinner} from "@angular/material/progress-spinner";
import {MatIcon} from "@angular/material/icon";
import {CimaCommonsModule} from "@cima/commons";

@Component({
  selector: 'dewetra3-check-server-url',
  standalone: true,
  imports: [CommonModule, MatButton, MatFormField, MatInput, MatLabel, TranslateModule, MatProgressSpinner, MatIcon, CimaCommonsModule],
  template: `
    <div class="server-url py-4 d-flex flex-column">
      <!--      <h2>{{ 'DEWETRA3APP.LM.SERVER_URL' | translate }}</h2>-->
      <p>
        <em>{{ 'DEWETRA3APP.LM.SERVER_CHECK_HINT' | translate }}</em>
      </p>

      <div class="d-flex">
        <mat-form-field class="flex-grow-1 hide-subscript-wrapper">
          <mat-label>{{ 'DEWETRA3APP.LM.SERVER_URL' | translate }}</mat-label>
          <input
            matInput
            type="text"
            [placeholder]="'DEWETRA3APP.LM.SERVER_URL' | translate"
            [value]="serverUrl()"
            (input)="setServerUrl($any($event.target).value)"
          />
        </mat-form-field>

        @if (isLoading()) {
          <div class="p-3">
            <mat-spinner diameter="24"></mat-spinner>
          </div>
        } @else if (errorMessage()) {
          <cima-icon type="symbols" icon="cancel" class="text-danger p-3"></cima-icon>
        } @else if (successMessage()) {
          <cima-icon type="symbols" icon="check_circle" class="text-success p-3"></cima-icon>
        }
      </div>
      <!--
            <button class="w-100 bg-success" mat-flat-button (click)="checkUrl()">
              {{ 'DEWETRA3APP.LM.CONNECT' | translate }}
            </button>

            <div *ngIf="isLoading()">{{ 'DEWETRA3APP.LM.LOADING' | translate }}</div>-->
      <div *ngIf="errorMessage()" class="text-danger"><small><em>{{ errorMessage() | translate }}</em></small></div>
      <div *ngIf="successMessage()" class="success">{{ successMessage() | translate }}</div>
    </div>
  `,
  styleUrl: './server-url.component.scss',
})
export class ServerUrlComponent {
  constructor(private translate: TranslateService) {
    this.initializeEffects();
  }

  private _menuService: MenuService = inject(MenuService);
  //signal output
  layer = input<LayerModel>(); // Input property to set the selected server URL
  onSelectedServer = output<LayerServer>(); // Signal to emit the selected server URL
  serverUrl = signal<string>(''); // Signal to track the server URL
  isValidUrl = signal(false); // Signal to track the validity of the URL
  isLoading = signal(false); // Signal to track loading state
  errorMessage = signal(''); // Signal to track error messages
  successMessage = signal(''); // Signal to track success messages

  initializeEffects() {
    effect(
      () => {
        const l = this.layer();
        if (!l) return;
        console.log('Server URL:', l.server.url);
        this.serverUrl.set(l.server.url);
      },
      {allowSignalWrites: true}
    );
  }

  setServerUrl(url: string) {
    if (!url) return;
    this.serverUrl.set(url);
    if (this.serverUrl().length > 0) {
      this.autocheck()
    }
  }

  timeout: any

  autocheck() {
    if (this.timeout) {
      clearTimeout(this.timeout);
    }
    this.timeout = setTimeout(() => {
      this.checkUrl();
    }, 1000);
  }

  async checkUrl() {
    this.isLoading.set(true);
    this.errorMessage.set('');
    this.successMessage.set('');
    try {
      const result = await this._menuService.check_server(this.serverUrl());
      if (result) {
        this.isValidUrl.set(true);
        this.onSelectedServer.emit(result); // Emit the selected server URL
        let msg = this.translate.instant('DEWETRA3APP.LM.SUCCESSFUL_CONNECTION');
        this.successMessage.set(msg);
      } else {
        this.isValidUrl.set(false);
        this.onSelectedServer.emit(null);
        let msg = this.translate.instant('DEWETRA3APP.LM.INVALID_URL');
        this.errorMessage.set(msg);
      }
    } catch (error) {
      this.onSelectedServer.emit(null);
      let msg = this.translate.instant('DEWETRA3APP.LM.ERROR_CONNECT');
      this.errorMessage.set(msg);
      console.error('Error connecting to server:', error);
    } finally {
      this.isLoading.set(false);
    }
  }
}
