import {NgClass, NgForOf, NgIf} from "@angular/common";
import {Component, Input, OnInit} from '@angular/core';
import {FormsModule} from "@angular/forms";
import {MatButton} from "@angular/material/button";
import {MatFormField, MatLabel} from "@angular/material/form-field";
import {MatIcon} from "@angular/material/icon";
import {MatInput} from "@angular/material/input";
import {MatMenu, MatMenuTrigger} from "@angular/material/menu";
import {MatOption, MatSelect} from "@angular/material/select";
import {ExposureAnalysisService} from "../../../../services/exposure-analysis.service";
import {TranslateModule} from "@ngx-translate/core";

@Component({
  selector: 'ea-result-table',
  templateUrl: './result-table.component.html',
  standalone: true,
  imports: [
    MatButton,
    MatMenuTrigger,
    MatMenu,
    MatFormField,
    MatSelect,
    MatOption,
    MatLabel,
    MatIcon,
    FormsModule,
    MatInput,
    NgIf,
    NgClass,
    NgForOf,
    TranslateModule
  ],
  styleUrl: './result-table.component.scss'
})
export class ResultTableComponent implements OnInit {
  constructor(public exposureAnalysisService: ExposureAnalysisService) {
  }

  selectedFeature: any;

  ngOnInit(): void {
    // if data.fields is empty, create it with all_fields
    if (!this.data.fields) {
      this.data.fields = this.data.all_fields;
    }


    // ON SELECTED FEATURE FROM MAP
    this.exposureAnalysisService.featureSelectedOnMap.subscribe((feature: any) => {
      this.selectedFeature = feature;
      if (this.selectedFeature) {
        this.scrollTableWrapperIDToShowSelectedRowID();
      }
      //console.log('selectedFeature', this.selectedFeature.feature.properties.id);
    })

    // SAVE FETURES BACKUP FOR SEARCH
    this.featuresBackUp = this.data.features;
  }

  @Input() data: any;

  /*TABLE VECTOR STUFF*/
  checkPresenceOfFieldsProperty(wmsId: string) {
    //let fields = this.exposureAnalysisService.selectedToolConfig.json_data.layers.find((layer: any) => layer.wmsId == wmsId).fields;
    //return !!fields;
  }

  checkPresenceOfFiled(fields: any[], field: string) {
    return fields.filter((o: any) => o.name == field).length > 0;
  }

  addRemoveField(oField: any, action: string) {
    if (action == 'add') {
      //if not existe in data.fields, add it
      this.data.fields.push(oField);
    } else {
      this.data.fields = this.data.fields.filter((o: any) => o.name != oField.name);
    }
  }

  sortingDirectionByField: { key: string; direction: string }[] = []

  findDirectionByField(key: any) {
    if (this.sortingDirectionByField && this.sortingDirectionByField.length > 0 && this.sortingDirectionByField.find((o: any) => o.key == key)) {
      return this.sortingDirectionByField.find((o: any) => o.key == key).direction;
    } else {
      return 'noSort';
    }
  }

  sortDataByKey(key: any) {
    let direction = 'asc';
    //if the key is not in the array, add it with the direction asc
    if (!this.sortingDirectionByField.find((o: any) => o.key == key)) {
      this.sortingDirectionByField.push({key: key, direction: direction});
    }
    //if the key is in the array, change the direction
    else {
      this.sortingDirectionByField.find((o: any) => o.key == key).direction = this.sortingDirectionByField.find((o: any) => o.key == key).direction == 'asc' ? 'desc' : 'asc';
      direction = this.sortingDirectionByField.find((o: any) => o.key == key).direction;
    }
    //if direction is asc, sort the data by the key
    if (direction == 'asc') {
      this.data.features.sort((a: any, b: any) => a.properties[key] > b.properties[key] ? 1 : -1);
    }
    //if direction is desc, sort the data by the key
    else {
      this.data.features.sort((a: any, b: any) => a.properties[key] < b.properties[key] ? 1 : -1);
    }
  }

  scrollTableWrapperIDToShowSelectedRowID() {
    let selectedRowID = this.selectedFeature.feature.properties.id;
    let tableWrapper = document.getElementById('table-wrapper');
    let selectedRow = document.getElementById(selectedRowID);
    if (tableWrapper && selectedRow) {
      tableWrapper.scrollTo({
        top: selectedRow.offsetTop - tableWrapper.offsetTop,
        behavior: 'smooth'
      });
    }
  }

  featuresBackUp: any;
  fieldToSearch: string = '';
  textToSearch: string = '';

  applyFilter() {
    if (this.textToSearch.length > 2 && this.fieldToSearch) {
      this.data.features = this.featuresBackUp.filter((feature: any) => {
        return feature.properties[this.fieldToSearch].toString().toLowerCase().includes(this.textToSearch.toLowerCase());
      })
    } else {
      this.resetData()
    }
  }

  sumField(field: string) {
    return this.data.features.reduce((a: any, b: any) => a + b.properties[field], 0);
  }

  averageField(field: string) {
    return this.sumField(field) / this.data.features.length;
  }

  minField(field: string) {
    return Math.min(...this.data.features.map((o: any) => o.properties[field]));
  }

  maxField(field: string) {
    return Math.max(...this.data.features.map((o: any) => o.properties[field]));
  }

  resetData() {
    this.data.features = this.featuresBackUp;
  }

  checkSpaceForTextualFilter() {
    //get element by id textual-filter-wrapper
    let textualFilterWrapper = document.getElementById('textual-filter-wrapper');
    if (textualFilterWrapper) {
      if (textualFilterWrapper.clientWidth > 500) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  protected readonly Object = Object;

}
