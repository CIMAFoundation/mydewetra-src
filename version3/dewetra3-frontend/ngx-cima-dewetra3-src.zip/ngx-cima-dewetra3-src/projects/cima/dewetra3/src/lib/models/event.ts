export type DewetraTimelineEvents = DewetraTimelineEvent[]

export interface DewetraTimelineEvent {
  id: number
  name: string
  enabled: boolean
  date?: string
  lat: number
  lon: number
  datatype: string
  floodcatid: string
  hazards: Hazard[]
  icon: string
  layers: number[]
}

export interface Hazard {
  id: number
  name: string
  icon: any
}

export interface DataTypes {
  id: number
  name: string
  icon: any
}
