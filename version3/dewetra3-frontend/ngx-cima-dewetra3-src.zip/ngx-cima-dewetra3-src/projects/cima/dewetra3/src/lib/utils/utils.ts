import { LayerManagerFactory, LayerWithViewProps } from '@cima/dewetra3-core';
import { BehaviorSubject } from 'rxjs';
import { ReportConfig, SerializableLayer, SerializableReportConfig } from '../models/generic-report';

/**
 * Converts a serializable report configuration to a report configuration.
 * @param config The serializable report configuration.
 * @returns The converted report configuration.
 */
export function fromSerializableReport(
  config: SerializableReportConfig,
  layerManagerFactory: LayerManagerFactory
): ReportConfig {
  const newConfig: ReportConfig = {
    ...config,
    pages: [
      ...config.pages.map((page) => ({
        ...page,
        maps: [
          ...page.maps.map((map) => ({
            ...map,
            layers: new BehaviorSubject(map.layers.map((layer) => fromSerializableLayer(layer, layerManagerFactory))),
          })),
        ],
      })),
    ],
  };

  return newConfig;
}
/**
 * Converts a ReportConfig object to a SerializableReportConfig object.
 * @param config The ReportConfig object to convert.
 * @returns The converted SerializableReportConfig object.
 */

export function toSerializableReport(config: ReportConfig): SerializableReportConfig {
  const clonedConfig = {
    ...config,
    pages: [
      ...config.pages.map((page) => ({
        ...page,
        maps: [
          ...page.maps.map((map) => ({
            ...map,
            layers: map.layers.getValue().map(toSerializableLayer),
          })),
        ],
      })),
    ],
  };

  return clonedConfig;
}

// export function toSerializableLayer(layer: LayerWithViewProps): SerializableLayer {
//   return {
//     model: layer.layer.getLayerModel(),
//     data: {
//       status: 'loading',
//       properties: layer.layer.data$.value.properties,
//       data: null,
//       error: null,
//     },
//     view: layer.viewProps$.value,
//   };
// }

export function toSerializableLayer(layer: LayerWithViewProps): SerializableLayer {
  return {
    model: layer.layer.getLayerModel(),
    data: layer.layer.data$.value,
    view: layer.viewProps$.value,
  };
}

export function fromSerializableLayer(
  serializedLayer: SerializableLayer,
  layerManagerFactory: LayerManagerFactory
): LayerWithViewProps {
  const layerManager = layerManagerFactory.create(serializedLayer.model, serializedLayer.data);

  return {
    layer: layerManager,
    viewProps$: new BehaviorSubject(serializedLayer.view),
  };
}

export async function initReportLayers(config: ReportConfig): Promise<void> {
  for (const page of config.pages) {
    for (const map of page.maps) {
      for (const layer of map.layers.getValue()) {
        const layerManager = layer.layer;
        const props = layerManager.data$.value.properties;
        await layerManager.applyProperties(props);
      }
    }
  }
}

function saveBlobManually(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = filename; // se il browser supporta download=""
  a.rel = 'noopener';

  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  // rilascio del blob URL
  URL.revokeObjectURL(url);
}
