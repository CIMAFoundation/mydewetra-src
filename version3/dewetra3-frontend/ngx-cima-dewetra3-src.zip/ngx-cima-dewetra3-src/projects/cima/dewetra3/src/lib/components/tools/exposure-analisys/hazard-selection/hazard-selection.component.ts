import { NgForOf, NgIf } from '@angular/common';
import { Component, inject } from '@angular/core';
import { CimaCommonsModule } from '@cima/commons';
import { LayerModel } from '@cima/dewetra3-core';
import { TranslateDataOrPipe } from '../../../../pipes/translate-data.pipe';
import { ExposureAnalysisService } from '../../../../services/exposure-analysis.service';
import { Dewetra3LayerStoreService } from '../../../../services/layer-store.service';
import { IconSvgComponent } from '../../../icon-svg/icon-svg.component';

@Component({
  selector: 'ea-hazard-selection',
  templateUrl: './hazard-selection.component.html',
  standalone: true,
  imports: [NgIf, NgForOf, CimaCommonsModule, IconSvgComponent, TranslateDataOrPipe],
  styleUrls: ['./hazard-selection.component.scss'],
})
export class HazardSelectionComponent {
  private _layerStore: Dewetra3LayerStoreService = inject(Dewetra3LayerStoreService);
  public exposureAnalysisService: ExposureAnalysisService = inject(ExposureAnalysisService);

  LayersMap = this.exposureAnalysisService.selectedHazardLayers;

  layerExistsInMap(l: LayerModel) {
    return this.LayersMap().has(l.id);
  }

  async toggleLayer(l: LayerModel) {
    this.LayersMap().has(l.id) ? this.removeLayer(l) : this.addLayer(l);
  }

  private async addLayer(l: LayerModel) {
    if (this.layerExistsInMap(l)) return;

    if (this.LayersMap().size > 0) {
      this._layerStore.removeLayer(this.LayersMap().get(0));
    }

    try {
      const layerAdded = await this._layerStore.addLayer(l);
      if (layerAdded) {
        const newMap = new Map(this.LayersMap());
        if (Array.isArray(layerAdded)) {
          if (layerAdded.length > 0) {
            newMap.set(l.id, layerAdded[0]);
          }
        } else {
          newMap.set(l.id, layerAdded);
        }
        this.LayersMap.set(newMap);
      }
    } catch (e) {
      console.error(e);
    }
  }

  private async removeLayer(l: LayerModel) {
    this._layerStore.removeLayer(this.LayersMap().get(l.id));
    const newMap = new Map(this.LayersMap());
    newMap.delete(l.id);
    this.LayersMap.set(newMap);
  }
}
