import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MapLayout, PageOptions, ReportConfig } from '../../../models/generic-report';
import { Dewetra3MapBaseLayers } from '@cima/dewetra3-core';
import { TileLayer } from 'leaflet';



@Component({
  selector: 'dewetra3-generic-report-print-template',
  templateUrl: './generic-report-print-template.component.html',
  styleUrls: ['./generic-report-print-template.component.scss']
})
export class GenericReportPrintTemplateComponent {
  @Input() reportConfig: ReportConfig;
  @Input() selectedPage?: PageOptions;

  @Output() selectedMap = new EventEmitter<MapLayout>();

  @Input() currentMapSelected: MapLayout;
  @Output() mapMovedEvent = new EventEmitter<{ map: MapLayout, center: L.LatLng; zoom: number }>();
  @Output('baseLayerChange') baseLayerChangeEvent = new EventEmitter<MapLayout>();

  clickOnMap(map: MapLayout) {
    this.selectedMap.emit(map);
  }

  getVisiblePages() {
    if (!!this.selectedPage) {
      return this.reportConfig.pages.filter(p => p === this.selectedPage);
    }
    return this.reportConfig.pages;
  }

  mapMoved(map: MapLayout, event: { center: L.LatLng; zoom: number }) {
    this.mapMovedEvent.emit({ map, ...event });
  }

  baseLayerChange(map: MapLayout, layer: { layer: TileLayer, name: Dewetra3MapBaseLayers }) {
    map.baseLayer = layer.name;
    this.baseLayerChangeEvent.emit(map);
  }
}
