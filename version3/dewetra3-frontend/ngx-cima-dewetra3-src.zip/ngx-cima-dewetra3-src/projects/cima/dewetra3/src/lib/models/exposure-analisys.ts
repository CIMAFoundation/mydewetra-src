export interface AnalysisTool {
  desc: string;
  id: number;
  name: string;
}
export interface AnalysisLayer {
  id: number;
  wmsServer: string;
  wmsId: string;
  name: string;
  descr: string;
  type?: string;
  opacity?: number;
  isRaster?: boolean;
  icon: string;
  bbox: number[];
  style: {
    color: string;
    weight: number;
    fillColor: string;
    fillOpacity: number;
    radius: number;
  };
  fields?: {
    name: string;
    sum?: boolean;
    max?: boolean;
    average?: boolean;
  }[];
}

export interface HazardZone {
  id: number;
  name: string;
  descr: string;
  opacity?: number;
  icon: string;
  type?: string;
  bbox: number[];
  filePath: string;
  classField: string;
  wmsServer: string;
  wmsId: string;
}

export interface ToolConfig {
  id: number;
  name: string;
  descr: string;
  json_data: {
    aoisize: number;
    layers: AnalysisLayer[];
    bbox: number[][];
    hazard_zones: HazardZone[];
  };
  client_manager: string;
}

/*RESULT TABLE*/
export interface HazardZoneData {
  hazardZone: string;
  sum: string;
}

export interface Result {
  data: HazardZoneData[];
  output: string;
  layer_id: string;
}


/*RESULT MAP*/
export interface CRSProperties {
  code: string;
}

export interface CRS {
  type: string;
  properties: CRSProperties;
}

export interface Geometry {
  type: string;
  coordinates: [number, number];
}

export interface Properties {
  id: string;
  name: string;
  owner: string;
  source: string;
  capacity: number;
  fuel: string;
}

export interface Feature {
  type: string;
  geometry: Geometry;
  properties: Properties;
  id: number;
}

export interface FeatureCollection {
  crs: CRS;
  type: string;
  features: Feature[];
  output: string;
  layer_id: string;
}


