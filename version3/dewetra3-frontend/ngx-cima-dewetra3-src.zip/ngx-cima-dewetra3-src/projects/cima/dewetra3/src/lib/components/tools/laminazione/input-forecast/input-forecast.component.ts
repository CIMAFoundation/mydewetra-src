import {Component, effect, EventEmitter, Input, input, output, Output, signal} from '@angular/core';
import {MatFormField, MatLabel} from "@angular/material/form-field";
import {MatOption, MatSelect} from "@angular/material/select";
import {MatIcon} from "@angular/material/icon";
import {FormsModule} from "@angular/forms";

@Component({
  selector: 'laminazione-input-forecast',
  standalone: true,
  imports: [
    MatFormField,
    MatSelect,
    MatOption,
    MatLabel,
    FormsModule
  ],
  templateUrl: './input-forecast.component.html',
  styleUrl: './input-forecast.component.scss'
})
export class InputForecastComponent {

  forecastsList = input<{ id: number, name: string }[]>([]);
  selectedForecast = signal<{ id: number, name: string } | null>(null);
  selectedForecastChange = output<{ id: number, name: string }>();

  constructor() {
    effect(() => {
      const list = this.forecastsList();
      if (list.length > 0 && !this.selectedForecast()) {
        this.selectedForecast.set(list[0]);
        this.selectedForecastChange.emit(list[0]);
      }
    }, {allowSignalWrites: true});
  }

  onSelectChange(selected: any) {
    const forecast = this.forecastsList().find(f => f.id === selected.id);
    if (forecast) {
      this.selectedForecast.set(forecast);
      this.selectedForecastChange.emit(forecast);
    }
  }

}
