import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { SentinelFeature, SentinelSensorInfoResponse } from '@cima/dewetra3-core';
import * as L from 'leaflet';

interface SentinelFeatureAdapted extends SentinelFeature {
  sensorInfo?: SentinelSensorInfoResponse;
} //duplicate interface, to remove circular dependency

@Component({
  selector: 'dewetra3-pluvio-monitoring-map',
  standalone: true,
  imports: [],
  templateUrl: './pluvio-monitoring-map.component.html',
  styleUrl: './pluvio-monitoring-map.component.scss',
})
export class PluvioMonitoringMapComponent implements OnChanges {
  map: L.Map | undefined;
  markerOnMap: L.LayerGroup | undefined;

  @Input() selectedPluvio: SentinelFeatureAdapted;

  constructor() {}

  ngAfterViewInit() {
    this.map = L.map('pluvio-monitoring-map').setView([41.9, 12.5], 6);
    this.markerOnMap = L.layerGroup().addTo(this.map);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
    }).addTo(this.map);

    //set italy bounding box
    this.resetMap();
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('selectedPluvio', this.selectedPluvio);
    if (this.selectedPluvio && this.map) {
      //remove previous marker
      this.markerOnMap.clearLayers();
      const point = L.latLng(this.selectedPluvio.geometry.coordinates[1], this.selectedPluvio.geometry.coordinates[0]);

      //custom marker icon
      const customIcon = L.icon({
        iconUrl: 'assets/dewetra3/markers/marker-icon.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41],
      });
      // add marker
      L.marker(point, { icon: customIcon }).addTo(this.markerOnMap);

      this.map.flyTo(point, 12, { duration: 2 });
    } else {
      this.resetMap();
    }
  }

  resetMap() {
    if (this.map) {
      this.map.fitBounds([
        [47.1, 6.6],
        [35.5, 18.5],
      ]);
    }
  }
}
