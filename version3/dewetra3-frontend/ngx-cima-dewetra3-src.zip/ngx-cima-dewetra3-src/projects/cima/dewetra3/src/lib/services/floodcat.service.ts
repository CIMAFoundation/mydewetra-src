import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Dewetra3ApiService } from '@cima/dewetra3-core';
import { FloodCatEventLocations, FloodCatEvents } from '../models/floodcat';
import { firstValueFrom, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FloodcatService {

  private _apiService: Dewetra3ApiService = inject(Dewetra3ApiService);

  async getFloodCatEvents(floodCatTag: string): Promise<FloodCatEvents> {
    return await firstValueFrom(this._apiService.getFloodCatApi<FloodCatEvents>('/floodcat/events/', { tag: floodCatTag }));
  }

  async getFloodCatEventLocations(eventIds: string[]): Promise<FloodCatEventLocations> {
    return await firstValueFrom(this._apiService.getFloodCatApi<FloodCatEventLocations>('/floodcat/eventlocations/', { eventIds: eventIds.join(',') }));
  }


}
