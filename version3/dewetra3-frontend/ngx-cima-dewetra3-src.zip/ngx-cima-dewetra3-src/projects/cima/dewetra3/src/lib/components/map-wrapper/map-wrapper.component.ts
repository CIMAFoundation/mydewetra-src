import {CdkDragDrop} from '@angular/cdk/drag-drop';
import {Component, EventEmitter, inject, Input, Output, ViewChild} from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import {AppSidenavService} from '@cima/commons';
import {
  Dewetra3LayerEvent,
  Dewetra3LayerEventWithData,
  Dewetra3MapClick,
  LayerWithViewProps,
  MapPosition,
} from '@cima/dewetra3-core';
import * as L from 'leaflet';
import {Observable} from 'rxjs';
import {FeatureChartsModalComponent} from '../../components/chart-container/FeatureChartsModalComponent';
import {TimeSeriesModalComponent} from '../../components/time-series/timeSeriesModalComponent';
import {Dewetra3Service} from '../../services/dewetra3.service';
import {ExposureAnalysisService} from '../../services/exposure-analysis.service';
import {LayerListService} from '../../services/layer-list.service';
import {Dewetra3LayerStoreService} from '../../services/layer-store.service';
import {EaContainerComponent} from '../tools/exposure-analisys/ea-container/ea-container.component';

@Component({
  selector: 'dewetra3-map-wrapper',
  standalone: false,
  templateUrl: './map-wrapper.component.html',
  styleUrl: './map-wrapper.component.scss',
})
export class MapWrapperComponent {
  @Input() timepicker: any;
  @Input() nMaps: any;
  @Input() orientation: any;
  @Input() layers$: Observable<LayerWithViewProps[]>;
  @Input() index: number;
  @Input() mapViewBounds: [number, number][];

  @Output() mapPositionChange = new EventEmitter<{
    center: L.LatLng;
    zoom: number;
  }>();

  @ViewChild('mapComponent') mapComponent: any;

  @ViewChild('exposureAnalysis') exposureAnalysis: EaContainerComponent;

  public dewetra3Service: Dewetra3Service = inject(Dewetra3Service);
  public appSidenavService: AppSidenavService = inject(AppSidenavService);

  public modal: MatDialog = inject(MatDialog);
  public layerStore: Dewetra3LayerStoreService = inject(Dewetra3LayerStoreService);
  public layerList: LayerListService = inject(LayerListService);

  public showToolsPanel: boolean = false;
  public activeToolsPanelTool: string | 'over' | 'layerDetails' | 'featureInfo' | 'measurement' | 'timeSeries' = 'over';
  public timeSeriesFullScreen: boolean = false;

  public mousePosition: any;

  mapClickEvent: Dewetra3MapClick;
  layerClickEvent: Dewetra3LayerEventWithData;
  mapLayerEvent: Boolean = false;
  locationSelected: any;
  //mapViewBounds: [number, number][];

  layerToDetails: LayerWithViewProps = null;

  @ViewChild('toolbar') toolbar: any;

  constructor(public exposureAnalysisService: ExposureAnalysisService) {
  }

  drop(event: CdkDragDrop<LayerWithViewProps>, mapIndex: number) {
    const layer = event.item.data as LayerWithViewProps;

    this.layerStore.sort(event.previousIndex, event.currentIndex, mapIndex, layer);
  }

  onZoomToLayer(bounds: [number, number][]) {
    this.mapViewBounds = bounds;
  }

  mouseOverLayerTimeOut: any;

  OnMouseOverLayer($event: LayerWithViewProps) {
    //this.setActiveToolsPanelTool('layerDetails');
    this.mouseOverLayerTimeOut = setTimeout(() => {
      this.showToolsPanel = true;
      this.layerToDetails = $event;
      this.activeToolsPanelTool = 'layerDetails';
      this.toolbar.selectTool('layerDetails');
    }, 500);
  }

  OnMouseOutLayer($event: LayerWithViewProps) {
    this.layerToDetails = null;
    clearTimeout(this.mouseOverLayerTimeOut);
  }

  mapOverTimeout: any;

  onLayerEvent(event: Dewetra3LayerEvent) {
    console.log('layerEvent', event);

    switch (event.type) {
      case 'click':
        this.layerClickEvent = event;
        this.showSensorChart(event);
        break;
      case 'mouseover':
        //if not active tool, set the active tool to 'over' doing nothing
        if (this.activeToolsPanelTool !== 'over') return;

        //delay the mouseover event to avoid flickering
        this.mapOverTimeout = setTimeout(() => {
          this.toolbar.selectTool('over');
          this.toggleActiveToolsPanelTool('over');
        }, 500);

        this.layerClickEvent = event;
        this.mapLayerEvent = true;
        break;
      case 'mouseout':
        this.mapLayerEvent = true;
        clearTimeout(this.mapOverTimeout);
        //this.toggleActiveToolsPanelTool(this.previousToolsPanelTool);
        break;
      case 'loaded':
        //console.log('loaded', event);
        break;
    }
  }

  onMapEvent(event: Dewetra3MapClick) {
    //console.log(event);
    this.addInfoMarkerOnMap(event);
    this.mapClickEvent = event;
    //if active tool is 'timeSeries' and map click event is not null and timeseriesFullScreen is true, open time series modal
    if (
      this.activeToolsPanelTool === 'timeSeries' &&
      this.mapClickEvent &&
      this.timeSeriesFullScreen
    ) {
      this.showTimeSeriesChartOnModal(event, this.layers$);
    }
  }

  onMapPositionChange(event: { center: L.LatLng; zoom: number }) {
    this.mapPositionChange.emit(event);
  }

  addInfoMarkerOnMap(event: Dewetra3MapClick) {
    // define custom icon for info marker
    let infoIcon = L.icon({
      iconUrl: 'assets/icons/target.svg',
      iconSize: [36, 36],
      iconAnchor: [18, 18],
      popupAnchor: [0, -18],
    });

    // if feature info tool is active, remove info marker from map and add a new one setting 'info' custom type
    if (this.activeToolsPanelTool == 'featureInfo') {
      this.removeInfoMarker(event);
      const marker = L.marker(event.latLng, {icon: infoIcon}).addTo(event.map);
      (marker as any).type = 'info';
    }
  }

  //remove info marker from map
  removeInfoMarker(event: Dewetra3MapClick) {
    if (event) {
      event.map.eachLayer((layer: any) => {
        if (layer instanceof L.Marker && (layer as any).type == 'info') {
          event.map.removeLayer(layer);
        }
      });
    }
  }

  showSensorChart(event: Dewetra3LayerEvent) {
    this.modal.open(FeatureChartsModalComponent, {
      width: '95vw',
      minWidth: '95vw',
      height: '95vh',
      minHeight: '95vh',
      data: {
        clickData: event,
      },
    });
  }

  showTimeSeriesChartOnModal(event: Dewetra3MapClick, layers$: Observable<LayerWithViewProps[]>) {
    this.modal.open(TimeSeriesModalComponent, {
      width: '95vw',
      minWidth: '95vw',
      height: '95vh',
      minHeight: '95vh',
      data: {
        clickData: event,
        layers$,
      },
    });
  }

  onLocationSelected($event: MapPosition) {
    this.locationSelected = $event;
  }

  toggleActiveToolsPanelTool(tool: string) {
    console.log('toggleActiveToolsPanelTool', tool);
    let newTool = tool ? tool : 'over';
    this.showToolsPanel = true;
    this.setActiveToolsPanelTool(newTool);
    this.appSidenavService.close();
  }

  getListId(index: number) {
    return 'dewetra3-layer-list-' + index;
  }

  getListConnectedTo(index: number) {
    return [0, 1, 2, 3].filter((v) => v !== index).map(this.getListId);
  }

  setActiveToolsPanelTool(tool: string) {
    this.activeToolsPanelTool = tool;
    // if tool is not 'featureInfo' remove info marker from map
    if (tool !== 'featureInfo') this.removeInfoMarker(this.mapClickEvent);
    // if exposure exist reset analysis
    if (this.exposureAnalysis) {
      this.exposureAnalysis.restartAnalysis();
    }
  }

  setMousePosition(event: any) {
    this.mousePosition = event.cursor.lat.toFixed(6) + ', ' + event.cursor.lng.toFixed(6);
  }

  closePanelTool() {
    this.activeToolsPanelTool = 'over';
    this.showToolsPanel = false;
    this.toolbar.switchOffTools();
    // if exposure exist reset analysis
    if (this.exposureAnalysis) {
      this.exposureAnalysis.restartAnalysis();
    }
  }

  togglePanelMode() {
    if (this.dewetra3Service.toolsPanelMode == 'dock') {
      this.dewetra3Service.setPanelMode('float');
      /*this.addStyleToToolsPanel()*/
    } else {
      this.dewetra3Service.setPanelMode('dock');
    }
  }
}
