import {NgForOf, NgIf} from '@angular/common';
import {Component, inject} from '@angular/core';
import {CimaCommonsModule} from '@cima/commons';
import {LayerModel} from '@cima/dewetra3-core';
import {ExposureAnalysisService} from '../../../../services/exposure-analysis.service';
import {Dewetra3LayerStoreService} from '../../../../services/layer-store.service';
import {IconSvgComponent} from "../../../icon-svg/icon-svg.component";
import {TranslateDataOrPipe} from "../../../../pipes/translate-data.pipe";

@Component({
  selector: 'ea-exposures-selection',
  templateUrl: './exposures-selection.component.html',
  standalone: true,
  imports: [NgIf, NgForOf, CimaCommonsModule, IconSvgComponent, TranslateDataOrPipe],
  styleUrls: ['./exposures-selection.component.scss'],
})
export class ExposuresSelectionComponent {
  private _layerStore: Dewetra3LayerStoreService = inject(Dewetra3LayerStoreService);
  public exposureAnalysisService: ExposureAnalysisService = inject(ExposureAnalysisService);

  LayersMap = this.exposureAnalysisService.selectedExposureLayers;

  isLayerPresent(l: LayerModel) {
    return this.LayersMap().has(l.id);
  }

  async toggleLayer(l: LayerModel) {
    this.LayersMap().has(l.id) ? this.removeLayer(l) : this.addLayer(l);
  }

  private async addLayer(l: LayerModel) {
    const layerAdded = await this._layerStore.addLayer(l);
    if (layerAdded) {
      const newMap = new Map(this.LayersMap());
      newMap.set(l.id, Array.isArray(layerAdded) ? layerAdded[0] : layerAdded);
      this.LayersMap.set(newMap);
    }
  }

  public async removeLayer(l: LayerModel) {
    this._layerStore.removeLayer(this.LayersMap().get(l.id));
    const newMap = new Map(this.LayersMap());
    newMap.delete(l.id);
    this.LayersMap.set(newMap);
  }
}
