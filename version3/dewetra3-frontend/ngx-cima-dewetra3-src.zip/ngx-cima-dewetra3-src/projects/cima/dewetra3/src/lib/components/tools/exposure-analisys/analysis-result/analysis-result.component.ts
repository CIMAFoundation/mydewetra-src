import {Component, effect, EventEmitter, inject, input, InputSignal, Output} from '@angular/core';

import {NgClass, NgForOf, NgIf} from '@angular/common';
import {MatButton, MatIconButton} from '@angular/material/button';
import {MatDialog} from '@angular/material/dialog';
import {
  MatAccordion,
  MatExpansionPanel,
  MatExpansionPanelHeader,
  MatExpansionPanelTitle,
} from '@angular/material/expansion';
import {MatTooltip} from '@angular/material/tooltip';
import {SnackbarService} from '@cima/commons';
import {ExposureAnalysisService} from '../../../../services/exposure-analysis.service';
import {ResultTableComponent} from '../result-table/result-table.component';
import {TableDialogComponent} from '../table-dialog/table-dialog.component';
import {TranslateModule, TranslateService} from "@ngx-translate/core";

@Component({
  selector: 'ea-analysis-result',
  templateUrl: './analysis-result.component.html',
  standalone: true,
  imports: [
    MatAccordion,
    MatExpansionPanel,
    MatExpansionPanelTitle,
    MatExpansionPanelHeader,
    NgIf,
    NgForOf,
    MatButton,
    MatIconButton,
    NgClass,
    MatTooltip,
    ResultTableComponent,
    TranslateModule,
  ],
  styleUrls: ['./analysis-result.component.scss'],
})
export class AnalysisResultComponent {
  constructor(private translate: TranslateService,) {
    effect(() => {
      if (this.selectedIndex() == 3) {
        this.generateAnalysisResult();
      }
    });
  }

  @Output() onGetResult: EventEmitter<any> = new EventEmitter<any>();

  public exposureAnalysisService: ExposureAnalysisService = inject(ExposureAnalysisService);
  private snackbarService: SnackbarService = inject(SnackbarService);
  private dialog: MatDialog = inject(MatDialog);

  selectedIndex: InputSignal<number | null> = input(null);
  analysisResult: any[];
  loading: boolean = false;
  previousAnalysisRequest: any;

  generateAnalysisResult() {
    if (this.exposureAnalysisService.selectedExposureLayers().size == 0) {
      let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.SELECT_EXPOSURE');
      this.snackbarService.error(msg, '', {duration: 5000});
      return;
    }
    if (!this.exposureAnalysisService.selectedPolygon()) {
      let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.SELECT_POLYGON');
      this.snackbarService.error(msg, '', {
        duration: 5000,
      });
      return;
    }

    //check if the previous analysis request is the same as the current request
    if (JSON.stringify(this.previousAnalysisRequest) == JSON.stringify(this.exposureAnalysisService.buildedBody())) {
      return;
    }

    //reset analysis result
    this.analysisResult = [];

    //console.log('Generating analysis result');
    this.loading = true;
    this.exposureAnalysisService.postAnalysis(this.exposureAnalysisService.buildedBody()).subscribe({
      next: (res) => {
        //save request to previousAnalysisRequest
        this.previousAnalysisRequest = this.exposureAnalysisService.buildedBody();

        res.forEach((result: any) => {
          //console.log('result', result.layer_id);
          //check if there are more than one layer with the same layer_id
          let count = res.filter((o: any) => o.layer_id == result.layer_id).length;
          if (count > 1) {
            // add flag to result where there are more than one layer with the same layer_id and output is equal to impacts_map
            if (result.output == 'impacts_map') {
              result.hideTable = true;
            }
          }
        });

        console.log('res', res);

        /*        //remove all features from map before add new features
                this.mapManagerService.removeAllFeaturesFromMap();


                res.forEach((result: any) => {
                  if (result.output !== 'impact_sum') {
                    this.mapManagerService.addFeatureGroup(result)
                  }
                })*/

        this.analysisResult = res;

        //emit result for populate map
        this.onGetResult.emit(this.analysisResult);

      },
      error: (err) => {
        let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.ERROR_GENERATING_ANALYSIS');
        this.snackbarService.error(msg, '', {
          duration: 5000,
        });
      },
      complete: () => {
        this.loading = false;
      },
    });
  }

  openResultFullScreen() {
    this.dialog.open(TableDialogComponent, {
      data: this.analysisResult,
      width: '90%',
      height: '90%',
      panelClass: 'full-screen-dialog',
    });
  }

  /*TABLE SORTING*/
  sortingDirectionByField: { key: string; direction: string }[] = [];

  findDirectionByField(key: any) {
    if (
      this.sortingDirectionByField &&
      this.sortingDirectionByField.length > 0 &&
      this.sortingDirectionByField.find((o: any) => o.key == key)
    ) {
      return this.sortingDirectionByField.find((o: any) => o.key == key).direction;
    } else {
      return 'noSort';
    }
  }

  sortDataByKey(key: any, data: any) {
    let direction = 'asc';
    //if the key is not in the array, add it with the direction asc
    if (!this.sortingDirectionByField.find((o: any) => o.key == key)) {
      this.sortingDirectionByField.push({key: key, direction: direction});
    }
    //if the key is in the array, change the direction
    else {
      this.sortingDirectionByField.find((o: any) => o.key == key).direction =
        this.sortingDirectionByField.find((o: any) => o.key == key).direction == 'asc' ? 'desc' : 'asc';
      direction = this.sortingDirectionByField.find((o: any) => o.key == key).direction;
    }

    //convert data.sum in number
    data.forEach((result: any) => {
      if (result.sum) {
        result.sum = parseFloat(result.sum);
      }
    });

    //if direction is asc, sort the data by the key
    if (direction == 'asc') {
      data.sort((a: any, b: any) => (a[key] > b[key] ? 1 : -1));
    }
    //if direction is desc, sort the data by the key
    else {
      data.sort((a: any, b: any) => (a[key] < b[key] ? 1 : -1));
    }
  }

  convertAnalysisResultToCSV() {
    console.log('Converting analysis result to CSV and download', this.analysisResult);
    let csv = '';

    this.analysisResult.forEach((result: any) => {
      const layerId = result.layer_id || 'unknown_layer';
      const outputType = result.output || 'unknown_output';

      if (outputType === 'impacts_map') {
        csv += `### ${layerId} - impacts_map ###\n`;
        if (result.features?.length) {
          const header = Object.keys(result.features[0].properties).join(';');
          csv += header + '\n';
          result.features.forEach((feature: any) => {
            const data = Object.values(feature.properties).join(';');
            csv += data + '\n';
          });
          csv += '\n';
        }
      } else if (outputType === 'impacts_sum') {
        csv += `### ${layerId} - impacts_sum ###\n`;

        const header = Object.keys(result.data[0]).join(';');
        const dataRows: string[] = result.data.map((row: any) => {
          return Object.values(row).join(';');
        });

        csv += header + '\n';
        csv += dataRows.join('\n') + '\n\n';
      }
    });

    // download
    const blob = new Blob([csv], {type: 'text/csv;charset=utf-8;'});
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', 'analysis_results.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
