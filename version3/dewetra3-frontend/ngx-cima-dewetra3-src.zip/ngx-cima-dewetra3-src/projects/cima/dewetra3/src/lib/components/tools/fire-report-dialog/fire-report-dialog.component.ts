import { Component, OnInit } from '@angular/core';

export interface MapLayout {
  id: number,
  mapTitle: string,
  showLegend: boolean,
  adminLimits: boolean,
  opacity: number,
  layerId: string,
}


@Component({
  selector: 'cima-fire-report-dialog',
  templateUrl: './fire-report-dialog.component.html',
  styleUrls: ['./fire-report-dialog.component.scss']
})


export class FireReportDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }



  singleMapLayoutConf: MapLayout =
    {
      id:0,
      mapTitle: 'Map Title',
      showLegend: true,
      adminLimits: false,
      opacity: 100,
      layerId: ''
    }

  //TODO agganciare al servizio dei layer caricati
  availableLayers: any[] = [
    {
      id: 'layer1',
      name: 'Layer 1'
    },
    {
      id: 'layer2',
      name: 'Layer 2'
    }
  ]

  public reportTitle: string = 'Fire Report of' + ' ' + new Date().toLocaleDateString()

  public lockPan: boolean = false

  public selectedMapLayout: MapLayout[] = [this.singleMapLayoutConf]

  public selectedOrientationLayout: string | 'landscape' | 'portrait' = 'landscape'

  setMapLayout(maps: number){
    switch (maps) {
      case 1:
        this.selectedMapLayout.splice(1)
        break;
      case 2:
        if (this.selectedMapLayout.length === 1) {
          this.selectedMapLayout.push(this.singleMapLayoutConf)
        } else if (this.selectedMapLayout.length > 2) {
          this.selectedMapLayout.splice(2)
        }
        break;
      case 4:
        if (this.selectedMapLayout.length !== 4) {
          while (this.selectedMapLayout.length < 4) {
            this.selectedMapLayout.push(this.singleMapLayoutConf)
          }
        }
        break;
      default:
        this.selectedMapLayout = [this.singleMapLayoutConf]
        break;
    }
  }


}
