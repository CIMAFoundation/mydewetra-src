import {Component, input, computed} from '@angular/core';
import {LayerWithViewProps} from '@cima/dewetra3-core';
import {AsyncPipe} from "@angular/common";
import {TranslateDataOrPipe} from "../../pipes/translate-data.pipe";

@Component({
  selector: 'dewetra3-layer-details',
  standalone: true,
  template: `
    @if (layer()?.layer?.getLayerModel()) {
      <div>
        <h4>{{ layer()?.layer?.getLayerModel()?.name }}
          {{ 'LAYERS.' + layer()?.layer?.getLayerModel()?.name_i18n | translateDataOr:layer()?.layer?.getLayerModel()?.name | async }}
        </h4>
        <p [innerHTML]="layerDetailsHtml()"></p>
      </div>
    }
  `,
  styles: [],
  imports: [
    AsyncPipe,
    TranslateDataOrPipe
  ]
})
export class LayerDetailsComponent {
  layer = input<LayerWithViewProps>();

  layerDetailsHtml = computed(() => {
    const detail = this.layer()?.layer?.getLayerModel()?.descr;
    return detail ? detail.replace(/&nbsp;/g, '<br>') : '';
  });
}
