import {CommonModule} from '@angular/common';
import {Component, inject, input, output, signal} from '@angular/core';
import {MatButton} from '@angular/material/button';
import {MatFormField, MatLabel} from '@angular/material/form-field';
import {MatInput} from '@angular/material/input';
import {LayerServer} from '@cima/dewetra3-core';
import {TranslateModule, TranslateService} from '@ngx-translate/core';
import {MenuService} from '../../../../services/menu.service';
import {CimaCommonsModule} from "@cima/commons";
import {MatProgressSpinner} from "@angular/material/progress-spinner";

interface LayerCAPABILITIES {
  Name?: string;
  Layer?: LayerCAPABILITIES[];
}

@Component({
  selector: 'dewetra3-lm-check-dataid',
  standalone: true,
  imports: [CommonModule, MatButton, MatFormField, MatLabel, MatInput, TranslateModule, CimaCommonsModule, MatProgressSpinner],
  template: `
    <div class="data-id">
      <!--     <h2>{{ 'DEWETRA3APP.LM.CHECK_DATA_ID' | translate }}</h2>-->
      <p>
        <em>{{ 'DEWETRA3APP.LM.DATA_ID_TIP' | translate }}</em>
      </p>

      <div class="d-flex">
        <mat-form-field class="flex-grow-1 hide-subscript-wrapper">
          <mat-label>{{ 'DEWETRA3APP.LM.INSERT_DATA_ID' | translate }}</mat-label>
          <input
            matInput
            type="text"
            [placeholder]="'DEWETRA3APP.LM.INSERT_DATA_ID' | translate"
            [value]="dataId()"
            (input)="setDataId($any($event.target).value)"
          />
        </mat-form-field>

        @if (isLoading()) {
          <div class="p-3">
            <mat-spinner diameter="24"></mat-spinner>
          </div>
        } @else if (errorMessage()) {
          <cima-icon type="symbols" icon="cancel" class="text-danger p-3"></cima-icon>
        } @else if (successMessage()) {
          <cima-icon type="symbols" icon="check_circle" class="text-success p-3"></cima-icon>
        }
      </div>

      <!--      <button mat-flat-button class="bg-success w-100" (click)="checkDataid()">
              {{ 'DEWETRA3APP.LM.CONNECT' | translate }}
            </button>-->

      <!--      <div *ngIf="isLoading()">Loading...</div>-->
      <div *ngIf="errorMessage()" class="text-danger"><small><em>{{ errorMessage() | translate }}</em></small></div>
      <div *ngIf="successMessage()" class="success">{{ successMessage() | translate }}</div>
    </div>
  `,
  styleUrl: './check-dataid.component.scss',
})
export class CheckDataidComponent {
  constructor(private translate: TranslateService) {
  }

  private _menuService: MenuService = inject(MenuService);

  selectedServer = input<LayerServer | null>(null); // Signal to track the selected server

  //signal output
  onSelectedID = output<string>(); // Signal to emit the selected server URL
  dataId = signal(''); // Signal to track the server URL input
  isLoading = signal(false); // Signal to track loading state
  errorMessage = signal(''); // Signal to track error messages
  successMessage = signal(''); // Signal to track success messages

  //https://gs01.cimafoundation.org/geoserver/wms
  //scenario:facilities

  async checkDataid() {
    if (this.selectedServer().id) {
      this.isLoading.set(true);
      const capabilities = await this._menuService.getCapabilities(this.selectedServer().id);
      if (capabilities) {
        //console.log('Capabilities:', capabilities);
        this.errorMessage.set('');
        let msg = this.translate.instant('DEWETRA3APP.LM.SUCCESSFUL_CONNECTION');
        this.successMessage.set(msg);
        const exists = this.checkIfDataidExistsInCapabilities(
          capabilities?.WMS_Capabilities?.Capability?.Layer,
          this.dataId()
        );
        if (exists) {
          let msg = this.translate.instant('DEWETRA3APP.LM.DATA_ID_EXISTS');
          this.successMessage.set(msg);
          this.onSelectedID.emit(this.dataId()); // Emit the selected server URL
        }
        this.isLoading.set(false);
      } else {
        let msg = this.translate.instant('DEWETRA3APP.LM.INVALID_DATA_ID');
        this.errorMessage.set(msg);
        this.isLoading.set(false);
      }
    }
  }

  checkIfDataidExistsInCapabilities(layer: LayerCAPABILITIES, dataId: string): boolean {
    if (layer.Name === dataId) {
      return true;
    }

    if (layer.Layer && Array.isArray(layer.Layer)) {
      return layer.Layer.some((subLayer) => this.checkIfDataidExistsInCapabilities(subLayer, dataId));
    }

    return false;
  }

  setDataId(id: string): void {
    if (!id) return;
    this.dataId.set(id);
    if (this.dataId().length > 0) {
      this.autocheck()
    }
  }

  timeout: any

  autocheck() {
    if (this.timeout) {
      clearTimeout(this.timeout);
    }
    this.timeout = setTimeout(() => {
      this.checkDataid();
    }, 1000);
  }


}
