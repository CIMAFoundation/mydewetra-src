import {Component, Inject} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog} from "@angular/material/dialog";
import {BaseLayerManager} from '@cima/dewetra3-core';


@Component({
  selector: 'legend-modal',
  template: `
    <div class="legend-modal">
      <div class="dialog-title d-flex justify-content-between p-1"
           cdkDrag
           cdkDragBoundary=".cdk-overlay-container"
           cdkDragRootElement=".cdk-overlay-pane"
           cdkDragHandle>
        <div class="d-flex title-wrapper align-items-center">
          <cima-icon class="drag-btn" icon="drag_indicator"></cima-icon>
          <span class="title-text"
                [matTooltip]="'LAYERS.' + modalData.manager.getLayerModel().name_i18n| translateDataOr:modalData.manager.getLayerModel().name | async">
            {{ 'LAYERS.' + modalData.manager.getLayerModel().name_i18n| translateDataOr:modalData.manager.getLayerModel().name | async }}
          </span>
        </div>
        <cima-icon class="close-btn" icon="close" [matDialogClose]=""></cima-icon>
      </div>
      <cima-dialog-content>
        <dewetra3-legend-wrapper [manager]="modalData.manager"></dewetra3-legend-wrapper>
      </cima-dialog-content>
    </div>
  `,
  styleUrls: ['./legend-modal.component.scss'],
})
export class LegendModalComponent {
  constructor(
    public dialogRef: MatDialog,
    @Inject(MAT_DIALOG_DATA) public modalData: { manager: BaseLayerManager; }
  ) {
  }
}
