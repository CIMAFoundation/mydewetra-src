import { Injectable } from '@angular/core';
import { Dewetra3ApiService } from "@cima/dewetra3-core";
import { Observable, Subject } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class LayerListService {

  constructor(private apiService: Dewetra3ApiService) { }

  layerListOpened: boolean = false

  selectedLayers: any = []



  /*ONLY FOR ANIMATION*/
  updating: boolean = false
  updatingAnimation() {
    this.updating = true
    setTimeout(() => { this.updating = false }, 1)
  }




}
