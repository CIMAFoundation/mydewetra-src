import { Component, inject, Input } from '@angular/core';
import * as uiid from 'uuid';
import * as Plotly from 'plotly.js-dist-min';
import { dateToSeconds, SentinelSensorInfoResponse } from '@cima/dewetra3-core';
import { firstValueFrom, Observable } from 'rxjs';
import { CimaEnvironment } from '@cima/commons';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'dewetra3-pluvio-monitoring-chart',
  standalone: true,
  imports: [],
  template: `
    <div class="p-2">
      <div [id]="chartId" class="rounded-2 overflow-hidden">
      </div>
    </div>
  `,
  styles: ``
})
export class PluvioMonitoringChartComponent {

  public chartId = uiid.v4();
  @Input() sensor: SentinelSensorInfoResponse;
  @Input() thr_group: string;
  @Input() serie_id: string;
  @Input() chart_id: string;
  @Input() dateTo: Date;
  @Input() dateFrom: Date;
  @Input() env : CimaEnvironment;
  private _http: HttpClient = inject(HttpClient);



  protected post<T>(url: string, body?: any, params?: any): Observable<T> {
    let server = this.env.server.baseUrl + '/dewetra3/';
    return this._http.post<T>(server + url, body, { params: params });
  }

  async loadChartData(type: string, sentinelSensor: SentinelSensorInfoResponse, dateFrom: Date, dateTo: Date): Promise<any> {


    // const chartProperties = getCustomChartProperties(this.layerModel);


    const params = {
      layer_id: 1,
      serie_id: this.serie_id,
      feature_id: sentinelSensor.sensorId + ';' + sentinelSensor.dbId,
      chart_id: this.chart_id,
      dt1: dateToSeconds(this.dateFrom).toString(),
      dt2: dateToSeconds(this.dateTo).toString(),
      threshold_group: this.thr_group,
    };

    return await firstValueFrom(this.post<any>('chartapi/dds_' + type + '/', {
      feature: sentinelSensor,
      //properties: chartProperties
    }, params));// json or img
  }

  async loadChartBySensor(sensor: SentinelSensorInfoResponse) {
    //const data = await this.loadChartBySensor('json', sensor, this.dateFrom, this.dateTo)
    //await this.plotChart(data);
  }

  async plotChart(chart: any) {
    await Plotly.purge(this.chartId);
    return await Plotly.newPlot(this.chartId, chart);
  }

  ngAfterViewInit() {

  }
}
