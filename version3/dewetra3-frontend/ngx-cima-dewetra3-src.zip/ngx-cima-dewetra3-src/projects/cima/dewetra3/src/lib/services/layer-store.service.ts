import { inject, Injectable } from '@angular/core';
import { TimepickerValue } from '@cima/commons';
import { LayerHazard, LayerManagerFactory, LayerModel, LayerWithViewProps, ViewProps } from '@cima/dewetra3-core';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { DewapiService } from './dewapi.service';

export type Dewetra3MapsConfig = '1' | '2h' | '2v' | '4';

const MAPS_CONFIG = {
  '1': { nMaps: 1, orientation: 'horizontal' },
  '2h': { nMaps: 2, orientation: 'horizontal' },
  '2v': { nMaps: 2, orientation: 'vertical' },
  '4': { nMaps: 4, orientation: 'vertical' },
};

@Injectable({
  providedIn: 'root',
})
export class Dewetra3LayerStoreService {
  private readonly _mapsLayers: BehaviorSubject<LayerWithViewProps[]>[] = [
    new BehaviorSubject<LayerWithViewProps[]>([]),
    new BehaviorSubject<LayerWithViewProps[]>([]),
    new BehaviorSubject<LayerWithViewProps[]>([]),
    new BehaviorSubject<LayerWithViewProps[]>([]),
  ];

  mapsLayers: Observable<LayerWithViewProps[]>[] = this._mapsLayers.map((layers$) => layers$.asObservable());

  private readonly config$ = new BehaviorSubject<Dewetra3MapsConfig>('1');
  private _factory: LayerManagerFactory = inject(LayerManagerFactory);
  private _dewepiService: DewapiService = inject(DewapiService);
  private _from: Date;
  private _to: Date | 'now' = 'now';

  private layerToPreload: string[] = [
    //'italy.floodproofs.gaugeobservation',
    //'COSMO_I5'
  ];

  constructor() {
    this._dewepiService
      .getLayers$()
      .pipe(map((layers) => layers.filter((l) => this.layerToPreload.includes(l.dataid))))
      .subscribe((layers) => {
        layers.forEach((l) => {
          this.addLayer(l, 0, {
            opacity: 1,
            visibility: true,
            showInLayerList: true,
          });
        });
      });
  }

  public get nMaps$() {
    return this.config$.asObservable().pipe(map((config) => MAPS_CONFIG[config].nMaps));
  }

  public get orientation$() {
    return this.config$.asObservable().pipe(map((config) => MAPS_CONFIG[config].orientation));
  }

  public getConfig$(): Observable<Dewetra3MapsConfig> {
    return this.config$.asObservable();
  }

  public setConfig(config: Dewetra3MapsConfig) {
    this.config$.next(config);
    const nMaps = MAPS_CONFIG[config].nMaps;
    // clear the layers on the maps that are not visible
    for (let i = nMaps; i < 4; i++) {
      this._mapsLayers[i].next([]);
    }
  }

  getLayersLoaded(mapIndex: number = 0) {
    return this._mapsLayers[mapIndex].getValue();
  }

  setDateRange(dateFrom: Date, dateTo: Date | 'now') {
    this._from = dateFrom;
    this._to = dateTo;
    this.checkWatching({ from: dateFrom, to: dateTo });
    this.updateLayers({ from: dateFrom, to: dateTo });
  }

  checkWatching(time: TimepickerValue) {
    if (time.to === 'now') {
      this._mapsLayers.forEach((layers$) => {
        layers$.value.forEach((layer: LayerWithViewProps) => {
          try {
            layer.layer.watch();
          } catch (e) {
            console.error(e);
          }
        });
      });
    } else {
      this._mapsLayers.forEach((layers$) => {
        layers$.value.forEach((layer: LayerWithViewProps) => {
          try {
            layer.layer.stopWatch();
          } catch (e) {
            console.error(e);
          }
        });
      });
    }
  }

  updateLayers(time: TimepickerValue) {
    this._mapsLayers.forEach((layers$) => {
      layers$.value.forEach((layer: LayerWithViewProps) => {
        layer.layer.setDateRange(time.from, time.to);
      });
    });
  }

  /**
   * Metodo pubblico: aggiunge un layer (con gestione dei `related` e protezione contro cicli).
   */
  async addLayer(
    model: LayerModel,
    mapIndex = 0,
    viewProps: ViewProps = {
      opacity: 1,
      visibility: true,
      showInLayerList: true,
    },
    visited: Set<string> = new Set()
  ): Promise<LayerWithViewProps[]> {
    const id = model.id.toString();
    if (visited.has(id)) {
      console.warn(`[addLayer] ciclo rilevato: ${id}`);
      console.warn('Layers visitati:', Array.from(visited).join(', '));
      return [];
    }
    visited.add(id);

    const relatedResults: LayerWithViewProps[] = [];

    if (Array.isArray(model.related) && model.related.length > 0) {
      for (const childId of model.related) {
        const childModel = this._dewepiService.getLayerById(childId);
        if (!childModel) {
          console.warn(`[addLayer] Layer related non trovato: ${childId}`);
          continue;
        }
        const results = await this.addLayer(childModel, mapIndex, viewProps, visited);
        relatedResults.push(...results);
      }
    }

    const mainLayer = await this._addLayer(model, mapIndex, viewProps);
    return [mainLayer, ...relatedResults];
  }
  /**
   * Metodo privato: carica un singolo layer in una mappa.
   */
  private async _addLayer(
    model: LayerModel,
    mapIndex = 0,
    viewProps: ViewProps = {
      opacity: 1,
      visibility: true,
      showInLayerList: true,
    }
  ): Promise<LayerWithViewProps> {
    let dateTo: Date, dateFrom: Date;
    if (this._to === 'now') {
      dateTo = new Date();
      dateFrom = new Date(dateTo.getTime() - 24 * 60 * 60 * 1000);
    } else {
      dateTo = this._to;
      dateFrom = this._from;
    }

    const layer = this._factory.create(model);
    const $viewProps = new BehaviorSubject<ViewProps>(viewProps);
    const wrapper: LayerWithViewProps = { layer, viewProps$: $viewProps };

    const layers = this._mapsLayers[mapIndex].value;
    this._mapsLayers[mapIndex].next([wrapper, ...layers]);

    await layer.applyDefaultProperties(dateFrom, dateTo);

    if (this._to === 'now') {
      try {
        layer.watch();
      } catch (e) {
        layer.postActivityLog(e.toString(), 'websocket-error');
      }
    }

    return wrapper;
  }

  removeLayer(layer: LayerWithViewProps) {
    for (let i = 0; i < this._mapsLayers.length; i++) {
      const layers = this._mapsLayers[i].value;
      if (layers.includes(layer)) {
        this._mapsLayers[i].next([...layers].filter((l) => l !== layer));
        layer.layer.destroy();
        return;
      }
    }
  }

  hasLayer(layer: LayerWithViewProps): boolean {
    return this._mapsLayers.some((layers$) => layers$.value.includes(layer));
  }

  hasLayerIdInMap(layerId: number, mapIndex: number = 0): boolean {
    return this._mapsLayers[mapIndex].value.some((layer) => layer.layer.getLayerModel().id === layerId);
  }

  hasLayerIdsInMap(layerIds: number[], mapIndex: number = 0): boolean {
    return this._mapsLayers[mapIndex].value.some((layer) => layerIds.includes(layer.layer.getLayerModel().id));
  }

  sort(previousIndex: number, newIndex: number, mapIndex: number, layer: LayerWithViewProps) {
    // first check if the layer is in the mapIndex list
    let layers = this._mapsLayers[mapIndex].value;
    if (layers.includes(layer)) {
      layers.splice(previousIndex, 1);
      layers.splice(newIndex, 0, layer);
      this._mapsLayers[mapIndex].next([...layers]);
    } else {
      //  we need to remove the layer from the other list
      const origin = this._mapsLayers.find((layers$) => layers$.value.includes(layer));
      origin.next([...origin.value].filter((l) => l !== layer));
      // add the layer at the newIndex position
      layers.splice(newIndex, 0, layer);
      this._mapsLayers[mapIndex].next([...layers]);
    }
  }

  filterLoadedLayersByHazard(hazards: LayerHazard[]) {
    this._mapsLayers.forEach((layers$) => {
      layers$.value.forEach((layer: LayerWithViewProps) => {
        if (hazards.length > 0) {
          if (
            !hazards.some((hazard) =>
              layer.layer.getLayerModel().hazards.some((layerHazard) => layerHazard.id === hazard.id)
            )
          ) {
            layer.viewProps$.next({
              ...layer.viewProps$.value,
              visibility: false,
            });
          } else {
            layer.viewProps$.next({
              ...layer.viewProps$.value,
              visibility: true,
            });
          }
        } else {
          layer.viewProps$.next({
            ...layer.viewProps$.value,
            visibility: true,
          });
        }
      });
    });
  }
}
