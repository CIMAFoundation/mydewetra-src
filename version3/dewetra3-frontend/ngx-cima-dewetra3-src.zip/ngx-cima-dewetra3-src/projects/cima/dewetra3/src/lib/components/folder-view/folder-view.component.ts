import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { LayerModel, LayerPath } from "@cima/dewetra3-core";
import { FlatTreeControl, NestedTreeControl } from "@angular/cdk/tree";
import { MatTreeFlatDataSource, MatTreeFlattener, MatTreeNestedDataSource }
  from "@angular/material/tree";

interface FolderStructure {
  id: string;
  name: string;
  descr: string;
  children: FolderStructure[];
  choices: LayerModel[];
}

@Component({
  selector: 'dewetra3-folder-view',
  templateUrl: './folder-view.component.html',
  styleUrls: ['./folder-view.component.scss']
})
export class FolderViewComponent implements OnChanges {

  @Input() layers: LayerModel[];

  paths: string[] = [];

  dataSource = new MatTreeNestedDataSource<FolderStructure>();
  treeControl = new NestedTreeControl<FolderStructure>(node => node.children);

  folderStructure: FolderStructure = {
    id: 'root', name: 'Layers', descr: 'Layers', children: [], choices: []
  };

  hasChild = (_: number, node: FolderStructure) => !!node.children && node.children.length > 0;


  buildFolderStructure() {
    this.paths = [];
    this.folderStructure.choices = [];

    this.layers.forEach((layer: LayerModel) => {
      //search the path 'simple' in layer.paths
      let layerPath = layer.paths.find((path: LayerPath) => path.path === 'simple');
      if (layerPath) {
        let pathParts = layerPath.hierarchy.split('.');
        let parent = this.folderStructure;
        pathParts.forEach((pathPart: string, index: number) => {
          let child = parent.children.find((child: any) => child.name === pathPart);
          if (!child) {
            child = {
              id: pathPart,
              name: pathPart,
              descr: pathPart,
              choices: [],
              children: []
            };
            parent.children.push(child);
          }
          parent = child;
          if (index === pathParts.length - 1 && (parent.choices.findIndex((choice: LayerModel) => choice.id === layer.id) === -1)) {
            parent.choices.push(layer);
          }
        });
      } else {
        this.folderStructure.choices.push(layer);
      }
    })
  }




  constructor() { }

  ngOnChanges(changes: SimpleChanges) {
    this.buildFolderStructure();
    this.dataSource.data = this.folderStructure.children;
    //console.log(this.folderStructure.children)
  }

}
