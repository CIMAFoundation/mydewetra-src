import { FolderView, LayerModel } from '@cima/dewetra3-core';

export interface DDSLayersResponse {
  meta: Meta;
  objects: LayerModel[];
}

export interface Meta {
  limit: number;
  next: null;
  offset: number;
  previous: null;
  total_count: number;
}

export type Category = 'event' | 'forecast' | 'observation' | 'static';

export interface Server {
  descr: string;
  id: number;
  name: string;
  url?: string;
  icon?: Icon | null;
}

export enum Icon {
  AdministrativeUnits = 'administrative_units',
  Empty = '',
  Past = 'past',
  Soilhumidity = 'soilhumidity',
  WeatherStations = 'weather_stations',
}

export interface Type {
  code: string;
  id: number;
  name: string;
}

export interface Tag {
  descr: string;
  icon: null | string;
  id: number;
  name: string;
}

export interface LayerCategory {
  category: string;
  tags: Tag[];
  folders: FolderView;
  layers: LayerModel[];
}

export interface DehydratedScenario {
  id: number;
  name: string;
  descr: string;
  aoisize: number;
  exposures: number[];
  hazards: number[];
}

export interface ScenarioLayers {
  name: string;
  descr: string;
  aoisize: number;
  exposures: LayerModel[];
  hazards: LayerModel[];
}
