import { Inject, Injectable, signal } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { CimaEnvironment } from '@cima/commons';
import { LayerHazard } from '@cima/dewetra3-core';
import { firstValueFrom, Observable } from 'rxjs';
import { CustomLayout } from '../models/layer-chooser';

export interface User {
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  emailEnabled: boolean;
  date: string;
  phoneNr: any;
  phoneEnabled: boolean;
  imgUrl: any;
  domain: string;
  color: string;
}

export interface Role {
  id: string;
  descr?: string;
  selected: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class Dewetra3Service {
  constructor(@Inject('env') private env: CimaEnvironment, private http: HttpClient) {}

  lastSelectedCategory = signal<string>('');

  themeMode = 'dark';
  layerChooserLocked = false;

  layout: CustomLayout = {
    id: 'dpc',
    name: 'Dewetra DPC',
    description: 'Layout for DPC',
    layout: {
      header: {
        hazardsFilter: true,
      },
      layerChooser: {
        hazardsFilter: false,
        zoomFilter: true,
        coverageFilter: true,
        textFilter: true,
        themesFilter: false,
        DRAFilter: false,
        hasTreeMode: false,
        hasTagMode: true,
      },
    },
  };

  getAvailableLayouts(): Observable<any> {
    return this.http.get<any>('./assets/dewetra3/layoutConfig.json');
  }

  /* ===================================
   ========= LAYER CHOOSER PANEL ========
    ====================================*/

  layerChooserMode: 'push' | 'over' = 'over';

  setLayerChooserMode(mode: 'push' | 'over') {
    this.layerChooserMode = mode;
  }

  async getUserName(): Promise<User> {
    const url = `${this.env.server.baseUrl}/acroweb_admin/users/me/`;
    return firstValueFrom(this.http.get<User>(url));
  }

  /* ===================================
  =======USER ROLES ======
  ====================================*/
  async getRoles(): Promise<Role[]> {
    const app = 'dewetra3';
    const userInfo = await this.getUserName();
    const url = `${this.env.server.baseUrl}/acroweb_admin/users/roles/?username=${userInfo.username}&app=${app}`;
    return firstValueFrom(this.http.get<Role[]>(url));
  }

  /* ===================================
  =======TOOLS DOCK / FLOAT PANEL ======
  ====================================*/

  toolsPanelMode: string = 'float';

  toolsPanelPosition: string = '';

  setPanelMode(mode: 'dock' | 'float') {
    if (mode == 'dock') {
      //remove style attribute from id 'tools-panel'
      let element = document.getElementById('tools-panel');
      if (element) {
        element.removeAttribute('style');
      }
    }
    this.toolsPanelMode = mode;
    // set panel mode in local storage
    localStorage.setItem('dewetra3_TOOLS_PANEL_panel_mode', this.toolsPanelMode);
  }

  /* ===================================
  =======HAZARDS FILTER ======
  ====================================*/
  public hazardsFilterSignal = signal<LayerHazard[]>([]);

  public updateHazardsFilter(hazards: LayerHazard[]) {
    this.hazardsFilterSignal.set([...hazards]);
  }
}
