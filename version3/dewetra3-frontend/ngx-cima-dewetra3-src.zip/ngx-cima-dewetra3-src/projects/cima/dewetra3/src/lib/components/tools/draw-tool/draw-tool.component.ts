import { CommonModule } from '@angular/common';
import {
  Component,
  computed,
  effect,
  inject,
  input,
  OnInit,
  output,
} from '@angular/core';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { TranslateService } from '@ngx-translate/core';
import L from 'leaflet';
// import 'leaflet-geoman-free'; // Import leaflet-geoman
import '@geoman-io/leaflet-geoman-free';
import '@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css';

export enum DrawType {
  NULL = 'null',
  POLYLINE = 'polyline',
  POLYGON = 'polygon',
  RECTANGLE = 'rectangle',
  CIRCLE = 'circle',
}

interface LayerEntry {
  text: string;
  layer: L.Layer;
}

interface layerClickEvent {
  layer: L.Layer;
  event: any;
}

@Component({
  selector: 'dewetra3-draw-tool',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatIcon],
  template: `
    <div class="draw-tool">
      <button class="draw-tool-button" (click)="drawPolygon()">
        <mat-icon>edit</mat-icon>
      </button>
      <button class="draw-tool-button" (click)="drawPolyline()">
        <mat-icon>timeline</mat-icon>
      </button>
      <button class="draw-tool-button" (click)="drawRectangle()">
        <mat-icon>crop_square</mat-icon>
      </button>
      <button class="draw-tool-button" (click)="drawCircle()">
        <mat-icon>panorama_fish_eye</mat-icon>
      </button>
      <button class="draw-tool-button" (click)="clearLayers()">
        <mat-icon>clear</mat-icon>
      </button>
    </div>
    <div class="draw-tool" style="height: auto;">
      <ul>
        @for (layer of drawedFeatures; track layer) {
        <li>
          <span>
            <input type="text" [(value)]="layer.text" />
            <button (click)="removeDrawedLayer(layer.layer)">Remove</button>
          </span>
        </li>
        }
      </ul>
    </div>
  `,
  styles: ``,
})
export class DrawToolComponent implements OnInit {
  private _translate = inject(TranslateService);
  private _layerGroup: L.LayerGroup = L.layerGroup();

  drawType = input<DrawType>(DrawType.NULL);
  isEnabled = input<boolean>(false);
  map = input(null);

  onDrawedFeatures = output<LayerEntry[]>();
  onDrawedFeature = output<L.Layer>();

  onLayerClick = output<layerClickEvent>();
  onLayerOvering = output<layerClickEvent>();
  onLayerOuting = output<layerClickEvent>();

  drawedFeatures: LayerEntry[] = [];

  filteredMap = computed(() => {
    const isEnabled = this.isEnabled();
    const mapInstance = this.map();
    const drawType = this.drawType();
    console.log(
      `[DRAW-TOOLBAR]isEnabled: ${isEnabled}, map: ${mapInstance}, drawType: ${drawType}`
    );

    if (isEnabled && mapInstance && drawType) {
      return mapInstance;
    }

    return null; // Ensure a safe fallback if inputs are not ready
  });

  ngOnInit(): void {}

  constructor() {
    effect(() => {
      const map = this.filteredMap();
      if (!map) {
        console.log('[DRAW-TOOLBAR]Map is not ready yet.');
        return;
      }
      console.log('[DRAW-TOOLBAR]Map is ready:', map);
      this.initializeToolbar();
      this.localizeDrawToolbar();
    });

    effect(() => {
      const drawType = this.drawType();
      if (drawType !== DrawType.NULL) {
        this.drawShape(drawType);
      }
    });
  }

  initializeToolbar() {
    const map = this.filteredMap();
    if (!map) {
      console.error(
        '[DRAW-TOOLBAR]Map is not ready for toolbar initialization.'
      );
      return;
    }
    console.log('[DRAW-TOOLBAR]Initializing toolbar for map:', map);
    map.pm.addControls({
      position: 'topleft',
      drawPolygon: false,
      drawPolyline: false,
      drawRectangle: false,
      drawCircle: false,
      editMode: false,
      dragMode: false,
      cutPolygon: false,
      removalMode: false,
      pinningOption: false,
      snappingOption: false,
      snappingLayer: false,
      snappingGuides: false,
      snappingRadius: false,
      drawMarker: false,
      rotateMode: false,
      dragCircle: false,
      drawCircleMarker: false,
      drawLineString: false,
      drawText: false,
    });
  }

  drawShape(shape: DrawType) {
    const map = this.filteredMap();
    if (!map) {
      console.error(`[DRAW-TOOLBAR]Map is not ready for drawing ${shape}.`);
      return;
    }
    this.addHandledCreated();

    switch (shape) {
      case DrawType.POLYLINE:
        map.pm.enableDraw('Line');
        break;
      case DrawType.POLYGON:
        map.pm.enableDraw('Polygon');
        break;
      case DrawType.RECTANGLE:
        map.pm.enableDraw('Rectangle');
        break;
      case DrawType.CIRCLE:
        map.pm.enableDraw('Circle');
        break;
      default:
        console.error(`[DRAW-TOOLBAR]Unknown shape type: ${shape}`);
    }
  }

  drawPolyline() {
    this.drawShape(DrawType.POLYLINE);
  }

  drawRectangle() {
    this.drawShape(DrawType.RECTANGLE);
  }

  drawCircle() {
    this.drawShape(DrawType.CIRCLE);
  }

  drawPolygon() {
    this.drawShape(DrawType.POLYGON);
  }

  localizeDrawToolbar() {
    // leaflet-geoman does not support localization out of the box
    // You may need to manually set tooltips or use a custom localization approach
  }

  addHandledCreated() {
    console.log('addHandledCreated');
    this.map().on('pm:create', (e: any) => {
      const layer = e.layer;
      this._layerGroup.addLayer(layer);
      this.manageEventOnLayer(layer);

      if (!this.drawedFeatures.some((entry) => entry.layer === layer)) {
        this.drawedFeatures.push({ text: this.drawType(), layer });
      }

      this.onDrawedFeature.emit(layer);
      this.map().pm.disableDraw();
    });
  }

  manageEventOnLayer(layer: L.Layer) {
    layer.on('click', (e: any) => {
      const layerClickEvent: layerClickEvent = { layer, event: e };
      this.onLayerClick.emit(layerClickEvent);
    });
    layer.on('mouseover', (e: any) => {
      const layerClickEvent: layerClickEvent = { layer, event: e };
      this.onLayerOvering.emit(layerClickEvent);
    });
    layer.on('mouseout', (e: any) => {
      const layerClickEvent: layerClickEvent = { layer, event: e };
      this.onLayerOuting.emit(layerClickEvent);
    });
  }

  removeHandledCreatedLayer() {
    if (this.map()) this.map().off('pm:create');
  }

  removeDrawedLayer(layer: L.Layer) {
    if (!layer) return;

    // Rimuovi il layer dalla mappa
    if (this.map() && this.map().hasLayer(layer)) {
      this.map().removeLayer(layer);
    }

    // Rimuovi dal gruppo
    this._layerGroup.removeLayer(layer);

    // Aggiorna l'array drawedFeatures
    this.drawedFeatures = this.drawedFeatures.filter(
      (entry) => entry.layer !== layer
    );
  }

  clearLayers() {
    // Pulisci sia il gruppo di layer che l'array drawedFeatures
    this._layerGroup.clearLayers();
    this.drawedFeatures = [];
    this.map().pm.disableDraw();
    this.removeHandledCreatedLayer();
  }

  ngOnDestroy(): void {
    this.clearLayers();
  }
}
