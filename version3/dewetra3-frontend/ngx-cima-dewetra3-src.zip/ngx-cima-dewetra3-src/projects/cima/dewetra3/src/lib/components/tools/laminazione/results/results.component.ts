import {Component} from '@angular/core';

@Component({
  selector: 'laminazione-results',
  standalone: true,
  imports: [],
  templateUrl: './results.component.html',
  styleUrl: './results.component.scss'
})
export class ResultsComponent {

}
