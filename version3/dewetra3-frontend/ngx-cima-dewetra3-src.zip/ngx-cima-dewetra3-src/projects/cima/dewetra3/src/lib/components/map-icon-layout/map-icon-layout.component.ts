import {Component, Input} from '@angular/core';

@Component({
  selector: 'dewetra3-map-icon-layout',
  templateUrl: './map-icon-layout.component.html',
  styleUrls: ['./map-icon-layout.component.scss']
})
export class MapIconLayoutComponent {

  @Input() mapsPerPage: string;
  @Input() mapNumber?: number;
  @Input() color?: string;

  getAltText(): string {
    if (this.mapsPerPage === '1') {
      return '1 Map';
    } else if (this.mapsPerPage === '2h') {
      return '2H Map';
    } else if (this.mapsPerPage === '2v') {
      return '2V Map';
    } else return '4 Map';
  }

  getIconPath(): string {
    const baseIconPath = 'assets/dewetra3/map-icon-layout/';
    const colorSuffix = this.color ? this.color + '-' : '';

    if (!this.mapNumber) {
      return `${baseIconPath}${colorSuffix}${this.getIconFileName()}.svg`;
    } else {
      return `${baseIconPath}${colorSuffix}s${this.mapNumber}-${this.getIconFileName()}.svg`;
    }

  }

  getIconFileName(): string {
    if (this.mapsPerPage === '1') {
      return '1m';
    } else if (this.mapsPerPage === '2h') {
      return '2mh';
    } else if (this.mapsPerPage === '2v') {
      return '2mv';
    } else return '4m';
  }

}
