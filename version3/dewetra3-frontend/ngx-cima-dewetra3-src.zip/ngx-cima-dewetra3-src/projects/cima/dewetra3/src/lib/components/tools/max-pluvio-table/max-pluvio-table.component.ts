import {Component, inject, Inject, Input, OnInit} from '@angular/core';
import {CimaCommonsModule, CimaEnvironment, PortalService} from "@cima/commons";
import {FormsModule} from "@angular/forms";
import {HttpClient} from "@angular/common/http";
import {ScrollingModule} from "@angular/cdk/scrolling";

interface Feature {
  type: string;
  properties: {
    stid: number;
    maxPluvio: {
      3600: TimelineValue;
      10800: TimelineValue;
      21600: TimelineValue;
      43200: TimelineValue;
      86400: TimelineValue;
      129600: TimelineValue;
    };
    st: string;
    nthr: number;
    e: any[]; // specifica il tipo se disponibile
    s: number;
    v: {
      t: number;
      p: number;
      v: number;
      a: "SUM" | "NONE";
    }[];
    db: number;
    mu: string;
    aggr: {
      catchments_it: string[];
      municipalities_it_topoieti: string[];
      regions_it: string[];
      municipalities_it: string[];
      warningareas_it: string[];
      districts_it: string[];
      uom_rbd_it: string[];
    };
  };
  geometry: {
    type: string;
    coordinates: [number, number]; // [lon, lat]
  };
}

interface TimelineValue {
  timeline: number;
  value: number;
}

interface TimelineWindow {
  timeline_from: number;
  timeline_to: number;
  value: number;
}

interface StationSummary {
  id: number;
  stationname: string;
  region: string[];
  province: string[];
  municipality: string[];
  zda: string[];
  h1: TimelineWindow;
  h3: TimelineWindow;
  h6: TimelineWindow;
  h12: TimelineWindow;
  h24: TimelineWindow;
  h36: TimelineWindow;
}

interface Regions {
  id: number;
  name: string;
}

@Component({
  selector: 'dewetra3-max-pluvio-table',
  standalone: true,
  imports: [
    CimaCommonsModule,
    FormsModule,
    ScrollingModule
  ],
  templateUrl: './max-pluvio-table.component.html',
  styleUrl: './max-pluvio-table.component.scss'
})
export class MaxPluvioTableComponent implements OnInit {
  constructor(@Inject('env') private env: CimaEnvironment, private portalService: PortalService) {
  }

  public maxPluvioAggrPeriods: number[] = [1, 3, 6, 12, 24, 36];
  public maxPluvioAggrPeriodsSelected: number[] = [1, 3];

  @Input() tool: any; //TODO: define the type of the tool


  allPluvioStations: any[] = [];
  searchingString: string = '';

  isLoadingMaxPluvio: boolean = false;

  selectAllOption: boolean = false;

  maxPluvioStations: any[] = [];

  showNds: boolean = true;
  showZero: boolean = true;

  regions: Regions[] = [];
  selectedRegionFilter: string = 'all'

  private _http: HttpClient = inject(HttpClient);

  ngOnInit(): void {


    this.getPluvios(null, this.portalService.userData?.currentDomain?.props?.sensors_group)

    this.getRegions()

    /*
    * https://mydewetra3-staging.cimafoundation.org/api/dewetra3/ddsapi/sentinelapi/max_pluvio/?dt=1744808682&sensor_group=Dewetra%25Default*/
  }

  getPluvios(date?: number, sensor_group?: any) {
    this.isLoadingMaxPluvio = true;
    let dt = date ? date : Math.floor(Date.now() / 1000);
    let sensorGroup = sensor_group ? sensor_group : 'Dewetra%25Default';
    this._http.get(this.env.server.baseUrl + '/dewetra3/sentinelapi/max_pluvio/?dt=' + dt + (sensorGroup ? ('&sensor_group=' + sensorGroup) : ''), {}).subscribe({
      next: (data: any) => {
        this.buildPluviomaxPluvioStations(data, dt);
        this.isLoadingMaxPluvio = false;
      },
      error: (err: any) => {
        console.error('Error loading max pluvio stations', err);
        this.isLoadingMaxPluvio = false;
      }
    })
  }

  getRegions(): void {
    this._http.get(this.env.server.baseUrl + '/dewetra3/sentinelapi/regions/', {}).subscribe({
      next: (data: any) => {
        //console.log(data);
        this.regions = data;
      },
      error: (err: any) => {
        console.error('Error loading regions', err);
      }
    })
  }

  buildPluviomaxPluvioStations(data: Feature[], date: number) {
    data.forEach((item: Feature) => {
      let station = {
        id: item.properties.stid,
        isSelected: false,
        stationname: item.properties.st,
        region: item.properties.aggr.regions_it,
        province: item.properties.aggr.districts_it,
        municipality: item.properties.aggr.municipalities_it,
        zda: item.properties.aggr.warningareas_it,
        h1: {
          timeline_from: item.properties.maxPluvio[3600].timeline,
          timeline_to: date,
          value: item.properties.maxPluvio[3600].value,
        },
        h3: {
          timeline_from: item.properties.maxPluvio[10800].timeline,
          timeline_to: date,
          value: item.properties.maxPluvio[10800].value,
        },
        h6: {
          timeline_from: item.properties.maxPluvio[21600].timeline,
          timeline_to: date,
          value: item.properties.maxPluvio[21600].value,
        },
        h12: {
          timeline_from: item.properties.maxPluvio[43200].timeline,
          timeline_to: date,
          value: item.properties.maxPluvio[43200].value,
        },
        h24: {
          timeline_from: item.properties.maxPluvio[86400].timeline,
          timeline_to: date,
          value: item.properties.maxPluvio[86400].value,
        },
        h36: {
          timeline_from: item.properties.maxPluvio[129600].timeline,
          timeline_to: date,
          value: item.properties.maxPluvio[129600].value,
        },
      }
      this.maxPluvioStations.push(station);
    })
    //this.maxPluvioStations = this.maxPluvioStations.splice(0, 25)
    this.allPluvioStations = this.maxPluvioStations;
  }


  addRemoveMaxPluvioAggrPeriods(aggr: number, event: any) {
    console.log("AddMaxPluvioAggrPeriods", aggr, event)
    if (event.checked) {
      this.maxPluvioAggrPeriodsSelected = [...this.maxPluvioAggrPeriodsSelected, aggr].sort((a, b) => a - b);
    } else {
      this.maxPluvioAggrPeriodsSelected = this.maxPluvioAggrPeriodsSelected.filter(itm => itm !== aggr);
    }
    console.log(this.maxPluvioAggrPeriodsSelected);
  }

  applyAllFilters() {
    this.maxPluvioStations = this.allPluvioStations;
    this.applyTextFilter();
    this.applyRegionFilter();
    this.applyNdsFilter()
    this.applyZeroFilter();

  }

  applyTextFilter() {
    //if searching string lenght > 3 apply filter
    if (this.searchingString.length >= 3) {
      this.maxPluvioStations = this.maxPluvioStations.filter((station) => {
        return station.stationname.toLowerCase().includes(this.searchingString.toLowerCase());
      });
    }
  }

  applyNdsFilter() {
    if (!this.showNds) {
      console.log('applico nds')
      this.maxPluvioStations = this.maxPluvioStations.filter((station) => {
        return station.h1.value >= 0;
      });
    }
  }

  applyZeroFilter() {
    if (!this.showZero) {
      console.log('applico zero')
      this.maxPluvioStations = this.maxPluvioStations.filter((station) => {
        return (station.h1.value != 0 || station.h3.value != 0 || station.h6.value != 0 || station.h12.value != 0 || station.h24.value != 0 || station.h36.value != 0);
      });
    }
  }

  applyRegionFilter() {
    console.log(this.selectedRegionFilter);
    if (this.selectedRegionFilter != 'all') {
      this.maxPluvioStations = this.maxPluvioStations.filter((station) => {
        return station.region == this.selectedRegionFilter;
      });
    }
  }


  sortDirection: string = null;
  sortedBy: string = '';

  public sortStations(property: string) {
    if (!this.sortDirection || this.sortDirection === 'desc') {
      this.sortDirection = 'asc';
      this.sortedBy = property;
      this.maxPluvioStations = [...this.maxPluvioStations].sort((a: any, b: any) => {
        if (a[property] < b[property]) return -1;
        if (a[property] > b[property]) return 1;
        return 0;
      });
    } else if (this.sortDirection === 'asc') {
      this.sortDirection = 'desc';
      this.maxPluvioStations = [...this.maxPluvioStations].sort((a: any, b: any) => {
        if (a[property] > b[property]) return -1;
        if (a[property] < b[property]) return 1;
        return 0;
      });
    }
    //this.updateFilters()
    //this.updateSelectedStation(this.selected,this.hydros);
  }

  public sortStationsValue(property: string) {
    if (!this.sortDirection || this.sortDirection === 'desc') {
      this.sortDirection = 'asc';
      this.sortedBy = property;
      this.maxPluvioStations = [...this.maxPluvioStations].sort((a: any, b: any) => {
        if (a[property].value < b[property].value) return -1;
        if (a[property].value > b[property].value) return 1;
        return 0;
      });
    } else if (this.sortDirection === 'asc') {
      this.sortDirection = 'desc';
      this.maxPluvioStations = [...this.maxPluvioStations].sort((a: any, b: any) => {
        if (a[property].value > b[property].value) return -1;
        if (a[property].value < b[property].value) return 1;
        return 0;
      });
    }
    //this.updateFilters()
    //this.updateSelectedStation(this.selected,this.hydros);
  }

  trackById(index: number, item: any): number {
    return item.id;
  }

  convertDate(epochSeconds: number): string {
    if (!epochSeconds || epochSeconds <= 0) return 'n.d.';
    const date = new Date(epochSeconds * 1000); // <-- qui la fix
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Mese da 0 a 11
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${day}/${month}/${year} ${hours}:${minutes}`;
  }


  // download csv al max pluvio
  downloadAllCSV(selection: boolean) {
    let csv = 'data:text/csv;charset=utf-8,';
    csv += 'id,stationname,region,province,municipality,zda,h1,h1 value,h3, h3 value,h6, h6 value,h12, h12 value,h24, h24 value,h36, h36 value\n';
    this.allPluvioStations.forEach((station: any) => {
      if (!selection || station.isSelected) {
        csv += station.id + ',' +
          station.stationname + ',' +
          station.region + ',' +
          station.province + ',' +
          station.municipality + ',' +
          station.zda + ',' +
          ((station.h1.timeline_from > 0) ? ('dal ' + this.convertDate(station.h1.timeline_from) + ' al ' + this.convertDate(station.h1.timeline_to)) : 'n.d.') + ',' +
          ((station.h1.value > 0) ? station.h1.value : 'n.d.') + ',' +
          ((station.h3.timeline_from > 0) ? ('dal ' + this.convertDate(station.h3.timeline_from) + ' al ' + this.convertDate(station.h3.timeline_to)) : 'n.d.') + ',' +
          ((station.h3.value > 0) ? station.h3.value : 'n.d.') + ',' +
          ((station.h6.timeline_from > 0) ? ('dal ' + this.convertDate(station.h6.timeline_from) + ' al ' + this.convertDate(station.h6.timeline_to)) : 'n.d.') + ',' +
          ((station.h6.value > 0) ? station.h6.value : 'n.d.') + ',' +
          ((station.h12.timeline_from > 0) ? ('dal ' + this.convertDate(station.h12.timeline_from) + ' al ' + this.convertDate(station.h12.timeline_to)) : 'n.d.') + ',' +
          ((station.h12.value > 0) ? station.h12.value : 'n.d.') + ',' +
          ((station.h24.timeline_from > 0) ? ('dal ' + this.convertDate(station.h24.timeline_from) + ' al ' + this.convertDate(station.h24.timeline_to)) : 'n.d.') + ',' +
          ((station.h24.value > 0) ? station.h24.value : 'n.d.') + ',' +
          ((station.h36.timeline_from > 0) ? ('dal ' + this.convertDate(station.h36.timeline_from) + ' al ' + this.convertDate(station.h36.timeline_to)) : 'n.d.') + ',' +
          ((station.h36.value > 0) ? station.h36.value : 'n.d.') + '\n';
      }
    });

    const encodedUri = encodeURI(csv);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "max_pluvio.csv");
    document.body.appendChild(link); // Required for FF
    link.click();
  }

  selectSingleStation(station: any) {
    //station.isSelected = !station.isSelected;
    const index = this.allPluvioStations.findIndex((s: any) => s.id === station.id);
    if (index > -1) {
      this.allPluvioStations[index].isSelected = station.isSelected;
    }
  }

  checkIfSelectedStation() {
    let result = false
    this.allPluvioStations.forEach((station: any) => {
      if (station.isSelected) {
        result = true
      }
    })
    return result;
  }

  selectAll(): void {
    this.maxPluvioStations.forEach((station: any) => {
      station.isSelected = this.selectAllOption;
      // find the station in allPluvioStations and set isSelected to true
      const index = this.allPluvioStations.findIndex((s: any) => s.id === station.id);
      if (index > -1) {
        this.allPluvioStations[index].isSelected = this.selectAllOption;
      }
    });
  }

  protected readonly Object: any = Object;


  protected readonly event = event;
}

