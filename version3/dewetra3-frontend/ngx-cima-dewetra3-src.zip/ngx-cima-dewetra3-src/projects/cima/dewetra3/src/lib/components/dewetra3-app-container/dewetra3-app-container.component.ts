import {AfterViewInit, Component, Inject} from '@angular/core';

import {
  APP_CONFIG,
  AppConfig,
  CimaConfigService,
  FaviconService,
  HttpLoadingSubjectService,
  PortalService
} from '@cima/commons';
import {Dewetra3ApiService} from '@cima/dewetra3-core';
import {LangChangeEvent, TranslateService} from '@ngx-translate/core';
import {Dewetra3Service} from '../../services/dewetra3.service';

@Component({
  selector: 'dewetra3-app-container',
  templateUrl: './dewetra3-app-container.component.html',
  styleUrls: ['./dewetra3-app-container.component.scss'],
})
export class Dewetra3AppContainerComponent implements AfterViewInit {
  constructor(
    @Inject(APP_CONFIG) private config: AppConfig,
    private faviconService: FaviconService,
    public portalService: PortalService,
    private configService: CimaConfigService,
    public translate: TranslateService,
    public dewetra3Service: Dewetra3Service,
    public dewetraApiService: Dewetra3ApiService,
    public httpLoadingSubjectService: HttpLoadingSubjectService
  ) {
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.portalService.getPortalLabels('mydewetra', 'dewetra3', event.lang);
    });
  }

  dewetraLoader = false
  availableLayouts: any[] = [];

  ngAfterViewInit() {

    this.httpLoadingSubjectService.isLoading.subscribe(isLoading => {
      this.dewetraLoader = isLoading;
      //console.log('Dewetra3AppContainerComponent isLoading', isLoading)
    })

    this.faviconService.setAppFavicon(this.config.name);
    //this.portalService.setTitle(this.config.description);
    this.toggleThemeMode();

    /*LANGUAGES*/
    // set lang available for the app
    this.portalService.availableLanguages = [
      {
        key: 'en',
        flag: 'gb',
        label: 'English',
        direction: 'rtl',
      },
      {
        key: 'it',
        flag: 'it',
        label: 'Italiano',
        direction: 'rtl',
      },
      {
        key: 'es',
        flag: 'es',
        label: 'Español',
        direction: 'rtl',
      },
      {
        key: 'fr',
        flag: 'fr',
        label: 'Français',
        direction: 'rtl',
      },
      {
        key: 'pt',
        flag: 'pt',
        label: 'Português',
        direction: 'rtl',
      },
    ];

    // set current lang from local storage
    this.portalService.setLangFromLocalStorage();

    this.dewetra3Service.getAvailableLayouts().subscribe((layouts) => {
      //console.log(layouts)

      this.availableLayouts = layouts;

      // et default layout
      let layoutConfName: any = null;

      // check if portal has a custom layout for app dewetra3 and if it has a layoutConfName save it
      /**
       *
       * SET THIS CONFIGURATION IN THE PORTAL CONFIG IN THE FIELD "apps_config" IN THIS WAY
       *   {
       *     "app": "dewetra3",
       *     "options": {
       *       "customLayout": "world"
       *     }
       *   }
       *
       * **/
      if (this.configService.config?.apps_config?.find((app: any) => app.app === 'dewetra3')) {
        if (this.configService.config?.apps_config?.find((app: any) => app.app === 'dewetra3').options.customLayout) {
          layoutConfName = this.configService.config.apps_config.find((app: any) => app.app === 'dewetra3').options
            .customLayout;
        }
      }

      //console.log('[DEWETRA3-SERVICE]layoutConfName after portal', layoutConfName)

      //check if domain has a custom layout for app dewetra3 and if it has a layoutConfName save it
      /**
       *
       * SET THIS CONFIGURATION IN DOMAIN IN THE FIELD props IN THIS WAY
       *   "apps_config": [
       *     {
       *     "app": "dewetra3",
       *     "options": {
       *       "customLayout": "dpc"
       *       }
       *     }
       *   ]
       *
       * **/
      this.portalService.userData$.subscribe((userData) => {

        if (userData) {
          if (userData.currentDomain?.props?.apps_config?.find((app: any) => app.app === 'dewetra3')) {
            if (userData.currentDomain?.props?.apps_config?.find((app: any) => app.app === 'dewetra3').options.customLayout) {
              layoutConfName = userData.currentDomain.props.apps_config.find((app: any) => app.app === 'dewetra3').options.customLayout
            }
          }

          //find layout in availableLayouts and set it
          if (layoutConfName && this.availableLayouts.find((layout) => layout.id === layoutConfName)) {
            this.dewetra3Service.layout = this.availableLayouts.find((layout) => layout.id === layoutConfName)
          }
        }

      })

    })

  }

  //append "dark" class to body if not already present, else remove it
  toggleThemeMode() {
    if (document.body.classList.contains('dark')) {
      document.body.classList.remove('dark');
      this.dewetra3Service.themeMode = 'light';
    } else {
      document.body.classList.add('dark');
      this.dewetra3Service.themeMode = 'dark';
    }
  }

  layerChooserViewMode: string = 'tag';
}
