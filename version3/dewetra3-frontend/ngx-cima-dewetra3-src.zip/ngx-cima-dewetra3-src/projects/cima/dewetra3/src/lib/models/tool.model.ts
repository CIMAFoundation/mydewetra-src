export interface Tool {
  id: number;
  name: string;
  descr: string;
  icon: string;
  component: string;
  props: any;
}

export interface Location {
  lat: number;
  lng: number;
}

export interface MagicSearchFeature {
  name: string;
  lon: number;
  lat: number;
  fids: string[];
  layer_id: number;
  layer_name: string;
}

export interface ResultInterface {
  address_components: AddressComponent[];
  formatted_address: string;
  geometry: GeoCoordinates;
  place_id: string;
  types: string[];
}

export interface AddressComponent {
  long_name: string;
  short_name: string;
  types: string[];
}

export interface GeoCoordinates {
  bounds: RegionBounds;
  location: Location;
  location_type: string;
  viewport: Viewport;
}

export interface RegionBounds {
  northeast: Northeast;
  southwest: Southwest;
}

export interface Northeast {
  lat: number;
  lng: number;
}

export interface Southwest {
  lat: number;
  lng: number;
}

export interface Location {
  lat: number;
  lng: number;
}

export interface Viewport {
  northeast: Northeast2;
  southwest: Southwest2;
}

export interface Northeast2 {
  lat: number;
  lng: number;
}

export interface Southwest2 {
  lat: number;
  lng: number;
}

