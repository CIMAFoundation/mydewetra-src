import { AfterViewInit, Component, OnDestroy } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { Subscription } from "rxjs";


@Component({
    selector: 'dewetra3-modal-chart-container',
    template: ``,
    styles: []
})
export class ChartModalContainerComponent implements AfterViewInit, OnDestroy {
    private eventsSubscription: Subscription;

    constructor(private matDialog: MatDialog) { }

    ngAfterViewInit(): void {
        // this.eventsSubscription = this.events$.pipe(
        //     filter(evt => evt.type === 'chart')
        // ).subscribe((evt) => {
        //     const component = evt.manager.getChartComponent();
        //     this.matDialog.open(
        //         component, {
        //         width: '95vw',
        //         height: '85vw',
        //         data: {
        //             data: evt.data,
        //             manager: evt.manager,
        //         }
        //     })
        // });
    }

    ngOnDestroy(): void {
        this.eventsSubscription.unsubscribe();
    }
}




