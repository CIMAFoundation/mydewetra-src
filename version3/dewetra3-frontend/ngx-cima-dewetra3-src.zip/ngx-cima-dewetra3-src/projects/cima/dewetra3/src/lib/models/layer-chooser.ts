
export interface CustomLayout {
  id: string;
  name: string;
  description: string;
  layout: {
    header: {
      hazardsFilter: boolean;
    },
    layerChooser: {
      hazardsFilter: boolean;
      zoomFilter: boolean;
      coverageFilter: boolean;
      textFilter: boolean;
      themesFilter: boolean;
      DRAFilter: boolean;
      hasTreeMode: boolean;
      hasTagMode: boolean;
    }
  }
}
