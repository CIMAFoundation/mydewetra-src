import {Component, EventEmitter, Output} from '@angular/core';
import {MatButton} from "@angular/material/button";
import {FormsModule} from "@angular/forms";
import {GenericParamsComponent} from "../generic-params/generic-params.component";

@Component({
  selector: 'laminazione-summary',
  standalone: true,
  imports: [
    MatButton,
    FormsModule,
    GenericParamsComponent,
  ],
  templateUrl: './summary.component.html',
  styleUrl: './summary.component.scss'
})
export class SummaryComponent {
  @Output() goToStep = new EventEmitter();


  onModeChange(mode: string | 'optimization' | 'manual') {
    if (mode === 'optimization') {
      this.goToStep.emit('run');
    }
    if (mode === 'manual') {
      this.goToStep.emit('inputActions');
    }

  }

}
