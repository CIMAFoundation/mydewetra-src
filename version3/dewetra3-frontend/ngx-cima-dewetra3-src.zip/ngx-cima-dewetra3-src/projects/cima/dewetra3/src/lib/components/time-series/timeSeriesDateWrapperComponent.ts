import { Component, Input } from '@angular/core';
import { BaseLayerManager, Dewetra3MapClick } from '@cima/dewetra3-core';
import { BehaviorSubject, take } from 'rxjs';

@Component({
    selector: 'dewetra3-time-series-date-wrapper',
    template: `
    <dewetra3-punctual-chart-wrapper [manager]="manager" [clickData]="clickData" [dateFrom]="dateFromObs$ | async" [dateTo]="dateToObs$ |async"></dewetra3-punctual-chart-wrapper>
  `
})
export class TimeSeriesDateWrapperComponent {

    @Input() manager: BaseLayerManager;
    @Input() clickData: Dewetra3MapClick;

    private dateFrom$ = new BehaviorSubject<Date | null>(null);
    @Input() set dateFrom(date: Date) {
        this.dateFrom$.next(date);
    }
    get dateFrom() {
        return this.dateFrom$.getValue();
    }

    private dateTo$ = new BehaviorSubject<Date | null>(null);
    @Input() set dateTo(date: Date) {
        this.dateTo$.next(date);
    }
    get dateTo() {
        return this.dateTo$.getValue();
    }

    dateFromObs$ = this.dateFrom$.asObservable().pipe(take(1));
    dateToObs$ = this.dateTo$.asObservable().pipe(take(1));

}
