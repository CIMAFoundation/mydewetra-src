import {Component, EventEmitter, input, Input, OnChanges, Output, SimpleChanges} from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
import {AppSidenavService} from '@cima/commons';
import {LayerModel} from '@cima/dewetra3-core';
import {Tag} from '../../models/layer';
import {DewapiService} from '../../services/dewapi.service';
import {Dewetra3Service} from '../../services/dewetra3.service';
import {LayerListService} from '../../services/layer-list.service';
import {MenuService} from '../../services/menu.service';

@Component({
  selector: 'dewetra3-layer-available',
  templateUrl: './layer-available.component.html',
  styleUrls: ['./layer-available.component.scss'],
})
export class LayerAvailableComponent implements OnChanges {
  constructor(
    private _sanitizer: DomSanitizer,
    private _appSidenavService: AppSidenavService,
    private _dewetra3Service: Dewetra3Service,
    private _layerListService: LayerListService,
    private _menuService: MenuService,
    private _dewapiService: DewapiService
  ) {
  }

  @Input() availableLayers: LayerModel[];

  @Input() category: string;

  selectedTags = input<Tag[]>(); // Signal to track the selected tags

  @Output() loadLayerModel = new EventEmitter<LayerModel>();

  orderDirection: 'asc' | 'desc' = 'asc';

  itemToDelete: number = null

  transform(html: any) {
    return this._sanitizer.bypassSecurityTrustHtml(html);
  }

  loadLayer(layer: LayerModel) {
    //if layer chooser is locked, do not close the sidenav
    if (!this._dewetra3Service.layerChooserLocked) this._appSidenavService.close();

    this.loadLayerModel.emit(layer);
    this._layerListService.updatingAnimation();
    this._layerListService.layerListOpened = true;
  }

  sortLayers(layers: LayerModel[], order: string): LayerModel[] {
    this.orderDirection = order as 'asc' | 'desc';
    return layers.sort((a: LayerModel, b: LayerModel) => {
      const comparison = a.name.localeCompare(b.name);
      return this.orderDirection === 'asc' ? comparison : -comparison;
    });
  }

  async deleteLayer(layer: LayerModel) {
    await this._menuService.deleteLayer(layer.id);
    this._dewapiService.logActivityToServer(
      `layer-deleted;name:${layer.name};dataid:${layer.dataid};category:${layer.category};`
    );
    this._dewapiService.getLayers();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['availableLayers'] && changes['availableLayers'].currentValue) {
      this.availableLayers = this.sortLayers(this.availableLayers, this.orderDirection);
    }
  }
}
