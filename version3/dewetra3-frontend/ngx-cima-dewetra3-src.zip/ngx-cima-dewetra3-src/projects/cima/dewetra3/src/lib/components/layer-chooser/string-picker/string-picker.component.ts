import {AsyncPipe} from "@angular/common";
import {Component, EventEmitter, inject, Input, Output} from '@angular/core';
import {FormControl, FormsModule, ReactiveFormsModule} from "@angular/forms";
import {MatFormField, MatFormFieldModule, MatLabel} from "@angular/material/form-field";
import {MatOption, MatSelect} from "@angular/material/select";
import {StorageService} from "@cima/commons";
import {Dewetra3ApiService, LayerModel} from '@cima/dewetra3-core';
import {TranslateModule} from "@ngx-translate/core";
import {Observable} from "rxjs";
import {filter, map, tap} from "rxjs/operators";

@Component({
  selector: 'dewetra3-string-picker',
  standalone: true,
  imports: [
    MatFormField,
    MatSelect,
    MatOption,
    FormsModule,
    ReactiveFormsModule,  // Import ReactiveFormsModule here
    MatFormFieldModule,
    TranslateModule,
    AsyncPipe,
    MatLabel
  ],
  templateUrl: './string-picker.component.html',
  styleUrl: './string-picker.component.scss'
})
export class StringPickerComponent {
  public _dewetra3ApiService = inject(Dewetra3ApiService);

  @Input() layers$: Observable<LayerModel[]> = this._dewetra3ApiService.getLayers$();
  @Input() props: string = '';
  @Input() translationPrefix: string = '';
  @Output() onSelected: EventEmitter<any> = new EventEmitter<any>();

  private _storageService = inject(StorageService);
  public formControl = new FormControl();

  public objects$: Observable<any[]> = this.layers$.pipe(
    filter((layer: any) => !!layer),
    map((layer: any) => {
      return [...new Set(layer.map((item: any) => item[this.props]))]
    }),
    map((x: any) => x.filter((s: any) => s !== null)),
  );

  ngOnInit(): void {
    this.objects$.pipe(
      map(objs => {
        const loadedHazardFromLocalStorage = JSON.parse(this._storageService.loadFromLocal('LAYER-CHOOSER_selected_' + this.props) || '[]')
        const preloadedObj = objs.filter(obj =>
          loadedHazardFromLocalStorage.some((loadedObj: any) => loadedObj === obj)
        );
        this.formControl.setValue(preloadedObj)
      })
    ).subscribe();

    this.formControl.valueChanges.pipe(
      tap((x: any) => {
        this.onSelected.emit(x);
        this._storageService.saveToLocal('LAYER-CHOOSER_selected_' + this.props, JSON.stringify(x));
      }),
    ).subscribe();
  }

}
