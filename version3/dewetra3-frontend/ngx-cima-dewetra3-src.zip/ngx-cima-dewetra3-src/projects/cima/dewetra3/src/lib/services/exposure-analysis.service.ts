import {HttpClient, HttpParams} from '@angular/common/http';
import {computed, inject, Inject, Injectable, signal} from '@angular/core';

import {CimaEnvironment} from '@cima/commons';
import {LayerWithViewProps} from '@cima/dewetra3-core';
import {firstValueFrom, Observable, Subject} from 'rxjs';
import {DehydratedScenario, ScenarioLayers} from '../models/layer';
import {DewapiService} from './dewapi.service';
import L from "leaflet";

@Injectable({
  providedIn: 'root',
})
export class ExposureAnalysisService {
  baseUrl: string;

  exposureAnalysisUrl: string

  constructor(@Inject('env') private env: CimaEnvironment, private http: HttpClient) {
    this.baseUrl = `${this.env.server.baseUrl}/dewetra3/exposure-analysis`;

    this.exposureAnalysisUrl = `${this.env.server.baseUrl}/exposure-analysis/api`;

    this.fetchScenarios().then((res) => {
      this.dehydratedScenarioTools.set(res);
    });
  }

  dewapiService = inject(DewapiService);

  selectedToolDwEdition = signal<ScenarioLayers>(undefined);
  hasScenario = signal<boolean>(false);
  dehydratedScenarioTools = signal<DehydratedScenario[]>([]);
  selectedPolygon = signal<any>(undefined);
  selectedExposureLayers = signal<Map<number, LayerWithViewProps>>(new Map());
  selectedHazardLayers = signal<Map<number, LayerWithViewProps>>(new Map());

  isDrawing = signal<boolean>(false);
  selectedPolygonLayer = signal<any>(undefined);

  map = signal<L.Map>(undefined);


  /*FEATURE SELECT FROM TABLE*/
  featureSelected: Subject<any> = new Subject();

  selectFeatureOnMap(feature: any) {
    const map = this.map();
    if (map) {

      //close all popups
      map.eachLayer((layer: any) => {
        if (layer instanceof L.Marker) {
          layer.closePopup()
        }
      });

      //open popup of selected feature
      if (feature) {
        const id = feature.properties.id;
        //const latlng = L.latLng(feature.geometry.coordinates[1], feature.geometry.coordinates[0]);
        map.eachLayer((layer: any) => {
          if (layer instanceof L.Marker) {
            if (layer.feature.properties.id == id) {
              layer.openPopup()
            }
          }
        });
      }


    }
  }

  /*FEATURE SELECT FROM MAP*/
  featureSelectedOnMap: Subject<any> = new Subject();

  selectFeatureOnMapFromMap(feature: any) {
    this.featureSelectedOnMap.next(feature);
  }


  buildedBody = computed(() => {

    let polygon = this.selectedPolygon().map((point: any) => {
      return {lat: point[1], lng: point[0]};
    });

    // add last point of polygon equal to first point
    polygon.push({lat: this.selectedPolygon()[0][1], lng: this.selectedPolygon()[0][0]});

    const hazard_zones = Array.from(this.selectedHazardLayers().values());
    const layers = Array.from(this.selectedExposureLayers().values());
    const aoisize = this.selectedToolDwEdition().aoisize;

    return {
      aoisize: aoisize,
      hazard_zones: hazard_zones.map((hazard) => hazard.layer.getLayerModel()),
      layers: layers.map((layers) => layers.layer.getLayerModel()),
      polygonFilter: polygon,
    };
  });

  get(url: string, params?: HttpParams): Observable<any> {
    if (params) {
      return this.http.get(`${this.baseUrl}${url}`, {params});
    } else {
      return this.http.get(`${this.baseUrl}${url}`);
    }
  }

  post(url: string, obj: any, params?: HttpParams, exposureBe?: boolean): Observable<any> {

    let baseUrl = `${this.baseUrl}${url}`;

    if (exposureBe) {
      baseUrl = `${this.exposureAnalysisUrl}${url}`;
    }

    if (params) {
      return this.http.post(baseUrl, obj, {params});
    } else {
      return this.http.post(baseUrl, obj);
    }
  }

  restartAnalysis() {

    this.selectedToolDwEdition.set(undefined);
    //remove polygon from map
    const map = this.map()
    if (map && this.selectedPolygonLayer()) {
      map.removeLayer(this.selectedPolygonLayer());
    }
    this.selectedPolygonLayer.set(undefined);
    this.selectedPolygon.set(undefined);
    this.selectedExposureLayers.set(new Map());
    this.selectedHazardLayers.set(new Map());
    this.isDrawing.set(false);
    this.deletePolygonLayer()
  }

  deletePolygonLayer() {
    this.selectedPolygon.set(undefined);
    const map = this.map();
    if (map && this.selectedPolygonLayer()) {
      map.removeLayer(this.selectedPolygonLayer());
      this.selectedPolygonLayer.set(null)
    }
  }

  addPolygonLayer() {
    const map = this.map();
    if (map && this.selectedPolygonLayer()) {
      const polygon = this.selectedPolygonLayer(); // L.Polygon
      polygon.addTo(map);
    }
  }

  onUploadShapefile: Subject<any> = new Subject<any>();

  /*======= API =====*/

  async fetchScenarios(): Promise<DehydratedScenario[]> {
    const scenarios = await firstValueFrom(this.get('/scenarios/'));
    return scenarios;
  }

  async fetchScenarioById(id: number): Promise<ScenarioLayers> {
    const scenario = await firstValueFrom(this.get('/scenarios/' + id + '/'));
    return scenario;
  }

  /*======= POST =====*/
  postAnalysis(body: any): Observable<any> {
    return this.post('/analysis/scenario/', body, null, true);
  }

  // postShapefileToPoly(file: any): Observable<any> {
  //   return this.post('/scenarios/utilities/shapefiletopoly/', file);
  // }

  postShapefileToPolyPromise(body: any): Promise<any> {
    return firstValueFrom(this.post('/utilities/shapefiletopoly/', body, null, true));
  }

  async postPolyToShapefilePromise(body: any): Promise<string> {
    try {
      const response: any = await firstValueFrom(
        this.http.post(
          `${this.exposureAnalysisUrl}/utilities/polytoshapefile/`,
          body,
          {responseType: 'blob', observe: 'response'}
        )
      );

      const file = new Blob([response.body], {type: 'application/zip'});
      this.createLinkForAutoDownload(file, 'zip', 'AOI');
      return 'success';
    } catch (error) {
      console.error(error);
      return 'error';
    }
  }

  // postPolyToShapefile(body: any): Observable<any> {
  //   let result = new Subject<any>();
  //   this.http
  //     .post(`${this.env.server.baseUrl}/dewetra3/exposure-analysis/scenarios/utilities/polytoshapefile/`, body, {
  //       responseType: 'blob',
  //       observe: 'response',
  //     })
  //     .subscribe(
  //       (response: any) => {
  //         // Gestisci la risposta come file blob
  //         const file = new Blob([response.body], { type: 'application/zip' });
  //         this.createLinkForAutoDownload(file, 'zip', 'AOI');
  //         result.next('success');
  //       },
  //       (error) => {
  //         console.log(error);
  //         result.next('error');
  //       }
  //     );
  //   return result;
  // }

  createLinkForAutoDownload(file: Blob, type: string, fileName?: string) {
    const fileURL = URL.createObjectURL(file);
    // Effettua il download del file utilizzando un link temporaneo
    const link = document.createElement('a');
    link.href = fileURL;
    link.download = fileName ? fileName : 'File' + (type == 'zip' ? '.zip' : '.pdf');
    link.target = '_blank';
    link.title = fileName ? fileName : 'File';
    link.click();

    /*this.pdfGenerationComplete.next(true)*/
  }
}
