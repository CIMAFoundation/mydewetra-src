import { Component, inject, Input, ViewChild } from '@angular/core';
import { FileDropComponent, SnackbarService } from '@cima/commons';
import { Dewetra3ApiService } from '@cima/dewetra3-core';
import { TranslateService } from '@ngx-translate/core';
import { forEach } from 'lodash-es';
import { concatMap, Observable } from 'rxjs';
import { Tool } from '../../../models/tool.model';

interface tool {
  accept: string;
  directory: boolean;
  label: string;
  disabled: boolean;
  multiple: boolean;
  maxSize: number;
  id: number;
  allowedExtensions: string[];
  urlToUpload: string;
}

@Component({
  selector: 'generic-uploader',
  template: `
    <cima-dialog-title [hasCloseButton]="true">
      {{ 'DEWETRA3TOOLS.' + tool.props.label | translate }}
    </cima-dialog-title>

    <cima-dialog-content>
      <cima-file-drop
        [directory]="tool.props.directory"
        [label]="tool.props.label"
        [disabled]="tool.props.disabled"
        [multiple]="false"
        [maxSize]="maxSize()"
        (outputFiles)="checkFile($event)"
      ></cima-file-drop>

      <button
        mat-raised-button
        color="primary"
        class=""
        [disabled]="!files || files?.length == 0 || uploading"
        (click)="uploadFiles(files)"
      >
        <div class="d-flex">
          <mat-spinner *ngIf="uploading" diameter="20" class="me-2"></mat-spinner>
          {{ 'DEWETRA3TOOLS.UPLOAD' | translate }}
        </div>
      </button>

      <div *ngIf="uploadProgress > 0">
        <div class="d-flex flex-column justify-content-center align-items-center py-2">
          <progress class="w-100" [value]="uploadProgress" max="100"></progress>
          <p>{{ uploadProgress }}% uploaded</p>
        </div>
      </div>
    </cima-dialog-content>
  `,
  styles: [``],
})
export class GenericUploaderComponent {
  constructor(private snackbarService: SnackbarService, private translateService: TranslateService) {}

  @Input() tool: Tool;

  @ViewChild(FileDropComponent) fileDropComponent: FileDropComponent;

  apiService: Dewetra3ApiService = inject(Dewetra3ApiService);

  chunkSize: number = 1024 * 1024;

  uploadProgress: number = 0;

  uploading: boolean = false;

  files: File[];

  checkFile(event: File[]) {
    //if event contains more than one file remove all the files except the last one
    if (event.length > 1) {
      event = [event[event.length - 1]];
      this.fileDropComponent.filesList = event;
      this.snackbarService.error(this.translateService.instant('DEWETRA3TOOLS.ONLY_ONE'), '', { duration: 5000 });
      return;
    }

    //check if the file is allowed if no  open snackbar and remove the file from the list in the cima-file-drop component
    if (
      event &&
      event.length > 0 &&
      this.tool.props.allowedExtensions &&
      this.tool.props.allowedExtensions.length > 0
    ) {
      let extension = event[0].name.split('.').pop();
      if (!this.tool.props.allowedExtensions.includes(extension)) {
        this.snackbarService.error(this.translateService.instant('DEWETRA3TOOLS.TYPE_NOT_ALLOWED'), '', {
          duration: 5000,
        });
        this.fileDropComponent.filesList = [];
        this.files = null;
        return;
      }
    }

    this.files = event;
  }

  uploadFiles(files: File[]) {
    if (!this.tool.props.urlToUpload) {
      this.snackbarService.error(this.translateService.instant('DEWETRA3TOOLS.NO_URL'), '', { duration: 5000 });
      //console.error('No url to upload')
      return;
    }
    forEach(files, (file: File) => {
      const fileId = this.generateFileId(this.tool.id.toString());

      this.uploading = true;

      this.uploadFile(file, 0, this.chunkSize, fileId, 0).subscribe({
        next: (upladedFileResult) => {
          console.log('Chunk uploaded:', upladedFileResult);
          if (upladedFileResult.file_name) {
            this.uploading = false;
            this.snackbarService.success(this.translateService.instant('DEWETRA3TOOLS.FILE_UPLOADED'), '', {
              duration: 5000,
            });
            console.log('File uploaded', upladedFileResult.file_name);
            files = files.filter((f) => f.name !== file.name); // remove the file from the list
            //TODO:
            if (files.length === 0) {
              this.snackbarService.success('All files uploaded', '', { duration: 5000 });
              console.log('All files uploaded');
              this.publishLayerToGeoserver(this.tool.id.toString(), upladedFileResult.file_name)
                .pipe(
                  concatMap((res) => {
                    console.log('Layer published to geoserver', res);
                    this.snackbarService.success(
                      this.translateService.instant('DEWETRA3TOOLS.LAYER_PUBLISHED_GEOSERVER'),
                      '',
                      { duration: 5000 }
                    );
                    return this.publishLayerToDewetra(this.tool.id.toString(), upladedFileResult.file_name);
                  })
                )
                .subscribe({
                  next: (res) => {
                    this.snackbarService.success(
                      this.translateService.instant('DEWETRA3TOOLS.LAYER_PUBLISHED_DEWETRA'),
                      '',
                      { duration: 5000 }
                    );
                    console.log('Layer published to Dewetra', res);
                  },
                  error: (err) => {
                    this.snackbarService.error(
                      this.translateService.instant('DEWETRA3TOOLS.ERROR_PUBLISHING_LAYER'),
                      '',
                      { duration: 5000 }
                    );
                    console.error('Error publishing layer:', err);
                  },
                });
            }
          }
        },
        error: (err) => {
          this.snackbarService.error(this.translateService.instant('DEWETRA3TOOLS.ERROR_UPLOADING_LAYER'), '', {
            duration: 5000,
          });
          console.error('Error uploading file:', err);
        },
        complete: () => {
          console.log('All chunks uploaded, file upload complete!');
        },
      });
    });
    /*    }*/
  }

  /**
   * Uploads a file
   * @param file File to upload
   * @param start Start byte of the chunk
   * @param chunkSize Size of the chunk
   * @param fileId Unique identifier of the file
   * @param chunkIndex Index of the chunk
   * @returns Observable<any>
   */
  uploadFile(file: File, start: number, chunkSize: number, fileId: string, chunkIndex: number): Observable<any> {
    return new Observable((observer) => {
      // Avvia il caricamento del primo chunk
      this.uploadNextChunk(file, start, chunkSize, fileId, chunkIndex).subscribe({
        next: (res) => {
          observer.next(res); // Emetti il risultato del chunk corrente
          if (res.file_name) {
            console.log('File uploaded', res.file_name); // Logga quando il file è stato completamente caricato
          }
        },
        error: (err) => {
          observer.error(err); // Gestione degli errori
        },
        complete: () => {
          observer.complete(); // Completa quando tutti i chunk sono stati caricati
        },
      });
    });
  }

  /**
   * Uploads the next chunk of a file
   * @param file File to upload
   * @param start Start byte of the chunk
   * @param chunkSize Size of the chunk
   * @param fileId Unique identifier of the file
   * @param chunkIndex Index of the chunk
   * @returns Observable<any>
   */

  uploadNextChunk(file: File, start: number, chunkSize: number, fileId: string, chunkIndex: number): Observable<any> {
    return new Observable((observer) => {
      const totalChunks = Math.ceil(file.size / chunkSize);

      const uploadChunk = (start: number, chunkIndex: number) => {
        if (start < file.size) {
          this.apiService
            .uploadChunk(this.tool.props.urlToUpload, file, start, chunkSize, fileId, chunkIndex)
            .subscribe({
              next: (res) => {
                observer.next(res);
                // **Aggiornamento della barra di caricamento**
                this.uploadProgress = Math.round((chunkIndex / totalChunks) * 100);

                uploadChunk(start + chunkSize, chunkIndex + 1);
              },
              error: (err) => {
                observer.error(err);
              },
            });
        } else {
          this.uploadProgress = 100; // Completato
          observer.complete();
        }
      };

      uploadChunk(start, chunkIndex);
    });
  }

  publishLayerToGeoserver(toolId: string, fileName: string) {
    return this.apiService.postTools('/publish-layer-to-geoserver/', { toolId, fileName });
  }

  publishLayerToDewetra(toolId: string, fileName: string) {
    return this.apiService.postTools('/publish-layer-to-dewetra/', { toolId, fileName });
  }

  generateFileId(tool_id: string): string {
    return tool_id + '_' + Math.random().toString(36).substr(2, 9);
  }

  maxSize(): number {
    return typeof this.tool.props.maxSize === 'number' ? this.tool.props.maxSize : 100 * 1024 * 1024;
  }

  // @Input() accept: string = ''
  // @Input() directory: boolean = false
  // @Input() label: string = 'Drop files here or click to upload'
  // @Input() disabled: boolean = false
  // @Input() multiple: boolean = true
  // @Input() maxSize: number = 100*1024*1024; // 100MB

  // @Output() outputFiles = new EventEmitter<any>();
}
