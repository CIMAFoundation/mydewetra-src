import {AsyncPipe, NgClass} from '@angular/common';
import {
  AfterViewInit,
  Component,
  ElementRef,
  inject,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren
} from '@angular/core';
import {MatIconButton} from '@angular/material/button';
import {MatDialog} from '@angular/material/dialog';
import {AppSidenavService, CimaCommonsModule, PortalService, TimepickerService, UserData} from '@cima/commons';
import * as L from 'leaflet';
import {CimaDewetra3Module} from '../../dewetra3.module';
import {Dewetra3Service} from '../../services/dewetra3.service';
import {Dewetra3LayerStoreService} from '../../services/layer-store.service';

@Component({
  selector: 'cima-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  standalone: true,

  imports: [NgClass, CimaDewetra3Module, AsyncPipe, MatIconButton, CimaCommonsModule],
})
export class HomeComponent implements OnInit, AfterViewInit, OnDestroy {
  constructor(private appSidenavService: AppSidenavService) {
  }

  public dewetra3Service: Dewetra3Service = inject(Dewetra3Service);

  private _timePickerService: TimepickerService = inject(TimepickerService);
  public modal: MatDialog = inject(MatDialog);
  public layerStore: Dewetra3LayerStoreService = inject(Dewetra3LayerStoreService);
  private _portalService: any = inject(PortalService);

  public nMaps$ = this.layerStore.nMaps$;
  public orientation$ = this.layerStore.orientation$;
  public layersList = this.layerStore.mapsLayers;

  public lockPan: boolean = false;

  public maxDate: Date = new Date();

  mapViewBounds: [number, number][];

  @ViewChild('toolbar') toolbar: any;

  @ViewChildren('mapWrapperComponent')
  mapWrapperComponents!: QueryList<any>;

  isSyncing = false;

  ngOnInit(): void {
    //get locked layer chooser status from local storage
    this.dewetra3Service.toolsPanelMode = localStorage.getItem('dewetra3_TOOLS_PANEL_panel_mode')
      ? localStorage.getItem('dewetra3_TOOLS_PANEL_panel_mode')
      : 'float';

    this._portalService.userData$.subscribe((userData: UserData) => {
      if (userData) {
        this.mapViewBounds = [
          [userData.currentDomain.lat1, userData.currentDomain.lon1],
          [userData.currentDomain.lat2, userData.currentDomain.lon2],
        ];
      }
    });
  }

  setLockPan() {
    this.lockPan = !this.lockPan;
    console.log(this.lockPan);
    if (this.lockPan) {
      // sync map position with the first map
      const mapWrapper = this.mapWrapperComponents.first;
      const map = mapWrapper.mapComponent?.map;
      if (!map) return;
      const currentZoom = map.getZoom();
      const currentCenter = map.getCenter();
      this.mapWrapperComponents.forEach((mapWrapper) => {
        const map = mapWrapper.mapComponent?.map;
        if (!map) return;

        const sameZoom = map.getZoom() === currentZoom;
        const sameCenter = map.getCenter().lat === currentCenter.lat && map.getCenter().lng === currentCenter.lng;

        if (!sameZoom || !sameCenter) {
          map.setView(currentCenter, currentZoom);
        }
      });
    }
  }

  onMapPositionChange(event: { center: L.LatLng; zoom: number }) {
    if (!this.lockPan || this.isSyncing) return;

    this.isSyncing = true;

    this.mapWrapperComponents.forEach((mapWrapper) => {
      const map = mapWrapper.mapComponent?.map;
      if (!map) return;

      const currentZoom = map.getZoom();
      const currentCenter = map.getCenter();

      const sameZoom = currentZoom === event.zoom;
      const sameCenter = currentCenter.lat === event.center.lat && currentCenter.lng === event.center.lng;

      if (!sameZoom || !sameCenter) {
        map.setView(event.center, event.zoom);
      }
    });

    // timeout to avoid syncing loop
    setTimeout(() => {
      this.isSyncing = false;
    }, 50);
  }

  onDateChange($event: any) {
    let time = this._timePickerService.getTimepickerValue();
    this.layerStore.setDateRange(time.from, time.to);
  }

  @ViewChild('timepicker', {read: ElementRef}) timepickerRef!: ElementRef;

  private captureListener!: (event: Event) => void;

  ngAfterViewInit() {
    const elem: HTMLElement = this.timepickerRef.nativeElement;
    this.captureListener = (event: Event) => {
      this.closeSidenav();
    };
    elem.addEventListener('click', this.captureListener, true);
  }

  ngOnDestroy() {
    // Pulizia, rimuovi il listener per evitare memory leak
    if (this.timepickerRef && this.captureListener) {
      this.timepickerRef.nativeElement.removeEventListener('click', this.captureListener, true);
    }
  }


  closeSidenav() {
    if (window.innerWidth <= 1800) {
      this.appSidenavService.close();
    }
  }
}
