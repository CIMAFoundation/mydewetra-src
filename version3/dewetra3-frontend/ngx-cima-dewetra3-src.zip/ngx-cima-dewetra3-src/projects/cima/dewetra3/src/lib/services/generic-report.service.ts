import { inject, Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

import {
  BASELAYER_OPENSTREETMAP,
  Dewetra3ApiService,
  LayerManagerFactory,
  LayerWithViewProps,
} from '@cima/dewetra3-core';
import { IMapLayout, PageOptions, ReportConfig, SerializableReportConfig } from '../models/generic-report';
import { fromSerializableReport, toSerializableReport } from '../utils/utils';
// import { MapLayout, PageOptions, ReportConfig, SerializableReportConfig } from '../models/generic-report';

const DEFAULT_REPORT_CONFIG: SerializableReportConfig = {
  title: 'Report ' + ' ' + new Date().toLocaleDateString(),
  orientation: 'portrait',
  pages: [
    {
      mapsPerPage: '1',
      lockPan: false,
      maps: [
        {
          mapTitle: null,
          showLegend: true,
          adminLimits: false,
          baseLayer: BASELAYER_OPENSTREETMAP,
          mapCaption: '',
          layers: [],
        },
      ],
      notes: [],
    },
  ],
};

@Injectable({
  providedIn: 'root',
})
export class GenericReportService {
  private _layerManagerFactory: LayerManagerFactory = inject(LayerManagerFactory);
  private _dewetra3ApiService: Dewetra3ApiService = inject(Dewetra3ApiService);

  public config: ReportConfig;

  public printing = false;

  createConfiguration() {
    this.config = fromSerializableReport(DEFAULT_REPORT_CONFIG, this._layerManagerFactory);
  }

  addPage() {
    const newPage: PageOptions = {
      mapsPerPage: '1',
      lockPan: false,

      maps: [
        {
          mapTitle: null,
          showLegend: true,
          adminLimits: false,
          baseLayer: BASELAYER_OPENSTREETMAP,
          mapCaption: '',
          layers: new BehaviorSubject([]),
        },
      ],
      notes: [],
    };

    this.config?.pages.push(newPage);

    //save to local storage
    this.saveConfigurationToLocalStorage();
  }

  removePage(page: PageOptions) {
    this.config.pages = this.config.pages.filter((p: PageOptions) => p != page);
    //save to local storage
    this.saveConfigurationToLocalStorage();
  }

  setMapsPerPage(page: PageOptions, mapsPerPage: '1' | '2h' | '2v' | '4' | string) {
    let nMaps;
    switch (mapsPerPage) {
      case '1':
        nMaps = 1;
        break;
      case '2h':
      case '2v':
        nMaps = 2;
        break;
      case '4':
        nMaps = 4;
        break;
    }
    if (nMaps > page.maps.length) {
      for (let i = page.maps.length; i < nMaps; i++) {
        page.maps.push({
          mapTitle: null,
          showLegend: true,
          adminLimits: false,
          baseLayer: BASELAYER_OPENSTREETMAP,
          mapCaption: '',
          layers: new BehaviorSubject([]),
        });
      }
    } else if (nMaps < page.maps.length) {
      page.maps = page.maps.slice(0, nMaps);
    }

    page.mapsPerPage = mapsPerPage;

    //save to local storage
    this.saveConfigurationToLocalStorage();
  }

  getConfiguration(): ReportConfig {
    if (this.config) {
      return this.config;
    }

    // check if there is a configuration in local storage
    if (localStorage.getItem('reportConfig')) {
      const answer = window.confirm('Unfinished report found. Do you want to load it?');
      if (answer) {
        this.loadConfigurationFromLocalStorage();
      }

      /*      const dialogData = new ConfirmDialogModel(
              $localize`Conferma operazione`,
              $localize`Sei sicuro di voler eseguire questa operazione?`
            );
            const dialogRef = this.dialog.open(ConfirmDialogComponent, {
              data: dialogData,
            });

            dialogRef.afterClosed().subscribe((dialogResult) => {
              if (dialogResult) {
                console.log('yes');
                this.loadConfigurationFromLocalStorage();
              } else {
                console.log('no');
                this.createConfiguration();
              }
            });*/
    }

    if (this.config == null) {
      this.createConfiguration();
    }

    return this.config;
  }

  saveConfigurationToLocalStorage() {
    const serializedConfig = toSerializableReport(this.config);
    localStorage.setItem('reportConfig', JSON.stringify(serializedConfig));
  }

  loadConfigurationFromLocalStorage() {
    const serializedConfig = localStorage.getItem('reportConfig');
    this.config = fromSerializableReport(JSON.parse(serializedConfig), this._layerManagerFactory);
  }

  hasReport(): boolean {
    return !!this.config;
  }

  clearConfig() {
    this.createConfiguration();
  }

  hasLayerOnMap(layer: LayerWithViewProps, map: IMapLayout<BehaviorSubject<LayerWithViewProps[]>>): boolean {
    return map.layers.getValue().some((l: LayerWithViewProps) => l.layer === layer.layer);
  }

  async sendToMyCloud(format: 'pdf' | 'png', title: string, description: string): Promise<void> {
    const config = toSerializableReport(this.config);

    const printEndpoint = this._dewetra3ApiService.getPostToolsUrl('/mycloud/' + format + '/');

    const body = JSON.stringify({
      timeout: 3000,
      templateData: config,
      title,
      description,
    });

    this.printing = true;

    const response = await fetch(printEndpoint, {
      method: 'POST',
      body,
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + window.localStorage.access_token,
      },
    });

    switch (response.status) {
      case 200:
        break;
      case 201:
        break;
        alert('Created');
      case 401:
        alert('Unauthorized');
        break;
      case 403:
        alert('Forbidden');
        break;
      case 404:
        alert('Not found');
        break;
      case 500:
        alert('Internal server error');
        break;
      default:
        alert('Unknown error');
    }

    this.printing = false;
  }

  async print(format: 'pdf' | 'png'): Promise<void> {
    const config = toSerializableReport(this.config);

    const printEndpoint = this._dewetra3ApiService.getPostToolsUrl('/print/' + format + '/');

    const body = JSON.stringify({
      timeout: 3000,
      templateData: config,
    });

    this.printing = true;

    const response = await fetch(printEndpoint, {
      method: 'POST',
      body,
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + window.localStorage.access_token,
      },
    });

    switch (response.status) {
      case 200:
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        // create an anchor tag and click it
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = 'report.' + format;
        anchor.click();
        break;
      case 401:
        alert('Unauthorized');
        break;
      case 403:
        alert('Forbidden');
        break;
      case 404:
        alert('Not found');
        break;
      case 500:
        alert('Internal server error');
        break;
      default:
        alert('Unknown error');
    }

    this.printing = false;
  }

  resetReport() {
    this.createConfiguration();
    localStorage.removeItem('reportConfig');
  }
}
