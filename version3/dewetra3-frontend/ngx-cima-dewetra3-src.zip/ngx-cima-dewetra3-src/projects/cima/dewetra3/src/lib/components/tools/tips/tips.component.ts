import {Component, OnInit} from '@angular/core';
import {MatDialogContent, MatDialogTitle} from "@angular/material/dialog";
import {CimaCommonsModule} from "@cima/commons";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'cima-tips',
  standalone: true,
  imports: [
    MatDialogContent,
    MatDialogTitle,
    CimaCommonsModule
  ],
  templateUrl: './tips.component.html',
  styleUrl: './tips.component.scss'
})
export class TipsComponent implements OnInit {
  constructor(private http: HttpClient) {
  }

  tips: any = []

  selectedTip: any

  ngOnInit(): void {
    this.http.get('assets/dewetra3/tipsFakeData/tips.json').subscribe((tips) => {
      console.log('TIPS', tips)
      this.tips = tips
    })
  }


}
