export type FloodCatEvents = FloodCatEvent[]

export interface FloodCatEvent {
  id: number
  domain: string
  localized: boolean
  phenomena_count: number
  damages_count: number
  code: string
  name: string
  validated: boolean
  date_of_commencement: string
  duration: string
  frequency: string
  recurrence: any
  area: string
  length: any
  other_source_of_flooding: string
  other_relevant_information: string
  summary: string
  id_trigger: string
  description: string
  orig_id: string
  creation_date: string
  deleted: boolean
  unit_of_management: number
  source_of_flooding: number
  category_of_flood: number
}


export type FloodCatEventLocations = FloodCatEventLocation[]

export interface FloodCatEventLocation {
  id: number
  geometry_centroid?: GeometryCentroid
}

export interface GeometryCentroid {
  type: string
  coordinates: number[]
}
