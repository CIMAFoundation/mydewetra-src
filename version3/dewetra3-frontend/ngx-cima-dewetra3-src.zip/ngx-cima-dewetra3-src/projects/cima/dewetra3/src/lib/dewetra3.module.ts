import {CommonModule} from '@angular/common';
import {inject, NgModule} from '@angular/core';

import {CimaCommonsModule, CimaLogService, StorageService, TimepickerService} from '@cima/commons';

import {Dewetra3RoutingModule} from './dewetra3-routing.module';

import {Dewetra3AppContainerComponent} from './components/dewetra3-app-container/dewetra3-app-container.component';

import {FormsModule} from '@angular/forms';
import {MatDialogModule} from '@angular/material/dialog';
import {DynamicModule} from 'ng-dynamic-component';
import {FolderViewComponent} from './components/folder-view/folder-view.component';
import {InfoWrapperComponent} from './components/info-wrapper/info-container.component';
import {LayerAvailableComponent} from './components/layer-available/layer-available.component';

import {LayerChooserComponent} from './components/layer-chooser/layer-chooser.component';
import {LayerListComponent} from './components/layer-list/layer-list.component';
import {LegendModalComponent} from './components/layer-list/LegendModalComponent';
import {PropertiesModalComponent} from './components/layer-list/PropertiesModalComponent';

import {TagFilterComponent} from './components/tag-filter/tag-filter.component';
import {ToolsBarComponent} from './components/tools-bar/tools-bar.component';
import {FireReportDialogComponent} from './components/tools/fire-report-dialog/fire-report-dialog.component';
import {GenericReportDialogComponent} from './components/tools/generic-report-dialog/generic-report-dialog.component';

import {ChartModalContainerComponent} from './components/chart-container/chart.component';
import {MapIconLayoutComponent} from './components/map-icon-layout/map-icon-layout.component';
import {
  GenericReportPrintTemplateComponent
} from './components/tools/generic-report-print-template/generic-report-print-template.component';
import {ReportPrintPage} from './pages/report/report-print.component';

import {MatSliderModule} from '@angular/material/slider';
import {MatTabsModule} from '@angular/material/tabs';
import {
  Dewetra3ChartsModule,
  Dewetra3InfoModule,
  Dewetra3LayerEventModule,
  Dewetra3LegendModule,
  Dewetra3MapModule,
  Dewetra3PipesModule,
  Dewetra3PropertieModule,
} from '@cima/dewetra3-core';

import {FeatureChartsModalComponent} from './components/chart-container/FeatureChartsModalComponent';
import {EventLoaderComponent} from './components/events-time-line/event-loader/event-loader.component';
import {EventsTimeLineComponent} from './components/events-time-line/events-time-line.component';
import {IconSvgComponent} from './components/icon-svg/icon-svg.component';
import {HazardsPickerComponent} from './components/layer-chooser/hazards-picker/hazards-picker.component';
import {MultiPickerComponent} from './components/layer-chooser/multi-picker/multi-picker.component';
import {StringPickerComponent} from './components/layer-chooser/string-picker/string-picker.component';
import {LayerDetailsComponent} from './components/layer-details/layer-details.component';
import {MapWrapperComponent} from './components/map-wrapper/map-wrapper.component';
import {TimeSeriesDateWrapperComponent} from './components/time-series/timeSeriesDateWrapperComponent';
import {TimeSeriesModalComponent} from './components/time-series/timeSeriesModalComponent';
import {DrawToolComponent} from './components/tools/draw-tool/draw-tool.component';
import {EaContainerComponent} from './components/tools/exposure-analisys/ea-container/ea-container.component';
import {GenericUploaderComponent} from './components/tools/generic-uploader/generic-uploader.component';
import {AddButtonComponent} from './components/tools/layer-management/add-button/add-button.component';
import {MagicSearchComponent} from './components/tools/magic-search/magic-search.component';
import {
  PluvioMonitoringChartComponent
} from './components/tools/pluvio-monitoring/pluvio-monitoring-chart/pluvio-monitoring-chart.component';
import {ToolsBarWrapperComponent} from './components/tools/tools-bar-wrapper.component';
import {DewapiService} from './services/dewapi.service';
import {GeocodeService} from './services/geocode.service';
import {ToolsBarService} from './services/tools-bar.service';
import {TranslateDataOrPipe} from "./pipes/translate-data.pipe";

const _PAGES = [ReportPrintPage];

const _MODULES = [
  Dewetra3MapModule,
  Dewetra3InfoModule,
  Dewetra3PropertieModule,
  Dewetra3ChartsModule,
  Dewetra3LegendModule,
  Dewetra3PipesModule,
  Dewetra3LayerEventModule,
  IconSvgComponent,
  EventsTimeLineComponent,
  EventLoaderComponent,
  HazardsPickerComponent,
  MultiPickerComponent,
  StringPickerComponent,
  PluvioMonitoringChartComponent,
  DrawToolComponent,
  TagFilterComponent,
  AddButtonComponent,
];

const _COMPONENTS = [
  Dewetra3AppContainerComponent,
  ToolsBarComponent,
  LayerChooserComponent,
  LayerListComponent,
  LayerAvailableComponent,

  FolderViewComponent,
  InfoWrapperComponent,
  FireReportDialogComponent,
  GenericReportDialogComponent,
  ChartModalContainerComponent,
  LegendModalComponent,
  PropertiesModalComponent,
  TimeSeriesModalComponent,
  TimeSeriesDateWrapperComponent,
  FeatureChartsModalComponent,
  ToolsBarWrapperComponent,
  GenericUploaderComponent,
  MagicSearchComponent,
  GenericReportPrintTemplateComponent,
  MapIconLayoutComponent,
  MapWrapperComponent,
];

const _PIPES: any[] = [];

@NgModule({
  declarations: [_PAGES, _COMPONENTS, _PIPES],
  imports: [
    CommonModule,
    CimaCommonsModule,
    Dewetra3RoutingModule,
    FormsModule,
    DynamicModule,
    MatDialogModule,
    MatTabsModule,
    MatSliderModule,
    ..._MODULES,
    LayerDetailsComponent,
    EaContainerComponent,
    TranslateDataOrPipe,
  ],
  exports: [_COMPONENTS],
  providers: [TimepickerService, StorageService, CimaLogService, ToolsBarService, GeocodeService],
})
export class CimaDewetra3Module {
  private _dewapiService: DewapiService = inject(DewapiService);

  constructor() {
    this._dewapiService.logActivityToServer('Dewetra3-Loaded', 'app-log');
  }
}
