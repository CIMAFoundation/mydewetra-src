import {Component, effect, input, OnDestroy} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {MatIconButton} from '@angular/material/button';
import {CimaCommonsModule, SnackbarService} from '@cima/commons';
import {ExposureAnalysisService} from '../../../../services/exposure-analysis.service';
import {DrawType} from '../../draw-tool/draw-tool.component';
import * as L from 'leaflet';
import {TranslateService} from "@ngx-translate/core";

@Component({
  selector: 'ea-area-selection',
  templateUrl: './area-selection.component.html',
  standalone: true,
  imports: [MatIconButton, CimaCommonsModule, FormsModule],
  styleUrls: ['./area-selection.component.scss'],
})
export class AreaSelectionComponent implements OnDestroy {
  constructor(public snackbarService: SnackbarService,
              private translate: TranslateService,
              public exposureAnalysisService: ExposureAnalysisService) {
    effect(() => {
      if (this.map()) {
        this.initializeToolbar();
      }
    });
  }

  map = input(null);
  public DrawType = DrawType;
  file: any;

  private initialized = false;

  // Add event listener for polygon creation
  polygonCreateHandler = (e: any) => {
    const layer = e.layer;
    //console log polygon area
    const area = (L.GeometryUtil.geodesicArea(layer.getLatLngs()[0]) / 1000000)

    //set default max area to 50km2
    let maxArea = 50000

    // override max area if set in the tool
    if (this.exposureAnalysisService.selectedToolDwEdition().aoisize) maxArea = this.exposureAnalysisService.selectedToolDwEdition().aoisize;

    this.exposureAnalysisService.selectedPolygonLayer.set(layer)
    this.exposureAnalysisService.isDrawing.set(false)

    if (area > maxArea) {
      let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.AREA_EXCEED');
      this.snackbarService.error(msg + maxArea + ' Km2 by ' + (Math.floor(area) - maxArea + 'Km2'), '', {duration: 5000});
      this.deletePolygon(false)
    } else {

      const coordinates = layer.getLatLngs()[0].map((latlng: any) => [latlng.lng, latlng.lat]);
      // Save to your exposureAnalysisService
      this.exposureAnalysisService.selectedPolygon.set(coordinates);

      let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.POLYGON_CREATED');
      this.snackbarService.success('Polygon created successfully', '', {
        duration: 3000,
      });


    }


  };

  initializeToolbar() {
    const map = this.map();
    if (!map || this.initialized) {
      return;
    }
    this.initialized = true;

    map.pm.addControls({
      position: 'topleft',
      drawPolygon: false,
      drawPolyline: false,
      drawRectangle: false,
      drawCircle: false,
      drawMarker: false,
      drawCircleMarker: false,
      cutPolygon: false,
      editMode: false,
      removalMode: false,
      dragMode: false,
      rotateMode: false,
      dragCircle: false,
      pinningOption: false,
      snappingOption: false,
      snappingLayer: false,
      snappingGuides: false,
      snappingRadius: false,
      drawLineString: false,
      drawText: false,
    });

    map.on('pm:create', this.polygonCreateHandler);
  }

  drawPolygon() {
    this.deletePolygon(false)
    const map = this.map();
    if (map && map.pm) {
      map.pm.enableDraw('Polygon');
      this.exposureAnalysisService.isDrawing.set(true)
    }
  }

  triggerInputFile() {
    //trigger click event on hidden input
    let input = document.getElementById('fileInput');
    input.click();
  }

  deletePolygon(message: boolean = true) {
    this.exposureAnalysisService.deletePolygonLayer()
    let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.POLYGON_CLEARED');
    if (message) this.snackbarService.success(msg, '', {duration: 5000});
  }

  async uploadPolygon(event: any) {
    const file = event.target.files[0];
    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await this.exposureAnalysisService.postShapefileToPolyPromise(formData);

      //if success remove old polygon
      this.exposureAnalysisService.deletePolygonLayer();

      //convert res.polygonFilter to array of latlng
      const coordinates = res.polygonFilter.map((latlng: any) => [latlng.lng, latlng.lat]);

      //set coordinates to exposureAnalysisService
      this.exposureAnalysisService.selectedPolygon.set(coordinates);

      //creo layer partendo dalle coordinate
      const polygonLayer = L.polygon(res.polygonFilter, {
        color: 'rgb(51, 136, 255)',
        fillOpacity: 0.2
      });

      this.exposureAnalysisService.selectedPolygonLayer.set(polygonLayer);

      //this.exposureAnalysisService.onUploadShapefile.next(res);
      // TODO CONTROLLARE AREA MAX

      //get area of polygon
      const latlngs: L.LatLng[] = polygonLayer.getLatLngs()[0] as L.LatLng[];
      const area = L.GeometryUtil.geodesicArea(latlngs) / 1000000;

      let maxArea = 50000

      // override max area if set in the tool
      if (this.exposureAnalysisService.selectedToolDwEdition().aoisize) maxArea = this.exposureAnalysisService.selectedToolDwEdition().aoisize;

      if (area > maxArea) {
        let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.AREA_EXCEED');
        this.snackbarService.error(msg + maxArea + ' Km2 by ' + (Math.floor(area) - maxArea + 'Km2'), '', {duration: 5000});
        this.deletePolygon(false)
      } else {
        this.exposureAnalysisService.addPolygonLayer()
        let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.FILE_UPLOADED');
        this.snackbarService.success('File uploaded', '', {duration: 5000});
        this.file = null;
        return;
      }

    } catch (error) {
      let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.ERROR_UPLOADING_FILE');
      this.snackbarService.error('Error uploading file', '', {
        duration: 5000,
      });
      this.file = null;
      event.target.value = null;
    }
  }

  async savePolygon() {
    console.log('savePolygon', this.exposureAnalysisService.selectedPolygon());
    let polygon = this.exposureAnalysisService.selectedPolygon().map((point: any) => {
      return {lat: point[1], lng: point[0]};
    });
    let body = {
      polygon: polygon,
    };

    const result = await this.exposureAnalysisService.postPolyToShapefilePromise(body);

    if (result == 'error') {
      let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.ERROR_SAVING_POLYGON');
      this.snackbarService.error(msg, '', {
        duration: 5000,
      });
    } else {
      let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.POLYGON_SAVED');
      this.snackbarService.success(msg, '', {duration: 5000});
    }
  }

  ngOnDestroy(): void {
    const map = this.map();
    if (map && map.pm) {
      map.pm.removeControls();
      map.off('pm:create', this.polygonCreateHandler);
    }
  }
}
