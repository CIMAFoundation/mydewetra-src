import {
  BaseLayerManager,
  Dewetra3MapBaseLayers,
  LayerDataContainer,
  LayerModel,
  LayerWithViewProps,
  ViewProps
} from "@cima/dewetra3-core";
import {BehaviorSubject} from "rxjs";


export interface IMapLayout<T> {
  mapTitle: string,
  showLegend: boolean,
  adminLimits: boolean,
  mapCaption: string,
  baseLayer: Dewetra3MapBaseLayers,
  mapPosition?: {
    center: L.LatLng;
    zoom: number;
  },
  layers?: T
}

export interface IPageOptions<T> {
  mapsPerPage: '1' | '2h' | '2v' | '4' | string,
  lockPan: boolean,
  maps: IMapLayout<T>[],
  notes: Note[]
}

interface Note {
  text: string;
  opacity: number;
  color: {
    r: number;
    g: number;
    b: number;
  };
  position: {
    left: number;
    top: number;
  };
  size: {
    width: number;
    height: number;
  }
}


export interface IReportConfig<T> {
  title: string,
  orientation: string,
  pages: IPageOptions<T>[],
}

export interface SerializableLayer {
  model: LayerModel;
  data: LayerDataContainer;
  view: ViewProps;
}


export type SerializableReportConfig = IReportConfig<SerializableLayer[]>;
export type PageOptions = IPageOptions<BehaviorSubject<LayerWithViewProps[]>>;
export type MapLayout = IMapLayout<BehaviorSubject<LayerWithViewProps[]>>;
export type ReportConfig = IReportConfig<BehaviorSubject<LayerWithViewProps[]>>;



