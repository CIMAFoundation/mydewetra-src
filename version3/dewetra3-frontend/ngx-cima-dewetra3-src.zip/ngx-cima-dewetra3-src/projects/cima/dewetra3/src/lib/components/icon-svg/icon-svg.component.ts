import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {DomSanitizer} from "@angular/platform-browser";
import {NgClass} from "@angular/common";

@Component({
  selector: 'dewetra3-icon-svg',
  standalone: true,
  imports: [
    NgClass
  ],
  template: `
    @if (icon && isValidSvg(icon)) {
      <div class="d-flex align-items-center" [innerHTML]="svgContent"></div>
    } @else {
      <div class="tag-icon" [ngClass]="defaultFAIconClass" [style.font-size]="size" [style.color]="color"></div>
    }`,
})
export class IconSvgComponent implements OnChanges {
  @Input() icon?: string;
  @Input() color?: string = 'grey';
  @Input() size?: string = '26px';
  @Input() defaultFAIconClass?: string = 'fa fa-question-circle';

  constructor(private sanitizer: DomSanitizer) {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['icon'] && changes['icon'].currentValue) {
      if (this.icon && this.isValidSvg(this.icon)) this.updateSvg(this.color, parseInt(this.size));
    }
  }

  svgContent: any;


  /*  ngOnInit(): void {
      if (this.icon && this.isValidSvg(this.icon)) this.updateSvg(this.color, parseInt(this.size));
    }*/

  //check if icon is valid svg
  isValidSvg(svgString: string): boolean {
    const parser = new DOMParser();
    const doc = parser.parseFromString(svgString, 'image/svg+xml');
    return doc.documentElement.nodeName === 'svg';
  }


  updateSvg(color: string, height: number) {
    let updatedSvg = this.icon;

    // Aggiorna o inserisci attributo height correttamente
    if (!updatedSvg.includes('height="')) {
      // Inserisce height nel tag <svg ...>
      updatedSvg = updatedSvg.replace(
        /<svg\b([^>]*)>/,
        `<svg$1 height="${height}px">`
      );
    } else {
      // Modifica altezza esistente
      updatedSvg = updatedSvg.replace(
        /height="[^"]*"/,
        `height="${height}px"`
      );
    }

    // Aggiorna o inserisci fill
    if (updatedSvg.includes('fill="')) {
      updatedSvg = updatedSvg.replace(
        /fill="[^"]*"/,
        `fill="${color}"`
      );
    } else {
      updatedSvg = updatedSvg.replace(
        /<svg\b/,
        `<svg fill="${color}"`
      );
    }

    // Rimuove attributo width, se presente
    updatedSvg = updatedSvg.replace(/width="[^"]*"/, '');

    // Sanifica per Angular
    this.svgContent = this.sanitizer.bypassSecurityTrustHtml(updatedSvg);
  }


}
