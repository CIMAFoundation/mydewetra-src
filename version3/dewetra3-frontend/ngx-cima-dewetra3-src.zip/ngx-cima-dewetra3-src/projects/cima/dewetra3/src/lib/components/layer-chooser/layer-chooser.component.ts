import { Component, effect, inject, Input, OnInit, Output, signal } from '@angular/core';
import { StorageService } from '@cima/commons';
import { LayerDraCategory, LayerHazard, LayerInspireTheme, LayerModel } from '@cima/dewetra3-core';
import { Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Tag } from '../../models/layer';
import { DewapiService } from '../../services/dewapi.service';
import { Dewetra3Service } from '../../services/dewetra3.service';
import { Dewetra3LayerStoreService } from '../../services/layer-store.service';

@Component({
  selector: 'dewetra3-layer-chooser',
  templateUrl: './layer-chooser.component.html',
  styleUrls: ['./layer-chooser.component.scss'],
})
export class LayerChooserComponent implements OnInit {
  @Input() category: string = '';
  @Input() viewMode: string = 'tag';
  @Output() selectedLayer: LayerModel;

  loading: boolean = false;
  selectedInspireTheme = signal<LayerInspireTheme[]>([]);
  selectedDraCategory = signal<LayerDraCategory[]>([]);
  selectedGeoscale = signal<string>('');
  selectedHazard = signal<LayerHazard[]>([]);
  selectedTags = signal<Tag[]>([]);
  filterName: string = '';
  selectedZoom: number = 0;

  private _apiService: DewapiService = inject(DewapiService);
  private _layerStore: Dewetra3LayerStoreService = inject(Dewetra3LayerStoreService);
  public dewetra3Service: Dewetra3Service = inject(Dewetra3Service);
  private _storageService: any = inject(StorageService);
  private _dewapiService: DewapiService = inject(DewapiService);

  constructor() {
    //initialize hazard filter sync
    this.initializeHazardFilterSync();
  }

  ngOnInit(): void {
    //get locked layer chooser status from local storage
    this.dewetra3Service.layerChooserLocked =
      localStorage.getItem('dewetra3_LAYER-CHOOSER_lock_layer_chooser') === 'true';
  }

  private initializeHazardFilterSync() {
    // Sync selectedHazard with hazardsFilterSignal from dewetra3Service
    effect(() => {
      const hazardFilter = this.dewetra3Service.hazardsFilterSignal();
      this.layersByCategory$ = this.updateLayerFilterIfHeaderHazardFilterChanged(hazardFilter);
      this._layerStore.filterLoadedLayersByHazard(hazardFilter);
    });
  }

  updateLayerFilterIfHeaderHazardFilterChanged(hazardFilter: LayerHazard[]): Observable<LayerModel[]> {
    return this._apiService.getLayers$().pipe(
      filter((layers) => layers.length > 0),
      map((layers) => layers.filter((layer) => layer.category === this.category)),
      map((layers) =>
        layers.filter((layer) => {
          if (hazardFilter.length > 0) {
            return hazardFilter.some((hazard) => layer.hazards.some((layerHazard) => layerHazard.id === hazard.id));
          } else {
            return true;
          }
        })
      )
    );
  }

  public layersByCategory$ = this._apiService.getLayers$().pipe(
    filter((layers) => layers.length > 0),
    map((layers) => layers.filter((layer) => layer.category === this.category))
  );

  //tags initialization
  public tags$: Observable<Tag[]> = this.layersByCategory$.pipe(
    map((x: any) => x.map((y: any) => y['tags'])),
    map((x: any) => x.flat()),
    map((x: any) => {
      return x.filter((y: any, i: any, a: any) => a.findIndex((z: any) => z.id === y.id) === i);
    })
  );

  onZoomChange(event: any) {
    this.selectedZoom = event;
  }

  reLoadData() {
    this._apiService.getLayers();
  }

  async loadLayer(layer: LayerModel) {
    this.logLayerLoad(layer);
    this._layerStore.addLayer(layer);
  }

  async logLayerLoad(layer: LayerModel) {
    const selectedCategory = this.category;
    const categorySelectedTagIds = this.extraxtIdsFromLocalStorage('TAG-FILTER_' + selectedCategory + '_selectedTags');
    const selectedDraCategories = this.extraxtIdsFromLocalStorage('LAYER-CHOOSER_selected_dracategories');
    const selectedGeoScales = this.extraxtIdsFromLocalStorage('LAYER-CHOOSER_selected_geoscale');
    const selectedHazards = this.extraxtIdsFromLocalStorage('LAYER-CHOOSER_selected_hazards');
    const selectedInspireThemes = this.extraxtIdsFromLocalStorage('LAYER-CHOOSER_selected_inspirethemes');

    const message = `layer-selected;tags:${categorySelectedTagIds};dra:${selectedDraCategories};geo:${selectedGeoScales};hazards:${selectedHazards};inspth:${selectedInspireThemes};layerid:${layer.id}`;

    await this._dewapiService.logActivityToServer(message);
  }

  extraxtIdsFromLocalStorage(key: string) {
    return JSON.parse(this._storageService.loadFromLocal(key))
      ?.map((x: any) => x.id)
      .join(',');
  }

  toggleLockLayerChooser() {
    this.dewetra3Service.layerChooserLocked = !this.dewetra3Service.layerChooserLocked;
    localStorage.setItem(
      'dewetra3_LAYER-CHOOSER_lock_layer_chooser',
      this.dewetra3Service.layerChooserLocked ? 'true' : 'false'
    );
  }

  /**
   * Preloads a layer based on the provided data ID.
   *
   * @param dataId - The unique identifier of the layer to be preloaded.
   * @returns void
   */
  preLoadLayerByDataId(dataId: string) {
    this.layersByCategory$.subscribe((data) => {
      let layer = data.filter((layer: LayerModel) => layer.dataid === dataId)[0];
      if (layer) this.loadLayer(layer);
    });
  }

  convertCatNameToTranslateString(name: string) {
    switch (name) {
      case 'observation':
        return 'DEWETRA3APP.OBSERVATIONS';
      case 'forecast':
        return 'DEWETRA3APP.FORECASTS';
      case 'static':
        return 'DEWETRA3APP.STATICS';
      default:
        return name;
    }
  }
}
