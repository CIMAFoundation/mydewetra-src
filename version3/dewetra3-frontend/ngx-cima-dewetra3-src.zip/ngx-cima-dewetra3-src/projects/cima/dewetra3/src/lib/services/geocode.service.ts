import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { filter, map, switchMap } from 'rxjs';

declare var google: any;

interface AutocompleteResponse {
  status: string;
  predictions: Array<{ description: string; place_id: string }>;
}

interface PlaceDetailsResponse {
  status: string;
  result: {
    formatted_address: string;
    geometry: { location: { lat: number; lng: number } };
  };
}

@Injectable()
export class GeocodeService {
  private API_KEY = 'AIzaSyBzb0kYgqebYOn2vVpxCNklo240SMJL5nw';

  constructor(private _traslateService: TranslateService, private _http: HttpClient) {}

  geocodeAddress(address: string) {
    const geocodeURL = `https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key=${this.API_KEY}`;
    return this._http.get(geocodeURL);
  }

  // 1) Chiedo autocomplete
  autocomplete(address: string) {
    const url =
      `https://maps.googleapis.com/maps/api/place/autocomplete/json` +
      `?input=${encodeURIComponent(address)}` +
      `&key=${this.API_KEY}`;
    return this._http.get<AutocompleteResponse>(url);
  }

  // 2) Sulla place_id prendo i dettagli (formatted_address + lat/lng)
  getDetails(placeId: string) {
    const url =
      `https://maps.googleapis.com/maps/api/place/details/json` + `?place_id=${placeId}` + `&key=${this.API_KEY}`;
    return this._http.get<PlaceDetailsResponse>(url);
  }

  // 3) Metodo “unico” che prima autocomplete, poi details
  searchAddress(address: string) {
    return this.autocomplete(address).pipe(
      filter((resp) => resp.status === 'OK' && resp.predictions.length > 0),
      map((resp) => resp.predictions[0].place_id),
      switchMap((pid) => this.getDetails(pid)),
      map((resp) => ({
        status: resp.status,
        results: resp.status === 'OK' ? [{ formatted_address: resp.result.formatted_address }] : [],
      }))
    );
  }
}
