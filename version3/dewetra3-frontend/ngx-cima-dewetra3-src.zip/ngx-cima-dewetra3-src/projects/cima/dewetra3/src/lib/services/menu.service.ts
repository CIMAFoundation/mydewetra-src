import { HttpClient } from '@angular/common/http';
import { Inject, inject, Injectable } from '@angular/core';
import { CimaEnvironment } from '@cima/commons';
import { LayerModel, WMS_CapabilitiesModel } from '@cima/dewetra3-core';
import { firstValueFrom, Observable } from 'rxjs';
import { DewapiService } from './dewapi.service';

@Injectable({
  providedIn: 'root',
})
export class MenuService {
  constructor(@Inject('env') private env: CimaEnvironment) {}

  private _http: HttpClient = inject(HttpClient);
  private dewetra3MenuApiUrl = this.env.server.baseUrl + '/dewetra3/menu';
  private _dewapiService: DewapiService = inject(DewapiService);

  get<T>(url: string, params?: any, server?: string): Observable<T> {
    if (!server) server = this.dewetra3MenuApiUrl;
    return this._http.get<T>(server + url, { params: params });
  }

  post<T>(url: string, payload?: any, server?: string): Observable<T> {
    if (!server) server = this.dewetra3MenuApiUrl;
    return this._http.post<T>(server + url, payload);
  }

  put<T>(url: string, payload: any, server?: string): Observable<T> {
    if (!server) server = this.dewetra3MenuApiUrl;
    return this._http.put<T>(server + url, payload);
  }

  delete<T>(url: string, payload?: any, server?: string): Observable<T> {
    if (!server) server = this.dewetra3MenuApiUrl;
    return this._http.delete<T>(server + url, { body: payload });
  }

  async getCapabilities(server_id: number): Promise<WMS_CapabilitiesModel> {
    let server = this.env.server.baseUrl + '/dewetra3/dewapi';
    try {
      return await firstValueFrom(
        this.get<WMS_CapabilitiesModel>('/server/' + server_id + '/capabilities', null, server)
      );
    } catch (error) {
      console.error('Error fetching capabilities:', error);
      return null;
    }
  }

  private userDataPromise: Promise<any> | null = null;

  async getUserData(): Promise<any> {
    if (this.userDataPromise) {
      return this.userDataPromise;
    }
    const url = '/layer_manager/user_data/';
    this.userDataPromise = firstValueFrom(this.get(url)).then((data) => {
      return data;
    });
    return this.userDataPromise;
  }

  async postLayerManager(payload: LayerModel, url: string = '/layer_manager/'): Promise<any> {
    payload = await this.castLayerModelToLayerToUpload(payload);
    return await firstValueFrom(this.post(url, payload));
  }

  async putLayerManager(payload: any, id: number = 0): Promise<any> {
    return await firstValueFrom(this.put('/layer_manager/' + id + '/', payload));
  }

  async check_server(url: string): Promise<any> {
    const payload = { url: url };
    return await firstValueFrom(this.post('/server_manager/check/', payload));
  }

  async getStyles(serverId: string): Promise<[]> {
    return await firstValueFrom(this.get('/style_manager/' + serverId + '/'));
  }

  async uploadStyle(serverId: string, stylePath: string): Promise<any> {
    return await firstValueFrom(this.post('/style_manager/' + serverId + '/' + stylePath + '/'));
  }

  async uploadLayer(serverId: string, layer_name: string, file_name: string, style_name: string): Promise<any> {
    const payload = {
      server_id: serverId,
      layer_name: layer_name,
      file_name: file_name,
      style_name: style_name,
    };
    return await firstValueFrom(this.post('/server_manager/publish_layer/', payload));
  }

  async deleteLayer(id: number): Promise<any> {
    return await firstValueFrom(this.delete('/layer_manager/' + id + '/'));
  }

  async castLayerModelToLayerToUpload(layer: LayerModel): Promise<any> {
    const LayerCasted = {
      name: layer.name,
      descr: layer.descr,
      icon: layer.icon,
      dataid: layer.dataid,
      lonw: layer.lonw,
      lone: layer.lone,
      lats: layer.lats,
      latn: layer.latn,
      category_id: layer.category,
      geoscale_id: layer.geoscale,
      server_id: layer.server.id ? layer.server.id : 'default',
      roles: layer.roles,
      hazard_ids: layer.hazards.map((hazard) => hazard.id),
      tag_ids: layer.tags.map((tag) => tag.id),
      inspire_theme_ids: layer.inspirethemes.map((theme) => theme.id),
      dra_category_ids: layer.dracategories.map((category) => category.id),
      path_ids: layer.paths.map((path) => path.id),
      source: layer.source,
    };
    return LayerCasted;
  }

  private allMyFeaturesPromise: Promise<any[]> | null = null;

  getAllMyFeatures$(): Promise<any[]> {
    if (this.allMyFeaturesPromise) {
      return this.allMyFeaturesPromise;
    }

    this.allMyFeaturesPromise = firstValueFrom(this.get<any[]>('/all_my_features/')).catch((err) => {
      this.allMyFeaturesPromise = null;
      throw err;
    });

    return this.allMyFeaturesPromise;
  }
}
