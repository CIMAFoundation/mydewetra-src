import {AsyncPipe} from "@angular/common";
import {Component, EventEmitter, inject, Input, Output} from '@angular/core';
import {FormControl, FormsModule, ReactiveFormsModule} from "@angular/forms";
import {MatFormField, MatFormFieldModule, MatLabel} from "@angular/material/form-field";
import {MatOption, MatSelect} from "@angular/material/select";
import {StorageService} from "@cima/commons";
import {Dewetra3ApiService, LayerModel} from '@cima/dewetra3-core';
import {TranslateModule} from "@ngx-translate/core";
import {Observable} from "rxjs";
import {map, tap} from "rxjs/operators";
import {Dewetra3Service} from "../../../services/dewetra3.service";

@Component({
  selector: 'dewetra3-multi-picker',
  standalone: true,
  imports: [
    MatFormField,
    MatSelect,
    MatOption,
    FormsModule,
    ReactiveFormsModule,  // Import ReactiveFormsModule here
    MatFormFieldModule,
    TranslateModule,
    AsyncPipe,
    MatLabel
  ],
  templateUrl: './multi-picker.component.html',
  styleUrl: './multi-picker.component.scss'
})
export class MultiPickerComponent {

  private _dewetra3ApiService = inject(Dewetra3ApiService);
  private _dewetra3Service = inject(Dewetra3Service);

  @Input() layers$: Observable<LayerModel[]> = null;
  @Input() props: string = '';
  @Input() translationPrefix: string = '';
  @Input() triggerService: boolean = false;
  @Output() onSelected: EventEmitter<any> = new EventEmitter<any>();

  private _storageService = inject(StorageService);
  public formControl = new FormControl();

  public objects$: Observable<any[]> = null

  ngOnInit(): void {

    this.objects$ = this.layers$.pipe(
      map((x: any) => x.map((y: any) => y[this.props])),
      map((x: any) => x.flat()),
      map((x: any) => {
        return x.filter((y: any, i: any, a: any) => a.findIndex((z: any) => z.id === y.id) === i)
      })
    )

    this.objects$.pipe(
      map(objs => {
        const loadedObjectsFromLocalStorage = JSON.parse(this._storageService.loadFromLocal('LAYER-CHOOSER_selected_' + this.props) || '[]')
        const preloadedObj = objs.filter(obj =>
          loadedObjectsFromLocalStorage.some((loadedObj: any) => loadedObj.id === obj.id)
        );
        this.formControl.setValue(preloadedObj)
      })
    ).subscribe();

    this.formControl.valueChanges.pipe(
      tap((selectedValue: any) => {
        this.onSelected.emit(selectedValue);
        this._storageService.saveToLocal('LAYER-CHOOSER_selected_' + this.props, JSON.stringify(selectedValue));
        if (this.props === 'hazards' && this.triggerService) this._dewetra3Service.updateHazardsFilter(selectedValue)
      }),
    ).subscribe();
  }

}
