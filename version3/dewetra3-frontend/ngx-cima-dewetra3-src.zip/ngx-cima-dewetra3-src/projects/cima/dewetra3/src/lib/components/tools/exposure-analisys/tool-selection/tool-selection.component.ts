import {NgForOf} from '@angular/common';
import {Component} from '@angular/core';
import {MatButton} from '@angular/material/button';
import {DehydratedScenario} from '../../../../models/layer';
import {ExposureAnalysisService} from '../../../../services/exposure-analysis.service';
import {TranslateModule} from "@ngx-translate/core";

@Component({
  selector: 'ea-tool-selection',
  templateUrl: './tool-selection.component.html',
  standalone: true,
  imports: [NgForOf, MatButton, TranslateModule],
  styleUrls: ['./tool-selection.component.scss'],
})
export class ToolSelectionComponent {
  constructor(public exposureAnalysisService: ExposureAnalysisService) {
  }

  async selectTool(tool: DehydratedScenario) {
    const scenarioSelected = await this.exposureAnalysisService.fetchScenarioById(tool.id);
    this.exposureAnalysisService.selectedToolDwEdition.set(scenarioSelected);
  }
}
