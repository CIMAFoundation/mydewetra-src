import {Injectable} from '@angular/core';
import {Dewetra3ApiService} from "@cima/dewetra3-core";
import {Observable, take} from "rxjs";
import {Tool} from '../models/tool.model';
import {GeocodeService} from './geocode.service';

@Injectable({
  providedIn: 'root'
})
export class ToolsBarService {

  constructor(private apiService: Dewetra3ApiService) {
  }

  loadAvailableTools(): Observable<Tool[]> {
    return this.apiService.get('/tools/');
  }

  magicSearchIsOpen = false;


}
