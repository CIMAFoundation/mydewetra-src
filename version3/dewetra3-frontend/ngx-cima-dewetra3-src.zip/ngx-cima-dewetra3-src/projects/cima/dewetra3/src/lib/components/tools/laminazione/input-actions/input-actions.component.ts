import {Component, effect, EventEmitter, input, Output, signal} from '@angular/core';
import {GenericParamsComponent} from "../generic-params/generic-params.component";
import {MatButton, MatIconButton} from "@angular/material/button";
import {MatFormField, MatHint, MatLabel, MatSuffix} from "@angular/material/form-field";
import {MatInput} from "@angular/material/input";
import {MatDatepicker, MatDatepickerInput, MatDatepickerToggle} from "@angular/material/datepicker";
import {FormsModule} from "@angular/forms";
import {MatOption, MatSelect} from "@angular/material/select";

@Component({
  selector: 'laminazione-input-actions',
  standalone: true,
  imports: [
    GenericParamsComponent,
    MatButton,
    MatFormField,
    MatInput,
    MatDatepickerInput,
    MatDatepickerToggle,
    MatDatepicker,
    FormsModule,
    MatIconButton,
    MatLabel,
    MatHint,
    MatSuffix,
    MatSelect,
    MatOption
  ],
  templateUrl: './input-actions.component.html',
  styleUrl: './input-actions.component.scss'
})
export class InputActionsComponent {
  actionsArray = input<any[]>([]);

  actions = signal(this.actionsArray());

  @Output() goToStep: EventEmitter<any> = new EventEmitter();

  now = new Date();
  hoursArray = ['00:00', '01:00', '02:00', '03:00', '04:00', '05:00', '06:00', '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'];

  constructor() {
    effect(() => {
      this.actions.set(this.actionsArray());
    }, {allowSignalWrites: true});
  }

  runSubmit() {
    this.goToStep.emit('run');
  }

  addNewAction(): void {
    this.actions.update(actions => [
      ...actions,
      {
        id: actions.length,
        dateTime: new Date(),
        value: 0
      }
    ]);
  }

  removeAction(action: { id: number }): void {
    this.actions.update(actions => actions.filter(a => a.id !== action.id));
  }


}
