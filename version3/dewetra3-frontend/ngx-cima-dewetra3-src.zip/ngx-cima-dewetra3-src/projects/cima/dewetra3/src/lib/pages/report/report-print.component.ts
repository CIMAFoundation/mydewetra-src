import { Component, inject, OnInit } from '@angular/core';
import { LayerManagerFactory } from '@cima/dewetra3-core';
import { ReportConfig, SerializableReportConfig } from '../../models/generic-report';
import { fromSerializableReport, initReportLayers } from '../../utils/utils';

@Component({
  selector: 'dewetra3-report-print',
  template: `
    <ng-container *ngIf="config">
      <dewetra3-generic-report-print-template [reportConfig]="config"></dewetra3-generic-report-print-template>
    </ng-container>
  `,
  styles: [],
})
export class ReportPrintPage implements OnInit {
  config: ReportConfig;

  private _layerManagerFactory: LayerManagerFactory = inject(LayerManagerFactory);

  ngOnInit(): void {
    //load the config from localstorage
    console.log('report print page');

    let config = JSON.parse(localStorage.getItem('reportConfig')) as SerializableReportConfig;

    if ('templateData' in window) {
      //@ts-ignore
      config = window['templateData'];
      console.log(config);
    }

    if (!config) return;

    this.config = fromSerializableReport(config, this._layerManagerFactory);
    //disabled for return to the old report print page
    //initReportLayers(this.config);
  }
}
