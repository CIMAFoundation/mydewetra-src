import {Component} from '@angular/core';
import {MatFormField, MatHint, MatLabel} from "@angular/material/form-field";
import {MatInput} from "@angular/material/input";
import {FormsModule} from "@angular/forms";

@Component({
  selector: 'laminazione-generic-params',
  standalone: true,
  imports: [
    MatFormField,
    MatInput,
    MatLabel,
    MatHint,
    FormsModule,
  ],
  templateUrl: './generic-params.component.html',
  styleUrl: './generic-params.component.scss'
})
export class GenericParamsComponent {
  francoSicurezza: number = 0;
  deltaSvaso: number = 0;
  portataTurbinata: number = 0;
  manovraAttuale: number = 0;
}
