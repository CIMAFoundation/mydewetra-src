import {DatePipe, NgIf} from "@angular/common";
import {Component, computed, inject, OnInit, output, signal} from '@angular/core';
import {MatOption} from "@angular/material/autocomplete";
import {MatFormField, MatLabel} from "@angular/material/form-field";
import {MatSelect} from "@angular/material/select";
import {TranslateModule} from "@ngx-translate/core";
import {DataTypes, Hazard} from '../../models/event';
import {DewapiService} from '../../services/dewapi.service';
import {FloodcatService} from '../../services/floodcat.service';
import {FeatureCollection} from "@turf/turf";
import {EventLoaderComponent} from "./event-loader/event-loader.component";

@Component({
  selector: 'dewetra3-events-time-line',
  standalone: true,
  imports: [
    MatFormField,
    MatLabel,
    MatOption,
    MatSelect,
    NgIf,
    TranslateModule,
    EventLoaderComponent,
    DatePipe
  ],
  templateUrl: './events-time-line.component.html',
  styleUrl: './events-time-line.component.scss'
})
export class EventsTimeLineComponent implements OnInit {
  private _floodCatService: FloodcatService = inject(FloodcatService);
  private _dewapiService: DewapiService = inject(DewapiService);

  public hazards = signal<Hazard[]>([]);
  public hazardsSelected = signal<Hazard[]>([]);
  public dataTypes = signal<DataTypes[]>([]);
  public dataTypesSelected = signal<DataTypes[]>([]);
  public events = signal(null);
  public level = signal(0);
  public selectedYear = signal(null);
  public selectedMonth = signal(null);
  public selectedDay = signal(null);
  public filteredItemEvents = signal([]);

  iconLayer = output<FeatureCollection>();

  async ngOnInit(): Promise<void> {
    try {
      const [events, hazards, dataTypes] = await Promise.all([
        this._dewapiService.getEvents(),
        this._dewapiService.getHazards(),
        this._dewapiService.getDataTypes()
      ]);
      this.hazards.set(hazards);
      this.dataTypes.set(dataTypes);
      this.events.set(events);
      this.filteredItemEvents.set(events);
    } catch (error) {
      console.error('Error loading data', error);
    }
  }

  filteredEvents = computed(() => {
    const allEvents = this.events();
    const selectedHazards = this.hazardsSelected();
    const selectedDataTypes = this.dataTypesSelected();

    if (!allEvents) return [];
    if (selectedHazards.length === 0 && selectedDataTypes.length === 0) {
      return allEvents;
    }

    const eventFiltered = allEvents.filter((event: any) => {
      const hasMatchingHazard = selectedHazards.length === 0 || selectedHazards.some(h => event.hazards.includes(h.id));
      const hasMatchingDataType = selectedDataTypes.length === 0 || selectedDataTypes.some(dt => event.datatypes.includes(dt.id));
      return hasMatchingHazard && hasMatchingDataType;
    });
    this.iconLayer.emit(this.createGeoJsonFromFilteredEvents(eventFiltered));
    return eventFiltered;
  });

  createGeoJsonFromFilteredEvents = (events: any): FeatureCollection => {
    return {
      type: 'FeatureCollection',
      features: events.map((event: any) => ({
        type: 'Feature',
        properties: {
          id: event.id,
          name: event.name,
          date: event.date,
          icon: event.icon,
          hazards: event.hazards,
          datatype: event.datatype,
          floodcatid: event.floodcatid,
          layers: event.layers
        },
        geometry: {
          type: 'Point',
          coordinates: [event.lon, event.lat]
        }
      }))
    };
  }

  yearMin = computed(() => {
    const events = this.events();
    if (!events) {
      return 0;
    }
    return Math.min(...events.map((e: any) => new Date(e.date).getFullYear()));
  });

  yearListFromYearMinWithEvents = computed(() => {
    const events = this.filteredEvents();
    if (!events) {
      return [];
    }
    const yearMin = this.yearMin();
    const yearList = Array.from({length: new Date().getFullYear() - yearMin + 1}, (_, i) => yearMin + i);

    const yearEvents = yearList.map(year => {
      const eventsByYear = events.filter((e: any) => new Date(e.date).getFullYear() === year) || [];
      return {
        year,
        events: eventsByYear
      };
    });

    return yearEvents.reverse();
  });

  eventsByMonthsAndYearSelected = computed(() => {
    const selectedYear = this.selectedYear();
    if (!selectedYear) {
      return [];
    }
    const events = selectedYear.events;
    const monthList = Array.from({length: 12}, (_, i) => i + 1);
    const monthEvents = monthList.map(month => {
      const eventsByMonth = events.filter((e: any) => new Date(e.date).getMonth() === month - 1) || [];
      return {
        month,
        events: eventsByMonth
      };
    });

    return monthEvents;
  });

  eventByDayAndMonthSelected = computed(() => {
    const selectedMonth = this.selectedMonth();
    if (!selectedMonth) {
      return [];
    }
    const events = selectedMonth.events;
    const daysInMonth = new Date(new Date().getFullYear(), new Date(selectedMonth.events[0].date).getMonth() + 1, 0).getDate();
    const dayList = Array.from({length: daysInMonth}, (_, i) => i + 1);
    const dayEvents = dayList.map(day => {
      const eventsByDay = events.filter((e: any) => new Date(e.date).getDate() === day) || [];
      return {
        day,
        events: eventsByDay
      };
    });

    return dayEvents;
  });

  createMonthDate(month: number) {
    return new Date(new Date().getFullYear(), month - 1, 1);
  }

  selectYear(year: any) {
    this.level.set(this.level() + 1);
    this.selectedYear.set(year);
    this.filteredItemEvents.set(year.events)
  }

  selectMonth(month: any) {
    this.level.set(this.level() + 1);
    this.selectedMonth.set(month);
    this.filteredItemEvents.set(month.events)
  }

  selectDay(day: any) {
    this.selectedDay.set(day);
  }

  protected readonly Math = Math;
}
