import {Component, Inject} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {CimaCommonsModule} from "@cima/commons";
import {ResultTableComponent} from "../result-table/result-table.component";

@Component({
  selector: 'ea-table-dialog',
  templateUrl: './table-dialog.component.html',
  standalone: true,
  imports: [
    CimaCommonsModule,
    ResultTableComponent
  ],
  styleUrl: './table-dialog.component.scss'
})
export class TableDialogComponent {
  constructor(public dialogRef: MatDialogRef<TableDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  /*TABLE SORTING*/
  sortingDirectionByField: { key: string; direction: string }[] = [];

  findDirectionByField(key: any) {
    if (
      this.sortingDirectionByField &&
      this.sortingDirectionByField.length > 0 &&
      this.sortingDirectionByField.find((o: any) => o.key == key)
    ) {
      return this.sortingDirectionByField.find((o: any) => o.key == key).direction;
    } else {
      return 'noSort';
    }
  }

  sortDataByKey(key: any, data: any) {
    let direction = 'asc';
    //if the key is not in the array, add it with the direction asc
    if (!this.sortingDirectionByField.find((o: any) => o.key == key)) {
      this.sortingDirectionByField.push({key: key, direction: direction});
    }
    //if the key is in the array, change the direction
    else {
      this.sortingDirectionByField.find((o: any) => o.key == key).direction =
        this.sortingDirectionByField.find((o: any) => o.key == key).direction == 'asc' ? 'desc' : 'asc';
      direction = this.sortingDirectionByField.find((o: any) => o.key == key).direction;
    }

    //convert data.sum in number
    data.forEach((result: any) => {
      if (result.sum) {
        result.sum = parseFloat(result.sum);
      }
    });

    //if direction is asc, sort the data by the key
    if (direction == 'asc') {
      data.sort((a: any, b: any) => (a[key] > b[key] ? 1 : -1));
    }
    //if direction is desc, sort the data by the key
    else {
      data.sort((a: any, b: any) => (a[key] < b[key] ? 1 : -1));
    }
  }

}
