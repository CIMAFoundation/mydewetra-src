import { HttpClient } from '@angular/common/http';
import { Inject, inject, Injectable, Signal, signal } from '@angular/core';
import { CimaEnvironment } from '@cima/commons';
import { layerCategoryModel, LayerModel } from '@cima/dewetra3-core';
import {
  DataTypes,
  DewetraTimelineEvent,
  DewetraTimelineEvents,
  Hazard,
} from 'projects/cima/dewetra3/src/lib/models/event';
import { BehaviorSubject, firstValueFrom, Observable } from 'rxjs';
import { DehydratedScenario, ScenarioLayers } from '../models/layer';

@Injectable({
  providedIn: 'root',
})
export class DewapiService {
  constructor(@Inject('env') private env: CimaEnvironment) {
    this.getLayers();
  }

  private _http: HttpClient = inject(HttpClient);
  private dewapiServerURL = this.env.server.baseUrl + '/dewetra3/dewapi';
  private layers$: BehaviorSubject<LayerModel[]> = new BehaviorSubject<LayerModel[]>([]);
  private _layersInSignal = signal<LayerModel[]>([]);

  categoriesCache = signal<layerCategoryModel[]>([]);
  geoScalesCache = signal<any[]>([]);

  get<T>(url: string, params?: any, server?: string): Observable<T> {
    if (!server) server = this.dewapiServerURL;
    return this._http.get<T>(server + url, { params: params });
  }

  post<T>(url: string, payload: any, server?: string): Observable<T> {
    if (!server) server = this.dewapiServerURL;
    return this._http.post<T>(server + url, payload);
  }

  async logActivityToServer(message: string, type: string = 'log'): Promise<void> {
    message = `${type};${message}`;
    console.log(message);
    const result = await firstValueFrom(this.post<any>('/dewetra3/commons/log/', { message }, this.env.server.baseUrl));
    if (result.status === 'error') {
      console.error('Error logging activity');
    }
    if (result.status === 'success') {
      //console.log('Activity logged');
    }
  }

  async getLayers(): Promise<void> {
    console.log('Fetching layers from Dewapi');
    const layers = await firstValueFrom(this.get<LayerModel[]>('/layers/'));
    this.layers$.next(layers as LayerModel[]);
    this._layersInSignal.set(layers as LayerModel[]);
  }

  getLayers$(): Observable<LayerModel[]> {
    return this.layers$;
  }

  getLayersInSignal(): Signal<LayerModel[]> {
    return this._layersInSignal.asReadonly();
  }

  getLayerById(id: number): LayerModel | undefined {
    return this.layers$.value.find((l) => l.id === id);
  }

  async getEvents(): Promise<DewetraTimelineEvents> {
    const events = await firstValueFrom(this.get<DewetraTimelineEvent[]>('/events/'));
    return events;
  }

  async getHazards(): Promise<Hazard[]> {
    const hazards = await firstValueFrom(this.get<Hazard[]>('/hazards/'));
    return hazards;
  }

  async getDataTypes(): Promise<DataTypes[]> {
    const dataTypes = await firstValueFrom(this.get<DataTypes[]>('/datatypes/'));
    return dataTypes;
  }

  async getLayerCategories(): Promise<layerCategoryModel[]> {
    if (this.categoriesCache().length > 0) {
      return this.categoriesCache();
    }
    const categories = await firstValueFrom(this.get<any[]>('/layercategory/'));
    return categories;
  }

  async getGeoScales(): Promise<any[]> {
    if (this.geoScalesCache().length > 0) {
      return this.geoScalesCache();
    }
    const geoscales = await firstValueFrom(this.get<any[]>('/geoscales/'));
    return geoscales;
  }

  async getHazardCategories(): Promise<any[]> {
    const hazardCategories = await firstValueFrom(this.get<any[]>('/hazards/'));
    return hazardCategories;
  }

  async getLayerTags(): Promise<any[]> {
    const tags = await firstValueFrom(this.get<any[]>('/tags/'));
    return tags;
  }

  async getLayerPaths(): Promise<any[]> {
    const paths = await firstValueFrom(this.get<any[]>('/paths/'));
    return paths;
  }

  async getTools(): Promise<any[]> {
    const tools = await firstValueFrom(this.get<any[]>('/tools/'));
    return tools;
  }

  async getIcons(): Promise<any[]> {
    const icons = await firstValueFrom(this.get<any[]>('/icons/'));
    return icons;
  }

  async getIconById(id: number): Promise<any[]> {
    const icon = await firstValueFrom(this.get<any[]>('/icons/' + id + '/'));
    return icon;
  }

  async getIconByName(name: string): Promise<any[]> {
    const icon = await firstValueFrom(this.get<any[]>('/icons/?search=' + name));
    return icon;
  }

  async getLayerInspireThemes(): Promise<any[]> {
    const inspireThemes = await firstValueFrom(this.get<any[]>('/inspirethemes/'));
    return inspireThemes;
  }

  async getTags(): Promise<any[]> {
    const tags = await firstValueFrom(this.get<any[]>('/tags/'));
    return tags;
  }

  async getLayerDraCategories(): Promise<any[]> {
    const draCategories = await firstValueFrom(this.get<any[]>('/dra_categories/'));
    return draCategories;
  }

  async fetchScenarios(): Promise<DehydratedScenario[]> {
    const scenarios = await firstValueFrom(this.get<DehydratedScenario[]>('/scenarios/'));
    return scenarios;
  }

  async fetchScenarioById(id: number): Promise<ScenarioLayers> {
    const scenario = await firstValueFrom(this.get<ScenarioLayers>('/scenarios/' + id + '/'));
    return scenario;
  }

  async proxyUrl(url: string, params: any): Promise<any> {
    const payload = { url: url, ...params };
    const result = await firstValueFrom(this.get<any>('/proxy/', payload));
    return result;
  }
}
