import { AsyncPipe } from "@angular/common";
import { Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatFormField, MatFormFieldModule, MatLabel } from "@angular/material/form-field";
import { MatOption, MatSelect } from "@angular/material/select";
import { StorageService } from "@cima/commons";
import { Dewetra3ApiService, LayerHazard, LayerModel } from '@cima/dewetra3-core';
import { TranslateModule } from "@ngx-translate/core";
import { Observable } from "rxjs";
import { map, tap } from "rxjs/operators";

@Component({
  selector: 'dewetra3-hazards-picker',
  standalone: true,
  imports: [
    MatFormField,
    MatSelect,
    MatOption,
    FormsModule,
    ReactiveFormsModule,  // Import ReactiveFormsModule here
    MatFormFieldModule,
    TranslateModule,
    AsyncPipe,
    MatLabel
  ],
  templateUrl: './hazards-picker.component.html',
  styleUrl: './hazards-picker.component.scss'
})
export class HazardsPickerComponent implements OnInit {

  public _dewetra3ApiService = inject(Dewetra3ApiService);

  @Input() layers$: Observable<LayerModel[]> = this._dewetra3ApiService.getLayers$();
  @Output() onSelectedHazard: EventEmitter<LayerHazard[]> = new EventEmitter<LayerHazard[]>();

  public selectedHazard: any;
  private _storageService = inject(StorageService);
  public hazardControl = new FormControl();
  private _props = 'hazards';

  public hazards$: Observable<LayerHazard[]> = this.layers$.pipe(
    map((x: any) => x.map((y: any) => y[this._props])),
    map((x: any) => x.flat()),
    map((x: any) => {
      return x.filter((y: any, i: any, a: any) => a.findIndex((z: any) => z.id === y.id) === i)
    })
  )

  ngOnInit(): void {
    this.hazards$.pipe(
      map(hazards => {
        const loadedHazardFromLocalStorage = JSON.parse(this._storageService.loadFromLocal('LAYER-CHOOSER_selectedHazard') || '[]')
        const preloadedHazard = hazards.filter(hazard =>
          loadedHazardFromLocalStorage.some((loadedHazard: any) => loadedHazard.id === hazard.id)
        );
        this.hazardControl.setValue(preloadedHazard)
      })
    ).subscribe();

    this.hazardControl.valueChanges.pipe(
      tap((x: any) => {
        this.onSelectedHazard.emit(x);
        this._storageService.saveToLocal('LAYER-CHOOSER_selectedHazard', JSON.stringify(x));
      }),
    ).subscribe();
  }

}
