import {CommonModule} from '@angular/common';
import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {CimaLogService, StorageService} from '@cima/commons';
import {LayerModel, LayerTag} from '@cima/dewetra3-core';
import {TranslateModule} from '@ngx-translate/core';
import isEqual from 'lodash/isEqual';
import {IconSvgComponent} from '../icon-svg/icon-svg.component';

@Component({
  selector: 'dewetra3-tag-filter',
  templateUrl: './tag-filter.component.html',
  styleUrls: ['./tag-filter.component.scss'],
  imports: [TranslateModule, IconSvgComponent, CommonModule],
  standalone: true,
})
export class TagFilterComponent implements OnInit, OnChanges {
  constructor(private _storageService: StorageService, private _logService: CimaLogService) {
  }

  @Input() Layers: LayerModel[];
  @Input() Tags: any;
  @Input() preSelectedTags: LayerTag[];
  //adding enabled input to enable/disable the component
  @Input() enabled: boolean;
  //adding loading input to show/hide the loading spinner
  @Input() loading: boolean;

  //custom class for the component
  @Input() customClass: string;

  @Input() layersType: string;
  //adding output to emit the selected tags
  @Output('selectedTagsEvent') selectedTagsEvent = new EventEmitter();

  selectedTags: LayerTag[] = [];

  selectTag = (tag: any) => {
    const index = this.selectedTags.findIndex(t => t.id === tag.id);
    if (index > -1) {
      this.selectedTags.splice(index, 1);
    } else {
      this.selectedTags.push(tag);
    }

    // Forza aggiornamento
    this.selectedTags = [...this.selectedTags];

    this.saveSelectedTags();
  };

  saveSelectedTags = () => {
    this.selectedTagsEvent.emit(this.selectedTags);
    this._storageService.saveToLocal(
      'TAG-FILTER_' + this.layersType + '_selectedTags',
      JSON.stringify(this.selectedTags)
    );
  };

  //adding a function to check if a tag is selected
  isSelectedTags = (tag: any) => {
    return this.selectedTags.map((selectedTag: any) => selectedTag.id).includes(tag.id) ? 'selected' : '';
  };

  compareByBool(item1: any, item2: any, fieldName: string) {
    return item1[fieldName] === item2[fieldName] ? 0 : item1[fieldName] ? -1 : 1;
  }

  loadPreSelectedTags = () => {
    // Check if there are pre-selected tags in local storage
    if (this.preSelectedTags && this.preSelectedTags.length > 0) {
      this.selectedTags = this.preSelectedTags;
      this.selectedTagsEvent.emit(this.selectedTags);
      this._storageService.saveToLocal(
        'TAG-FILTER_' + this.layersType + '_selectedTags',
        JSON.stringify(this.selectedTags)
      );
      return;
    }
    // If not, check if there are pre-selected tags in local storage
    // If there are, set them as the selected tags

    let preSelectedTags = JSON.parse(
      this._storageService.loadFromLocal('TAG-FILTER_' + this.layersType + '_selectedTags')
    );
    if (preSelectedTags && preSelectedTags.length > 0) {
      this.Tags?.filter((tag: any) => {
        this.selectedTagsEvent.emit(this.selectedTags);
      });
    }
  };

  ngOnInit(): void {
    this.loadPreSelectedTags();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (
      changes['Tags'] &&
      changes['Tags'].currentValue &&
      Array.isArray(changes['Tags'].currentValue) &&
      !isEqual(changes['Tags']?.currentValue, changes['Tags']?.previousValue)
    ) {
      // Se ci sono tag pre-selezionati, usali
      if (this.preSelectedTags && this.preSelectedTags.length > 0) {
        this.selectedTags = [...this.preSelectedTags];
      } else {
        // Altrimenti, seleziona il primo tag
        this.selectedTags = [changes['Tags'].currentValue[0]];
      }
      this.saveSelectedTags();
    }
  }
}
