import { AppConfig } from '@cima/commons';

export const DEWETRA3_CONFIG: AppConfig = {
  name: 'dewetra3',
  description: 'Dewetra3',
  version: "18.4.1",
};
