import {Injectable} from '@angular/core';
import {GenericUploaderComponent} from './generic-uploader/generic-uploader.component';
import {PluvioMonitoringComponent} from './pluvio-monitoring/pluvio-monitoring.component';
import {TipsComponent} from './tips/tips.component';
import {LaminazioneComponent} from "./laminazione/laminazione.component";
import {MaxPluvioTableComponent} from "./max-pluvio-table/max-pluvio-table.component";
import {ThresholdMonitorComponent} from './threshold-monitor/threshold-monitor.component';

@Injectable({
  providedIn: 'root'
})
export class ToolsBarComponentFactory {
  static DEFAULT_TOOLBAR_COMPONENTS = {
    'UploaderComponent': GenericUploaderComponent,
    'PluvioMonitoringComponent': PluvioMonitoringComponent,
    'ThresholdMonitorComponent': ThresholdMonitorComponent,
    'TipsComponent': TipsComponent,
    'MaxPluvioTableComponent': MaxPluvioTableComponent,
    'LaminazioneComponent': LaminazioneComponent
  };

  private _registry: Map<string, any> = new Map(Object.entries(ToolsBarComponentFactory.DEFAULT_TOOLBAR_COMPONENTS))


  constructor() {
  }

  set(name: string, component: any) {
    this._registry.set(name, component);
  }

  create(componentName: string): any {

    const klass = this._registry.get(componentName);

    if (!klass) {
      throw new Error(`Component for ${componentName} not found in registry`);
    }
    return klass;
  }
}

