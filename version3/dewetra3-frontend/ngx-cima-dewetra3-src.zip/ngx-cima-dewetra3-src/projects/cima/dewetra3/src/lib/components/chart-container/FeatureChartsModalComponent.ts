import { Component, inject, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialog } from "@angular/material/dialog";
import { TimepickerService } from "@cima/commons";
import { Dewetra3LayerEvent } from "@cima/dewetra3-core";


@Component({
  selector: 'feature-charts-modal',
  template: `
    <cima-dialog-title [hasCloseButton]="true">
      {{ modalData.clickData.layer.getLayerModel().name }}
    </cima-dialog-title>
    <cima-dialog-content>
      <dewetra3-series-chart-wrapper [clickData]="modalData.clickData" [dateFrom]="dateFrom"
                                     [dateTo]="dateTo"></dewetra3-series-chart-wrapper>
    </cima-dialog-content>


  `,
  styleUrls: [],
})
export class FeatureChartsModalComponent {

  public dateFrom : Date = null;
  public dateTo : Date = null;

  constructor(
    public dialogRef: MatDialog,
    @Inject(MAT_DIALOG_DATA) public modalData: { clickData: Dewetra3LayerEvent; },
    private _timePickerService: TimepickerService = inject(TimepickerService)
  ) {
    const timePickerValue = this._timePickerService.getTimepickerValue();
    this.dateTo = (timePickerValue.to === 'now') ? new Date() : new Date(timePickerValue.to);
    this.dateFrom = new Date(timePickerValue.from);
  }
}
