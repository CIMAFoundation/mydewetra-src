import {Component, inject, Inject, OnInit} from '@angular/core';
import {DewapiService} from "../../../../services/dewapi.service";
import {CimaCommonsModule} from "@cima/commons";
import {IconSvgComponent} from "../../../icon-svg/icon-svg.component";
import {Icon} from "../../../../models/layer";
import {Dewetra3Icon} from "@cima/dewetra3-core";
import {MAT_DIALOG_DATA} from "@angular/material/dialog";

@Component({
  selector: 'dewetra3-icon-chooser',
  standalone: true,
  imports: [
    CimaCommonsModule,
    IconSvgComponent
  ],
  templateUrl: './icon-chooser.component.html',
  styleUrl: './icon-chooser.component.scss'
})
export class IconChooserComponent implements OnInit {
  constructor(private dewapiService: DewapiService) {
  }

  loading = false

  readonly data = inject<any>(MAT_DIALOG_DATA);

  icons: Dewetra3Icon[]
  filteredIcons: Dewetra3Icon[]

  selectedIconName: string

  ngOnInit(): void {
    if (this.data && this.data.iconList && this.data.iconList.length > 0) {
      this.icons = this.data.iconList;
      this.filteredIcons = this.data.iconList;
    } else {
      this.getIcons()
    }
    this.setSelectedIcon(this.data?.icon)
  }

  async getIcons() {
    this.loading = true;
    try {
      this.filteredIcons = this.icons = await this.dewapiService.getIcons();
      //console.log('getIcons', this.icons);
    } catch (error) {
      console.error('Errore nel caricamento icone', error);
    } finally {
      this.loading = false;
    }
  }

  filterIcons(event: Event) {
    this.filteredIcons = this.icons;
    const filterValue = (event.target as HTMLInputElement).value.toLowerCase();
    this.filteredIcons = this.icons.filter((icon) => {
      return icon.name.toLowerCase().includes(filterValue)
    });
  }

  setSelectedIcon(icon: string) {
    //console.log('setSelectedIcon', icon);
    icon ? this.selectedIconName = icon : this.selectedIconName = '';
  }


}
