import { CommonModule } from '@angular/common';
import {
  Component,
  computed,
  effect,
  inject,
  input,
  OnInit,
  output,
  Signal,
  signal,
  WritableSignal,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { Dewetra3Icon, layerCategoryModel, LayerModel } from '@cima/dewetra3-core';
import { TranslateModule } from '@ngx-translate/core';
import { DewapiService } from '../../../../services/dewapi.service';
import { MenuService } from '../../../../services/menu.service';
import { IconSvgComponent } from '../../../icon-svg/icon-svg.component';
import { IconChooserComponent } from '../icon-chooser/icon-chooser.component';

@Component({
  selector: 'dewetra3-lm-layer-form',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatButtonModule,
    CommonModule,
    TranslateModule,
    MatIcon,
    IconSvgComponent,
  ],
  templateUrl: './layer-form.component.html',
  styleUrl: './layer-form.component.scss',
})
export class LayerFormComponent implements OnInit {
  private _menuService: MenuService = inject(MenuService);
  private _dewapiService: DewapiService = inject(DewapiService);

  onFormCompleted = output<LayerModel>(); // Signal to track if the form is selected

  layer = input<LayerModel>(null); // Input property to set the selected category
  // selectedDataID = input<string>(''); // Input property to set the selected dataId
  // selectedServer = input<LayerServer>(); // Input property to set the selected server URL
  layers: Signal<LayerModel[]> = signal<LayerModel[]>([]); // Signal to track the list of layers
  // Input property to set the selected category
  constructor(private matDialog: MatDialog) {
    this.effects(); // Call the effects method to set up reactive signals
  }

  async ngOnInit(): Promise<void> {
    // Simuliamo il caricamento dei dati utente
    //const userData = await this._menuService.getUserData();
    const categories = await this._dewapiService.getLayerCategories();
    const geoScales = await this._dewapiService.getGeoScales();
    this.categories.set(categories);
    this.geoScales.set(geoScales);
    this.layers = this._dewapiService.getLayersInSignal();
  }

  validateName(name: string): boolean {
    if (this.layers().length == 0) return false;
    const trimmedName = name.trim().toLowerCase();
    const existingLayer = this.layers().find((layer) => layer.name.trim().toLowerCase() === trimmedName);
    if (existingLayer == undefined) return false;
    return true;
  }

  // Campi stringa
  name = signal('');
  descr = signal('');
  icon = signal('');
  dataid = signal('');
  source = signal('');

  // Campi numerici
  lonw = signal(0);
  lone = signal(0);
  lats = signal(0);
  latn = signal(0);

  // Selezioni singole (simuliamo con select o radio)
  categories = signal<layerCategoryModel[]>([]); // Lista delle categorie
  geoScales = signal<any[]>([]); // Lista delle scale geografiche
  category_id = signal(null);
  geoscale_id = signal(null);
  server_id = signal(0);

  // Liste multiple
  roles = signal<string[]>([]);
  hazard_ids = signal<number[]>([]);
  tag_ids = signal<number[]>([]);
  inspire_theme_ids = signal<number[]>([]);
  dra_category_ids = signal<number[]>([]);
  path_ids = signal<number[]>([]);

  //icon cache populated by the icon chooser after first load
  iconCache: Dewetra3Icon[] = [];
  //icon preview value got from api using the icon name each time the icon changes
  iconPreviewValue: string = '';

  // Form valid?
  isValid = computed(() => {
    return (
      this.name().trim().length > 0 &&
      this.category_id() != '' &&
      this.dataid().trim().length > 0 && // Aggiungi una validità per dataid
      !isNaN(Number(this.lonw())) &&
      this.lonw() >= -180 &&
      this.lonw() <= 180 && // Controllo longitudine
      !isNaN(Number(this.lats())) &&
      this.lats() >= -90 &&
      this.lats() <= 90
    );
  });

  submit() {
    if (!this.isValid()) return;

    const layer = this.layer();

    layer.name = this.name();
    layer.descr = this.descr();
    layer.icon = this.icon();
    layer.dataid = this.dataid();
    layer.lonw = this.lonw();
    layer.lone = this.lone();
    layer.lats = this.lats();
    layer.latn = this.latn();
    layer.category = this.category_id();
    layer.geoscale = this.geoscale_id();

    this.onFormCompleted.emit(layer); // Emit the form data
    console.log('Dati inviati:', layer);
  }

  toggleInList<T>(list: WritableSignal<T[]>, value: T): void {
    const current: T[] = list();
    list.set(current.includes(value) ? current.filter((v: T) => v !== value) : [...current, value]);
  }

  getValue(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  getNumberValue(event: Event): number {
    const input = event.target as HTMLInputElement;
    return Number(input.value);
  }

  getStringValue(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  effects() {
    effect(() => {
      const geoscaleValue = this.geoscale_id();
      const categoryValue = this.category_id();
      console.log('Category:', categoryValue);
      console.log('Geoscale:', geoscaleValue);
    });

    effect(
      () => {
        const l = this.layer();
        const categories = this.categories();

        if (!l || !categories.length) return;

        console.log('LayerFormComponent initialized');
        this.dataid.set(l.dataid);

        this.getIconByName(this.icon());

        const matchedCategory = categories.find((c) => c.name === l.category);
        if (matchedCategory) {
          this.category_id.set(matchedCategory.id);
        }
      },
      { allowSignalWrites: true }
    );
  }

  openIconChooser(): void {
    const dialog = this.matDialog.open(IconChooserComponent, {
      width: '400px',
      data: {
        icon: this.icon(),
        iconList: this.iconCache,
      },
    });
    dialog.afterClosed().subscribe((result: any) => {
      if (result.selectedIcon) {
        this.icon.set(result.selectedIcon);
        this.iconCache = result.iconList;
      }
    });
  }

  async getIconByName(name: string) {
    let icons;
    if (name) {
      try {
        icons = await this._dewapiService.getIconByName(name);
        this.iconPreviewValue = icons[0].value;
      } catch (error) {
        console.error('Error fetching icon by name:', error);
      }
    }
  }
}
