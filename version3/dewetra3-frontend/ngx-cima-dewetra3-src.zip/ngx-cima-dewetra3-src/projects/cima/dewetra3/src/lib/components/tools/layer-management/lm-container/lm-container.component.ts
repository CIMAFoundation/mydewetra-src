import { NgIf } from '@angular/common';
import { Component, inject, Inject, OnInit, signal, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButton, MatIconButton } from '@angular/material/button';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatStep, MatStepLabel, MatStepper, MatStepperNext, MatStepperPrevious } from '@angular/material/stepper';
import { CimaCommonsModule, SnackbarService } from '@cima/commons';
import { Dewetra3ApiService, LayerModel, LayerServer, LayerTag } from '@cima/dewetra3-core';
import { TranslateService } from '@ngx-translate/core';
import { Tag } from '../../../../models/layer';
import { DewapiService } from '../../../../services/dewapi.service';
import { LayerService } from '../../../../services/layer.service';
import { MenuService } from '../../../../services/menu.service';
import { CheckDataidComponent } from '../check-dataid/check-dataid.component';
import { LayerDomainsComponent } from '../layer-domains/layer-domains.component';
import { LayerFormComponent } from '../layer-form/layer-form.component';
import { LayerTaggerComponent } from '../layer-tagger/layer-tagger.component';
import { ServerUrlComponent } from '../server-url/server-url.component';
import { ShapeStylerComponent } from '../shape-styler/shape-styler.component';
import { UploadLayerComponent } from '../upload-layer/upload-layer.component';

@Component({
  selector: 'cima-lm-container',
  standalone: true,
  imports: [
    MatIconButton,
    MatStepper,
    MatStep,
    MatButton,
    MatStepperPrevious,
    MatStepperNext,
    MatStepLabel,
    NgIf,
    CimaCommonsModule,
    ServerUrlComponent,
    UploadLayerComponent,
    CheckDataidComponent,
    LayerTaggerComponent,
    LayerDomainsComponent,
    LayerFormComponent,
    ShapeStylerComponent,
    FormsModule,
  ],
  templateUrl: './lm-container.component.html',
  styleUrl: './lm-container.component.scss',
})
export class LmContainerComponent implements OnInit {
  translateService: TranslateService = inject(TranslateService);
  apiService: Dewetra3ApiService = inject(Dewetra3ApiService);
  snackbarService: SnackbarService = inject(SnackbarService);
  menuService: MenuService = inject(MenuService);
  private _dewapiService: DewapiService = inject(DewapiService);
  private _layerService: LayerService = inject(LayerService);

  @ViewChild('stepper') stepper!: MatStepper;

  constructor(@Inject(MAT_DIALOG_DATA) public modalData: { userData: any; category: string; preselectedTags: Tag[] }) {}

  private _layerPresets: any = {
    name: this.translateService.instant('DEWETRA3APP.LM.LAYER_NAME'),
    descr: this.translateService.instant('DEWETRA3APP.LM.LAYER_DESCRIPTION'),
    category: '',
    server: {
      name: '',
      url: '',
    },
    hazards: [],
    geoscale: '',
    tags: [],
    inspirethemes: [],
    dracategories: [],
    paths: [],
    icon: 'default',
    dataid: '',
    thumb: '',
    lonw: 0,
    lone: 0,
    lats: 0,
    latn: 0,
    customprops: {},
  };

  public layer = signal<LayerModel>(null); // LayerModel object to be passed to the layer service

  ngOnInit(): void {
    this.is_layer_manager.set(this.modalData.userData.is_layer_manager);
    this.is_layer_manager_upload.set(this.modalData.userData.is_layer_manager_upload);
    this.is_layer_tagger.set(this.modalData.userData.is_layer_tagger);
    this.coordinated_domains.set(this.modalData.userData.coordinated_domains);
    this.preselectedTags.set(this.modalData.preselectedTags);

    this._layerPresets.category = this.modalData.category;
    this._layerPresets.tags = this.modalData.preselectedTags;

    const layer = this._layerService.generateLayerObject(this._layerPresets);

    this.layer.set(layer); // Set the layer object
  }

  is_layer_manager = signal<boolean>(false); // Signal per tracciare se l'utente è un layer manager
  is_layer_manager_upload = signal<boolean>(false); // Signal per tracciare se l'utente è un layer manager upload
  is_layer_tagger = signal<boolean>(false); // Signal per tracciare se l'utente è un layer tagger

  layer_status: string = '';
  stepIndex = signal(0); // Signal per tracciare il passo corrente
  uploadedFile = signal<File | null>(null); // Signal per tracciare il file caricato
  uploadedFileName = signal<string>(null); // Signal per tracciare il file caricato
  uploadedStyleFile = signal<File | null>(null); // Signal per tracciare il file di stile caricato
  uploadedStyleFileName = signal<string>(null); // Signal per tracciare il file di stile caricato
  styleName = signal<string>(''); // Signal per tracciare il nome dello stile

  selectedTags = signal<LayerTag[]>([]); // Signal per tracciare i tag selezionati
  preselectedTags = signal<Tag[]>([]); // Signal per tracciare i tag pre-selezionati

  selectedDomains = signal<string[]>([]); // Signal per tracciare i domini selezionati
  coordinated_domains = signal<string[]>([]); // Signal per tracciare i domini coordinati

  onFormCompleted = signal<LayerModel>(null); // Signal per tracciare se il form è completato

  layerPreset = signal<LayerModel>(null); // Signal per tracciare il preset del layer

  effects() {
    console.log('Selected Tags:', this.preselectedTags());
    const layer = this.layer();
    if (layer) {
      console.log('Layer:', layer);
    }
  }

  selectServer = (server: LayerServer) => {
    console.log('Selected server:', server);
    const layer = { ...this.layer() }; // Recreate the object to trigger signals
    layer.server = server;
    this.layer.set(layer);
  };

  selectDataID = (dataId: string) => {
    console.log('Selected dataId:', dataId);
    const layer = { ...this.layer() }; // Recreate the object to trigger signals
    layer.dataid = dataId;
    this.layer.set(layer);
  };

  selectDomains = (domains: string[]) => {
    console.log('Selected domains:', domains);
    this.selectedDomains.set(domains);
    const layer = this.layer();
    //@ts-ignore  TODO fix this
    layer.roles = domains;
    this.layer.set(layer);
  };

  selectTags = (tags: LayerTag[]) => {
    console.log('Selected tags:', tags);
    this.selectedTags.set(tags);
    const layer = this.layer();
    layer.tags = tags;
    this.layer.set(layer);
  };

  publishLayer = (fileStyleName: string) => {
    console.log('Uploaded style name:', fileStyleName);
    this.uploadedStyleFileName.set(fileStyleName);
    this.menuService
      .uploadLayer('default', this.layer().dataid, this.uploadedFileName(), this.uploadedStyleFileName())
      .then((data) => {
        this.snackbarService.success(this.translateService.instant('DEWETRA3TOOLS.LAYER_PUBLISHED'), '', {
          duration: 5000,
        });
      })
      .catch((err) => {
        this.snackbarService.error(err.error.detail, '', {});
      });
  };

  uploadConfiguration() {
    console.log('Upload configuration:', this.layer());
    const layer = this.layer();
    this.menuService
      .postLayerManager(layer)
      .then((data) => {
        this.snackbarService.success(this.translateService.instant('DEWETRA3TOOLS.LAYER_UPLOADED'), '', {
          duration: 5000,
        });
        this._dewapiService.getLayers();
        const message = `layer-added;name:${layer.name};dataid:${layer.dataid};category:${layer.category};`;
        this._dewapiService.logActivityToServer(message);
      })
      .catch((err) => {
        this.snackbarService.error(err.error.detail, '', {});
      });
  }

  nextStep() {
    this.stepper.next();
  }

  prevStep() {
    this.stepper.previous();
  }

  disableNextBtn() {
    return false;
  }

  goToStep(step: number) {
    this.stepIndex.set(step);
  }

  completa() {
    // logica finale
    console.log('Completato!');
  }
}
