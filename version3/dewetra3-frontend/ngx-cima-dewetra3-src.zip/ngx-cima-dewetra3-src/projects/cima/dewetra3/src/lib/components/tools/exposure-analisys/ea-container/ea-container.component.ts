import {NgIf} from '@angular/common';
import {Component, effect, inject, input, InputSignal, ViewChild} from '@angular/core';
import {MatButton, MatIconButton} from '@angular/material/button';
import {
  MatStep,
  MatStepLabel,
  MatStepper,
  MatStepperNext,
  MatStepperPrevious,
} from '@angular/material/stepper';
import {CimaCommonsModule} from '@cima/commons';
import {ExposureAnalysisService} from '../../../../services/exposure-analysis.service';
import {AnalysisResultComponent} from '../analysis-result/analysis-result.component';
import {AreaSelectionComponent} from '../area-selection/area-selection.component';
import {ExposuresSelectionComponent} from '../exposures-selection/exposures-selection.component';
import {HazardSelectionComponent} from '../hazard-selection/hazard-selection.component';
import {ToolSelectionComponent} from '../tool-selection/tool-selection.component';
import L from "leaflet";
import {Dewetra3LayerStoreService} from "../../../../services/layer-store.service";
import {TranslateService} from "@ngx-translate/core";

@Component({
  selector: 'cima-ea-container',
  standalone: true,
  imports: [
    MatIconButton,
    MatStepper,
    MatStep,
    MatButton,
    MatStepperPrevious,
    MatStepperNext,
    MatStepLabel,
    NgIf,
    AnalysisResultComponent,
    AreaSelectionComponent,
    HazardSelectionComponent,
    ExposuresSelectionComponent,
    ToolSelectionComponent,
    CimaCommonsModule,
  ],
  templateUrl: './ea-container.component.html',
  styleUrl: './ea-container.component.scss',
})
export class EaContainerComponent {
  public exposureAnalysisService = inject(ExposureAnalysisService);
  map: InputSignal<any> = input(null);

  constructor(private translate: TranslateService) {
    effect(() => {
      const currentMap = this.map();
      this.exposureAnalysisService.map.set(currentMap);
    }, {allowSignalWrites: true});
  }

  eaFeatureOnMap = L.layerGroup();

  private _layerStore: Dewetra3LayerStoreService = inject(Dewetra3LayerStoreService);

  @ViewChild('exposureSelection') exposureSelection: ExposuresSelectionComponent;

  restartAnalysis() {
    //  remove exposure layers from the map
    this.exposureAnalysisService.selectedExposureLayers().forEach((layer) => {
      this._layerStore.removeLayer(layer);
    });

    // remove hazard layers from the map
    this.exposureAnalysisService.selectedHazardLayers().forEach((layer) => {
      this._layerStore.removeLayer(layer);
    });

    this.eaFeatureOnMap.clearLayers()

    this.exposureAnalysisService.restartAnalysis()
  }

  onGetResult(res: any) {
    // create new layer group

    // add layer group to the map if not already present
    if (!this.map().hasLayer(this.eaFeatureOnMap)) {
      this.map().addLayer(this.eaFeatureOnMap);
    } else {
      //remove all layers from the layer group
      this.eaFeatureOnMap.clearLayers()
    }

    res.forEach((result: any) => {
      if (result.output !== 'impact_sum') {
        // for each feature in result fetaures
        this.addFeatureGroupToMap(result);
      }
    })
  }


  addFeatureGroupToMap(featureCollection: any) {
    //if feature collection is empty return
    if (!featureCollection) {
      return;
    }

    const defaultSvgIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" fill="currentColor" class="bi bi-crosshair" viewBox="0 0 16 16">
  <path d="M8.5.5a.5.5 0 0 0-1 0v.518A7 7 0 0 0 1.018 7.5H.5a.5.5 0 0 0 0 1h.518A7 7 0 0 0 7.5 14.982v.518a.5.5 0 0 0 1 0v-.518A7 7 0 0 0 14.982 8.5h.518a.5.5 0 0 0 0-1h-.518A7 7 0 0 0 8.5 1.018zm-6.48 7A6 6 0 0 1 7.5 2.02v.48a.5.5 0 0 0 1 0v-.48a6 6 0 0 1 5.48 5.48h-.48a.5.5 0 0 0 0 1h.48a6 6 0 0 1-5.48 5.48v-.48a.5.5 0 0 0-1 0v.48A6 6 0 0 1 2.02 8.5h.48a.5.5 0 0 0 0-1zM8 10a2 2 0 1 0 0-4 2 2 0 0 0 0 4"/>
</svg>`

    //define customa marker
    let icon = featureCollection.icon ? featureCollection.icon.replace('<svg', '<svg width="36" height="36"') : defaultSvgIcon;
    const customIcon = L.divIcon({
      html: icon,
      iconSize: [36, 36],
      iconAnchor: [18, 18],
      popupAnchor: [1, -34],
    });

    // check if feature collection is a valid geojson
    if (!featureCollection.features) {
      return;
    }
    
    let msg = this.translate.instant('DEWETRA3APP.EXPOSURE_ANALYSIS.HERE');

    //add feature collection to map using custom icon
    let jsonObject = L.geoJSON(featureCollection, {
      pointToLayer: function (feature, latlng) {
        const marker = L.marker(latlng, {icon: customIcon});
        marker.feature = feature;
        marker.bindPopup(msg);
        return marker;
      }
    });
    // add the feature collectionin at eaFeatureOnMap layer group
    this.eaFeatureOnMap.addLayer(jsonObject);


    //all'hover del mouse assegno nel manager il feature per fare highlight su tabella
    jsonObject.on('mouseover', (event) => {
      // Scateno l'evento per far vedere evidenziare la tabella
      this.exposureAnalysisService.selectFeatureOnMapFromMap(event.layer)
    });

    //all'uscita del mouse resetto nel manager il feature
    jsonObject.on('mouseout', (event) => {
      this.exposureAnalysisService.selectFeatureOnMapFromMap('');
    });
  }

}
