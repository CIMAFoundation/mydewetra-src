import {animate, style, transition, trigger} from '@angular/animations';
import {AsyncPipe, DatePipe, NgClass, NgForOf} from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {Component, inject, Inject, Input, OnInit} from '@angular/core';
import {FormControl, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatIconButton} from '@angular/material/button';
import {MatFormField, MatFormFieldModule, MatLabel} from '@angular/material/form-field';
import {MatIcon} from '@angular/material/icon';
import {MatProgressSpinner} from '@angular/material/progress-spinner';
import {MatOption, MatSelect} from '@angular/material/select';
import {MatSlideToggle} from '@angular/material/slide-toggle';
import {MatTooltip} from '@angular/material/tooltip';
import {AuthService, CimaEnvironment, SnackbarService, StorageService, TimepickerService} from '@cima/commons';
import {
  SENTINELAggreWithouGeom, SentinelExceedingFeatureProperties,
  SentinelFeature,
  SentinelFeatureProperties,
  SentinelFeaturePropertiesUpdate,
  SentinelResponse,
  SentinelSensorInfoResponse,
} from '@cima/dewetra3-core';
import {left} from '@popperjs/core';
import {
  BehaviorSubject,
  combineLatest,
  defer,
  filter,
  firstValueFrom,
  from,
  map,
  mergeMap,
  Observable,
  of,
  retryWhen,
  Subject,
  switchMap,
  tap,
  timer,
  toArray,
} from 'rxjs';
import {scan, startWith, takeUntil} from 'rxjs/operators';
import {webSocket, WebSocketSubject} from 'rxjs/webSocket';
import {Tool} from '../../../models/tool.model';
import {PluvioMonitoringMapComponent} from "../pluvio-monitoring/pluvio-monitoring-map/pluvio-monitoring-map.component";
import {MatCheckbox} from "@angular/material/checkbox";

interface tool {
  serie_id: string;
  thr_group: string;
  sensor_class: number;
  sensors_group: string;
  chart_id: string;
}

interface ToolThresholdMonitor extends Tool {
  props: tool;
}


export interface SentinelFeatureAdapted extends SentinelFeature {
  sensorInfo?: SentinelSensorInfoResponse;
}

@Component({
  selector: 'dewetra3-threshold-monitor',
  standalone: true,
  animations: [
    trigger('fadeInOut', [
      transition(':enter', [style({opacity: 0}), animate('250ms ease-out', style({opacity: 1}))]),
      transition(':leave', [animate('400ms ease-in', style({opacity: 0}))]),
    ]),
  ],
  imports: [
    ReactiveFormsModule,
    MatFormFieldModule,
    MatFormField,
    MatSelect,
    MatOption,
    MatLabel,
    MatSlideToggle,
    FormsModule,
    NgClass,
    DatePipe,
    AsyncPipe,
    MatProgressSpinner,
    MatIconButton,
    MatIcon,
    MatTooltip,
    PluvioMonitoringMapComponent,
    MatCheckbox,
    NgForOf,
  ],
  templateUrl: './threshold-monitor.component.html',
  styleUrl: './threshold-monitor.component.scss',
})
export class ThresholdMonitorComponent implements OnInit {
  @Input() tool: ToolThresholdMonitor;
  public env: CimaEnvironment;

  constructor(@Inject('env') env: CimaEnvironment) {
    this.env = env;
  }

  private _http: HttpClient = inject(HttpClient);
  private _authService: any = inject(AuthService);
  private _storageService: any = inject(StorageService);
  private _ws: WebSocketSubject<any>;
  private _timePickerService: any = inject(TimepickerService);
  private snackbarService: SnackbarService = inject(SnackbarService);

  private _sensors: BehaviorSubject<SentinelFeature[]> = new BehaviorSubject<SentinelFeature[]>(null);

  private _recentNotifications: BehaviorSubject<any[]> = new BehaviorSubject<SentinelFeature[]>(null);

  wsUpdating$ = new BehaviorSubject<boolean>(false);
  private readonly LOADER_VISIBILITY = 1200;
  private _loaderTimeout: any = null;
  private destroy$ = new Subject<void>();

  public maxPluvioAggrPeriods: number[] = [1, 3, 6, 12, 24];
  public maxPluvioAggrPeriodsSelected: number[] = [1, 3];
  private _maxPluvioAggrPeriodsSelected$ = new BehaviorSubject<number[]>([1, 3]);

  private _listOfAvailableAggregations = [
    'catchments_it',
    'districts_it',
    'municipalities_it',
    'regions_it',
    'warningareas_it',
  ];
  private _loadedAggregationWithoutGeom: Record<string, SENTINELAggreWithouGeom[]>;

  public alertActivated = true;

  public reloading = false;

  private autoUpdateTimer: any = null;

  //public alertAudio = new Audio('assets/audio/alert.mp3');

  private _sensorsWithThreshold$: Observable<SentinelFeature[]> = this._sensors.pipe(
    //filter((sensors) => sensors !== null && sensors?.length > 0),
    map(sensors => sensors ?? []), // evita null
  );

  public recentNotifications$: Observable<SentinelFeatureAdapted[]> = this._recentNotifications.pipe(
    filter((sensors) => sensors !== null && sensors?.length > 0),
    switchMap((sensors) =>
      // Fetch additional sensor info for each filtered sensor
      from(sensors).pipe(
        mergeMap((sentinelFeature) =>
          this.loadSensorInfo$(sentinelFeature.properties).pipe(
            map((sensorInfo) => this._hydrateSentinelInfoResponse(sensorInfo)),
            map((sensorInfo) => ({
              ...sentinelFeature,
              sensorInfo, // Attach sensor info to each filtered feature
            }))
          )
        ),
        //play sound on alert
        tap((sensor) => {
          if (this.alertActivated) {
            this.playSound();
          }
        }),
        // Collect results into an array
        toArray()
      )
    )
  );

  protected get<T>(url: string, params?: any): Observable<T> {
    let server = this.env.server.baseUrl + '/dewetra3/';
    return this._http.get<T>(server + url + (params ? '?' + new URLSearchParams(params).toString() : ''));
  }

  private getWebSocket(path: string) {
    const token = this._authService.accessToken;
    const wsEndpoint = this.env.server.wsEndpoint;
    let url = `${wsEndpoint}?path=${path}&token=${token}`;
    return webSocket(url);
  }

  private socketFactory(path: string) {
    return defer(() => this.getWebSocket(path)); // nuovo WS ad ogni sub
  }

  private _cacheSensorInfo: Map<string, SentinelSensorInfoResponse> = new Map();

  public thrFilterControl = new FormControl('1');

  public filteredSensors$: Observable<SentinelFeatureAdapted[]> = combineLatest([
    this._sensorsWithThreshold$,
    this.thrFilterControl.valueChanges.pipe(startWith(this.thrFilterControl.value)),
    this._maxPluvioAggrPeriodsSelected$
  ]).pipe(
    tap((sensors) => {
      console.log('Pre filtered sensors:', sensors);
    }),
    switchMap(([sensors, thrFilter, selectedPeriods]) =>
      // Fetch additional sensor info for each filtered sensor
      from(sensors).pipe(
        mergeMap((sentinelFeature) =>
          this.loadSensorInfo$(sentinelFeature.properties).pipe(
            map((sensorInfo) => this._hydrateSentinelInfoResponse(sensorInfo)),
            map((sensorInfo) => ({
              ...sentinelFeature,
              sensorInfo, // Attach sensor info to each filtered feature
            }))
          )
        ),
        // Collect results into an array
        toArray()
      )
    ),
    //get last level using period
    map((sensors: SentinelFeatureAdapted[]) =>
      sensors.map(sensor => {
        const period = sensor.properties.event?.period;
        const matched = sensor.properties.v.find((v: any) => v.p === period);
        sensor.properties.event = {
          ...sensor.properties.event,
          lastValue: matched?.v
        };
        return sensor;
      })
    ),
    //reoder by event.overflowDatetime
    map((sensors) => {
      return sensors.sort((a, b) => {
        const aTime = a.properties.event?.overflowDatetime ? new Date(a.properties.event.overflowDatetime).getTime() : 0;
        const bTime = b.properties.event?.overflowDatetime ? new Date(b.properties.event.overflowDatetime).getTime() : 0;
        return bTime - aTime; // Sort descending
      });
    }),
    // filter using aggrPeriods
    map((sensors: SentinelFeatureAdapted[]) => {
      if (this.maxPluvioAggrPeriodsSelected.length === 0) return sensors; // No filter applied
      return sensors.filter(sensor => {
        const period = sensor.properties.event.period;
        return this.maxPluvioAggrPeriodsSelected.includes(period / 3600);
      });
    }),
    // filter using thrFilterControl
    map((sensors: SentinelFeatureAdapted[]) => {
      //TODO se this.thrFilterControl.value è 40 filtra i sensori con overflowValue >= 40

      const threshold = parseInt(this.thrFilterControl.value ?? '0', 10);
      return sensors.filter(sensor =>
        sensor.properties.event.severity >= threshold
      );
    }),

    tap((sensors) => {
      console.log('Final filtered sensors:', sensors);
      //this.playSound()
    })
  );


  loadSensorInfo$(sentinelFeatureProperties: SentinelFeatureProperties): Observable<SentinelSensorInfoResponse> {
    const path = sentinelFeatureProperties.s + '/' + sentinelFeatureProperties.db;
    if (this._cacheSensorInfo.has(path)) return of(this._cacheSensorInfo.get(path));
    return this.get<SentinelSensorInfoResponse>('sentinelapi/sensor_info/' + path + '/').pipe(
      map((data: SentinelSensorInfoResponse) => {
        this._cacheSensorInfo.set(path, data);
        return data;
      })
    );
  }

  private _hydrateSentinelInfoResponse(data: SentinelSensorInfoResponse) {
    Object.keys(data.aggregations).forEach((aggregationKey: any) => {
      data.aggregations[aggregationKey] = data.aggregations[aggregationKey].map((aggregationId) => {
        if (!this._loadedAggregationWithoutGeom[aggregationKey]) return aggregationId; //if no layers are loaded, return the original data
        const layer = this._loadedAggregationWithoutGeom[aggregationKey].find((l) => l.id.toString() === aggregationId);
        if (layer) {
          aggregationId = layer.name;
        }
        return aggregationId;
      });
    });
    return data;
  }

  //loading data from tools
  async loadDataFromTools(tool: Tool): Promise<SentinelResponse> {
    //const timePickerValue = this._timePickerService.getTimepickerValue();

    //const dateTo = timePickerValue.to === 'now' ? new Date() : new Date(timePickerValue.to);

    /*    const params = new URLSearchParams({
          dt: dateToSeconds(dateTo).toString(),
        });*/

    const sensors = await firstValueFrom(this.get<SentinelResponse>('toolsapi/thr_monitoring/' + tool.id + '/'));
    return sensors;
  }

  //loading aggregated layer without geom
  async loadAggreatedLayerWithoutGeom(aggr_layer: string): Promise<SENTINELAggreWithouGeom[]> {
    const localData = JSON.parse(this._storageService.loadFromLocal('DEWETRA3_' + aggr_layer));
    if (localData == null) {
      const aggregatedLayer = await firstValueFrom(
        this.get<any>('sentinelapi/aggregated_layer_without_geom/' + aggr_layer + '/')
      );
      this._storageService.saveToLocal('DEWETRA3_' + aggr_layer, JSON.stringify(aggregatedLayer));
      return aggregatedLayer;
    } else {
      return localData;
    }
  }

  getMaxSeverity(exceeding: SentinelFeaturePropertiesUpdate): number {
    const sev = exceeding?.e?.map((e) => e.sev) ?? [];
    return sev.length ? Math.max(...sev) : 0;
  }

  getMaxSeverityTime(ex: SentinelFeaturePropertiesUpdate | undefined | null): number {
    if (!ex || !Array.isArray(ex.e) || ex.e.length === 0) return 0;
    const max = this.getMaxSeverity(ex);
    return ex.e.find((e) => e.sev === max)?.t ?? 0;
  }

  getMaxSeverityDate(exceeding: SentinelFeaturePropertiesUpdate): Date {
    const maxSeverityTime = this.getMaxSeverityTime(exceeding);
    return new Date(maxSeverityTime * 1000);
  }

  getMaxSeverityValue(ex: SentinelFeaturePropertiesUpdate | undefined | null): number {
    if (!ex || !Array.isArray(ex.e) || ex.e.length === 0) return 0;
    const max = this.getMaxSeverity(ex);
    return ex.e.find((e) => e.sev === max)?.v ?? 0;
  }

  // pluvio-monitoring.component.ts
  trackBySensor(_index: number, sensor: SentinelFeatureAdapted): number | string {
    // Use something guaranteed unique & stable.
    // `properties.s` looks like the sensor’s primary key.
    return sensor?.properties?.s;
  }


  //init websocket
  private initWebSocket(): void {
    const path = `sentinel.${this.tool.props.sensors_group.replace('%', '%25')}` + `.${this.tool.props.thr_group}`;

    this.socketFactory(path)
      .pipe(
        takeUntil(this.destroy$),

        /** riconnessione con back-off incrementale */
        retryWhen((err$) =>
          err$.pipe(
            tap((err) => console.error('WS error:', err)),
            scan((attempt, _) => attempt + 1, 0), // 1,2,3…
            mergeMap((attempt) => timer(Math.min(attempt, 5) * 1000)) // max 5 s
          )
        ),

        /** feedback “live” */
        tap(() => {
          this.wsUpdating$.next(true);
          clearTimeout(this._loaderTimeout);
          this._loaderTimeout = setTimeout(() => this.wsUpdating$.next(false), this.LOADER_VISIBILITY);
        }),

        /** business-logic: aggiorna i sensori */
        map((data) => this.patchSensors(data as SentinelFeaturePropertiesUpdate[]))
      )
      .subscribe();
  }

  private patchSensors(data: SentinelFeaturePropertiesUpdate[]): void {
    const byId = new Map(data.map((d) => [d.s, d])); // indicizza per id sensore
    const current = this._sensors.value ?? [];
    const withThr = data.filter((sensor) => sensor.e && sensor.e.length > 0); // filtra solo quelli con soglie

    const updated = current.map((sensor) => {
      const upd = byId.get(sensor.properties.s);
      if (!upd) return sensor; // nessun update → invariato

      const oldSev = this.getMaxSeverity(sensor.properties);
      const newSev = this.getMaxSeverity(upd); // 0 se upd.e mancante/vuoto

      // notifica solo quando si passa da livello inferiore a superiore (>),
      // oppure implementa una logica “cleared” se ti serve
      if (newSev > oldSev) {
        this._recentNotifications.next([...(this._recentNotifications.value ?? []), sensor]);
      }

      return {
        ...sensor,
        properties: {
          ...sensor.properties,
          v: upd.v,
          e: upd.e ?? [], // ← importante
        },
      };
    });

    this._sensors.next(updated);

    console.log(`->Sensor Received: ${data?.length} -> Updated sensors:${withThr?.length} out of ${current.length}`);

    if (withThr.length) {
      this.snackbarService.success(`Ricevuti sensori con soglie ${withThr.length} aggiornati`, '', {
        duration: 3000,
      });
    }
  }

  //loading sensors list
  private async _initSensors() {
    this.reloading = true;
    const sensors = await this.loadDataFromTools(this.tool);
    console.info(sensors);
    this._sensors.next(sensors.features);
    this.reloading = false;
  }

  async loadAllAggregationsWithoutGeom(): Promise<Record<string, SENTINELAggreWithouGeom[]>> {
    // Map each aggregation to a tuple with the key and promise result
    const requests = this._listOfAvailableAggregations.map(async (aggr_layer) => {
      const data = await this.loadAggreatedLayerWithoutGeom(aggr_layer);
      return [aggr_layer, data] as const; // Tuple to use in creating an object
    });

    // Wait for all promises to resolve, then create an object from the entries
    const entries = await Promise.all(requests);
    const result = Object.fromEntries(entries); // Convert array of tuples to a dictionary
    return result;
  }

  thrSortedByPeriod() {
    const v = this.selectedPluvio?.properties?.v;
    return Array.isArray(v) ? [...v].sort((a, b) => a.p - b.p) : [];
  }

  parseTime(): string {
    const time = this.mostRecentTime() * 1000;
    return new Date(time).toLocaleString();
  }

  mostRecentTime() {
    if (!this.selectedPluvio.properties.v) return 0;
    let mostRecent = 0;
    this.selectedPluvio.properties.v.forEach((v: any) => {
      if (v.t > mostRecent) {
        mostRecent = v.t;
      }
    });
    return mostRecent;
  }

  reload() {
    this._sensors.next(null);
    this._initSensors();
  }

  playSound() {
    const audio = new Audio('assets/dewetra3/audio/notification.mp3');
    audio.play();
  }

  autoUpdate() {
    if (this.autoUpdateTimer) {
      clearInterval(this.autoUpdateTimer);
      this.autoUpdateTimer = null;
    } else {
      this.autoUpdateTimer = setInterval(() => {
        console.log('Auto updating...');
        this.reload();
      }, 300000); // 5 minute interval
    }
  }

  addRemoveMaxPluvioAggrPeriods(aggr: number, event: any) {
    console.log("AddMaxPluvioAggrPeriods", aggr, event)
    if (event.checked) {
      this.maxPluvioAggrPeriodsSelected = [...this.maxPluvioAggrPeriodsSelected, aggr].sort((a, b) => a - b);
    } else {
      this.maxPluvioAggrPeriodsSelected = this.maxPluvioAggrPeriodsSelected.filter(itm => itm !== aggr);
    }
    this._maxPluvioAggrPeriodsSelected$.next(this.maxPluvioAggrPeriodsSelected);
    console.log(this.maxPluvioAggrPeriodsSelected);
  }


  //init necessary data
  async ngOnInit() {
    this._loadedAggregationWithoutGeom = await this.loadAllAggregationsWithoutGeom();

    this._initSensors();

    //this.autoUpdate();

    /*    if (this._timePickerService.getTimepickerValue().to === 'now') {
          this.initWebSocket();
        }*/

    this.thrFilterControl.setValue('1');
  }

  ngOnDestroy(): void {
    try {
      this.destroy$.next();
      this.destroy$.complete();
      clearTimeout(this._loaderTimeout);
    } catch (e) {
      console.error('Error unsubscribing from WebSocket:');
      console.error(e);
    }
  }

  filterLevel = 'all';
  selectedPluvio: any = null;

  protected readonly left = left;
}
