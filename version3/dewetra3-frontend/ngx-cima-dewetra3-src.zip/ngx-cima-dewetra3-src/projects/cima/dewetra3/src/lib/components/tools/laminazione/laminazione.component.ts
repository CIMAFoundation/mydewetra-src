import {Component, Input, ViewChild} from '@angular/core';
import {CimaCommonsModule} from "@cima/commons";
import {ExposuresSelectionComponent} from "../exposure-analisys/exposures-selection/exposures-selection.component";
import {InputForecastComponent} from "./input-forecast/input-forecast.component";
import {SummaryComponent} from "./summary/summary.component";
import {RunComponent} from "./run/run.component";
import {ChartsComponent} from "./charts/charts.component";
import {MatStepper} from "@angular/material/stepper";
import {InputActionsComponent} from "./input-actions/input-actions.component";
import {ResultsComponent} from "./results/results.component";

@Component({
  selector: 'dewetra3-laminazione',
  standalone: true,
  imports: [
    CimaCommonsModule,
    ExposuresSelectionComponent,
    InputForecastComponent,
    SummaryComponent,
    RunComponent,
    ChartsComponent,
    InputActionsComponent,
    ResultsComponent
  ],
  templateUrl: './laminazione.component.html',
  styleUrl: './laminazione.component.scss'
})
export class LaminazioneComponent {
  @Input() tool: any; //TODO: define the type of the tool

  @ViewChild('stepper') stepper!: MatStepper;

  //STEP 1
  forecastsList: any[] = [
    {id: 1, name: 'Previsione FP'},
    {id: 2, name: 'Previsione CF‐UMBRIA MISDc LAMI'},
    {id: 3, name: 'Previsione CF‐UMBRIA MISDc ECMWF '}
  ];

  selectedForecast: any

  setNewForecast(selectedForecast: any) {
    this.selectedForecast = selectedForecast;
  }

  goToStep(step: string) {
    if (step == 'run') {
      this.stepper.selectedIndex = 3
    }
    if (step == 'inputActions') {
      this.stepper.selectedIndex = 2
    }
  }

  nextStep() {
    this.stepper.next();
  }

  previousStep() {
    this.stepper.previous();
  }


}
