#!/bin/bash

echo "Starting message service"
export DJANGO_SETTINGS_MODULE=dewetra3.settings
python dewetra3/message/service.py
1