#!/usr/bin/env bash
set -euo pipefail

#------------------------------------------------------------------------------
# update_tag_on_deployments.sh
#
# Usage: update_tag_on_deployments.sh -c CLUSTER -n NAMESPACE -d DEPLOYMENT -t TAG [options]
#
# Options:
#   -c CLUSTER      Kubernetes cluster (e.g. awsprod, awstest, cimatest)
#   -n NAMESPACE    Kubernetes namespace
#   -d DEPLOYMENT   Deployment key under versions (e.g. dewetra3-backend)
#   -t TAG          New tag (must match vX.Y.Z)
#   -p PATH         Path to deployments repo (default: ../deployments)
#   -y              Assume “yes” to confirmations
#   -r              Dry run (show diff, don’t push)
#   -h              Help
#------------------------------------------------------------------------------

readonly PROGNAME=$(basename "$0")

print_usage() {
  cat <<EOF
Usage: $PROGNAME -c CLUSTER -n NAMESPACE -d DEPLOYMENT -t TAG [options]

Options:
  -c CLUSTER      Kubernetes cluster (e.g. awsprod, awstest, cimatest)
  -n NAMESPACE    Kubernetes namespace
  -d DEPLOYMENT   Deployment key under versions (e.g. dewetra3-backend)
  -t TAG          New tag (must match vX.Y.Z)
  -p PATH         Path to deployments repo (default: ../deployments)
  -y              Assume “yes” to confirmations
  -r              Dry run (show diff, don’t push)
  -h              Help
EOF
}

log()    { echo "[INFO]  $*"; }
err()    { echo "[ERROR] $*" >&2; exit 1; }
confirm() {
  [[ "${ASSUME_YES:-false}" == true ]] && return 0
  read -rp "$* [y/N]: " choice
  [[ "$choice" =~ ^[Yy]$ ]]
}

# Defaults
DEPLOYMENTS_PATH="../deployments"
ASSUME_YES=false
DRY_RUN=false

# Parse options
while getopts ":c:n:d:t:p:yrh" opt; do
  case $opt in
    c) CLUSTER="$OPTARG" ;;
    n) NAMESPACE="$OPTARG" ;;
    d) DEPLOYMENT="$OPTARG" ;;
    t) TAG="$OPTARG" ;;
    p) DEPLOYMENTS_PATH="$OPTARG" ;;
    y) ASSUME_YES=true ;;
    r) DRY_RUN=true ;;
    h) print_usage; exit 0 ;;
    \?) err "Invalid option: -$OPTARG";;
    :)  err "Option -$OPTARG requires an argument";;
  esac
done

# Required arguments
: "${CLUSTER:?Missing -c CLUSTER}"
: "${NAMESPACE:?Missing -n NAMESPACE}"
: "${DEPLOYMENT:?Missing -d DEPLOYMENT}"
: "${TAG:?Missing -t TAG}"

# Validate TAG format
if [[ ! $TAG =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  err "TAG must be in the format vX.Y.Z"
fi

# Ensure tools
command -v git >/dev/null || err "git is required"
command -v yq >/dev/null || err "yq is required (https://github.com/mikefarah/yq)"

# Move into the repo directory
cd "$DEPLOYMENTS_PATH"

# Pull latest
log "Pulling latest changes in $(pwd)..."
git pull

# YAML path relative to repo root
YAML_FILE="data/$CLUSTER/$NAMESPACE.yaml"
[[ -f "$YAML_FILE" ]] || err "File not found: $YAML_FILE"

# Check that the deployment key exists
key_exists=$(yq e "has(\"versions\") and .versions | has(\"${DEPLOYMENT}\")" "$YAML_FILE")
[[ "$key_exists" == "true" ]] || err "Deployment key 'versions.${DEPLOYMENT}' not found in $YAML_FILE"

# Fetch current tag
current_tag=$(yq e ".versions.\"${DEPLOYMENT}\"" "$YAML_FILE")
[[ -n "$current_tag" && "$current_tag" != "null" ]] || err "Deployment key 'versions.${DEPLOYMENT}' is null or empty"

if [[ "$current_tag" == "$TAG" ]]; then
  err "Current tag ($current_tag) is already $TAG"
fi

log "Will update 'versions.${DEPLOYMENT}' in $CLUSTER/$NAMESPACE:"
echo "  from: $current_tag"
echo "    to: $TAG"

confirm "Proceed with tag update?" || err "Aborted by user"

# Update with yq
yq e -i ".versions.\"${DEPLOYMENT}\" = \"${TAG}\"" "$YAML_FILE"
log "Updated YAML"

# Show diff
git diff "$YAML_FILE"

if [[ "$DRY_RUN" == true ]]; then
  log "Dry run enabled – skipping commit & push"
  exit 0
fi

confirm "Commit & push changes?" || err "Aborted by user"

# Commit & push
git add "$YAML_FILE"
git commit -m "Update ${DEPLOYMENT} to ${TAG} in ${NAMESPACE}"
git push

log "Successfully updated ${DEPLOYMENT} to ${TAG} in ${NAMESPACE}"
