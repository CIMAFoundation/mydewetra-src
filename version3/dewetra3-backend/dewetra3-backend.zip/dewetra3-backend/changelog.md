-e ## v0.3.146 

 
- feat: remove order field from LayerTag model and add it to Tag model for improved tag ordering
-e ## v0.3.145 

 
- feat: add order field to LayerTag model for tag ordering and update related field in Layer model for clarity
- Merge branch 'master' of https://github.com/CIMAFoundation/acroweb3-dewetra3-backend
- feat: add order field to LayerTag model for tag ordering
-e ## v0.3.142 

 
- feat: add migration to introduce name_i18n field and modify related field in layer model
- style: format code for better readability and consistency
-e ## v0.3.141 

 
- fix: correct syntax error in urlpatterns and tidy import statements
- feat: add ExternalProxyView for generic proxying of GET/POST/OPTIONS requests
-e ## v0.3.140 

 
- fix: simplify server object retrieval by removing unnecessary filters
-e ## v0.3.139 

 
- fix: enhance server object retrieval for default geoserver configuration
-e ## v0.3.138 

 
- fix: simplify server object retrieval for default geoserver
-e ## v0.3.137 

 
- fix: refactor server object retrieval logic for clarity and consistency
-e ## v0.3.136 

 
- fix: create server for default geoserver if it does not exists
- fix: create server for default geoserver if it does not exists
- fix: managed style already exists
-e ## v0.3.135 

 
- Merge branch 'master' of https://github.com/CIMAFoundation/acroweb3-dewetra3-backend
- refactor: reorganize imports and clean up whitespace in DDSDynamicLayer
- fix: chack properties for movie
-e ## v0.3.134 

 
- new: movie allowed depending on layer properties
- new: movie allowed depending on layer properties
- new: movie allowed depending on layer properties
-e ## v0.3.133 

 
- Merge branch 'master' of https://github.com/CIMAFoundation/acroweb3-dewetra3-backend
- fix: update proxy_pass to use host.docker.internal for API endpoints
- wip: added layer data to pubblication result
- new: addel all_my_features endpoint
- new: download url
- new: download url
-e ## v0.3.132 

 
- new: movie implementation
- wip: docs for movie creation
- wip: docs for movie creation
-e ## v0.3.131 

 
- feat: implement destroy method in LayerManagerViewSet with permission checks
-e ## v0.3.130 

 
- refactor: reorganize imports and improve code readability
-e ## v0.3.129 

 
- Merge branch 'master' of https://github.com/CIMAFoundation/acroweb3-dewetra3-backend
- feat: add roles field to LayerSerializer
- fix: gpkg management and upload
-e ## v0.3.127 

 
- wip
-e ## v0.3.126 

 
- fix: update database configuration in dump script
- Merge branch 'master' of https://github.com/CIMAFoundation/acroweb3-dewetra3-backend
- fix: style publish and file upload management
- Add search functionality to IconView
-e ## v0.3.125 

 
- Add Icon serializer and viewset for Icon objects
-e ## v0.3.124 

 
- Refine deployment script: update comments, improve tag validation, and enhance YAML handling
-e ## v0.3.121 

 
- refactor: enhance update_tag_on_deployments.sh with improved argument parsing and error handling
- fix: gpkg pubblication
-e ## v0.3.120 

 
- new: managed default geoserver
-e ## v0.3.119 

 
- fix: update short description for icon SVG preview in IconAdmin
-e ## v0.3.118 

 
- fix: Response in capabilities view
-e ## v0.3.117 

 
- feat: add IconAdmin with SVG icon display and search functionality
- feat: enhance event and manager creation with descriptions and update related manager names
-e ## v0.3.116 

 
- Merge branch 'master' of https://github.com/CIMAFoundation/acroweb3-dewetra3-backend
- feat: add import layers commands and update dump script output file name
- refactor: clean up logging statements in DDSDynamicLayer for consistency
- feat: add max pluvio action to SentinelLayer for retrieving maximum pluvio data
- chore: update .gitignore to include additional dump files
- refactor: streamline Layer creation by consolidating defaults in import_layers_event command
- feat: update PostgreSQL version in restore script to 17
- feat: add database dump and restore scripts for production environment
- refactor: remove import_layers management command to streamline codebase
- feat: enhance Layer import command with improved data management and error handling
- feat: add management command to import Layer data from JSON file
-e ## v0.3.115 

 
- chore: update acroweb3 dependency to version 1.7.1
-e ## v0.3.114 

 
- Merge remote-tracking branch 'origin/master'
- refactor: improve code formatting and organization in settings and admin files
- fix: check layer from capabilities if auth info not present in server
- fix: check layer from capabilities if auth info not present in server
- fix: replace wrong websocket library with websocket-client
- Merge remote-tracking branch 'origin/master'
- refactor: improve code formatting and organization in serializers and views
- refactor: enhance code organization and readability by restructuring imports and formatting
- refactor: improve code readability by organizing imports and formatting
- fix: acroweb3 api lib with coordinated_domains
- new: server check
- new: menu styles management
-e ## v0.3.113 

 
- chore: update .gitignore to exclude temp/event.json
- refactor: simplify tag retrieval logic in LayerSerializer
-e ## v0.3.112 

 
- feat: add backend URLs for Floodcat and Exposure Analysis in default.env
-e ## v0.3.111 

 
- refactor: remove unused LayerTag model and clean up imports
-e ## v0.3.110 

 
- Merge remote-tracking branch 'origin/master'
- feat: update exposure analysis view methods and improve NGINX configuration
- refactor: clean up imports and reorganize viewset definitions for clarity
- refactor: reorganize URL imports and update urlpatterns for clarity
- Merge branch 'new-authorization'
- new: geoserver workspace from domain
- feat: add exposure analysis functionality and update related models and views #15
- new: geoserver pubblication with geoserver_rest and geoserver publication of GPKG files
- wip: add layer debug
- feat: update Docker setup and initialization scripts for PostGIS support
- wip: menu views for adding layers
- fix: requirements reduction
- wip: menu views for adding layers
- fix: requirements reduction
-e ## v0.3.109 

 
- fix: update role filtering to match exact user domain
- feat: disable deletion of EventLayerInline instances in admin
-e ## v0.3.108 

 
- feat: enhance admin interface with new ServerAdmin and GenericManagerAdmin classes
- feat: add namespace hosts to allowed hosts in settings
-e ## v0.3.107 

 
- feat: update caching configuration and enhance AsyncProxyView error handling
-e ## v0.3.106 

 
- feat: replace CachedProxyView with AsyncProxyView for improved proxy handling
-e ## v0.3.105 

 
- feat: add CachedProxyView for enhanced proxy handling with caching support
-e ## v0.3.104 

 
- feat: implement AsyncProxyView for improved asynchronous proxy handling
- feat: replace ProxyView with AsyncProxyView for improved asynchronous handling
- feat: add httpx dependency for improved HTTP handling
- feat: enhance server startup configuration with dynamic worker and thread settings
-e ## v0.3.103 

 
- feat: update proxy URL pattern to use regex for improved path handling
-e ## v0.3.102 

 
- feat: update proxy endpoint to accept additional path parameter
- feat: add token to query parameters if available in proxy function
- docs: update README.md with debugging instructions
-e ## v0.3.101 

 
- fix: correct filename from guniconf.py to gunicorn_conf.py in Dockerfile
-e ## v0.3.100 

 
- feat: add guniconf.py to Dockerfile for configuration
-e ## v0.3.99 

 
- feat: add interactive debugging support and update Docker configuration
-e ## v0.3.98 

 
- Merge remote-tracking branch 'origin/master'
- Bump version to v0.3.97
- feat: add token field to Server model and create migration
- fix: update proxy URL path in dewapi to remove unused path parameter
- fix: comment out hardcoded proxy URL in ServerSerializer for flexibility
- fix: update proxy URL in ServerSerializer to point to localhost for testing
- refactor: simplify proxy function by removing unused path parameter
-e ## v0.3.97 

 
- feat: add token field to Server model and create migration
- fix: update proxy URL path in dewapi to remove unused path parameter
- fix: comment out hardcoded proxy URL in ServerSerializer for flexibility
- fix: update proxy URL in ServerSerializer to point to localhost for testing
- refactor: simplify proxy function by removing unused path parameter
-e ## v0.3.96 

 
- chore: update Dockerfile and nginx configuration; modify settings for floodcat backend integration
-e ## v0.3.95 

 
- Merge remote-tracking branch 'origin/master'
- chore: update Dockerfile to use Python 3.11 and install librdkafka-dev; enhance README with conda usage instructions
- chore: add environment.yml for managing project dependencies
-e ## v0.3.94 

 
- feat: add DDS WebSocket message configuration to default environment
-e ## v0.3.93 

 
- Merge remote-tracking branch 'origin/master'
- feat: enhance print functionality by adding customizable title and description
- chore: add .DS_Store to .gitignore to prevent tracking of macOS system files
- Merge remote-tracking branch 'origin/master'
- Add 'dataid' and 'descr' to search fields in LayerAdmin for improved search functionality
-e ## v0.3.91 

 
- Refactor chart options handling in ChartViewSet and update translation function parameter naming for clarity
- Enhance logging functionality by adding 'app-log' and 'layer-removed' activity types; update deployment script comments for version consistency
-e ## v0.3.90 

 
- Comment out print-service configuration in docker-compose and adjust proxy_pass settings in nginx.conf
- Refactor file name handling to avoid redundant splitting in ToolsViewsSet
- Update Nginx configuration to simplify admin path routing
- Clean up URL patterns by removing commented-out admin path in urls.py
- Update FORCE_SCRIPT_NAME setting to an empty string in settings.py
- Fix logging to use file name instead of tool ID in Publish_layer_to_geoserver
-e ## v0.3.89 

 
- Update file handling in ToolsViewsSet to retain uploaded files
- Remove file extension from file name in ToolsViewsSet response
-e ## v0.3.88 

 
- Fix typo in print URL management and add logging for GeoTIFF uploads and layer publishing
-e ## v0.3.87 

 
- Refactor GeoTIFF publishing to use temporary directory for file handling
- Add FORCE_SCRIPT_NAME to Kubernetes config map
- Add default environment variable for DEWETRA3 FORCE_SCRIPT_NAME
- Update STATIC_URL default path in settings
-e ## v0.3.86 

 
- Set ownership for code/media folder in Dockerfile
- Add FORCE_SCRIPT_NAME to settings
-e ## v0.3.85 

 
- Add FORCE_SCRIPT_NAME and SECURE_PROXY_SSL_HEADER to settings; update deployment script examples for new version tags
-e ## v0.3.84 

 
- Refactor translation logging to use internal activity logging function
- Add internal activity logging function with error handling
- Implement chart options management with translation support
- Add translation service with lazy loading and placeholder support
- Comment out unused admin URL and proxy settings in Nginx configuration
- Update deployment script usage examples for consistency with latest tags
-e ## v0.3.83 

 
- Add system status endpoints for server info and backend version
-e ## v0.3.82 

 
- Refactor print request URL handling for consistency and update deployment script usage example
-e ## v0.3.81 

 
- Refactor FloodCat API URL handling and add MyCloud print functionality with improved request management
- Refactor user information extraction into a separate function; update logging functions to utilize the new method for improved clarity and maintainability
-e ## v0.3.80 

 
- Refactor logging functions for improved formatting and error handling; update LogView to utilize log_activity for activity logging
- Implement log_to_acroweb function and update LogView to use it; enhance EventView queryset filtering by user domain
- Add logging functionality with LogView for activity tracking
-e ## v0.3.79 

 
- Refactor Layer model to use ManyToManyField for events; update serializers and views
-e ## v0.3.78 

 
- Remove unused event fields from LayerView serializer
-e ## v0.3.77 

 
- Refactor Layer model to use ManyToManyField for events; update admin and migration files
-e ## v0.3.76 

 
- Add DataType model and update Event model to use datatypes field
- Enhance FloodCat API views with improved logging and error handling for flood events and locations
- Add additional line breaks for improved readability in log function
- Add DataType model and viewset; update Event model and serializers
-e ## v0.3.75 

 
- Refactor Event model and serializers; add FloodCat API views and routing
- Add debug logging for missing data keys in WidgetManager
- Remove debug logging for unset data keys in WidgetManager
- Add WidgetAdmin class with save_as option and autocomplete fields
-e ## v0.3.74 

 
- modules init file
- Add debug logging for unset data keys in WidgetManager
- Add bypass for admin login and reorganize admin URL patterns
-e ## v0.3.73 

 
- Update acroweb3_api dependency to version 1.4.1
-e ## v0.3.72 

 
- Merge branch 'dev'
- Enhance logging in ChartViewSet for better traceability; add error handling for JSON and image generation
- Merge branch 'dev'
- Merge pull request #14 from CIMAFoundation/dev
- Update 3-services.yml
- Merge pull request #12 from CIMAFoundation/dev
- Merge branch 'dev'
- Bump version to v0.3.15
-e ## v0.3.71 

 
- Enhance logging function to include user, domain, request path, and method; add error handling
-e ## v0.3.70 

 
- Refactor log function to remove unnecessary self parameter
-e ## v0.3.69 

 
- Add logging functionality to enhance request tracking in views
- Add logging for layer operations in DDSDynamicLayer
-e ## v0.3.68 

 
- Add read-only icon field to ToolSerializer
-e ## v0.3.67 

 
- Refactor SentinelLayer to remove caching logic and improve request handling
- Enhance deployment tag update script with validation checks and confirmation prompt
-e ## v0.3.66 

 
- Add script to update deployment tags in CI/CD pipeline
- Add wget to Dockerfile dependencies
-e ## v0.3.65 

 
- Refactor views.py to include timestamp parameter in the request for retrieving sensors
- Refactor views.py to include validity_period parameter in threshold data retrieval
-e ## v0.3.64 

 
- Refactor views.py to handle Sentinel data retrieval and thresholds
-e ## v0.3.63 

 
- Refactor views.py to include timestamp parameter in the request for retrieving sensors
-e ## v0.3.62 

 
- Refactor views.py to improve handling of date parsing and request period retrieval
-e ## v0.3.61 

 
- New: tools pluvio_monitoring
- Fix:  __set_variable method in views.py
-e ## v0.3.60 

 
- Fix: views.py to improve handling of sensor_group query parameter
-e ## v0.3.59 

 
- Refactor nginx.conf to use HTTPS for WebSocket connection in notifier API
- Refactor nginx.conf to enable WebSocket connection for notifier API
-e ## v0.3.58 

 
- Fix: added message service
- Fix: updated 3 services
-e ## v0.3.57 

 
- Fix: removed file handler
-e ## v0.3.56 

 
- New: added service for routing dds messages #13
- Fix: nginx conf
- New: added movies api
- Fix: docker compose configuration
- Fix: docker compose configuration
- Fix: docker compose configuration
-e ## v0.3.55 

 
- Refactor file renaming logic in views.py
- Refactor views.py to add file upload functionality and publish layers to GeoServer and Dewetra ORM
- Refactor upload_utils.py to add function for appending file chunks to a destination file
- Refactor create_dataid and create_uploaded_layer_in_django_orm functions
- Refactor settings.py and add media URL and root
-e ## v0.3.54 

 
- Refactor print and dispatch methods in views.py
-e ## v0.3.53 

 
- Refactor print and dispatch methods in views.py
-e ## v0.3.52 

 
- Refactor print and dispatch methods in views.py
-e ## v0.3.51 

 
- Refactor print method in views.py
- Refactor dispatch method in views.py
- Merge branch 'dev-working' into dev
- Refactor settings.py to use "bricks-staging" as default namespace
- Refactor settings.py to use "bricks-staging" as default namespace
## v0.3.49 

 
- Improve handling of print service requests in views.py and add asyncio to dispatch method
## v0.3.48 

 
- Improve handling of print service requests in views.py and add JSONParser to parser classes
## v0.3.47 

 
- Improve handling of print service requests in views.py and update dependencies
## v0.3.46 

 
- Improve handling of print service requests in views.py
## v0.3.45 

 
- Improve logging and handle print service requests in views.py
## v0.3.44 

 
- Merge branch 'feature-uploadToGeoserver' into dev
- Add auth.json to .gitignore Update launch.json for Django local debugging Update PORTAL_BACKEND_URL in settings.py Update acroweb3_api version in requirements.txt
- New: adding tools for manage upload geotiff
- New: views.py to improve logging and handle print service requests
## v0.3.43 

 
- Fix: views.py to improve logging and handle print service requests
## v0.3.42 

 
- Fix views.py to handle different print types and return appropriate content type
## v0.3.41 

 
- Fix views.py to fix URL formatting for print service
## v0.3.40 

 
- Fix: views.py to handle templateData as JSON or string and return response content instead of JSON
## v0.3.39 

 
- Refactor views.py to handle templateData as JSON or string
## v0.3.38 

 
- Refactor views.py to return response content instead of JSON
## v0.3.37 

 
- Refactor views.py to handle templateData as JSON or string
## v0.3.36 

 
- Fix: views.py to handle templateData as JSON or string
## v0.3.35 

 
- Fix: views.py to handle template data in print service request
## v0.3.34 

 
- Add dewetra3/dds/request.py to the repository
- Fix views.py to improve readability and maintainability
## v0.3.33 

 
- Fix views.py to include additional parameters for print service URL
## v0.3.32 

 
- Fix: Update views.py to improve readability and maintainability
-e ## v0.3.31 

 
- chore: Add K8S_NAMESPACE to settings for print service URL
- New: added namespace retrieving
- Fix: Change HTTP method for dds_image and dds_json actions in ChartViewSet
- Fix: Fake thresholdsfor test
- fix: Update cache_string concatenation in SentinelLayer views
-e ## v0.3.30 

 
- Fix: Update memcached server IP address in dewetra3-backend.sh and handle exceptions in SentinelLayer views
-e ## v0.3.29 

 
- Update: DEWETRA3_BACKEND_URL to use dewetra3-backend
-e ## v0.3.28 

 

## v0.3.27 

 
- New: Added view for aggregated table [refs #10]
- Upgrade:  updated sentinel library [refs #10]
- New: updated sentinel viws [refs #10 ]
- Merge pull request #11 from CIMAFoundation/sentinel-aggregated-table
- New: View for filter sensor by aggregated feature [refs #10]
-e ## v0.3.26 

 
- chore: Start memcached server in the backend script
-e ## v0.3.25 

 
- Fix: update memcached method
-e ## v0.3.24 

 
- chore: Update Dockerfile to use 0.0.0.0 as memcached host
-e ## v0.3.23 

 
- chore: Update Dockerfile to include telnet package
- chore: Update dewetra3 widget backend URL
-e ## v0.3.22 

 
- chore: Update k8s deployments and services
- chore: Update docker-compose.yml to include local testing services
-e ## v0.3.21 

 
- chore: Reorder imports in service.py file
-e ## v0.3.20 

 
- Fix: update services
-e ## v0.3.19 

 
- Fix updated deployments
-e ## v0.3.18 

 
- chore: Update Dockerfile to use CMD instead of RUN for starting memcached
-e ## v0.3.17 

 
- Fix: fixed iteraction
- WIP widget
- New: implemented memcached for widgets
- Fix: Admin prefeatch for layers in roles
-e ## v0.3.16 

 
- Bump version to v0.3.15
- New: Init cache system with pylibmc
- New: add and mod filters
- Merge pull request #9 from CIMAFoundation/master
- Merge pull request #8 from CIMAFoundation/dev
- Merge pull request #7 from CIMAFoundation/master
- Merge remote-tracking branch 'origin/dev' into dev
- Update: Add FilterByLayerRole to LayerAdmin list_filter
- Upgrade: updated tools for importing layers
- Merge pull request #6 from CIMAFoundation/dev
- Merge branch 'master' into dev
- Docs: updated documentation
- Update doc.md
- Merge pull request #5 from CIMAFoundation/dev
- chore: Add API documentation PDF and update data model image
- Merge pull request #4 from CIMAFoundation/dev
- Merge pull request #3 from CIMAFoundation/dev-documented
- doc-pages
- init docs
- chore: Add django_extensions to INSTALLED_APPS and added some documentation
-e ## v0.3.15 

 
- New: Init cache system with pylibmc
- New: add and mod filters
- Merge pull request #9 from CIMAFoundation/master
- Merge pull request #8 from CIMAFoundation/dev
- Merge pull request #7 from CIMAFoundation/master
- Merge remote-tracking branch 'origin/dev' into dev
- Update: Add FilterByLayerRole to LayerAdmin list_filter
- Upgrade: updated tools for importing layers
- Merge pull request #6 from CIMAFoundation/dev
- Merge branch 'master' into dev
- Docs: updated documentation
- Update doc.md
- Merge pull request #5 from CIMAFoundation/dev
- chore: Add API documentation PDF and update data model image
- Merge pull request #4 from CIMAFoundation/dev
- Merge pull request #3 from CIMAFoundation/dev-documented
- doc-pages
- init docs
- chore: Add django_extensions to INSTALLED_APPS and added some documentation
## v0.3.14 

 
- chore: Update authorization header in ToolsViewsSet
## v0.3.13 

 
- chore: Add filters for category and layer manager in LayerAdmin
## v0.3.12 

 
- WIP: move folder
- WIP
- build: added dockercompose for simulating portal
- chore: Update docker-compose.yaml for backend network configuration
- WIP: environment configurations
-e ## v0.3.11 

 
- chore: Update logging configuration in settings.py and views.py
-e ## v0.3.7 

 
- WIP: update sentinel
- aggiunti user e pwd di sentinel
## v0.3.5 

 
- fixing dockerfile
- Bump version to v0.3.5
- fixing requirements
- Bump version to v0.3.5
- Merge branch 'dev'
- Update Dewetra Admin site header with revision and version. Added release script
- added chart in django
- add setting
- add setting
## v0.3.5 

 
- fixing requirements
- Bump version to v0.3.5
- Merge branch 'dev'
- Update Dewetra Admin site header with revision and version. Added release script
- added chart in django
- add setting
- add setting
## v0.3.5 

 
- Merge branch 'dev'
- Update Dewetra Admin site header with revision and version. Added release script
- added chart in django
- add setting
- add setting
