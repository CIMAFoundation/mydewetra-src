# DEWETRA3 BACKEND

backend di dewetra3 sviluppato con nuovo framework acroweb3

## Installation

[INSTALLATION](/docs/installation.md)

## Documents

[DOCUMENTS](/docs/doc.md)

## Git Feature Workflow

The Git Feature Workflow is a methodology that allows for an organized and systematic implementation of features in the development project. This workflow is based on the use of specific branches for each new feature, ensuring that development remains isolated and independent until it is ready to be integrated into the main codebase.

### Branch Structure

•  master: The main branch that contains the production code.

•  dev: The development branch that contains code integrated from various features and updates in preparation for the next release.

•  feature-: Temporary branches created to develop new features.

### Steps of the Git Feature Workflow

#### 1. Creating the Feature Branch

When starting work on a new feature, create a separate branch from the dev branch.
Naming convention: feature-<feature-name>.

```bash
git checkout -b feature-<feature-name> dev
```

#### 2. Developing the Feature

Within the feature-<feature-name> branch, develop the new feature.
Make frequent commits to track changes and facilitate the review process.

#### 3. Synchronizing with the Main Branch

During the development of the feature, it may be necessary to update the feature-<feature-name> branch with the latest changes from the dev branch.

```bash
git fetch origin
git checkout dev
git pull
git checkout feature-<feature-name>
git rebase dev
```

#### 4. Testing

Ensure that the feature is fully tested within the feature-<feature-name> branch.
Fix any bugs that emerge during testing.

#### 5. Creating a Pull Request (PR)

When the feature is ready, create a pull request from the feature-<feature-name> branch to the dev branch.
Describe the changes made, improvements, and any issues resolved in the PR.

#### 6. Code Review

The development team reviews the pull request, comments, and requests any changes.
Make the requested changes and update the PR.

#### 7. Merging the Feature

Once the pull request is approved, merge the feature-<feature-name> branch into the dev branch.
Use the --no-ff command to maintain the branch history.

```bash
git checkout dev
git merge --no-ff feature-<feature-name>
git push origin dev
```

#### 8. Releasing the Release

When ready for a new release, the dev branch is tested and integrated into the main branch.

```bash
git checkout main
git merge --no-ff dev
git push origin main
```

#### 9. Deleting the Branch

After the merge, delete the feature-<feature-name> branch to keep the repository clean.

git branch -d feature-<feature-name>
git push origin --delete feature-<feature-name>

Advantages of the Git Feature Workflow
•  Feature Isolation: Each new feature is developed in a separate branch, reducing the risk of conflicts with existing code.

•  Ease of Review: Pull requests allow for a detailed review of the code before it is integrated into the main branch.

•  Traceability: Frequent commits and branch history provide detailed traceability of feature development.

By following the Git Feature Workflow with the use of the dev branch, the development process will be more structured, clear, and collaborative, contributing to the overall quality and stability of the project.

### Commits guideline

**Important**:

* commits without task id (link for asana) are not allowed (except docs and libs version updates)
* keep application version bump as separate commits

Make the changes to the code and tests and then commit to your branch. Be sure to follow the commit message conventions.

Commit message summaries must follow this basic format:

```git
Tag: Message [Action #1234]
```

The `Tag` is one of the following:

* `Fix` - for a bug fix.
* `Docs` - changes to documentation only.
* `Build` - changes to build process only.
* `New` - implemented a new feature.
* `Upgrade` - for a dependency upgrade.

* `Message` is short description of what have been done

`Action` - depends on used task tracking, but in general case:

* `refs` - link commit to task
* `fixes` - closes task, moving it to testing state

The message summary should be a one-sentence description of the change. The issue number should be mentioned at the end. If the commit doesn't completely fix the issue, then use `[refs #1234]` instead of `[fixes #1234]`.

Here are some good commit message summary examples:

```git
Build: Update Travis to only test Node 0.10 [refs #734]
Fix: Semi rule incorrectly flagging extra semicolon [fixes #840]
Upgrade: Esprima to 1.2, switch to using Esprima comment attachment [fixes #730]
Docs: Updated file README.md
```

The commit message format is important because these messages are used to create a changelog later for each release. The tag and issue number help to create more consistent and useful changelogs.

###USING WITH CONDA
#DELETING OLD CONDAS
conda remove --prefix .venv --all
rm -rf .venv

#INSTALL DEPENDENCIES FOR TROUBLESHOOTING
conda install -c conda-forge gdal
conda list gdal
find $CONDA_PREFIX -name "libgdal.*"
echo 'export GDAL_LIBRARY_PATH=$CONDA_PREFIX/lib/libgdal.dylib' >> ~/.zshrc\nsource ~/.zshrc
conda install -c conda-forge librdkafka
find $(gdal-config --prefix) -name "libgdal.*"
pip install GDAL==$(gdal-config --version) --global-option=build_ext --global-option="-I/usr/include/gdal"

#RECREATING ENVS
conda env create --prefix .venv -f environment.yml

#SAVING ENVS
conda env export --prefix .venv > environment.yml


#DEBUGGING
change INTERACTIVE_DEBUG to True
rollout restart deployments
attach to pod with visual studio to path code
and click on play debug