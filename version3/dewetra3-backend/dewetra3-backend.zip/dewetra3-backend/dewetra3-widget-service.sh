#!/bin/bash

echo "Starting widget service"
export DJANGO_SETTINGS_MODULE=dewetra3.settings
python dewetra3/widget/service.py
