#!/bin/bash

# Set the version for the Docker image
VERSION=${1:-latest}
IMAGE_NAME="dewetra3-backend:$VERSION"

# Set the environment (default is production)
ENVIRONMENT=${2:-production}

# Check if the SSH private key file exists
if [ ! -f ~/.ssh/id_rsa ]; then
    echo "SSH private key not found at ~/.ssh/id_rsa. Please ensure the file exists and try again."
    exit 1
fi

# Check if the image with the specified version already exists
if docker images | grep -q "$IMAGE_NAME"; then
    echo "Image $IMAGE_NAME already exists. Stopping and removing any running containers..."

    # Find and stop running containers using the image
    CONTAINER_IDS=$(docker ps -q --filter ancestor="$IMAGE_NAME")
    if [ -n "$CONTAINER_IDS" ]; then
        docker stop $CONTAINER_IDS
        docker rm $CONTAINER_IDS
    fi

    echo "Deleting the existing image $IMAGE_NAME..."
    docker rmi -f "$IMAGE_NAME"
    if [ $? -ne 0 ]; then
        echo "Failed to delete existing image $IMAGE_NAME. Please check your Docker setup and try again."
        exit 1
    fi
fi

# Export the SSH private key as an environment variable
export SSH_PRIVATE_KEY="$(cat ~/.ssh/id_rsa)"

# Export the version as an environment variable
export VERSION

# Build and run the Docker Compose stack based on the environment
if [ "$ENVIRONMENT" = "development" ]; then
    docker-compose -f docker-compose.yaml -f docker-compose.override.yml up --build
else
    docker-compose up --build
fi

# Unset the SSH private key environment variable for security reasons
unset SSH_PRIVATE_KEY

# Inform the user
echo "Docker Compose stack is running with image version: $VERSION in $ENVIRONMENT environment"
