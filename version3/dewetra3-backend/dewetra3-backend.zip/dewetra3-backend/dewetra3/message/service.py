'''
Created on Oct 09, 2024

@author: dario
'''
import websocket
from acroweb3_api import get_logger, get_portal_backend_url
from acroweb3.portal_tools import PortalServiceClient
import time
import threading
import django
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dewetra3.settings')
django.setup()

_logger = get_logger(__name__)


class MessageService(threading.Thread):
    '''
    cbe monitoring class
    '''

    def __init__(self):
        '''
        constructor
        '''
        super(MessageService, self).__init__()

    def __connect(self):
        ws_url = os.getenv('MESSAGE_DDS_WEBSOCKET', 'wss://messages.cimafoundation.org/ddsws')
        _logger.info(f'MESSAGE SERVICE: connecting to acquisition websocket {ws_url}')

        self.ws = websocket.WebSocketApp(ws_url,
                                         on_message=lambda ws, message: self.on_message(
                                             ws, message),
                                         on_error=lambda ws, error: self.on_error(
                                             ws, error),
                                         on_close=lambda ws: self.on_close(ws))

        self.ws.run_forever()

    def run(self):

        self.__connect()

    def on_error(self, ws, error):
        _logger.error('MESSAGE SERVICE: websocket error: %s' % error)

    def on_close(self, ws):
        _logger.info(
            'MESSAGE SERVICE: websocket closed. reconnectiong in 10 seconds')
        time.sleep(10)
        self.__connect()

    def on_message(self, ws, message):
        try:
            toks = message.split(';')
            if len(toks) == 2:
                data_id = toks[1]
                _logger.debug(
                    f'MESSAGE SERVICE: sending notification for: {data_id}')
                try:
                    PortalServiceClient(get_portal_backend_url()).send_portal_notification(
                        '__ALL__', 'dewetra3', f'{message}')
                except Exception as e:
                    _logger.error(f'error sending notification', exc_info=e)
            else:
                _logger.error(
                    f'MESSAGE SERVICE: received invalid acquisition message: {message}')

        except Exception as e:
            _logger.error(
                f"MESSAGE SERVICE: ERROR managing message {str(message)}", exc_info=e)


if __name__ == '__main__':

    MessageService().start()
