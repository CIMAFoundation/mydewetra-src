"""dewetra3 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from acroweb3_api.admin_auth import bypass_admin_login
from acroweb3_api.views import acroweb3_to_portal_urls
from django.contrib import admin
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.urls import path, re_path
from django.urls.conf import include
from drf_yasg import openapi
from drf_yasg.views import get_schema_view
from rest_framework import permissions

from dewetra3.charts.views import chart_app_router
from dewetra3.commons.system_status import system_status_router
from dewetra3.commons.views import LogView
from dewetra3.dds.views import dds_app_router
from dewetra3.exposure.views import scenario_router
from dewetra3.floodcat.views import flood_cat_router
from dewetra3.menu.views import menu_app_router
from dewetra3.sentinel.views import sentinel_app_router
from dewetra3.tools.views import tool_app_router
from dewetra3.views import (AsyncProxyView, CapabilitiesView,
                            ExternalProxyView, dewetra_app_router)
from dewetra3.widget.views import widget_app_router

schema_view = get_schema_view(
    openapi.Info(
        title="Dewetra backend api",
        default_version='v1',
        description="Dewetra Portal backend API",
        terms_of_service="https://www.cimafoundation.org",
        contact=openapi.Contact(email="dario.rubado@cimafoundation.org"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
    permission_classes=[permissions.AllowAny],
)


urlpatterns = [
    re_path(r'^docs/swagger(?P<format>\.json|\.yaml)$',
            schema_view.without_ui(cache_timeout=0), name='schema-json'),
    re_path(r'^docs/swagger/$', schema_view.with_ui('swagger',
                                                    cache_timeout=0), name='schema-swagger-ui'),
    re_path(r'^docs/redoc/$', schema_view.with_ui('redoc',
                                                  cache_timeout=0), name='schema-redoc'),

    path('prometheus/', include('django_prometheus.urls')),
    path('dewapi/', include(dewetra_app_router.urls)),
    re_path(r'^dewapi/server/(?P<pk>\d+)/proxy(?:/(?P<path>.*))?$',
            AsyncProxyView.as_view()),
    path('dewapi/server/<int:pk>/capabilities', CapabilitiesView.as_view()),
    path(
        'dewapi/proxy/',
        ExternalProxyView.as_view(),
        name='external-proxy'
    ),
    path('widgetapi/', include(widget_app_router.urls)),
    path('ddsapi/', include(dds_app_router.urls)),
    path('sentinelapi/', include(sentinel_app_router.urls)),
    path('chartapi/', include(chart_app_router.urls)),
    path('toolsapi/', include(tool_app_router.urls)),
    path('floodcatapi/', include(flood_cat_router.urls)),
    path('exposure-analysis/', include(scenario_router.urls)),
    path('menu/', include(menu_app_router.urls)),
    path('commons/log/', LogView.as_view()),
    path('common/system_status/', include(system_status_router.urls)),

    re_path(r'^admin/login/', bypass_admin_login, name='bypass_admin_login'),
    re_path(r'^admin/', admin.site.urls),
]

urlpatterns += acroweb3_to_portal_urls()

urlpatterns += staticfiles_urlpatterns()
