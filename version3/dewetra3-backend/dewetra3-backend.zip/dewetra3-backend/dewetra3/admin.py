
import urllib
from typing import Any

from django.contrib import admin
from django.db import models
from django.utils.html import format_html
from django_json_widget.widgets import JSONEditorWidget

from dewetra3.models import *
from dewetra3.models import Layer, LayerCategory, LayerManager
from version import REVISION, VERSION

admin.site.site_header = 'Dewetra Admin - ' + VERSION + '.' + REVISION


class IsEnabledFilter(admin.SimpleListFilter):
    title = 'Is Enabled'
    parameter_name = 'enabled'

    def default_value(self):
        return 'yes'

    def lookups(self, request, model_admin):
        return (
            ('yes', 'Enabled'),
            ('no', 'Disabled'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'yes':
            return queryset.filter(enabled=True)
        elif self.value() == 'no':
            return queryset.filter(enabled=False)


class FilterByCategory(admin.SimpleListFilter):
    title = 'Category'
    parameter_name = 'category'

    def lookups(self, request, model_admin):
        categories = LayerCategory.objects.all()
        return [(category.name, category.name) for category in categories]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(category__name=self.value())
        return queryset


class FilterByLayerManager(admin.SimpleListFilter):
    title = 'Layer Manager'
    parameter_name = 'layermanager'

    def lookups(self, request, model_admin):
        layermanagers = LayerManager.objects.all()
        return [(layermanager.name, layermanager.name) for layermanager in layermanagers]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(layermanager__name=self.value())
        return queryset


class FilterByLayerRole(admin.SimpleListFilter):
    title = 'Role'
    parameter_name = 'role'

    def lookups(self, request, model_admin):
        roles = Role.objects.all()
        return [(role.name, role.name) for role in roles]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(roles__name=self.value())
        return queryset


class FilterByEvent(admin.SimpleListFilter):
    title = 'Event'
    parameter_name = 'event'

    def lookups(self, request, model_admin):
        events = Event.objects.all()
        return [(event.name, event.name) for event in events]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(event__name=self.value())
        return queryset


class EventLayerInline(admin.TabularInline):
    model = Layer.event.through
    extra = 0
    autocomplete_fields = ['layer']


class EventAdmin(admin.options.ModelAdmin):
    save_as = True
    list_max_show_all = 1000
    list_per_page = 200
    search_fields = ['name']
    inlines = [EventLayerInline]
    list_filter = [IsEnabledFilter, FilterByLayerRole]
    list_display = ['name', 'descr', 'floodcatid']

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        return queryset.prefetch_related('layers')


class AppAdmin(admin.options.ModelAdmin):
    save_as = True
    list_max_show_all = 1000
    list_per_page = 200
    search_fields = ['name']
    formfield_overrides = {
        # fields.JSONField: {'widget': JSONEditorWidget}, # if django < 3.1
        models.JSONField: {'widget': JSONEditorWidget},
    }


class ServerAdmin(admin.options.ModelAdmin):
    save_as = True
    list_max_show_all = 1000
    list_per_page = 200
    search_fields = ['name', 'descr', 'url']
    list_display = ['name', 'descr', 'url']


class GenericManagerAdmin(admin.options.ModelAdmin):
    save_as = True
    list_max_show_all = 1000
    list_per_page = 200
    search_fields = ['name', 'descr', 'component']
    list_display = ['name', 'descr', 'component']
    formfield_overrides = {
        models.JSONField: {'widget': JSONEditorWidget},
    }


class LayerTagInline(admin.TabularInline):
    model = Layer.tags.through
    extra = 1


class LayerAdmin(admin.options.ModelAdmin):
    save_as = True
    list_max_show_all = 1000
    list_per_page = 200
    search_fields = ['name', 'dataid', 'descr']
    list_display = ['name', 'dataid', 'server', 'enabled']
    list_filter = [IsEnabledFilter, FilterByCategory,
                   FilterByLayerManager, FilterByLayerRole]
    filter_horizontal = ['roles', 'related',
                         'inspirethemes', 'hazards', 'dracategories', 'paths']
    inlines = [LayerTagInline]

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        # By default, filter to display only enabled entries
        return queryset

    def custom_name(self, obj: Layer):
        # Customize the display name with other fields
        return f"{obj.name} - {obj.layermanager}"

    formfield_overrides = {
        # fields.JSONField: {'widget': JSONEditorWidget}, # if django < 3.1
        models.JSONField: {'widget': JSONEditorWidget},
    }


class WidgetAdmin(admin.options.ModelAdmin):
    save_as = True
    autocomplete_fields = ['layer']


class LayerInLine(admin.TabularInline):
    model = Layer.roles.through
    extra = 0
    autocomplete_fields = ['layer']


class RoleAdmin(admin.options.ModelAdmin):
    inlines = [LayerInLine]
    save_as = True

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        return queryset.prefetch_related('layers')


class LayerInLineForScenario(admin.TabularInline):
    model = Scenario.exposures.through
    extra = 0
    autocomplete_fields = ['layer']
    verbose_name = "Scenario Exposure"
    verbose_name_plural = "Scenario Exposure"

    # will work only if the autocomplete_fields is setted off
    # def formfield_for_foreignkey(self, db_field, request, **kwargs):
    #    if db_field.name == 'layer':
    #        kwargs["queryset"] = Layer.objects.filter(category__name__icontains='scenario')
    #    return super().formfield_for_foreignkey(db_field, request, **kwargs)


class LayerInLineForScenarioHazard(admin.TabularInline):
    model = Scenario.hazards.through
    verbose_name = "Scenario Hazard Relationship"
    extra = 0
    autocomplete_fields = ['layer']
    verbose_name = "Scenario Hazard"
    verbose_name_plural = "Scenario Hazards"

    # will work only if the autocomplete_fields is setted off
    # def formfield_for_foreignkey(self, db_field, request, **kwargs):
    #    if db_field.name == 'layer':
    #        kwargs["queryset"] = Layer.objects.filter(category__name__icontains='scenario')
    #    return super().formfield_for_foreignkey(db_field, request, **kwargs)


class ScenarioAdmin(admin.ModelAdmin):
    list_display = ('id', 'aoisize',)
    search_fields = ('name', 'descr')
    list_display = ['name', 'id', 'descr', 'aoisize']
    inlines = [LayerInLineForScenario, LayerInLineForScenarioHazard]
    exclude = ('exposures', 'hazards')
    save_as = True


class IconAdmin(admin.ModelAdmin):
    list_display = ['id', 'icon_svg_view', 'name']
    search_fields = ['name']
    save_as = True
    list_max_show_all = 1000

    def icon_svg_view(self, obj):
        if not obj.value:
            return None
        svg_encoded = urllib.parse.quote(obj.value)
        url = f'data:image/svg+xml;utf8,{svg_encoded}'

        return format_html(f'<img src="{url}" width="30" height="30" style="background-color:white" />')

    icon_svg_view.short_description = 'Preview'


admin.autodiscover()


admin.site.register(Server, ServerAdmin)
admin.site.register(Icon, IconAdmin)
admin.site.register(Tag, AppAdmin)
admin.site.register(Source, AppAdmin)
admin.site.register(Role, RoleAdmin)
admin.site.register(InspireTheme, AppAdmin)
admin.site.register(Hazard, AppAdmin)
admin.site.register(DataType, AppAdmin)
admin.site.register(DraCategory, AppAdmin)
admin.site.register(Path, AppAdmin)
admin.site.register(LayerCategory, AppAdmin)
admin.site.register(GeoScale, AppAdmin)
admin.site.register(Event, EventAdmin)
admin.site.register(Tool, AppAdmin)


admin.site.register(LegendManager, GenericManagerAdmin)
admin.site.register(PropertiesManager, GenericManagerAdmin)
admin.site.register(LayerManager, GenericManagerAdmin)
admin.site.register(InfoManager, GenericManagerAdmin)
admin.site.register(MetadataManager, GenericManagerAdmin)
admin.site.register(ChartManager, GenericManagerAdmin)
admin.site.register(MapManager, GenericManagerAdmin)

admin.site.register(Layer, LayerAdmin)

admin.site.register(Scenario, ScenarioAdmin)

admin.site.register(Widget, WidgetAdmin)
