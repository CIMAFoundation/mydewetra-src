# Description: Views for the tools app

import logging
import os
import json
import requests
from acroweb3.sentinel.client import SentinelClient
from acroweb3_api.auth import AcrowebAuthData
from django.http import HttpResponse
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.routers import DefaultRouter
from urllib.parse import quote
from io import BytesIO
import tempfile
from dewetra3.models import Tool, Server
from dewetra3.settings import (CHARTS_SERVICE_URL, K8S_NAMESPACE, MEDIA_ROOT,
                               PRINT_SERVICE_URL, SENTINEL_SERVICE_PASSWORD,
                               SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER)
from dewetra3.tools.layer_publish_utils import (create_uploaded_layer_in_django_orm, 
                publish_geotiff, build_workspace_name_for_user)
from dewetra3.menu.data import StaticLayerData

logger = logging.getLogger(__name__)

from dewetra3.commons.logs import log
import shutil
import threading


def _remove_temp_path(path):
    """Remove the temporary directory and all its contents."""
    try:
        if os.path.exists(path):
            if os.path.isfile(path):
                os.remove(path)
                logger.info(f"Temporary file {path} removed.")
            else:
                shutil.rmtree(path)
                logger.info(f"Temporary directory {path} removed.")
        else:
            logger.info(f"Temporary path {path} does not exist. Nothing to remove.")
    except Exception as e:
        logger.error(f"Error removing temporary path: {e}")


# viewset for tools

class ToolsViewsSet(viewsets.ViewSet):
    """
    A viewset for handling tools-related operations.
    """
    
    parser_classes = (MultiPartParser, FormParser, JSONParser)

    permission_classes = [permissions.AllowAny]
    
    def _manage_print_url(self, print_type):
        if print_type == 'pdf':
            url = PRINT_SERVICE_URL+'/pdf'
            content_type = 'application/pdf'
        elif print_type == 'image':
            url = PRINT_SERVICE_URL+'/print/image'
            content_type = 'image/png'
        else:
            return Response({'error': 'Invalid print type'}, status=400)
        
        return url, content_type
        
    def _create_print_request(self, request):
        
        template_data = request.data.get('templateData', None)
        portal_user = request.data.get('portalUser', 'dario.rubado@cimafoundation.org')
        timeout = request.data.get('timeout', 3000)
        
        url = request.data.get('url', f'http://cima-service-portal.{K8S_NAMESPACE}/dewetra3/#/report?portaluser={portal_user}')
        
        params = {
            'url': url,
            'templateData': template_data,
            'timeout': timeout
        }
        
        return params
    
    def _send_print_to_mycloud(self, response, content_type, print_type, name, description):
        url= 'http://mycloud-backend:8000/private/document/upload/'
        data={}
        data["name"] = name
        data["source"] = "Dewetra"
        data["description"] = description
        data["configuration"] = 1
        file = BytesIO(response.content)
        file.name = 'document.pdf' if print_type == 'pdf' else 'document.png'
        response_mycloud = requests.post(
            url, 
            data=data, 
            files={'file': (file.name, file, content_type)}
        )
        
        return response_mycloud

    @action(detail=False, methods=['post'], url_path='upload_image')
    def upload_image(self, request):
        """
        Uploads an image file.

        Args:
            request (HttpRequest): The HTTP request object.

        Returns:
            HttpResponse: The response containing the file path.
        """
        file_obj = request.data.get('file')
        if not file_obj:
            return Response({'error': 'no file provided'}, status=400)

        file_path = f'/tmp/{file_obj.name}'
        with open(file_path, 'wb') as f:
            for chunk in file_obj.chunks():
                f.write(chunk)

        return Response({'file_path': file_path})

    @action(detail=False, methods=['post'], url_path='print/(?P<print_type>[^/.]+)')
    def print(self, request, print_type):
        """
        Prints the request data using the specified print type (PDF or image).
        """
        logger.info(f"[TOOLS->PRINT] Print Tool: {print_type}")

        template_data = request.data.get('templateData', None)
        portal_user = request.data.get('portalUser', 'dario.rubado@cimafoundation.org')
        timeout = request.data.get('timeout', 3000)

        url = request.data.get(
            'url', f'http://cima-service-portal.{K8S_NAMESPACE}/dewetra3/#/report?portaluser={portal_user}')

        params = {
            'url': url,
            'templateData': template_data,
            'timeout': timeout
        }

        logger.info(f"[TOOLS->PRINT] Print Tool: URL: {params['url']}")

        if print_type == 'pdf':
            url = PRINT_SERVICE_URL+'/pdf'
            content_type = 'application/pdf'
        elif print_type == 'image':
            url = PRINT_SERVICE_URL+'/print/image'
            content_type = 'image/png'
        else:
            return Response({'error': 'Invalid print type'}, status=400)

        # Sending the request to the print service
        response = requests.post(url, json=params)

        # Return the response from the print service
        if response.status_code == 200:
            logger.info(
                f"[TOOLS->PRINT] response status: {response.status_code}")
            return HttpResponse(
                response.content,
                content_type=content_type,
                status=response.status_code
            )
        else:
            logger.error(
                f"[TOOLS->PRINT] response status: {response.status_code}")
            logger.error(
                f"[TOOLS->PRINT] response content: {response.content}")
            return Response(response.content, status=response.status_code)
        
    @action(detail=False, methods=['post'], url_path='mycloud/(?P<print_type>[^/.]+)')
    def mycloud(self, request, print_type):
        """
        Prints the request data using the specified print type (PDF or image).
        """
        logger.info(f"[TOOLS->MYCLOUD] MyCloud Tool: {print_type}")

        params = self._create_print_request(request)
        
        title = request.data.get('title', 'Report')
        description = request.data.get('description', 'Report generated by Dewetra3')

        logger.info(f"[TOOLS->MYCLOUD] Print Tool: URL: {params['url']}")

        url, content_type = self._manage_print_url(print_type)

        # Sending the request to the print service
        response = requests.post(url, json=params)

        # Return the response from the print service
        if response.status_code == 200:
            logger.info(f"[TOOLS->MYCLOUD] response status: {response.status_code}")
            
            response_mycloud = self._send_print_to_mycloud(response, content_type, print_type, title, description)
            
            if response_mycloud.status_code == 200:
                logger.info(f"[TOOLS->MYCLOUD] response status: {response_mycloud.status_code}")
                return Response(response_mycloud.content, status=response_mycloud.status_code)
            else:
                logger.error(
                    f"[TOOLS->MYCLOUD] response status: {response_mycloud.status_code}")
                logger.error(
                    f"[TOOLS->MYCLOUD] response content: {response_mycloud.content}")
                return Response(response_mycloud.content, status=response_mycloud.status_code)
            
        else:
            logger.error(
                f"[TOOLS->MYCLOUD] response status: {response.status_code}")
            logger.error(
                f"[TOOLS->MYCLOUD] response content: {response.content}")
            return Response(response.content, status=response.status_code)
        

    @action(detail=False, methods=['post', 'put'], url_path='upload-file')
    def upload_geotiff(self, request):
        """
        Uploads a georeferenced file using a temporary directory inside the pod.
        """
        try:
            chunk = request.data.get('chunk')
            file_id = request.data.get('fileId')
            chunk_index = request.data.get('chunkIndex')
            file_name = request.data.get('fileName')
            file_name = file_name.split('.')[0]
            file_extension = request.data.get('fileExtension')
            is_last_chunk = request.data.get('isLastChunk')

            if isinstance(is_last_chunk, str):
                is_last_chunk = is_last_chunk.lower() == 'true'
        except Exception as e:
            return Response({'error': 'Invalid request data'}, status=400)

        # Verifica i campi richiesti
        required_fields = {
            'chunk': chunk,
            'chunk_index': chunk_index,
            'file_id': file_id,
            'file_name': file_name,
            'file_extension': file_extension
        }
        
        log(request ,'info', f'Upload_geotiff {str(chunk_index)}', )

        for field_name, field_value in required_fields.items():
            if not field_value:
                return Response({'error': f'no {field_name} provided'}, status=400)

        # Creazione di una cartella temporanea
        temp_dir = tempfile.gettempdir()  # Ottiene la directory temporanea del sistema
        file_path = os.path.join(temp_dir, f'{file_id}.part')

        # Scrivi il chunk nel file temporaneo
        with open(file_path, 'ab') as temp_file:  # 'ab' -> append in modalità binaria
            temp_file.write(chunk.read())

        if is_last_chunk:
            user_data: AcrowebAuthData = request.user
            file_prefix = user_data.user
            
            new_name = f'{file_prefix}{file_name}.{file_extension}'
            new_file_path = os.path.join(temp_dir, new_name)

            if os.path.exists(new_file_path):
                os.remove(new_file_path)

            os.rename(file_path, new_file_path)
            log(request ,'info', f'Upload_geotiff {str(new_file_path)}', )
            #schedule the file removal after 1 hour
            seconds_before_removal = int(os.environ.get('UPLOADED_DATA_REMOVAL_TIME', 3600))
            threading.Timer(seconds_before_removal, _remove_temp_path, args=[new_file_path]).start()
            logger.info(f"Temporary file {new_file_path} scheduled for removal in {seconds_before_removal} seconds.")

            return Response({'file_name': new_name, 'message': 'File uploaded'}, status=200)

        return Response({'message': 'chunk uploaded successfully'}, status=200)

    @action(detail=False, methods=['post'], url_path='publish-layer-to-geoserver')
    def publish_layer_to_geoserver(self, request):
        """
        Publishes a layer to the GeoServer instance.

        """
        user_data: AcrowebAuthData = request.user

        tool_id = request.data.get('toolId')
        file_name = request.data.get('fileName')
        tool_props = Tool.objects.get(id=tool_id).props
        log(request ,'info', f'Publish_layer_to_geoserver {str(file_name)}', )
        if not tool_props:
            return Response({'error': 'no tool properties provided'}, status=400)
        
        geoserver_url = tool_props['geoserver_url']
        geoserver_user = tool_props['geoserver_user']
        geoserver_pwd = tool_props['geoserver_pwd']
        # geoserver_workspace = tool_props['geoserver_workspace']
        geoserver_workspace = build_workspace_name_for_user(user_data)
        server = Server(url=geoserver_url, user=geoserver_user, password=geoserver_pwd)

        file_prefix = user_data.user
        layer_name = os.path.splitext(file_name)[0][len(file_prefix):]

        result = publish_geotiff(file_name, server, geoserver_workspace, None, layer_name)

        if 'error' in result:
            return Response(result, status=400)
        else:
            return Response(result, status=200)

    @action(detail=False, methods=['post'], url_path='publish-layer-to-dewetra')
    def publish_layer_to_dewetra(self, request):
        """
        Publishes a layer to the Dewetra ORM instance.

        """
        tool_id = request.data.get('toolId')
        file_name = request.data.get('fileName')
        tool_props = Tool.objects.get(id=tool_id).props
        log(request ,'info', f'Publish_layer_to_dewetra {str(tool_id)}', )
        if not tool_props:
            return Response({'error': 'no tool properties provided'}, status=400)

        # Create the layer in the Django ORM
        result = create_uploaded_layer_in_django_orm(file_name, tool_props)

        if 'error' in result:
            log(request ,'error', f'Publish_layer_to_dewetra ' )
            return Response(result, status=400)
        else:
            log(request ,'info', f'Publish_layer_to_dewetra ' )
            return Response(result, status=200)
        
        
    @action(detail=False, methods=['get'], url_path='thr_monitoring/(?P<tool_id>[^/.]+)')
    def thr_monitoring(self, request, tool_id):
        '''
        Retrieves thr exceeding monitoring data based on the provided parameters.

        Args:
            request (HttpRequest): The HTTP request object.
            sensor_class (str): The class of the sensor.

        Returns:
            Response: The HTTP response object containing the pluvio monitoring data.

        Raises:
            ValueError: If the 'aggr_layer' parameter is missing in the request.
        '''
        
        tool_props = Tool.objects.get(id=tool_id).props

        thr_group = tool_props.get('thr_group', None)
        serie_id = tool_props.get('serie_id', None)
        sensor_class = tool_props.get('sensor_class', None)
        sensors_group = tool_props.get('sensors_group', None)
        timestamp = request.query_params.get('dt', None)


        sensors_group = quote(sensors_group, safe='')
        thr_group = quote(thr_group, safe='')

        client = SentinelClient(
            SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
        endpoint = f'thresholds/events/{sensors_group}/{thr_group}'
        sensors = client.get(endpoint)


        return Response(json.loads(sensors), status=status.HTTP_200_OK)
    
    @action(detail=False, methods=['get'], url_path='monitoring/(?P<tool_id>[^/.]+)')
    def pluvio_monitoring(self, request, tool_id):
        '''
        Retrieves pluvio monitoring data based on the provided parameters.

        Args:
            request (HttpRequest): The HTTP request object.
            sensor_class (str): The class of the sensor.

        Returns:
            Response: The HTTP response object containing the pluvio monitoring data.

        Raises:
            ValueError: If the 'aggr_layer' parameter is missing in the request.
        '''
        
        tool_props = Tool.objects.get(id=tool_id).props

        thr_group = tool_props.get('thr_group', None)
        serie_id = tool_props.get('serie_id', None)
        sensor_class = tool_props.get('sensor_class', None)
        sensors_group = tool_props.get('sensors_group', None)
        timestamp = request.query_params.get('dt', None)

        client = SentinelClient(
            SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
        sensors = client.features_geojson(
            sensors_group, thr_group, sensor_class, ts=timestamp)

        return Response(json.loads(sensors), status=status.HTTP_200_OK)


# router for tools
tool_app_router = DefaultRouter()

tool_app_router.register('', ToolsViewsSet, basename='')
