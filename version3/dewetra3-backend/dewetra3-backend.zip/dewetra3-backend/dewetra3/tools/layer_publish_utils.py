import logging
import os
from urllib.parse import urlparse
import tempfile
from django.conf import settings
import geopandas
from geo.Geoserver import Geoserver, GeoserverException
from dewetra3.models import Layer, Role, Server, LayerCategory, Tag,InfoManager, LegendManager, PropertiesManager, MetadataManager, MapManager, LayerManager, ChartManager
from acroweb3_api.auth import AcrowebAuthData
from typing import Optional
import requests
import xmltodict
import pyogrio


logger = logging.getLogger(__name__)

UPLOAD_DIR = os.path.join(settings.MEDIA_ROOT, 'geotiffs')

# ===================================UTILITY DJANGO============================================

def create_dataid(file_name):
    """
    Create a dataid from the file name.
    """
    return file_name.split('.')[0].replace(' ', '_').replace(
        '-', '_').replace('.', '_').replace(',', '_').replace(';', '_').replace(':', '_')

def create_uploaded_layer_in_django_orm(file_name, tool_props):
    """
    Create a new layer in the Django ORM.
    """
    try:
        name = file_name.split('.')[0]
        parsed_url = urlparse(tool_props['geoserver_url'])
        
        dataid = create_dataid(file_name)
        lonw = 0.0
        lone = 0.0
        lats = 0.0
        latn = 0.0
        
        if parsed_url.port:
            host_and_port = f"{parsed_url.hostname}:{parsed_url.port}"
        else:
            host_and_port = parsed_url.hostname

        # Get the server
        servers = Server.objects.filter(url__contains=host_and_port)
        if not servers:
            server = None
        else:
            server = servers[0]
        # get the role
        roles = Role.objects.filter(name__contains=tool_props['role'])
        if not roles:
            role = None
        else:
            role = roles[0]
            
        category = LayerCategory.objects.get(name='static')
        
        tag, tag_created = Tag.objects.get_or_create(
            name='geotiff',
            descr='geotiff'
            )
        if not tag_created:
            logger.info(f"Tag {tag} already exists!")
        
        info_manager = InfoManager.objects.get_or_create(name='WMSInfoComponent')[0]
        
        legend_manager = LegendManager.objects.get_or_create(name='StaticWMSLegendComponent')[0]
        
        layer_manager = LayerManager.objects.get_or_create(name='STATICWMSLayerManager')[0]
        
        map_manager = MapManager.objects.get_or_create(name='StaticWMSMapComponent')[0]

        layer_uploaded = Layer.objects.create(
            dataid=dataid,
            name=name,
            descr=f'DESCR_{name}',
            server=server,
            lats=lats,
            latn=latn,
            lonw=lonw,
            lone=lone,
            category=category,            
            infomanager=info_manager,
            legendmanager=legend_manager,
            layermanager =layer_manager,
            mapmanager=map_manager,    
            customprops=tool_props,
            enabled=True,
        )
        layer_uploaded.tags.add(tag)
        layer_uploaded.roles.add(role)
        
        layer_uploaded.save()
        logger.info(f"Layer {name} created in Django ORM successfully!")
        return {'success': f"Layer {name} created in Django ORM successfully!"}
    except Exception as e:
        logger.error(f"An error occurred publishing on django: {e}")
        return {'error': f"An error occurred publishing on django: {e}"}

# ===============================================================================


def _get_geoserver_client(server: Server):
    """
    Get the Geoserver client from the server.
    """
    geoserver_url = server.url
    geoserver_user = server.user
    geoserver_pwd = server.password

    parsed_geoserver_url = urlparse(geoserver_url)

    # Connessione a GeoServer
    geo = Geoserver(geoserver_url, geoserver_user, geoserver_pwd)
    logger.info(f"Connected to GeoServer at {parsed_geoserver_url.geturl()}")
    
    return geo

def _check_workspace(geo:Geoserver, server: Server, workspace: str):
    """
    Check if the workspace exists on the server.
    """
    if workspace:
        try:
            wks = geo.get_workspace(workspace)
        except GeoserverException as e:
            if e.status == 404:
                geo.create_workspace(workspace)
                logger.info(f"Workspace '{workspace}' did not exists on Geoserves. Created successfully")
            else:
                raise Exception(f"Error creating workspace: {e}")

def _check_publish_params(file_name:str, server: Server, workspace: str, style: str, dataid: str = None):
    
    geo = _get_geoserver_client(server)

    # build the path to the GeoPackage file
    temp_dir = tempfile.gettempdir()
    file_path = os.path.join(temp_dir, file_name)

    #check if the file exists and is a GeoPackage
    if not os.path.exists(file_path):
        raise Exception(f"File not found: {file_path}")
    
    # some other checks
    if workspace is None:
        raise Exception(f"Workspace is required")
    if style is None:
        raise Exception(f"Style is required")
    
    _check_workspace(geo, server, workspace)

    # check if the style exists
    try:
        style_obj = geo.get_style(style, workspace)
    except GeoserverException as e:
        raise Exception(f"Style {style} not found on GeoServer")


    
    return geo, file_path

def build_workspace_name_for_user(user_data: AcrowebAuthData):
    prefix = os.environ.get('GEOSERVER_WORKSPACE_PREFIX', 'bricks')
    return f"{prefix}-{user_data.portal}-{user_data.domain}"


def publish_geotiff(file_name:str, server: Server, workspace: str, style: str, dataid: str):
    """
    Publish a GeoTIFF file to GeoServer using a temporary directory.
    """
    style = style if style else 'raster'
    geo, file_path = _check_publish_params(file_name, server, workspace, style, dataid)

    try:
        coveragestore = geo.get_coveragestore(dataid, workspace)
        if coveragestore is not None:
            raise Exception(f"Store {dataid} already exists on workspace {workspace}")
    except GeoserverException as e:
        pass

    # Pubblica il file su GeoServer
    geo.create_coveragestore(path=file_path, workspace=workspace, layer_name=dataid)
    geo.publish_style(dataid, style, workspace) 
    logger.info(f"Layer '{dataid}' published successfully on workspace {workspace} with style '{style}'")
    # os.remove(file_path)



def publish_gpkg(file_name: str, server: Server, workspace: str, style: str, dataid: str):
    """
    Publish a GeoPackage file to GeoServer.
    """
    geo, file_path = _check_publish_params(file_name, server, workspace, style, dataid)

    #check if the file exists and is a GeoPackage
    if not os.path.exists(file_path):
        raise Exception(f"File not found: {file_path}")
    try:
        gpd = geopandas.read_file(file_path, driver='GPKG')
        if gpd is None:
            raise Exception(f"File is not a valid GeoPackage")
        #get the crs
        crs = gpd.crs
        if crs is None:
            raise Exception(f"CRS not found in GeoPackage")
        if crs.srs.lower() != 'epsg:4326':
            raise Exception(f"GeoPackage file not in EPSG:4326")
        #get the layer name
        layers = pyogrio.list_layers(file_path)
        if layers is None or len(layers) == 0:
            raise Exception(f"No layers found in the GeoPackage")
        if len(layers) > 1:
            # search for the layer name
            layer_name = next((item for item in layers if item[0] == dataid), None)
            if layer_name is None:
                raise Exception(f"Layer {dataid} not found in the GeoPackage")
            # remove the other layers from the gpd
            os.remove(file_path)
            gpd.to_file(file_path, layer=dataid, driver='gpkg')
        else:
            layer_name = layers[0][0]
            if layer_name != dataid:
                #create a new file with the layer name
                os.remove(file_path)
                gpd.to_file(file_path, layer=dataid, driver='gpkg')            

        pass

    except Exception as e:
        raise Exception(f"File is not a valid GeoPackage: {e}")
    
    try:
        featurestore = geo.get_datastore(dataid, workspace)
        if featurestore is not None:
            raise Exception(f"Store {dataid} already exists on workspace {workspace}")
    except GeoserverException as e:
        pass
    
    # create the datastore
    geo.create_gpkg_datastore(file_path, dataid, workspace)

    # remove the file
    # os.remove(file_path)
    
    if style is not None:
        geo.publish_style(dataid, style, workspace) 

    logger.info(f"Layer '{dataid}' published successfully on workspace {workspace} with style '{style}'")
    
    # os.remove(file_path)

    

def get_server_styles(server: Server, workspace: Optional[str]=None):
    geo = _get_geoserver_client(server)
    _check_workspace(geo, server, workspace)
    styles = geo.get_styles(workspace)
    return styles

    

def upload_server_style(server: Server, style_name: str, sld_content: str, workspace: Optional[str]=None):
    geo = _get_geoserver_client(server)
    _check_workspace(geo, server, workspace)
    try:
        geo.upload_style(sld_content, style_name, workspace)
    except GeoserverException as e:
        if 'already exists' in str(e):
            logger.warning(f"Style {style_name} already exists on workspace {workspace}. Updating the style.")
        else:
            raise Exception(f"Error uploading style: {e}")
    

def delete_server_style(server: Server, style_name: str, workspace: Optional[str]=None):
    geo = _get_geoserver_client(server)
    _check_workspace(geo, server, workspace)
    geo.delete_style(style_name, workspace)   


def get_server_layer(server: Server, layer_name: str, workspace: Optional[str]=None):
    geo = _get_geoserver_client(server)
    _check_workspace(geo, server, workspace)
    try:
        layer = geo.get_layer(layer_name, workspace)
    except GeoserverException as e:
        if e.status == 404:
            return None
        else:
            raise Exception(f"Error getting layer: {e}")
    
    return {
        'name': layer['layer']['name'],
        'type': layer['layer']['type'],
        'style': layer['layer']['defaultStyle']['name'],
    }

def get_server_capabilities(server_obj: Server, additional_params: Optional[dict] = None) -> dict:
    params = {
        'service': 'WMS',
        # 'version': '1.3.0',
        'request': 'GetCapabilities',
    }

    if additional_params:
        params.update(additional_params)

    # use username and password if provided
    if server_obj.user and server_obj.password:
        auth = (server_obj.user, server_obj.password)
    else:
        auth = None

    # Forward GET request
    response = requests.get(server_obj.url, auth=auth, params=params)

    # extract the capabilities from the response as text, convert from xml to json
    capabilities = response.text
    capabilities_json = xmltodict.parse(capabilities)

    return capabilities_json


def get_layers_from_capabilities(capabilities_json: dict) -> list:
    layers_array = capabilities_json.get('WMS_Capabilities', {}).get('Capability', {}).get('Layer', {}).get('Layer', [])
    return layers_array