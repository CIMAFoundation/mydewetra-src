import json
from datetime import date, datetime, time, timedelta
import pylibmc
from acroweb3.sentinel.client import SentinelClient
from django.core.cache import cache
from rest_framework import status, viewsets
from rest_framework.decorators import action, api_view
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.routers import DefaultRouter
from urllib.parse import quote


from dewetra3.commons.logs import log

from dewetra3.models import Layer, Serie
from dewetra3.settings import (SENTINEL_SERVICE_PASSWORD, SENTINEL_SERVICE_URL,
                               SENTINEL_SERVICE_USER)

ALL_KEYS = "SENTINEL_KEYS"
#DEWETRA3_BACKEND_URL = "127.0.0.1:11211"
DEWETRA3_BACKEND_URL = "dewetra3-backend"

AGGR_PERIODS = [1,3,6,12,24,36]

class SentinelLayer(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]
    '''
    This class provides the following functionalities:

    - sensors: returns the list of sensors of a given class
    - aggregations: returns the list of aggregations
    - aggregated_layer: returns the aggregated layer of a given class
    - sensor_info: returns the info of a given sensor
    - stations_sensors: returns the list of sensors of a given station

    '''
    def __load_anag(self, sentinel_client):
        self.regions_it = sentinel_client.get('sensors/aggrfeatureswithoutgeom/regions_it/')
        self.municipalities_it = sentinel_client.get('sensors/aggrfeatureswithoutgeom/municipalities_it/')
        self.warningareas_it = sentinel_client.get('sensors/aggrfeatureswithoutgeom/warningareas_it/')
        self.districts_it = sentinel_client.get('sensors/aggrfeatureswithoutgeom/districts_it/')
        self.uom_rbd_it = sentinel_client.get('sensors/aggrfeatureswithoutgeom/uom_rbd_it/')
        self.catchments_it = sentinel_client.get('sensors/aggrfeatureswithoutgeom/catchments_it/')
        
    
    def __get_sensors_anag(self, sentinel_client):
        if self.regions_it is None or self.municipalities_it is None or self.warningareas_it is None or self.districts_it is None or self.uom_rbd_it is None or self.catchments_it is None:
            self.__load_anag(sentinel_client)
        return self.regions_it, self.municipalities_it, self.warningareas_it, self.districts_it, self.uom_rbd_it,self.catchments_it
        
    def __init__(self, **kwargs):
        '''
        Initializes the SentinelLayer object.
        '''
        self.mc = pylibmc.Client([DEWETRA3_BACKEND_URL], binary=True,
                                 behaviors={"tcp_nodelay": True, "ketama": True})
        super().__init__(**kwargs)        
        self.regions_it = None
        self.municipalities_it = None
        self.warningareas_it = None
        self.districts_it = None
        self.uom_rbd_it = None
        self.catchments_it = None

    def __get_all_keys(self):
        return self.mc.get(ALL_KEYS)

    def __set_key(self, key, time=86400):
        keys = self.__get_all_keys()
        if keys is None:
            keys = set()
        keys.add(key)
        self.mc.set(ALL_KEYS, keys, time)

    def __get_data_keys_by_key(self, key):
        keys = self.__get_all_keys()
        if keys is not None:
            return [key for key in keys if key.startswith(key)]
        else:
            return None

    def __get_request_timestamp(self, request):
        '''
        Get the timestamp from the request query parameters.

        Args:
            request (HttpRequest): The HTTP request object.

        Returns:
            str or None: The timestamp value if it exists in the query parameters, None otherwise.
        '''
        dt_par = request.query_params.get('dt', None)
        if dt_par is None:
            return None

        return dt_par

    def __get_request_thr_group(self, request):
        '''
        Get the value of the 'thr_group' query parameter from the request.

        Parameters:
        - request: The request object.

        Returns:
        - The value of the 'thr_group' query parameter, or '_' if it is not present.
        '''
        thr_group = request.query_params.get('thr_group', None)

        return thr_group if thr_group is not None else '_'

    def __get_request_aggr_layer(self, request):
        '''
        Get the value of the 'aggr_layer' query parameter from the request.

        Parameters:
        - request: The request object.

        Returns:
        - The value of the 'aggr_layer' query parameter, or None if it is not present.
        '''
        return request.query_params.get('aggr_layer', None)

    def __get_get_feauture_id_from_request(self, request):
        '''
        Get the value of the 'feature_id' query parameter from the request.

        Parameters:
        - request: The request object.

        Returns:
        - The value of the 'feature_id' query parameter, or None if it is not present.
        '''
        return request.query_params.get('feature_id', None)

    def __get_request_sensors_group(self, request):
        '''
        Get the value of the 'sensors_group' query parameter from the request.
        '''        
        log(request, 'info', 'Getting sensors group from request')
        
        sensor_group = request.query_params.get('sensor_group', None)
        
        if sensor_group is None:
            sensor_group = request.user.domain_data.props.get('sensors_group', None)
            
        return sensor_group if sensor_group is not None else '_'

    def __getCachedData(self, cache_key):
        '''
        Retrieves the cached data associated with the given cache key.

        Args:
            cache_key (str): The key used to store the data in the cache.

        Returns:
            The cached data associated with the cache key, or None if no data is found.
        '''
        try:
            data = self.mc.get(cache_key)  # returns None if no key-value pair
        except Exception as e:
            print(e)
            return None

        return data

    def __setCacheData(self, data, cache_key, cache_time=86400):
        '''
        Set the provided data in the cache with the given cache key and cache time.

        Parameters:
        - data: The data to be stored in the cache.
        - cache_key: The key to identify the cached data.
        - cache_time: The time (in seconds) for which the data should be cached. If not provided, a default value of 86400 seconds (1 day) will be used.
        '''
        try:
            self.mc.set(cache_key, data, cache_time)
        except Exception as e:
            print(e)
            pass

    @action(detail=False, methods=['get'], url_path='sensors/(?P<sensor_class>[^/.]+)')
    def sensors(self, request, sensor_class):
        """
        Retrieves sensor data based on the provided parameters.

        Args:
            request (HttpRequest): The HTTP request object.
            sensor_class (str): The class of the sensor.

        Returns:
            Response: The HTTP response containing the sensor data.

        Raises:
            N/A
        """
        log(request, 'info', 'Getting sensors')
        
        ts = self.__get_request_timestamp(request)
        thr_group = self.__get_request_thr_group(request)
        sensors_group = self.__get_request_sensors_group(request)
        
        client = SentinelClient(SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
                
        sensors = client.features_geojson(sensors_group, thr_group, sensor_class, ts=ts)
        
        return Response(json.loads(sensors), status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='aggregations')
    def aggregations(self, request):
        """
        Retrieves the aggregation layers from the Sentinel service.

        Args:
            request: The HTTP request object.

        Returns:
            A Response object containing the aggregation layers retrieved from the Sentinel service.
        """
        log(request, 'info', 'Getting aggregations')
        client = SentinelClient(
            SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
        return Response(client.aggregation_layers())

    @action(detail=False, methods=['get'], url_path='aggregated_layer/(?P<sensor_class>[^/.]+)')
    def aggregated_layer(self, request, sensor_class):
        """
        Retrieves aggregated sensor data based on the provided parameters.

        Args:
            request (HttpRequest): The HTTP request object.
            sensor_class (str): The sensor class to filter the data.

        Returns:
            Response: The HTTP response object containing the aggregated sensor data.

        Raises:
            ValueError: If the 'aggr_layer' parameter is missing in the request.
        """
        log(request, 'info', 'Getting aggregated layer')
        ts = self.__get_request_timestamp(request)
        thr_group = self.__get_request_thr_group(request)
        sensors_group = self.__get_request_sensors_group(request)
        aggr_layer = request.query_params.get('aggr_layer', None)
        if aggr_layer is None:
            return Response("aggr_layer parameter is missing", status=status.HTTP_400_BAD_REQUEST)

        client = SentinelClient(
            SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)

        sensors = client.aggregated_geojson(
            aggr_layer, sensors_group, thr_group, sensor_class, ts=ts)
        
        return Response(json.loads(sensors), status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='regions')
    def regions(self, request):
        """
        Retrieves the regions from the Sentinel service.

        Args:
            request: The HTTP request object.

        Returns:
            A Response object containing the regions retrieved from the Sentinel service.
        """
        log(request, 'info', 'Getting regions')
        client = SentinelClient(
            SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
        if self.regions_it is None:
            self.regions_it = client.get('sensors/aggrfeatureswithoutgeom/regions_it/')
        return Response(self.regions_it, status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='max_pluvio')
    def max_pluvio(self, request):
        """
        Retrieves the maximum pluvio data based on the provided parameters.
        Args:
            request (HttpRequest): The HTTP request object.
        Returns:
            Response: The HTTP response object containing the maximum pluvio data.
        Raises:
            ValueError: If the 'sensors_group' parameter is missing in the request.
        """
        log(request, 'info', 'Getting max pluvio')
        ts = self.__get_request_timestamp(request)
        string_aggr_periods = ','.join(str(aggr) for aggr in AGGR_PERIODS)
        sensor_group = request.query_params.get('sensor_group', None)
        region = request.query_params.get('region', None)
        
        sensors_group_encoded = quote(sensor_group, safe='')

        sentinel_client = SentinelClient(
            SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
        
        regions_it, municipalities_it, warningareas_it, districts_it, uom_rbd_it, catchments_it = self.__get_sensors_anag(sentinel_client)
        # Lookup dicts
        region_dict = {str(item['id']): item['name'] for item in regions_it}
        municipality_dict = {str(item['id']): item['name'] for item in municipalities_it}
        warningarea_dict = {str(item['id']): item['name'] for item in warningareas_it}
        district_dict = {str(item['id']): item['name'] for item in districts_it}
        uom_rbd_dict = {str(item['id']): item['name'] for item in uom_rbd_it}
        catchment_dict = {str(item['id']): item['name'] for item in catchments_it}
        
        def replace_ids_with_names(aggr):
            def map_ids(id_list, lookup):
                return [lookup.get(str(i), f"UNKNOWN({i})") for i in id_list]

            aggr["regions_it"] = map_ids(aggr.get("regions_it", []), region_dict)
            aggr["municipalities_it"] = map_ids(aggr.get("municipalities_it", []), municipality_dict)
            aggr["warningareas_it"] = map_ids(aggr.get("warningareas_it", []), warningarea_dict)
            aggr["districts_it"] = map_ids(aggr.get("districts_it", []), district_dict)
            aggr["uom_rbd_it"] = map_ids(aggr.get("uom_rbd_it", []), uom_rbd_dict)
            aggr["catchments_it"] = map_ids(aggr.get("catchments_it", []), catchment_dict)
            return aggr

        pluvios_raw = sentinel_client.get("sensors/pluviomax/{}/?ts={}&aggrPeriods={}".format(sensors_group_encoded, ts, string_aggr_periods))
        pluvios = json.loads(pluvios_raw)
        if region:
            pluvios = [pluvio for pluvio in pluvios if region in pluvio.get("properties", {}).get("aggr", {}).get("regions_it", [])]
        for sensor in pluvios:
            aggr = sensor.get("properties", {}).get("aggr", {})
            sensor["properties"]["aggr"] = replace_ids_with_names(aggr)
            
        return Response(pluvios, status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='aggregated_data/(?P<sensor_class>[^/.]+)')
    def aggregated_data(self, request, sensor_class):
        """
        Retrieves aggregated sensor data based on the provided parameters.

        Args:
            request (HttpRequest): The HTTP request object.
            sensor_class (str): The sensor class to filter the data.

        Returns:
            Response: The HTTP response object containing the aggregated sensor data.

        Raises:
            ValueError: If the 'aggr_layer' parameter is missing in the request.
        """
        log(request, 'info', 'Getting aggregated data')
        ts = self.__get_request_timestamp(request)
        thr_group = self.__get_request_thr_group(request)
        sensors_group = self.__get_request_sensors_group(request)
        aggr_layer = self.__get_request_aggr_layer(request)
        if aggr_layer is None:
            return Response("aggr_layer parameter is missing", status=status.HTTP_400_BAD_REQUEST)

        client = SentinelClient(
            SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)

        sensors = client.aggregated_data(
            aggr_layer, sensors_group, thr_group, sensor_class, ts=ts)
        return Response(sensors, status=status.HTTP_200_OK)
    
    @action(detail=False, methods=['get'], url_path='aggregated_layer_without_geom/(?P<aggr_layer>[^/.]+)')
    def aggregated_features_without_geom(self, request, aggr_layer):
        '''
        Retrieves aggregated features without geometry based on the provided parameters.
        
        Args:
            request (HttpRequest): The HTTP request object.
            aggr_layer (str): The aggregation layer to filter the data.
            
        Returns:
            Response: The HTTP response object containing the aggregated features without geometry.
            
        Raises:
            ValueError: If the 'aggr_layer' parameter is missing in the request.
            
        '''
        log(request, 'info', 'Getting aggregated features without geometry')
       
        client = SentinelClient(SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
        aggregated_layer_withoutdata = SentinelClient.aggregated_features_without_geom(client, aggr_layer)     

        return Response(aggregated_layer_withoutdata, status=status.HTTP_200_OK)
        

    @action(detail=False, methods=['get'], url_path='sensors_by_aggregated_feature/(?P<sensor_class>[^/.]+)')
    def sensor_by_aggregated_feature(self, request, sensor_class):
        """
        Retrieves sensor data based on the provided parameters.

        Args:
            request (HttpRequest): The HTTP request object.
            sensor_class (str): The class of the sensor.

        Returns:
            Response: The HTTP response containing the sensor data.

        Raises:
            ValueError: If the 'feature_id' parameter is missing in the request.
            ValueError: If the 'aggr_layer' parameter is missing in the request.
        """
        log(request, 'info', 'Getting sensors by aggregated feature')

        ts = self.__get_request_timestamp(request)
        thr_group = self.__get_request_thr_group(request)
        sensors_group = self.__get_request_sensors_group(request)
        aggr_layer = self.__get_request_aggr_layer(request)
        
        if aggr_layer is None:
            return Response("aggr_layer parameter is missing", status=status.HTTP_400_BAD_REQUEST)

        feature_id = self.__get_get_feauture_id_from_request(request)
        if feature_id is None:
            return Response("feature_id parameter is missing", status=status.HTTP_400_BAD_REQUEST)

        client = SentinelClient(
            SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)

        sensors = client.features_geojson(sensors_group, thr_group, sensor_class, ts=ts, full=False, aggr=True)
            
        sensors_dict = json.loads(sensors)

        filtered_features = [feature for feature in sensors_dict['features']
                             if aggr_layer in feature['properties']['aggr'] and feature_id in feature['properties']['aggr'][aggr_layer]]

        return Response(filtered_features, status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='sensor_info/(?P<sensor_id>[^/.]+)/(?P<db_id>[^/.]+)')
    def sensor_info(self, request, sensor_id, db_id):
        """
        Retrieves information about a sensor.

        Args:
            request (HttpRequest): The HTTP request object.
            sensor_id (int): The ID of the sensor.
            db_id (int): The ID of the database.

        Returns:
            Response: The response containing the sensor information.

        """
        log(request, 'info', 'Getting sensor info')
        cache_time = 900
        cache_string = 'sensor_info'.join([sensor_id, db_id])
        cached_info = self.__getCachedData(cache_string)

        if (cached_info):
            return Response(cached_info, status=status.HTTP_200_OK)
        else:
            client = SentinelClient(
                SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
            info = client.sensor_info(sensor_id=sensor_id, db_id=db_id)
            self.__setCacheData(info, cache_string, cache_time)
            return Response(info, status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='stations_sensors/(?P<station_id>[^/.]+)/(?P<db_id>[^/.]+)')
    def stations_sensors(self, request, station_id, db_id):
        """
        Retrieve information about sensors for a specific station.

        Args:
            request: The HTTP request object.
            station_id: The ID of the station.
            db_id: The ID of the database.

        Returns:
            A Response object containing the information about sensors for the specified station.
        """
        log(request, 'info', 'Getting stations sensors')
        client = SentinelClient(
            SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
        info = client.stations_sensors(station_id=station_id, db_id=db_id)
        return Response(info, status=status.HTTP_200_OK)


sentinel_app_router = DefaultRouter()

sentinel_app_router.register('', SentinelLayer, basename='')
