import json
import os
from collections import defaultdict

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from dewetra3.models import (ChartManager, DraCategory, Event, GeoScale,
                             Hazard, InfoManager, InspireTheme, Layer,
                             LayerCategory, LayerManager, LegendManager,
                             MapManager, MetadataManager, Path, PathHierarchy,
                             PropertiesManager, Role, Server, Source, Tag)


class Command(BaseCommand):

    """
    Comando per importare i Layer da un file JSON.

    Utilizza il comando `python manage.py import_layers <file_path>`.
    Il file JSON deve essere formattato correttamente e contenere i dati dei Layer.

    """

    help = 'Importa i dati dei Layer da JSON'

    def _manage_source(self, source_name):
        """
        Gestisce la creazione o il recupero di una fonte esistente.
        """
        if not source_name:
            source_name = 'Cima'
        source, created = Source.objects.get_or_create(name=source_name)
        if created:
            self.stdout.write(self.style.SUCCESS(
                f"Source creata: {source_name}"))
        return source

    def _manage_category(self, category_name):
        category, created = LayerCategory.objects.get_or_create(
            name=category_name)
        if created:
            self.stdout.write(self.style.SUCCESS(
                f"Categoria creata: {category_name}"))
        return category

    def _manage_geoscale(self, geoscale_name):
        """
        Gestisce la creazione o il recupero di una scala geografica esistente.
        """
        if not geoscale_name:
            geoscale_name = 'Unknown'
        geoscale, created = GeoScale.objects.get_or_create(name=geoscale_name)
        if created:
            self.stdout.write(self.style.SUCCESS(
                f"GeoScale creato: {geoscale_name}"))
        return geoscale

    def _manage_event_relatoin(self, event_name):
        """
        Gestisce la creazione o il recupero di un evento esistente.
        """
        if not event_name:
            return None
        event, created = Event.objects.get_or_create(name=event_name)
        if created:
            event.descr = event_name
            self.stdout.write(self.style.SUCCESS(
                f"Event creato: {event_name}"))
        return event

    def _manage_many_to_many(self, model_class, names, field_label):
        if not names:
            return []

        objects = []
        for name in names:
            if not name:
                continue
            obj, created = model_class.objects.get_or_create(name=name)
            objects.append(obj)

        self.stdout.write(self.style.SUCCESS(
            f"{field_label} associati: {', '.join(str(o) for o in objects)}"))
        return objects

    def _manage_manager(self, manager_class, name):
        if not name:
            return None
        manager, created = manager_class.objects.get_or_create(name=name)
        if created:
            manager.descr = name
            self.stdout.write(self.style.SUCCESS(
                f"{manager_class.__name__} creato: {name}"))
        return manager

    def _manage_server(self, server_url):
        """
        Gestisce la creazione o il recupero di un server esistente.
        """

        server_name = server_url.replace(
            "https://", "").replace("http://", "").split("/")[0]

        server, created = Server.objects.get_or_create(
            url=server_url,
            defaults={'name': server_name}
        )

        if created:
            self.stdout.write(self.style.SUCCESS(
                f"Server creato: {server_url} ({server_name})"))
        else:
            self.stdout.write(self.style.WARNING(
                f"Server già esistente: {server_url}"))
        return server

    def _manage_role(self, role_name):
        """
        Aggiunge tutti i ruoli esistenti al Layer.
        """
        roles = Role.objects.all()
        if not roles:
            self.stdout.write(self.style.WARNING(
                f"Nessun ruolo trovato per il Layer: {role_name}"))
            return []
        self.stdout.write(self.style.SUCCESS(
            f"Ruoli trovati per il Layer: {role_name}"))
        return roles

    def _print_layer(self, grouped):
        """
        Stampa i Layer raggruppati per gerarchia.
        """
        for hierarchy, items in grouped.items():
            print(f"\n== Hierarchy: {hierarchy} ({len(items)} elementi) ==")
            for item in items:
                print(f" - {item.get('name')}")

    def add_arguments(self, parser):
        # Opzionale: specifica il percorso del file json da linea di comando
        parser.add_argument('file_path', type=str,
                            help='Percorso file JSON con i dati da importare')

    def handle(self, *args, **options):
        file_path = options['file_path']

        if not os.path.exists(file_path):
            raise CommandError(f"File non trovato: {file_path}")

        with open(file_path, 'r') as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                raise CommandError(f"Errore nel parsing del file JSON: {e}")

        # ✅ Raggruppa per hierarchy
        grouped = defaultdict(list)
        for item in data:
            hierarchy_key = item.get('hierarchy', 'UNKNOWN')
            grouped[hierarchy_key].append(item)

        with transaction.atomic():
            for hierarchy, items in grouped.items():
                for item in items:
                    try:
                        # Gestione FK e campi diretti
                        server = self._manage_server(
                            item.get('server').get('url'))
                        # category = self._manage_category(item.get('category'))
                        category = self._manage_category('test')
                        source = self._manage_source(item.get('source'))
                        geoscale = self._manage_geoscale(item.get('geoscale'))

                        infomanager = self._manage_manager(
                            InfoManager, item.get('EventInfoManager'))
                        legendmanager = self._manage_manager(
                            LegendManager, item.get('EventLegendManager'))
                        propertiesmanager = self._manage_manager(
                            PropertiesManager, item.get('EventPropertiesManager'))
                        metadatamanager = self._manage_manager(
                            MetadataManager, item.get('EventMetadataManager'))
                        layermanager = self._manage_manager(
                            LayerManager, 'EventStaticLayerManager')
                        mapmanager = self._manage_manager(
                            MapManager, 'EventStaticMapManager')
                        chartmanager = self._manage_manager(
                            ChartManager, item.get('chartmanager'))

                        defaults = {
                            'descr': item.get('descr'),
                            'dataid': item.get('dataid'),
                            'server': server,
                            'thumb': '',
                            'source': source,
                            'lonw': item.get('lonw'),
                            'lone': item.get('lone'),
                            'lats': item.get('lats'),
                            'latn': item.get('latn'),
                            'enabled': item.get('enabled', True),
                            'category': category,
                            'geoscale': geoscale,
                            'infomanager': infomanager,
                            'legendmanager': legendmanager,
                            'propertiesmanager': propertiesmanager,
                            'metadatamanager': metadatamanager,
                            'layermanager': layermanager,
                            'mapmanager': mapmanager,
                            'chartmanager': chartmanager,
                            'customprops': item.get('customprops'),
                            # 'creator': item.get('creator'),  ❌ make sure it's not here
                        }

                        # Crea il Layer
                        layer, created = Layer.objects.update_or_create(
                            name=item.get('name'),
                            defaults=defaults
                        )

                        # Relazioni ManyToMany
                        roles = self._manage_role(item.get('role'))
                        if roles:
                            layer.roles.set(roles)

                        events = self._manage_many_to_many(
                            Event, item.get('event'), "Eventi")
                        if events:
                            layer.event.set(events)

                        hazards = self._manage_many_to_many(
                            Hazard, item.get('hazards'), "Hazard")
                        if hazards:
                            layer.hazards.set(hazards)

                        tags = self._manage_many_to_many(
                            Tag, item.get('tags'), "Tag")
                        if tags:
                            layer.tags.set(tags)

                        inspirethemes = self._manage_many_to_many(
                            InspireTheme, item.get('inspirethemes'), "InspireThemes")
                        if inspirethemes:
                            layer.inspirethemes.set(inspirethemes)

                        dracategories = self._manage_many_to_many(
                            DraCategory, item.get('dracategories'), "DraCategories")
                        if dracategories:
                            layer.dracategories.set(dracategories)

                        paths = self._manage_many_to_many(
                            PathHierarchy, item.get('paths'), "PathHierarchy")
                        if paths:
                            layer.paths.set(paths)

                        related = None

                        event_name = item.get('hierarchy')

                        if event_name:
                            event = self._manage_event_relatoin(event_name)
                            if event:
                                event.layers.add(layer)
                                event.save()
                            else:
                                self.stdout.write(self.style.WARNING(
                                    f"Event '{event_name}' non trovato."))
                        else:
                            self.stdout.write(self.style.WARNING(
                                f"Event '{event_name}' non trovato."))
                            continue

                        self.stdout.write(self.style.SUCCESS(
                            f"✅ Layer creato: {layer.name}"))

                    except Exception as e:
                        self.stderr.write(self.style.ERROR(
                            f"❌ Errore durante la creazione del Layer '{item.get('name')}': {e}"))
                        continue
