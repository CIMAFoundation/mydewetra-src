# import_layers.py
import json
import sys
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from dewetra3.models import (Layer, LayerCategory, LayerManager, LayerTag,
                             Role, Tag)


class Command(BaseCommand):
    help = "Importa o aggiorna in bulk i layer da un file JSON"

    def add_arguments(self, parser):
        parser.add_argument("file", help="Percorso al file JSON")
        parser.add_argument("--dry-run", action="store_true",
                            help="Valida e mostra il risultato senza salvare")

    def handle(self, *args, **opts):
        path = Path(opts["file"])
        if not path.exists():
            raise CommandError(f"File non trovato: {path}")

        # 1) Carichiamo il JSON
        try:
            records = json.loads(path.read_text())
        except json.JSONDecodeError as exc:
            raise CommandError(f"JSON non valido: {exc}") from exc

        # 2) Pre-recupero relazioni per evitare query N+1
        managers = {m.pk: m for m in LayerManager.objects.all()}
        categories = {c.pk: c for c in LayerCategory.objects.all()}
        tags = {t.name: t for t in Tag.objects.all()}       # se usi name
        roles = {r.name: r for r in Role.objects.all()}

        to_create, to_update = [], []

        # 3) Scansioniamo i record
        for raw in records:
            dataid = raw.get("dataid")
            if not dataid:
                self.stderr.write(f"⚠️  Record senza dataid, salto: {raw}")
                continue

            try:
                layer = Layer.objects.get(dataid=dataid)
                mode = "update"
            except Layer.DoesNotExist:
                layer = Layer(dataid=dataid)
                mode = "create"

            # --- Prepariamo i campi da settare -------------------------
            # se c'è update_only prendi solo quello
            payload = raw.get("update_only", raw)
            layer.name = payload.get("name", layer.name)
            layer.enabled = payload.get("enabled", layer.enabled)

            if "layermanager" in payload:
                lm_id = payload["layermanager"]
                layer.layermanager = managers.get(
                    lm_id)  # presuppone ID numerico

            if "category" in payload:
                cat_id = payload["category"]
                layer.category = categories.get(cat_id)

            if "bbox" in payload:
                layer.lonw, layer.lone, layer.lats, layer.latn = payload["bbox"]

            # -----------------------------------------------------------------

            (to_update if mode == "update" else to_create).append(layer)

            # Many-to-Many rimandati a dopo
            raw["_tags"] = payload.get("tags", [])
            raw["_roles"] = payload.get("roles", [])

        # 4) Salviamo in bulk
        with transaction.atomic():
            if to_create:
                Layer.objects.bulk_create(to_create, batch_size=1000)
            if to_update:
                Layer.objects.bulk_update(
                    to_update,
                    ["name", "enabled",
                     "layermanager", "category",
                     "lonw", "lone", "lats", "latn"],
                    batch_size=1000
                )

            # 5) Gestione Many-to-Many (tags tramite through, roles diretto)
            layer_map = {l.dataid: l for l in to_create + to_update}

            layer_tags_bulk = []
            for raw in records:
                layer = layer_map.get(raw["dataid"])
                if not layer:
                    continue

                # Tags
                for tag_name in raw.get("_tags", []):
                    tag = tags.get(tag_name)
                    if tag:
                        layer_tags_bulk.append(
                            LayerTag(layer=layer, tag=tag)
                        )

                # Roles
                if raw.get("_roles"):
                    role_objs = [roles[r] for r in raw["_roles"] if r in roles]
                    layer.roles.add(*role_objs)  # Django già usa bulk add

            if layer_tags_bulk:
                LayerTag.objects.bulk_create(layer_tags_bulk, batch_size=1000)

            if opts["dry_run"]:
                raise transaction.TransactionManagementError(
                    "Dry-run: rollback volontario"
                )

        self.stdout.write(self.style.SUCCESS(
            f"Create: {len(to_create)}  ‖  Update: {len(to_update)}"
        ))


# Esempio di file JSON da importare
# [
#   {
#     "dataid": "corine:2024",
#     "name": "Corine Land Cover 2024",
#     "layermanager": 37,          // PK oppure stringa‐chiave
#     "category": 1,
#     "enabled": true,
#     "bbox": [-10, 35, 34, 72],   // [lonw, lone, lats, latn]
#     "tags": [ "HOT", "EU" ],     // Many-to-Many (through LayerTag)
#     "roles": [ "admin", "viewer" ]
#   },
#   {
#     "dataid": "soil:it",
#     "name": "Suoli italiani",
#     "update_only": {             // puoi indicare solo ciò che cambia
#       "layermanager": 37,
#       "enabled": false
#     }
#   }
# ]
# prova senza toccare il DB
# python manage.py import_layers dati/layers.json --dry-run

# esecuzione reale
# python manage.py import_layers dati/layers.json
