import json
import os
from collections import defaultdict

import requests  # Importa la libreria requests per effettuare le chiamate HTTP
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from dewetra3.models import (ChartManager, DraCategory, Event, GeoScale,
                             Hazard, InfoManager, InspireTheme, Layer,
                             LayerCategory, LayerManager, LegendManager,
                             MapManager, MetadataManager, Path, PathHierarchy,
                             PropertiesManager, Role, Server, Source, Tag)


class AbstractLayerImporter(BaseCommand):
    """
    Classe astratta per importare i Layer da un file JSON oppure da un URL.

    Utilizzo:
        - Per un file locale:
            python manage.py import_layers --file_path <percorso_file.json>
        - Per un URL:
            python manage.py import_layers --url <URL_che_restituisce_JSON>
    """
    help = 'Importa i dati dei Layer da JSON in maniera astratta e customizzabile'

    # (Le configurazioni e metodi di gestione FK/M2M rimangono invariati)
    fk_config = {
        'server': {
            'func': '_manage_server',
        },
        'source': {
            'model': Source,
            'default': 'Cima',
        },
        'category': {
            'model': LayerCategory,
            'default': 'test',
        },
        'geoscale': {
            'model': GeoScale,
            'default': 'Unknown',
        },
        'WMSLayerInfoComponent': {
            'model': InfoManager,
        },
        'StaticWMSLegendComponent': {
            'model': LegendManager,
        },
        'propertiesmanager': {
            'model': PropertiesManager,
        },
        'metadatamanager': {
            'model': MetadataManager,
        },
        'layermanager': {
            'model': LayerManager,
            'default': 'STATICWMSLayerManager',
        },
        'mapmanager': {
            'model': MapManager,
            'default': 'StaticMapComponent',
        },
        'chartmanager': {
            'model': ChartManager,
        },
    }

    m2m_config = {
        'hazards': {
            'model': Hazard,
            'label': "Hazard"
        },
        'tags': {
            'model': Tag,
            'label': "Tag"
        },
        'inspirethemes': {
            'model': InspireTheme,
            'label': "InspireThemes"
        },
        'dracategories': {
            'model': DraCategory,
            'label': "DraCategories"
        },
        'paths': {
            'model': PathHierarchy,
            'label': "PathHierarchy"
        },
    }

    def add_arguments(self, parser):
        parser.add_argument('--file_path', type=str,
                            help='Percorso file JSON con i dati da importare')
        parser.add_argument('--url', type=str,
                            help='URL da cui recuperare il JSON')

    def _manage_instance(self, model, value, default_value=None, field_name="name", custom_msg=None):
        if not value:
            if default_value is not None:
                value = default_value
            else:
                return None
        kwargs = {field_name: value}
        obj, created = model.objects.get_or_create(**kwargs)
        if created:
            msg = custom_msg or f"{model.__name__} creato: {value}"
            self.stdout.write(self.style.SUCCESS(msg))
        return obj

    def _manage_server(self, server_url):
        if not server_url:
            return None
        server_name = server_url.replace(
            "https://", "").replace("http://", "").split("/")[0]
        server, created = Server.objects.get_or_create(
            url=server_url,
            defaults={'name': server_name}
        )
        if created:
            self.stdout.write(self.style.SUCCESS(
                f"Server creato: {server_url} ({server_name})"))
        else:
            self.stdout.write(self.style.WARNING(
                f"Server già esistente: {server_url}"))
        return server

    def _manage_role(self, role_value):
        roles = Role.objects.all()
        if not roles:
            self.stdout.write(self.style.WARNING(
                f"Nessun ruolo trovato per il Layer: {role_value}"))
            return []
        self.stdout.write(self.style.SUCCESS(
            f"Ruoli associati al Layer: {role_value}"))
        return roles

    def _manage_event_relation(self, event_name):
        if not event_name:
            return None
        event, created = Event.objects.get_or_create(name=event_name)
        if created:
            self.stdout.write(self.style.SUCCESS(
                f"Event creato: {event_name}"))
        return event

    def _manage_many_to_many(self, model_class, names, field_label):
        if not names:
            return []
        objects = []
        for name in names:
            if not name:
                continue
            obj = self._manage_instance(model_class, name)
            if obj:
                objects.append(obj)
        self.stdout.write(self.style.SUCCESS(
            f"{field_label} associati: {', '.join(str(o) for o in objects)}"))
        return objects

    def process_foreign_keys(self, item):
        fk_objects = {}
        for key, config in self.fk_config.items():
            if key == 'server':
                server_data = item.get('server')
                if server_data and server_data.get('url'):
                    fk_objects['server'] = self._manage_server(
                        server_data.get('url'))
                else:
                    fk_objects['server'] = None
            else:
                model = config.get('model')
                default_value = config.get('default')
                value = item.get(key)
                fk_objects[key] = self._manage_instance(
                    model, value, default_value=default_value)
        return fk_objects

    def process_many_to_many(self, item):
        m2m_objects = {}
        for key, config in self.m2m_config.items():
            model = config.get('model')
            label = config.get('label', key)
            values = item.get(key)
            m2m_objects[key] = self._manage_many_to_many(model, values, label)
        return m2m_objects

    def handle(self, *args, **options):
        file_path = options.get('file_path')
        url = options.get('url')

        if not file_path and not url:
            raise CommandError(
                "Devi specificare almeno --file_path o --url per recuperare i dati.")

        # Caricamento dei dati dal file o dall'URL
        if file_path:
            if not os.path.exists(file_path):
                raise CommandError(f"File non trovato: {file_path}")
            with open(file_path, 'r') as f:
                try:
                    data = json.load(f)
                except json.JSONDecodeError as e:
                    raise CommandError(
                        f"Errore nel parsing del file JSON: {e}")
        else:
            try:
                response = requests.get(url)
                response.raise_for_status()
            except Exception as e:
                raise CommandError(
                    f"Errore durante il fetching della URL: {e}")
            try:
                data = response.json()
            except json.JSONDecodeError as e:
                raise CommandError(
                    f"Errore nel parsing del JSON dalla URL: {e}")

        # Raggruppa gli elementi per gerarchia
        grouped = defaultdict(list)
        for item in data:
            hierarchy_key = item.get('hierarchy', 'UNKNOWN')
            grouped[hierarchy_key].append(item)

        with transaction.atomic():
            for hierarchy, items in grouped.items():
                for item in items:
                    try:
                        fk_objects = self.process_foreign_keys(item)
                        m2m_objects = self.process_many_to_many(item)
                        roles = self._manage_role(item.get('role'))

                        layer_fields = {
                            'descr': item.get('descr'),
                            'dataid': item.get('dataid'),
                            'server': fk_objects.get('server'),
                            'thumb': '',
                            'source': fk_objects.get('source'),
                            'lonw': item.get('lonw'),
                            'lone': item.get('lone'),
                            'lats': item.get('lats'),
                            'latn': item.get('latn'),
                            'enabled': item.get('enabled', True),
                            'category': fk_objects.get('category'),
                            'geoscale': fk_objects.get('geoscale'),
                            'infomanager': fk_objects.get('WMSLayerInfoComponent'),
                            'legendmanager': fk_objects.get('StaticWMSLegendComponent'),
                            'propertiesmanager': fk_objects.get('propertiesmanager'),
                            'metadatamanager': fk_objects.get('metadatamanager'),
                            'layermanager': fk_objects.get('layermanager'),
                            'mapmanager': fk_objects.get('mapmanager'),
                            'chartmanager': fk_objects.get('chartmanager'),
                            'customprops': item.get('customprops'),
                            'creator': item.get('creator'),
                        }

                        layer, created = Layer.objects.update_or_create(
                            name=item.get('name'),
                            defaults=layer_fields
                        )

                        if roles:
                            layer.roles.set(roles)

                        for key, objs in m2m_objects.items():
                            if objs:
                                getattr(layer, key).set(objs)

                        event_name = item.get('hierarchy')
                        if event_name:
                            event = self._manage_event_relation(event_name)
                            if event:
                                event.layers.add(layer)
                                event.save()
                            else:
                                self.stdout.write(self.style.WARNING(
                                    f"Event '{event_name}' non trovato."))
                        else:
                            self.stdout.write(self.style.WARNING(
                                f"Event '{event_name}' non trovato."))
                            continue

                        self.stdout.write(self.style.SUCCESS(
                            f"✅ Layer creato/aggiornato: {layer.name}"))

                    except Exception as e:
                        self.stderr.write(self.style.ERROR(
                            f"❌ Errore durante la creazione del Layer '{item.get('name')}': {e}"
                        ))
                        continue


if __name__ == '__main__':
    command = AbstractLayerImporter()
    # Esempio di esecuzione diretta: specifica --file_path o --url
    command.handle(file_path='path_al_file.json')
