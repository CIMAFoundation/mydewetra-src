
import json
from datetime import datetime, timedelta

import pandas as pd
from acroweb3.charts.client import ChartsServiceClient
from acroweb3.dds.router import DDSClientRouter
from acroweb3.sentinel.client import SentinelClient
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.routers import DefaultRouter

from dewetra3.commons.logs import log
from dewetra3.commons.translate import (TranslateService,
                                        apply_translation_to_object,
                                        get_translation_url)
from dewetra3.models import Layer, Serie
from dewetra3.settings import (CHARTS_SERVICE_URL, SENTINEL_SERVICE_PASSWORD,
                               SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER)


class ChartViewSet(viewsets.ViewSet):
    """
    A viewset for handling chart build operations.
    """

    def _get_query_period(self, request):
        """
        Get the query period from the request parameters.

        Args:
            request (HttpRequest): The HTTP request object.

        Returns:
            tuple: A tuple containing the start and end timestamps of the query period.

        """
        # Read period dt1 and dt2 from request parameter
        dts1 = request.query_params.get('dt1', None)
        dts2 = request.query_params.get('dt2', None)

        # If dt1 or dt2 are not specified, take the last 24 hours
        if dts1 is None or dts2 is None:
            dt2 = datetime.utcnow().timestamp
            dt1 = dt2 - timedelta(hours=24).timestamp()
        else:
            dt1 = dts1
            dt2 = dts2

        # Return the unix timestamps
        return int(dt1), int(dt2)

    def __get_lat_lon(self, request):
        """
        Get the latitude and longitude from the request query parameters.

        Args:
            request (Request): The request object.

        Returns:
            Tuple[float, float]: A tuple containing the latitude and longitude as floats.
            If either latitude or longitude is missing in the request query parameters, returns (None, None).
        """
        lat = request.query_params.get('lat', None)
        lon = request.query_params.get('lon', None)
        if lat is None or lon is None:
            return None, None
        return float(lat), float(lon)

    def __get_lat_lon_from_body(self, request):
        """
        Extracts latitude and longitude values from the request body.

        Args:
            request (HttpRequest): The HTTP request object.

        Returns:
            tuple: A tuple containing the latitude and longitude values extracted from the request body.
                   If either latitude or longitude is missing, returns (None, None).
        """
        lat = request.data.get('lat', None)
        lon = request.data.get('lon', None)
        if lat is None or lon is None:
            return None, None
        return float(lat), float(lon)

    def __get_query_period_punctual_series(self, request):
        """
        Get the query period for punctual series.

        Args:
            request (object): The request object containing the 'from' and 'to' parameters.

        Returns:
            tuple: A tuple containing the start and end timestamps of the query period.
        """

        dt_from_par = request.data.get('from', None)
        dt_to_par = request.data.get('to', None)

        if dt_from_par is None or dt_to_par is None:
            dt2 = datetime.utcnow().timestamp
            dt1 = dt2 - timedelta(hours=24).timestamp()
        else:
            dt1 = dt_from_par
            dt2 = dt_to_par
        # return the unix timestamps

        return int(dt1), int(dt2)

    def _build_pandas_dataframe(self, request):
        """
        Builds a pandas DataFrame with series values and categories.

        Args:
            request (Request): The HTTP request object.

        Returns:
            DataFrame: A pandas DataFrame containing the series values and categories.
        """
        # read layer id from request parameter
        layer_id = request.query_params.get('layer_id', None)
        # read serie id from request parameter
        serie_id = request.query_params.get('serie_id', None)
        # read feature id from request parameter
        feature_id = request.query_params.get('feature_id', None)
        # read threshold id from request parameter
        threshold_group = request.query_params.get('threshold_group', None)

        if serie_id is None or feature_id is None or layer_id is None:
            return Response(status=400, data={'error': 'layer_id, serie_id and feature_id are required'})

        log(request, 'info',
            f'[CHARTS->]Building pandas dataframe for layer {layer_id}, serie {serie_id}, feature {feature_id} , threshold_group {threshold_group}')

        # read period dt1 and dt2 from request parameter
        t1, t2 = self._get_query_period(request)

        # get layer from db
        layer = Layer.objects.get(id=layer_id)

        # get data from DDS
        client = DDSClientRouter().get_dds_serie_client(
            layer.server.url, layer.server.user, layer.server.password)
        dds_series = client.series(serie_id, feature_id, t1, t2)

        try:

            # get data from Sentinel
            sentinel_client = SentinelClient(
                SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
            # get thresholds
            thresholds = sentinel_client.thr_by_sensor(feature_id.split(
                ';')[0], feature_id.split(';')[1], threshold_group)
            # if thresholds is None or len(thresholds) == 0:
            #     #station,   db,    sensor,   severity,    name,         value,    validity_period
            #     #392100,    2,  268441244,  	3  ,	"TH_ele_6h",	172,	21600
            #     thresholds = [
            #         {'station': 392100, 'db': 2, 'sensor': 268441244, 'severity': 1, 'name': 'TH_ele_6h', 'value': 17, 'validity_period': 21600},
            #         {'station': 392100, 'db': 2, 'sensor': 268441244, 'severity': 2, 'name': 'TH_ele_6h', 'value': 34, 'validity_period': 21600},
            #         {'station': 392100, 'db': 2, 'sensor': 268441244, 'severity': 3, 'name': 'TH_ele_6h', 'value': 68, 'validity_period': 21600}
            #         ]
        except Exception as e:
            thresholds = []

        data = {
            'x': None
        }

        y_count = 1
        for dds_serie in dds_series:
            if data['x'] is None:
                data['x'] = dds_serie['timeline']
            data[f'y{y_count}'] = dds_serie['values']
            y_count += 1

        if len(thresholds) > 0:
            len_thresholds_str = str(len(thresholds))
            log(request, 'info',
                f'[CHARTS->]Adding {len_thresholds_str} thresholds to the dataframe')
            for threshold in thresholds:
                validity_period = threshold.get("validity_period", "none")
                data[f'thr;{threshold["name"]};{threshold["severity"]};{validity_period}'] = threshold['value']
        # check if the dataframe is empty
        if data['x'] is None:
            log(request, 'info',
                '[CHARTS->]No data found for the given parameters')

        series_loaded = str(y_count - 1)

        if series_loaded == '0':
            log(request, 'info',
                '[CHARTS->]No series found for the given parameters')
            return pd.DataFrame()
        else:
            log(request, 'info', f'[CHARTS->]Series loaded: {series_loaded}')
            df = pd.DataFrame(data)

            y_count = 1
            # add the series title to the dataframe
            for dds_serie in dds_series:
                df.attrs[f'y{y_count}'] = dds_serie["title"]
                y_count += 1

        return df

    def _build_pandas_dataframe_punctual_series(self, request, layer_id):
        """
        Builds a pandas DataFrame from the punctual series data.

        Args:
            request (HttpRequest): The HTTP request object.
            layer_id (int): The ID of the layer.

        Returns:
            pandas.DataFrame: The pandas DataFrame containing the punctual series data.
        """

        layer = Layer.objects.get(id=layer_id)
        props_from_client = request.data.get('props', None)
        t_from, t_to = self.__get_query_period_punctual_series(request)
        lat, lon = self.__get_lat_lon_from_body(request)

        log(request, 'info',
            f'[CHARTS->]Building pandas dataframe for punctual series of layer {layer_id}')

        client = DDSClientRouter().get_dds_map_client(
            layer.server.url, layer.server.user, layer.server.password)
        series = client.punctualSerie(
            props_from_client, t_from, t_to, lon, lat)
        data = {
            'x': None
        }
        y_count = 1
        for serie in series:
            if data['x'] is None:
                data['x'] = serie['timeline']
            data[f'y{y_count}'] = serie['values']
            y_count += 1

        # check if the dataframe is empty
        if data['x'] is None:
            log(request, 'info',
                '[CHARTS->]No data found for the given parameters')

        return pd.DataFrame(data)

    def _manage_options(self, request):
        """
        Manage the options for the chart.

        Args:
            request (HttpRequest): The HTTP request object.
            options (dict): The options dictionary.

        Returns:
            dict: The options dictionary with the updated values.
        """
        # read the chart option as the request body
        chart_options = request.data

        if 'chart_properties' in chart_options:
            chart_options['chart_properties'] = apply_translation_to_object(
                chart_options['chart_properties'], chart_options['feature'], TranslateService(get_translation_url(portal='mydewetra', app='dewetra3', lang='it')))
        return chart_options

    @action(detail=False, methods=['post'], url_path='dds_image')
    def dds_chart_image(self, request, chart_id):
        """
        Generate and return a chart image based on the provided chart ID and request data.

        Args:
            request (HttpRequest): The HTTP request object.
            chart_id (str): The ID of the chart to generate the image for.

        Returns:
            Response: The HTTP response object containing the generated chart image.

        Raises:
            None
        """
        # build dataframe
        df = self._build_pandas_dataframe(request)

        # read the chart option as the request body
        try:
            chart_options = self._manage_options(request)
        except Exception as e:
            log(request, 'error',
                f'[CHART->]Error managing chart options: {str(e)}')

        # build charts server client
        charts_service = ChartsServiceClient(CHARTS_SERVICE_URL)

        # build chart
        image_type = request.query_params.get('img_type', 'png')
        log(request, 'info',
            f'[CHART->]Generating chart image of type {image_type}')
        chart_image = charts_service.get_image(
            chart_id, df, options=chart_options, type=image_type)

        return Response(content_type=f'image/{image_type}', data=chart_image)

    @action(detail=False, methods=['post'], url_path='dds_json')
    def dds_chart_json(self, request):
        """
        Generate a JSON representation of a chart based on the given request.

        Args:
            request (HttpRequest): The HTTP request object.

        Returns:
            Response: The HTTP response object containing the JSON representation of the chart.
        """
        chart_id = request.query_params.get('chart_id', None)
        # build dataframe
        df = self._build_pandas_dataframe(request)

        # read the chart option as the request body
        try:
            chart_options = self._manage_options(request)
        except Exception as e:
            log(request, 'error',
                f'[CHART->]Error managing chart options: {str(e)}')

        # build charts server client
        charts_service = ChartsServiceClient(CHARTS_SERVICE_URL)

        # #TODO portal should be taken from the request
        # translate_service = TranslateService(get_translation_url(portal='mydewetra', app='dewetra3', lang='en'))

        # chart_options['properties'] = apply_translation_to_object(chart_options.get('properties',{}), chart_options.get('feature',{}), translate_service)

        # build chart
        log(request, 'info', '[CHART->]Generating chart JSON')
        try:
            chart_json = charts_service.get_json(
                chart_id, df, options=chart_options)
        except Exception as e:
            log(request, 'error',
                f'[CHART->]Error generating chart JSON: {str(e)}')
            return Response(status=500, data={'error': str(e)})

        return Response(json.loads(chart_json))

    @action(detail=False, methods=['post'], url_path='dds_punctual_image/(?P<layer_id>[^/.]+)')
    def dds_punctual_chart_image(self, request, layer_id):
        """
        Generate and return a punctual chart image.

        Args:
            request (HttpRequest): The HTTP request object.
            layer_id (int): The ID of the layer.

        Returns:
            Response: The HTTP response object containing the chart image.

        """
        chart_id = request.data.get('chart_id', None)

        # build dataframe
        df = self._build_pandas_dataframe_punctual_series(request, layer_id)

        # read the chart option as the request body
        chart_options = request.data

        # build charts server client
        charts_service = ChartsServiceClient(CHARTS_SERVICE_URL)

        # build chart
        image_type = request.query_params.get('img_type', 'png')
        log(request, 'info',
            f'[CHART-->]Generating punctual chart image of type {image_type}')

        try:
            chart_image = charts_service.get_image(
                chart_id, df, options=chart_options, type=image_type)
        except Exception as e:
            log(request, 'error',
                f'[CHART-->]Error generating punctual chart image: {str(e)}')
            return Response(status=500, data={'error': str(e)})

        return Response(content_type=f'image/{image_type}', data=chart_image)

    @action(detail=False, methods=['post'], url_path='dds_punctual_json/(?P<layer_id>[^/.]+)')
    def dds_punctual_chart_json(self, request, layer_id):
        """
        Generate a JSON representation of a punctual chart.

        Args:
            request (HttpRequest): The HTTP request object.
            layer_id (int): The ID of the layer.

        Returns:
            Response: The HTTP response containing the JSON representation of the chart.
        """
        chart_id = request.data.get('chart_id', None)

        # build dataframe
        df = self._build_pandas_dataframe_punctual_series(request, layer_id)

        # read the chart option as the request body
        try:
            chart_options = self._manage_options(request)
        except Exception as e:
            log(request, 'error',
                f'[CHART->]Error managing chart options: {str(e)}')

        # build charts server client
        charts_service = ChartsServiceClient(CHARTS_SERVICE_URL)

        # build chart
        log(request, 'info', '[CHART-->]Generating punctual chart JSON')
        try:
            chart_json = charts_service.get_json(
                chart_id, df, options=chart_options)
        except Exception as e:
            log(request, 'error',
                f'[CHART-->]Error generating punctual chart JSON: {str(e)}')
            return Response(status=500, data={'error': str(e)})

        return Response(json.loads(chart_json))


chart_app_router = DefaultRouter()

chart_app_router.register('', ChartViewSet, basename='')
