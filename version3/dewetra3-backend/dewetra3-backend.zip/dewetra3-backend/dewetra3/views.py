import logging

import httpx
import requests
import xmltodict
from acroweb3_api.auth import AcrowebAuthData
from asgiref.sync import async_to_sync, sync_to_async
from django.core.cache import cache
from django.db.models import Prefetch
from django.http import HttpResponse
from rest_framework import filters, permissions, status, viewsets
from rest_framework.decorators import action, api_view
from rest_framework.negotiation import BaseContentNegotiation
from rest_framework.response import Response
from rest_framework.routers import DefaultRouter
from rest_framework.views import APIView

from dewetra3.models import (DataType, DraCategory, Event, GeoScale, Hazard,
                             Icon, InspireTheme, Layer, LayerCategory,
                             LayerTag, Path, Role, Server, Tag, Tool)
from dewetra3.serializers import (DataTypeSerializer, DraCategorySerializer,
                                  EventSerializer, GeoScaleSerializer,
                                  HazardSerializer, IconSerializer,
                                  IspireThemeSerializer,
                                  LayerCategorySerializer, LayerSerializer,
                                  ScenarioSerializerDetail,
                                  ScenarioSerializerList, ServerSerializer,
                                  TagSerializer, ToolSerializer)
from dewetra3.tools.layer_publish_utils import get_server_capabilities

DEWETRA3_BACKEND_URL = "dewetra3-backend"

logger = logging.getLogger(__name__)


class ServerView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving server data.

    This viewset provides read-only endpoints for retrieving server objects.
    """

    queryset = Server.objects.all()
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = ServerSerializer


class TagView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving Tag objects.

    This viewset provides read-only endpoints for retrieving Tag objects.
    """

    queryset = Tag.objects.all()
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = TagSerializer


class DataTypeView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving DataType objects.

    This viewset provides read-only endpoints for retrieving DataType objects.
    """

    queryset = DataType.objects.all()
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = DataTypeSerializer


class HazardView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving Tag objects.

    This viewset provides read-only endpoints for retrieving Tag objects.
    """

    queryset = Hazard.objects.all()
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = HazardSerializer


class LayerCategoryView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving LayerCategory objects.

    This viewset provides read-only endpoints for retrieving LayerCategory objects.
    """

    queryset = LayerCategory.objects.all()
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = LayerCategorySerializer


class GeoScaleView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving GeoScale objects.

    This viewset provides read-only endpoints for retrieving GeoScale objects.
    """

    queryset = GeoScale.objects.all()
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = GeoScaleSerializer


class InspireThemeView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving InspireTheme objects.

    This viewset provides read-only endpoints for retrieving InspireTheme objects.
    """

    queryset = InspireTheme.objects.all()
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = IspireThemeSerializer


class DraCategoryView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving DraCategory objects.

    This viewset provides read-only endpoints for retrieving DraCategory objects.
    """

    queryset = DraCategory.objects.all()
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = DraCategorySerializer


class IconView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving Icon objects.

    This viewset provides read-only endpoints for retrieving Icon objects.
    """

    queryset = Icon.objects.all()
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = IconSerializer
    # permission_classes = [permissions.IsAuthenticated]
    filter_backends = [filters.SearchFilter]
    search_fields = ['name']


class ToolView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving tools based on user domain.

    Attributes:
        queryset (QuerySet): The queryset of Tool objects.
        serializer_class (Serializer): The serializer class for Tool objects.
    """

    queryset = Tool.objects.all()
    # permission_classes = [permissions.IsAuthenticated]
    serializer_class = ToolSerializer

    def get_queryset(self):
        userDomain = 'dewetra_dev'

        if hasattr(self.request.user, 'domain') and self.request.user.domain is not None:
            userDomain = self.request.user.domain

        logger.info("[APP] User domain for Tool : %s", userDomain)

        related_roles = Role.objects.filter(name=userDomain)

        queryset = Tool.objects.filter(
            roles__id__in=related_roles
        )

        return queryset


class LayerView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving read-only Layer objects.

    This viewset provides the following actions:
    - list: Retrieves a list of Layer objects.
    - retrieve: Retrieves a specific Layer object by its ID.

    Additional filtering can be applied by specifying the 'category' query parameter.

    Only authenticated users are allowed to access this viewset.
    """

    queryset = Layer.objects.none()
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = LayerSerializer

    def get_queryset(self):
        """
        Returns the queryset of Layer objects.

        The queryset is filtered based on the 'category' query parameter and the user's domain.

        Returns:
            QuerySet: The filtered queryset of Layer objects.
        """
        category_name = self.request.query_params.get("category", None)

        user_data: AcrowebAuthData = self.request.user

        logger.debug("[APP]User domain for LAYERS: %s", user_data.domain)

        # related_roles = Role.objects.filter(name=user_data.domain)

        prefetch_default_tags = Prefetch(
            'tags',
            queryset=LayerTag.objects.filter(username=None, role=None),
            to_attr='default_tags'
        )

        prefetch_domain_tags = Prefetch(
            'tags',
            queryset=LayerTag.objects.filter(role__name=user_data.domain),
            to_attr='domain_tags'
        )

        prefetch_user_tags = Prefetch(
            'tags',
            queryset=LayerTag.objects.filter(username=user_data.user),
            to_attr='user_tags'
        )

        queryset = Layer.objects.select_related(
            "icon",
            "server",
            "source",
            "source__icon",
            "category",
            "geoscale",
            "infomanager",
            "legendmanager",
            "propertiesmanager",
            "metadatamanager",
            "layermanager",
        ).prefetch_related(
            prefetch_default_tags,
            prefetch_domain_tags,
            prefetch_user_tags,
            "paths",
            "paths__path",
            "roles",
            "hazards",
            "hazards__icon",
            "inspirethemes",
            "inspirethemes__icon",
            "dracategories",
            "dracategories__icon",
            "related",
        ).filter(
            enabled=True,
            roles__name=user_data.domain
        )

        if category_name is not None:
            queryset = queryset.filter(category__name=category_name)

        return queryset


class EventView(viewsets.ReadOnlyModelViewSet):
    """
    A viewset for retrieving Event objects with related layers.
    """
    queryset = Event.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = EventSerializer

    def get_queryset(self):

        userDomain = 'dewetra_dev'

        if hasattr(self.request.user, 'domain') and self.request.user.domain is not None:
            userDomain = self.request.user.domain

        related_roles = Role.objects.filter(name=userDomain)

        queryset = Event.objects.select_related(
            'icon',
        ).prefetch_related(
            'hazards',
            'datatypes'
        ).filter(
            enabled=True,
            roles__id__in=related_roles
        )

        return queryset

    @action(detail=True, methods=['get'])
    def layers(self, request, pk=None):
        event = self.get_object()
        layers = Layer.objects.filter(event=event)
        serializer = LayerSerializer(layers, many=True)
        return Response(serializer.data)

# class ScenarioView(viewsets.ReadOnlyModelViewSet):
#     queryset = Scenario.objects.all()
#     permission_classes = [permissions.IsAuthenticated]

#     # serializer di default
#     serializer_class = ScenarioSerializerList

#     def get_serializer_class(self):
#         if self.action == 'retrieve':
#             return ScenarioSerializerDetail
#         return ScenarioSerializerList

#     def get_queryset(self):
#         userDomain = 'dewetra_dev'

#         if hasattr(self.request.user, 'domain') and self.request.user.domain is not None:
#             userDomain = self.request.user.domain

#         related_roles = Role.objects.filter(name=userDomain)

#         queryset = Scenario.objects.filter(
#             roles__id__in=related_roles
#         ).distinct()

#         return queryset


def proxy(request, pk=None, path=None, format=None):
    """
    Proxies the request to a server specified by the given primary key (pk) and path.
    The function forwards the request to the server and returns the response to the client.

    Args:
        request (HttpRequest): The incoming request object.
        pk (int): The primary key of the server object to proxy the request to.
        path (str): The path to append to the server's URL.
        format (str): The desired response format.

    Returns:
        HttpResponse: The response from the server.

    Raises:
        Server.DoesNotExist: If the server with the given primary key does not exist.
    """

    try:
        server_obj = Server.objects.get(id=pk)
    except Server.DoesNotExist:
        return Response(status=404)

    target_url = server_obj.url
    if path is not None:
        target_url = f"{target_url}/{path}"

    query_params = dict(**request.query_params)

    if server_obj.token and len(server_obj.token) > 0:
        query_params['token'] = server_obj.token

    # use username and password if provided
    if server_obj.user and server_obj.password:
        auth = (server_obj.user, server_obj.password)
    else:
        auth = None

    # Forward GET request
    if request.method == 'GET':
        response = requests.get(target_url, auth=auth, params=query_params)

    # Forward POST request
    elif request.method == 'POST':
        response = requests.post(
            target_url, json=request.json, auth=auth, params=query_params)

    # Handle OPTIONS request
    elif request.method == 'OPTIONS':
        response = requests.options(target_url, auth=auth, params=query_params)

    # Forward the response from the server to the client
    proxy_response = HttpResponse(
        content=response.content,
        status=response.status_code,
        content_type=response.headers['Content-Type']
    )
    return proxy_response


def capabilities(request, pk=None, format=None):
    """
    Get the capabilities of the server and return them as json.

    Args:
        request (HttpRequest): The HTTP request object.
        pk (int, optional): The ID of the server. Defaults to None.
        format (str, optional): The format of the response. Defaults to None.

    Returns:
        Response: The capabilities of the server as a JSON response.
    """
    try:
        server_obj = Server.objects.get(id=pk)
    except Server.DoesNotExist:
        return Response(status=404)

    return get_server_capabilities(server_obj, **request.query_params)


class BypassFormatArgumentNegotiation(BaseContentNegotiation):
    """
    A content negotiation class that ignores the 'format' argument.

    This class is used to bypass the format argument negotiation in content negotiation.
    It always selects the first parser and renderer from the available options.

    """

    def select_parser(self, request, parsers):
        return parsers[0]

    def select_renderer(self, request, renderers, format_suffix):
        return (renderers[0], renderers[0].media_type)


class ExternalProxyView(APIView):
    """
    Proxy generico "open" che rilancia GET/POST/OPTIONS verso 
    qualunque URL passato via ?url=<DESTINATION>.
    ATTENZIONE: esponendo un open proxy, valuta bene i rischi di sicurezza!
    """
    permission_classes = [permissions.IsAuthenticated]
    content_negotiation_class = BypassFormatArgumentNegotiation
    http_method_names = ['get', 'post', 'options']

    def _forward(self, request):
        # Prendo l'URL di destinazione dal query-param
        dest = request.query_params.get('url')
        if not dest:
            return Response(
                {"detail": "Parametro 'url' mancante"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Copio tutti gli altri query-param (tranne 'url')
        params = {
            k: v
            for k, v in request.query_params.items()
            if k != 'url'
        }

        # Preparo i kwargs per requests
        kwargs = {
            "params": params,
            "timeout": 10,
        }
        if request.method.lower() == 'post':
            # per POST, invio JSON
            kwargs["json"] = request.data

        # Rilancio
        try:
            resp = requests.request(request.method, dest, **kwargs)
        except requests.RequestException as e:
            return Response(
                {"detail": f"Errore proxy: {str(e)}"},
                status=status.HTTP_502_BAD_GATEWAY
            )

        # Mappo la risposta
        return HttpResponse(
            content=resp.content,
            status=resp.status_code,
            content_type=resp.headers.get(
                "Content-Type", "application/octet-stream")
        )

    def get(self, request):
        return self._forward(request)

    def post(self, request):
        return self._forward(request)

    def options(self, request):
        return self._forward(request)


class CapabilitiesView(APIView):
    """
    GetCapabilities proxy view with json translation.

    This view handles the GET and OPTIONS requests for retrieving capabilities.
    It acts as a proxy to the `capabilities` function, passing the request,
    primary key (pk), and format as parameters.

    Attributes:
        content_negotiation_class (class): The content negotiation class to use.

    Methods:
        get(request, pk, format=None): Handles the GET request.
        options(request, pk, format=None): Handles the OPTIONS request.
    """
    content_negotiation_class = BypassFormatArgumentNegotiation

    def get(self, request, pk, format=None):
        return Response(capabilities(request, pk, format))

    def options(self, request, pk, format=None):
        return Response(capabilities(request, pk, format))


class ProxyView(APIView):
    """
    Custom view to proxy requests to the server.
    """

    content_negotiation_class = BypassFormatArgumentNegotiation

    def get(self, request, pk, path):
        """
        Handles GET requests to proxy data to the server.

        Args:
            request (HttpRequest): The HTTP request object.
            pk (int): The primary key of the object.
            path (str): The path to proxy the request to.

        Returns:
            HttpResponse: The response from the server.
        """
        return proxy(request, pk, path)

    def post(self, request, pk, path):
        """
        Handles POST requests to proxy data to the server.

        Args:
            request (HttpRequest): The HTTP request object.
            pk (int): The primary key of the object.
            path (str): The path to proxy the request to.

        Returns:
            HttpResponse: The response from the server.
        """
        return proxy(request, pk, path)

    def options(self, request, pk, path):
        """
        Handles OPTIONS requests to proxy data to the server.

        Args:
            request (HttpRequest): The HTTP request object.
            pk (int): The primary key of the object.
            path (str): The path to proxy the request to.

        Returns:
            HttpResponse: The response from the server.
        """
        return proxy(request, pk, path)


class AsyncProxyView(APIView):
    content_negotiation_class = BypassFormatArgumentNegotiation

    async def _proxy(self, request, pk, path=None):
        server_obj = await self._get_server(pk)
        if not server_obj:
            return Response(status=status.HTTP_404_NOT_FOUND)

        target_url = server_obj.url
        if path:
            target_url = f"{target_url}/{path}"

        query_params = request.query_params.dict()
        if server_obj.token:
            query_params['token'] = server_obj.token

        auth = (server_obj.user,
                server_obj.password) if server_obj.user and server_obj.password else None

        async with httpx.AsyncClient(timeout=10) as client:
            try:
                method = request.method.lower()
                request_func = getattr(client, method, None)
                if not request_func:
                    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

                request_kwargs = {
                    "params": query_params,
                    "auth": auth
                }

                if method in ['post', 'put', 'patch']:
                    request_kwargs["json"] = request.data

                response = await request_func(target_url, **request_kwargs)

            except httpx.RequestError as exc:
                return Response(
                    {"detail": f"Proxy error: {str(exc)}"},
                    status=status.HTTP_502_BAD_GATEWAY
                )

        content_type = response.headers['Content-Type']
        return HttpResponse(response.content, status=response.status_code, content_type=content_type)

    async def _get_server(self, pk):
        cache_key = f"server_{pk}"
        server = cache.get(cache_key)
        if server is None:
            try:
                server = await sync_to_async(Server.objects.get)(id=pk)
                cache.set(cache_key, server, timeout=60)
            except Server.DoesNotExist:
                return None
        return server

    def get(self, request, pk, path=None):
        return async_to_sync(self._proxy)(request, pk, path)

    def post(self, request, pk, path=None):
        return async_to_sync(self._proxy)(request, pk, path)

    def options(self, request, pk, path=None):
        return async_to_sync(self._proxy)(request, pk, path)


dewetra_app_router = DefaultRouter()

dewetra_app_router.register("tags", TagView)
dewetra_app_router.register("hazards", HazardView)
dewetra_app_router.register("datatypes", DataTypeView)
dewetra_app_router.register("layers", LayerView)
dewetra_app_router.register("tools", ToolView)
dewetra_app_router.register("icons", IconView)
dewetra_app_router.register("layercategory", LayerCategoryView)
dewetra_app_router.register("geoscales", GeoScaleView)
dewetra_app_router.register("dra_categories", DraCategoryView)
dewetra_app_router.register("inspirethemes", InspireThemeView)
dewetra_app_router.register("server", ServerView, basename='server')
dewetra_app_router.register("events", EventView, basename='events')
