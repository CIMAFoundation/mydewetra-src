import uuid
import threading

from concurrent.futures import ThreadPoolExecutor
from dewetra3.models import Server

from acroweb3.dds.router import DDSClientRouter
from acroweb3_api.auth import AcrowebAuthData
from acroweb3.portal_tools import PortalServiceClient
from acroweb3_api import get_logger, get_portal_backend_url

_logger = get_logger(__name__)

class MovieTaskException(Exception):
    pass

class MovieTaskRunner:

    # static cocurrent dictionary to store the task ids and associated istances
    _tasks: dict[str, "MovieTaskRunner"] = {}
    _tasks_lock = threading.Lock()

    @staticmethod
    def check_props(props:dict) -> bool:
        #props must contain the movie key
        if 'layerProperties' in props:
            props = props['layerProperties']
        if 'attributes' not in props:
            raise MovieTaskException("invalid props: attributes not found")
        movie_attr = None
        for attr in props['attributes']:
            if attr['name'] == 'movie':
                movie_attr = attr
                break;
        if movie_attr is None:
            raise MovieTaskException("invalid props: movie attribute not found")
        movie_constraints = {}
        for entry in movie_attr['entries']:
            toks = entry['value'].split('=')
            if len(toks) != 2:
                raise MovieTaskException(f"invalid movie attribute entry: {entry['value']}")
            if toks[0] not in movie_constraints:
                movie_constraints[toks[0]] = []
            movie_constraints[toks[0]].append(toks[1])
        # check contraints over all the attributes
        for attr in props['attributes']:
            key = attr['name']
            value = attr['selectedEntry']['value']
            if key in movie_constraints and value not in movie_constraints[key]:
                raise MovieTaskException(f"movie not allowed for current properties: {key}={value} not allowed")

    def __init__(self, server: Server, props:dict, items:list, t_from:int, t_to:int, user_data:AcrowebAuthData):

        self.check_props(props)

        self.executor = None
        self.task_id = uuid.uuid4().hex
        self.server = server
        self.props = props
        self.items = items
        self.t_from = t_from
        self.t_to = t_to
        self.user_data = user_data                
        self.client = DDSClientRouter().get_dds_map_client(server.url, server.user, server.password)        
        self.portal_client = PortalServiceClient(get_portal_backend_url())
        self.first_layer_pubblication = self._publish_item(items[0])      
        with MovieTaskRunner._tasks_lock:  
            MovieTaskRunner._tasks[self.task_id] = self
        _logger.info(f"Task {self.task_id} created for user {user_data.user} on server {server.url}")


    @classmethod
    def get_task(cls, task_id) -> "MovieTaskRunner":
        with cls._tasks_lock:
            return cls._tasks.get(task_id, None)    

    def _notify(self, obj):
        self.portal_client.send_notification(self.user_data.portal, self.task_id, obj)
        _logger.info(f"Notification sent to {self.user_data.portal} for task {self.task_id}: {obj}")

    def _publish_item(self, item) -> dict:
        pub = self.client.publish(self.props, item, self.t_from, self.t_to)
        if pub is None:
            raise Exception("Error publishing item")
        _logger.info(f"Item {item} published with layerid {pub['layerid']} and layertype {pub['layertype']}")
        return {
            'item': item,
            'layerid': pub['layerid'],
            'layertype': pub['layertype'],
        }


    def run(self):
        if self.executor is not None:
            raise Exception("Task already running")
        
        self.executor = ThreadPoolExecutor(max_workers=1)        
        future = self.executor.submit(self._run_and_notify, self.items[1:])
        _logger.info(f"Task {self.task_id} started for user {self.user_data.user} on server {self.server.url}")
        future.add_done_callback(self._task_finished)


    def _task_finished(self, future):
        try:
            future.result()
            _logger.info(f"Task {self.task_id} completed successfully")
            # self.portal_client.send_notification(self.user_data.portal, self.task_id, {'status': 'completed'})
            self._notify({'status': 'completed'})
        except Exception as e:
            _logger.error(f"Task {self.task_id} failed: {e}")
            # self.portal_client.send_notification(self.user_data.portal, self.task_id, {'error': str(e)})
            self._notify({'error': str(e)})
            
        finally:
            # Clean up executor and registry
            if self.executor:
                self.executor.shutdown(wait=False)
            with MovieTaskRunner._tasks_lock:
                MovieTaskRunner._tasks.pop(self.task_id, None)
            _logger.info(f"Task {self.task_id} cleaned up")


    def _run_and_notify(self, items):
        for item in items:
            try:
                res = self._publish_item(item)                
                # self.portal_client.send_notification(self.user_data.portal, self.task_id, res)
                self._notify(res)
            except Exception as e:
                _logger.error(f"Error publishing item {item}: {e}")
                break
        else:
            _logger.info(f"All items published successfully")

        
        


