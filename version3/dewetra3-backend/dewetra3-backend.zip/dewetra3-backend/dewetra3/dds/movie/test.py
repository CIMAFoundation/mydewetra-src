import requests
from datetime import datetime

base_url = "http://localhost:8000/ddsapi/"
layer_id = 269
t_from = datetime.strptime('202311160000', '%Y%m%d%H%M')
t_to = datetime.strptime('202311161000', '%Y%m%d%H%M')
period_params = {
    'from': t_from.strftime('%Y-%m-%dT%H:%M:%S'),
    'to': t_to.strftime('%Y-%m-%dT%H:%M:%S'),
}

res = requests.get(f'{base_url}properties/{layer_id}/')

props = res.json()['layerProperties']

res = requests.post(f'{base_url}availability/{layer_id}/',  
                    json={'props':props}, 
                    params=period_params)

availability = res.json()

res = requests.post(f'{base_url}create_movie_task/{layer_id}/',  
                    json={'props':props, 'data': availability}, 
                    params=period_params)
task_data = res.json()
print(f'Task created: {task_data['task_id']}. layer pubblication: {task_data['publication']}')

res = requests.get(f'{base_url}start_movie_task/{task_data['task_id']}/')

print(f'Task started: {res.text}')