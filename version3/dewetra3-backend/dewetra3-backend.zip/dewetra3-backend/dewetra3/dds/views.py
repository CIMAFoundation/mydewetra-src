import json
from datetime import date, datetime, time, timedelta
from urllib.parse import urlparse, urlunparse

import requests
from acroweb3.dds.client_2 import DDSMapClient
from acroweb3.dds.router import DDSClientRouter
from django.http import StreamingHttpResponse
from rest_framework import status, viewsets
from rest_framework.decorators import action, api_view
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.routers import DefaultRouter

from dewetra3.commons.logs import log
from dewetra3.dds.movie.task import MovieTaskException, MovieTaskRunner
from dewetra3.models import Layer, Serie
from dewetra3.serializers import LayerSerializer, ServerSerializer


class DDSDynamicLayer(viewsets.ViewSet):
    """
    ViewSet for handling dynamic layers in the DDS application.
    """


class DDSDynamicLayer(viewsets.ViewSet):

    # permission_classes = [IsAuthenticated]

    def __get_lat_lon(self, request):
        """
        Get the latitude and longitude from the request query parameters.

        Args:
            request (Request): The request object.

        Returns:
            Tuple[float, float]: A tuple containing the latitude and longitude as floats.
            If either latitude or longitude is missing in the request query parameters, returns (None, None).
        """
        lat = request.query_params.get('lat', None)
        lon = request.query_params.get('lon', None)
        if lat is None or lon is None:
            return None, None
        return float(lat), float(lon)

     # Helper function to parse date strings or timestamps
    def __parse_datetime(self, dt_str, default):
        if dt_str is None:
            return default
        try:
            # Check if dt_str is a timestamp by converting it to a string and checking if all characters are digits
            if str(dt_str).isdigit():
                return datetime.fromtimestamp(int(dt_str))
            # Otherwise, parse as ISO format
            return datetime.fromisoformat(dt_str)
        except (ValueError, TypeError):
            raise ValueError(
                "Invalid date format. Expected ISO format or Unix timestamp.")

    def __get_request_period(self, request):
        """
        Get the request period from the query parameters or request body.

        Args:
            request (HttpRequest): The HTTP request object.

        Returns:
            tuple: A tuple containing the start and end datetime objects, 
                as well as their corresponding timestamps.
        """
        # Attempt to retrieve 'from' and 'to' from query params or request body as fallback
        dt_from_str = request.query_params.get(
            'from') or request.data.get('from')
        dt_to_str = request.query_params.get('to') or request.data.get('to')

        # Determine dt_to and dt_from with defaults if missing
        dt_to = self.__parse_datetime(dt_to_str, datetime.now())
        dt_from = self.__parse_datetime(dt_from_str, dt_to - timedelta(days=1))

        # Calculate timestamps
        t_from = dt_from.timestamp()
        t_to = dt_to.timestamp()

        return dt_from, dt_to, t_from, t_to

    def __get_variables_attr(self, props):
        """
        Retrieves the 'variable' attribute from the given properties.

        Args:
            props (dict): The properties dictionary.

        Returns:
            dict or None: The 'variable' attribute dictionary if found, None otherwise.
        """
        if 'layerProperties' not in props or 'attributes' not in props['layerProperties']:
            return None
        for attr in props['layerProperties']['attributes']:
            if 'name' in attr and attr['name'] == 'variable':
                return attr
        return None

    def __set_variable(self, props, variable):
        """
        Sets the selected entry in the variables attribute based on the given variable value.

        Args:
            props (dict): The properties dictionary.
            variable: The variable value to set.

        Returns:
            None
        """
        attr = self.__get_variables_attr(props)
        for entry in attr['entries']:
            if entry['value'] == variable:
                attr['selectedEntry'] = entry
                break

    def list(self, request):
        return Response()

    @action(detail=False, methods=['get'], url_path='variables/(?P<layer_id>[^/.]+)')
    def variables(self, request, layer_id):
        """
        Retrieves the variables associated with a layer.

        Args:
            request (HttpRequest): The HTTP request object.
            layer_id (int): The ID of the layer.

        Returns:
            Response: The response containing the variables associated with the layer.
        """

        layer = Layer.objects.get(id=layer_id)
        log(request, 'info', f"[DDS->GET VARIABLES]Layer id {layer_id}")
        client = DDSClientRouter().get_dds_map_client(
            layer.server.url, layer.server.user, layer.server.password)
        props = client.properties(layer_id)
        attr = self.__get_variables_attr(props)
        variables = []
        if attr is None:
            variables.append({
                'id': layer_id,
                'descr': props['layerProperties']['description']
            })
        else:
            for entry in attr['entries']:
                variables.append({
                    'id': entry['value'],
                    'descr': entry['descr']
                })
        log(request, 'info',
            f"[DDS->GET VARIABLES]Layer id {layer_id} - Variables Response")
        return Response(variables)

    @action(detail=False, methods=['get'], url_path='properties/(?P<layer_id>[^/.]+)')
    def properties(self, request, layer_id):
        """
        Retrieve the properties of a layer.

        Args:
            request (HttpRequest): The HTTP request object.
            layer_id (int): The ID of the layer.

        Returns:
            Response: The response containing the properties of the layer.

        Raises:
            Layer.DoesNotExist: If the layer with the given ID does not exist.
            status.HTTP_500_INTERNAL_SERVER_ERROR: If the properties are invalid or an internal server error occurs.
        """

        layer = Layer.objects.get(id=layer_id)
        log(request, 'info', f"[DDS->GET PROPERTIES]Layer id {layer_id}")
        client = DDSClientRouter().get_dds_map_client(
            layer.server.url, layer.server.user, layer.server.password)
        props = client.properties(layer.dataid)

        if props is None:
            return Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response(props)

    @action(detail=False, methods=['post'], url_path='availability/(?P<layer_id>[^/.]+)')
    def availabilty(self, request, layer_id):
        """
        Retrieves the availability of a layer based on the provided request and layer ID.

        Args:
            request (HttpRequest): The HTTP request object.
            layer (int): The ID of the layer.

        Returns:
            Response: The availability of the layer.

        Raises:
            Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR): If the request data is invalid.
        """
        _, _, t_from, t_to = self.__get_request_period(request)

        layerObj = Layer.objects.get(id=layer_id)

        log(request, 'info', f"[DDS->GET AVAILABILITY]Layer id {layer_id}")

        props_from_client = request.data.get('props', None)

        if props_from_client is None:
            return Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        client = DDSClientRouter().get_dds_map_client(
            layerObj.server.url, layerObj.server.user, layerObj.server.password)

        props = client.properties(layerObj.dataid)
        if 'layerProperties' not in props or 'attributes' not in props['layerProperties']:
            log(request, 'error',
                f"[DDS->GET AVAILABILITY]Layer id {layer_id} - Get properties failed")
            return Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        avs = client.availability(props_from_client, t_from, t_to)
        if avs is None:
            log(request, 'error',
                f"[DDS->GET AVAILABILITY]Layer id {layer_id} - Get availability failed")
            return Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response(avs)

    @action(detail=False, methods=['post'], url_path='publish/(?P<layer>[^/.]+)')
    def publish(self, request, layer):
        """
        Publishes a layer using the provided request and layer ID.

        Args:
            request (HttpRequest): The HTTP request object.
            layer (int): The ID of the layer to publish.

        Returns:
            Response: The response containing the published layer ID and type.

        Raises:
            Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR): If the data is invalid.
        """

        layerObj = Layer.objects.get(id=layer)

        log(request, 'info', f"[DDS->PUBLISH]Layer id {layer}")

        _, _, t_from, t_to = self.__get_request_period(request)

        client = DDSClientRouter().get_dds_map_client(
            layerObj.server.url, layerObj.server.user, layerObj.server.password)

        props = client.properties(layerObj.dataid)
        if 'layerProperties' not in props or 'attributes' not in props['layerProperties']:
            log(request, 'error',
                f"[DDS->PUBLISH]Layer id {layer} - Get properties failed")
            return Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        avs = client.availability(props, t_from, t_to)
        if avs is None or len(avs) == 0:
            log(request, 'error',
                f"[DDS->PUBLISH]Layer id {layer} - Get availability failed")
            return Response(f'data not found', status=status.HTTP_404_NOT_FOUND)

        log(request, 'info',
            f"[DDS->PUBLISH]Layer id {layer} - Layer availability: {len(avs)}")

        pub = client.publish(props, avs[0], t_from, t_to)
        if pub is None:
            log(request, 'error',
                f"[DDS->PUBLISH]Layer id {layer} - Publish failed")
            return Response(f'publish failed', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        log(request, 'info',
            f"[DDS->PUBLISH]Layer id {layer} - Layer published")

        return Response({
            'layerid': pub['layerid'],
            'layertype': pub['layertype'],
        })

    @action(detail=False, methods=['post'], url_path='republish/(?P<layer_id>[^/.]+)')
    def republish(self, request, layer_id):
        """
        Republishes a layer with the given layer_id using the provided request.

        Args:
            request (HttpRequest): The HTTP request object.
            layer_id (int): The ID of the layer to republish.

        Returns:
            Response: The HTTP response containing the republishing result.

        Raises:
            Layer.DoesNotExist: If the layer with the given layer_id does not exist.
            status.HTTP_500_INTERNAL_SERVER_ERROR: If the provided data is invalid.

        """
        layer = Layer.objects.get(id=layer_id)

        log(request, 'info', f"[DDS->REPUBLISH]Layer id {layer_id}")

        _, _, t_from, t_to = self.__get_request_period(request)

        client = DDSClientRouter().get_dds_map_client(
            layer.server.url, layer.server.user, layer.server.password)

        props_from_client = request.data.get('props', None)

        item_from_client = request.data.get('data', None)

        if 'layerProperties' not in props_from_client or 'attributes' not in props_from_client['layerProperties']:
            log(request, 'error',
                f"[DDS->REPUBLISH]Layer id {layer_id} - Get properties failed")
            return Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        pub = client.publish(props_from_client, item_from_client, t_from, t_to)

        if pub is None:
            log(request, 'error',
                f"[DDS->REPUBLISH]Layer id {layer_id} - Publish failed")
            return Response(f'publish failed', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        log(request, 'info',
            f"[DDS->REPUBLISH]Layer id {layer_id} - Layer republished")

        return Response({
            'layerid': pub['layerid'],
            'layertype': pub['layertype'],
        })

    @action(detail=False, methods=['post'], url_path='is_movie_allowed')
    def is_movie_allowed(self, request):
        """
        Checks if a movie is allowed for the given properties.

        Args:
            request (HttpRequest): The HTTP request object.

        Returns:
            Response: The HTTP response indicating whether the movie is allowed or not.

        Raises:
            status.HTTP_500_INTERNAL_SERVER_ERROR: If the provided data is invalid.
        """
        props_from_client = request.data.get('props', None)

        try:
            MovieTaskRunner.check_props(props_from_client)
        except MovieTaskException as e:
            log(request, 'error', f"[DDS->MOVIE ALLOWED] - {e}")
            return Response(str(e), status=status.HTTP_403_FORBIDDEN)

        return Response({
            'status': 'OK',
        })

    @action(detail=False, methods=['post'], url_path='create_movie_task/(?P<layer_id>[^/.]+)')
    def create_movie_task(self, request, layer_id):
        """
        Republishes a layer with the given layer_id using the provided request.

        Args:
            request (HttpRequest): The HTTP request object.
            layer_id (int): The ID of the layer to republish.

        Returns:
            Response: The HTTP response containing the republishing result.

        Raises:
            Layer.DoesNotExist: If the layer with the given layer_id does not exist.
            status.HTTP_500_INTERNAL_SERVER_ERROR: If the provided data is invalid.

        """
        layer = Layer.objects.get(id=layer_id)

        log(request, 'info', f"[DDS->CREATE MOVIE TASK]Layer id {layer_id}")

        _, _, t_from, t_to = self.__get_request_period(request)

        props_from_client = request.data.get('props', None)

        items_from_client = request.data.get('data', None)

        try:
            task_runner = MovieTaskRunner(
                layer.server,
                props_from_client,
                items_from_client,
                t_from,
                t_to,
                request.user,
            )
        except MovieTaskException as e:
            log(request, 'error',
                f"[DDS->CREATE MOVIE TASK]Layer id {layer_id} - Create task failed: {e}")
            return Response(str(e), status=status.HTTP_403_FORBIDDEN)

        return Response({
            'task_id': task_runner.task_id,
            'publication': task_runner.first_layer_pubblication,
        })

    @action(detail=False, methods=['get'], url_path='start_movie_task/(?P<task_id>[^/.]+)')
    def start_movie_task(self, request, task_id):
        """
        Starts a movie task with the given task ID.

        Args:
            request (HttpRequest): The HTTP request object.
            task_id (str): The ID of the task to start.

        Returns:
            Response: The HTTP response containing the result of starting the task.

        Raises:
            Layer.DoesNotExist: If the layer with the given layer_id does not exist.
            status.HTTP_500_INTERNAL_SERVER_ERROR: If the provided data is invalid.
        """
        task_runner = MovieTaskRunner.get_task(task_id)
        if task_runner is None:
            return Response(f'task not found', status=status.HTTP_404_NOT_FOUND)

        task_runner.run()

        return Response({
            'status': 'OK',
        })

    @action(detail=False, methods=['get'], url_path='publish_default/(?P<layer_id>[^/.]+)')
    def publish_default(self, request, layer_id):
        """
        Publishes the default layer for a given layer ID.

        Args:
            request: The HTTP request object.
            layer_id: The ID of the layer to publish.

        Returns:
            A Response object containing the server URL and the published layer ID.

        Raises:
            HTTP_500_INTERNAL_SERVER_ERROR: If the layer properties or attributes are invalid.
            HTTP_404_NOT_FOUND: If the data is not found.
        """

        _, _, t_from, t_to = self.__get_request_period(request)

        layer = Layer.objects.get(id=layer_id)

        client = DDSClientRouter().get_dds_map_client(
            layer.server.url, layer.server.user, layer.server.password)

        props = client.properties(layer_id)
        if 'layerProperties' not in props or 'attributes' not in props['layerProperties']:
            log(request, 'error',
                f"[DDS->PUBLISH_DEFAULT]Layer id {layer_id} - Get properties failed")
            return Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        # get availability
        avs = client.availability(props, t_from, t_to)

        if avs is None or len(avs) == 0:
            log(request, 'error',
                f"[DDS->PUBLISH_DEFAULT]Layer id {layer_id} - Get availability failed")
            return Response(f'data not found', status=status.HTTP_404_NOT_FOUND)

        pub = client.publish(props, avs[0], t_from, t_to)

        if pub is None:
            log(request, 'error',
                f"[DDS->PUBLISH_DEFAULT]Layer id {layer_id} - Publish failed")
            return Response(f'publish failed', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        log(request, 'info',
            f"[DDS->PUBLISH_DEFAULT]Layer id {layer_id} - Layer published")

        return Response({
            'server': layer.server.url,
            'layerid': pub['layerid']
        })

    @action(detail=False, methods=['get'], url_path='layerstyle/(?P<layer>[^/.]+)/(?P<layer_id>[^/.]+)')
    def layerstyle(self, request, layer, layer_id):
        """
        Retrieves the layer style for a given layer ID.

        Args:
            request (HttpRequest): The HTTP request object.
            layer (int): The ID of the layer.
            layer_id (int): The ID of the layer style.

        Returns:
            Response: A JSON response containing the legend for the layer style.
        """
        layer = Layer.objects.get(id=layer)
        log(request, 'info', f"[DDS->GET LAYERSTYLE]Layer id {layer_id}")
        client = DDSClientRouter().get_dds_map_client(
            layer.server.url, layer.server.user, layer.server.password)
        legend = client.getLayerStyle(layer_id)

        if legend is None:
            log(request, 'error',
                f"[DDS->GET LAYERSTYLE]Layer id {layer_id} - Get layer style failed")
            return Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response({
            'legend': json.loads(legend)
        })

    @action(detail=False, methods=['get'], url_path='floodproof/layer/(?P<layer_id>[^/.]+)/(?P<now>[^/.]+)')
    def floodproof(self, request, layer_id, now):
        """
        Retrieves floodproof features for a given layer and time range.

        Args:
            request (HttpRequest): The HTTP request object.
            layer_id (int): The ID of the layer to retrieve floodproof features for.
            now (int): The current timestamp.

        Returns:
            Response: The HTTP response containing the floodproof features.
        """

        layer = Layer.objects.get(id=layer_id)

        log(request, 'info', f"[DDS->FLOODPROOF]Layer id {layer_id}")

        now = int(now)

        t_from = now - 86400  # 24 hours in seconds

        client = DDSClientRouter().get_dds_serie_client(
            layer.server.url, layer.server.user, layer.server.password)

        features = client.featuresDDS(layer.dataid, t_from, now)

        if features is None:
            log(request, 'error',
                f"[DDS->FLOODPROOF]Layer id {layer_id} - Get floodproof features failed")
            return Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        log(request, 'info',
            f"[DDS->FLOODPROOF]Layer id {layer_id} - Floodproof features")

        return Response(features)

    @action(detail=False, methods=['get'], url_path='floodproof/compatibles/(?P<layer_id>[^/.]+)')
    def floodproofCompatibles(self, request, layer_id):
        """
        Retrieves floodproof compatibles for a given layer.

        Args:
            request: The HTTP request object.
            layer: The ID of the layer.

        Returns:
            A Response object containing the floodproof compatibles.
        """
        layer_id = Layer.objects.get(id=layer_id)

        log(request, 'info',
            f"[DDS->FLOODPROOF COMPATIBLES]Layer id {layer_id}")

        client = DDSClientRouter().get_dds_serie_client(
            layer_id.server.url, layer_id.server.user, layer_id.server.password)
        compatibles = client.compatibles(layer_id.dataid)

        # filter compatibles with the allowed series ids
        roles = []  # TODO: request.user.roles
        allowed_series = Serie.objects.filter(roles__in=roles)
        allowed_series_ids = [s.name for s in allowed_series]
        allowed_compatibles = [
            c for c in compatibles if c['id'] in allowed_series_ids]

        log(request, 'info',
            f"[DDS->FLOODPROOF COMPATIBLES]Layer id {layer_id} - Floodproof compatibles")

        return Response({
            'compatibles': compatibles
        })

    @action(detail=False, methods=['post'], url_path='punctualserie/(?P<layer_id>[^/.]+)')
    def punctualserie(self, request, layer_id):
        """
        Retrieve punctual series data from the DDS client.

        Args:
            request (HttpRequest): The HTTP request object.
            layer (int): The ID of the layer to retrieve data from.

        Returns:
            Response: The HTTP response containing the punctual series data.
        """
        layer_id = Layer.objects.get(id=layer_id)
        log(request, 'info', f"[DDS->PUNCTUALSERIE]Layer id {layer_id}")
        props_from_client = request.data.get('props', None)
        t_from = request.data.get('from', None)
        t_to = request.data.get('to', None)
        lat = request.data.get('lat', None)
        lon = request.data.get('lon', None)

        client = DDSClientRouter().get_dds_map_client(
            layer_id.server.url, layer_id.server.user, layer_id.server.password)
        series = client.punctualSerie(
            props_from_client, t_from, t_to, lon, lat)

        if series is None:
            log(request, 'error',
                f"[DDS->PUNCTUALSERIE]Layer id {layer_id} - Get punctual serie failed")
            return Response(f'invalid data', status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        log(request, 'info',
            f"[DDS->PUNCTUALSERIE]Layer id {layer_id} - Punctual serie")

        return Response(series)

    @action(detail=False, methods=['get'], url_path='download_url/(?P<layer_id>[^/.]+)/(?P<dds_layer_id>[^/.]+)')
    def download(self, request, layer_id, dds_layer_id):
        """
        Retrieves the download URL for a given layer ID.

        Args:
            request (HttpRequest): The HTTP request object.
            dds_layer_id (int): The ID of the layer.

        Returns:
            Response: The HTTP response containing the download URL for the layer.
        """
        layer = Layer.objects.get(id=layer_id)
        log(request, 'info', f"[DDS->GET DOWNLOAD URL]Layer id {dds_layer_id}")
        client: DDSMapClient = DDSClientRouter().get_dds_map_client(
            layer.server.url, layer.server.user, layer.server.password)
        remote_relative_url, file_ext = client.getDownloadURLAndType(
            dds_layer_id)
        # server_url_parts = urlparse(layer.server.url)
        # server_url = urlunparse((server_url_parts.scheme, server_url_parts.netloc, '', '', '', ''))
        server_url = layer.server.url + ('/' if not layer.server.url.endswith(
            '/') and not remote_relative_url.startswith('/') else '')
        remote_url = server_url + remote_relative_url
        try:
            resp = requests.get(remote_url, stream=True, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as exc:
            return Response(
                {'detail': f'Could not fetch remote file: {exc}'},
                status=status.HTTP_502_BAD_GATEWAY
            )

        streamer = StreamingHttpResponse(
            streaming_content=resp.iter_content(chunk_size=8192),
            content_type=resp.headers.get(
                'Content-Type', 'application/octet-stream')
        )
        # forward Content-Length if provided
        content_length = resp.headers.get('Content-Length')
        if content_length:
            streamer['Content-Length'] = content_length

        # Override the filename for the client with the one in the request parameters
        # or use a default name if not provided
        filename = request.query_params.get('filename', None)
        if filename is None:
            filename = dds_layer_id
        filename = f'{filename}.{file_ext}'

        streamer['Content-Disposition'] = f'attachment; filename="{filename}"'

        return streamer


dds_app_router = DefaultRouter()

dds_app_router.register('', DDSDynamicLayer, basename='')
