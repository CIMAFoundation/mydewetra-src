# Description: This file contains the views for the FloodCat API.
import json
import logging
import os

import requests
from acroweb3.sentinel.client import SentinelClient
from django.http import HttpResponse
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.routers import DefaultRouter
from dewetra3.settings import FLOODCAT_BACKEND_URL
from dewetra3.commons.logs import log

# api/flood_event_locations/?ids=3832,283
#https://bricks-dev.cimafoundation.org/api/floodcat/api/flood_events/?tags__tag=test
#http://localhost/api/floodcat/api/flood_events/?tags__tag=test?token
TOKEN = 'm0cfpXOIZefFbqWIQU0PK7Le11yUSaEmgIua8lSOf0pAo2vFx3P0GxV0oJ2rrAzQ3s5TsKS5ChCBZrdXbO7sviH6m2CRKGqKTF5hfd2bcLs6grfTKrSiGcebTzurSUsq'
FLOODCAT_API_BASE_URL = FLOODCAT_BACKEND_URL+'/api'
#BASE_URL = 'https://bricks-developers-access.cimafoundation.org/api/floodcat/api'




class FloodCatView(viewsets.ViewSet):
    permission_classes = [permissions.AllowAny]

    @action(detail=False, methods=['get'], url_path='flood_events/(?P<tags>[^/.]+)')
    def flood_events(self, request, tags):
        log(request, 'info', f"[FLOODCAT -> get flood events] Requesting flood events with tags: {tags}")
        url = FLOODCAT_API_BASE_URL + '/flood_events/?tags__tag=' + tags
        headers = {'Authorization': 'Token ' + TOKEN}
        resp = requests.get(f'{url}', headers=headers, verify=False)
        if(resp.status_code == 200):
            log(request, 'info', f"[FLOODCAT] Successfully requested flood events with tags: {tags}")
            return Response(resp)
        else:
            log(request, 'error', f"[FLOODCAT] Error requesting flood events with tags: {tags}")
            return Response(resp, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['get'], url_path='flood_event_locations/(?P<ids>[^/.]+)')
    def flood_event_locations(self, request, ids):
        log(request, 'info', f"[FLOODCAT -> get flood locations] Requesting flood event locations with ids: {ids}")
        url = FLOODCAT_API_BASE_URL + '/flood_event_locations/?ids=' + ids
        headers = {'Authorization': 'Token ' + TOKEN}
        resp = requests.get(f'{url}', headers=headers, verify=False)
        if(resp.status_code == 200):
            log(request, 'info', f"[FLOODCAT] Successfully requested flood event locations with ids: {ids}")
            return Response(resp)
        else:
            log(request, 'error', f"[FLOODCAT] Error requesting flood event locations with ids: {ids}")
            return Response(resp, status=status.HTTP_400_BAD_REQUEST)


# router for the views
flood_cat_router = DefaultRouter()
flood_cat_router.register('', FloodCatView, basename='')
