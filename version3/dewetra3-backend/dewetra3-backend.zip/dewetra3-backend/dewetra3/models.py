from django.db import models
from django.db.models.deletion import CASCADE, SET_NULL

# abstract base classes from all models


class AbstractNameModel(models.Model):
    class Meta:
        abstract = True

    name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return self.name


class AbstractDescrModel(AbstractNameModel):
    class Meta:
        abstract = True

    descr = models.TextField(blank=True)

    def __str__(self):
        return self.descr


class Icon(AbstractNameModel):
    value = models.TextField(blank=True)

    def __str__(self):
        return self.name


class AbstractIconDescrModel(AbstractDescrModel):
    class Meta:
        abstract = True

    icon = models.ForeignKey(
        Icon, null=True, on_delete=SET_NULL, blank=True, default=None
    )

    def __str__(self):
        return self.descr


class AbstractWithComponentModel(AbstractDescrModel):
    class Meta:
        abstract = True

    component = models.CharField(max_length=255)
    props = models.JSONField(blank=True, null=True, default=None)

    def __str__(self):
        return "%s (%s) " % (self.name, self.component)


class AbstractWithPropertiesModel(AbstractDescrModel):
    class Meta:
        abstract = True

    props = models.JSONField(blank=True, null=True, default=None)

    def __str__(self):
        return "%s (%s) " % (self.name, self.component)


# ===============================================================================
# dds management models
# ===============================================================================


class Server(AbstractDescrModel):
    url = models.CharField(max_length=255)
    user = models.CharField(max_length=255, null=True,
                            blank=True, default=None)
    password = models.CharField(
        max_length=255, null=True, blank=True, default=None)
    token = models.TextField(blank=True, null=True, default=None)

    use_proxy = models.BooleanField(
        default=False,
        help_text="Client should use the provided proxy endpoint for this server",
    )

    def __str__(self):
        return self.descr


# ===============================================================================
# permission management models
# ===============================================================================


class Role(AbstractNameModel):
    pass


# ===============================================================================
# tools management models
# ===============================================================================

class Tool(AbstractWithComponentModel):
    """
    This class is used to manage the tools that are available in the application
    """
    icon = models.ForeignKey(
        Icon, null=True, on_delete=SET_NULL, blank=True, default=None
    )
    # roles enableb for the layer (= permissions)
    roles = models.ManyToManyField(
        Role, blank=True, default=None, related_name="tools"
    )

# ===============================================================================
# layers management models
# ===============================================================================


class Tag(AbstractIconDescrModel):
    order = models.IntegerField(
        null=True, blank=True, default=None,
        help_text="Order of the tag in the layer's tags list"
    )
    pass


class Source(AbstractIconDescrModel):
    pass


class InspireTheme(AbstractIconDescrModel):
    pass


class Hazard(AbstractIconDescrModel):
    pass


class DataType(AbstractIconDescrModel):
    pass


class DraCategory(AbstractIconDescrModel):
    pass


class Path(AbstractNameModel):
    pass


class PathHierarchy(models.Model):
    path = models.ForeignKey(Path, on_delete=CASCADE, related_name="hierarchy")
    hierarchy = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.path} ({self.hierarchy})"


class LayerCategory(AbstractNameModel):
    pass


class GeoScale(AbstractDescrModel):
    pass


class Event(AbstractIconDescrModel):

    enabled = models.BooleanField(default=True)
    date = models.DateField(default='1970-01-01')
    lat = models.FloatField(default='44')
    lon = models.FloatField(default='8')
    datatypes = models.ManyToManyField(DataType, blank=True, default=None)
    floodcatid = models.CharField(
        max_length=255, null=True, blank=True, default=None)
    hazards = models.ManyToManyField(Hazard, blank=True, default=None)
    roles = models.ManyToManyField(
        Role, blank=True, default=None, related_name="events"
    )


class LegendManager(AbstractWithComponentModel):
    # override the name fields because in this case it is not unique
    name = models.CharField(max_length=255)


class PropertiesManager(AbstractWithComponentModel):
    """
    This class is used to manage the properties of the layer
    """
    pass


class InfoManager(AbstractWithComponentModel):
    """
    This class is used to manage the information coming from the layer
    """
    pass


class LayerManager(AbstractWithComponentModel):
    """
    This class is used to manage the data from the layer
    """
    pass


class MapManager(AbstractWithComponentModel):
    """
    This class is used to manage the visualization of the layer on the map 
    """
    pass


class ChartManager(AbstractWithComponentModel):
    """
    This class is used to manage the visualization of the charts coming from the layer
    """
    pass


class MetadataManager(AbstractWithComponentModel):
    # override the name fields because in this case it is not unique
    name = models.CharField(max_length=255)


class Layer(AbstractIconDescrModel):
    # data access
    dataid = models.CharField(max_length=255)
    name_i18n = models.CharField(
        max_length=255, null=True, blank=True, default=None)
    server = models.ForeignKey(Server, null=True, on_delete=SET_NULL)

    # layer thumb
    thumb = models.CharField(max_length=255, null=True, blank=True)

    # layers source (supplier)
    source = models.ForeignKey(
        Source, null=True, on_delete=SET_NULL, blank=True, default=None
    )

    # bounding box
    lonw = models.FloatField()
    lone = models.FloatField()
    lats = models.FloatField()
    latn = models.FloatField()

    # layer enabled
    enabled = models.BooleanField(default=True)

    # layer properties for menu composition
    category = models.ForeignKey(
        LayerCategory, null=True, on_delete=SET_NULL, related_name="layers"
    )
    event = models.ManyToManyField(
        Event, blank=True, default=None, related_name="layers"
    )
    hazards = models.ManyToManyField(Hazard, blank=True, default=None)
    geoscale = models.ForeignKey(
        GeoScale, null=True, on_delete=SET_NULL, default=None)
    # tags = models.ManyToManyField(Tag, null=True, blank=True, default=None)
    # tags is a many to many field with a through model LayerTag
    tags = models.ManyToManyField(
        Tag, through="LayerTag", blank=True, default=None)
    inspirethemes = models.ManyToManyField(
        InspireTheme, blank=True, default=None)
    dracategories = models.ManyToManyField(
        DraCategory, blank=True, default=None)
    paths = models.ManyToManyField(PathHierarchy, blank=True, default=None)

    # managers for all the frontend views
    infomanager = models.ForeignKey(
        InfoManager, null=True, on_delete=SET_NULL, blank=True, default=None
    )

    legendmanager = models.ForeignKey(
        LegendManager, null=True, on_delete=SET_NULL, blank=True, default=None
    )

    propertiesmanager = models.ForeignKey(
        PropertiesManager, null=True, on_delete=SET_NULL, blank=True, default=None
    )

    metadatamanager = models.ForeignKey(
        MetadataManager, null=True, on_delete=SET_NULL, blank=True, default=None
    )

    layermanager = models.ForeignKey(
        LayerManager, null=True, on_delete=SET_NULL, blank=True, default=None
    )

    mapmanager = models.ForeignKey(
        MapManager, null=True, on_delete=SET_NULL, blank=True, default=None
    )

    chartmanager = models.ForeignKey(
        ChartManager, null=True, on_delete=SET_NULL, blank=True, default=None
    )

    # roles enableb for the layer (= permissions)
    roles = models.ManyToManyField(
        Role, blank=True, default=None, related_name="layers"
    )

    # layer custom properties
    customprops = models.JSONField(blank=True, null=True, default=None)

    # Used to manage logical layer groups. Recursive loading supported in frontend. Avoid cycles!
    related = models.ManyToManyField(
        "self", symmetrical=False, blank=True, default=None)

    creator = models.CharField(
        max_length=255, null=True, blank=True, default=None)

    def __str__(self):
        return "%s %s (%s) (%s)" % (
            self.name,
            self.dataid,
            self.layermanager,
            self.category.name,
        )


# ===============================================================================
# LayerTag model
# ===============================================================================

class LayerTag(models.Model):
    layer = models.ForeignKey(Layer, on_delete=CASCADE)
    tag = models.ForeignKey(Tag, on_delete=CASCADE, related_name="layers")
    role = models.ForeignKey(Role, null=True, blank=True,
                             on_delete=CASCADE, related_name="tags")
    username = models.CharField(
        max_length=255, null=True, blank=True, default=None)

    def __str__(self):
        return f"{self.layer} - {self.tag}"


# ===============================================================================
# Scenario management models
# ===============================================================================

class Scenario(AbstractDescrModel):
    aoisize = models.IntegerField(null=True, blank=True, default=None)
    roles = models.ManyToManyField(Role, blank=True, default=None)
    exposures = models.ManyToManyField(
        Layer, blank=True, default=None, related_name="scenario_exposure_layers")
    hazards = models.ManyToManyField(
        Layer, blank=True, default=None, related_name="scenario_hazard_layers")


# ===============================================================================
# series management models
# ===============================================================================


class Serie(AbstractNameModel):
    roles = models.ManyToManyField(Role, related_name="series")

    def __str__(self):
        return self.descr


# ===============================================================================
# Charts management models
# ===============================================================================
class Chart(AbstractWithPropertiesModel):
    type = models.CharField(max_length=255)

    def __str__(self):
        return self.descr


# ===============================================================================
# widget
# ===============================================================================
class Widget(models.Model):
    name = models.CharField(max_length=255, unique=True)
    layer = models.ForeignKey(Layer, on_delete=CASCADE)
    mode = models.CharField(max_length=255, null=True, blank=True)
    wmsparams = models.CharField(max_length=1024, null=True, blank=True)
    wmsbaselayer = models.CharField(max_length=255, null=True, blank=True)
    alwaysupdate = models.BooleanField(default=False, blank=True)
    period = models.IntegerField(null=True, blank=True)
    properties = models.JSONField(null=True, blank=True)

    def __str__(self):
        return f"{self.name} - {self.layer.dataid}"
