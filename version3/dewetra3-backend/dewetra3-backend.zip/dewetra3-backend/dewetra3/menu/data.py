import os
from dataclasses import dataclass, field
from typing import Optional

from acroweb3_api.auth import AcrowebAuthData

from dewetra3.models import (Icon, InfoManager, Layer, LayerCategory,
                             LayerManager, LegendManager, MapManager,
                             MetadataManager, Role, Source)


def _get_django_model_obj_from_name(model_calss: any, name: str):
    if not name:
        return None
    qs = model_calss.objects.filter(name=name)
    if qs.exists():
        if qs.count() > 1:
            raise Exception(f'{model_calss} with name {name} is not unique')
        return qs.first()
    raise Exception(f'{model_calss} with name {name} does not exist')


def _get_django_model_obj_from_component(model_calss: any, name: str):
    if not name:
        return None
    qs = model_calss.objects.filter(component=name)
    if qs.exists():
        if qs.count() > 1:
            raise Exception(f'{model_calss} with name {name} is not unique')
        return qs.first()
    raise Exception(f'{model_calss} with name {name} does not exist')


@dataclass
class MenuLayerData:
    # fields from request
    name: str
    descr: str
    icon: str
    dataid: str
    lonw: float
    lone: float
    lats: float
    latn: float
    category_id: int
    geoscale_id: int
    server_id: int
    roles: list[str]

    hazard_ids: list[int] = None
    tag_ids: list[int] = None
    inspire_theme_ids: list[int] = None
    dra_category_ids: list[int] = None
    path_ids: list[int] = None
    source: Optional[str] = None

    # server fields
    icon_obj: any = field(init=False)
    source_obj: any = field(init=False)
    roles_obj: list[any] = field(init=False)
    info_manager_obj: any = field(init=False)
    legend_manager_obj: any = field(init=False)
    properties_manager_obj: any = field(init=False)
    metadata_manager_obj: any = field(init=False)
    layer_manager_obj: any = field(init=False)
    map_manager_obj: any = field(init=False)
    chart_manager_obj: any = field(init=False)

    def _set_from_env(self):
        self.icon_obj = _get_django_model_obj_from_name(Icon, self.icon)
        self.source_obj = _get_django_model_obj_from_name(Source, self.source)
        self.roles_obj = [_get_django_model_obj_from_name(
            Role, d) for d in self.roles]


@dataclass
class StaticLayerData(MenuLayerData):

    def __post_init__(self):
        self._set_from_env()
        self.layer_manager_obj = _get_django_model_obj_from_component(
            LayerManager, os.environ.get(f'DEFAULT_STATIC_LAYER_MANAGER_NAME', 'STATICWMSLayerManager'))
        self.info_manager_obj = _get_django_model_obj_from_component(
            InfoManager, os.environ.get(f'DEFAULT_STATIC_INFO_MANAGER_NAME', 'WMSLayerInfoComponent'))
        self.legend_manager_obj = _get_django_model_obj_from_component(LegendManager, os.environ.get(
            f'DEFAULT_STATIC_LEGEND_MANAGER_NAME', 'StaticWMSLegendComponent'))
        self.map_manager_obj = _get_django_model_obj_from_component(
            MapManager, os.environ.get(f'DEFAULT_STATIC_MAP_MANAGER_NAME', 'StaticMapComponent'))
        self.properties_manager_obj = _get_django_model_obj_from_component(
            MetadataManager, os.environ.get(f'DEFAULT_STATIC_PROPERTIES_MANAGER_NAME', None))
        self.metadata_manager_obj = _get_django_model_obj_from_component(
            MetadataManager, os.environ.get(f'DEFAULT_STATIC_METADATA_MANAGER_NAME', None))
        self.chart_manager_obj = _get_django_model_obj_from_component(
            MapManager, os.environ.get(f'DEFAULT_STATIC_CHART_MANAGER_NAME', None))


@dataclass
class DynamicLayerData(MenuLayerData):

    def __post_init__(self):
        self._set_from_env()
        self.layer_manager_obj = _get_django_model_obj_from_component(
            LayerManager, os.environ.get(f'DEFAULT_DYNAMIC_LAYER_MANAGER_NAME', 'DDSWMSLayerManager'))
        self.info_manager_obj = _get_django_model_obj_from_component(InfoManager, os.environ.get(
            f'DEFAULT_DYNAMIC_INFO_MANAGER_NAME', 'DDSWMsCustomInfoComponent'))
        self.legend_manager_obj = _get_django_model_obj_from_component(
            LegendManager, os.environ.get(f'DEFAULT_DYNAMIC_LEGEND_MANAGER_NAME', 'DDSWMSLegendComponent'))
        self.map_manager_obj = _get_django_model_obj_from_component(
            MapManager, os.environ.get(f'DEFAULT_DYNAMIC_MAP_MANAGER_NAME', 'DDSWMSMapComponent'))
        self.properties_manager_obj = _get_django_model_obj_from_component(MetadataManager, os.environ.get(
            f'DEFAULT_DYNAMIC_PROPERTIES_MANAGER_NAME', 'DDSLayerPropertiesComponent'))
        self.metadata_manager_obj = _get_django_model_obj_from_component(
            MetadataManager, os.environ.get(f'DEFAULT_DYNAMIC_METADATA_MANAGER_NAME', None))
        self.chart_manager_obj = _get_django_model_obj_from_component(
            MapManager, os.environ.get(f'DEFAULT_DYNAMIC_CHART_MANAGER_NAME', None))


@dataclass
class DynamicSerieLayerData(MenuLayerData):

    def __post_init__(self):
        self._set_from_env()
        self.layer_manager_obj = _get_django_model_obj_from_component(
            LayerManager, os.environ.get(f'DEFAULT_DYNAMIC_LAYER_MANAGER_NAME', 'SERIESLayerManager'))
        self.info_manager_obj = _get_django_model_obj_from_component(
            InfoManager, os.environ.get(f'DEFAULT_DYNAMIC_INFO_MANAGER_NAME', None))
        self.legend_manager_obj = _get_django_model_obj_from_component(LegendManager, os.environ.get(
            f'DEFAULT_DYNAMIC_LEGEND_MANAGER_NAME', 'FloodPROOFSLegendComponent'))
        self.map_manager_obj = _get_django_model_obj_from_component(
            MapManager, os.environ.get(f'DEFAULT_DYNAMIC_MAP_MANAGER_NAME', 'SeriesMapComponent'))
        self.properties_manager_obj = _get_django_model_obj_from_component(
            MetadataManager, os.environ.get(f'DEFAULT_DYNAMIC_PROPERTIES_MANAGER_NAME', None))
        self.chart_manager_obj = _get_django_model_obj_from_component(MapManager, os.environ.get(
            f'DEFAULT_DYNAMIC_CHART_MANAGER_NAME', 'SERIESItalyChartComponent'))
        self.metadata_manager_obj = _get_django_model_obj_from_component(
            MetadataManager, os.environ.get(f'DEFAULT_DYNAMIC_METADATA_MANAGER_NAME', None))
