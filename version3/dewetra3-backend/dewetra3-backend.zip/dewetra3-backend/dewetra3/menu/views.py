import json
import os
import tempfile
import time

from acroweb3.dds.router import DDSClientRouter
from acroweb3.sentinel.client import SentinelClient
from acroweb3_api import get_logger
from acroweb3_api.auth import AcrowebAuthData
from django.db import transaction
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import (APIException, NotFound,
                                       PermissionDenied, ValidationError)
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.routers import DefaultRouter
from rest_framework.settings import api_settings

from dewetra3.models import Layer, LayerTag, Server
from dewetra3.serializers import ServerSerializer
from dewetra3.settings import (SENTINEL_SERVICE_PASSWORD, SENTINEL_SERVICE_URL,
                               SENTINEL_SERVICE_USER)
from dewetra3.tools.layer_publish_utils import (build_workspace_name_for_user,
                                                delete_server_style,
                                                get_layers_from_capabilities,
                                                get_server_capabilities,
                                                get_server_layer,
                                                get_server_styles,
                                                publish_geotiff, publish_gpkg,
                                                upload_server_style)

from .data import MenuLayerData, StaticLayerData
from .permissions import (is_layer_manager, is_layer_manager_upload,
                          is_layer_tagger)

_logger = get_logger(__name__)


class LayerManagerViewSet(viewsets.ViewSet):

    @action(detail=False, methods=['get'])
    def user_data(self, request):
        user_data: AcrowebAuthData = request.user
        return Response({
            'is_layer_manager': is_layer_manager(user_data),
            'is_layer_manager_upload': is_layer_manager_upload(user_data),
            'is_layer_tagger': is_layer_tagger(user_data),
            'coordinated_domains': user_data.coordinated_domains
        })

    def __set_layer_base_data(self, layer: Layer, data: MenuLayerData):
        layer.name = data.name
        layer.descr = data.descr
        layer.icon = data.icon_obj
        layer.dataid = data.dataid
        layer.source = data.source_obj
        layer.lonw = data.lonw
        layer.lone = data.lone
        layer.lats = data.lats
        layer.latn = data.latn
        layer.category_id = data.category_id
        layer.geoscale_id = data.geoscale_id
        if data.server_id == 'default':
            server_obj = _getServerObjectForDjangoModel(data.server_id)
            layer.server_id = server_obj.id
        else:
            layer.server_id = data.server_id

    def __insert_menu_layer(self, data: MenuLayerData, creator: str):
        with transaction.atomic():

            layer = Layer()
            self.__set_layer_base_data(layer, data)
            layer.infomanager = data.info_manager_obj
            layer.legendmanager = data.legend_manager_obj
            layer.propertiesmanager = data.properties_manager_obj
            layer.metadatamanager = data.metadata_manager_obj
            layer.layermanager = data.layer_manager_obj
            layer.mapmanager = data.map_manager_obj
            layer.chartmanager = data.chart_manager_obj
            layer.creator = creator

            layer.save()

            layer.roles.set(data.roles_obj)

            if data.hazard_ids:
                layer.hazards.set(data.hazard_ids)
            if data.inspire_theme_ids:
                layer.inspirethemes.set(data.inspire_theme_ids)
            if data.dra_category_ids:
                layer.dracategories.set(data.dra_category_ids)
            if data.path_ids:
                layer.paths.set(data.path_ids)

            for tag_id in data.tag_ids:
                LayerTag.objects.create(layer=layer, tag_id=tag_id)

    def create(self, request):
        user_data: AcrowebAuthData = request.user
        if not is_layer_manager(user_data):
            raise PermissionDenied('Permission denied')
        try:
            data: MenuLayerData = StaticLayerData(**request.data)
        except Exception as e:
            raise ValidationError(str(e))
        # cannot set domain visibility for domains not coordinated
        for role_to_add in data.roles_obj:
            if role_to_add.name not in user_data.coordinated_domains:
                raise PermissionDenied(
                    'You cannot set a domain you are not the coordinator')
        try:
            self.__insert_menu_layer(data, user_data.user)
        except Exception as e:
            raise APIException('Error inserting layer: ' +
                               str(e), status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response({'status': 'ok'}, status=status.HTTP_201_CREATED)

    def update(self, request, pk=None):

        user_data: AcrowebAuthData = request.user
        if not is_layer_manager(user_data):
            raise PermissionDenied('Permission denied')

        with transaction.atomic():

            try:
                layer = Layer.objects.get(pk=pk)
            except Layer.DoesNotExist:
                raise NotFound('Layer not found')
            # check if layer is mine
            is_mine = layer.creator == user_data.user
            try:
                data: MenuLayerData = StaticLayerData(**request.data)
            except Exception as e:
                raise ValidationError(str(e))

            # cannot set domain visibility for domains not coordinated
            for role_to_add in data.roles_obj:
                if role_to_add.name not in user_data.coordinated_domains:
                    raise PermissionDenied(
                        'You cannot set a domain you are not the coordinator')

            if is_mine:
                self.__set_layer_base_data(layer, data)
                layer.save()

            # set the new domains
            layer.roles.set(data.roles_obj)

            if 'layer-tagger' in user_data.roles:
                layer.hazards.set(data.hazard_ids)
                layer.inspirethemes.set(data.inspire_theme_ids)
                layer.dracategories.set(data.dra_category_ids)
                layer.paths.set(data.path_ids)

                tag_user = user_data.user if not user_data.coordinated_domains else None
                if tag_user:
                    LayerTag.objects.filter(
                        layer=layer, username=tag_user).delete()
                    for tag_id in data.tag_ids:
                        LayerTag.objects.create(
                            layer=layer, tag_id=tag_id, username=tag_user)
                else:
                    for role in data.roles_obj:
                        LayerTag.objects.filter(
                            layer=layer, role=role).delete()
                        for tag_id in data.tag_ids:
                            LayerTag.objects.create(
                                layer=layer, tag_id=tag_id, role=role)

        return Response({'status': 'ok'}, status=status.HTTP_201_CREATED)

    def destroy(self, request, pk=None):
        user_data: AcrowebAuthData = request.user
        if not is_layer_manager(user_data):
            raise PermissionDenied('Permission denied')

        try:
            layer = Layer.objects.get(pk=pk)
        except Layer.DoesNotExist:
            raise NotFound('Layer not found')

        # check if layer is mine
        is_mine = layer.creator == user_data.user

        if is_mine:
            layer.delete()
        else:
            raise PermissionDenied('Permission denied')

        return Response({'status': 'ok'}, status=status.HTTP_200_OK)


def _getServerObjectForDjangoModel(server_id):
    if server_id is None or str(server_id).lower() in ('default', 'none'):
        url = os.environ.get(
            'DEFAULT_GEOSERVER_URL',
            'http://localhost:8080/geoserver'
        )
        user = os.environ.get('DEFAULT_GEOSERVER_USER', 'admin')
        password = os.environ.get('DEFAULT_GEOSERVER_PASSWORD', 'geoserver')

        # make sure we’re talking to the WMS endpoint
        if not url.endswith('/wms'):
            url = url.rstrip('/') + '/wms'

        servers = Server.objects.filter(
            url__startswith=url
        )
        if not servers.exists():
            server = Server.objects.create(
                url=url, user=user, password=password
            )
        else:
            server = servers.first()
        return server
    else:
        try:
            return Server.objects.get(pk=server_id)
        except Server.DoesNotExist:
            raise NotFound('Server not found')


def _getServerObject(server_id):
    if server_id is None or str(server_id).lower() in ('default', 'none'):
        # take the deafult geoserver, user and password from environment
        return Server(
            url=os.environ.get('DEFAULT_GEOSERVER_URL',
                               'http://localhost:8080/geoserver'),
            user=os.environ.get('DEFAULT_GEOSERVER_USER', 'admin'),
            password=os.environ.get('DEFAULT_GEOSERVER_PASSWORD', 'geoserver')
        )
    else:
        try:
            return Server.objects.get(pk=server_id)
        except Server.DoesNotExist:
            raise NotFound('Server not found')


class StyleManagerViewSet(viewsets.ViewSet):

    parser_classes = (MultiPartParser, FormParser, JSONParser)

    def _get_request_data(self, request, server_id):
        user_data: AcrowebAuthData = request.user
        if not is_layer_manager_upload(user_data):
            raise PermissionDenied('Permission denied')

        server_obj = _getServerObject(server_id)

        workspace_name = build_workspace_name_for_user(user_data)

        return server_obj, workspace_name

    @action(detail=False, methods=['get'], url_path='(?P<server_id>[^/.]+)')
    def list_styles(self, request, server_id=None):

        server_obj, workspace_name = self._get_request_data(request, server_id)

        # get the styles from the server
        styles = get_server_styles(server_obj, workspace_name)

        if 'styles' not in styles or 'style' not in styles['styles']:
            styles = []
        else:
            styles = [s['name'] for s in styles['styles']['style']]

        return Response(styles, status=status.HTTP_200_OK)

    @action(detail=False, methods=['post', 'delete'], url_path='(?P<server_id>[^/.]+)/(?P<file_name>[^/]+)')
    def create_style(self, request, server_id=None, file_name=None):
        server_obj, workspace_name = self._get_request_data(request, server_id)

        user_data: AcrowebAuthData = request.user
        file_prefix = user_data.user

        style_name = os.path.splitext(os.path.basename(file_name))[
            0][len(file_prefix):]

        if request.method == 'DELETE':
            delete_server_style(server_obj, style_name, workspace_name)
            return Response({'status': 'ok'}, status=status.HTTP_200_OK)

        file_path = os.path.join(tempfile.gettempdir(), file_name)

        upload_server_style(server_obj, style_name,
                            file_path, workspace_name)

        return Response({'status': 'ok'}, status=status.HTTP_201_CREATED)


class ServerManagerViewSet(viewsets.ViewSet):
    """
    Viewset for managing servers
    """

    @action(detail=False, methods=['post'])
    def check(self, request):
        """
        Check if the server is reachable
        """
        user_data: AcrowebAuthData = request.user
        if not is_layer_manager(user_data):
            raise PermissionDenied('Permission denied')

        if 'url' not in request.data:
            raise ValidationError('URL not found in request')

        servers = Server.objects.filter(url=request.data['url'])
        if not servers.exists():
            server_name = request.data.get('name', None)
            if not server_name:
                # the the url without protocol and path as name
                server_name = request.data['url'].split('://')[1].split('/')[0]
            server = Server.objects.create(
                name=server_name,
                descr=f'created by {user_data.user}',
                url=request.data['url']
            )
        else:
            server = servers.first()

        response_data = ServerSerializer(server).data

        return Response(response_data, status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'])
    def check_layer(self, request):
        """
        Check if the layer is reachable
        """
        user_data: AcrowebAuthData = request.user
        if not is_layer_manager(user_data):
            raise PermissionDenied('Permission denied')

        # get the server id and layer name from the request query params
        server_id = request.query_params.get('server_id', None)
        layer_name = request.query_params.get('layer_name', None)
        if not server_id or not layer_name:
            raise ValidationError(
                'server_id and layer_name are required parameters')

        try:
            server_obj = Server.objects.get(pk=server_id)
        except Server.DoesNotExist:
            raise NotFound('Server not found')

        layer = None
        if server_obj.user and server_obj.password:
            layer = get_server_layer(server_obj, layer_name)
        else:
            capabilities = get_server_capabilities(server_obj)
            if capabilities:
                layers_array = get_layers_from_capabilities(capabilities)
                layer = next((item for item in layers_array if item.get(
                    "Title") == layer_name), None)

        if not layer:
            raise NotFound('Layer not found on server')

        return Response(layer, status=status.HTTP_200_OK)

    @action(detail=False, methods=['post'])
    def publish_layer(self, request):
        """
        Publish a layer on the server
        """
        user_data: AcrowebAuthData = request.user
        if not is_layer_manager_upload(user_data):
            raise PermissionDenied('Permission denied')

        body = request.data
        server_id = body.get('server_id', None)
        layer_name = body.get('layer_name', None)
        file_name = body.get('file_name', None)
        style_name = body.get('style_name', None)

        if layer_name == file_name:
            layer_name = os.path.splitext(file_name)[0][len(user_data.user):]

        if layer_name is None or file_name is None:
            raise ValidationError(
                'layer_name and file_name are required parameters')

        file_path = os.path.join(tempfile.gettempdir(), file_name)
        if not os.path.exists(file_path):
            raise ValidationError(f'File not found: {file_name}')

        # get file_name extension
        file_extension = os.path.splitext(file_name)[1]
        if file_extension not in ['.gpkg', '.tiff', '.tif']:
            raise ValidationError(
                f'File extension not supported: {file_extension}')

        try:
            server_obj = _getServerObject(server_id)

            workspace_name = build_workspace_name_for_user(user_data)

            if file_extension == '.gpkg':
                # publish the layer on the server
                publish_gpkg(file_path, server_obj,
                             workspace_name, style_name, layer_name)
            else:
                publish_geotiff(file_path, server_obj,
                                workspace_name, style_name, layer_name)
        except Exception as e:
            raise APIException(
                f'Error publishing layer: {e}', status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response({'status': 'ok'}, status=status.HTTP_201_CREATED)
        # publish the layer on the server


class AllMyFeaturesViewSet(viewsets.ViewSet):
    """
    Viewset for managing all my features
    """

    _layer_features_cache = {}

    def list(self, request):
        """
        Retrieves all features for the authenticated user.

        Args:
            request (HttpRequest): The HTTP request object.

        Returns:
            Response: The HTTP response containing the features for the authenticated user.
        """
        manager_components = os.environ.get('LAYER_MANAGER_COMPONENTS_FOR_FEATURES',
                                            'SERIESLayerManager,SENTINELLayerManager,WARNINGSLayerManager')
        layers = Layer.objects.filter(
            layermanager__component__in=manager_components.split(','),
            enabled=True,
            roles__name=request.user.domain
        )
        total_features = {}
        station_groups_layer = {}
        for layer in layers:

            if layer.id in AllMyFeaturesViewSet._layer_features_cache:
                layer_features = AllMyFeaturesViewSet._layer_features_cache[layer.id]
            else:
                if layer.layermanager.component == 'SERIESLayerManager':
                    # read features from DDS
                    try:
                        client = DDSClientRouter().get_dds_serie_client(
                            layer.server.url, layer.server.user, layer.server.password)
                        props = client.properties(layer.dataid)
                        descr_field = props['descrField'] if 'descrField' in props else props['fidField']
                        id_field = props['fidField']
                        epoch_time = int(time.time())
                        dds_features = client.featuresDDS(
                            layer.dataid, epoch_time, epoch_time + 3600)
                        if 'features' not in dds_features:
                            continue
                        layer_features = []
                        for feature in dds_features['features']:
                            layer_features.append({
                                'name': feature['properties'][descr_field],
                                'lon': feature['geometry']['coordinates'][0],
                                'lat': feature['geometry']['coordinates'][1],
                                'fids': [feature['properties'][id_field]],
                                'layer_id': layer.id,
                                'layer_name': layer.name,
                            })
                        pass
                    except Exception as e:
                        _logger.error(
                            f'Error retrieving features from DDS: {e}')
                        continue
                else:
                    # read the features from sentinel 2;national_PLUVIOMETRO;italy.sensor.rainfall;sensors.pluvio;Dewetra%Default
                    toks = layer.dataid.split(';')
                    station_group = toks[-1]
                    if station_group not in station_groups_layer:
                        try:
                            sentinel_client = SentinelClient(
                                SENTINEL_SERVICE_URL, SENTINEL_SERVICE_USER, SENTINEL_SERVICE_PASSWORD)
                            sentinel_features = json.loads(
                                sentinel_client.stations_geojson(station_group, '_'))
                            if 'features' not in sentinel_features:
                                continue
                            layer_features = []
                            for feature in sentinel_features['features']:
                                layer_features.append({
                                    'name': feature['properties']['name'],
                                    'lon': feature['geometry']['coordinates'][0],
                                    'lat': feature['geometry']['coordinates'][1],
                                    'fids': [f"{s['id']};{feature['properties']['db']}" for s in feature['properties']['sensors']],
                                    'layer_id': layer.id,
                                    'layer_name': layer.name,
                                })
                            station_groups_layer[station_group] = layer.id
                        except Exception as e:
                            _logger.error(
                                f'Error retrieving features from SENTINEL: {e}')
                            continue
                    else:
                        # station groups already loaded for another layer... take the features from it
                        layer_features = AllMyFeaturesViewSet._layer_features_cache[
                            station_groups_layer[station_group]]

                AllMyFeaturesViewSet._layer_features_cache[layer.id] = layer_features

            # add the features to the total features
            for feature in layer_features:
                key = f"{feature['name']}_{feature['lon']}_{feature['lat']}"
                total_features[key] = feature

        return Response(total_features.values())


menu_app_router = DefaultRouter()
menu_app_router.register(
    r'layer_manager', LayerManagerViewSet, basename='layer_manager')
menu_app_router.register(
    r'style_manager', StyleManagerViewSet, basename='style_manager')
menu_app_router.register(
    r'server_manager', ServerManagerViewSet, basename='server_manager')
menu_app_router.register(
    r'all_my_features', AllMyFeaturesViewSet, basename='all_my_features')
