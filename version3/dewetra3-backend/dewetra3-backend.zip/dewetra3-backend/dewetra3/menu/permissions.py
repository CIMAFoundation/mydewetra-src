
from rest_framework import permissions


def is_layer_manager(user):
    return user and user.roles and 'layer-manager' in user.roles

def is_layer_manager_upload(user):
    return user and user.roles and 'layer-manager-upload' in user.roles

def is_layer_tagger(user):
    return user and user.roles and 'layer-tagger' in user.roles


