from acroweb3_api.auth import AcrowebAuthData
from django.urls import reverse
from rest_framework import serializers

from dewetra3.models import *


class AbstractNameIconSerializer(serializers.ModelSerializer):
    icon = serializers.SlugRelatedField(
        many=False, read_only=True, slug_field='value')

    class Meta:
        abstract = True
        fields = ['id', 'name', 'icon']


class AbstractComponentSerializer(serializers.ModelSerializer):
    class Meta:
        abstract = True
        fields = ['id', 'component', 'props']


class HazardSerializer(AbstractNameIconSerializer):
    class Meta(AbstractNameIconSerializer.Meta):
        model = Hazard


class DataTypeSerializer(AbstractNameIconSerializer):
    class Meta(AbstractNameIconSerializer.Meta):
        model = DataType


class ServerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Server
        exclude = ('user', 'password', 'use_proxy')

    url = serializers.SerializerMethodField()

    def get_url(self, obj):
        if obj.use_proxy:
            request = self.context.get("request")
            if request is None:
                return obj.url
            proxy_url = request.build_absolute_uri(
                reverse('server-detail', args=[obj.pk]))
            # proxy_url = 'http://localhost/api/dewetra3/dewapi/server/24/'
            return proxy_url + 'proxy/'
        else:
            return obj.url


class PathHierarchySerializer(serializers.ModelSerializer):
    path = serializers.StringRelatedField(many=False, read_only=True)

    class Meta:
        model = PathHierarchy
        fields = '__all__'


class SourceSerializer(AbstractNameIconSerializer):
    class Meta(AbstractNameIconSerializer.Meta):
        model = Source


class IconSerializer(serializers.ModelSerializer):
    class Meta:
        model = Icon
        fields = '__all__'


class GeoScaleSerializer(serializers.ModelSerializer):
    class Meta:
        model = GeoScale
        fields = '__all__'


class TagSerializer(AbstractNameIconSerializer):
    class Meta(AbstractNameIconSerializer.Meta):
        model = Tag


class IspireThemeSerializer(AbstractNameIconSerializer):
    class Meta(AbstractNameIconSerializer.Meta):
        model = InspireTheme


class DraCategorySerializer(AbstractNameIconSerializer):
    class Meta(AbstractNameIconSerializer.Meta):
        model = DraCategory


class InfoManagerSerializer(AbstractComponentSerializer):
    class Meta(AbstractComponentSerializer.Meta):
        model = InfoManager


class LegendManagerSerializer(AbstractComponentSerializer):
    class Meta(AbstractComponentSerializer.Meta):
        model = LegendManager


class MetadataManagerSerializer(AbstractComponentSerializer):
    class Meta(AbstractComponentSerializer.Meta):
        model = MetadataManager


class PropertiesManagerSerializer(AbstractComponentSerializer):
    class Meta(AbstractComponentSerializer.Meta):
        model = PropertiesManager


class LayerManagerSerializer(AbstractComponentSerializer):
    class Meta(AbstractComponentSerializer.Meta):
        model = LayerManager


class ChartManagerSerializer(AbstractComponentSerializer):
    class Meta(AbstractComponentSerializer.Meta):
        model = ChartManager


class MapManagerSerializer(AbstractComponentSerializer):
    class Meta(AbstractComponentSerializer.Meta):
        model = MapManager


class LayerCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = LayerCategory
        fields = ['id', 'name']


class ToolSerializer(serializers.ModelSerializer):

    icon = serializers.SlugRelatedField(
        many=False, read_only=True, slug_field='value')

    class Meta:
        model = Tool
        fields = '__all__'


class EventSerializer(AbstractNameIconSerializer):
    hazards = HazardSerializer(many=True, read_only=True)
    datatypes = DataTypeSerializer(many=True, read_only=True)

    class Meta:
        model = Event
        fields = ['id', 'name', 'enabled', 'date', 'lat', 'lon',
                  'floodcatid', 'hazards', 'datatypes', 'icon', 'layers']


class LayerSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    server = ServerSerializer(many=False, read_only=True)
    source = SourceSerializer(many=False, read_only=True)
    category = serializers.SlugRelatedField(
        many=False, read_only=True, slug_field='name')
    # event = EventSerializer(many=False, read_only=True)
    hazards = HazardSerializer(many=True, read_only=True)
    geoscale = serializers.SlugRelatedField(
        many=False, read_only=True, slug_field='name')
    # TagSerializer(many=True, read_only=True)
    tags = serializers.SerializerMethodField()
    inspirethemes = IspireThemeSerializer(many=True, read_only=True)
    dracategories = DraCategorySerializer(many=True, read_only=True)
    paths = PathHierarchySerializer(many=True, read_only=True)
    infomanager = InfoManagerSerializer(many=False, read_only=True)
    legendmanager = LegendManagerSerializer(many=False, read_only=True)
    metadatamanager = MetadataManagerSerializer(many=False, read_only=True)
    propertiesmanager = PropertiesManagerSerializer(many=False, read_only=True)
    layermanager = LayerManagerSerializer(many=False, read_only=True)
    chartmanager = ChartManagerSerializer(many=False, read_only=True)
    mapmanager = MapManagerSerializer(many=False, read_only=True)
    related = serializers.PrimaryKeyRelatedField(many=True, read_only=True)
    roles = serializers.SlugRelatedField(
        many=True, read_only=True, slug_field='name')
    icon = serializers.SlugRelatedField(
        many=False, read_only=True, slug_field='value')
    is_mine = serializers.SerializerMethodField()

    def get_is_mine(self, obj):
        request = self.context.get('request')
        return obj.creator == request.user.user

    def get_tags(self, obj):
        tags = getattr(obj, 'user_tags', None) or getattr(
            obj, 'domain_tags', None) or getattr(obj, 'default_tags', [])
        return TagSerializer([t.tag for t in tags], many=True).data

    class Meta:
        model = Layer
        fields = '__all__'


class ScenarioSerializerDetail(serializers.ModelSerializer):
    exposures = LayerSerializer(many=True, read_only=True)
    hazards = LayerSerializer(many=True, read_only=True)

    class Meta:
        model = Scenario
        fields = ['id', 'name', 'descr', 'aoisize', 'exposures', 'hazards']


class ScenarioSerializerList(serializers.ModelSerializer):

    class Meta:
        model = Scenario
        fields = ['id', 'name', 'descr', 'aoisize', 'exposures', 'hazards']
