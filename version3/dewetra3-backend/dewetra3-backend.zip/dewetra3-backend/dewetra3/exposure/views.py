import requests
from django.http import HttpResponse
from rest_framework import permissions, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.routers import DefaultRouter

from dewetra3.models import Role, Scenario
from dewetra3.serializers import (ScenarioSerializerDetail,
                                  ScenarioSerializerList)
from dewetra3.settings import EXPOSURE_ANALYSIS_URL


class ScenarioExposureViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.IsAuthenticated]

    # Serializer default per list, può variare in retrieve
    serializer_class = ScenarioSerializerList

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return ScenarioSerializerDetail
        return ScenarioSerializerList

    def get_queryset(self):
        userDomain = 'dewetra_dev'

        if hasattr(self.request.user, 'domain') and self.request.user.domain is not None:
            userDomain = self.request.user.domain

        related_roles = Role.objects.filter(name=userDomain)
        
        queryset = Scenario.objects.filter(
            roles__id__in=related_roles
        ).distinct()
        
        return queryset

    # Endpoint custom 
    @action(detail=False, methods=['post'], url_path='analysis/scenario')
    def scenario_analysis(self, request):
        request_url = EXPOSURE_ANALYSIS_URL + '/api/analysis/scenario/'
        response = requests.post(request_url, json=request.data)
        return Response(response.json())
        
    @action(detail=False, methods=['post'], url_path='utilities/shapefiletopoly')
    def shapefiletopoly(self, request):
        request_url = EXPOSURE_ANALYSIS_URL + '/api/utilities/shapefiletopoly'
        print(request_url)
        files = {'file': request.FILES['file']}
        response = requests.post(request_url, files=files)
        return Response(response.json())

    @action(detail=False, methods=['post'], url_path='utilities/polytoshapefile')
    def polytoshapefile(self, request):
        request_url = EXPOSURE_ANALYSIS_URL + '/api/utilities/polytoshapefile/'
        response = requests.post(request_url, json=request.data)
        print(request_url)
        return HttpResponse(
            response.content,
            content_type=response.headers.get('Content-Type', 'application/zip'),
            status=response.status_code
            )

    
    
# Router unificato
scenario_router = DefaultRouter()
scenario_router.register(r'scenarios', ScenarioExposureViewSet, basename='scenario-exposure')
