'''
Created on May 14, 2020

@author: doy
'''
import django
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dewetra3.settings')
django.setup()
import threading
import websocket 
import time
import traceback
from dewetra3.models import Widget
from dewetra3.widget.widget import WidgetManager
from acroweb3_api import get_logger

_logger = get_logger(__name__)


class WidgetService(threading.Thread):
    '''
    cbe monitoring class
    '''

    def __init__(self):
        '''
        constructor
        '''
        super(WidgetService, self).__init__()

    def __connect(self, ws_url):        
        _logger.info(f'WIDGET SERVICE: connecting to acquisition websocket {ws_url}')

        self.ws = websocket.WebSocketApp(ws_url,
                                         on_message=lambda ws, message: self.on_message(
                                             ws, message),
                                         on_error=lambda ws, error: self.on_error(
                                             ws, error),
                                         on_close=lambda ws: self.on_close(ws))

        self.ws.run_forever()

    def __do_polling(self):
        seconds = os.getenv('WIDGET_POLLING_SECONDS', 300)
        while True:

            time.sleep(seconds)
            
            _logger.info(f'WIDGET SERVICE: managing widget update (polling)')
            self.__update_all()
            

    def __update_all(self):
        widgets = Widget.objects.all()
        for widget in widgets:
            WidgetManager(widget).update()


    def run(self):

        # updtaing all widgets
        self.__update_all()

        ws_url = os.getenv('WIDGET_DDS_WEBSOCKET', 'wss://messages.cimafoundation.org/ddsws')

        if ws_url is not None and len(ws_url) > 0:
            # connection to websocket
            self.__connect(ws_url)
        else:
            self.__do_polling()

    def on_error(self, ws, error):
        _logger.error('WIDGET SERVICE: websocket error: %s' % error)

    def on_close(self, ws):
        _logger.info(
            'WIDGET SERVICE: websocket closed. reconnectiong in 10 seconds')
        time.sleep(10)
        self.__connect()

    def on_message(self, ws, message):
        try:

            toks = message.split(';')
            if len(toks) == 2:
                data_id = toks[1]

                _logger.debug(
                    f'WIDGET SERVICE: managing widget update for: {data_id}')

                widgets = Widget.objects.filter(layer__dataid=data_id)
                if widgets.exists():

                    for widget in widgets:
                        WidgetManager(widget).update()

            else:
                _logger.error(
                    f'WIDGET SERVICE: received invalid acquisition message: {message}')

        except Exception as e:
            _logger.error(
                f"WIDGET_SERVICE: ERROR managing message {str(message)}", exc_info=e)


if __name__ == '__main__':

    WidgetService().start()
