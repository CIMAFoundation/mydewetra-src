import time
import json
import pylibmc
import requests
from acroweb3.dds.router import DDSClientRouter
from dewetra3.settings import WIDGET_WMS_BASE_LAYER, WIDGET_WMS_REQUET_URL_PARAMS
from acroweb3.portal_tools import PortalServiceClient
from acroweb3_api import get_logger, get_portal_backend_url

_logger = get_logger(__name__)

ALL_KEYS = "SETTED_KEYS"
#DEWETRA3_BACKEND_URL = "127.0.0.1:11211"
DEWETRA3_BACKEND_URL = "dewetra3-backend"

class WidgetManager():
    def __init__(self, widget):
        self.widget = widget
        self.dds_client_router = DDSClientRouter()
        
        self.mc = pylibmc.Client([DEWETRA3_BACKEND_URL], binary=True,
                                 behaviors={"tcp_nodelay": True, "ketama": True})

    def __get_all_keys(self):
        return self.mc.get(ALL_KEYS)

    def __set_key(self, key):
        keys = self.__get_all_keys()
        if keys is None:
            keys = set()
        keys.add(key)
        self.mc.set(ALL_KEYS, keys)

    def __get_data_keys_by_widget(self):
        keys = self.__get_all_keys()
        if keys is not None:
            return [key for key in keys if (key.startswith(self.widget.name) and key.endswith('data'))]
        return None

    def __download_image(self, av, properties, t1, t2, dds_client, pos):
        cache_key = f"{self.widget.name}:{pos}:img"
        data_cache_key = f"{self.widget.name}:{pos}:data"

        current_av = self.mc.get(data_cache_key)
        if not self.widget.alwaysupdate and current_av and av['id'] == current_av['id']:
            _logger.debug(f'widget {self.widget.name} is up to date!')
            return

        _logger.debug(f'publishing {av} for widget {self.widget.name}')
        layer = dds_client.publish(properties, av, t1, t2)

        wms_params = self.widget.wmsparams if self.widget.wmsparams is not None else WIDGET_WMS_REQUET_URL_PARAMS
        wms_base_layer = self.widget.wmsbaselayer if self.widget.wmsbaselayer is not None else WIDGET_WMS_BASE_LAYER

        wms_base_layers = wms_base_layer.split(',')
        wms_background_layers = []
        wms_foregournd_layers = []
        for l in wms_base_layers:
            if l.startswith('__FORE__'):
                wms_foregournd_layers.append(l[8:])
            else:
                wms_background_layers.append(l)

        layers = f'{",".join(wms_background_layers)},{layer["layerid"]}' if len(
            wms_background_layers) > 0 else layer["layerid"]
        if len(wms_foregournd_layers) > 0:
            layers = f'{layers},{",".join(wms_foregournd_layers)}'

        url = f'{self.widget.layer.server.url}/wms/getmap?layers={layers}{wms_params}'

        _logger.debug(url)

        r = requests.get(url)

        self.mc.set(cache_key, r.content)
        self.mc.set(data_cache_key, av)

        self.__set_key(data_cache_key)
        self.__set_key(cache_key)

        try:
            PortalServiceClient(get_portal_backend_url()).send_portal_notification(
                '__ALL__', 'dewetra3', f'widget {self.widget.name} updated')
        except Exception as e:
            _logger.error(f'error sending notification', exc_info=e)

    def update(self):
        try:
            _logger.info(f'updating widget {self.widget.name}')
            dds_client = self.dds_client_router.get_dds_map_client(
                self.widget.layer.server.url, self.widget.layer.server.user, self.widget.layer.server.password)

            _logger.debug(
                f'getting properties for widget {self.widget.name}. dataId: {self.widget.layer.dataid}')
            properties = dds_client.properties(self.widget.layer.dataid)
            widget_attrs_rows = self.widget.properties
            widget_attrs = {}
            if widget_attrs_rows is not None:
                for row in widget_attrs_rows:
                    widget_attrs[row] = widget_attrs_rows[row]
            for attr in properties['layerProperties']['attributes']:
                if attr['name'] in widget_attrs:
                    if isinstance(attr['entries'], dict):
                        if attr['entries']['value'] == widget_attrs[attr['name']]:
                            attr['selectedEntry'] = attr['entries']
                    else:
                        for entry in attr['entries']:
                            if entry['value'] == widget_attrs[attr['name']]:
                                attr['selectedEntry'] = entry
                                break

            t2 = time.time()
            t1 = t2 - 86400 if not self.widget.period else t2 - self.widget.period
            _logger.debug(
                f'getting properties for widget {self.widget.name} from {t1} to {t2}')
            availability = dds_client.availability(properties, t1, t2)

            if self.widget.mode == 'all':
                pos = 0
                for av in availability:
                    self.__download_image(
                        av, properties, t1, t2, dds_client, pos)
                    pos += 1
            else:
                av = availability[0]
                self.__download_image(av, properties, t1, t2, dds_client, 0)

        except Exception as e:
            _logger.error(
                f'error updating widget {self.widget.name}', exc_info=e)

    def get_data(self):
        # START enabled only for testing in local
        # manager = WidgetManager(self.widget)
        # manager.update()
        # END enabled only for testing in local

        t = time.time()
        res = []

        keys_setted = self.__get_data_keys_by_widget()
        
        if keys_setted is None:
            _logger.debug(f"No data keys set for widget {self.widget.name}")
            return res

        for key in keys_setted:
            data = self.mc.get(key)
            if data is not None:
                res.append(data)

        res.sort(key=lambda x: x['date'], reverse=True)

        _logger.debug(f"get_data for {self.widget.name}: {time.time() - t} s")

        return res

    def get_img(self, id):

        keys_setted = self.__get_data_keys_by_widget()

        for key in keys_setted:
            entry = self.mc.get(key)
            if entry['id'] == id:
                cache_key = key.replace('data', 'img')
                return self.mc.get(cache_key)

        _logger.debug(f"img for {self.widget.name} not found")
        return None
