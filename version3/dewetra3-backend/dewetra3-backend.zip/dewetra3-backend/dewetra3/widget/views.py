from django.http.response import HttpResponse
from rest_framework import status, viewsets, permissions
from rest_framework.decorators import action
from rest_framework.routers import DefaultRouter
from rest_framework.response import Response

from dewetra3.models import Widget
from dewetra3.widget.widget import WidgetManager


class WidgetDataView(viewsets.ViewSet):
    """
    A viewset for handling widget data requests.
    """

    #permission_classes = [permissions.IsAuthenticated]
    permission_classes = [permissions.AllowAny]

    @action(detail=False, methods=['get'], url_path='data/(?P<widget_name>[^/.]+)')
    def widget_data(self, request, widget_name):
        """
        Retrieve data for a specific widget.

        Args:
            request (HttpRequest): The HTTP request object.
            widget_name (str): The name of the widget.

        Returns:
            Response: The response containing the widget data.
        """
        try:
            widget = Widget.objects.filter(name=widget_name).get()
        except Widget.DoesNotExist:
            return Response(f'widget {widget_name} not found', status=status.HTTP_404_NOT_FOUND)

        manager = WidgetManager(widget)
        widget_data = manager.get_data()

        return Response(widget_data)

    @action(detail=False, methods=['get'], url_path='img/(?P<widget_name>[^/.]+)/(?P<id>[^/.]+)')
    def widget_img(self, request, widget_name, id):
        """
        Return the image for a specific widget.

        Args:
            request (HttpRequest): The HTTP request object.
            widget_name (str): The name of the widget.
            id (str): The ID of the image.

        Returns:
            HttpResponse: The HTTP response containing the image.
        """
        try:
            widget = Widget.objects.filter(name=widget_name).get()
        except Widget.DoesNotExist:
            return Response(f'widget {widget_name} not found', status=status.HTTP_404_NOT_FOUND)

        img_data = WidgetManager(widget).get_img(id)
        if img_data is None:
            return Response(f'image {id} for widget {widget_name} not found', status=status.HTTP_404_NOT_FOUND)

        response = HttpResponse(img_data, content_type='image/png')
        response['Content-Length'] = len(img_data)
        return response


widget_app_router = DefaultRouter()
widget_app_router.register('', WidgetDataView, basename='')
