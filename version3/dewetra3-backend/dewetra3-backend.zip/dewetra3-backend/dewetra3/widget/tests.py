import pylibmc

def get_all_keys(memcached_client):
    keys = set()
    slabs = memcached_client.get_stats('items')
    
    
        

# Connect to Memcached
mc = pylibmc.Client(["127.0.0.1"], binary=True)

# Get all keys
all_keys = get_all_keys(mc)



print("All keys in Memcached:")
for key in all_keys:
    print(key)
