import logging

from acroweb3_api.tools import save_activity

logger = logging.getLogger(__name__)

def _extract_user_info(request):
    # Recupera le informazioni dell'utente e del dominio
    user_info = f" {getattr(request.user, 'user', 'Anonymous')}" if hasattr(request, 'user') else "User: Anonymous"
    domain_info = f" {getattr(request.user, 'domain', 'Unknown')}" if hasattr(request, 'user') else "Domain: Unknown"
    return user_info, domain_info

def log(request, level, message):
    try:
        # Funzione per generare un separatore
        def generate_separator(length=40):
            return '-' * length
        
        user_info, domain_info = _extract_user_info(request)

        # Recupera le informazioni della richiesta
        path = f" {getattr(request, 'path', 'Unknown')}"
        method = f" {getattr(request, 'method', 'Unknown')}"

        # Crea il separatore
        separator_end = '^'* 100

        # Prepara il messaggio formattato
        formatted_log = f"{user_info}:{domain_info}:{path}:{method} >>>> {message}\n{separator_end}"

        # Determina il livello di logging
        log_levels = {
            'info': logger.info,
            'warning': logger.warning,
            'error': logger.error,
            'debug': logger.debug,
        }
        log_function = log_levels.get(level, logger.info)

        # Emette il log
        log_function(formatted_log)

    except Exception as e:
        logger.exception(f"Logging failed: {e}")


def log_internal_activity(level, activity):
    try:
        # Crea il separatore
        separator_end = '^'* 100

        # Prepara il messaggio formattato
        formatted_log = f"{activity}\n{separator_end}"

        # Determina il livello di logging
        log_levels = {
            'info': logger.info,
            'warning': logger.warning,
            'error': logger.error,
            'debug': logger.debug,
        }
        log_function = log_levels.get(level, logger.info)

        # Emette il log
        log_function(formatted_log)

    except Exception as e:
        logger.exception(f"Logging failed: {e}")

def log_activity(request, activity):
    # Log the activity
    # activity example message =  'activity_type;additional_info_label;additional_info_value'
    # activity type = 'layer-selected', 'layer-loaded', 'layer-error'
    activity_type = activity.split(';')[0]
    if activity_type == 'app-log':
        log_to_acroweb(request, 'dewetra3', activity)
        log(request, 'info', f'{activity}')
    elif activity_type == 'layer-selected':
        log(request, 'info', f'{activity}')
    elif activity_type == 'layer-loaded':
        log_to_acroweb(request, 'dewetra3', activity)
        log(request, 'info', f'{activity}')
    elif activity_type == 'layer-error':
        log_to_acroweb(request, 'dewetra3', activity)
        log(request, 'info', f'{activity}')
    elif activity_type == 'layer-removed':
        log(request, 'info', f'{activity}')
    else:
        log(request, 'info', activity)


def log_to_acroweb(request, app, activity):
    try:
        user_info, domain_info = _extract_user_info(request)
        activity = f"{user_info}:{domain_info}:{activity}"  
        save_activity(request, app, activity)
    except Exception as e:
        logger.error(f'Activity logging failed: {e}')


