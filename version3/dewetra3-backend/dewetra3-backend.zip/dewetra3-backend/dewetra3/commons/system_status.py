# Description: Views for the tools app

import logging
import os
import json
import requests
from version import REVISION, VERSION

from acroweb3.sentinel.client import SentinelClient
from django.http import HttpResponse
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.routers import DefaultRouter
from dewetra3.settings import CURRENT_TIMESTAMP
import datetime

class SystemStatusViewSet(viewsets.ViewSet):
    permission_classes = [permissions.AllowAny]

    @action(detail=False, methods=['get'], url_path='server_info')
    def server_info(self, request):
        try:
            uptime = os.popen('uptime').read()
            service_start_time = CURRENT_TIMESTAMP
            current_datetime = datetime.datetime.now()
            elapsed_time = current_datetime - datetime.datetime.strptime(service_start_time, "%Y-%m-%dT%H:%M:%S")
            
            return Response({'uptime': uptime, 'start_timestamp': service_start_time, 'current_timestamp': current_datetime, 'elapsed_time': elapsed_time})
        except Exception as e:
            return Response({'error': e})
        
    @action(detail=False, methods=['get'], url_path='backend_version')
    def backend_version(self, request):
        try:
            version = {
                'version': VERSION,
                'revision': REVISION
            }
            return Response(version)
        except Exception as e:
            return Response({'error': e})


system_status_router = DefaultRouter()
system_status_router.register('', SystemStatusViewSet, basename='')