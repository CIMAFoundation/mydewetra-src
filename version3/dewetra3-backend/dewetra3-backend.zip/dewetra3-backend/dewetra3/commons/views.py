from rest_framework.views import APIView
from rest_framework.response import Response
from dewetra3.commons.logs import log_activity, log

class LogView(APIView):
    def post(self, request):
        try:
            log_activity(request, request.data['message'])
            return Response({'status': 'success'})
        except Exception as e:
            log(request, 'error', f"Error logging activity: {e}")
            return Response({'status': 'error'})