import logging
import requests
import re
from typing import Any, Dict, Union, List
from dewetra3.settings import PORTAL_BACKEND_URL
from dewetra3.commons.logs import log_internal_activity

# Configure logging

def get_translation_url(portal: str = 'mydewetra', app: str = 'dewetra3', lang: str = 'it') -> str:
    if 'bricks-developers-access' in PORTAL_BACKEND_URL:
        return f"{PORTAL_BACKEND_URL}/api/acroweb/translate/{portal}/{app}/{lang}/"
    else:
        return f"{PORTAL_BACKEND_URL}/public/acroweb/translate/{portal}/{app}/{lang}/"

class TranslateService:
    def __init__(self, api_url: str):
        """Initializes the translation service with lazy loading and caching."""
        self.api_url = api_url
        self.translations = None  # Lazy loading on first request

    def load_translations(self):
        """Loads translations from the API if not already loaded."""
        if self.translations is None:
            try:
                response = requests.get(self.api_url, verify=False)
                response.raise_for_status()
                self.translations = response.json()
                log_internal_activity('info',"Translations loaded successfully.")
            except requests.RequestException as error:
                log_internal_activity('info',f"Error loading translations: {error}")
                self.translations = {}

    def instant(self, key: str) -> str:
        """Retrieves translation for a key, supporting dot notation for nested values."""
        self.load_translations()
        keys = key.split(".")
        current = self.translations
        try:
            for k in keys:
                current = current[k]
            return current
        except (KeyError, TypeError):
            log_internal_activity('warning',f"Missing translation for key: {key}")
            return key  # Fallback to the key itself

def apply_translation_to_object(obj: Any, property_mappings: Dict[str, Any], translate_service: TranslateService) -> Any:
    try:
        return translate_nested_values(obj, property_mappings, translate_service)
    except Exception as error:
        log_internal_activity('error',f"Error during translation: {error}")
        raise

def translate_nested_values(value: Any, properties: Dict[str, Any], translate_service: TranslateService) -> Any:
    if isinstance(value, str):
        return replace_placeholders_with_translations(value, properties, translate_service)
    elif isinstance(value, list):
        return [translate_nested_values(item, properties, translate_service) for item in value]
    elif isinstance(value, dict):
        return {key: translate_nested_values(val, properties, translate_service) for key, val in value.items()}
    return value

def replace_placeholders_with_translations(string: str, properties: Dict[str, Any], translate_service: TranslateService) -> str:
    regex = re.compile(r"\{\{(.*?)\}\}")
    translations_cache: Dict[str, str] = {}

    def replace_match(match: re.Match) -> str:
        key = match.group(1).strip()
        if key not in translations_cache:
            try:
                translations_cache[key] = properties.get(key, translate_service.instant(key))
            except Exception as error:
                log_internal_activity('error',f"Error translating key '{key}': {error}")
                translations_cache[key] = key  # Fallback
        return translations_cache[key]

    return regex.sub(replace_match, string)

# Example Usage
if __name__ == "__main__":
    API_URL = get_translation_url()
    translate_service = TranslateService(API_URL)
    obj = {
        "greeting": "Hello, {{name}}!",
        "nested": {
            "message": "Welcome to {{place}}.",
            "info": "{{DEWETRA3APP.TAG_MODE}}"
        }
    }
    properties = {"name": "Alice", "place": "Wonderland"}
    translated_obj = apply_translation_to_object(obj, properties, translate_service)
    print(translated_obj)
