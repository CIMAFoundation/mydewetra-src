#!/bin/bash

# Start memcached server
memcached -d -m 64 -I 10485760 -l 0.0.0.0 -p 11211 &

DEBUG_OPTIONS=""

# Default settings for production
WORKERS=${NUM_WORKERS:-4}  # Use NUM_WORKERS if provided, else 4 workers
THREADS=4

# Check if interactive debug is enabled
if [ "$INTERACTIVE_DEBUG" = "True" ]; then
    echo "Interactive debug enabled. Installing debugpy..."
    pip install debugpy
    DEBUG_OPTIONS="--reload --log-level debug --config gunicorn_conf.py"
    
    # For interactive debug, use 1 worker and configurable threads.
    WORKERS=1
    THREADS=${N_THREADS:-4}  # Use N_THREADS if provided, else default to 4 threads
fi

# Apply database migrations
echo "Apply database migrations -${DJANGO_SETTINGS_MODULE}-"
python manage.py migrate

# Determine the interface to bind on
INTERFACE="0.0.0.0"
if [ $# -eq 1 ]; then
    INTERFACE=$1
fi

echo "Starting server on interface ${INTERFACE}"
export DJANGO_SETTINGS_MODULE=dewetra3.settings

# Start gunicorn server with the chosen worker and thread settings
gunicorn dewetra3.wsgi:application --workers ${WORKERS} --threads ${THREADS} --bind ${INTERFACE}:8000 $DEBUG_OPTIONS
