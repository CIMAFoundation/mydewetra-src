#!/bin/bash
set -e

echo "📦 Creating databases if they don't exist..."
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<-EOSQL
    CREATE DATABASE acroweb3;
    CREATE DATABASE dewetra3;
    CREATE DATABASE DOCKER_POSTGRES_LOCAL_DB;
EOSQL

echo "🚀 Restoring database: dewetra3"
pg_restore -v --username "$POSTGRES_USER" --dbname dewetra3 /docker-entrypoint-initdb.d-custom/dewetra3.dump || {
    echo "⚠️ Warning: pg_restore exited with an error, but continuing..."
}
