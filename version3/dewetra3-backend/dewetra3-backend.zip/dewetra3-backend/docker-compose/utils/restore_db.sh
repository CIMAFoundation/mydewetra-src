#!/bin/zsh

# === CONFIGURAZIONE ===
PG_HOST="host.docker.internal"  # Su macOS/Windows. Su Linux: es. 172.17.0.1
PG_PORT="5432"
PG_USER="postgres"
PG_PASSWORD="root"
PG_DB="mydewetra-italy-prod-dewetra3"
DUMP_FILE="../dump/dewetra3-prod.dump"
POSTGRES_VERSION="17"  # Versione di PostgreSQL da usare nel container Docker

# === VERIFICA FILE DI DUMP ===
if [[ ! -f "$DUMP_FILE" ]]; then
  echo "❌ File di dump non trovato: $DUMP_FILE"
  exit 1
fi

# === ESEGUI PG_RESTORE USANDO DOCKER ===
echo "Ripristino il database '$PG_DB' da $DUMP_FILE usando Docker (PostgreSQL $POSTGRES_VERSION)..."

docker run --rm \
  -e PGPASSWORD="$PG_PASSWORD" \
  -v "$(cd "$(dirname "$DUMP_FILE")" && pwd)":/backups \
  postgres:"$POSTGRES_VERSION" \
  pg_restore \
    -h "$PG_HOST" \
    -p "$PG_PORT" \
    -U "$PG_USER" \
    -d "$PG_DB" \
    -c \
    "/backups/$(basename "$DUMP_FILE")"

# === RISULTATO ===
if [[ $? -eq 0 ]]; then
  echo "✅ Ripristino completato con successo nel database: $PG_DB"
else
  echo "❌ Errore durante il ripristino del database."
fi
# === NOTE ===
# - Assicurati che il database di destinazione esista prima di eseguire il ripristino.
# - Il flag -c in pg_restore indica di eliminare gli oggetti esistenti prima di ripristinare.
# - Se il database non esiste, puoi crearlo prima di eseguire il ripristino:
# docker run -d \
#   --name pg17-prod-db \
#   -e POSTGRES_USER=postgres \
#   -e POSTGRES_PASSWORD=root \
#   -e POSTGRES_DB=mydewetra-italy-prod-dewetra3 \
#   -p 5432:5432 \
#   -v pg17-prod-db-data:/var/lib/postgresql/data \
#   postgis/postgis:17-3.4