#!/bin/zsh

# === CONFIGURAZIONE ===
#PG_HOST="host.docker.internal"  # Su macOS/Windows. Su Linux: es. 172.17.0.1
PG_HOST="130.251.104.23"
#PG_PORT="55432"
PG_PORT="5432"
PG_USER="postgres"

#PG_DB="mydewetra-italy-prod-dewetra3"
PG_DB="dewetra3-cimatest-bricks-staging"
OUTPUT_DIR="../dump"
OUTPUT_FILE="dewetra3_test_12_05_2025.dump"
DUMP_FORMAT="c"  # "c" = custom, "t" = tar, "p" = plain SQL
POSTGRES_VERSION="17"  # Versione di PostgreSQL da usare nel container Docker

# === CREA CARTELLA DI OUTPUT SE NON ESISTE ===
mkdir -p "$OUTPUT_DIR"

# === ESEGUI PG_DUMP USANDO DOCKER ===
echo "Eseguo il dump del database '$PG_DB' da $PG_HOST:$PG_PORT usando Docker (PostgreSQL $POSTGRES_VERSION)..."

docker run --rm \
  -e PGPASSWORD="$PG_PASSWORD" \
  -v "$(cd "$OUTPUT_DIR" && pwd)":/backups \
  postgres:"$POSTGRES_VERSION" \
  pg_dump \
    -h "$PG_HOST" \
    -p "$PG_PORT" \
    -U "$PG_USER" \
    -F "$DUMP_FORMAT" \
    -f "/backups/$OUTPUT_FILE" \
    "$PG_DB"

# === RISULTATO ===
if [[ $? -eq 0 ]]; then
  echo "✅ Dump completato con successo: $OUTPUT_DIR/$OUTPUT_FILE"
else
  echo "❌ Errore durante il dump del database."
fi
