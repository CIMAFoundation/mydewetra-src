#!/bin/bash


sphinx-apidoc -o docs/sphinx/ .
cd docs/sphinx
make clean
make html
make latexpdf