#!/bin/bash

sudo -u postgres dropdb dewetra3
sudo -u postgres createdb dewetra3
rm -rf dewetra3/migrations/
python manage.py makemigrations dewetra3
python manage.py migrate
python import_dewetra2_layers.py