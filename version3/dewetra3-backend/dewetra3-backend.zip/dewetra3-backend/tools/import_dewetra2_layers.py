
#%%
import django
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dewetra3.settings')
django.setup()

import requests
import json
from dewetra3.models import *
from django.db import transaction
import datetime

dewetra2_api_url = 'https://staging.mydewetra.world/dewetra2/dewapi/settings/layers/'
dewetra2_api_url_params = 'https://staging.mydewetra.world/dewetra2/dewapi/settings/layers/?limit=0&offset=0&token=andrea.tessore|1699281404405|70001e8e-611a-4236-bf7d-6b339e2f2913;27'
server_api_url = 'https://staging.mydewetra.world/dewetra2/dewapi/settings/servers/'
                    

request_base_params = {
    'limit': 0,
    'offset': 0,
    'acroweb_token': 'andrea.tessore|1678446585587|9fd0e3e1-b5ce-44ec-a39e-e31f4c032279;27'
}

def get_dewetra2_layers():
    request_params = {
        **request_base_params,        
    }
    response = requests.get(dewetra2_api_url, params=request_params)
    response_json = response.json()
    print(f'Found {response_json["meta"]["total_count"]} layers')
    return response_json['objects']
    

def get_dewetra2_layers_with_params() :
    response = requests.get(dewetra2_api_url_params)
    response_json = response.json()
    print(f'Found {response_json["meta"]["total_count"]} servers')
    return response_json['objects']
    

def get_dewetra2_servers() :
    request_params = {
        **request_base_params,        
    }
    response = requests.get(server_api_url, params=request_params)
    response_json = response.json()
    print(f'Found {response_json["meta"]["total_count"]} servers')
    servers = response_json['objects']
    server_passwords = {}
    for server in servers:
        server_passwords[server['name']] = server['password']
    return server_passwords 

def get_dewetra2_layers_from_json_file():
    return json.load(open('dewetra2_layers.json', 'r'))['objects']

def _snake_case_to_camel_case(snake_str):
    components = snake_str.split('_')
    return ''.join(x.title() for x in components)


def _manage_path_hierarchy(dewetra2_layer, path_name, hierarchy_name):
    path, path_hierarchy = None, None
    if hierarchy_name in dewetra2_layer and dewetra2_layer[hierarchy_name] is not None and len(dewetra2_layer[hierarchy_name]) > 0:
        path, path_created = Path.objects.get_or_create(
            name=path_name,                
        )
        if path_created:
            print(f'\tCreated path {path}')
        path_hierarchy, path_hierarchy_created = PathHierarchy.objects.get_or_create(
            path=path,
            hierarchy=dewetra2_layer[hierarchy_name]
        )
        if path_hierarchy_created:
            print(f'\tCreated path_hierarchy {path_hierarchy}')
        
    return path, path_hierarchy


def _manage_hazard(hazard_name):
    hazard, hazard_created = Hazard.objects.get_or_create(
        name=hazard_name,
        descr=_snake_case_to_camel_case(hazard_name),
        icon=_manage_icon(None, 'hazard_default')
    )
    if hazard_created:
        print(f'\tCreated hazard {hazard.name}')
    return hazard


def _manage_layer_category(dewetra2_layer):
    category, category_created = LayerCategory.objects.get_or_create(name=dewetra2_layer['category'])
    if category_created:
        print(f'\tCreated category {category.name}')
    return category



def _manage_custom_pros(dewetra2_layer):
    event_data, legend_manager = None, None
    if 'customprops' in dewetra2_layer and dewetra2_layer['customprops'] is not None and len(dewetra2_layer['customprops']) > 0:
        try:
            layer_custom_props = json.loads(dewetra2_layer['customprops'])

            # manage event data
            if 'event_properties' in layer_custom_props and 'properties' in layer_custom_props['event_properties']:
                event_props = layer_custom_props['event_properties']['properties']

                event_name = event_props['event_id']
                event, event_created = Event.objects.get_or_create(
                    name=event_name,
                    descr=_snake_case_to_camel_case(event_name)
                )
                if event_created:
                    print(f'\tCreated event {event.name}')

                [lat, lon] = event_props['point']
                event_date = datetime.datetime.strptime(event_props['date'], '%Y%m%d%H%M')
                if event_props['hazard'] is None or len(event_props['hazard']) == 0:
                    event_props['hazard']= 'hazard_default'
                hazard = _manage_hazard(event_props['hazard'])

                event_data, event_data_created = Event.objects.get_or_create(
                    event=event,
                    hazard=hazard,
                    lat=lat,
                    lon=lon,
                    date=event_date,
                    datatype=event_props['data_type']
                )
                if event_data_created:
                    print(f'\tCreated event_data {event_data.date} - {event_data.hazard.name} for event {event_data.event.name}')


            # manage legend data
            if 'customLegend' in layer_custom_props:
                legend_data = layer_custom_props['customLegend']
                legend_manager, legend_manager_created = LegendManager.objects.get_or_create(
                    name='custom_legend',
                    descr='Custom Legend',
                    component='CustomLegendComponent',
                    props=legend_data
                )
                if legend_manager_created:
                    print(f'\tCreated legend manager {legend_manager.name}')


        except Exception as e:
            print(f'\tError while parsing custom props: {e}')

    return event_data, legend_manager

def _manage_icon(icon_name, default_name=None):
    actual_icon_name = icon_name if icon_name is not None else default_name
    if actual_icon_name is None or len(actual_icon_name) == 0:
        return None
    icon, icon_created = Icon.objects.get_or_create(
        name=actual_icon_name,
        value=actual_icon_name
    )
    if icon_created:
        print(f'\tCreated icon {icon.name}')
    return icon

#%%
                
if __name__ == '__main__':
    #%%

    server_passwords = {}
    dewetra2_layers = get_dewetra2_layers_from_json_file() 
    
    #%%
    
    
    #insert all layers in database inside a transaction
    with transaction.atomic():
        #%%
        for dewetra2_layer in dewetra2_layers:

            print(f"Processing layer {dewetra2_layer['name']} - DATAID: {dewetra2_layer['dataid']}")

            #manage layer category
            category = _manage_layer_category(dewetra2_layer)

            #manage custom props
            event_data, legend_manager = _manage_custom_pros(dewetra2_layer)

            #manage geoscale
            if 'geoscale' not in dewetra2_layer or dewetra2_layer['geoscale'] is None or len(dewetra2_layer['geoscale']) == 0:
                dewetra2_layer['geoscale'] = {
                    'name': 'unknown',
                    'descr': 'Unknown geoscale'
                }
            geoscale, geoscale_created = GeoScale.objects.get_or_create(
                name=dewetra2_layer['geoscale']['name'], 
                descr=dewetra2_layer['geoscale']['descr'] if 'descr' in dewetra2_layer['geoscale'] else _snake_case_to_camel_case(dewetra2_layer['geoscale']['name']))
            if geoscale_created:
                print(f'\tCreated geoscale {geoscale.name}')
                #geoscale = geoscale_created
                

            #manage inspiretheme
            if 'inspiretheme' not in dewetra2_layer or dewetra2_layer['inspiretheme'] is None or len(dewetra2_layer['inspiretheme']) == 0:
                dewetra2_layer['inspiretheme'] = {
                    'name': 'unknown',
                    'descr': 'Unknown inspiretheme'
                }
            inspiretheme, inspiretheme_created = InspireTheme.objects.get_or_create(
                name=dewetra2_layer['inspiretheme']['name'],
                descr=dewetra2_layer['inspiretheme']['descr'] if 'descr' in dewetra2_layer['inspiretheme'] else _snake_case_to_camel_case(dewetra2_layer['inspiretheme']['name']))
            
            if inspiretheme_created:
                print(f'\tCreated inspiretheme {inspiretheme.name}')
                #inspiretheme = inspiretheme_created
                
            #manager DRA category
            if 'dracategory' not in dewetra2_layer or dewetra2_layer['dracategory'] is None or len(dewetra2_layer['dracategory']) == 0:
                dewetra2_layer['dracategory'] = {
                    'name': 'unknown',
                    'descr': 'Unknown dracategory'
                }
            dracategory, dracategory_created = DraCategory.objects.get_or_create(
                name=dewetra2_layer['dracategory']['name'],
                descr=dewetra2_layer['dracategory']['descr'] if 'descr' in dewetra2_layer['dracategory'] else _snake_case_to_camel_case(dewetra2_layer['dracategory']['name']))
            
            if dracategory_created:
                print(f'\tCreated dracategory {dracategory.name}')
                #dracategory = dracategory_created
                
            #manager hazard category
            if 'hazard' not in dewetra2_layer or dewetra2_layer['hazard'] is None or len(dewetra2_layer['hazard']) == 0:
                dewetra2_layer['hazard'] = {
                    'name': 'unknown',
                    'descr': 'Unknown hazard'
                }
            hazard, hazard_created = Hazard.objects.get_or_create(
                name=dewetra2_layer['hazard']['name'],
                descr=dewetra2_layer['hazard']['descr'] if 'descr' in dewetra2_layer['hazard'] else _snake_case_to_camel_case(dewetra2_layer['hazard']['name']))
            
            if hazard_created:
                print(f'\tCreated hazard {hazard.name}')
                #hazard = hazard_created    

            #manage server
            if 'server' in dewetra2_layer and dewetra2_layer['server'] is not None and len(dewetra2_layer['server']) > 0:
                if dewetra2_layer['server']['name'] not in server_passwords:
                    server_passwords[dewetra2_layer['server']['name']] = '.'
                server, server_created = Server.objects.get_or_create(
                    name=dewetra2_layer['server']['name'],
                    url=dewetra2_layer['server']['url'],
                    descr=dewetra2_layer['server']['descr'] if 'descr' in dewetra2_layer['server'] else _snake_case_to_camel_case(dewetra2_layer['server']['name']),
                    password=server_passwords[dewetra2_layer['server']['name']])
                if server_created:
                    print(f'\tCreated server {server.name}')


            paths = []
            #manage path
            path, path_hierarchy = _manage_path_hierarchy(dewetra2_layer, 'simple', 'hierarchy')
            if path_hierarchy is not None:
                paths.append(path_hierarchy)
            
            #manage pathdrr
            pathdrr, pathdrr_hierarchy = _manage_path_hierarchy(dewetra2_layer, 'drr', 'hierarchy_drr')
            if pathdrr_hierarchy is not None:
                paths.append(pathdrr_hierarchy)

            #manage icon
            icon = _manage_icon(dewetra2_layer['icon'], 'layer_default')


            #manage metadata
            if dewetra2_layer['metadataurl'] is not None and len(dewetra2_layer['metadataurl']) > 0:
                metadata_manager, metadata_manager_created = MetadataManager.objects.get_or_create(
                    name='url_metadata_manager',
                    descr='URL metadata manager',
                    component='MetadataManagerComponentURL',
                    props={'url': dewetra2_layer['metadataurl']}
                )
                if metadata_manager_created:
                    print(f'\tCreated metadata manager url_metadata_manager')
            else:
                metadata_manager = None

            #manage source
            if 'source' not in dewetra2_layer or dewetra2_layer['source'] is None or len(dewetra2_layer['source']) == 0:
                dewetra2_layer['source'] = 'unknown'
            source, source_created = Source.objects.get_or_create(
                name=dewetra2_layer['source'],
                descr=_snake_case_to_camel_case(dewetra2_layer['source']),
                icon=_manage_icon(None, 'source_default')
            )
            if source_created:
                print(f'\tCreated source {source.name}')

            #manage tags
            tags = []
            for tag in dewetra2_layer['tags']:

                tag_icon = _manage_icon(tag['icon'], 'tag_default')

                tag, tag_created = Tag.objects.get_or_create(
                    name=tag['name'],
                    descr=tag['descr'] if 'descr' in tag else _snake_case_to_camel_case(tag['name']),
                    icon=tag_icon
                )
                tags.append(tag)
                if tag_created:
                    print(f'\tCreated tag {tag.name}')

            #manage layermanager
            capitalized_component = _snake_case_to_camel_case(dewetra2_layer['type']['code'])
            layermanager, layermanager_created = LayerManager.objects.get_or_create(
                name=f"{dewetra2_layer['type']['name']}_layermanager",
                descr=f"{dewetra2_layer['type']['name']} layermanager",
                component=f"LayerManager{capitalized_component}"
            )
            if layermanager_created:
                print(f'\tCreated layermanager {layermanager.name}')    
            
            #manage mapmanager    
            mapmanager, mapmanager_created = MapManager.objects.get_or_create(
                name=f"{dewetra2_layer['type']['name']}_mapmanager",
                descr=f"{dewetra2_layer['type']['name']} mapmanager",
                component=f"MapManager{capitalized_component}"
            )
            
            if mapmanager_created:
                print(f'\tCreated mapmanager {mapmanager.name}')
            
            #manage chartmanager
            chartmanager, chartmanager_created = ChartManager.objects.get_or_create(
                name=f"{dewetra2_layer['type']['name']}_chartmanager",
                descr=f"{dewetra2_layer['type']['name']} chartmanager",
                component=f"ChartManager{capitalized_component}"
            )
            if chartmanager_created:
                print(f'\tCreated chartmanager {chartmanager.name}')
                
            try:
                #print create layer
                print(f'Creating layer {dewetra2_layer["name"]}')
                
                
                
                #create layer
                layer, layer_created = Layer.objects.get_or_create(
                    name=dewetra2_layer['name'],
                    descr=dewetra2_layer['descr'],
                    dataid=dewetra2_layer['dataid'],
                    category=category,
                    event=event_data,
                    enabled=False,
                    geoscale=geoscale,
                    server=server,
                    icon=icon,
                    metadatamanager=metadata_manager,
                    source=source,
                    layermanager=layermanager,
                    mapmanager=mapmanager,
                    chartmanager=chartmanager,
                    legendmanager=legend_manager,
                    lonw=dewetra2_layer['lonw'],
                    lone=dewetra2_layer['lone'],
                    lats=dewetra2_layer['lats'],
                    latn=dewetra2_layer['latn'],                
                )
                
                layer.hazards.set([hazard])
                
                layer.paths.set(paths)
                layer.tags.set(tags)
                layer.dracategories.set([dracategory])
                layer.inspirethemes.set([inspiretheme])
                
                if layer_created:
                    print(f'\tCreated layer {layer.name}')
                else:
                    print(f'\tUpdated layer {layer.name}')
                
            except Exception as e:
                print(f'Error creating layer {dewetra2_layer["name"]}: {e}')
                continue




        
# %%
