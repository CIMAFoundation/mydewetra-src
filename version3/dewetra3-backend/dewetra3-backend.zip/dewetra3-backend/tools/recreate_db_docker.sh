#!/bin/bash
#set variable database name
DBNAME='dewetra3'
container_name='postgres_container_alone'
docker exec -it $container_name psql -U postgres -d $DBNAME -c "SELECT pg_terminate_backend (pg_stat_activity.pid) FROM pg_stat_activity WHERE pg_stat_activity.datname = '$DBNAME';"
#connecting to postgres container
#docker exec -it $container_name psql -U postgres
#drop database
#docker exec -it $container_name dropdb $DBNAME
#drop database as postgres user
docker exec -it $container_name dropdb -U postgres $DBNAME
#create database
docker exec -it $container_name createdb -U postgres $DBNAME
#rm -rf dewetra3/migrations/
#python manage.py makemigrations dewetra3
cd ..
python manage.py migrate
cd tools
python import_dewetra2_layers.py

#import sql file 
#docker exec -it $container_name psql -U postgres -d $DBNAME -f /Users/dario/workspace/BRICKS/DATABASE/dewetra3_27_02_2024.sql
