#!/bin/bash

# this script tags and pushes the tag on origin
# first thing, we need to read the latest tag from the repo
# then we need to increment it

# first check that there are no uncommitted changes
if [[ $(git status --porcelain) ]]; then
    echo "There are uncommitted changes, please commit them before proceeding"
    exit 1
fi

# check that we are on master/main
current_branch=$(git branch --show-current)
if [[ $current_branch != "master" && $current_branch != "main" ]]; then
    echo "You are not on master/main, are you sure you want to proceed?"
    read -p "Do you want to proceed? [y/n]" -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]
    then
        echo "OK"
    else
        echo "Aborting..."
        exit 1
    fi
fi

# get latest tag
latest_tag=$(git describe --abbrev=0 --tags)

# split the tag into its components
IFS='.' read -r -a tag_parts <<< "$latest_tag"


# strip away the v from the first part
major_version=${tag_parts[0]:1}
minor_version=${tag_parts[1]}
# increment the patch version
patch_version=$((${tag_parts[2]}+1))

new_tag=$major_version.$minor_version.$patch_version
# ask for confirmation
read -p "The latest tag is $latest_tag, do you want to increment it to v$new_tag? [y/n]" -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]]
then
    echo "OK"
else
    # enter the new tag
    read -p "Enter the new tag in X.X.X format: " new_tag
    # check if format is valid 
    if [[ $new_tag =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]
    then
        echo "New tag will be v$new_tag"

        # proceed?
        read -p "Do you want to proceed? [y/n]" -n 1 -r
        echo

        if [[ $REPLY =~ ^[Yy]$ ]]
        then
            echo "Proceeding..."
        else
            echo "Aborting..."
            exit 1
        fi

    else
        echo "Tag format is not valid, it should be major.minor.patch, e.g. 1.0.0"
        exit 1
    fi
fi


# write file "version.py" containing two variables: VERSION = "x.x.x" and REVISION containing the git revision
echo "VERSION = \"$new_tag\"" > version.py

echo "REVISION = \"$(git rev-parse --short HEAD)\"" >> version.py

# generate changelog from latest tag and write it to CHANGELOG.md
version_header="## v$new_tag \n\n "
changelog=`git log --pretty=format:"- %s" $latest_tag..HEAD`
echo -e "$version_header\n$changelog\n$(cat changelog.md)" > changelog.md
 
# commit and push
git add version.py changelog.md
git commit -m "Bump version to v$new_tag"


git push
git tag v$new_tag
git push origin v$new_tag
