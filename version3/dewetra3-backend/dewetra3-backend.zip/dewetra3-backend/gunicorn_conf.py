# gunicorn_conf.py
def when_ready(server):
    import debugpy
    debugpy.listen(('0.0.0.0', 5678))
    server.log.info("debugpy is listening on port 5678")