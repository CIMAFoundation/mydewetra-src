-- Importa le associazioni tra zone di vigilanza meteo e regioni.
-- Associa ogni zona a tutte le regioni con cui ha una sovrapposizione spaziale.
-- Le geometrie regionali provengono da public.layer_ancillary_regions; il campo
-- nome_reg viene confrontato con public.ps_vm_core_region.name per ottenere la FK.
-- Lo script e' idempotente: puo' essere rieseguito per aggiornare i dati.
-- Tutte le tabelle coinvolte appartengono allo schema public.

BEGIN;

INSERT INTO public.ps_vm_core_zone_vigilanza_meteo_region (
    zone_id,
    region_id,
    description,
    sort_order
)
SELECT
    destination_zone.id AS zone_id,
    destination_region.id AS region_id,
    '' AS description,
    destination_region.sort_order
FROM public.ps_vm_core_zone_vigilanza_meteo AS destination_zone
JOIN public.layer_ancillary_regions AS source_region
    ON destination_zone.geometry && source_region.geom
   AND ST_Intersects(destination_zone.geometry, source_region.geom)
   AND NOT ST_Touches(destination_zone.geometry, source_region.geom)
JOIN public.ps_vm_core_region AS destination_region
    ON LOWER(TRIM(destination_region.name)) = LOWER(TRIM(source_region.nome_reg))
WHERE destination_zone.geometry IS NOT NULL
  AND source_region.geom IS NOT NULL
  AND source_region.nome_reg IS NOT NULL
  AND NULLIF(TRIM(source_region.nome_reg), '') IS NOT NULL
GROUP BY
    destination_zone.id,
    destination_region.id,
    destination_region.sort_order,
    destination_region.name
ORDER BY
    destination_zone.id,
    destination_region.sort_order,
    destination_region.name
ON CONFLICT (zone_id, region_id) DO UPDATE
SET
    description = EXCLUDED.description,
    sort_order = EXCLUDED.sort_order;

COMMIT;

-- Verifica facoltativa delle associazioni create:
-- SELECT
--     zone.code AS zone_code,
--     zone.name AS zone_name,
--     zone.type AS zone_type,
--     region.code AS region_code,
--     region.name AS region_name,
--     link.sort_order
-- FROM public.ps_vm_core_zone_vigilanza_meteo_region AS link
-- JOIN public.ps_vm_core_zone_vigilanza_meteo AS zone
--     ON zone.id = link.zone_id
-- JOIN public.ps_vm_core_region AS region
--     ON region.id = link.region_id
-- ORDER BY
--     zone.type,
--     CASE
--         WHEN zone.code ~ '^[0-9]+$' THEN zone.code::integer
--     END NULLS LAST,
--     zone.code,
--     region.sort_order,
--     region.name;
--
-- Verifica facoltativa delle regioni geometriche non agganciate all'anagrafica:
-- SELECT DISTINCT
--     source_region.nome_reg
-- FROM public.layer_ancillary_regions AS source_region
-- LEFT JOIN public.ps_vm_core_region AS destination_region
--     ON LOWER(TRIM(destination_region.name)) = LOWER(TRIM(source_region.nome_reg))
-- WHERE source_region.nome_reg IS NOT NULL
--   AND NULLIF(TRIM(source_region.nome_reg), '') IS NOT NULL
--   AND destination_region.id IS NULL
-- ORDER BY source_region.nome_reg;
