-- Importa public.layer_ancillary_regions nell'anagrafica delle regioni.
-- cod_reg viene usato sia come codice stabile sia come ordine applicativo.
-- Lo script e' idempotente: puo' essere rieseguito per aggiornare i dati.
-- Tutte le tabelle coinvolte appartengono allo schema public.

BEGIN;

INSERT INTO public.ps_vm_core_region (
    code,
    name,
    sort_order,
    is_active
)
SELECT
    source_region.cod_reg::text AS code,
    MAX(source_region.nome_reg) AS name,
    source_region.cod_reg::smallint AS sort_order,
    TRUE AS is_active
FROM public.layer_ancillary_regions AS source_region
WHERE source_region.cod_reg IS NOT NULL
GROUP BY source_region.cod_reg
ORDER BY source_region.cod_reg::smallint
ON CONFLICT (code) DO UPDATE
SET
    name = EXCLUDED.name,
    sort_order = EXCLUDED.sort_order,
    is_active = TRUE;

COMMIT;

-- Verifica facoltativa dopo l'importazione:
-- SELECT
--     id,
--     code,
--     name,
--     sort_order,
--     is_active
-- FROM public.ps_vm_core_region
-- ORDER BY sort_order, name;
