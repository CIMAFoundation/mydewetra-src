# Mappe sorgente e mappe intermedie

## Politica di promozione

Le mappe sorgente sono lo stato autorevole dei dati previsionali iniziali per
`d0`, `d1` e `d2`. Quando il client passa dalla sezione sorgente a quella
intermedia chiama:

```http
POST /api/promote_source_maps/
```

La promozione ricostruisce integralmente e atomicamente tutte le mappe
intermedie a partire dallo stato sorgente corrente. Eventuali modifiche manuali
precedentemente apportate alle mappe intermedie vengono quindi eliminate.

Dopo la promozione l'operatore può modificare liberamente lo stato intermedio,
aggiungendo, spostando o eliminando icone e cambiando campiture o descrizioni.
Queste modifiche non vengono mai riportate nelle mappe sorgente. Se l'operatore
torna alle sorgenti, le modifica e accede nuovamente alle intermedie, una nuova
promozione riparte ancora dallo stato sorgente e sostituisce quello intermedio.

## Promozione QPF

Il progetto gestisce soltanto ZVM, rappresentate dal tipo zona `zdv`; non sono
previste ZDA. Ogni ZVM deve avere una riga nell'anagrafica
`ps_vm_core_qpf_threshold_24h` con le quattro soglie sulle 24 ore:

- `weak_mm`: ingresso nel livello 1, `deboli`;
- `moderate_mm`: ingresso nel livello 2, `moderate`;
- `elevated_mm`: ingresso nel livello 3, `elevate`;
- `very_elevated_mm`: ingresso nel livello 4, `molto_elevate`.

Per tutte le ZVM i valori sono rispettivamente `5`, `20`, `60` e `100 mm`.
Le prime tre soglie di ingresso sono inclusive; per `molto_elevate` il
confronto è stretto (`>100 mm`). Deve valere
`0 < weak_mm < moderate_mm < elevated_mm < very_elevated_mm`. Il catalogo è
consultabile tramite `GET /api/qpf_thresholds/`.

Per ogni definizione QPF e intervallo giornaliero sorgente l'algoritmo usa
`max_mm` e ragguaglia
linearmente il valore alla durata di 24 ore:

```text
equivalent_24h_mm = max_mm * 24 / duration_hours
```

Per esempio, `10-20 mm / 3h` viene classificato come `160 mm / 24h`. Nel
codice il confronto viene effettuato tramite prodotti interi equivalenti, per
non introdurre arrotondamenti:

```text
max_mm * 24 >= threshold_mm * duration_hours
```

Per la sola soglia `very_elevated_mm` l'operatore è invece `>`. Ogni riga con
durata ammessa (`3`, `6`, `12`, `18` o `24` ore) viene classificata
separatamente e alla zona viene assegnata la severità massima tra tutte le
durate e tutti gli intervalli giornalieri:

| Severità | Codice QPF intermedio |
| --- | --- |
| 0 | `assenti_o_deboli_non_rilevanti` |
| 1 | `deboli` |
| 2 | `moderate` |
| 3 | `elevate` |
| 4 | `molto_elevate` |

Il livello 4, `molto_elevate`, è prodotto automaticamente quando il valore
equivalente sulle 24 ore supera `100 mm`. `min_mm` e le classificazioni
impulsiva/non impulsiva restano dati sorgente, ma non determinano la campitura
automatica.

La promozione viene rifiutata con `400 Bad Request` se anche una sola ZVM
presente nella QPF sorgente non dispone delle proprie soglie. Essendo
l'operazione atomica, in questo caso lo stato intermedio precedente rimane
invariato.

## Promozione PS

Le icone PS sorgenti contengono già zona, fenomeno, livello PS, slot e
descrizione. La promozione copia direttamente questi valori nello stato
intermedio. Le sorgenti accettano soltanto ZVM e fenomeni di tipo `piogge` o
`temporali`; una volta promosse, le mappe intermedie possono essere arricchite
con tutti gli altri fenomeni ammessi dai cataloghi intermedi.

In sintesi:

| Output sorgente | Stato intermedio |
| --- | --- |
| `maps[].map_id` | `map_id` |
| `maps[].zones[].zone_id` | `zones[].zone_id` |
| `maps[].zones[].amounts[].max_mm` + durata + soglie ZVM | `zones[].qpf_level_id` calcolato |
| `maps[].icons[].zone_id` | `icons[].zone_id` |
| `maps[].icons[].phenomenon.id` | `icons[].phenomenon_type_id` |
| `maps[].icons[].ps_level.id` | `icons[].ps_level_id` |
| `maps[].icons[].icon_slot` | `icons[].icon_slot` |
| `maps[].icons[].custom_description` | `icons[].custom_description` |

La descrizione QPF intermedia viene inizializzata vuota, perché non esiste un
campo sorgente equivalente.

## Lettura e modifica degli stati

Le due famiglie di mappe seguono la stessa struttura di lettura:

| Stato | QPF | Icone PS |
| --- | --- | --- |
| Sorgente | `GET /api/source_qpf/` | `GET /api/source_ps/` |
| Intermedio | `GET /api/current_qpf/` | `GET /api/current_ps/` |

Senza filtro vengono restituiti `d0`, `d1` e `d2`; con `?map_id=d1` viene
restituito soltanto il giorno richiesto. La risposta contiene
`operational_date` e l'array `maps`; ogni mappa espone `map_id`, `valid_date` e
rispettivamente `zones` oppure `icons`.

Il catalogo condiviso dalle tendine QPF delle tre mappe sorgente è disponibile
su `GET /api/daily_precipitation_intervals/`. Il salvataggio usa
`amounts[].daily_precipitation_interval_id`; la lettura restituisce l'oggetto
`amounts[].daily_precipitation_interval` con `id`, `giorno`, `intervallo` e
`descrizione`. La stessa durata può essere salvata più volte per una ZVM
quando gli intervalli selezionati sono diversi.

Il salvataggio completo sostituisce atomicamente lo stato del solo `map_id`
indicato:

| Stato | QPF | Icone PS |
| --- | --- | --- |
| Sorgente | `POST /api/save_source_qpf/` | `POST /api/save_source_ps/` |
| Intermedio | `POST /api/save_current_qpf/` | `POST /api/save_current_ps/` |

Il payload contiene `map_id` e l'intero array `zones` o `icons` da conservare.
Gli elementi precedenti omessi vengono rimossi; un array vuoto produce quindi
uno stato vuoto. Le operazioni puntuali usano invece:

```http
PUT|DELETE /api/source_qpf/{map_id}/{zone_id}/
PUT|DELETE /api/current_qpf/{map_id}/{zone_id}/
PUT|DELETE /api/source_ps/{map_id}/{zone_id}/{icon_slot}/
PUT|DELETE /api/current_ps/{map_id}/{zone_id}/{icon_slot}/
```

## Cancellazione e reset

Per le QPF il `DELETE` è un reset idempotente:

- nella sorgente assegna le classificazioni `absent` e valori `0-0 mm` per
  tutte le durate, con intervallo giornaliero `null`;
- nell'intermedia assegna il livello
  `assenti_o_deboli_non_rilevanti` e azzera la descrizione.

Per le icone PS il `DELETE` elimina realmente la singola icona o tutte le icone
del giorno. Gli endpoint completi sono:

```http
DELETE /api/source_qpf/{map_id}/
DELETE /api/current_qpf/{map_id}/
DELETE /api/source_ps/{map_id}/
DELETE /api/current_ps/{map_id}/
```

## Atomicità e notifiche

Tutte le scritture richiedono autenticazione. Le normali operazioni di stato
sono atomiche sul singolo `map_id`; la promozione è l'eccezione intenzionale e
sostituisce in un'unica transazione QPF e PS intermedi di `d0`, `d1` e `d2`.
Un errore impedisce l'applicazione dell'intera richiesta.

Dopo il commit il backend pubblica per ogni giorno una notifica
`updateCurrentQpf` e una `updateCurrentPs`, contenenti gli snapshot risultanti.
