-- Importa le zone terrestri e marine da public."zvm_2021_01_&_zone_mare"
-- nell'anagrafica delle zone di vigilanza meteo.
-- Le righe con layer = 'sea' usano AREA_ID/AREA_NAME e ricevono type = 'sea';
-- le righe con layer = 'zvm_2021_01' usano code/name e ricevono type = 'zdv'.
-- Lo script e' idempotente: puo' essere rieseguito per aggiornare i dati.
-- Le geometrie vengono copiate dalla sorgente senza trasformazioni.
-- Tutte le tabelle coinvolte appartengono allo schema public.

BEGIN;

INSERT INTO public.ps_vm_core_zone_vigilanza_meteo (
    created_at,
    updated_at,
    code,
    name,
    type,
    description,
    keywords,
    is_active,
    geometry
)
SELECT
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    source_zone.code,
    source_zone.name,
    source_zone.type,
    source_zone.name,
    '' AS keywords,
    TRUE AS is_active,
    source_zone.geometry
FROM (
    SELECT DISTINCT ON (normalized_source.code)
        normalized_source.code,
        COALESCE(normalized_source.name, normalized_source.code) AS name,
        normalized_source.type,
        normalized_source.geometry
    FROM (
        SELECT
            CASE
                WHEN LOWER(TRIM(source_area.layer)) = 'sea'
                    THEN NULLIF(TRIM(source_area."AREA_ID"), '')
                WHEN LOWER(TRIM(source_area.layer)) = 'zvm_2021_01'
                    THEN NULLIF(TRIM(source_area.code), '')
            END AS code,
            CASE
                WHEN LOWER(TRIM(source_area.layer)) = 'sea'
                    THEN NULLIF(TRIM(source_area."AREA_NAME"), '')
                WHEN LOWER(TRIM(source_area.layer)) = 'zvm_2021_01'
                    THEN NULLIF(TRIM(source_area.name), '')
            END AS name,
            CASE
                WHEN LOWER(TRIM(source_area.layer)) = 'sea' THEN 'sea'
                WHEN LOWER(TRIM(source_area.layer)) = 'zvm_2021_01' THEN 'zdv'
            END AS type,
            source_area.geom AS geometry,
            source_area.fid
        FROM public."zvm_2021_01_&_zone_mare" AS source_area
        WHERE LOWER(TRIM(source_area.layer)) IN ('sea', 'zvm_2021_01')
          AND source_area.geom IS NOT NULL
    ) AS normalized_source
    WHERE normalized_source.code IS NOT NULL
    ORDER BY
        normalized_source.code,
        normalized_source.fid
) AS source_zone
ORDER BY
    source_zone.type,
    CASE
        WHEN source_zone.code ~ '^[0-9]+$' THEN source_zone.code::integer
    END NULLS LAST,
    source_zone.code
ON CONFLICT (code) DO UPDATE
SET
    updated_at = CURRENT_TIMESTAMP,
    name = EXCLUDED.name,
    type = EXCLUDED.type,
    description = EXCLUDED.description,
    keywords = REDACTED
    is_active = EXCLUDED.is_active,
    geometry = EXCLUDED.geometry;

COMMIT;

-- Verifica facoltativa dopo l'importazione:
-- SELECT
--     id,
--     code,
--     name,
--     type,
--     is_active,
--     ST_GeometryType(geometry) AS geometry_type
-- FROM public.ps_vm_core_zone_vigilanza_meteo
-- ORDER BY
--     type,
--     CASE
--         WHEN code ~ '^[0-9]+$' THEN code::integer
--     END NULLS LAST,
--     code;
--
-- Verifica facoltativa dei codici duplicati nella sorgente normalizzata:
-- SELECT
--     CASE
--         WHEN LOWER(TRIM(layer)) = 'sea' THEN NULLIF(TRIM("AREA_ID"), '')
--         WHEN LOWER(TRIM(layer)) = 'zvm_2021_01' THEN NULLIF(TRIM(code), '')
--     END AS normalized_code,
--     COUNT(*) AS count
-- FROM public."zvm_2021_01_&_zone_mare"
-- WHERE LOWER(TRIM(layer)) IN ('sea', 'zvm_2021_01')
-- GROUP BY normalized_code
-- HAVING COUNT(*) > 1
-- ORDER BY normalized_code;
