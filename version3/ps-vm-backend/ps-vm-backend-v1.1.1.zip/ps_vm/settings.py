"""
Django settings for ps_vm project.
"""

import os
from pathlib import Path

import environ
from corsheaders.defaults import default_headers


env = environ.Env(
    DEBUG=(bool, False)
)

environ.Env.read_env()

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = REDACTED
DEBUG = env('DEBUG')
ALLOWED_HOSTS = env('ALLOWED_HOSTS').split(',')

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'rest_framework_gis',
    'corsheaders',
    'drf_yasg',
    'django_prometheus',
    'django_extensions',

    'ps_vm',
    'ps_vm_core',
]

MIDDLEWARE = [
    'django_prometheus.middleware.PrometheusBeforeMiddleware',

    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',

    'corsheaders.middleware.CorsMiddleware',

    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',

    'django_prometheus.middleware.PrometheusAfterMiddleware',
]

CORS_ALLOW_HEADERS = list(default_headers) + [
    'acrowebrole',
    'acroweb3-domain',
]

CORS_ALLOWED_ORIGINS = env('CORS_ALLOWED_ORIGINS').split(',')

ROOT_URLCONF = 'ps_vm.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'ps_vm.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.contrib.gis.db.backends.postgis',
        'NAME': env('DB_NAME'),
        'USER': env('DB_USER'),
        'PASSWORD': env('DB_PASSWORD'),
        'HOST': env('DB_HOST'),
        'PORT': env('DB_PORT'),
    }
}

AUTH_PASSWORD_VALIDATORS = REDACTED
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Europe/Rome'
USE_I18N = True
USE_L10N = True
USE_TZ = True

STATIC_URL = '/static/'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'acroweb3_api.auth.AcrowebOAuth2Authentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.AllowAny',
    ),
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
    ),
    'DEFAULT_PARSER_CLASSES': (
        'rest_framework.parsers.JSONParser',
        'rest_framework.parsers.MultiPartParser',
    ),
    'EXCEPTION_HANDLER': 'acroweb3_api.exceptions.acroweb3_exception_handler',
}

ACROWEB3_APP_NAME = env('ACROWEB3_APP_NAME')

PORTAL_BACKEND_URL = env('PORTAL_BACKEND_URL')

RESOURCE_BASE = os.path.join(os.path.dirname(__file__), 'resources')

PRINTSERVICE_PDF_URL = env('PRINTSERVICE_PDF_URL', default='')
PRINTSERVICE_PDF_TIMEOUT = env.int('PRINTSERVICE_PDF_TIMEOUT', default=500)
PRINT_CLIENT_PDF_BASE_URL = env('PRINT_CLIENT_PDF_BASE_URL', default='').strip()

EMAIL_SMTP_HOST = env('EMAIL_SMTP_HOST')
EMAIL_SMTP_PORT = env('EMAIL_SMTP_PORT')
EMAIL_SMTP_USER = env('EMAIL_SMTP_USER')
EMAIL_SMTP_PSW = env('EMAIL_SMTP_PSW')
EMAIL_SENDER = env('EMAIL_SENDER')
EMAIL_RECEIVERS = env('EMAIL_RECEIVERS')

MYCLOUD_UPLOAD_URL = env('MYCLOUD_UPLOAD_URL')
MYCLOUD_AUTH_TOKEN = REDACTED

PS_VM_DIR = env('PS_VM_DIR')

DOMAIN_HEADERS_KEY = REDACTED
