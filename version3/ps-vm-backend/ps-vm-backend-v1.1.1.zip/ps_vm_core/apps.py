from django.apps import AppConfig


class PsVmCoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ps_vm_core'
