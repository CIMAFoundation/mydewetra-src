from django.contrib import admin

from ps_vm_core.models import (
    DailyPrecipitationInterval,
    MapLayer,
    MapLayerFeature,
    QpfThreshold24h,
)


@admin.register(DailyPrecipitationInterval)
class DailyPrecipitationIntervalAdmin(admin.ModelAdmin):
    list_display = (
        "description",
        "day",
        "time_interval",
        "sort_order",
        "is_active",
    )
    list_filter = ("day", "is_active")
    ordering = ("sort_order", "day", "time_interval")


@admin.register(MapLayer)
class MapLayerAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "layer_type", "sort_order", "is_active")
    list_filter = ("layer_type", "is_active")
    search_fields = ("code", "name", "description")
    ordering = ("layer_type", "sort_order", "name")


@admin.register(MapLayerFeature)
class MapLayerFeatureAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "layer", "sort_order", "is_active")
    list_filter = ("layer__layer_type", "is_active")
    search_fields = ("code", "name", "description", "layer__code", "layer__name")
    autocomplete_fields = ("layer",)
    ordering = ("layer__sort_order", "layer__code", "sort_order", "name", "code")


@admin.register(QpfThreshold24h)
class QpfThreshold24hAdmin(admin.ModelAdmin):
    list_display = (
        "zone",
        "weak_mm",
        "moderate_mm",
        "elevated_mm",
        "very_elevated_mm",
        "updated_at",
    )
    search_fields = ("zone__code", "zone__name")
    raw_id_fields = ("zone",)
    ordering = ("zone__code",)
