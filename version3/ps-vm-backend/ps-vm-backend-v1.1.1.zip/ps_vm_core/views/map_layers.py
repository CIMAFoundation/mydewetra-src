from rest_framework import permissions, status, viewsets
from rest_framework.response import Response

from ps_vm_core.models import AppSetting, LayerType, MapLayer, MapLayerFeature
from ps_vm_core.serializers import MapLayerFeatureSerializer, MapLayerSerializer


def _active_app_setting_queryset():
    return AppSetting.objects.filter(is_active=True)


def _feature_collection(serializer):
    return serializer.data


def _active_layer_queryset(layer_type):
    return MapLayer.objects.filter(
        layer_type=layer_type,
        is_active=True,
    ).order_by("sort_order", "name")


class BackgroundResView(viewsets.ReadOnlyModelViewSet):
    """Restituisce le feature dello sfondo configurato per l'applicazione.

    Se non esiste una configurazione attiva, include le feature appartenenti a
    tutti i layer di sfondo attivi, mantenendo l'ordinamento dei layer e delle
    relative feature.
    """

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MapLayerFeatureSerializer

    def get_queryset(self):
        return MapLayerFeature.objects.filter(
            layer__layer_type=LayerType.BACKGROUND,
            layer__is_active=True,
            is_active=True,
        ).select_related("layer").order_by("layer__sort_order", "sort_order", "name")

    def list(self, request):
        if not request.user.is_authenticated:
            return Response(
                "Error: Not Authenticated user",
                status=status.HTTP_401_UNAUTHORIZED,
            )

        app_setting = (
            AppSetting.objects.filter(
                is_active=True,
                background_layer__isnull=False,
                background_layer__is_active=True,
                background_layer__layer_type=LayerType.BACKGROUND,
            )
            .select_related("background_layer")
            .first()
        )

        if app_setting:
            background_features = self.get_queryset().filter(
                layer_id=app_setting.background_layer_id
            )
        else:
            background_features = self.get_queryset()

        if not background_features.exists():
            return Response(
                "Error: Cannot obtain Background areas",
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        serializer = self.get_serializer(background_features, many=True)
        return Response(_feature_collection(serializer), status=status.HTTP_200_OK)


class AncillaryLayerResView(viewsets.ReadOnlyModelViewSet):
    """Restituisce i layer accessori attivi con le rispettive feature GeoJSON.

    I layer indicati nella configurazione attiva hanno la precedenza; in sua
    assenza vengono utilizzati tutti i layer accessori attivi. I layer privi di
    feature attive non sono inclusi nella risposta.
    """

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MapLayerFeatureSerializer

    def get_queryset(self):
        return MapLayerFeature.objects.filter(
            layer__layer_type=LayerType.ANCILLARY,
            layer__is_active=True,
            is_active=True,
        ).select_related("layer").order_by("layer__sort_order", "sort_order", "name")

    def list(self, request):
        if not request.user.is_authenticated:
            return Response(
                "Error: Not Authenticated user",
                status=status.HTTP_401_UNAUTHORIZED,
            )

        app_setting = (
            _active_app_setting_queryset()
            .filter(
                ancillary_layers__isnull=False,
                ancillary_layers__is_active=True,
                ancillary_layers__layer_type=LayerType.ANCILLARY,
            )
            .prefetch_related("ancillary_layers")
            .distinct()
            .first()
        )

        if app_setting:
            ancillary_layers = app_setting.ancillary_layers.filter(
                layer_type=LayerType.ANCILLARY,
                is_active=True,
            ).order_by("sort_order", "name")
        else:
            ancillary_layers = _active_layer_queryset(LayerType.ANCILLARY)

        response_data = []
        for layer in ancillary_layers:
            features = self.get_queryset().filter(layer=layer)
            if not features.exists():
                continue
            feature_serializer = self.get_serializer(features, many=True)
            response_data.append(
                {
                    "layer": MapLayerSerializer(layer).data,
                    "geojson": _feature_collection(feature_serializer),
                }
            )

        if not response_data:
            return Response(
                "Error: Cannot obtain Ancillary layers",
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        return Response(response_data, status=status.HTTP_200_OK)


class BaseMapResView(viewsets.ReadOnlyModelViewSet):
    """Restituisce la mappa di base attiva selezionata per l'applicazione.

    Se la configurazione attiva non indica una mappa di base valida, viene
    restituito il primo layer base attivo secondo l'ordinamento predefinito.
    """

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MapLayerSerializer

    def get_queryset(self):
        return _active_layer_queryset(LayerType.BASE)

    def list(self, request):
        if not request.user.is_authenticated:
            return Response(
                "Error: Not Authenticated user",
                status=status.HTTP_401_UNAUTHORIZED,
            )

        app_setting = (
            _active_app_setting_queryset()
            .filter(
                base_map__isnull=False,
                base_map__is_active=True,
                base_map__layer_type=LayerType.BASE,
            )
            .select_related("base_map")
            .first()
        )

        base_map = app_setting.base_map if app_setting else self.get_queryset().first()
        if not base_map:
            return Response(
                "Error: Cannot obtain Base map",
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        serializer = self.get_serializer(base_map)
        return Response(serializer.data, status=status.HTTP_200_OK)
