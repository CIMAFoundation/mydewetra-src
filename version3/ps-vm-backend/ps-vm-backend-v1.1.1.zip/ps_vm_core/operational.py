from ps_vm_core.models import MapOperationalState


MAP_OPERATIONAL_STATE_KEY = REDACTED


def lock_map_operational_state():
    """Serializza salvataggi e rollover delle lavagne operative correnti."""
    state, _ = MapOperationalState.objects.select_for_update().get_or_create(
        key=REDACTED
    )
    return state
