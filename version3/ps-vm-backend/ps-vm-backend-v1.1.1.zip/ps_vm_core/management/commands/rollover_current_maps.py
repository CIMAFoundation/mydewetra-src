from datetime import date

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone

from ps_vm_core.models import (
    CurPs,
    CurQpf,
    MapId,
    QpfLevel,
    SourcePs,
    SourceQpf,
    ZoneVigilanzaMeteo,
)
from ps_vm_core.operational import lock_map_operational_state


DEFAULT_QPF_LEVEL_CODE = "assenti_o_deboli_non_rilevanti"
ROLLOVER_MODELS = (SourceQpf, SourcePs, CurQpf, CurPs)


class Command(BaseCommand):
    help = (
        "Esegue il rollover atomico delle mappe sorgente e intermedie: "
        "D1 diventa D0, D2 diventa D1 e D2 viene inizializzato."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--date",
            dest="target_date",
            help="Data operativa di destinazione in formato YYYY-MM-DD.",
        )

    def handle(self, *args, **options):
        target_date = self._target_date(options.get("target_date"))

        with transaction.atomic():
            state = lock_map_operational_state()
            last_date = state.last_rollover_date
            if last_date and target_date < last_date:
                raise CommandError(
                    f"La data {target_date} precede l'ultimo rollover {last_date}."
                )

            elapsed_days = (target_date - last_date).days if last_date else 1
            if elapsed_days == 0:
                self.stdout.write(
                    self.style.WARNING(
                        f"Rollover gia' eseguito per la data {target_date}."
                    )
                )
                return

            if elapsed_days >= 3:
                self._clear_all_maps()
            else:
                for _ in range(elapsed_days):
                    self._roll_one_day()

            self._initialize_intermediate_d2()
            state.last_rollover_date = target_date
            state.save(update_fields=["last_rollover_date", "updated_at"])

        self.stdout.write(
            self.style.SUCCESS(
                f"Rollover completato per {target_date} ({elapsed_days} giorno/i)."
            )
        )

    def _target_date(self, raw_date):
        if not raw_date:
            return timezone.localdate()
        try:
            return date.fromisoformat(raw_date)
        except ValueError as exc:
            raise CommandError("Formato --date non valido: usare YYYY-MM-DD.") from exc

    def _roll_one_day(self):
        now = timezone.now()
        for model in ROLLOVER_MODELS:
            model.objects.filter(map_id=MapId.TODAY).delete()
            model.objects.filter(map_id=MapId.TOMORROW).update(
                map_id=MapId.TODAY,
                updated_at=now,
            )
            model.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).update(
                map_id=MapId.TOMORROW,
                updated_at=now,
            )

    def _clear_all_maps(self):
        for model in ROLLOVER_MODELS:
            model.objects.all().delete()

    def _initialize_intermediate_d2(self):
        CurQpf.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).delete()
        CurPs.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).delete()
        SourceQpf.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).delete()
        SourcePs.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).delete()

        try:
            default_level = QpfLevel.objects.get(
                code=DEFAULT_QPF_LEVEL_CODE,
                level=0,
                is_active=True,
            )
        except QpfLevel.DoesNotExist as exc:
            raise CommandError(
                "Livello QPF di default attivo non configurato: "
                f"{DEFAULT_QPF_LEVEL_CODE} (level=0)."
            ) from exc

        CurQpf.objects.bulk_create(
            [
                CurQpf(
                    map_id=MapId.DAY_AFTER_TOMORROW,
                    zone=zone,
                    qpf_level=default_level,
                )
                for zone in ZoneVigilanzaMeteo.objects.filter(is_active=True)
            ]
        )
