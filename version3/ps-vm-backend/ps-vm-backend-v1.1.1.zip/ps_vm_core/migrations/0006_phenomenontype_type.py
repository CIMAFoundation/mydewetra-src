from django.db import migrations, models


SEA_PHENOMENON_CODES = ("mari", "moto_ondoso")


def set_sea_phenomena(apps, schema_editor):
    PhenomenonType = apps.get_model("ps_vm_core", "PhenomenonType")
    PhenomenonType.objects.filter(code__in=SEA_PHENOMENON_CODES).update(type="sea")


class Migration(migrations.Migration):

    dependencies = [
        ("ps_vm_core", "0005_zonevigilanzameteo_type"),
    ]

    operations = [
        migrations.AddField(
            model_name="phenomenontype",
            name="type",
            field=models.CharField(
                choices=[
                    ("zdv", "Zona di vigilanza"),
                    ("sea", "Mare"),
                    ("all", "Zona di vigilanza e mare"),
                ],
                default="zdv",
                max_length=3,
            ),
        ),
        migrations.RunPython(set_sea_phenomena, migrations.RunPython.noop),
    ]
