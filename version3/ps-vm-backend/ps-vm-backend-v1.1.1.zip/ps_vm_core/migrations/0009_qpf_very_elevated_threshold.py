import django.core.validators
from django.db import migrations, models
from django.db.models import F, Q


UNIFORM_THRESHOLDS_24H = {
    "weak_mm": 5,
    "moderate_mm": 20,
    "elevated_mm": 60,
    "very_elevated_mm": 100,
}


def populate_uniform_thresholds(apps, schema_editor):
    ZoneVigilanzaMeteo = apps.get_model(
        "ps_vm_core", "ZoneVigilanzaMeteo"
    )
    QpfThreshold24h = apps.get_model("ps_vm_core", "QpfThreshold24h")
    QpfThreshold24h.objects.all().update(**UNIFORM_THRESHOLDS_24H)

    for zone_id in ZoneVigilanzaMeteo.objects.filter(type="zdv").values_list(
        "id", flat=True
    ):
        QpfThreshold24h.objects.update_or_create(
            zone_id=zone_id,
            defaults=UNIFORM_THRESHOLDS_24H,
        )


class Migration(migrations.Migration):
    # PostgreSQL cannot add the check constraint in the same transaction that
    # has just populated the table because foreign-key triggers are pending.
    atomic = False

    dependencies = [
        ("ps_vm_core", "0008_qpf_threshold_24h"),
    ]

    operations = [
        migrations.AddField(
            model_name="qpfthreshold24h",
            name="very_elevated_mm",
            field=models.PositiveIntegerField(
                default=100,
                validators=[django.core.validators.MinValueValidator(1)],
            ),
            preserve_default=False,
        ),
        migrations.RunPython(
            populate_uniform_thresholds,
            migrations.RunPython.noop,
        ),
        migrations.AddConstraint(
            model_name="qpfthreshold24h",
            constraint=models.CheckConstraint(
                condition=Q(elevated_mm__lt=F("very_elevated_mm")),
                name="chk_ps_vm_core_qpf_thr_24h_elev_lt_very",
            ),
        ),
    ]
