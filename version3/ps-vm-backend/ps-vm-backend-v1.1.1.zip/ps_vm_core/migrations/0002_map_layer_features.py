# Generated manually for the logical layer/feature split.

import django.contrib.gis.db.models.fields
import django.db.models.deletion
from django.db import migrations, models


def copy_layer_geometries_to_features(apps, schema_editor):
    MapLayer = apps.get_model("ps_vm_core", "MapLayer")
    MapLayerFeature = apps.get_model("ps_vm_core", "MapLayerFeature")

    features = []
    for layer in MapLayer.objects.exclude(layer_type="base").iterator():
        features.append(
            MapLayerFeature(
                layer_id=layer.id,
                code=layer.code,
                name=layer.name,
                description=layer.description,
                properties={},
                sort_order=layer.sort_order,
                is_active=layer.is_active,
                geometry=layer.geometry,
            )
        )

    MapLayerFeature.objects.bulk_create(features)


def copy_features_to_layer_geometries(apps, schema_editor):
    MapLayer = apps.get_model("ps_vm_core", "MapLayer")
    MapLayerFeature = apps.get_model("ps_vm_core", "MapLayerFeature")

    for layer in MapLayer.objects.all().iterator():
        feature = (
            MapLayerFeature.objects.filter(layer_id=layer.id)
            .order_by("sort_order", "name", "code")
            .first()
        )
        if feature:
            layer.geometry = feature.geometry
            layer.save(update_fields=["geometry"])


class Migration(migrations.Migration):

    dependencies = [
        ("ps_vm_core", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="MapLayerFeature",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=REDACTED
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("code", models.CharField(max_length=64)),
                ("name", models.CharField(blank=True, max_length=255)),
                ("description", models.TextField(blank=True)),
                ("properties", models.JSONField(blank=True, default=dict)),
                ("sort_order", models.PositiveSmallIntegerField(default=0)),
                ("is_active", models.BooleanField(default=True)),
                (
                    "geometry",
                    django.contrib.gis.db.models.fields.GeometryField(srid=4326),
                ),
                (
                    "layer",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="features",
                        to="ps_vm_core.maplayer",
                    ),
                ),
            ],
            options={
                "db_table": "ps_vm_core_map_layer_feature",
                "ordering": [
                    "layer__sort_order",
                    "layer__code",
                    "sort_order",
                    "name",
                    "code",
                ],
            },
        ),
        migrations.AddConstraint(
            model_name="maplayerfeature",
            constraint=models.UniqueConstraint(
                fields=("layer", "code"),
                name="uniq_ps_vm_core_map_layer_feature_layer_code",
            ),
        ),
        migrations.RunPython(
            copy_layer_geometries_to_features,
            reverse_code=copy_features_to_layer_geometries,
        ),
        migrations.RemoveField(
            model_name="maplayer",
            name="geometry",
        ),
    ]
