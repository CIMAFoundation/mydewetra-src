import django.core.validators
import django.db.models.deletion
from django.db import migrations, models
from django.db.models import F, Q


class Migration(migrations.Migration):
    dependencies = [
        ("ps_vm_core", "0007_source_maps"),
    ]

    operations = [
        migrations.CreateModel(
            name="QpfThreshold24h",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=REDACTED
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "weak_mm",
                    models.PositiveIntegerField(
                        validators=[django.core.validators.MinValueValidator(1)]
                    ),
                ),
                (
                    "moderate_mm",
                    models.PositiveIntegerField(
                        validators=[django.core.validators.MinValueValidator(1)]
                    ),
                ),
                (
                    "elevated_mm",
                    models.PositiveIntegerField(
                        validators=[django.core.validators.MinValueValidator(1)]
                    ),
                ),
                (
                    "zone",
                    models.OneToOneField(
                        limit_choices_to={"type": "zdv"},
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="qpf_threshold_24h",
                        to="ps_vm_core.zonevigilanzameteo",
                    ),
                ),
            ],
            options={
                "db_table": "ps_vm_core_qpf_threshold_24h",
                "ordering": ["zone__code"],
            },
        ),
        migrations.AddConstraint(
            model_name="qpfthreshold24h",
            constraint=models.CheckConstraint(
                condition=Q(weak_mm__gt=0),
                name="chk_ps_vm_core_qpf_thr_24h_weak_gt_zero",
            ),
        ),
        migrations.AddConstraint(
            model_name="qpfthreshold24h",
            constraint=models.CheckConstraint(
                condition=Q(weak_mm__lt=F("moderate_mm")),
                name="chk_ps_vm_core_qpf_thr_24h_weak_lt_mod",
            ),
        ),
        migrations.AddConstraint(
            model_name="qpfthreshold24h",
            constraint=models.CheckConstraint(
                condition=Q(moderate_mm__lt=F("elevated_mm")),
                name="chk_ps_vm_core_qpf_thr_24h_mod_lt_elev",
            ),
        ),
    ]
