from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("ps_vm_core", "0004_seed_forecast_catalogs"),
    ]

    operations = [
        migrations.AddField(
            model_name="zonevigilanzameteo",
            name="type",
            field=models.CharField(default="zdv", max_length=32),
        ),
    ]
