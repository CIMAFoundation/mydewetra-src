from django.db import migrations, models


class Migration(migrations.Migration):
    """Rende uno slot PS univoco per mappa e zona, indipendentemente dal fenomeno."""

    dependencies = [
        ("ps_vm_core", "0002_map_layer_features"),
    ]

    operations = [
        migrations.RemoveConstraint(
            model_name="curps",
            name="uniq_ps_vm_core_cur_ps_map_zone_phenomenon_slot",
        ),
        migrations.AddConstraint(
            model_name="curps",
            constraint=models.UniqueConstraint(
                fields=("map_id", "zone", "icon_slot"),
                name="uniq_ps_vm_core_cur_ps_map_zone_slot",
            ),
        ),
    ]
