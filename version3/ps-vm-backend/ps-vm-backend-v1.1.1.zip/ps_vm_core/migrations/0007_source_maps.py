import django.core.validators
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models
from django.db.models import F, Q
from django.utils import timezone


NON_IMPULSIVE_TYPES = (
    ("isolated", "Isolate", 1, 10),
    ("scattered", "Sparse", 2, 20),
    ("widespread", "Diffuse", 3, 30),
    ("absent", "Assenti", 0, 40),
)

IMPULSIVE_TYPES = (
    ("absent", "Assenti", 0, 10),
    ("isolated10", "Isolati (prob. 10-30%)", 1, 20),
    ("isolated30", "Isolati (prob. >30%)", 2, 30),
    ("scattered", "Sparsi (prob. >10%)", 3, 40),
    ("widespread", "Diffusi (prob. >10%)", 4, 50),
)


def seed_source_catalogs(apps, schema_editor):
    NonImpulsiveType = apps.get_model(
        "ps_vm_core", "NonImpulsivePrecipitationType"
    )
    ImpulsiveType = apps.get_model("ps_vm_core", "ImpulsivePrecipitationType")
    MapOperationalState = apps.get_model("ps_vm_core", "MapOperationalState")

    for code, name, severity, sort_order in NON_IMPULSIVE_TYPES:
        NonImpulsiveType.objects.update_or_create(
            code=code,
            defaults={
                "name": name,
                "severity": severity,
                "sort_order": sort_order,
                "is_active": True,
            },
        )
    for code, name, severity, sort_order in IMPULSIVE_TYPES:
        ImpulsiveType.objects.update_or_create(
            code=code,
            defaults={
                "name": name,
                "severity": severity,
                "sort_order": sort_order,
                "is_active": True,
            },
        )

    MapOperationalState.objects.update_or_create(
        key=REDACTED
        defaults={"last_rollover_date": timezone.localdate()},
    )


class Migration(migrations.Migration):
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("ps_vm_core", "0006_phenomenontype_type"),
    ]

    operations = [
        migrations.CreateModel(
            name="ImpulsivePrecipitationType",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=REDACTED
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("code", models.CharField(max_length=32, unique=True)),
                ("name", models.CharField(max_length=255)),
                ("severity", models.PositiveSmallIntegerField(default=0)),
                ("sort_order", models.PositiveSmallIntegerField(default=0)),
                ("is_active", models.BooleanField(default=True)),
            ],
            options={
                "db_table": "ps_vm_core_impulsive_precipitation_type",
                "ordering": ["sort_order", "severity", "code"],
            },
        ),
        migrations.CreateModel(
            name="MapOperationalState",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=REDACTED
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "key",
                    models.CharField(
                        default="current_maps", max_length=32, unique=True
                    ),
                ),
                ("last_rollover_date", models.DateField(blank=True, null=True)),
            ],
            options={"db_table": "ps_vm_core_map_operational_state"},
        ),
        migrations.CreateModel(
            name="NonImpulsivePrecipitationType",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=REDACTED
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("code", models.CharField(max_length=32, unique=True)),
                ("name", models.CharField(max_length=255)),
                ("severity", models.PositiveSmallIntegerField(default=0)),
                ("sort_order", models.PositiveSmallIntegerField(default=0)),
                ("is_active", models.BooleanField(default=True)),
            ],
            options={
                "db_table": "ps_vm_core_non_impulsive_precipitation_type",
                "ordering": ["sort_order", "severity", "code"],
            },
        ),
        migrations.CreateModel(
            name="SourceQpf",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=REDACTED
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "map_id",
                    models.CharField(
                        choices=[
                            ("d0", "Oggi"),
                            ("d1", "Domani"),
                            ("d2", "Dopodomani"),
                        ],
                        max_length=2,
                    ),
                ),
                (
                    "impulsive_type",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="source_assignments",
                        to="ps_vm_core.impulsiveprecipitationtype",
                    ),
                ),
                (
                    "non_impulsive_type",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="source_assignments",
                        to="ps_vm_core.nonimpulsiveprecipitationtype",
                    ),
                ),
                (
                    "updated_by",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="updated_source_qpf",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "zone",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="source_qpf",
                        to="ps_vm_core.zonevigilanzameteo",
                    ),
                ),
            ],
            options={
                "db_table": "ps_vm_core_source_qpf",
                "ordering": ["map_id", "zone__code"],
            },
        ),
        migrations.CreateModel(
            name="SourcePs",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=REDACTED
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "map_id",
                    models.CharField(
                        choices=[
                            ("d0", "Oggi"),
                            ("d1", "Domani"),
                            ("d2", "Dopodomani"),
                        ],
                        max_length=2,
                    ),
                ),
                (
                    "icon_slot",
                    models.PositiveSmallIntegerField(
                        validators=[
                            django.core.validators.MinValueValidator(1),
                            django.core.validators.MaxValueValidator(4),
                        ]
                    ),
                ),
                ("custom_description", models.TextField(blank=True)),
                (
                    "phenomenon_type",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="source_ps",
                        to="ps_vm_core.phenomenontype",
                    ),
                ),
                (
                    "ps_level",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="source_assignments",
                        to="ps_vm_core.pslevel",
                    ),
                ),
                (
                    "updated_by",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="updated_source_ps",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "zone",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="source_ps",
                        to="ps_vm_core.zonevigilanzameteo",
                    ),
                ),
            ],
            options={
                "db_table": "ps_vm_core_source_ps",
                "ordering": ["map_id", "zone__code", "icon_slot"],
            },
        ),
        migrations.CreateModel(
            name="SourceQpfAmount",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=REDACTED
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "duration_hours",
                    models.PositiveSmallIntegerField(
                        choices=[
                            (3, "3h"),
                            (6, "6h"),
                            (12, "12h"),
                            (18, "18h"),
                            (24, "24h"),
                        ]
                    ),
                ),
                ("min_mm", models.PositiveIntegerField()),
                ("max_mm", models.PositiveIntegerField()),
                (
                    "source_qpf",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="amounts",
                        to="ps_vm_core.sourceqpf",
                    ),
                ),
            ],
            options={
                "db_table": "ps_vm_core_source_qpf_amount",
                "ordering": [
                    "source_qpf__map_id",
                    "source_qpf__zone__code",
                    "duration_hours",
                ],
            },
        ),
        migrations.AddConstraint(
            model_name="sourceqpf",
            constraint=models.UniqueConstraint(
                fields=("map_id", "zone"),
                name="uniq_ps_vm_core_source_qpf_map_zone",
            ),
        ),
        migrations.AddConstraint(
            model_name="sourceps",
            constraint=models.UniqueConstraint(
                fields=("map_id", "zone", "icon_slot"),
                name="uniq_ps_vm_core_source_ps_map_zone_slot",
            ),
        ),
        migrations.AddConstraint(
            model_name="sourceqpfamount",
            constraint=models.UniqueConstraint(
                fields=("source_qpf", "duration_hours"),
                name="uniq_ps_vm_core_source_qpf_amount_duration",
            ),
        ),
        migrations.AddConstraint(
            model_name="sourceqpfamount",
            constraint=models.CheckConstraint(
                condition=Q(min_mm__lte=F("max_mm")),
                name="chk_ps_vm_core_source_qpf_amount_min_lte_max",
            ),
        ),
        migrations.RunPython(seed_source_catalogs, migrations.RunPython.noop),
    ]
