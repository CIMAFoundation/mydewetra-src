import django.db.models.deletion
from django.db import migrations, models


INTERVALS = (
    ("OGGI", "12:00 - 18:00", "OGGI dalle 12:00 alle 18:00", 1),
    ("OGGI", "18:00 - 24:00", "OGGI dalle 18:00 alle 24:00", 2),
    ("DOMANI", "00:00 - 06:00", "DOMANI dalle 00:00 alle 06:00", 3),
    ("DOMANI", "06:00 - 12:00", "DOMANI dalle 06:00 alle 12:00", 4),
    ("DOMANI", "12:00 - 18:00", "DOMANI dalle 12:00 alle 18:00", 5),
    ("DOMANI", "18:00 - 24:00", "DOMANI dalle 18:00 alle 24:00", 6),
)


def seed_daily_precipitation_intervals(apps, schema_editor):
    interval_model = apps.get_model(
        "ps_vm_core", "DailyPrecipitationInterval"
    )
    for day, time_interval, description, sort_order in INTERVALS:
        interval_model.objects.update_or_create(
            day=day,
            time_interval=time_interval,
            defaults={
                "description": description,
                "sort_order": sort_order,
                "is_active": True,
            },
        )


def unseed_daily_precipitation_intervals(apps, schema_editor):
    interval_model = apps.get_model(
        "ps_vm_core", "DailyPrecipitationInterval"
    )
    for day, time_interval, _, _ in INTERVALS:
        interval_model.objects.filter(
            day=day,
            time_interval=time_interval,
        ).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("ps_vm_core", "0010_sync_forecast_catalogs"),
    ]

    operations = [
        migrations.CreateModel(
            name="DailyPrecipitationInterval",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=REDACTED
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "day",
                    models.CharField(
                        choices=[("OGGI", "OGGI"), ("DOMANI", "DOMANI")],
                        max_length=7,
                    ),
                ),
                ("time_interval", models.CharField(max_length=13)),
                ("description", models.CharField(max_length=64)),
                ("sort_order", models.PositiveSmallIntegerField(default=0)),
                ("is_active", models.BooleanField(default=True)),
            ],
            options={
                "db_table": "ps_vm_core_daily_precipitation_interval",
                "ordering": ["sort_order", "day", "time_interval"],
            },
        ),
        migrations.AddConstraint(
            model_name="dailyprecipitationinterval",
            constraint=models.UniqueConstraint(
                fields=("day", "time_interval"),
                name="uniq_ps_vm_core_daily_precip_day_interval",
            ),
        ),
        migrations.RunPython(
            seed_daily_precipitation_intervals,
            unseed_daily_precipitation_intervals,
        ),
        migrations.AddField(
            model_name="sourceqpfamount",
            name="daily_precipitation_interval",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="source_qpf_amounts",
                to="ps_vm_core.dailyprecipitationinterval",
            ),
        ),
        migrations.RemoveConstraint(
            model_name="sourceqpfamount",
            name="uniq_ps_vm_core_source_qpf_amount_duration",
        ),
        migrations.AddConstraint(
            model_name="sourceqpfamount",
            constraint=models.UniqueConstraint(
                fields=(
                    "source_qpf",
                    "duration_hours",
                    "daily_precipitation_interval",
                ),
                name="uniq_ps_vm_core_source_qpf_amount_duration_interval",
            ),
        ),
        migrations.AddConstraint(
            model_name="sourceqpfamount",
            constraint=models.UniqueConstraint(
                condition=models.Q(daily_precipitation_interval__isnull=True),
                fields=("source_qpf", "duration_hours"),
                name="uniq_ps_vm_core_source_qpf_amount_null_interval",
            ),
        ),
        migrations.AlterModelOptions(
            name="sourceqpfamount",
            options={
                "ordering": [
                    "source_qpf__map_id",
                    "source_qpf__zone__code",
                    "duration_hours",
                    "daily_precipitation_interval__sort_order",
                ]
            },
        ),
    ]
