from django.db import migrations


PS_LEVEL_UPDATES = (
    ("rovesci_isolati", "temporali", 1, 10),
    ("temporali_isolati", "temporali", 2, 20),
    ("temporali_sparsi", "temporali", 3, 30),
    ("temporali_diffusi", "temporali", 4, 40),
)

IMPULSIVE_CODE_UPDATES = (
    ("isolated10", "rovesci_isolati"),
    ("isolated30", "temporali_isolati"),
    ("scattered", "temporali_sparsi"),
    ("widespread", "temporali_diffusi"),
)

NON_IMPULSIVE_CODE_UPDATES = (
    ("isolated", "piogge_isolate"),
    ("scattered", "piogge_sparse"),
    ("widespread", "piogge_diffuse"),
)


def _rename_catalog_codes(model, code_updates):
    for old_code, new_code in code_updates:
        items = list(model.objects.filter(code__in=(old_code, new_code)))
        if len(items) != 1:
            raise ValueError(
                f"Attesa una sola riga con codice {old_code} o {new_code}, "
                f"trovate {len(items)}."
            )
        item = items[0]
        if item.code != new_code:
            item.code = new_code
            item.save(update_fields=["code"])


def sync_forecast_catalogs(apps, schema_editor):
    PhenomenonType = apps.get_model("ps_vm_core", "PhenomenonType")
    PsLevel = apps.get_model("ps_vm_core", "PsLevel")
    ImpulsiveType = apps.get_model(
        "ps_vm_core", "ImpulsivePrecipitationType"
    )
    NonImpulsiveType = apps.get_model(
        "ps_vm_core", "NonImpulsivePrecipitationType"
    )

    temporali = PhenomenonType.objects.get(code="temporali")
    for code, phenomenon_code, level, sort_order in PS_LEVEL_UPDATES:
        if phenomenon_code != temporali.code:
            raise ValueError(
                f"Fenomeno PS non supportato nella migrazione: {phenomenon_code}"
            )
        item = PsLevel.objects.get(code=code)
        item.phenomenon_type_id = temporali.pk
        item.level = level
        item.sort_order = sort_order
        item.save(
            update_fields=["phenomenon_type", "level", "sort_order"]
        )

    _rename_catalog_codes(ImpulsiveType, IMPULSIVE_CODE_UPDATES)
    _rename_catalog_codes(NonImpulsiveType, NON_IMPULSIVE_CODE_UPDATES)


class Migration(migrations.Migration):
    dependencies = [
        ("ps_vm_core", "0009_qpf_very_elevated_threshold"),
    ]

    operations = [
        migrations.RunPython(
            sync_forecast_catalogs,
            migrations.RunPython.noop,
        ),
    ]
