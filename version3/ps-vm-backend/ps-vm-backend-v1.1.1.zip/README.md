# acroweb3-ps-vm-backend

## Documentazione

- [Modello dati](docs/data-model.md)
- [API REST](docs/api.md)
- [Mappe sorgente e intermedie](docs/source-intermediate-maps.md)

Bollettino di previsione sinottica e di vigilanza meteo nazionale
