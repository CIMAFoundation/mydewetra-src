from django.conf import settings
from django.contrib.gis.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db.models import Q
from django.utils import timezone


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class MapId(models.TextChoices):
    TODAY = "d0", "Oggi"
    TOMORROW = "d1", "Domani"
    DAY_AFTER_TOMORROW = "d2", "Dopodomani"


class QpfDuration(models.IntegerChoices):
    THREE_HOURS = 3, "3h"
    SIX_HOURS = 6, "6h"
    TWELVE_HOURS = 12, "12h"
    EIGHTEEN_HOURS = 18, "18h"
    TWENTY_FOUR_HOURS = 24, "24h"


class PrecipitationIntervalDay(models.TextChoices):
    TODAY = "d0", "Oggi"
    TOMORROW = "d1", "Domani"
    DAY_AFTER_TOMORROW = "d2", "Dopodomani"


class BulletinKind(models.TextChoices):
    FIRST = "first", "Prima emissione"
    UPDATE = "update", "Aggiornamento"


class BulletinProduct(models.TextChoices):
    PS = "ps", "Previsione sinottica"
    VMN = "vmn", "Vigilanza meteo nazionale"


class BulletinStatus(models.TextChoices):
    DRAFT = "draft", "Bozza"
    FINALIZED = "finalized", "Finalizzato"


class LayerType(models.TextChoices):
    BASE = "base", "Base map"
    BACKGROUND = "background", "Layer di sfondo"
    ANCILLARY = "ancillary", "Layer ancillare"


class PsIconType(models.TextChoices):
    ZDV = "zdv", "Zona di vigilanza"
    SEA = "sea", "Mare"
    ALL = "all", "Zona di vigilanza e mare"


class Region(models.Model):
    code = models.CharField(max_length=32, unique=True)
    name = models.CharField(max_length=255)
    sort_order = models.PositiveSmallIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ps_vm_core_region"
        ordering = ["sort_order", "name"]

    def __str__(self):
        return self.name


class ZoneVigilanzaMeteo(TimeStampedModel):
    code = models.CharField(max_length=32, unique=True)
    name = models.CharField(max_length=255)
    type = models.CharField(max_length=32, default="zdv")
    description = models.TextField(blank=True)
    keywords = REDACTED
    regions = models.ManyToManyField(
        Region,
        through="ZoneVigilanzaMeteoRegion",
        related_name="zone_vigilanza_meteo",
        blank=True,
    )
    is_active = models.BooleanField(default=True)
    geometry = models.MultiPolygonField(srid=4326)

    class Meta:
        db_table = "ps_vm_core_zone_vigilanza_meteo"
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} - {self.name}"


class ZoneVigilanzaMeteoRegion(models.Model):
    zone = models.ForeignKey(
        ZoneVigilanzaMeteo,
        on_delete=models.CASCADE,
        related_name="zone_regions",
    )
    region = models.ForeignKey(
        Region,
        on_delete=models.CASCADE,
        related_name="zone_regions",
    )
    description = models.CharField(max_length=255, blank=True)
    sort_order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        db_table = "ps_vm_core_zone_vigilanza_meteo_region"
        ordering = ["zone__code", "sort_order", "region__name"]
        constraints = [
            models.UniqueConstraint(
                fields=["zone", "region"],
                name="uniq_ps_vm_core_zone_vigilanza_meteo_region_zone_region",
            ),
        ]

    def __str__(self):
        return f"{self.zone.code} - {self.region.name}"


class ZoneIconAnchor(models.Model):
    zone = models.ForeignKey(
        ZoneVigilanzaMeteo,
        on_delete=models.CASCADE,
        related_name="icon_anchors",
    )
    slot = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4)]
    )
    label = models.CharField(max_length=64, blank=True)
    point = models.PointField(srid=4326)

    class Meta:
        db_table = "ps_vm_core_zone_icon_anchor"
        ordering = ["zone__code", "slot"]
        constraints = [
            models.UniqueConstraint(
                fields=["zone", "slot"],
                name="uniq_ps_vm_core_zone_icon_anchor_zone_slot",
            ),
        ]

    def __str__(self):
        return f"{self.zone.code} - slot {self.slot}"


class QpfLevel(TimeStampedModel):
    code = models.CharField(max_length=32, unique=True)
    description = models.CharField(max_length=255)
    level = models.PositiveSmallIntegerField()
    text = models.TextField(blank=True)
    sort_order = models.PositiveSmallIntegerField(default=0)
    image = models.FileField(upload_to="qpf_levels/images/", blank=True)
    color = models.CharField(max_length=32, blank=True)
    svg = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ps_vm_core_qpf_def"
        ordering = ["sort_order", "level", "code"]

    def __str__(self):
        return f"{self.code} - {self.description}"


class PhenomenonType(models.Model):
    code = models.CharField(max_length=32, unique=True)
    name = models.CharField(max_length=255)
    type = models.CharField(
        max_length=3,
        choices=PsIconType.choices,
        default=PsIconType.ZDV,
    )
    description = models.TextField(blank=True)
    sort_order = models.PositiveSmallIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ps_vm_core_ps_phenomenon_type"
        ordering = ["sort_order", "name"]

    def __str__(self):
        return self.name


class PsLevel(TimeStampedModel):
    phenomenon_type = models.ForeignKey(
        PhenomenonType,
        on_delete=models.PROTECT,
        related_name="levels",
    )
    code = models.CharField(max_length=32)
    description = models.CharField(max_length=255)
    level = models.PositiveSmallIntegerField()
    text = models.TextField(blank=True)
    sort_order = models.PositiveSmallIntegerField(default=0)
    icon = models.FileField(upload_to="ps_levels/icons/", blank=True)
    color = models.CharField(max_length=32, blank=True)
    svg = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ps_vm_core_ps_def"
        ordering = ["phenomenon_type__sort_order", "sort_order", "level", "code"]
        constraints = [
            models.UniqueConstraint(
                fields=["phenomenon_type", "code"],
                name="uniq_ps_vm_core_ps_def_phenomenon_code",
            ),
        ]

    def __str__(self):
        return f"{self.phenomenon_type.code} - {self.code}"


class MapLayer(TimeStampedModel):
    code = models.CharField(max_length=64, unique=True)
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    layer_type = models.CharField(max_length=32, choices=LayerType.choices)
    style = models.JSONField(default=dict, blank=True)
    sort_order = models.PositiveSmallIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ps_vm_core_map_layer"
        ordering = ["layer_type", "sort_order", "name"]

    def __str__(self):
        return f"{self.code} - {self.name}"


class MapLayerFeature(TimeStampedModel):
    layer = models.ForeignKey(
        MapLayer,
        on_delete=models.CASCADE,
        related_name="features",
    )
    code = models.CharField(max_length=64)
    name = models.CharField(max_length=255, blank=True)
    description = models.TextField(blank=True)
    properties = models.JSONField(default=dict, blank=True)
    sort_order = models.PositiveSmallIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    geometry = models.GeometryField(srid=4326)

    class Meta:
        db_table = "ps_vm_core_map_layer_feature"
        ordering = ["layer__sort_order", "layer__code", "sort_order", "name", "code"]
        constraints = [
            models.UniqueConstraint(
                fields=["layer", "code"],
                name="uniq_ps_vm_core_map_layer_feature_layer_code",
            ),
        ]

    def __str__(self):
        return f"{self.layer.code} - {self.code}"


class AppSetting(TimeStampedModel):
    title = models.CharField(max_length=255)
    map_title = models.CharField(max_length=255, blank=True)
    text_title = models.CharField(max_length=255, blank=True)
    base_map = models.ForeignKey(
        MapLayer,
        on_delete=models.SET_NULL,
        related_name="base_map_settings",
        null=True,
        blank=True,
        limit_choices_to={"layer_type": LayerType.BASE},
    )
    background_layer = models.ForeignKey(
        MapLayer,
        on_delete=models.SET_NULL,
        related_name="background_settings",
        null=True,
        blank=True,
        limit_choices_to={"layer_type": LayerType.BACKGROUND},
    )
    ancillary_layers = models.ManyToManyField(
        MapLayer,
        related_name="ancillary_settings",
        blank=True,
        limit_choices_to={"layer_type": LayerType.ANCILLARY},
    )
    config = models.JSONField(default=dict, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ps_vm_core_app_settings"
        ordering = ["-is_active", "title"]

    def __str__(self):
        return self.title


class BulletinSettings(TimeStampedModel):
    bulletin_type = models.CharField(max_length=16, choices=BulletinProduct.choices)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="ps_vm_bulletin_settings",
        null=True,
        blank=True,
    )
    title = models.CharField(max_length=255, blank=True)
    default_titles = models.JSONField(default=dict, blank=True)
    default_texts = models.JSONField(default=dict, blank=True)
    layout_config = models.JSONField(default=dict, blank=True)
    qpf_regions = models.ManyToManyField(
        Region,
        related_name="bulletin_qpf_settings",
        blank=True,
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ps_vm_core_bulletin_settings"
        ordering = ["bulletin_type", "user_id"]
        constraints = [
            models.UniqueConstraint(
                fields=["bulletin_type", "user"],
                name="uniq_ps_vm_core_bulletin_settings_type_user",
            ),
            models.UniqueConstraint(
                fields=["bulletin_type"],
                condition=Q(user__isnull=True),
                name="uniq_ps_vm_core_bulletin_settings_global_type",
            ),
        ]

    def __str__(self):
        scope = self.user_id or "global"
        return f"{self.bulletin_type} - {scope}"


class NonImpulsivePrecipitationType(TimeStampedModel):
    code = models.CharField(max_length=32, unique=True)
    name = models.CharField(max_length=255)
    severity = models.PositiveSmallIntegerField(default=0)
    sort_order = models.PositiveSmallIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ps_vm_core_non_impulsive_precipitation_type"
        ordering = ["sort_order", "severity", "code"]

    def __str__(self):
        return self.name


class ImpulsivePrecipitationType(TimeStampedModel):
    code = models.CharField(max_length=32, unique=True)
    name = models.CharField(max_length=255)
    severity = models.PositiveSmallIntegerField(default=0)
    sort_order = models.PositiveSmallIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ps_vm_core_impulsive_precipitation_type"
        ordering = ["sort_order", "severity", "code"]

    def __str__(self):
        return self.name


class DailyPrecipitationInterval(TimeStampedModel):
    """Intervallo giornaliero selezionabile per una QPF sorgente."""

    day = models.CharField(max_length=2, choices=PrecipitationIntervalDay.choices)
    time_interval = models.CharField(max_length=13)
    description = models.CharField(max_length=64)
    sort_order = models.PositiveSmallIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ps_vm_core_daily_precipitation_interval"
        ordering = ["day", "sort_order", "time_interval"]
        constraints = [
            models.UniqueConstraint(
                fields=["day", "time_interval"],
                name="uniq_ps_vm_core_daily_precip_day_interval",
            ),
        ]

    def __str__(self):
        return self.description


class SourceQpf(TimeStampedModel):
    map_id = models.CharField(max_length=2, choices=MapId.choices)
    zone = models.ForeignKey(
        ZoneVigilanzaMeteo,
        on_delete=models.CASCADE,
        related_name="source_qpf",
    )
    non_impulsive_type = models.ForeignKey(
        NonImpulsivePrecipitationType,
        on_delete=models.PROTECT,
        related_name="source_assignments",
    )
    impulsive_type = models.ForeignKey(
        ImpulsivePrecipitationType,
        on_delete=models.PROTECT,
        related_name="source_assignments",
    )
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name="updated_source_qpf",
        null=True,
        blank=True,
    )

    class Meta:
        db_table = "ps_vm_core_source_qpf"
        ordering = ["map_id", "zone__code"]
        constraints = [
            models.UniqueConstraint(
                fields=["map_id", "zone"],
                name="uniq_ps_vm_core_source_qpf_map_zone",
            ),
        ]

    def __str__(self):
        return f"{self.map_id} - {self.zone.code}"


class SourceQpfAmount(TimeStampedModel):
    source_qpf = models.ForeignKey(
        SourceQpf,
        on_delete=models.CASCADE,
        related_name="amounts",
    )
    duration_hours = models.PositiveSmallIntegerField(choices=QpfDuration.choices)
    min_mm = models.PositiveIntegerField()
    max_mm = models.PositiveIntegerField()
    daily_precipitation_interval = models.ForeignKey(
        DailyPrecipitationInterval,
        on_delete=models.PROTECT,
        related_name="source_qpf_amounts",
        null=True,
        blank=True,
    )

    class Meta:
        db_table = "ps_vm_core_source_qpf_amount"
        ordering = [
            "source_qpf__map_id",
            "source_qpf__zone__code",
            "duration_hours",
            "daily_precipitation_interval__day",
            "daily_precipitation_interval__sort_order",
        ]
        constraints = [
            models.UniqueConstraint(
                fields=[
                    "source_qpf",
                    "duration_hours",
                    "daily_precipitation_interval",
                ],
                name="uniq_ps_vm_core_source_qpf_amount_duration_interval",
            ),
            models.UniqueConstraint(
                fields=["source_qpf", "duration_hours"],
                condition=Q(daily_precipitation_interval__isnull=True),
                name="uniq_ps_vm_core_source_qpf_amount_null_interval",
            ),
            models.CheckConstraint(
                condition=Q(min_mm__lte=models.F("max_mm")),
                name="chk_ps_vm_core_source_qpf_amount_min_lte_max",
            ),
        ]

    def __str__(self):
        interval = self.daily_precipitation_interval or "senza intervallo"
        return f"{self.source_qpf} - {self.duration_hours}h - {interval}"


class QpfThreshold24h(TimeStampedModel):
    """Soglie QPF di riferimento sulle 24 ore per una singola ZVM."""

    zone = models.OneToOneField(
        ZoneVigilanzaMeteo,
        on_delete=models.CASCADE,
        related_name="qpf_threshold_24h",
        limit_choices_to={"type": "zdv"},
    )
    weak_mm = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    moderate_mm = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    elevated_mm = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    very_elevated_mm = models.PositiveIntegerField(validators=[MinValueValidator(1)])

    class Meta:
        db_table = "ps_vm_core_qpf_threshold_24h"
        ordering = ["zone__code"]
        constraints = [
            models.CheckConstraint(
                condition=Q(weak_mm__gt=0),
                name="chk_ps_vm_core_qpf_thr_24h_weak_gt_zero",
            ),
            models.CheckConstraint(
                condition=Q(weak_mm__lt=models.F("moderate_mm")),
                name="chk_ps_vm_core_qpf_thr_24h_weak_lt_mod",
            ),
            models.CheckConstraint(
                condition=Q(moderate_mm__lt=models.F("elevated_mm")),
                name="chk_ps_vm_core_qpf_thr_24h_mod_lt_elev",
            ),
            models.CheckConstraint(
                condition=Q(elevated_mm__lt=models.F("very_elevated_mm")),
                name="chk_ps_vm_core_qpf_thr_24h_elev_lt_very",
            ),
        ]

    def __str__(self):
        return f"{self.zone.code} - soglie QPF 24h"


class SourcePs(TimeStampedModel):
    map_id = models.CharField(max_length=2, choices=MapId.choices)
    zone = models.ForeignKey(
        ZoneVigilanzaMeteo,
        on_delete=models.CASCADE,
        related_name="source_ps",
    )
    phenomenon_type = models.ForeignKey(
        PhenomenonType,
        on_delete=models.PROTECT,
        related_name="source_ps",
    )
    ps_level = models.ForeignKey(
        PsLevel,
        on_delete=models.PROTECT,
        related_name="source_assignments",
    )
    icon_slot = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4)]
    )
    custom_description = models.TextField(blank=True)
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name="updated_source_ps",
        null=True,
        blank=True,
    )

    class Meta:
        db_table = "ps_vm_core_source_ps"
        ordering = ["map_id", "zone__code", "icon_slot"]
        constraints = [
            models.UniqueConstraint(
                fields=["map_id", "zone", "icon_slot"],
                name="uniq_ps_vm_core_source_ps_map_zone_slot",
            ),
        ]

    def __str__(self):
        return (
            f"{self.map_id} - {self.zone.code} - "
            f"{self.phenomenon_type.code} - slot {self.icon_slot}"
        )


class MapOperationalState(TimeStampedModel):
    key = REDACTED
    last_rollover_date = models.DateField(null=True, blank=True)

    class Meta:
        db_table = "ps_vm_core_map_operational_state"

    def __str__(self):
        return f"{self.key} - {self.last_rollover_date or 'mai'}"


class CurQpf(TimeStampedModel):
    map_id = models.CharField(max_length=2, choices=MapId.choices)
    zone = models.ForeignKey(
        ZoneVigilanzaMeteo,
        on_delete=models.CASCADE,
        related_name="current_qpf",
    )
    qpf_level = models.ForeignKey(
        QpfLevel,
        on_delete=models.PROTECT,
        related_name="current_assignments",
    )
    custom_description = models.TextField(blank=True)
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name="updated_current_qpf",
        null=True,
        blank=True,
    )

    class Meta:
        db_table = "ps_vm_core_cur_qpf"
        ordering = ["map_id", "zone__code"]
        constraints = [
            models.UniqueConstraint(
                fields=["map_id", "zone"],
                name="uniq_ps_vm_core_cur_qpf_map_zone",
            ),
        ]

    def __str__(self):
        return f"{self.map_id} - {self.zone.code} - {self.qpf_level.code}"


class CurPs(TimeStampedModel):
    map_id = models.CharField(max_length=2, choices=MapId.choices)
    zone = models.ForeignKey(
        ZoneVigilanzaMeteo,
        on_delete=models.CASCADE,
        related_name="current_ps",
    )
    phenomenon_type = models.ForeignKey(
        PhenomenonType,
        on_delete=models.PROTECT,
        related_name="current_ps",
    )
    ps_level = models.ForeignKey(
        PsLevel,
        on_delete=models.PROTECT,
        related_name="current_assignments",
    )
    icon_slot = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4)]
    )
    custom_description = models.TextField(blank=True)
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name="updated_current_ps",
        null=True,
        blank=True,
    )

    class Meta:
        db_table = "ps_vm_core_cur_ps"
        ordering = ["map_id", "zone__code", "icon_slot"]
        constraints = [
            models.UniqueConstraint(
                fields=["map_id", "zone", "icon_slot"],
                name="uniq_ps_vm_core_cur_ps_map_zone_slot",
            ),
        ]

    def __str__(self):
        return (
            f"{self.map_id} - {self.zone.code} - "
            f"{self.phenomenon_type.code} - slot {self.icon_slot}"
        )


class PsBulText(TimeStampedModel):
    day_string = models.CharField(max_length=64)
    operational_date = models.DateField(default=timezone.localdate)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name="ps_bulletins",
        null=True,
        blank=True,
    )
    bull_type = models.CharField(
        max_length=16,
        choices=BulletinKind.choices,
        default=BulletinKind.FIRST,
    )
    update_number = models.PositiveSmallIntegerField(default=0)
    is_preview = models.BooleanField(default=True)
    status = models.CharField(
        max_length=16,
        choices=BulletinStatus.choices,
        default=BulletinStatus.DRAFT,
    )
    progressive_year = models.PositiveSmallIntegerField(null=True, blank=True)
    progressive_number = models.PositiveIntegerField(null=True, blank=True)
    finalized_at = models.DateTimeField(null=True, blank=True)
    title = models.CharField(max_length=255, blank=True)
    subtitle = models.CharField(max_length=255, blank=True)
    generated_sections = models.JSONField(default=dict, blank=True)
    text_sections = models.JSONField(default=dict, blank=True)
    notes = models.TextField(blank=True)
    ts = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "ps_vm_core_ps_bul_text"
        ordering = ["-ts", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["operational_date"],
                condition=Q(status=BulletinStatus.DRAFT),
                name="uniq_ps_vm_core_ps_daily_draft",
            ),
            models.UniqueConstraint(
                fields=["progressive_year", "progressive_number"],
                condition=Q(progressive_number__isnull=False),
                name="uniq_ps_vm_core_ps_year_progressive",
            ),
        ]

    def __str__(self):
        return f"PS {self.day_string} - {self.bull_type}"


class PsBulIcon(models.Model):
    bulletin = models.ForeignKey(
        PsBulText,
        on_delete=models.CASCADE,
        related_name="icons",
    )
    map_id = models.CharField(max_length=2, choices=MapId.choices)
    zone = models.ForeignKey(
        ZoneVigilanzaMeteo,
        on_delete=models.PROTECT,
        related_name="ps_bulletin_icons",
    )
    phenomenon_type = models.ForeignKey(
        PhenomenonType,
        on_delete=models.PROTECT,
        related_name="ps_bulletin_icons",
    )
    ps_level = models.ForeignKey(
        PsLevel,
        on_delete=models.PROTECT,
        related_name="ps_bulletin_icons",
    )
    icon_slot = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4)]
    )
    zone_code = models.CharField(max_length=32, blank=True)
    zone_name = models.CharField(max_length=255, blank=True)
    phenomenon_code = models.CharField(max_length=32, blank=True)
    ps_code = models.CharField(max_length=32, blank=True)
    ps_text = models.TextField(blank=True)
    custom_description = models.TextField(blank=True)
    icon = models.FileField(upload_to="ps_bulletins/icons/", blank=True)
    color = models.CharField(max_length=32, blank=True)
    svg = models.TextField(blank=True)
    anchor = models.PointField(srid=4326, null=True, blank=True)
    zone_geometry = models.MultiPolygonField(srid=4326, null=True, blank=True)

    class Meta:
        db_table = "ps_vm_core_ps_bul_icon"
        ordering = ["bulletin_id", "map_id", "zone__code", "icon_slot"]
        constraints = [
            models.UniqueConstraint(
                fields=["bulletin", "map_id", "zone", "icon_slot"],
                name="uniq_ps_vm_core_ps_bul_icon_bul_map_zone_slot",
            ),
        ]

    def __str__(self):
        return f"PS bulletin {self.bulletin_id} - {self.map_id} - {self.zone.code}"


class VmBulText(TimeStampedModel):
    day_string = models.CharField(max_length=64)
    operational_date = models.DateField(default=timezone.localdate)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name="vm_bulletins",
        null=True,
        blank=True,
    )
    bull_type = models.CharField(
        max_length=16,
        choices=BulletinKind.choices,
        default=BulletinKind.FIRST,
    )
    update_number = models.PositiveSmallIntegerField(default=0)
    is_preview = models.BooleanField(default=True)
    status = models.CharField(
        max_length=16,
        choices=BulletinStatus.choices,
        default=BulletinStatus.DRAFT,
    )
    progressive_year = models.PositiveSmallIntegerField(null=True, blank=True)
    progressive_number = models.PositiveIntegerField(null=True, blank=True)
    finalized_at = models.DateTimeField(null=True, blank=True)
    title = models.CharField(max_length=255, blank=True)
    subtitle = models.CharField(max_length=255, blank=True)
    generated_sections = models.JSONField(default=dict, blank=True)
    text_sections = models.JSONField(default=dict, blank=True)
    notes = models.TextField(blank=True)
    ts = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "ps_vm_core_vm_bul_text"
        ordering = ["-ts", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["operational_date"],
                condition=Q(status=BulletinStatus.DRAFT),
                name="uniq_ps_vm_core_vm_daily_draft",
            ),
            models.UniqueConstraint(
                fields=["progressive_year", "progressive_number"],
                condition=Q(progressive_number__isnull=False),
                name="uniq_ps_vm_core_vm_year_progressive",
            ),
        ]

    def __str__(self):
        return f"VMN {self.day_string} - {self.bull_type}"


class VmBulZoneVigilanza(models.Model):
    bulletin = models.ForeignKey(
        VmBulText,
        on_delete=models.CASCADE,
        related_name="zones",
    )
    map_id = models.CharField(max_length=2, choices=MapId.choices)
    zone = models.ForeignKey(
        ZoneVigilanzaMeteo,
        on_delete=models.PROTECT,
        related_name="vm_bulletin_zones",
    )
    qpf_level = models.ForeignKey(
        QpfLevel,
        on_delete=models.PROTECT,
        related_name="vm_bulletin_zones",
    )
    zone_code = models.CharField(max_length=32, blank=True)
    zone_name = models.CharField(max_length=255, blank=True)
    qpf_code = models.CharField(max_length=32, blank=True)
    qpf_text = models.TextField(blank=True)
    custom_description = models.TextField(blank=True)
    color = models.CharField(max_length=32, blank=True)
    svg = models.TextField(blank=True)
    zone_geometry = models.MultiPolygonField(srid=4326, null=True, blank=True)

    class Meta:
        db_table = "ps_vm_core_vm_bul_zone_vigilanza"
        ordering = ["bulletin_id", "map_id", "zone__code"]
        constraints = [
            models.UniqueConstraint(
                fields=["bulletin", "map_id", "zone"],
                name="uniq_ps_vm_core_vm_bul_zone_vigilanza_bul_map_zone",
            ),
        ]

    def __str__(self):
        return f"VMN bulletin {self.bulletin_id} - {self.map_id} - {self.zone.code}"


class VmBulIcon(models.Model):
    bulletin = models.ForeignKey(
        VmBulText,
        on_delete=models.CASCADE,
        related_name="icons",
    )
    map_id = models.CharField(max_length=2, choices=MapId.choices)
    zone = models.ForeignKey(
        ZoneVigilanzaMeteo,
        on_delete=models.PROTECT,
        related_name="vm_bulletin_icons",
    )
    phenomenon_type = models.ForeignKey(
        PhenomenonType,
        on_delete=models.PROTECT,
        related_name="vm_bulletin_icons",
    )
    ps_level = models.ForeignKey(
        PsLevel,
        on_delete=models.PROTECT,
        related_name="vm_bulletin_icons",
    )
    display_ps_level = models.ForeignKey(
        PsLevel,
        on_delete=models.PROTECT,
        related_name="vm_bulletin_display_icons",
    )
    icon_slot = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(4)]
    )
    zone_code = models.CharField(max_length=32, blank=True)
    zone_name = models.CharField(max_length=255, blank=True)
    phenomenon_code = models.CharField(max_length=32, blank=True)
    ps_code = models.CharField(max_length=32, blank=True)
    ps_text = models.TextField(blank=True)
    display_ps_code = models.CharField(max_length=32, blank=True)
    display_ps_text = models.TextField(blank=True)
    custom_description = models.TextField(blank=True)
    icon = models.FileField(upload_to="vm_bulletins/icons/", blank=True)
    svg = models.TextField(blank=True)
    display_icon = models.FileField(upload_to="vm_bulletins/icons/", blank=True)
    display_svg = models.TextField(blank=True)
    color = models.CharField(max_length=32, blank=True)
    display_color = models.CharField(max_length=32, blank=True)
    anchor = models.PointField(srid=4326, null=True, blank=True)
    zone_geometry = models.MultiPolygonField(srid=4326, null=True, blank=True)

    class Meta:
        db_table = "ps_vm_core_vm_bul_icon"
        ordering = ["bulletin_id", "map_id", "zone__code", "icon_slot"]
        constraints = [
            models.UniqueConstraint(
                fields=["bulletin", "map_id", "zone", "icon_slot"],
                name="uniq_ps_vm_core_vm_bul_icon_bul_map_zone_slot",
            ),
        ]


class PsBulQpf(models.Model):
    bulletin = models.ForeignKey(
        PsBulText,
        on_delete=models.CASCADE,
        related_name="qpf_zones",
    )
    map_id = models.CharField(max_length=2, choices=MapId.choices)
    zone = models.ForeignKey(
        ZoneVigilanzaMeteo,
        on_delete=models.PROTECT,
        related_name="ps_bulletin_qpf_zones",
    )
    non_impulsive_type = models.ForeignKey(
        NonImpulsivePrecipitationType,
        on_delete=models.PROTECT,
        related_name="ps_bulletin_qpf_zones",
    )
    impulsive_type = models.ForeignKey(
        ImpulsivePrecipitationType,
        on_delete=models.PROTECT,
        related_name="ps_bulletin_qpf_zones",
    )
    zone_code = models.CharField(max_length=32, blank=True)
    zone_name = models.CharField(max_length=255, blank=True)
    non_impulsive_code = models.CharField(max_length=32, blank=True)
    non_impulsive_name = models.CharField(max_length=255, blank=True)
    impulsive_code = models.CharField(max_length=32, blank=True)
    impulsive_name = models.CharField(max_length=255, blank=True)
    zone_geometry = models.MultiPolygonField(srid=4326, null=True, blank=True)

    class Meta:
        db_table = "ps_vm_core_ps_bul_qpf"
        ordering = ["bulletin_id", "map_id", "zone__code"]
        constraints = [
            models.UniqueConstraint(
                fields=["bulletin", "map_id", "zone"],
                name="uniq_ps_vm_core_ps_bul_qpf_bul_map_zone",
            ),
        ]


class PsBulQpfAmount(models.Model):
    qpf_zone = models.ForeignKey(
        PsBulQpf,
        on_delete=models.CASCADE,
        related_name="amounts",
    )
    daily_precipitation_interval = models.ForeignKey(
        DailyPrecipitationInterval,
        on_delete=models.PROTECT,
        related_name="ps_bulletin_qpf_amounts",
    )
    duration_hours = models.PositiveSmallIntegerField(choices=QpfDuration.choices)
    min_mm = models.PositiveIntegerField()
    max_mm = models.PositiveIntegerField()
    interval_day = models.CharField(max_length=2, choices=MapId.choices)
    time_interval = models.CharField(max_length=13)
    interval_description = models.CharField(max_length=64)

    class Meta:
        db_table = "ps_vm_core_ps_bul_qpf_amount"
        ordering = [
            "qpf_zone__bulletin_id",
            "qpf_zone__map_id",
            "qpf_zone__zone__code",
            "duration_hours",
            "interval_day",
            "time_interval",
        ]
        constraints = [
            models.UniqueConstraint(
                fields=[
                    "qpf_zone",
                    "duration_hours",
                    "daily_precipitation_interval",
                ],
                name="uniq_ps_vm_core_ps_bul_qpf_amount",
            ),
            models.CheckConstraint(
                condition=Q(min_mm__lte=models.F("max_mm")),
                name="chk_ps_vm_core_ps_bul_qpf_amount_min_lte_max",
            ),
        ]


class BulletinSequence(TimeStampedModel):
    bulletin_type = models.CharField(max_length=16, choices=BulletinProduct.choices)
    year = models.PositiveSmallIntegerField()
    last_number = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = "ps_vm_core_bulletin_sequence"
        constraints = [
            models.UniqueConstraint(
                fields=["bulletin_type", "year"],
                name="uniq_ps_vm_core_bulletin_sequence_type_year",
            ),
        ]


class BulletinPdfArchive(TimeStampedModel):
    bulletin_type = models.CharField(max_length=16, choices=BulletinProduct.choices)
    ps_bulletin = models.ForeignKey(
        PsBulText,
        on_delete=models.CASCADE,
        related_name="pdf_archives",
        null=True,
        blank=True,
    )
    vm_bulletin = models.ForeignKey(
        VmBulText,
        on_delete=models.CASCADE,
        related_name="pdf_archives",
        null=True,
        blank=True,
    )
    file = models.FileField(upload_to="bulletin_pdfs/")
    filename = models.CharField(max_length=255, blank=True)
    content_type = models.CharField(max_length=128, default="application/pdf")
    size = models.PositiveBigIntegerField(null=True, blank=True)
    sha256 = models.CharField(max_length=64, blank=True)
    is_signed = models.BooleanField(default=False)

    class Meta:
        db_table = "ps_vm_core_bulletin_pdf_archive"
        ordering = ["-created_at", "-id"]
        constraints = [
            models.CheckConstraint(
                condition=(
                    Q(ps_bulletin__isnull=False, vm_bulletin__isnull=True)
                    | Q(ps_bulletin__isnull=True, vm_bulletin__isnull=False)
                ),
                name="chk_ps_vm_core_bulletin_pdf_archive_one_bulletin",
            ),
        ]

    def __str__(self):
        bulletin_id = self.ps_bulletin_id or self.vm_bulletin_id
        return f"{self.bulletin_type} PDF - bulletin {bulletin_id}"
