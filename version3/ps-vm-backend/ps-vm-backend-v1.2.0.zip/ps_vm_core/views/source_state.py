from django.core.exceptions import ImproperlyConfigured
from django.db import transaction
from django.db.models import Prefetch
from django.shortcuts import get_object_or_404
from rest_framework import permissions, status, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

from ps_vm_core.models import (
    ImpulsivePrecipitationType,
    NonImpulsivePrecipitationType,
    SourcePs,
    SourceQpf,
    SourceQpfAmount,
    ZoneIconAnchor,
    ZoneVigilanzaMeteo,
)
from ps_vm_core.notify import NotificationType
from ps_vm_core.operational import lock_map_operational_state
from ps_vm_core.serializers import (
    SourcePsItemWriteSerializer,
    SourcePsSerializer,
    SourcePsWriteSerializer,
    SourceQpfItemWriteSerializer,
    SourceQpfSerializer,
    SourceQpfWriteSerializer,
)
from ps_vm_core.views.current_state import (
    MAP_DAY_OFFSETS,
    CurrentStateViewSet,
    _database_user,
    _notify_after_commit,
)


def _source_qpf_queryset():
    return (
        SourceQpf.objects.select_related(
            "zone",
            "non_impulsive_type",
            "impulsive_type",
        )
        .prefetch_related(
            Prefetch(
                "amounts",
                queryset=SourceQpfAmount.objects.select_related(
                    "daily_precipitation_interval"
                ).order_by(
                    "duration_hours",
                    "daily_precipitation_interval__day",
                    "daily_precipitation_interval__sort_order",
                ),
            )
        )
        .order_by("map_id", "zone__code")
    )


def _source_qpf_snapshot(
    request,
    map_id,
    operation,
    deleted_count=0,
    reset_count=None,
):
    items = list(_source_qpf_queryset().filter(map_id=map_id))
    data = {
        "map_id": map_id,
        "operation": operation,
        "saved_count": len(items),
        "deleted_count": deleted_count,
        "zones": SourceQpfSerializer(
            items,
            many=True,
            context={"request": request},
        ).data,
    }
    if reset_count is not None:
        data["reset_count"] = reset_count
    return data


def _source_ps_snapshot(request, map_id, operation, deleted_count=0):
    items = list(
        SourcePs.objects.select_related("zone", "phenomenon_type", "ps_level")
        .filter(map_id=map_id)
        .order_by("zone__code", "icon_slot")
    )
    anchors = {
        (anchor.zone_id, anchor.slot): anchor
        for anchor in ZoneIconAnchor.objects.filter(
            zone_id__in={item.zone_id for item in items}
        )
    }
    return {
        "map_id": map_id,
        "operation": operation,
        "saved_count": len(items),
        "deleted_count": deleted_count,
        "icons": SourcePsSerializer(
            items,
            many=True,
            context={"request": request, "anchors": anchors},
        ).data,
    }


def _replace_amounts(source_qpf, amounts):
    source_qpf.amounts.all().delete()
    SourceQpfAmount.objects.bulk_create(
        [
            SourceQpfAmount(source_qpf=source_qpf, **amount)
            for amount in amounts
        ]
    )


def _default_source_qpf_types():
    """Restituisce le classificazioni sorgente usate per il reset QPF."""
    try:
        return (
            NonImpulsivePrecipitationType.objects.get(
                code="absent",
                severity=0,
                is_active=True,
            ),
            ImpulsivePrecipitationType.objects.get(
                code="absent",
                severity=0,
                is_active=True,
            ),
        )
    except (
        NonImpulsivePrecipitationType.DoesNotExist,
        ImpulsivePrecipitationType.DoesNotExist,
    ) as exc:
        raise ImproperlyConfigured(
            "Classificazioni QPF sorgente di default attive non configurate: "
            "absent (severity=0)."
        ) from exc


def _reset_source_qpf_item(item, non_impulsive_type, impulsive_type, updated_by):
    """Riporta una QPF sorgente allo stato canonico senza precipitazioni."""
    item.non_impulsive_type = non_impulsive_type
    item.impulsive_type = impulsive_type
    item.updated_by = updated_by
    item.save()
    _replace_amounts(item, [])


class SourceQpfResView(CurrentStateViewSet):
    serializer_class = SourceQpfSerializer
    result_key = REDACTED

    def get_queryset(self):
        return _source_qpf_queryset()


class SourcePsResView(CurrentStateViewSet):
    serializer_class = SourcePsSerializer
    result_key = REDACTED

    def get_queryset(self):
        return SourcePs.objects.select_related(
            "zone", "phenomenon_type", "ps_level"
        ).order_by("map_id", "zone__code", "icon_slot")

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context["anchors"] = {
            (anchor.zone_id, anchor.slot): anchor
            for anchor in ZoneIconAnchor.objects.all()
        }
        return context


class SaveSourceQpfResView(viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = SourceQpfWriteSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        map_id = serializer.validated_data["map_id"]
        assignments = serializer.validated_data["zones"]
        updated_by = _database_user(request.user)

        with transaction.atomic():
            lock_map_operational_state()
            existing = {
                item.zone_id: item
                for item in SourceQpf.objects.select_for_update().filter(map_id=map_id)
            }
            for assignment in assignments:
                zone = assignment["zone"]
                item = existing.pop(zone.pk, None)
                if item is None:
                    item = SourceQpf(map_id=map_id, zone=zone)
                item.non_impulsive_type = assignment["non_impulsive_type"]
                item.impulsive_type = assignment["impulsive_type"]
                item.updated_by = updated_by
                item.save()
                _replace_amounts(item, assignment["amounts"])

            deleted_count = len(existing)
            if existing:
                SourceQpf.objects.filter(
                    pk__in=[item.pk for item in existing.values()]
                ).delete()

            response_data = _source_qpf_snapshot(
                request, map_id, operation="replace", deleted_count=deleted_count
            )
            _notify_after_commit(
                request,
                NotificationType.UPDATE_SOURCE_QPF,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)


class SaveSourcePsResView(viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = SourcePsWriteSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        map_id = serializer.validated_data["map_id"]
        assignments = serializer.validated_data["icons"]
        updated_by = _database_user(request.user)

        with transaction.atomic():
            lock_map_operational_state()
            existing = {
                (item.zone_id, item.icon_slot): item
                for item in SourcePs.objects.select_for_update().filter(map_id=map_id)
            }
            for assignment in assignments:
                zone = assignment["zone"]
                key = REDACTED
                item = existing.pop(key, None)
                if item is None:
                    item = SourcePs(map_id=map_id, zone=zone)
                item.phenomenon_type = assignment["phenomenon_type"]
                item.ps_level = assignment["ps_level"]
                item.icon_slot = assignment["icon_slot"]
                item.custom_description = assignment.get("custom_description", "")
                item.updated_by = updated_by
                item.save()

            deleted_count = len(existing)
            if existing:
                SourcePs.objects.filter(
                    pk__in=[item.pk for item in existing.values()]
                ).delete()

            response_data = _source_ps_snapshot(
                request, map_id, operation="replace", deleted_count=deleted_count
            )
            _notify_after_commit(
                request,
                NotificationType.UPDATE_SOURCE_PS,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)


class ClearSourceStateResView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    model = None
    snapshot = None
    notification_type = None

    def delete(self, request, map_id):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        with transaction.atomic():
            lock_map_operational_state()
            queryset = self.model.objects.select_for_update().filter(map_id=map_id)
            deleted_count = queryset.count()
            queryset.delete()
            response_data = self.snapshot(
                request,
                map_id,
                operation="clear",
                deleted_count=deleted_count,
            )
            _notify_after_commit(request, self.notification_type, response_data)
        return Response(response_data, status=status.HTTP_200_OK)


class ClearSourceQpfResView(ClearSourceStateResView):
    """Riporta al default le QPF di tutte le zone sorgente della mappa."""

    def delete(self, request, map_id):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )

        non_impulsive_type, impulsive_type = _default_source_qpf_types()
        updated_by = _database_user(request.user)
        with transaction.atomic():
            lock_map_operational_state()
            existing = {
                item.zone_id: item
                for item in SourceQpf.objects.select_for_update().filter(map_id=map_id)
            }
            active_zones = list(
                ZoneVigilanzaMeteo.objects.filter(is_active=True, type="zdv")
            )
            for zone in active_zones:
                item = existing.pop(zone.pk, None)
                if item is None:
                    item = SourceQpf(map_id=map_id, zone=zone)
                _reset_source_qpf_item(
                    item,
                    non_impulsive_type,
                    impulsive_type,
                    updated_by,
                )

            # Come per le mappe intermedie, conserva coerenti anche le
            # assegnazioni storiche di zone nel frattempo disattivate.
            for item in existing.values():
                _reset_source_qpf_item(
                    item,
                    non_impulsive_type,
                    impulsive_type,
                    updated_by,
                )

            reset_count = len(active_zones) + len(existing)
            response_data = _source_qpf_snapshot(
                request,
                map_id,
                operation="reset",
                reset_count=reset_count,
            )
            _notify_after_commit(
                request,
                NotificationType.UPDATE_SOURCE_QPF,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)


class ClearSourcePsResView(ClearSourceStateResView):
    model = SourcePs
    snapshot = staticmethod(_source_ps_snapshot)
    notification_type = NotificationType.UPDATE_SOURCE_PS


class SourceQpfItemResView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def put(self, request, map_id, zone_id):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        zone = get_object_or_404(
            ZoneVigilanzaMeteo.objects.filter(is_active=True, type="zdv"),
            pk=zone_id,
        )
        serializer = SourceQpfItemWriteSerializer(
            data=request.data,
            context={"map_id": map_id},
        )
        serializer.is_valid(raise_exception=True)

        with transaction.atomic():
            lock_map_operational_state()
            item, _ = SourceQpf.objects.update_or_create(
                map_id=map_id,
                zone=zone,
                defaults={
                    "non_impulsive_type": serializer.validated_data[
                        "non_impulsive_type"
                    ],
                    "impulsive_type": serializer.validated_data["impulsive_type"],
                    "updated_by": _database_user(request.user),
                },
            )
            _replace_amounts(item, serializer.validated_data["amounts"])
            response_data = _source_qpf_snapshot(request, map_id, operation="upsert")
            _notify_after_commit(
                request, NotificationType.UPDATE_SOURCE_QPF, response_data
            )
        return Response(response_data, status=status.HTTP_200_OK)

    def delete(self, request, map_id, zone_id):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        zone = get_object_or_404(
            ZoneVigilanzaMeteo.objects.filter(is_active=True, type="zdv"),
            pk=zone_id,
        )
        non_impulsive_type, impulsive_type = _default_source_qpf_types()
        updated_by = _database_user(request.user)
        with transaction.atomic():
            lock_map_operational_state()
            item, _ = SourceQpf.objects.get_or_create(
                map_id=map_id,
                zone=zone,
                defaults={
                    "non_impulsive_type": non_impulsive_type,
                    "impulsive_type": impulsive_type,
                    "updated_by": updated_by,
                },
            )
            _reset_source_qpf_item(
                item,
                non_impulsive_type,
                impulsive_type,
                updated_by,
            )
            response_data = _source_qpf_snapshot(
                request,
                map_id,
                operation="reset",
                reset_count=1,
            )
            _notify_after_commit(
                request, NotificationType.UPDATE_SOURCE_QPF, response_data
            )
        return Response(response_data, status=status.HTTP_200_OK)


class SourcePsItemResView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def put(self, request, map_id, zone_id, icon_slot):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if icon_slot not in range(1, 5):
            return Response(
                {"icon_slot": ["Lo slot deve essere compreso tra 1 e 4."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        zone = get_object_or_404(
            ZoneVigilanzaMeteo.objects.filter(is_active=True, type="zdv"),
            pk=zone_id,
        )
        serializer = SourcePsItemWriteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        with transaction.atomic():
            lock_map_operational_state()
            SourcePs.objects.update_or_create(
                map_id=map_id,
                zone=zone,
                icon_slot=icon_slot,
                defaults={
                    "phenomenon_type": serializer.validated_data[
                        "phenomenon_type"
                    ],
                    "ps_level": serializer.validated_data["ps_level"],
                    "custom_description": serializer.validated_data.get(
                        "custom_description", ""
                    ),
                    "updated_by": _database_user(request.user),
                },
            )
            response_data = _source_ps_snapshot(request, map_id, operation="upsert")
            _notify_after_commit(
                request, NotificationType.UPDATE_SOURCE_PS, response_data
            )
        return Response(response_data, status=status.HTTP_200_OK)

    def delete(self, request, map_id, zone_id, icon_slot):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if icon_slot not in range(1, 5):
            return Response(
                {"icon_slot": ["Lo slot deve essere compreso tra 1 e 4."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        with transaction.atomic():
            lock_map_operational_state()
            deleted_count, _ = SourcePs.objects.filter(
                map_id=map_id,
                zone_id=zone_id,
                icon_slot=icon_slot,
            ).delete()
            if not deleted_count:
                return Response(
                    {"detail": "Icona sorgente non trovata."},
                    status=status.HTTP_404_NOT_FOUND,
                )
            response_data = _source_ps_snapshot(
                request, map_id, operation="delete", deleted_count=1
            )
            _notify_after_commit(
                request, NotificationType.UPDATE_SOURCE_PS, response_data
            )
        return Response(response_data, status=status.HTTP_200_OK)
