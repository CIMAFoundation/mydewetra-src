from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from ps_vm_core.bulletin_serializers import (
    BulletinWriteSerializer,
    PsBulletinDetailSerializer,
    PsBulletinListSerializer,
    VmBulletinDetailSerializer,
    VmBulletinListSerializer,
)
from ps_vm_core.bulletins import finalize_draft, initialize_draft, refresh_draft
from ps_vm_core.models import (
    BulletinProduct,
    BulletinStatus,
    PsBulText,
    VmBulText,
)


class BulletinViewSet(viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    product = None
    detail_serializer_class = None
    list_serializer_class = None

    def get_serializer_class(self):
        if self.action == "list":
            return self.list_serializer_class
        if self.action == "partial_update":
            return BulletinWriteSerializer
        return self.detail_serializer_class

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        return Response(self.list_serializer_class(queryset, many=True).data)

    def retrieve(self, request, *args, **kwargs):
        return Response(self.detail_serializer_class(self.get_object()).data)

    def partial_update(self, request, *args, **kwargs):
        bulletin = self.get_object()
        if bulletin.status != BulletinStatus.DRAFT:
            return Response(
                {"status": "Un bollettino finalizzato è immutabile."},
                status=status.HTTP_409_CONFLICT,
            )
        serializer = BulletinWriteSerializer(
            bulletin,
            data=request.data,
            partial=True,
        )
        serializer.is_valid(raise_exception=True)
        bulletin = serializer.save()
        return Response(self.detail_serializer_class(bulletin).data)

    @action(detail=False, methods=["post"], url_path="draft")
    def draft(self, request):
        bulletin, created = initialize_draft(self.product, request.user)
        response_status = status.HTTP_201_CREATED if created else status.HTTP_200_OK
        data = self.detail_serializer_class(bulletin).data
        data["created"] = created
        return Response(data, status=response_status)

    @action(detail=True, methods=["post"])
    def refresh(self, request, pk=None):
        bulletin = self.get_object()
        if bulletin.status != BulletinStatus.DRAFT:
            return Response(
                {"status": "Un bollettino finalizzato è immutabile."},
                status=status.HTTP_409_CONFLICT,
            )
        bulletin = refresh_draft(bulletin.pk, self.product)
        return Response(self.detail_serializer_class(bulletin).data)

    @action(detail=True, methods=["post"])
    def finalize(self, request, pk=None):
        self.get_object()
        bulletin, finalized = finalize_draft(pk, self.product, request.user)
        data = self.detail_serializer_class(bulletin).data
        data["finalized"] = finalized
        return Response(data)


class PsBulletinViewSet(BulletinViewSet):
    product = BulletinProduct.PS
    detail_serializer_class = PsBulletinDetailSerializer
    list_serializer_class = PsBulletinListSerializer

    def get_queryset(self):
        return PsBulText.objects.select_related("user").order_by("-created_at", "-id")


class VmBulletinViewSet(BulletinViewSet):
    product = BulletinProduct.VMN
    detail_serializer_class = VmBulletinDetailSerializer
    list_serializer_class = VmBulletinListSerializer

    def get_queryset(self):
        return VmBulText.objects.select_related("user").order_by("-created_at", "-id")
