from django.core.management.color import no_style
from django.db import migrations, models


INTERVALS = (
    (1, "d0", "12:00 - 18:00", "Dalle 12:00 alle 18:00", 1),
    (2, "d0", "18:00 - 24:00", "Dalle 18:00 alle 24:00", 2),
    (3, "d1", "00:00 - 06:00", "Dalle 00:00 alle 06:00", 1),
    (4, "d1", "06:00 - 12:00", "Dalle 06:00 alle 12:00", 2),
    (5, "d1", "12:00 - 18:00", "Dalle 12:00 alle 18:00", 3),
    (6, "d1", "18:00 - 24:00", "Dalle 18:00 alle 24:00", 4),
    (7, "d2", "00:00 - 06:00", "Dalle 00:00 alle 06:00", 1),
    (8, "d2", "06:00 - 12:00", "Dalle 06:00 alle 12:00", 2),
    (9, "d2", "12:00 - 18:00", "Dalle 12:00 alle 18:00", 3),
    (10, "d2", "18:00 - 24:00", "Dalle 18:00 alle 24:00", 4),
)

LEGACY_INTERVALS = (
    (1, "OGGI", "12:00 - 18:00", "OGGI dalle 12:00 alle 18:00", 1),
    (2, "OGGI", "18:00 - 24:00", "OGGI dalle 18:00 alle 24:00", 2),
    (3, "DOMANI", "00:00 - 06:00", "DOMANI dalle 00:00 alle 06:00", 3),
    (4, "DOMANI", "06:00 - 12:00", "DOMANI dalle 06:00 alle 12:00", 4),
    (5, "DOMANI", "12:00 - 18:00", "DOMANI dalle 12:00 alle 18:00", 5),
    (6, "DOMANI", "18:00 - 24:00", "DOMANI dalle 18:00 alle 24:00", 6),
)


def _upsert_intervals(apps, schema_editor, intervals):
    interval_model = apps.get_model("ps_vm_core", "DailyPrecipitationInterval")
    for pk, day, time_interval, description, sort_order in intervals:
        interval_model.objects.update_or_create(
            pk=pk,
            defaults={
                "day": day,
                "time_interval": time_interval,
                "description": description,
                "sort_order": sort_order,
                "is_active": True,
            },
        )

    for sql in schema_editor.connection.ops.sequence_reset_sql(
        no_style(), [interval_model]
    ):
        schema_editor.execute(sql)


def sync_daily_precipitation_intervals(apps, schema_editor):
    _upsert_intervals(apps, schema_editor, INTERVALS)


def restore_legacy_daily_precipitation_intervals(apps, schema_editor):
    interval_model = apps.get_model("ps_vm_core", "DailyPrecipitationInterval")
    interval_model.objects.filter(pk__in=(7, 8, 9, 10)).delete()
    _upsert_intervals(apps, schema_editor, LEGACY_INTERVALS)


class Migration(migrations.Migration):
    dependencies = [
        ("ps_vm_core", "0012_remove_default_zero_qpf_amounts"),
    ]

    operations = [
        migrations.RunPython(
            sync_daily_precipitation_intervals,
            restore_legacy_daily_precipitation_intervals,
        ),
        migrations.AlterField(
            model_name="dailyprecipitationinterval",
            name="day",
            field=models.CharField(
                choices=[
                    ("d0", "Oggi"),
                    ("d1", "Domani"),
                    ("d2", "Dopodomani"),
                ],
                max_length=2,
            ),
        ),
        migrations.AlterModelOptions(
            name="dailyprecipitationinterval",
            options={"ordering": ["day", "sort_order", "time_interval"]},
        ),
        migrations.AlterModelOptions(
            name="sourceqpfamount",
            options={
                "ordering": [
                    "source_qpf__map_id",
                    "source_qpf__zone__code",
                    "duration_hours",
                    "daily_precipitation_interval__day",
                    "daily_precipitation_interval__sort_order",
                ]
            },
        ),
    ]
