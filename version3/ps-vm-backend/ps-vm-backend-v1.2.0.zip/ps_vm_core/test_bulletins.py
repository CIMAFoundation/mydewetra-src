from datetime import date

from django.contrib.auth import get_user_model
from django.contrib.gis.geos import GEOSGeometry, Point
from django.test import override_settings
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from ps_vm_core.models import (
    BulletinKind,
    BulletinProduct,
    BulletinSequence,
    BulletinSettings,
    BulletinStatus,
    CurPs,
    CurQpf,
    DailyPrecipitationInterval,
    ImpulsivePrecipitationType,
    MapId,
    NonImpulsivePrecipitationType,
    PhenomenonType,
    PsBulText,
    PsLevel,
    QpfLevel,
    Region,
    SourceQpf,
    SourceQpfAmount,
    VmBulText,
    ZoneIconAnchor,
    ZoneVigilanzaMeteo,
)


class BulletinApiTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username="bulletin-user")
        self.client.force_authenticate(self.user)
        self.region = Region.objects.create(code="LAZ", name="Lazio")
        self.zone_a = self._zone("A", "Zona Alfa")
        self.zone_b = self._zone("B", "Zona Beta")
        self.zone_out = self._zone("OUT", "Zona esclusa")
        self.zone_a.regions.add(self.region)
        self.zone_b.regions.add(self.region)
        settings, _created = BulletinSettings.objects.get_or_create(
            bulletin_type=BulletinProduct.PS,
            user=None,
        )
        settings.is_active = True
        settings.save()
        settings.qpf_regions.set([self.region])

        self.rain = PhenomenonType.objects.get(code="piogge")
        self.rain_isolated = PsLevel.objects.get(
            phenomenon_type=self.rain,
            code="piogge_isolate",
        )
        self.rain_sparse = PsLevel.objects.get(
            phenomenon_type=self.rain,
            code="piogge_sparse",
        )
        self.storm = PhenomenonType.objects.get(code="temporali")
        self.shower_isolated = PsLevel.objects.get(
            phenomenon_type=self.storm,
            code="rovesci_isolati",
        )
        self.storm_isolated = PsLevel.objects.get(
            phenomenon_type=self.storm,
            code="temporali_isolati",
        )
        self.qpf = QpfLevel.objects.get(code="deboli")
        for zone in (self.zone_a, self.zone_b, self.zone_out):
            ZoneIconAnchor.objects.create(
                zone=zone,
                slot=1,
                point=Point(12, 42, srid=4326),
            )
            CurQpf.objects.create(
                map_id=MapId.TODAY,
                zone=zone,
                qpf_level=self.qpf,
            )

        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone_a,
            phenomenon_type=self.rain,
            ps_level=self.rain_isolated,
            icon_slot=1,
            custom_description="in serata",
        )
        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone_b,
            phenomenon_type=self.rain,
            ps_level=self.rain_isolated,
            icon_slot=1,
            custom_description="in serata",
        )
        self._source_qpf(MapId.TODAY, self.zone_a)
        self._source_qpf(MapId.TODAY, self.zone_b)
        self._source_qpf(MapId.DAY_AFTER_TOMORROW, self.zone_a)

    def _zone(self, code, name):
        return ZoneVigilanzaMeteo.objects.create(
            code=code,
            name=name,
            geometry=GEOSGeometry(
                "MULTIPOLYGON(((10 40, 10 41, 11 41, 11 40, 10 40)))",
                srid=4326,
            ),
        )

    def _source_qpf(self, map_id, zone):
        source = SourceQpf.objects.create(
            map_id=map_id,
            zone=zone,
            non_impulsive_type=NonImpulsivePrecipitationType.objects.get(
                code="piogge_sparse"
            ),
            impulsive_type=ImpulsivePrecipitationType.objects.get(
                code="temporali_isolati"
            ),
        )
        interval = DailyPrecipitationInterval.objects.filter(day=map_id).first()
        SourceQpfAmount.objects.create(
            source_qpf=source,
            duration_hours=6,
            min_mm=5,
            max_mm=20,
            daily_precipitation_interval=interval,
        )

    def test_drafts_are_idempotent_and_products_keep_independent_texts(self):
        first = self.client.post("/api/ps_bulletins/draft/", {}, format="json")
        second = self.client.post("/api/ps_bulletins/draft/", {}, format="json")
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json")

        self.assertEqual(first.status_code, status.HTTP_201_CREATED)
        self.assertEqual(second.status_code, status.HTTP_200_OK)
        self.assertEqual(first.data["id"], second.data["id"])
        self.assertEqual(vm.status_code, status.HTTP_201_CREATED)
        self.assertEqual(PsBulText.objects.count(), 1)
        self.assertEqual(VmBulText.objects.count(), 1)
        categories = first.data["generated_sections"]["days"][0]["categories"]
        self.assertEqual(
            [item["code"] for item in categories],
            ["precipitazioni", "visibilita", "temperature", "venti", "mari"],
        )
        self.assertIn("Zona Alfa", categories[0]["generated_text"])
        self.assertEqual(categories[1]["generated_text"], "nessun fenomeno significativo.")

        edited = first.data["text_sections"]
        edited["d0"]["precipitazioni"] = "Testo PS indipendente."
        response = self.client.patch(
            f"/api/ps_bulletins/{first.data['id']}/",
            {"text_sections": edited},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertNotEqual(
            response.data["text_sections"],
            vm.data["text_sections"],
        )

    def test_refresh_overwrites_manual_text_and_qpf_rows_are_grouped(self):
        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        edited = draft["text_sections"]
        edited["d0"]["precipitazioni"] = "Modifica manuale."
        self.client.patch(
            f"/api/ps_bulletins/{draft['id']}/",
            {"text_sections": edited},
            format="json",
        )

        response = self.client.post(
            f"/api/ps_bulletins/{draft['id']}/refresh/",
            {},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertNotEqual(
            response.data["text_sections"]["d0"]["precipitazioni"],
            "Modifica manuale.",
        )
        self.assertEqual(len(response.data["qpf_rows"]), 1)
        self.assertEqual(
            [zone["code"] for zone in response.data["qpf_rows"][0]["zones"]],
            ["A", "B"],
        )

    def test_vm_map_collapses_only_display_levels(self):
        draft = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data
        icon = draft["maps"][0]["icons"][0]
        self.assertEqual(icon["original_level"]["code"], "piogge_isolate")
        self.assertEqual(icon["display_level"]["code"], "piogge_sparse")
        generated = draft["generated_sections"]["days"][0]["categories"][0]
        self.assertIn("Piogge isolate", generated["generated_text"])

        CurPs.objects.filter(map_id=MapId.TODAY).delete()
        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone_a,
            phenomenon_type=self.storm,
            ps_level=self.shower_isolated,
            icon_slot=1,
        )
        refreshed = self.client.post(
            f"/api/vm_bulletins/{draft['id']}/refresh/", {}, format="json"
        ).data
        icon = refreshed["maps"][0]["icons"][0]
        self.assertEqual(icon["original_level"]["code"], "rovesci_isolati")
        self.assertEqual(icon["display_level"]["code"], "temporali_isolati")

    def test_finalize_assigns_daily_type_and_independent_annual_sequences(self):
        ps1 = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        first = self.client.post(
            f"/api/ps_bulletins/{ps1['id']}/finalize/", {}, format="json"
        )
        ps2 = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        update = self.client.post(
            f"/api/ps_bulletins/{ps2['id']}/finalize/", {}, format="json"
        )
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data
        vm_first = self.client.post(
            f"/api/vm_bulletins/{vm['id']}/finalize/", {}, format="json"
        )

        self.assertEqual(first.data["bull_type"], BulletinKind.FIRST)
        self.assertEqual(first.data["progressive_number"], 1)
        self.assertEqual(update.data["bull_type"], BulletinKind.UPDATE)
        self.assertEqual(update.data["update_number"], 1)
        self.assertEqual(update.data["progressive_number"], 2)
        self.assertEqual(vm_first.data["progressive_number"], 1)
        self.assertEqual(
            BulletinSequence.objects.get(
                bulletin_type=BulletinProduct.PS,
                year=timezone.localdate().year,
            ).last_number,
            2,
        )

        immutable = self.client.patch(
            f"/api/ps_bulletins/{ps1['id']}/",
            {"title": "Non consentito"},
            format="json",
        )
        self.assertEqual(immutable.status_code, status.HTTP_409_CONFLICT)
