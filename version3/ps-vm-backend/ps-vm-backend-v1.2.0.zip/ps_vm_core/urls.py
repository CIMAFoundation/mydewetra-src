from django.urls import path
from rest_framework.routers import DefaultRouter

from ps_vm_core.views.catalogs import (
    DailyPrecipitationIntervalResView,
    ImpulsivePrecipitationTypeResView,
    NonImpulsivePrecipitationTypeResView,
    PsIconResView,
    QpfLevelResView,
    QpfThreshold24hResView,
    WeatherVigilanceZoneResView,
    ZoneIconAnchorResView,
)
from ps_vm_core.views.current_state import (
    ClearCurrentPsResView,
    ClearCurrentQpfResView,
    CurrentPsItemResView,
    CurrentPsResView,
    CurrentQpfItemResView,
    CurrentQpfResView,
    SaveCurrentPsResView,
    SaveCurrentQpfResView,
)
from ps_vm_core.views.bulletins import PsBulletinViewSet, VmBulletinViewSet
from ps_vm_core.views.map_layers import (
    AncillaryLayerResView,
    BackgroundResView,
    BaseMapResView,
)
from ps_vm_core.views.promotion import PromoteSourceMapsResView
from ps_vm_core.views.source_state import (
    ClearSourcePsResView,
    ClearSourceQpfResView,
    SaveSourcePsResView,
    SaveSourceQpfResView,
    SourcePsItemResView,
    SourcePsResView,
    SourceQpfItemResView,
    SourceQpfResView,
)

ps_vm_api_router = DefaultRouter()

ps_vm_api_router.register(r"background_layer", BackgroundResView, basename="background_layer")
ps_vm_api_router.register(r"ancillary_layer", AncillaryLayerResView, basename="ancillary_layer")
ps_vm_api_router.register(r"base_map", BaseMapResView, basename="base_map")
ps_vm_api_router.register(r"qpf_levels", QpfLevelResView, basename="qpf_levels")
ps_vm_api_router.register(r"qpf_thresholds", QpfThreshold24hResView, basename="qpf_thresholds")
ps_vm_api_router.register(r"daily_precipitation_intervals", DailyPrecipitationIntervalResView, basename="daily_precipitation_intervals")
ps_vm_api_router.register(r"ps_icons", PsIconResView, basename="ps_icons")
ps_vm_api_router.register(r"weather_vigilance_zones", WeatherVigilanceZoneResView, basename="weather_vigilance_zones")
ps_vm_api_router.register(r"zone_icon_anchors", ZoneIconAnchorResView, basename="zone_icon_anchors")
ps_vm_api_router.register(r"non_impulsive_precipitation_types", NonImpulsivePrecipitationTypeResView, basename="non_impulsive_precipitation_types")
ps_vm_api_router.register(r"impulsive_precipitation_types", ImpulsivePrecipitationTypeResView, basename="impulsive_precipitation_types")
ps_vm_api_router.register(r"source_qpf", SourceQpfResView, basename="source_qpf")
ps_vm_api_router.register(r"source_ps", SourcePsResView, basename="source_ps")
ps_vm_api_router.register(r"save_source_qpf", SaveSourceQpfResView, basename="save_source_qpf")
ps_vm_api_router.register(r"save_source_ps", SaveSourcePsResView, basename="save_source_ps")
ps_vm_api_router.register(r"current_qpf", CurrentQpfResView, basename="current_qpf")
ps_vm_api_router.register(r"current_ps", CurrentPsResView, basename="current_ps")
ps_vm_api_router.register(r"save_current_qpf", SaveCurrentQpfResView, basename="save_current_qpf")
ps_vm_api_router.register(r"save_current_ps", SaveCurrentPsResView, basename="save_current_ps")
ps_vm_api_router.register(r"ps_bulletins", PsBulletinViewSet, basename="ps_bulletins")
ps_vm_api_router.register(r"vm_bulletins", VmBulletinViewSet, basename="vm_bulletins")

urlpatterns = [
    path(
        "promote_source_maps/",
        PromoteSourceMapsResView.as_view(),
        name="promote_source_maps",
    ),
    path(
        "source_qpf/<str:map_id>/",
        ClearSourceQpfResView.as_view(),
        name="clear_source_qpf",
    ),
    path(
        "source_ps/<str:map_id>/",
        ClearSourcePsResView.as_view(),
        name="clear_source_ps",
    ),
    path(
        "source_qpf/<str:map_id>/<int:zone_id>/",
        SourceQpfItemResView.as_view(),
        name="source_qpf_item",
    ),
    path(
        "source_ps/<str:map_id>/<int:zone_id>/<int:icon_slot>/",
        SourcePsItemResView.as_view(),
        name="source_ps_item",
    ),
    path(
        "current_qpf/<str:map_id>/",
        ClearCurrentQpfResView.as_view(),
        name="clear_current_qpf",
    ),
    path(
        "current_ps/<str:map_id>/",
        ClearCurrentPsResView.as_view(),
        name="clear_current_ps",
    ),
    path(
        "current_qpf/<str:map_id>/<int:zone_id>/",
        CurrentQpfItemResView.as_view(),
        name="current_qpf_item",
    ),
    path(
        "current_ps/<str:map_id>/<int:zone_id>/<int:icon_slot>/",
        CurrentPsItemResView.as_view(),
        name="current_ps_item",
    ),
]
urlpatterns += ps_vm_api_router.urls
