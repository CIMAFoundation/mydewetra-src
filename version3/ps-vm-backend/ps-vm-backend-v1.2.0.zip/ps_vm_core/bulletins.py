from collections import OrderedDict
from datetime import timedelta

from django.db import transaction
from django.db.models import Prefetch
from django.utils import timezone
from rest_framework import serializers

from ps_vm_core.models import (
    BulletinKind,
    BulletinProduct,
    BulletinSequence,
    BulletinSettings,
    BulletinStatus,
    CurPs,
    CurQpf,
    MapId,
    PsBulIcon,
    PsBulQpf,
    PsBulQpfAmount,
    PsBulText,
    PsLevel,
    SourceQpf,
    SourceQpfAmount,
    VmBulIcon,
    VmBulText,
    VmBulZoneVigilanza,
    ZoneIconAnchor,
)
from ps_vm_core.operational import lock_map_operational_state
from ps_vm_core.views.current_state import MAP_DAY_OFFSETS, _database_user


CATEGORY_DEFINITIONS = (
    ("precipitazioni", "Precipitazioni", ("piogge", "temporali", "nevicate")),
    ("visibilita", "Visibilità", ("nebbie",)),
    ("temperature", "Temperature", ("temperature", "gelate")),
    ("venti", "Venti", ("venti",)),
    ("mari", "Mari", ("mari", "moto_ondoso")),
)
CATEGORY_BY_PHENOMENON = {
    phenomenon: category
    for category, _label, phenomena in CATEGORY_DEFINITIONS
    for phenomenon in phenomena
}
NO_SIGNIFICANT_PHENOMENA = "nessun fenomeno significativo."
VM_DISPLAY_LEVEL_MAPPING = {
    "piogge_isolate": "piogge_sparse",
    "rovesci_isolati": "temporali_isolati",
}

PRODUCT_MODELS = {
    BulletinProduct.PS: PsBulText,
    BulletinProduct.VMN: VmBulText,
}


def _settings_for(product):
    return (
        BulletinSettings.objects.filter(
            bulletin_type=product,
            user__isnull=True,
            is_active=True,
        )
        .prefetch_related("qpf_regions")
        .first()
    )


def _current_icons():
    return list(
        CurPs.objects.select_related("zone", "phenomenon_type", "ps_level")
        .filter(map_id__in=MAP_DAY_OFFSETS)
        .order_by(
            "map_id",
            "phenomenon_type__sort_order",
            "ps_level__sort_order",
            "zone__code",
            "icon_slot",
        )
    )


def _anchors_for(items):
    keys = REDACTED
    if not keys:
        return {}
    zone_ids = {zone_id for zone_id, _slot in keys}
    return {
        (anchor.zone_id, anchor.slot): anchor
        for anchor in ZoneIconAnchor.objects.filter(zone_id__in=zone_ids)
        if (anchor.zone_id, anchor.slot) in keys
    }


def _sentence(level_text, custom_description, zone_names):
    base = (level_text or "Fenomeno significativo").strip().rstrip(".")
    sentence = f"{base} sulle zone {', '.join(zone_names)}"
    custom = custom_description.strip()
    if custom:
        sentence += f" ({custom.rstrip('.')})"
    return sentence + "."


def build_generated_sections(items, operational_date):
    grouped = {
        map_id: {category: OrderedDict() for category, _label, _types in CATEGORY_DEFINITIONS}
        for map_id in MAP_DAY_OFFSETS
    }
    for item in items:
        category = CATEGORY_BY_PHENOMENON.get(item.phenomenon_type.code)
        if category is None:
            continue
        custom = item.custom_description.strip()
        key = REDACTED
            item.phenomenon_type.sort_order,
            item.ps_level.sort_order,
            item.phenomenon_type.code,
            item.ps_level.code,
            custom,
        )
        group = grouped[item.map_id][category].setdefault(
            key,
            {
                "phenomenon": {
                    "code": item.phenomenon_type.code,
                    "name": item.phenomenon_type.name,
                },
                "level": {
                    "code": item.ps_level.code,
                    "text": item.ps_level.text or item.ps_level.description,
                },
                "custom_description": custom,
                "zones": OrderedDict(),
            },
        )
        group["zones"].setdefault(
            item.zone.code,
            {
                "id": item.zone_id,
                "code": item.zone.code,
                "name": item.zone.name,
            },
        )

    days = []
    text_sections = {}
    for map_id, offset in MAP_DAY_OFFSETS.items():
        valid_date = operational_date + timedelta(days=offset)
        categories = []
        text_sections[map_id] = {}
        for category_code, category_label, _types in CATEGORY_DEFINITIONS:
            category_groups = []
            sentences = []
            for group in grouped[map_id][category_code].values():
                group = dict(group)
                zones = list(group.pop("zones").values())
                sentence = _sentence(
                    group["level"]["text"],
                    group["custom_description"],
                    [zone["name"] for zone in zones],
                )
                group["zones"] = zones
                group["text"] = sentence
                category_groups.append(group)
                sentences.append(sentence)
            generated_text = " ".join(sentences) or NO_SIGNIFICANT_PHENOMENA
            categories.append(
                {
                    "code": category_code,
                    "label": category_label,
                    "groups": category_groups,
                    "generated_text": generated_text,
                }
            )
            text_sections[map_id][category_code] = generated_text
        days.append(
            {
                "map_id": map_id,
                "valid_date": valid_date.isoformat(),
                "categories": categories,
            }
        )
    return {"days": days}, text_sections


def _copy_ps_icons(bulletin, items, anchors):
    PsBulIcon.objects.bulk_create(
        [
            PsBulIcon(
                bulletin=bulletin,
                map_id=item.map_id,
                zone=item.zone,
                phenomenon_type=item.phenomenon_type,
                ps_level=item.ps_level,
                icon_slot=item.icon_slot,
                zone_code=item.zone.code,
                zone_name=item.zone.name,
                phenomenon_code=item.phenomenon_type.code,
                ps_code=item.ps_level.code,
                ps_text=item.ps_level.text or item.ps_level.description,
                custom_description=item.custom_description,
                icon=item.ps_level.icon.name if item.ps_level.icon else "",
                color=item.ps_level.color,
                svg=item.ps_level.svg,
                anchor=getattr(anchors.get((item.zone_id, item.icon_slot)), "point", None),
                zone_geometry=item.zone.geometry,
            )
            for item in items
        ]
    )


def _display_levels(items):
    result = {}
    for item in items:
        target_code = VM_DISPLAY_LEVEL_MAPPING.get(item.ps_level.code)
        if target_code is None:
            result[item.pk] = item.ps_level
            continue
        try:
            result[item.pk] = PsLevel.objects.get(
                phenomenon_type=item.phenomenon_type,
                code=target_code,
                is_active=True,
            )
        except PsLevel.DoesNotExist as exc:
            raise serializers.ValidationError(
                {
                    "vm_icons": (
                        "Livello cartografico VMN non configurato: "
                        f"{item.phenomenon_type.code}/{target_code}."
                    )
                }
            ) from exc
    return result


def _copy_vm_icons(bulletin, items, anchors):
    display_levels = _display_levels(items)
    VmBulIcon.objects.bulk_create(
        [
            VmBulIcon(
                bulletin=bulletin,
                map_id=item.map_id,
                zone=item.zone,
                phenomenon_type=item.phenomenon_type,
                ps_level=item.ps_level,
                display_ps_level=display_levels[item.pk],
                icon_slot=item.icon_slot,
                zone_code=item.zone.code,
                zone_name=item.zone.name,
                phenomenon_code=item.phenomenon_type.code,
                ps_code=item.ps_level.code,
                ps_text=item.ps_level.text or item.ps_level.description,
                display_ps_code=display_levels[item.pk].code,
                display_ps_text=(
                    display_levels[item.pk].text or display_levels[item.pk].description
                ),
                custom_description=item.custom_description,
                icon=item.ps_level.icon.name if item.ps_level.icon else "",
                svg=item.ps_level.svg,
                display_icon=(
                    display_levels[item.pk].icon.name
                    if display_levels[item.pk].icon
                    else ""
                ),
                display_svg=display_levels[item.pk].svg,
                color=item.ps_level.color,
                display_color=display_levels[item.pk].color,
                anchor=getattr(anchors.get((item.zone_id, item.icon_slot)), "point", None),
                zone_geometry=item.zone.geometry,
            )
            for item in items
        ]
    )


def _copy_vm_qpf(bulletin):
    items = list(
        CurQpf.objects.select_related("zone", "qpf_level")
        .filter(map_id__in=MAP_DAY_OFFSETS)
        .order_by("map_id", "zone__code")
    )
    VmBulZoneVigilanza.objects.bulk_create(
        [
            VmBulZoneVigilanza(
                bulletin=bulletin,
                map_id=item.map_id,
                zone=item.zone,
                qpf_level=item.qpf_level,
                zone_code=item.zone.code,
                zone_name=item.zone.name,
                qpf_code=item.qpf_level.code,
                qpf_text=item.qpf_level.text or item.qpf_level.description,
                custom_description=item.custom_description,
                color=item.qpf_level.color,
                svg=item.qpf_level.svg,
                zone_geometry=item.zone.geometry,
            )
            for item in items
        ]
    )


def _copy_ps_qpf(bulletin, settings):
    if settings is None or not settings.qpf_regions.exists():
        raise serializers.ValidationError(
            {
                "qpf_regions": (
                    "Configurare almeno una regione QPF nelle impostazioni globali "
                    "del bollettino PS."
                )
            }
        )
    region_ids = settings.qpf_regions.values_list("id", flat=True)
    queryset = (
        SourceQpf.objects.select_related(
            "zone", "non_impulsive_type", "impulsive_type"
        )
        .prefetch_related(
            Prefetch(
                "amounts",
                queryset=SourceQpfAmount.objects.select_related(
                    "daily_precipitation_interval"
                ).order_by(
                    "duration_hours",
                    "daily_precipitation_interval__sort_order",
                ),
            )
        )
        .filter(map_id__in=(MapId.TODAY, MapId.TOMORROW), zone__regions__in=region_ids)
        .distinct()
        .order_by("map_id", "zone__code")
    )
    for item in queryset:
        amounts = [
            amount
            for amount in item.amounts.all()
            if amount.daily_precipitation_interval is not None
            and amount.daily_precipitation_interval.day == item.map_id
        ]
        if (
            item.non_impulsive_type.code == "absent"
            and item.impulsive_type.code == "absent"
            and not amounts
        ):
            continue
        qpf_zone = PsBulQpf.objects.create(
            bulletin=bulletin,
            map_id=item.map_id,
            zone=item.zone,
            non_impulsive_type=item.non_impulsive_type,
            impulsive_type=item.impulsive_type,
            zone_code=item.zone.code,
            zone_name=item.zone.name,
            non_impulsive_code=item.non_impulsive_type.code,
            non_impulsive_name=item.non_impulsive_type.name,
            impulsive_code=item.impulsive_type.code,
            impulsive_name=item.impulsive_type.name,
            zone_geometry=item.zone.geometry,
        )
        PsBulQpfAmount.objects.bulk_create(
            [
                PsBulQpfAmount(
                    qpf_zone=qpf_zone,
                    daily_precipitation_interval=amount.daily_precipitation_interval,
                    duration_hours=amount.duration_hours,
                    min_mm=amount.min_mm,
                    max_mm=amount.max_mm,
                    interval_day=amount.daily_precipitation_interval.day,
                    time_interval=amount.daily_precipitation_interval.time_interval,
                    interval_description=(
                        amount.daily_precipitation_interval.description
                    ),
                )
                for amount in amounts
            ]
        )


def refresh_bulletin(bulletin, product):
    if bulletin.status != BulletinStatus.DRAFT:
        raise serializers.ValidationError(
            {"status": "Un bollettino finalizzato non può essere aggiornato."}
        )
    items = _current_icons()
    anchors = _anchors_for(items)
    generated, editable = build_generated_sections(items, bulletin.operational_date)
    bulletin.generated_sections = generated
    bulletin.text_sections = editable
    bulletin.save(update_fields=["generated_sections", "text_sections", "updated_at"])

    if product == BulletinProduct.PS:
        bulletin.icons.all().delete()
        bulletin.qpf_zones.all().delete()
        _copy_ps_icons(bulletin, items, anchors)
        _copy_ps_qpf(bulletin, _settings_for(product))
    else:
        bulletin.icons.all().delete()
        bulletin.zones.all().delete()
        _copy_vm_icons(bulletin, items, anchors)
        _copy_vm_qpf(bulletin)
    return bulletin


@transaction.atomic
def initialize_draft(product, authenticated_user):
    lock_map_operational_state()
    operational_date = timezone.localdate()
    model = PRODUCT_MODELS[product]
    existing = model.objects.select_for_update().filter(
        operational_date=operational_date,
        status=BulletinStatus.DRAFT,
    ).first()
    if existing is not None:
        return existing, False

    settings = _settings_for(product)
    bulletin = model.objects.create(
        day_string=operational_date.strftime("%Y%m%d"),
        operational_date=operational_date,
        user=_database_user(authenticated_user),
        title=settings.title if settings else "",
        subtitle=(settings.default_titles.get("subtitle", "") if settings else ""),
        notes=(settings.default_texts.get("notes", "") if settings else ""),
    )
    refresh_bulletin(bulletin, product)
    return bulletin, True


@transaction.atomic
def refresh_draft(bulletin_id, product):
    lock_map_operational_state()
    model = PRODUCT_MODELS[product]
    bulletin = model.objects.select_for_update().get(pk=bulletin_id)
    return refresh_bulletin(bulletin, product)


@transaction.atomic
def finalize_draft(bulletin_id, product, authenticated_user):
    model = PRODUCT_MODELS[product]
    bulletin = model.objects.select_for_update().get(pk=bulletin_id)
    if bulletin.status != BulletinStatus.DRAFT:
        return bulletin, False

    finalized = model.objects.filter(
        operational_date=bulletin.operational_date,
        status=BulletinStatus.FINALIZED,
    )
    previous_updates = finalized.filter(bull_type=BulletinKind.UPDATE).count()
    if finalized.exists():
        bulletin.bull_type = BulletinKind.UPDATE
        bulletin.update_number = previous_updates + 1
    else:
        bulletin.bull_type = BulletinKind.FIRST
        bulletin.update_number = 0

    year = bulletin.operational_date.year
    sequence, _created = BulletinSequence.objects.get_or_create(
        bulletin_type=product,
        year=year,
        defaults={"last_number": 0},
    )
    sequence = BulletinSequence.objects.select_for_update().get(pk=sequence.pk)
    sequence.last_number += 1
    sequence.save(update_fields=["last_number", "updated_at"])

    bulletin.progressive_year = year
    bulletin.progressive_number = sequence.last_number
    bulletin.status = BulletinStatus.FINALIZED
    bulletin.is_preview = False
    bulletin.finalized_at = timezone.now()
    bulletin.user = _database_user(authenticated_user) or bulletin.user
    bulletin.save(
        update_fields=[
            "bull_type",
            "update_number",
            "progressive_year",
            "progressive_number",
            "status",
            "is_preview",
            "finalized_at",
            "user",
            "updated_at",
        ]
    )
    return bulletin, True


def ps_qpf_rows(bulletin):
    groups = OrderedDict()
    zones = bulletin.qpf_zones.select_related(
        "non_impulsive_type", "impulsive_type"
    ).prefetch_related("amounts").order_by("map_id", "zone_code")
    for zone in zones:
        amounts = [
            {
                "duration_hours": amount.duration_hours,
                "min_mm": amount.min_mm,
                "max_mm": amount.max_mm,
                "interval": {
                    "day": amount.interval_day,
                    "time_interval": amount.time_interval,
                    "description": amount.interval_description,
                },
            }
            for amount in zone.amounts.all()
        ]
        signature = (
            zone.non_impulsive_code,
            zone.impulsive_code,
            tuple(
                (
                    amount["duration_hours"],
                    amount["min_mm"],
                    amount["max_mm"],
                    amount["interval"]["day"],
                    amount["interval"]["time_interval"],
                )
                for amount in amounts
            ),
        )
        row = groups.setdefault(
            signature,
            {
                "non_impulsive": {
                    "code": zone.non_impulsive_code,
                    "name": zone.non_impulsive_name,
                },
                "impulsive": {
                    "code": zone.impulsive_code,
                    "name": zone.impulsive_name,
                },
                "amounts": amounts,
                "zones": [],
            },
        )
        row["zones"].append(
            {"id": zone.zone_id, "code": zone.zone_code, "name": zone.zone_name}
        )
    return list(groups.values())
