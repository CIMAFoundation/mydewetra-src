# Data model PS/VMN

Questo documento descrive il modello dati iniziale per la produzione dei
bollettini di Previsione Sinottica (PS) e Vigilanza Meteo Nazionale (VMN).

Il modello segue l'approccio concordato:

- Le tabelle `source_*` e `cur_*` rappresentano rispettivamente lo stato
  operativo corrente delle mappe sorgente e intermedie.
- Le tabelle del bollettino salvano una fotografia autonoma dello stato corrente
  al momento della generazione/salvataggio.
- Non viene introdotto un ciclo di produzione separato (`ForecastSession`).
- Un rollover giornaliero sposta atomicamente D1 in D0 e D2 in D1, quindi
  inizializza un nuovo D2 senza conservare uno storico delle lavagne.
- La distinzione tra prima emissione, aggiornamento e preview resta sul
  bollettino.

## Convenzioni principali

### Mappe previsionali

I tre step temporali sono rappresentati dal campo `map_id`:

| Valore | Significato |
| --- | --- |
| `d0` | oggi |
| `d1` | domani |
| `d2` | dopodomani |

### Tipi bollettino

Il campo `bull_type` identifica il tipo di emissione:

| Valore | Significato |
| --- | --- |
| `first` | prima emissione |
| `update` | aggiornamento |

Il campo `is_preview` indica se il bollettino e' una preview oppure una versione
da considerare effettiva.

## Tabelle anagrafiche e definizioni

### `ps_vm_core_region`

Anagrafica delle regioni usata per descrivere e aggregare le zone di vigilanza
meteo transregionali.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `code` | codice univoco della regione |
| `name` | nome della regione |
| `sort_order` | ordinamento applicativo |
| `is_active` | abilita/disabilita la regione |

### `ps_vm_core_zone_vigilanza_meteo`

Anagrafica delle zone geografiche usate dalla vigilanza meteo, comprese le
zone di mare.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `code` | codice univoco della zona |
| `name` | nome della zona |
| `type` | tipo libero della zona (per esempio `zdv` o `sea`); il default e' `zdv` |
| `description` | descrizione libera |
| `keywords` | parole chiave utili per generazione testi e ricerca |
| `is_active` | abilita/disabilita la zona |
| `geometry` | geometria `MultiPolygon` della zona |
| `created_at`, `updated_at` | audit tecnico |

Relazioni:

- relazione molti-a-molti con `ps_vm_core_region` tramite
  `ps_vm_core_zone_vigilanza_meteo_region`.
- relazione uno-a-molti con `ps_vm_core_zone_icon_anchor`.

`type` e' una stringa libera: non usa una tabella di dominio ne' un elenco di
scelte applicativo, quindi eventuali nuovi valori possono essere inseriti
direttamente nei dati.

### `ps_vm_core_zone_vigilanza_meteo_region`

Tabella di relazione tra zone di vigilanza e regioni.

Serve per gestire il fatto che le zone possono essere transregionali e per
aggiungere eventuali descrizioni testuali specifiche della relazione.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `region_id` | FK verso `ps_vm_core_region` |
| `description` | descrizione specifica della relazione zona/regione |
| `sort_order` | ordinamento |

Vincoli:

- una stessa coppia zona/regione puo' comparire una sola volta.

### `ps_vm_core_zone_icon_anchor`

Posizioni disponibili per disegnare le icone PS dentro una zona.

Sostituisce le colonne fisse `ps_icon_pos1`, `ps_icon_pos2`, ecc. con una
struttura piu' flessibile.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `slot` | posizione logica dell'icona, da 1 a 4 |
| `label` | etichetta opzionale |
| `point` | punto geografico dove disegnare l'icona |

Vincoli:

- per ogni zona puo' esistere un solo anchor per ciascuno slot.

### `ps_vm_core_qpf_def`

Definizione dei livelli QPF.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `code` | codice univoco del livello |
| `description` | descrizione breve |
| `level` | livello numerico |
| `text` | testo associato al livello, utile per generazione bollettini |
| `sort_order` | ordinamento |
| `image` | eventuale immagine associata |
| `color` | colore applicativo/cartografico |
| `svg` | eventuale SVG inline |
| `is_active` | abilita/disabilita il livello |
| `created_at`, `updated_at` | audit tecnico |

### `ps_vm_core_ps_phenomenon_type`

Anagrafica dei tipi di fenomeno sinottico.

Esempi: pioggia, temporali, neve, vento, temperatura, nebbia, gelate, mari.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `code` | codice univoco del fenomeno |
| `name` | nome del fenomeno |
| `type` | destinazione delle icone del fenomeno: `zdv`, `sea` o `all` |
| `description` | descrizione libera |
| `sort_order` | ordinamento |
| `is_active` | abilita/disabilita il fenomeno |

### `ps_vm_core_ps_def`

Definizione dei livelli/icone di previsione sinottica.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `phenomenon_type_id` | FK verso `ps_vm_core_ps_phenomenon_type` |
| `code` | codice del livello nel contesto del fenomeno |
| `description` | descrizione breve |
| `level` | livello numerico |
| `text` | testo associato al livello |
| `sort_order` | ordinamento |
| `icon` | eventuale file icona |
| `color` | colore applicativo/cartografico |
| `svg` | eventuale SVG inline |
| `is_active` | abilita/disabilita il livello |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- `phenomenon_type_id + code` deve essere univoco.

#### Endpoint REST associati

I modelli esistenti coprono le anagrafiche richieste senza introdurre nuove
tabelle o migrazioni:

- `GET /api/qpf_levels/` legge i record attivi di `ps_vm_core_qpf_def`, ordinati
  per l'uso nelle tendine dei livelli di severita';
- `GET /api/ps_icons/` legge i fenomeni attivi di
  `ps_vm_core_ps_phenomenon_type` e annida per ciascuno i record attivi di
  `ps_vm_core_ps_def`.

Il secondo endpoint esclude i fenomeni senza icone attive. Entrambi espongono
anche il dettaglio tramite `GET /api/<anagrafica>/<id>/` e richiedono
autenticazione.

### `ps_vm_core_map_layer`

Layer cartografici logici usati dall'applicazione.

Unifica i concetti di base map, background layer e ancillary layer. Il layer
logico non contiene geometrie: per i base layer descrive solo la configurazione
del provider client, mentre per background e ancillary raggruppa le feature
geografiche salvate in `ps_vm_core_map_layer_feature`.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `code` | codice univoco del layer |
| `name` | nome del layer |
| `description` | descrizione |
| `layer_type` | `base`, `background`, `ancillary` |
| `style` | configurazione JSON di stile |
| `sort_order` | ordinamento |
| `is_active` | abilita/disabilita il layer |
| `created_at`, `updated_at` | audit tecnico |

### `ps_vm_core_map_layer_feature`

Feature geografiche appartenenti a un layer cartografico logico.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `layer_id` | FK verso `ps_vm_core_map_layer` |
| `code` | codice della feature nel contesto del layer |
| `name` | nome della feature |
| `description` | descrizione |
| `properties` | attributi JSON liberi della feature |
| `sort_order` | ordinamento |
| `is_active` | abilita/disabilita la feature |
| `geometry` | geometria della feature |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- `layer_id + code` deve essere univoco.

## Settings

### `ps_vm_core_app_settings`

Configurazione generale dell'applicazione.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `title` | titolo applicazione |
| `map_title` | titolo area mappa |
| `text_title` | titolo area testi |
| `base_map_id` | FK opzionale verso `ps_vm_core_map_layer` di tipo `base` |
| `background_layer_id` | FK opzionale verso `ps_vm_core_map_layer` di tipo `background` |
| `config` | JSON generico per configurazioni future |
| `is_active` | configurazione attiva/non attiva |
| `created_at`, `updated_at` | audit tecnico |

Relazioni:

- molti-a-molti con `ps_vm_core_map_layer` per gli ancillary layer tramite
  `ancillary_layers`.

## Endpoint cartografici di base

Gli endpoint leggono la prima configurazione attiva in `ps_vm_core_app_settings`.
Se il relativo layer non e' configurato, usano come fallback i layer attivi dello
stesso tipo.

### `GET /api/background_layer/`

Restituisce una `FeatureCollection` GeoJSON con le feature attive del background
layer configurato.

### `GET /api/ancillary_layer/`

Restituisce una lista di layer ancillary. Ogni elemento contiene:

| Campo | Descrizione |
| --- | --- |
| `layer` | metadati JSON del layer logico `ps_vm_core_map_layer` |
| `geojson` | `FeatureCollection` GeoJSON con le feature attive del layer |

Forma della risposta:

```json
[
  {
    "layer": {
      "id": 1,
      "code": "italy_provinces",
      "name": "Province italiane",
      "layer_type": "ancillary",
      "style": {}
    },
    "geojson": {
      "type": "FeatureCollection",
      "features": []
    }
  }
]
```

### `GET /api/base_map/`

Restituisce il JSON del base map configurato. Non restituisce GeoJSON, perche'
il base map e' una configurazione del provider client e non ha feature
geografiche.

Esempio:

```json
{
  "id": 1,
  "code": "google_maps_sat",
  "name": "Google Satellite",
  "layer_type": "base",
  "style": {
    "provider": "google",
    "mapType": "satellite"
  }
}
```

### `ps_vm_core_bulletin_settings`

Configurazioni specifiche dei bollettini, globali o per utente.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `bulletin_type` | `ps` oppure `vmn` |
| `user_id` | utente opzionale; se nullo la configurazione e' globale |
| `title` | titolo default |
| `default_titles` | JSON con titoli/sezioni predefinite |
| `default_texts` | JSON con testi default |
| `layout_config` | JSON con impostazioni di layout |
| `is_active` | configurazione attiva/non attiva |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- una configurazione globale per tipo bollettino.
- una configurazione per coppia tipo bollettino/utente.

Alla creazione di una bozza, `default_titles.subtitle` inizializza il
sottotitolo. `default_texts` può inizializzare `notes`, `preliminary_notes` e
`signature` per entrambi i prodotti, oltre a `current_situation` per il solo
bollettino PS. Le chiavi assenti producono una stringa vuota.

## Stato corrente delle mappe sorgente

### Cataloghi delle precipitazioni

`ps_vm_core_non_impulsive_precipitation_type` e
`ps_vm_core_impulsive_precipitation_type` contengono i valori selezionabili dal
client. Entrambi espongono codice stabile, etichetta, severita', ordinamento e
flag di attivazione.

### `ps_vm_core_daily_precipitation_interval`

Anagrafica degli intervalli giornalieri selezionabili nelle QPF di tutte le
mappe sorgente (`d0`, `d1`, `d2`).

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo usato dal payload di salvataggio |
| `day` | identificativo mappa `d0`, `d1` oppure `d2` |
| `time_interval` | fascia oraria (`00:00 - 06:00`, ecc.) |
| `description` | etichetta completa mostrabile dal client |
| `sort_order` | ordine della tendina |
| `is_active` | abilita/disabilita la voce |
| `created_at`, `updated_at` | audit tecnico |

La coppia `day + time_interval` è univoca. Le migration inizializzano dieci
voci: `d0` per `12-18` e `18-24`; `d1` e `d2` per `00-06`, `06-12`, `12-18`
e `18-24`. `GET /api/daily_precipitation_intervals/` espone `id`, `day`,
`time_interval` e `description` delle sole voci attive.

### `ps_vm_core_source_qpf`

Contiene una riga completa per ogni coppia `map_id + zone_id`, limitata alle
zone di vigilanza `zdv`. La riga seleziona una classificazione impulsiva e una
non impulsiva e registra autore e timestamp dell'ultimo aggiornamento.

### `ps_vm_core_source_qpf_amount`

Contiene zero o piu' definizioni `duration_hours`, `min_mm`, `max_mm` associate
alla QPF sorgente. Ogni riga può selezionare tramite
`daily_precipitation_interval_id` una voce di
`ps_vm_core_daily_precipitation_interval`.

Le durate ammesse sono 3, 6, 12, 18 e 24 ore e il minimo non può superare il
massimo. Il vincolo univoco comprende `source_qpf_id + duration_hours +
daily_precipitation_interval_id`: una ZVM può quindi salvare definizioni di
durata diversa e la stessa durata può essere ripetuta su intervalli giornalieri
diversi. Per esempio sono rappresentabili contemporaneamente `5-10 mm / 3h`
e `25-35 mm / 6h`; quest'ultima può inoltre comparire su tre intervalli.

La FK è nullable per compatibilità con righe pregresse e con quantità non
associate a uno specifico intervallo giornaliero.

Il reset puntuale o completo della QPF sorgente conserva le righe della zona e
assegna lo stato predefinito: classificazioni impulsiva e non impulsiva
`absent`, senza quantità associate. L'assenza di una quantità indica che la
durata non è stata selezionata, mentre `0-0 mm` resta un valore esplicito.
Come per la QPF intermedia, il reset e' idempotente e crea le assegnazioni
mancanti.

### `ps_vm_core_qpf_threshold_24h`

Anagrafica delle soglie QPF sulle 24 ore per le sole ZVM (`type=zdv`). Ogni
zona può avere una sola configurazione.

| Campo | Descrizione |
| --- | --- |
| `zone_id` | relazione uno-a-uno con la ZVM |
| `weak_mm` | soglia inclusiva di ingresso nel livello `deboli` |
| `moderate_mm` | soglia inclusiva di ingresso nel livello `moderate` |
| `elevated_mm` | soglia inclusiva di ingresso nel livello `elevate` |
| `very_elevated_mm` | limite superiore del livello `elevate`; oltre la soglia si entra in `molto_elevate` |
| `created_at`, `updated_at` | audit tecnico |

I vincoli impongono
`0 < weak_mm < moderate_mm < elevated_mm < very_elevated_mm`. I valori sono
uniformi per tutte le ZVM: `5`, `20`, `60` e `100 mm/24h`; l'ultima soglia
usa eccezionalmente il confronto stretto `>`, mentre le altre sono inclusive.
Non esistono soglie per durate
diverse dalle 24 ore: i valori sorgente a 3, 6, 12 o 18 ore vengono ragguagliati
linearmente durante la promozione.

### `ps_vm_core_source_ps`

Contiene le icone sorgente di piogge e temporali. Riusa cataloghi e anchor PS,
ma mantiene uno stato distinto dalla mappa intermedia. E' ammessa una sola
icona per `map_id + zone_id + icon_slot`.

## Stato corrente delle mappe intermedie

### `ps_vm_core_cur_qpf`

Stato corrente QPF delle zone per le tre mappe `d0`, `d1`, `d2`.

Questa tabella e' una lavagna operativa: puo' essere aggiornata e sovrascritta.
Non rappresenta uno storico.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `map_id` | `d0`, `d1`, `d2` |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `qpf_level_id` | FK verso `ps_vm_core_qpf_def` |
| `custom_description` | descrizione specifica dell'assegnazione QPF, opzionale |
| `updated_by_id` | utente che ha aggiornato il valore |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- un solo valore QPF corrente per coppia `map_id + zone_id`.

### `ps_vm_core_cur_ps`

Stato corrente delle icone di Previsione Sinottica sulle zone.

Anche questa tabella e' una lavagna operativa e non uno storico.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `map_id` | `d0`, `d1`, `d2` |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `phenomenon_type_id` | FK verso `ps_vm_core_ps_phenomenon_type` |
| `ps_level_id` | FK verso `ps_vm_core_ps_def` |
| `icon_slot` | posizione logica dell'icona nella zona, da 1 a 4 |
| `custom_description` | descrizione specifica dell'assegnazione PS, opzionale |
| `updated_by_id` | utente che ha aggiornato il valore |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- una sola icona corrente per `map_id + zone_id + icon_slot`.

Nota applicativa:

- Il modello non impedisce a livello database che `ps_level_id` appartenga a un
  fenomeno diverso da `phenomenon_type_id`. Questo controllo va gestito in
  serializer/service layer oppure con una validazione custom.

## Endpoint dello stato corrente

Gli endpoint dello stato corrente richiedono autenticazione e restituiscono una
risposta sparsa: sono presenti soltanto le assegnazioni esistenti nelle tabelle
`cur_*`. L'assenza di una zona o di un'icona indica quindi che non esiste
un'assegnazione corrente.

Senza parametri, entrambi gli endpoint restituiscono sempre i contenitori delle
mappe `d0`, `d1` e `d2`, inclusi quelli vuoti. Il parametro opzionale `map_id`
permette di richiedere una sola mappa:

```text
?map_id=d0
?map_id=d1
?map_id=d2
```

La risposta include `operational_date`, calcolata nel fuso orario applicativo,
e la `valid_date` di ciascuna mappa.

### `GET /api/current_qpf/`

Restituisce le assegnazioni QPF correnti, raggruppate per mappa. Ciascuna
assegnazione contiene zona, livello QPF, descrizione personalizzata e dati di
audit.

```json
{
  "operational_date": "2026-07-22",
  "maps": [
    {
      "map_id": "d0",
      "valid_date": "2026-07-22",
      "zones": []
    },
    {
      "map_id": "d1",
      "valid_date": "2026-07-23",
      "zones": []
    },
    {
      "map_id": "d2",
      "valid_date": "2026-07-24",
      "zones": []
    }
  ]
}
```

### `GET /api/current_ps/`

Restituisce le icone PS correnti, raggruppate per mappa. Ciascuna icona contiene
zona, fenomeno, livello PS, slot, descrizione personalizzata e, quando definito,
il relativo anchor geografico.

### `POST /api/save_current_qpf/`

Sostituisce atomicamente lo stato QPF di una singola mappa. Il payload contiene
`map_id` e l'array completo `zones`; le assegnazioni precedenti non presenti
nell'array vengono eliminate. Un array vuoto cancella lo stato QPF del giorno.

### `POST /api/save_current_ps/`

Sostituisce atomicamente lo stato delle icone PS di una singola mappa. Il
payload contiene `map_id` e l'array completo `icons`; le icone precedenti non
presenti nell'array vengono eliminate. La validazione controlla che ogni slot
di una zona sia occupato al massimo una volta e che ciascun livello PS
appartenga al fenomeno indicato.

Gli endpoint `PUT` e `DELETE` sotto `current_qpf/{map_id}/{zone_id}` e
`current_ps/{map_id}/{zone_id}/{icon_slot}` modificano invece una sola chiave e
seguono la politica `last write wins`.

L'endpoint `DELETE /api/current_qpf/{map_id}/` esegue in modo atomico il reset
di tutte le zone VM della mappa: assegna il livello
`assenti_o_deboli_non_rilevanti` (`level=0`) e azzera le descrizioni
personalizzate. `DELETE /api/current_ps/{map_id}/` elimina invece tutte le
icone PS della sola mappa indicata. Entrambe le operazioni sono idempotenti e
notificano ai client lo snapshot risultante.

La stessa distinzione vale per gli endpoint puntuali: il `DELETE` QPF esegue un
upsert del valore di default sulla zona, mentre il `DELETE` PS rimuove
effettivamente l'icona dallo slot.

### Promozione sorgente-intermedia

`POST /api/promote_source_maps/` ricostruisce in una singola transazione
`cur_qpf` e `cur_ps` di `d0`, `d1` e `d2`. Le sorgenti sono autorevoli:
ogni chiamata elimina integralmente lo stato intermedio precedente, incluse le
modifiche manuali, e lo ripopola dalle tabelle `source_*`.

Per QPF viene considerato il `max_mm` di ogni definizione/intervallo e si calcola
`max_mm * 24 / duration_hours`; la severità risultante è confrontata con le
soglie 24h della ZVM e si conserva il livello massimo tra tutte le durate e
tutti gli intervalli giornalieri. Le
prime tre soglie sono inclusive, mentre l'ultima usa `>`; il calcolo produce
automaticamente i livelli da 0 a 4,
compreso `molto_elevate` per valori equivalenti superiori a `100 mm/24h`. Le
classificazioni impulsiva e
non impulsiva e `min_mm` non partecipano alla determinazione del colore.

La PS viene copiata direttamente, conservando zona, fenomeno, livello, slot e
descrizione. L'assenza delle soglie per una ZVM presente nelle sorgenti QPF
annulla l'intera operazione con una risposta `400 Bad Request`.

Il contratto completo, con payload e risposte di esempio, e' descritto in
[`docs/api.md`](api.md).

## Bollettino Previsione Sinottica

Le testate PS e VMN espongono un ciclo di vita `draft/finalized`, la data
operativa, la data di finalizzazione e il progressivo annuale. Per ciascun
prodotto può esistere una sola bozza per data; le emissioni finalizzate sono
immutabili. `ps_vm_core_bulletin_sequence` assegna progressivi indipendenti per
prodotto e anno.

### `ps_vm_core_ps_bul_text`

Testata e testi del bollettino di Previsione Sinottica.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo bollettino |
| `day_string` | stringa giorno usata nel bollettino |
| `user_id` | utente che ha prodotto/salvato il bollettino |
| `bull_type` | `first` oppure `update` |
| `update_number` | numero aggiornamento |
| `is_preview` | indica se e' una preview |
| `title` | titolo bollettino |
| `subtitle` | sottotitolo opzionale (`text`, senza limite di 255 caratteri) |
| `preliminary_notes` | note preliminari opzionali |
| `current_situation` | situazione corrente opzionale |
| `signature` | firma opzionale |
| `generated_sections` | JSON con testi generati automaticamente |
| `text_sections` | JSON con testi finali editabili |
| `qpf_row_texts` | JSON con il testo editoriale delle zone, indicizzato per `row_id` QPF |
| `notes` | note interne/opzionali |
| `ts` | timestamp di creazione emissione |
| `created_at`, `updated_at` | audit tecnico |

`generated_sections` e `text_sections` permettono di conservare sia il testo
generato dalla mappa sia il testo modificato manualmente dal previsore.
`qpf_row_texts` ha forma `{ "<row_id>": "<zones_text>" }` e conserva in modo
indipendente il testo visualizzato nella colonna zone di ogni riga QPF. Il
valore iniziale elenca le regioni delle zone raggruppate, una per riga, seguite
dai rispettivi codici separati da `-` (per esempio `LAZIO 37-40(rilievi)-42`).
Una zona condivisa compare sotto ciascuna regione; l'eventuale descrizione
della relazione zona/regione compare tra parentesi dopo il codice. Il testo
salvato è libero e non è vincolato alla composizione dello snapshot QPF.

### `ps_vm_core_ps_bul_icon`

Snapshot delle icone PS associate a un bollettino PS.

Questa tabella viene popolata copiando lo stato corrente da `ps_vm_core_cur_ps` quando si
salva/genera il bollettino.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `bulletin_id` | FK verso `ps_vm_core_ps_bul_text` |
| `map_id` | `d0`, `d1`, `d2` |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `phenomenon_type_id` | FK verso `ps_vm_core_ps_phenomenon_type` |
| `ps_level_id` | FK verso `ps_vm_core_ps_def` |
| `icon_slot` | slot icona usato nella zona |
| `zone_code`, `zone_name` | copia dei dati zona al momento del salvataggio |
| `phenomenon_code` | copia del codice fenomeno |
| `ps_code`, `ps_text` | copia dei dati livello PS |
| `custom_description` | copia della descrizione specifica impostata in `ps_vm_core_cur_ps` |
| `icon`, `color`, `svg` | copia dei riferimenti/stili icona |

I campi duplicati sono intenzionali: servono a mantenere coerente il bollettino
anche se in futuro cambiano anagrafiche, testi o icone.

## Bollettino Vigilanza Meteo Nazionale

### `ps_vm_core_vm_bul_text`

Testata e testi del bollettino di Vigilanza Meteo Nazionale.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo bollettino |
| `day_string` | stringa giorno usata nel bollettino |
| `user_id` | utente che ha prodotto/salvato il bollettino |
| `bull_type` | `first` oppure `update` |
| `update_number` | numero aggiornamento |
| `is_preview` | indica se e' una preview |
| `title` | titolo bollettino |
| `subtitle` | sottotitolo opzionale (`text`, senza limite di 255 caratteri) |
| `preliminary_notes` | note preliminari opzionali |
| `signature` | firma opzionale |
| `generated_sections` | JSON con testi generati automaticamente |
| `text_sections` | JSON con testi finali editabili |
| `notes` | note interne/opzionali |
| `ts` | timestamp di creazione emissione |
| `created_at`, `updated_at` | audit tecnico |

### `ps_vm_core_vm_bul_zone_vigilanza`

Snapshot QPF delle zone associato a un bollettino VMN.

Questa tabella viene popolata copiando lo stato corrente da `ps_vm_core_cur_qpf` quando si
salva/genera il bollettino.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `bulletin_id` | FK verso `ps_vm_core_vm_bul_text` |
| `map_id` | `d0`, `d1`, `d2` |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `qpf_level_id` | FK verso `ps_vm_core_qpf_def` |
| `zone_code`, `zone_name` | copia dei dati zona al momento del salvataggio |
| `qpf_code`, `qpf_text` | copia dei dati QPF |
| `custom_description` | copia della descrizione specifica impostata in `ps_vm_core_cur_qpf` |
| `color`, `svg` | copia dello stile QPF |

Vincoli:

- una sola riga per `bulletin_id + map_id + zone_id`.

### Snapshot aggiuntivi delle preview

- `ps_vm_core_ps_bul_qpf` e `ps_vm_core_ps_bul_qpf_amount` congelano le QPF
  sorgenti d0/d1 usate dalla tabella conclusiva PS;
- le righe esposte dall'API non corrispondono a una singola tabella: sono
  raggruppamenti delle righe `ps_vm_core_ps_bul_qpf` con firma meteorologica
  identica. Il backend assegna a ogni gruppo un `row_id`, usato come chiave in
  `ps_vm_core_ps_bul_text.qpf_row_texts`;
- il refresh elimina e ricrea gli snapshot QPF PS, rigenera i `row_id` e
  sostituisce integralmente `qpf_row_texts` con la concatenazione aggiornata dei
  codici zona; le precedenti modifiche manuali non vengono conservate;
- `ps_vm_core_vm_bul_icon` congela le icone originali e quelle rimappate per la
  sola resa cartografica VMN;
- gli snapshot cartografici conservano geometrie ZVM e anchor, oltre ai dati
  duplicati di catalogo, per non dipendere da modifiche anagrafiche successive;
- `ps_vm_core_bulletin_settings.qpf_regions` definisce le regioni ammesse nella
  tabella QPF PS ed è gestibile dal Django Admin.

## Archivio PDF

### `ps_vm_core_bulletin_pdf_archive`

Archivio dei PDF prodotti per PS e VMN.

E' una tabella unica per entrambi i prodotti.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `bulletin_type` | `ps` oppure `vmn` |
| `ps_bulletin_id` | FK opzionale verso `ps_vm_core_ps_bul_text` |
| `vm_bulletin_id` | FK opzionale verso `ps_vm_core_vm_bul_text` |
| `file` | riferimento legacy opzionale; non usato per i nuovi PDF |
| `filename` | nome file originale/logico |
| `content_type` | content type, default `application/pdf` |
| `size` | dimensione file in byte |
| `sha256` | hash del PDF |
| `is_signed` | indica se il PDF e' firmato digitalmente |
| `s3_bucket`, `s3_key` | posizione autorevole del PDF nel bucket S3 |
| `s3_etag`, `s3_size`, `s3_content_type` | metadati dell'oggetto S3 |
| `s3_last_uploaded_at` | istante dell'ultimo upload S3 riuscito |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- ogni record deve puntare a un solo bollettino: PS oppure VMN, non entrambi.

## Flusso operativo previsto

1. Il client salva la mappa sorgente nelle tabelle `source_*` passando alla
   vista intermedia.
2. Il client chiama `POST /api/promote_source_maps/`, che sostituisce e
   precompila `cur_qpf` e `cur_ps`; l'operatore completa quindi lo stato
   intermedio.
3. Passando alla vista bollettino, il client salva lo stato intermedio tramite
   gli endpoint `save_current_*`.
4. L'applicazione genera i testi a partire dallo stato corrente.
5. Il previsore puo' modificare manualmente i testi generati.
6. Al salvataggio del bollettino:
   - viene creata una riga in `ps_vm_core_ps_bul_text` o `ps_vm_core_vm_bul_text`;
   - viene copiato lo stato corrente in `ps_vm_core_ps_bul_icon` o
     `ps_vm_core_vm_bul_zone_vigilanza`;
   - eventuali descrizioni specifiche delle assegnazioni correnti vengono
     copiate negli snapshot del bollettino;
   - i testi finali e i testi zona delle righe QPF PS vengono salvati nei campi
     JSON del bollettino.
7. Alla produzione del PDF viene creata una riga in `ps_vm_core_bulletin_pdf_archive`.

## Rollover giornaliero

Il comando `rollover_current_maps` opera in una singola transazione sulle mappe
sorgente e intermedie: elimina D0, sposta D1 in D0, sposta D2 in D1 e crea il
nuovo D2. Le mappe sorgente e le icone intermedie ripartono vuote; la QPF
intermedia D2 viene inizializzata al livello predefinito per tutte le zone
attive. `ps_vm_core_map_operational_state` conserva esclusivamente la data
dell'ultimo rollover per rendere il comando idempotente e gestire eventuali
giorni saltati; non rappresenta una sessione o uno storico.

Le quantità sorgenti QPF vengono ricollegate all'intervallo attivo con la stessa
fascia oraria e `day` uguale al nuovo `map_id`, senza modificare durata, minimo
o massimo. Nel passaggio D1 → D0 vengono eliminate le quantità delle fasce
`00:00 - 06:00` e `06:00 - 12:00`, non previste per D0. La corrispondenza usa
`time_interval`, non `sort_order` o ID fissi. Se manca un intervallo attivo
di destinazione richiesto, l'intero rollover viene annullato. Le quantità
legacy con intervallo nullo mantengono tale valore.

`CurQpf` conserva un livello per zona, senza quantità o intervalli temporali.
Nel passaggio D1 → D0 viene ricostruita dalle quantità sorgenti del nuovo D0
nelle sole fasce `12:00 - 18:00` e `18:00 - 24:00`, usando lo stesso algoritmo
della promozione (ragguaglio a 24h e massima severità tra tutte le durate).
Il ricalcolo sostituisce i livelli manuali, azzera le descrizioni intermedie
e rimuove l'attribuzione all'operatore precedente. Le zone senza quantità
valide, comprese quelle presenti solo nell'intermedia, ricevono il livello
`assenti_o_deboli_non_rilevanti`. Le quantità legacy con intervallo nullo
sono conservate nelle sorgenti ma escluse dal ricalcolo di D0. Se mancano
le soglie per una zona con quantità valide o i livelli attivi necessari,
l'intero rollover viene annullato. Nel passaggio D2 → D1 vengono conservati
livello, descrizione e autore intermedi, inclusi gli override manuali.
La regola e' conservare la valutazione dell'operatore finche' tutte le fasce
del periodo previsto restano valide: D2 → D1 mantiene la stessa data effettiva
e tutte e quattro le fasce; D1 → D0 restringe il periodo alle due fasce
pomeridiane/serali e richiede quindi il ricalcolo. Il livello calcolato e
l'override manuale non sono memorizzati in campi separati.
Il recupero di due giorni applica queste regole a ciascun passaggio: le QPF
originariamente in D2 vengono quindi ricalcolate quando raggiungono D0.

Le icone `SourcePs` e `CurPs` hanno slot grafici, senza un riferimento a
`DailyPrecipitationInterval`: il rollover ne aggiorna il giorno conservando gli
slot. I bollettini mantengono i propri snapshot; le nuove bozze PS copiano le
quantità sorgenti con gli intervalli aggiornati e i relativi min/max.

## Note per sviluppi successivi

- La validazione di coerenza tra `ps_vm_core_cur_ps.phenomenon_type` e
  `ps_vm_core_cur_ps.ps_level.phenomenon_type` va implementata nei serializer o nei service.
