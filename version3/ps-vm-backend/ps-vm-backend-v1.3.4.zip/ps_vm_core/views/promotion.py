from django.db import transaction
from django.utils import timezone
from rest_framework import permissions, serializers, status
from rest_framework.response import Response
from rest_framework.views import APIView

from ps_vm_core.models import (
    CurPs,
    CurQpf,
    MapId,
    QpfThreshold24h,
    SourcePs,
    SourceQpf,
)
from ps_vm_core.notify import NotificationType
from ps_vm_core.operational import lock_map_operational_state
from ps_vm_core.qpf_conversion import qpf_amounts_severity, qpf_levels
from ps_vm_core.views.current_state import (
    MAP_DAY_OFFSETS,
    _database_user,
    _notify_after_commit,
    _ps_snapshot,
    _qpf_snapshot,
)


class PromoteSourceMapsResView(APIView):
    """Ricostruisce integralmente le mappe intermedie dalle mappe sorgente."""

    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        map_ids = list(MAP_DAY_OFFSETS)
        updated_by = _database_user(request.user)

        with transaction.atomic():
            lock_map_operational_state()
            levels = qpf_levels()
            thresholds_by_zone = {
                item.zone_id: item
                for item in QpfThreshold24h.objects.select_related("zone")
            }
            source_qpf = list(
                SourceQpf.objects.select_related("zone")
                .prefetch_related("amounts")
                .filter(map_id__in=map_ids)
                .order_by("map_id", "zone__code")
            )
            missing_thresholds = sorted(
                {
                    item.zone.code
                    for item in source_qpf
                    if item.zone_id not in thresholds_by_zone
                }
            )
            if missing_thresholds:
                raise serializers.ValidationError(
                    {
                        "thresholds": [
                            "Soglie QPF 24h non configurate per le ZVM: "
                            + ", ".join(missing_thresholds)
                            + "."
                        ]
                    }
                )

            source_ps = list(
                SourcePs.objects.select_related(
                    "zone",
                    "phenomenon_type",
                    "ps_level",
                )
                .filter(map_id__in=map_ids)
                .order_by("map_id", "zone__code", "icon_slot")
            )
            deleted_qpf = {
                map_id: CurQpf.objects.filter(map_id=map_id).count()
                for map_id in map_ids
            }
            deleted_ps = {
                map_id: CurPs.objects.filter(map_id=map_id).count()
                for map_id in map_ids
            }

            CurQpf.objects.filter(map_id__in=map_ids).delete()
            CurPs.objects.filter(map_id__in=map_ids).delete()
            CurQpf.objects.bulk_create(
                [
                    CurQpf(
                        map_id=item.map_id,
                        zone=item.zone,
                        qpf_level=levels[
                            qpf_amounts_severity(
                                item.amounts.all(),
                                thresholds_by_zone[item.zone_id],
                            )
                        ],
                        custom_description="",
                        updated_by=updated_by,
                    )
                    for item in source_qpf
                ]
            )
            CurPs.objects.bulk_create(
                [
                    CurPs(
                        map_id=item.map_id,
                        zone=item.zone,
                        phenomenon_type=item.phenomenon_type,
                        ps_level=item.ps_level,
                        icon_slot=item.icon_slot,
                        custom_description=item.custom_description,
                        updated_by=updated_by,
                    )
                    for item in source_ps
                ]
            )

            maps = []
            for map_id in map_ids:
                qpf_data = _qpf_snapshot(
                    request,
                    map_id,
                    operation="promote",
                    deleted_count=deleted_qpf[map_id],
                )
                ps_data = _ps_snapshot(
                    request,
                    map_id,
                    operation="promote",
                    deleted_count=deleted_ps[map_id],
                )
                maps.append(
                    {
                        "map_id": map_id,
                        "qpf": qpf_data,
                        "ps": ps_data,
                    }
                )
                _notify_after_commit(
                    request,
                    NotificationType.UPDATE_CURRENT_QPF,
                    qpf_data,
                )
                _notify_after_commit(
                    request,
                    NotificationType.UPDATE_CURRENT_PS,
                    ps_data,
                )

        return Response(
            {
                "operation": "promote",
                "operational_date": timezone.localdate(),
                "maps": maps,
            },
            status=status.HTTP_200_OK,
        )
