from datetime import date

from django.core.exceptions import ImproperlyConfigured
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.db.models import Prefetch
from django.utils import timezone

from ps_vm_core.models import (
    CurPs,
    CurQpf,
    DailyPrecipitationInterval,
    MapId,
    QpfLevel,
    QpfThreshold24h,
    SourcePs,
    SourceQpf,
    SourceQpfAmount,
    ZoneVigilanzaMeteo,
)
from ps_vm_core.operational import lock_map_operational_state
from ps_vm_core.qpf_conversion import qpf_amounts_severity, qpf_levels


DEFAULT_QPF_LEVEL_CODE = "assenti_o_deboli_non_rilevanti"
ROLLOVER_MODELS = (SourceQpf, SourcePs, CurQpf, CurPs)


class Command(BaseCommand):
    help = (
        "Esegue il rollover atomico delle mappe sorgente e intermedie: "
        "D1 diventa D0, D2 diventa D1 e D2 viene inizializzato."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--date",
            dest="target_date",
            help="Data operativa di destinazione in formato YYYY-MM-DD.",
        )

    def handle(self, *args, **options):
        target_date = self._target_date(options.get("target_date"))

        with transaction.atomic():
            state = lock_map_operational_state()
            last_date = state.last_rollover_date
            if last_date and target_date < last_date:
                raise CommandError(
                    f"La data {target_date} precede l'ultimo rollover {last_date}."
                )

            elapsed_days = (target_date - last_date).days if last_date else 1
            if elapsed_days == 0:
                self.stdout.write(
                    self.style.WARNING(
                        f"Rollover gia' eseguito per la data {target_date}."
                    )
                )
                return

            if elapsed_days >= 3:
                self._clear_all_maps()
            else:
                for _ in range(elapsed_days):
                    self._roll_one_day()

            self._initialize_intermediate_d2()
            state.last_rollover_date = target_date
            state.save(update_fields=["last_rollover_date", "updated_at"])

        self.stdout.write(
            self.style.SUCCESS(
                f"Rollover completato per {target_date} ({elapsed_days} giorno/i)."
            )
        )

    def _target_date(self, raw_date):
        if not raw_date:
            return timezone.localdate()
        try:
            return date.fromisoformat(raw_date)
        except ValueError as exc:
            raise CommandError("Formato --date non valido: usare YYYY-MM-DD.") from exc

    def _roll_one_day(self):
        now = timezone.now()
        self._roll_qpf_intervals(now)
        for model in ROLLOVER_MODELS:
            model.objects.filter(map_id=MapId.TODAY).delete()
            model.objects.filter(map_id=MapId.TOMORROW).update(
                map_id=MapId.TODAY,
                updated_at=now,
            )
            model.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).update(
                map_id=MapId.TOMORROW,
                updated_at=now,
            )
        self._recalculate_intermediate_d0()

    def _recalculate_intermediate_d0(self):
        sources = list(
            SourceQpf.objects.filter(map_id=MapId.TODAY)
            .select_related("zone")
            .prefetch_related(
                Prefetch(
                    "amounts",
                    queryset=SourceQpfAmount.objects.filter(
                        daily_precipitation_interval__day=MapId.TODAY,
                        daily_precipitation_interval__is_active=True,
                        daily_precipitation_interval__time_interval__in=(
                            "12:00 - 18:00", "18:00 - 24:00"
                        ),
                    ),
                )
            )
        )
        # Manual-only zones also lose their override when they become D0.
        zone_ids = set(
            CurQpf.objects.filter(map_id=MapId.TODAY).values_list("zone_id", flat=True)
        ) | {source.zone_id for source in sources}
        if not zone_ids:
            return

        try:
            levels = qpf_levels()
        except ImproperlyConfigured as exc:
            raise CommandError(str(exc)) from exc
        thresholds = {
            item.zone_id: item
            for item in QpfThreshold24h.objects.filter(zone_id__in=zone_ids)
        }
        missing = sorted(
            source.zone.code
            for source in sources
            if source.amounts.all() and source.zone_id not in thresholds
        )
        if missing:
            raise CommandError(
                "Soglie QPF 24h non configurate per il rollover delle ZVM: "
                + ", ".join(missing) + "."
            )

        levels_by_zone = {zone_id: levels[0] for zone_id in zone_ids}
        for source in sources:
            amounts = source.amounts.all()
            if amounts:
                levels_by_zone[source.zone_id] = levels[
                    qpf_amounts_severity(amounts, thresholds[source.zone_id])
                ]
        CurQpf.objects.filter(map_id=MapId.TODAY).delete()
        CurQpf.objects.bulk_create(
            [
                CurQpf(map_id=MapId.TODAY, zone_id=zone_id, qpf_level=level)
                for zone_id, level in levels_by_zone.items()
            ]
        )

    def _roll_qpf_intervals(self, now):
        intervals = {
            (item.day, item.time_interval): item.pk
            for item in DailyPrecipitationInterval.objects.filter(is_active=True)
        }
        for source_day, target_day in (
            (MapId.TOMORROW, MapId.TODAY),
            (MapId.DAY_AFTER_TOMORROW, MapId.TOMORROW),
        ):
            amounts = SourceQpfAmount.objects.filter(source_qpf__map_id=source_day)
            if target_day == MapId.TODAY:
                amounts.filter(
                    daily_precipitation_interval__time_interval__in=(
                        "00:00 - 06:00",
                        "06:00 - 12:00",
                    )
                ).delete()

            # Match by clock time, never by sort_order (D0 has only two intervals).
            # Collect groups before updating so each original FK is shifted once.
            groups = list(
                amounts.filter(daily_precipitation_interval__isnull=False)
                .order_by()
                .values_list(
                    "daily_precipitation_interval_id",
                    "daily_precipitation_interval__time_interval",
                )
                .distinct()
            )
            for interval_id, time_interval in groups:
                target_id = intervals.get((target_day, time_interval))
                if target_id is None:
                    raise CommandError(
                        "Intervallo QPF di destinazione attivo non configurato: "
                        f"{target_day} {time_interval}."
                    )
                amounts.filter(daily_precipitation_interval_id=interval_id).update(
                    daily_precipitation_interval_id=target_id,
                    updated_at=now,
                )

    def _clear_all_maps(self):
        for model in ROLLOVER_MODELS:
            model.objects.all().delete()

    def _initialize_intermediate_d2(self):
        CurQpf.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).delete()
        CurPs.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).delete()
        SourceQpf.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).delete()
        SourcePs.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).delete()

        try:
            default_level = QpfLevel.objects.get(
                code=DEFAULT_QPF_LEVEL_CODE,
                level=0,
                is_active=True,
            )
        except QpfLevel.DoesNotExist as exc:
            raise CommandError(
                "Livello QPF di default attivo non configurato: "
                f"{DEFAULT_QPF_LEVEL_CODE} (level=0)."
            ) from exc

        CurQpf.objects.bulk_create(
            [
                CurQpf(
                    map_id=MapId.DAY_AFTER_TOMORROW,
                    zone=zone,
                    qpf_level=default_level,
                )
                for zone in ZoneVigilanzaMeteo.objects.filter(is_active=True)
            ]
        )
