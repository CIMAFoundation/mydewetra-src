import os
from datetime import timedelta
from io import StringIO
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.contrib.gis.geos import GEOSGeometry, Point
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import TestCase
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APIClient, APITestCase

from ps_vm_core.models import (
    CurPs,
    CurQpf,
    DailyPrecipitationInterval,
    ImpulsivePrecipitationType,
    MapId,
    MapOperationalState,
    NonImpulsivePrecipitationType,
    PhenomenonType,
    PsLevel,
    QpfLevel,
    QpfThreshold24h,
    SourcePs,
    SourceQpf,
    SourceQpfAmount,
    ZoneIconAnchor,
    ZoneVigilanzaMeteo,
)


def create_zone(code, *, zone_type="zdv"):
    return ZoneVigilanzaMeteo.objects.create(
        code=code,
        name=f"Zona {code}",
        type=zone_type,
        geometry=GEOSGeometry(
            "MULTIPOLYGON(((0 0, 0 1, 1 1, 1 0, 0 0)))",
            srid=4326,
        ),
    )


class SourceStateApiTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username="source-user")
        self.client.force_authenticate(user=self.user)
        self.zone = create_zone("A1")
        self.sea_zone = create_zone("M1", zone_type="sea")
        self.non_impulsive = NonImpulsivePrecipitationType.objects.get(
            code="piogge_sparse"
        )
        self.impulsive = ImpulsivePrecipitationType.objects.get(
            code="temporali_isolati"
        )
        self.default_non_impulsive = NonImpulsivePrecipitationType.objects.get(
            code="absent"
        )
        self.default_impulsive = ImpulsivePrecipitationType.objects.get(code="absent")
        self.rain = PhenomenonType.objects.get(code="piogge")
        self.rain_level = PsLevel.objects.filter(
            phenomenon_type=self.rain,
            is_active=True,
        ).first()
        self.snow = PhenomenonType.objects.get(code="nevicate")
        self.snow_level = PsLevel.objects.filter(
            phenomenon_type=self.snow,
            is_active=True,
        ).first()
        self.today_interval = DailyPrecipitationInterval.objects.filter(
            day=MapId.TODAY
        ).first()
        self.tomorrow_interval = DailyPrecipitationInterval.objects.filter(
            day=MapId.TOMORROW
        ).first()

    def test_source_catalogs_expose_seeded_values(self):
        non_impulsive = self.client.get(
            "/api/non_impulsive_precipitation_types/"
        )
        impulsive = self.client.get("/api/impulsive_precipitation_types/")

        self.assertEqual(non_impulsive.status_code, status.HTTP_200_OK)
        self.assertEqual(impulsive.status_code, status.HTTP_200_OK)
        self.assertEqual(
            [item["code"] for item in non_impulsive.data],
            ["piogge_isolate", "piogge_sparse", "piogge_diffuse", "absent"],
        )
        self.assertEqual(
            [item["code"] for item in impulsive.data],
            [
                "absent",
                "rovesci_isolati",
                "temporali_isolati",
                "temporali_sparsi",
                "temporali_diffusi",
            ],
        )

    def test_daily_precipitation_intervals_expose_seeded_dropdown_values(self):
        response = self.client.get("/api/daily_precipitation_intervals/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(
            response.data,
            [
                {
                    "id": 1,
                    "day": "d0",
                    "time_interval": "12:00 - 18:00",
                    "description": "Dalle 12:00 alle 18:00",
                },
                {
                    "id": 2,
                    "day": "d0",
                    "time_interval": "18:00 - 24:00",
                    "description": "Dalle 18:00 alle 24:00",
                },
                {
                    "id": 3,
                    "day": "d1",
                    "time_interval": "00:00 - 06:00",
                    "description": "Dalle 00:00 alle 06:00",
                },
                {
                    "id": 4,
                    "day": "d1",
                    "time_interval": "06:00 - 12:00",
                    "description": "Dalle 06:00 alle 12:00",
                },
                {
                    "id": 5,
                    "day": "d1",
                    "time_interval": "12:00 - 18:00",
                    "description": "Dalle 12:00 alle 18:00",
                },
                {
                    "id": 6,
                    "day": "d1",
                    "time_interval": "18:00 - 24:00",
                    "description": "Dalle 18:00 alle 24:00",
                },
                {
                    "id": 7,
                    "day": "d2",
                    "time_interval": "00:00 - 06:00",
                    "description": "Dalle 00:00 alle 06:00",
                },
                {
                    "id": 8,
                    "day": "d2",
                    "time_interval": "06:00 - 12:00",
                    "description": "Dalle 06:00 alle 12:00",
                },
                {
                    "id": 9,
                    "day": "d2",
                    "time_interval": "12:00 - 18:00",
                    "description": "Dalle 12:00 alle 18:00",
                },
                {
                    "id": 10,
                    "day": "d2",
                    "time_interval": "18:00 - 24:00",
                    "description": "Dalle 18:00 alle 24:00",
                },
            ],
        )

    def test_save_source_qpf_replaces_map_and_returns_sorted_amounts(self):
        response = self.client.post(
            "/api/save_source_qpf/",
            {
                "map_id": "d1",
                "zones": [
                    {
                        "zone_id": self.zone.pk,
                        "non_impulsive_type_id": self.non_impulsive.pk,
                        "impulsive_type_id": self.impulsive.pk,
                        "amounts": [
                            {"duration_hours": 12, "min_mm": 10, "max_mm": 30,
                             "daily_precipitation_interval_id": self.tomorrow_interval.pk},
                            {"duration_hours": 3, "min_mm": 2, "max_mm": 8,
                             "daily_precipitation_interval_id": self.tomorrow_interval.pk},
                        ],
                    }
                ],
            },
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["saved_count"], 1)
        self.assertEqual(
            [item["duration_hours"] for item in response.data["zones"][0]["amounts"]],
            [3, 12],
        )
        saved = SourceQpf.objects.get(map_id="d1", zone=self.zone)
        self.assertEqual(saved.updated_by, self.user)
        self.assertEqual(saved.amounts.count(), 2)

        read_response = self.client.get("/api/source_qpf/?map_id=d1")
        self.assertEqual(read_response.status_code, status.HTTP_200_OK)
        self.assertEqual(read_response.data["maps"][0]["valid_date"], timezone.localdate() + timedelta(days=1))
        self.assertEqual(len(read_response.data["maps"][0]["zones"]), 1)

    def test_source_qpf_rejects_invalid_amounts_and_non_zdv_zone(self):
        base = {
            "map_id": "d0",
            "zones": [
                {
                    "zone_id": self.zone.pk,
                    "non_impulsive_type_id": self.non_impulsive.pk,
                    "impulsive_type_id": self.impulsive.pk,
                    "amounts": [
                        {"duration_hours": 6, "min_mm": 20, "max_mm": 10,
                         "daily_precipitation_interval_id": self.today_interval.pk}
                    ],
                }
            ],
        }
        invalid_range = self.client.post("/api/save_source_qpf/", base, format="json")
        base["zones"][0]["zone_id"] = self.sea_zone.pk
        base["zones"][0]["amounts"] = [
            {"duration_hours": 6, "min_mm": 10, "max_mm": 20,
             "daily_precipitation_interval_id": self.today_interval.pk}
        ]
        invalid_zone = self.client.post("/api/save_source_qpf/", base, format="json")

        self.assertEqual(invalid_range.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(invalid_zone.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(SourceQpf.objects.exists())

    def test_source_qpf_item_accepts_no_selected_durations(self):
        response = self.client.put(
            f"/api/source_qpf/d0/{self.zone.pk}/",
            {
                "non_impulsive_type_id": self.non_impulsive.pk,
                "impulsive_type_id": self.impulsive.pk,
                "amounts": [],
            },
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        saved = SourceQpf.objects.get(map_id="d0", zone=self.zone)
        self.assertFalse(saved.amounts.exists())
        self.assertEqual(response.data["zones"][0]["amounts"], [])

    def test_source_qpf_rejects_duplicate_duration(self):
        response = self.client.post(
            "/api/save_source_qpf/",
            {
                "map_id": "d0",
                "zones": [
                    {
                        "zone_id": self.zone.pk,
                        "non_impulsive_type_id": self.non_impulsive.pk,
                        "impulsive_type_id": self.impulsive.pk,
                        "amounts": [
                            {"duration_hours": 3, "min_mm": 1, "max_mm": 2,
                             "daily_precipitation_interval_id": self.today_interval.pk},
                            {"duration_hours": 3, "min_mm": 2, "max_mm": 3,
                             "daily_precipitation_interval_id": self.today_interval.pk},
                        ],
                    }
                ],
            },
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(SourceQpf.objects.exists())

    def test_source_qpf_accepts_multiple_durations_and_daily_intervals(self):
        today_12_18 = DailyPrecipitationInterval.objects.get(
            day="d0", time_interval="12:00 - 18:00"
        )
        today_18_24 = DailyPrecipitationInterval.objects.get(
            day="d0", time_interval="18:00 - 24:00"
        )

        response = self.client.post(
            "/api/save_source_qpf/",
            {
                "map_id": "d0",
                "zones": [
                    {
                        "zone_id": self.zone.pk,
                        "non_impulsive_type_id": self.non_impulsive.pk,
                        "impulsive_type_id": self.impulsive.pk,
                        "amounts": [
                            {
                                "duration_hours": 3,
                                "min_mm": 5,
                                "max_mm": 10,
                                "daily_precipitation_interval_id": today_12_18.pk,
                            },
                            {
                                "duration_hours": 6,
                                "min_mm": 5,
                                "max_mm": 20,
                                "daily_precipitation_interval_id": today_12_18.pk,
                            },
                            {
                                "duration_hours": 6,
                                "min_mm": 5,
                                "max_mm": 20,
                                "daily_precipitation_interval_id": today_18_24.pk,
                            },
                        ],
                    }
                ],
            },
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        amounts = response.data["zones"][0]["amounts"]
        self.assertEqual(len(amounts), 3)
        self.assertEqual(
            [
                (
                    item["daily_precipitation_interval"]["day"],
                    item["daily_precipitation_interval"]["time_interval"],
                    item["daily_precipitation_interval"]["description"],
                )
                for item in amounts
                if item["duration_hours"] == 6
            ],
            [
                ("d0", "12:00 - 18:00", "Dalle 12:00 alle 18:00"),
                ("d0", "18:00 - 24:00", "Dalle 18:00 alle 24:00"),
            ],
        )
        saved = SourceQpf.objects.get(map_id="d0", zone=self.zone)
        self.assertEqual(saved.amounts.filter(duration_hours=3).count(), 1)
        self.assertEqual(saved.amounts.filter(duration_hours=6).count(), 2)

    def test_source_qpf_rejects_interval_from_another_map(self):
        response = self.client.post(
            "/api/save_source_qpf/",
            {
                "map_id": "d0",
                "zones": [
                    {
                        "zone_id": self.zone.pk,
                        "non_impulsive_type_id": self.non_impulsive.pk,
                        "impulsive_type_id": self.impulsive.pk,
                        "amounts": [
                            {
                                "duration_hours": 6,
                                "min_mm": 5,
                                "max_mm": 20,
                                "daily_precipitation_interval_id": self.tomorrow_interval.pk,
                            }
                        ],
                    }
                ],
            },
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(SourceQpf.objects.exists())

    def test_save_source_ps_accepts_rain_and_rejects_other_phenomena(self):
        ZoneIconAnchor.objects.create(
            zone=self.zone,
            slot=1,
            label="Slot 1",
            point=Point(9.0, 44.0, srid=4326),
        )
        valid = self.client.post(
            "/api/save_source_ps/",
            {
                "map_id": "d0",
                "icons": [
                    {
                        "zone_id": self.zone.pk,
                        "phenomenon_type_id": self.rain.pk,
                        "ps_level_id": self.rain_level.pk,
                        "icon_slot": 1,
                        "custom_description": "Pioggia prevista",
                    }
                ],
            },
            format="json",
        )
        invalid = self.client.post(
            "/api/save_source_ps/",
            {
                "map_id": "d1",
                "icons": [
                    {
                        "zone_id": self.zone.pk,
                        "phenomenon_type_id": self.snow.pk,
                        "ps_level_id": self.snow_level.pk,
                        "icon_slot": 1,
                    }
                ],
            },
            format="json",
        )

        self.assertEqual(valid.status_code, status.HTTP_200_OK)
        self.assertEqual(valid.data["icons"][0]["anchor"]["slot"], 1)
        self.assertEqual(invalid.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(SourcePs.objects.filter(map_id="d1").exists())

    def test_source_qpf_item_put_delete_and_bulk_reset(self):
        put_response = self.client.put(
            f"/api/source_qpf/d0/{self.zone.pk}/",
            {
                "non_impulsive_type_id": self.non_impulsive.pk,
                "impulsive_type_id": self.impulsive.pk,
                "amounts": [{"duration_hours": 24, "min_mm": 0, "max_mm": 5,
                             "daily_precipitation_interval_id": self.today_interval.pk}],
            },
            format="json",
        )
        delete_response = self.client.delete(
            f"/api/source_qpf/d0/{self.zone.pk}/"
        )
        second_delete_response = self.client.delete(
            f"/api/source_qpf/d0/{self.zone.pk}/"
        )
        second_put_response = self.client.put(
            f"/api/source_qpf/d0/{self.zone.pk}/",
            {
                "non_impulsive_type_id": self.non_impulsive.pk,
                "impulsive_type_id": self.impulsive.pk,
                "amounts": [
                    {"duration_hours": 24, "min_mm": 0, "max_mm": 5,
                     "daily_precipitation_interval_id": self.today_interval.pk}
                ],
            },
            format="json",
        )
        reset_response = self.client.delete("/api/source_qpf/d0/")

        self.assertEqual(put_response.status_code, status.HTTP_200_OK)
        self.assertEqual(delete_response.status_code, status.HTTP_200_OK)
        self.assertEqual(delete_response.data["operation"], "reset")
        self.assertEqual(delete_response.data["reset_count"], 1)
        self.assertEqual(second_delete_response.status_code, status.HTTP_200_OK)
        self.assertEqual(second_put_response.status_code, status.HTTP_200_OK)
        self.assertEqual(reset_response.status_code, status.HTTP_200_OK)
        self.assertEqual(reset_response.data["operation"], "reset")
        self.assertEqual(reset_response.data["deleted_count"], 0)
        self.assertEqual(reset_response.data["reset_count"], 1)
        saved = SourceQpf.objects.get(map_id="d0", zone=self.zone)
        self.assertEqual(saved.non_impulsive_type, self.default_non_impulsive)
        self.assertEqual(saved.impulsive_type, self.default_impulsive)
        self.assertFalse(saved.amounts.exists())

    def test_source_qpf_item_delete_creates_missing_default_assignment(self):
        response = self.client.delete(
            f"/api/source_qpf/d1/{self.zone.pk}/"
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["operation"], "reset")
        self.assertEqual(response.data["reset_count"], 1)
        assignment = SourceQpf.objects.get(map_id="d1", zone=self.zone)
        self.assertEqual(assignment.non_impulsive_type, self.default_non_impulsive)
        self.assertEqual(assignment.impulsive_type, self.default_impulsive)

    def test_source_qpf_bulk_reset_creates_all_active_zdv_zones_only(self):
        other_zone = create_zone("A2")

        first_response = self.client.delete("/api/source_qpf/d2/")
        second_response = self.client.delete("/api/source_qpf/d2/")

        self.assertEqual(first_response.status_code, status.HTTP_200_OK)
        self.assertEqual(first_response.data["operation"], "reset")
        self.assertEqual(first_response.data["reset_count"], 2)
        self.assertEqual(second_response.status_code, status.HTTP_200_OK)
        self.assertEqual(second_response.data["reset_count"], 2)
        self.assertEqual(
            set(
                SourceQpf.objects.filter(map_id="d2").values_list(
                    "zone_id", flat=True
                )
            ),
            {self.zone.pk, other_zone.pk},
        )
        self.assertFalse(SourceQpf.objects.filter(zone=self.sea_zone).exists())

    def test_source_ps_read_item_put_delete_and_bulk_clear(self):
        ZoneIconAnchor.objects.create(
            zone=self.zone,
            slot=2,
            label="Slot 2",
            point=Point(9.0, 44.0, srid=4326),
        )
        path = f"/api/source_ps/d0/{self.zone.pk}/2/"
        payload = {
            "phenomenon_type_id": self.rain.pk,
            "ps_level_id": self.rain_level.pk,
            "custom_description": "Temporali previsti",
        }

        put_response = self.client.put(path, payload, format="json")
        read_response = self.client.get("/api/source_ps/?map_id=d0")
        delete_response = self.client.delete(path)
        second_put_response = self.client.put(path, payload, format="json")
        clear_response = self.client.delete("/api/source_ps/d0/")

        self.assertEqual(put_response.status_code, status.HTTP_200_OK)
        self.assertEqual(read_response.status_code, status.HTTP_200_OK)
        self.assertEqual(read_response.data["maps"][0]["icons"][0]["icon_slot"], 2)
        self.assertEqual(delete_response.status_code, status.HTTP_200_OK)
        self.assertEqual(delete_response.data["operation"], "delete")
        self.assertEqual(second_put_response.status_code, status.HTTP_200_OK)
        self.assertEqual(clear_response.status_code, status.HTTP_200_OK)
        self.assertEqual(clear_response.data["deleted_count"], 1)
        self.assertFalse(SourcePs.objects.exists())

    def test_source_endpoints_require_authentication(self):
        with patch.dict(os.environ):
            os.environ.pop("ACROWEB_LOCAL_AUTH_DATA_JSON_FILE", None)
            anonymous_client = APIClient()
            self.assertEqual(
                anonymous_client.get(
                    "/api/daily_precipitation_intervals/"
                ).status_code,
                status.HTTP_403_FORBIDDEN,
            )
            self.assertEqual(
                anonymous_client.get("/api/source_qpf/").status_code,
                status.HTTP_403_FORBIDDEN,
            )
            self.assertEqual(
                anonymous_client.post(
                    "/api/save_source_ps/",
                    {"map_id": "d0", "icons": []},
                    format="json",
                ).status_code,
                status.HTTP_403_FORBIDDEN,
            )


class PromoteSourceMapsApiTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username="promoter")
        self.client.force_authenticate(user=self.user)
        self.zone = create_zone("P1")
        self.other_zone = create_zone("P2")
        self.non_impulsive = NonImpulsivePrecipitationType.objects.get(
            code="piogge_sparse"
        )
        self.impulsive = ImpulsivePrecipitationType.objects.get(code="temporali_isolati")
        self.rain = PhenomenonType.objects.get(code="piogge")
        self.rain_level = PsLevel.objects.filter(
            phenomenon_type=self.rain,
            is_active=True,
        ).first()
        self.snow = PhenomenonType.objects.get(code="nevicate")
        self.snow_level = PsLevel.objects.filter(
            phenomenon_type=self.snow,
            is_active=True,
        ).first()
        self.manual_qpf = QpfLevel.objects.get(code="molto_elevate")

    def _source_qpf(self, map_id, zone, amounts):
        item = SourceQpf.objects.create(
            map_id=map_id,
            zone=zone,
            non_impulsive_type=self.non_impulsive,
            impulsive_type=self.impulsive,
        )
        SourceQpfAmount.objects.bulk_create(
            [SourceQpfAmount(source_qpf=item, **amount) for amount in amounts]
        )
        return item

    def test_promote_replaces_all_maps_and_scales_qpf_amounts_to_24_hours(self):
        QpfThreshold24h.objects.create(
            zone=self.zone,
            weak_mm=100,
            moderate_mm=150,
            elevated_mm=200,
            very_elevated_mm=250,
        )
        QpfThreshold24h.objects.create(
            zone=self.other_zone,
            weak_mm=80,
            moderate_mm=160,
            elevated_mm=240,
            very_elevated_mm=320,
        )
        self._source_qpf(
            MapId.TODAY,
            self.zone,
            [
                {"duration_hours": 3, "min_mm": 10, "max_mm": 20},
                {"duration_hours": 24, "min_mm": 40, "max_mm": 90},
            ],
        )
        self._source_qpf(
            MapId.TOMORROW,
            self.other_zone,
            [{"duration_hours": 3, "min_mm": 1, "max_mm": 10}],
        )
        SourcePs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            phenomenon_type=self.rain,
            ps_level=self.rain_level,
            icon_slot=1,
            custom_description="Piogge promosse",
        )
        CurQpf.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            qpf_level=self.manual_qpf,
        )
        CurQpf.objects.create(
            map_id=MapId.DAY_AFTER_TOMORROW,
            zone=self.other_zone,
            qpf_level=self.manual_qpf,
        )
        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            phenomenon_type=self.snow,
            ps_level=self.snow_level,
            icon_slot=2,
        )
        CurPs.objects.create(
            map_id=MapId.DAY_AFTER_TOMORROW,
            zone=self.other_zone,
            phenomenon_type=self.snow,
            ps_level=self.snow_level,
            icon_slot=1,
        )

        response = self.client.post("/api/promote_source_maps/", {}, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["operation"], "promote")
        self.assertEqual(
            [item["map_id"] for item in response.data["maps"]],
            [MapId.TODAY, MapId.TOMORROW, MapId.DAY_AFTER_TOMORROW],
        )
        # 20 mm / 3h equivalgono a 160 mm / 24h: livello moderato.
        self.assertEqual(
            CurQpf.objects.get(map_id=MapId.TODAY, zone=self.zone).qpf_level.code,
            "moderate",
        )
        # Il confronto e' inclusivo: 10 mm / 3h equivalgono alla soglia 80 mm / 24h.
        self.assertEqual(
            CurQpf.objects.get(
                map_id=MapId.TOMORROW,
                zone=self.other_zone,
            ).qpf_level.code,
            "deboli",
        )
        self.assertFalse(
            CurQpf.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists()
        )
        promoted_icon = CurPs.objects.get(map_id=MapId.TODAY)
        self.assertEqual(promoted_icon.phenomenon_type, self.rain)
        self.assertEqual(promoted_icon.icon_slot, 1)
        self.assertEqual(promoted_icon.custom_description, "Piogge promosse")
        self.assertEqual(promoted_icon.updated_by, self.user)
        self.assertFalse(
            CurPs.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists()
        )

    def test_promote_without_zone_thresholds_is_atomic(self):
        self._source_qpf(
            MapId.TODAY,
            self.zone,
            [{"duration_hours": 24, "min_mm": 10, "max_mm": 20}],
        )
        previous_qpf = CurQpf.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            qpf_level=self.manual_qpf,
        )
        previous_ps = CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            phenomenon_type=self.snow,
            ps_level=self.snow_level,
            icon_slot=1,
        )

        response = self.client.post("/api/promote_source_maps/", {}, format="json")

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("P1", response.data["thresholds"][0])
        self.assertTrue(CurQpf.objects.filter(pk=previous_qpf.pk).exists())
        self.assertTrue(CurPs.objects.filter(pk=previous_ps.pk).exists())

    def test_promote_assigns_very_elevated_level_above_100_mm_24h(self):
        QpfThreshold24h.objects.create(
            zone=self.zone,
            weak_mm=5,
            moderate_mm=20,
            elevated_mm=60,
            very_elevated_mm=100,
        )
        self._source_qpf(
            MapId.TODAY,
            self.zone,
            [{"duration_hours": 24, "min_mm": 100, "max_mm": 101}],
        )

        response = self.client.post("/api/promote_source_maps/", {}, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        assignment = CurQpf.objects.get(map_id=MapId.TODAY, zone=self.zone)
        self.assertEqual(assignment.qpf_level.code, "molto_elevate")

    def test_promote_uses_worst_qpf_across_durations_and_daily_intervals(self):
        QpfThreshold24h.objects.create(
            zone=self.zone,
            weak_mm=5,
            moderate_mm=20,
            elevated_mm=60,
            very_elevated_mm=100,
        )
        today = DailyPrecipitationInterval.objects.get(
            day="d0", time_interval="12:00 - 18:00"
        )
        tomorrow = DailyPrecipitationInterval.objects.get(
            day="d1", time_interval="06:00 - 12:00"
        )
        self._source_qpf(
            MapId.TODAY,
            self.zone,
            [
                {
                    "duration_hours": 3,
                    "min_mm": 1,
                    "max_mm": 2,
                    "daily_precipitation_interval": today,
                },
                {
                    "duration_hours": 6,
                    "min_mm": 2,
                    "max_mm": 5,
                    "daily_precipitation_interval": today,
                },
                {
                    "duration_hours": 6,
                    "min_mm": 5,
                    "max_mm": 26,
                    "daily_precipitation_interval": tomorrow,
                },
            ],
        )

        response = self.client.post("/api/promote_source_maps/", {}, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        assignment = CurQpf.objects.get(map_id=MapId.TODAY, zone=self.zone)
        self.assertEqual(assignment.qpf_level.code, "molto_elevate")

    def test_promote_keeps_100_mm_24h_in_elevated_level(self):
        QpfThreshold24h.objects.create(
            zone=self.zone,
            weak_mm=5,
            moderate_mm=20,
            elevated_mm=60,
            very_elevated_mm=100,
        )
        self._source_qpf(
            MapId.TODAY,
            self.zone,
            [{"duration_hours": 24, "min_mm": 60, "max_mm": 100}],
        )

        response = self.client.post("/api/promote_source_maps/", {}, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        assignment = CurQpf.objects.get(map_id=MapId.TODAY, zone=self.zone)
        self.assertEqual(assignment.qpf_level.code, "elevate")

    def test_qpf_threshold_catalog_and_promotion_require_authentication(self):
        QpfThreshold24h.objects.create(
            zone=self.zone,
            weak_mm=100,
            moderate_mm=150,
            elevated_mm=200,
            very_elevated_mm=250,
        )
        catalog = self.client.get("/api/qpf_thresholds/")
        self.assertEqual(catalog.status_code, status.HTTP_200_OK)
        self.assertEqual(catalog.data[0]["zone_code"], "P1")
        self.assertEqual(catalog.data[0]["very_elevated_mm"], 250)

        self.client.force_authenticate(user=None)
        self.assertEqual(
            self.client.post("/api/promote_source_maps/", {}, format="json").status_code,
            status.HTTP_401_UNAUTHORIZED,
        )
        self.assertEqual(
            self.client.get("/api/qpf_thresholds/").status_code,
            status.HTTP_401_UNAUTHORIZED,
        )


class CurrentMapsRolloverTests(TestCase):
    def setUp(self):
        self.zone = create_zone("R1")
        QpfThreshold24h.objects.create(
            zone=self.zone, weak_mm=10, moderate_mm=20,
            elevated_mm=50, very_elevated_mm=100,
        )
        self.non_impulsive = NonImpulsivePrecipitationType.objects.get(code="piogge_isolate")
        self.impulsive = ImpulsivePrecipitationType.objects.get(code="absent")
        self.default_qpf = QpfLevel.objects.get(
            code="assenti_o_deboli_non_rilevanti"
        )
        self.other_qpf = QpfLevel.objects.get(code="moderate")
        self.rain = PhenomenonType.objects.get(code="piogge")
        self.rain_level = PsLevel.objects.filter(phenomenon_type=self.rain).first()
        self.state = MapOperationalState.objects.get(key="current_maps")
        self.target_date = timezone.localdate()
        self.state.last_rollover_date = self.target_date - timedelta(days=1)
        self.state.save(update_fields=["last_rollover_date"])

    def _source_qpf(self, map_id, min_mm):
        item = SourceQpf.objects.create(
            map_id=map_id,
            zone=self.zone,
            non_impulsive_type=self.non_impulsive,
            impulsive_type=self.impulsive,
        )
        SourceQpfAmount.objects.create(
            source_qpf=item,
            duration_hours=3,
            min_mm=min_mm,
            max_mm=min_mm + 1,
        )

    def _source_qpf_with_intervals(self, map_id):
        self._source_qpf(map_id, 10)
        item = SourceQpf.objects.get(map_id=map_id, zone=self.zone)
        item.amounts.all().delete()
        for interval in DailyPrecipitationInterval.objects.filter(day=map_id):
            for duration in (3, 6, 12, 18, 24):
                SourceQpfAmount.objects.create(
                    source_qpf=item,
                    daily_precipitation_interval=interval,
                    duration_hours=duration,
                    min_mm=duration,
                    max_mm=duration + 10,
                )
        return item

    def test_d0_recalculation_discards_morning_and_overrides_manual_level(self):
        source = self._source_qpf_with_intervals(MapId.TOMORROW)
        source.amounts.filter(
            daily_precipitation_interval__time_interval__in=(
                "12:00 - 18:00", "18:00 - 24:00"
            )
        ).update(min_mm=0, max_mm=1)
        # Evening is the worst surviving quantity; morning values were much higher.
        source.amounts.filter(
            daily_precipitation_interval__time_interval="18:00 - 24:00",
            duration_hours=24,
        ).update(min_mm=10, max_mm=15)
        manual_level = QpfLevel.objects.get(code="molto_elevate")
        user = get_user_model().objects.create_user(username="rollover-editor")
        for day in (MapId.TOMORROW, MapId.DAY_AFTER_TOMORROW):
            CurQpf.objects.create(
                map_id=day, zone=self.zone, qpf_level=manual_level,
                custom_description="Scelta manuale", updated_by=user,
            )

        call_command("rollover_current_maps", target_date=self.target_date.isoformat(),
                     stdout=StringIO())

        today = CurQpf.objects.get(map_id=MapId.TODAY, zone=self.zone)
        self.assertEqual(today.qpf_level.code, "deboli")
        self.assertEqual(today.custom_description, "")
        self.assertIsNone(today.updated_by)
        tomorrow = CurQpf.objects.get(map_id=MapId.TOMORROW, zone=self.zone)
        self.assertEqual(tomorrow.qpf_level, manual_level)
        self.assertEqual(tomorrow.custom_description, "Scelta manuale")
        self.assertEqual(tomorrow.updated_by, user)
        before = list(CurQpf.objects.order_by("pk").values())
        call_command("rollover_current_maps", target_date=self.target_date.isoformat(),
                     stdout=StringIO())
        self.assertEqual(before, list(CurQpf.objects.order_by("pk").values()))

    def test_no_valid_quantities_reset_d0_even_without_thresholds(self):
        source = self._source_qpf_with_intervals(MapId.TOMORROW)
        source.amounts.filter(
            daily_precipitation_interval__time_interval__in=(
                "12:00 - 18:00", "18:00 - 24:00"
            )
        ).delete()
        # Legacy quantities without a clock interval cannot justify a D0 level.
        SourceQpfAmount.objects.create(
            source_qpf=source, duration_hours=3, min_mm=100, max_mm=200,
        )
        manual_zone = create_zone("MANUAL")
        for zone in (self.zone, manual_zone):
            CurQpf.objects.create(
                map_id=MapId.TOMORROW, zone=zone, qpf_level=self.other_qpf,
            )
        QpfThreshold24h.objects.filter(zone=self.zone).delete()

        call_command("rollover_current_maps", target_date=self.target_date.isoformat(),
                     stdout=StringIO())

        self.assertEqual(CurQpf.objects.filter(map_id=MapId.TODAY).count(), 2)
        self.assertEqual(set(CurQpf.objects.filter(map_id=MapId.TODAY).values_list(
            "qpf_level_id", flat=True
        )), {self.default_qpf.pk})

    def test_missing_thresholds_roll_back_sources_intermediates_and_date(self):
        self._source_qpf_with_intervals(MapId.TOMORROW)
        self._source_qpf_with_intervals(MapId.DAY_AFTER_TOMORROW)
        CurQpf.objects.create(
            map_id=MapId.TOMORROW, zone=self.zone, qpf_level=self.other_qpf,
        )
        QpfThreshold24h.objects.filter(zone=self.zone).delete()
        models = (SourceQpf, SourceQpfAmount, CurQpf, MapOperationalState)
        before = [list(model.objects.order_by("pk").values()) for model in models]

        with self.assertRaisesMessage(CommandError, "Soglie QPF 24h"):
            call_command("rollover_current_maps", target_date=self.target_date.isoformat(),
                         stdout=StringIO())

        self.assertEqual(before, [list(model.objects.order_by("pk").values())
                                  for model in models])

    def test_rollover_remaps_intervals_and_preserves_quantities(self):
        today = self._source_qpf_with_intervals(MapId.TODAY)
        tomorrow = self._source_qpf_with_intervals(MapId.TOMORROW)
        day_after = self._source_qpf_with_intervals(MapId.DAY_AFTER_TOMORROW)
        original = {
            amount.pk: (amount.duration_hours, amount.min_mm, amount.max_mm,
                        amount.daily_precipitation_interval.time_interval)
            for amount in SourceQpfAmount.objects.select_related(
                "daily_precipitation_interval"
            ).exclude(source_qpf=today)
        }

        call_command("rollover_current_maps", target_date=self.target_date.isoformat(),
                     stdout=StringIO())

        self.assertFalse(SourceQpf.objects.filter(pk=today.pk).exists())
        for source, day, count in ((tomorrow, MapId.TODAY, 10),
                                   (day_after, MapId.TOMORROW, 20)):
            source.refresh_from_db()
            self.assertEqual(source.map_id, day)
            self.assertEqual(source.amounts.count(), count)
            for amount in source.amounts.select_related("daily_precipitation_interval"):
                interval = amount.daily_precipitation_interval
                self.assertEqual(interval.day, day)
                self.assertEqual(interval.pk, DailyPrecipitationInterval.objects.get(
                    day=day, time_interval=interval.time_interval
                ).pk)
                self.assertEqual(
                    (amount.duration_hours, amount.min_mm, amount.max_mm,
                     interval.time_interval), original[amount.pk]
                )
        self.assertFalse(tomorrow.amounts.filter(
            daily_precipitation_interval__time_interval__in=(
                "00:00 - 06:00", "06:00 - 12:00"
            )
        ).exists())
        before = list(SourceQpfAmount.objects.order_by("pk").values())
        call_command("rollover_current_maps", target_date=self.target_date.isoformat(),
                     stdout=StringIO())
        self.assertEqual(before, list(SourceQpfAmount.objects.order_by("pk").values()))

    def test_two_day_rollover_remaps_d2_to_d0_and_discards_morning(self):
        self.state.last_rollover_date = self.target_date - timedelta(days=2)
        self.state.save(update_fields=["last_rollover_date"])
        expired = self._source_qpf_with_intervals(MapId.TOMORROW)
        surviving = self._source_qpf_with_intervals(MapId.DAY_AFTER_TOMORROW)

        call_command("rollover_current_maps", target_date=self.target_date.isoformat(),
                     stdout=StringIO())

        self.assertFalse(SourceQpf.objects.filter(pk=expired.pk).exists())
        surviving.refresh_from_db()
        self.assertEqual(surviving.map_id, MapId.TODAY)
        self.assertEqual(surviving.amounts.count(), 10)
        self.assertEqual(set(surviving.amounts.values_list(
            "daily_precipitation_interval__day", flat=True
        )), {MapId.TODAY})
        self.assertEqual(
            CurQpf.objects.get(map_id=MapId.TODAY, zone=self.zone).qpf_level.code,
            "molto_elevate",
        )

    def test_missing_destination_interval_rolls_back_all_changes(self):
        self._source_qpf_with_intervals(MapId.TODAY)
        self._source_qpf_with_intervals(MapId.TOMORROW)
        DailyPrecipitationInterval.objects.filter(
            day=MapId.TODAY, time_interval="18:00 - 24:00"
        ).update(is_active=False)
        before_maps = list(SourceQpf.objects.order_by("pk").values())
        before_amounts = list(SourceQpfAmount.objects.order_by("pk").values())

        with self.assertRaisesMessage(CommandError, "d0 18:00 - 24:00"):
            call_command("rollover_current_maps", target_date=self.target_date.isoformat(),
                         stdout=StringIO())

        self.assertEqual(before_maps, list(SourceQpf.objects.order_by("pk").values()))
        self.assertEqual(before_amounts, list(SourceQpfAmount.objects.order_by("pk").values()))
        self.state.refresh_from_db()
        self.assertEqual(self.state.last_rollover_date, self.target_date - timedelta(days=1))

    def test_rollover_shifts_all_maps_initializes_d2_and_is_idempotent(self):
        self._source_qpf(MapId.TODAY, 1)
        self._source_qpf(MapId.TOMORROW, 10)
        self._source_qpf(MapId.DAY_AFTER_TOMORROW, 20)
        for map_id, slot in ((MapId.TOMORROW, 1), (MapId.DAY_AFTER_TOMORROW, 2)):
            SourcePs.objects.create(
                map_id=map_id,
                zone=self.zone,
                phenomenon_type=self.rain,
                ps_level=self.rain_level,
                icon_slot=slot,
            )
            CurPs.objects.create(
                map_id=map_id,
                zone=self.zone,
                phenomenon_type=self.rain,
                ps_level=self.rain_level,
                icon_slot=slot,
            )
            CurQpf.objects.create(
                map_id=map_id,
                zone=self.zone,
                qpf_level=self.other_qpf,
            )

        call_command(
            "rollover_current_maps",
            target_date=self.target_date.isoformat(),
            stdout=StringIO(),
        )

        self.assertEqual(
            SourceQpf.objects.get(map_id=MapId.TODAY).amounts.get().min_mm,
            10,
        )
        self.assertEqual(
            SourceQpf.objects.get(map_id=MapId.TOMORROW).amounts.get().min_mm,
            20,
        )
        self.assertFalse(SourceQpf.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists())
        self.assertEqual(SourcePs.objects.get(map_id=MapId.TODAY).icon_slot, 1)
        self.assertEqual(SourcePs.objects.get(map_id=MapId.TOMORROW).icon_slot, 2)
        self.assertFalse(SourcePs.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists())
        self.assertEqual(CurPs.objects.get(map_id=MapId.TODAY).icon_slot, 1)
        self.assertEqual(CurPs.objects.get(map_id=MapId.TOMORROW).icon_slot, 2)
        self.assertFalse(CurPs.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists())
        self.assertEqual(
            CurQpf.objects.get(map_id=MapId.DAY_AFTER_TOMORROW, zone=self.zone).qpf_level,
            self.default_qpf,
        )

        before = list(SourceQpf.objects.values_list("map_id", "id"))
        output = StringIO()
        call_command(
            "rollover_current_maps",
            target_date=self.target_date.isoformat(),
            stdout=output,
        )
        self.assertEqual(before, list(SourceQpf.objects.values_list("map_id", "id")))
        self.assertIn("gia' eseguito", output.getvalue())

    def test_rollover_after_three_days_discards_expired_maps(self):
        self.state.last_rollover_date = self.target_date - timedelta(days=3)
        self.state.save(update_fields=["last_rollover_date"])
        self._source_qpf(MapId.DAY_AFTER_TOMORROW, 20)
        CurPs.objects.create(
            map_id=MapId.DAY_AFTER_TOMORROW,
            zone=self.zone,
            phenomenon_type=self.rain,
            ps_level=self.rain_level,
            icon_slot=1,
        )

        call_command(
            "rollover_current_maps",
            target_date=self.target_date.isoformat(),
            stdout=StringIO(),
        )

        self.assertFalse(SourceQpf.objects.exists())
        self.assertFalse(CurPs.objects.exists())
        self.assertTrue(
            CurQpf.objects.filter(
                map_id=MapId.DAY_AFTER_TOMORROW,
                zone=self.zone,
                qpf_level=self.default_qpf,
            ).exists()
        )
