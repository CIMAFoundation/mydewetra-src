# Data model PS/VMN

Questo documento descrive il modello dati iniziale per la produzione dei
bollettini di Previsione Sinottica (PS) e Vigilanza Meteo Nazionale (VMN).

Il modello segue l'approccio concordato:

- `ps_vm_core_cur_qpf` e `ps_vm_core_cur_ps` rappresentano solo lo stato corrente operativo della
  mappa.
- Le tabelle del bollettino salvano una fotografia autonoma dello stato corrente
  al momento della generazione/salvataggio.
- Non viene introdotto un ciclo di produzione separato (`ForecastSession`).
- La distinzione tra prima emissione, aggiornamento e preview resta sul
  bollettino.

## Convenzioni principali

### Mappe previsionali

I tre step temporali sono rappresentati dal campo `map_id`:

| Valore | Significato |
| --- | --- |
| `d0` | oggi |
| `d1` | domani |
| `d2` | dopodomani |

### Tipi bollettino

Il campo `bull_type` identifica il tipo di emissione:

| Valore | Significato |
| --- | --- |
| `first` | prima emissione |
| `update` | aggiornamento |

Il campo `is_preview` indica se il bollettino e' una preview oppure una versione
da considerare effettiva.

## Tabelle anagrafiche e definizioni

### `ps_vm_core_region`

Anagrafica delle regioni usata per descrivere e aggregare le zone di vigilanza
meteo transregionali.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `code` | codice univoco della regione |
| `name` | nome della regione |
| `sort_order` | ordinamento applicativo |
| `is_active` | abilita/disabilita la regione |

### `ps_vm_core_zone_vigilanza_meteo`

Anagrafica delle zone di vigilanza meteo.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `code` | codice univoco della zona |
| `name` | nome della zona |
| `description` | descrizione libera |
| `keywords` | parole chiave utili per generazione testi e ricerca |
| `is_active` | abilita/disabilita la zona |
| `geometry` | geometria `MultiPolygon` della zona |
| `created_at`, `updated_at` | audit tecnico |

Relazioni:

- relazione molti-a-molti con `ps_vm_core_region` tramite
  `ps_vm_core_zone_vigilanza_meteo_region`.
- relazione uno-a-molti con `ps_vm_core_zone_icon_anchor`.

### `ps_vm_core_zone_vigilanza_meteo_region`

Tabella di relazione tra zone di vigilanza e regioni.

Serve per gestire il fatto che le zone possono essere transregionali e per
aggiungere eventuali descrizioni testuali specifiche della relazione.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `region_id` | FK verso `ps_vm_core_region` |
| `description` | descrizione specifica della relazione zona/regione |
| `sort_order` | ordinamento |

Vincoli:

- una stessa coppia zona/regione puo' comparire una sola volta.

### `ps_vm_core_zone_icon_anchor`

Posizioni disponibili per disegnare le icone PS dentro una zona.

Sostituisce le colonne fisse `ps_icon_pos1`, `ps_icon_pos2`, ecc. con una
struttura piu' flessibile.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `slot` | posizione logica dell'icona, da 1 a 4 |
| `label` | etichetta opzionale |
| `point` | punto geografico dove disegnare l'icona |

Vincoli:

- per ogni zona puo' esistere un solo anchor per ciascuno slot.

### `ps_vm_core_qpf_def`

Definizione dei livelli QPF.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `code` | codice univoco del livello |
| `description` | descrizione breve |
| `level` | livello numerico |
| `text` | testo associato al livello, utile per generazione bollettini |
| `sort_order` | ordinamento |
| `image` | eventuale immagine associata |
| `color` | colore applicativo/cartografico |
| `svg` | eventuale SVG inline |
| `is_active` | abilita/disabilita il livello |
| `created_at`, `updated_at` | audit tecnico |

### `ps_vm_core_ps_phenomenon_type`

Anagrafica dei tipi di fenomeno sinottico.

Esempi: pioggia, temporali, neve, vento, temperatura, nebbia, gelate, mari.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `code` | codice univoco del fenomeno |
| `name` | nome del fenomeno |
| `description` | descrizione libera |
| `sort_order` | ordinamento |
| `is_active` | abilita/disabilita il fenomeno |

### `ps_vm_core_ps_def`

Definizione dei livelli/icone di previsione sinottica.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `phenomenon_type_id` | FK verso `ps_vm_core_ps_phenomenon_type` |
| `code` | codice del livello nel contesto del fenomeno |
| `description` | descrizione breve |
| `level` | livello numerico |
| `text` | testo associato al livello |
| `sort_order` | ordinamento |
| `icon` | eventuale file icona |
| `color` | colore applicativo/cartografico |
| `svg` | eventuale SVG inline |
| `is_active` | abilita/disabilita il livello |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- `phenomenon_type_id + code` deve essere univoco.

#### Endpoint REST associati

I modelli esistenti coprono le anagrafiche richieste senza introdurre nuove
tabelle o migrazioni:

- `GET /api/qpf_levels/` legge i record attivi di `ps_vm_core_qpf_def`, ordinati
  per l'uso nelle tendine dei livelli di severita';
- `GET /api/ps_icons/` legge i fenomeni attivi di
  `ps_vm_core_ps_phenomenon_type` e annida per ciascuno i record attivi di
  `ps_vm_core_ps_def`.

Il secondo endpoint esclude i fenomeni senza icone attive. Entrambi espongono
anche il dettaglio tramite `GET /api/<anagrafica>/<id>/` e richiedono
autenticazione.

### `ps_vm_core_map_layer`

Layer cartografici logici usati dall'applicazione.

Unifica i concetti di base map, background layer e ancillary layer. Il layer
logico non contiene geometrie: per i base layer descrive solo la configurazione
del provider client, mentre per background e ancillary raggruppa le feature
geografiche salvate in `ps_vm_core_map_layer_feature`.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `code` | codice univoco del layer |
| `name` | nome del layer |
| `description` | descrizione |
| `layer_type` | `base`, `background`, `ancillary` |
| `style` | configurazione JSON di stile |
| `sort_order` | ordinamento |
| `is_active` | abilita/disabilita il layer |
| `created_at`, `updated_at` | audit tecnico |

### `ps_vm_core_map_layer_feature`

Feature geografiche appartenenti a un layer cartografico logico.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `layer_id` | FK verso `ps_vm_core_map_layer` |
| `code` | codice della feature nel contesto del layer |
| `name` | nome della feature |
| `description` | descrizione |
| `properties` | attributi JSON liberi della feature |
| `sort_order` | ordinamento |
| `is_active` | abilita/disabilita la feature |
| `geometry` | geometria della feature |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- `layer_id + code` deve essere univoco.

## Settings

### `ps_vm_core_app_settings`

Configurazione generale dell'applicazione.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `title` | titolo applicazione |
| `map_title` | titolo area mappa |
| `text_title` | titolo area testi |
| `base_map_id` | FK opzionale verso `ps_vm_core_map_layer` di tipo `base` |
| `background_layer_id` | FK opzionale verso `ps_vm_core_map_layer` di tipo `background` |
| `config` | JSON generico per configurazioni future |
| `is_active` | configurazione attiva/non attiva |
| `created_at`, `updated_at` | audit tecnico |

Relazioni:

- molti-a-molti con `ps_vm_core_map_layer` per gli ancillary layer tramite
  `ancillary_layers`.

## Endpoint cartografici di base

Gli endpoint leggono la prima configurazione attiva in `ps_vm_core_app_settings`.
Se il relativo layer non e' configurato, usano come fallback i layer attivi dello
stesso tipo.

### `GET /api/background_layer/`

Restituisce una `FeatureCollection` GeoJSON con le feature attive del background
layer configurato.

### `GET /api/ancillary_layer/`

Restituisce una lista di layer ancillary. Ogni elemento contiene:

| Campo | Descrizione |
| --- | --- |
| `layer` | metadati JSON del layer logico `ps_vm_core_map_layer` |
| `geojson` | `FeatureCollection` GeoJSON con le feature attive del layer |

Forma della risposta:

```json
[
  {
    "layer": {
      "id": 1,
      "code": "italy_provinces",
      "name": "Province italiane",
      "layer_type": "ancillary",
      "style": {}
    },
    "geojson": {
      "type": "FeatureCollection",
      "features": []
    }
  }
]
```

### `GET /api/base_map/`

Restituisce il JSON del base map configurato. Non restituisce GeoJSON, perche'
il base map e' una configurazione del provider client e non ha feature
geografiche.

Esempio:

```json
{
  "id": 1,
  "code": "google_maps_sat",
  "name": "Google Satellite",
  "layer_type": "base",
  "style": {
    "provider": "google",
    "mapType": "satellite"
  }
}
```

### `ps_vm_core_bulletin_settings`

Configurazioni specifiche dei bollettini, globali o per utente.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `bulletin_type` | `ps` oppure `vmn` |
| `user_id` | utente opzionale; se nullo la configurazione e' globale |
| `title` | titolo default |
| `default_titles` | JSON con titoli/sezioni predefinite |
| `default_texts` | JSON con testi default |
| `layout_config` | JSON con impostazioni di layout |
| `is_active` | configurazione attiva/non attiva |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- una configurazione globale per tipo bollettino.
- una configurazione per coppia tipo bollettino/utente.

## Stato corrente mappa

### `ps_vm_core_cur_qpf`

Stato corrente QPF delle zone per le tre mappe `d0`, `d1`, `d2`.

Questa tabella e' una lavagna operativa: puo' essere aggiornata e sovrascritta.
Non rappresenta uno storico.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `map_id` | `d0`, `d1`, `d2` |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `qpf_level_id` | FK verso `ps_vm_core_qpf_def` |
| `custom_description` | descrizione specifica dell'assegnazione QPF, opzionale |
| `updated_by_id` | utente che ha aggiornato il valore |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- un solo valore QPF corrente per coppia `map_id + zone_id`.

### `ps_vm_core_cur_ps`

Stato corrente delle icone di Previsione Sinottica sulle zone.

Anche questa tabella e' una lavagna operativa e non uno storico.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `map_id` | `d0`, `d1`, `d2` |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `phenomenon_type_id` | FK verso `ps_vm_core_ps_phenomenon_type` |
| `ps_level_id` | FK verso `ps_vm_core_ps_def` |
| `icon_slot` | posizione logica dell'icona nella zona, da 1 a 4 |
| `custom_description` | descrizione specifica dell'assegnazione PS, opzionale |
| `updated_by_id` | utente che ha aggiornato il valore |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- una sola icona corrente per `map_id + zone_id + icon_slot`.

Nota applicativa:

- Il modello non impedisce a livello database che `ps_level_id` appartenga a un
  fenomeno diverso da `phenomenon_type_id`. Questo controllo va gestito in
  serializer/service layer oppure con una validazione custom.

## Endpoint dello stato corrente

Gli endpoint dello stato corrente richiedono autenticazione e restituiscono una
risposta sparsa: sono presenti soltanto le assegnazioni esistenti nelle tabelle
`cur_*`. L'assenza di una zona o di un'icona indica quindi che non esiste
un'assegnazione corrente.

Senza parametri, entrambi gli endpoint restituiscono sempre i contenitori delle
mappe `d0`, `d1` e `d2`, inclusi quelli vuoti. Il parametro opzionale `map_id`
permette di richiedere una sola mappa:

```text
?map_id=d0
?map_id=d1
?map_id=d2
```

La risposta include `operational_date`, calcolata nel fuso orario applicativo,
e la `valid_date` di ciascuna mappa.

### `GET /api/current_qpf/`

Restituisce le assegnazioni QPF correnti, raggruppate per mappa. Ciascuna
assegnazione contiene zona, livello QPF, descrizione personalizzata e dati di
audit.

```json
{
  "operational_date": "2026-07-22",
  "maps": [
    {
      "map_id": "d0",
      "valid_date": "2026-07-22",
      "zones": []
    },
    {
      "map_id": "d1",
      "valid_date": "2026-07-23",
      "zones": []
    },
    {
      "map_id": "d2",
      "valid_date": "2026-07-24",
      "zones": []
    }
  ]
}
```

### `GET /api/current_ps/`

Restituisce le icone PS correnti, raggruppate per mappa. Ciascuna icona contiene
zona, fenomeno, livello PS, slot, descrizione personalizzata e, quando definito,
il relativo anchor geografico.

### `POST /api/save_current_qpf/`

Sostituisce atomicamente lo stato QPF di una singola mappa. Il payload contiene
`map_id` e l'array completo `zones`; le assegnazioni precedenti non presenti
nell'array vengono eliminate. Un array vuoto cancella lo stato QPF del giorno.

### `POST /api/save_current_ps/`

Sostituisce atomicamente lo stato delle icone PS di una singola mappa. Il
payload contiene `map_id` e l'array completo `icons`; le icone precedenti non
presenti nell'array vengono eliminate. La validazione controlla che ogni slot
di una zona sia occupato al massimo una volta e che ciascun livello PS
appartenga al fenomeno indicato.

Gli endpoint `PUT` e `DELETE` sotto `current_qpf/{map_id}/{zone_id}` e
`current_ps/{map_id}/{zone_id}/{icon_slot}` modificano invece una sola chiave e
seguono la politica `last write wins`.

L'endpoint `DELETE /api/current_qpf/{map_id}/` esegue in modo atomico il reset
di tutte le zone VM della mappa: assegna il livello
`assenti_o_deboli_non_rilevanti` (`level=0`) e azzera le descrizioni
personalizzate. `DELETE /api/current_ps/{map_id}/` elimina invece tutte le
icone PS della sola mappa indicata. Entrambe le operazioni sono idempotenti e
notificano ai client lo snapshot risultante.

La stessa distinzione vale per gli endpoint puntuali: il `DELETE` QPF esegue un
upsert del valore di default sulla zona, mentre il `DELETE` PS rimuove
effettivamente l'icona dallo slot.

Il contratto completo, con payload e risposte di esempio, e' descritto in
[`docs/api.md`](api.md).

## Bollettino Previsione Sinottica

### `ps_vm_core_ps_bul_text`

Testata e testi del bollettino di Previsione Sinottica.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo bollettino |
| `day_string` | stringa giorno usata nel bollettino |
| `user_id` | utente che ha prodotto/salvato il bollettino |
| `bull_type` | `first` oppure `update` |
| `update_number` | numero aggiornamento |
| `is_preview` | indica se e' una preview |
| `title` | titolo bollettino |
| `subtitle` | sottotitolo |
| `generated_sections` | JSON con testi generati automaticamente |
| `text_sections` | JSON con testi finali editabili |
| `notes` | note interne/opzionali |
| `ts` | timestamp di creazione emissione |
| `created_at`, `updated_at` | audit tecnico |

`generated_sections` e `text_sections` permettono di conservare sia il testo
generato dalla mappa sia il testo modificato manualmente dal previsore.

### `ps_vm_core_ps_bul_icon`

Snapshot delle icone PS associate a un bollettino PS.

Questa tabella viene popolata copiando lo stato corrente da `ps_vm_core_cur_ps` quando si
salva/genera il bollettino.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `bulletin_id` | FK verso `ps_vm_core_ps_bul_text` |
| `map_id` | `d0`, `d1`, `d2` |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `phenomenon_type_id` | FK verso `ps_vm_core_ps_phenomenon_type` |
| `ps_level_id` | FK verso `ps_vm_core_ps_def` |
| `icon_slot` | slot icona usato nella zona |
| `zone_code`, `zone_name` | copia dei dati zona al momento del salvataggio |
| `phenomenon_code` | copia del codice fenomeno |
| `ps_code`, `ps_text` | copia dei dati livello PS |
| `custom_description` | copia della descrizione specifica impostata in `ps_vm_core_cur_ps` |
| `icon`, `color`, `svg` | copia dei riferimenti/stili icona |

I campi duplicati sono intenzionali: servono a mantenere coerente il bollettino
anche se in futuro cambiano anagrafiche, testi o icone.

## Bollettino Vigilanza Meteo Nazionale

### `ps_vm_core_vm_bul_text`

Testata e testi del bollettino di Vigilanza Meteo Nazionale.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo bollettino |
| `day_string` | stringa giorno usata nel bollettino |
| `user_id` | utente che ha prodotto/salvato il bollettino |
| `bull_type` | `first` oppure `update` |
| `update_number` | numero aggiornamento |
| `is_preview` | indica se e' una preview |
| `title` | titolo bollettino |
| `subtitle` | sottotitolo |
| `generated_sections` | JSON con testi generati automaticamente |
| `text_sections` | JSON con testi finali editabili |
| `notes` | note interne/opzionali |
| `ts` | timestamp di creazione emissione |
| `created_at`, `updated_at` | audit tecnico |

### `ps_vm_core_vm_bul_zone_vigilanza`

Snapshot QPF delle zone associato a un bollettino VMN.

Questa tabella viene popolata copiando lo stato corrente da `ps_vm_core_cur_qpf` quando si
salva/genera il bollettino.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `bulletin_id` | FK verso `ps_vm_core_vm_bul_text` |
| `map_id` | `d0`, `d1`, `d2` |
| `zone_id` | FK verso `ps_vm_core_zone_vigilanza_meteo` |
| `qpf_level_id` | FK verso `ps_vm_core_qpf_def` |
| `zone_code`, `zone_name` | copia dei dati zona al momento del salvataggio |
| `qpf_code`, `qpf_text` | copia dei dati QPF |
| `custom_description` | copia della descrizione specifica impostata in `ps_vm_core_cur_qpf` |
| `color`, `svg` | copia dello stile QPF |

Vincoli:

- una sola riga per `bulletin_id + map_id + zone_id`.

## Archivio PDF

### `ps_vm_core_bulletin_pdf_archive`

Archivio dei PDF prodotti per PS e VMN.

E' una tabella unica per entrambi i prodotti.

Campi principali:

| Campo | Descrizione |
| --- | --- |
| `id` | identificativo interno |
| `bulletin_type` | `ps` oppure `vmn` |
| `ps_bulletin_id` | FK opzionale verso `ps_vm_core_ps_bul_text` |
| `vm_bulletin_id` | FK opzionale verso `ps_vm_core_vm_bul_text` |
| `file` | file PDF archiviato |
| `filename` | nome file originale/logico |
| `content_type` | content type, default `application/pdf` |
| `size` | dimensione file in byte |
| `sha256` | hash del PDF |
| `is_signed` | indica se il PDF e' firmato digitalmente |
| `created_at`, `updated_at` | audit tecnico |

Vincoli:

- ogni record deve puntare a un solo bollettino: PS oppure VMN, non entrambi.

## Flusso operativo previsto

1. Il client aggiorna la mappa operativa scrivendo su `ps_vm_core_cur_qpf` e `ps_vm_core_cur_ps`.
2. L'applicazione genera i testi a partire dallo stato corrente.
3. Il previsore puo' modificare manualmente i testi generati.
4. Al salvataggio del bollettino:
   - viene creata una riga in `ps_vm_core_ps_bul_text` o `ps_vm_core_vm_bul_text`;
   - viene copiato lo stato corrente in `ps_vm_core_ps_bul_icon` o
     `ps_vm_core_vm_bul_zone_vigilanza`;
   - eventuali descrizioni specifiche delle assegnazioni correnti vengono
     copiate negli snapshot del bollettino;
   - i testi finali vengono salvati nei campi JSON del bollettino.
5. Alla produzione del PDF viene creata una riga in `ps_vm_core_bulletin_pdf_archive`.

## Note per sviluppi successivi

- Quando saranno definiti con precisione i campi testuali dei due bollettini, i
  JSON `generated_sections` e `text_sections` potranno essere mantenuti oppure
  sostituiti/affiancati da campi relazionali piu' specifici.
- La validazione di coerenza tra `ps_vm_core_cur_ps.phenomenon_type` e
  `ps_vm_core_cur_ps.ps_level.phenomenon_type` va implementata nei serializer o nei service.
- La strategia di rollover giornaliero (`d1 -> d0`, `d2 -> d1`) puo' essere
  implementata come comando applicativo che aggiorna le tabelle `cur_*`.
