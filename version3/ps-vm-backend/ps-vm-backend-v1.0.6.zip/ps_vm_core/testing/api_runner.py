from __future__ import annotations

import json
import traceback
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from acroweb3_api.auth import AcrowebAuthData
from django.conf import settings
from django.core.serializers.json import DjangoJSONEncoder
from rest_framework.test import APIClient

from ps_vm_core.urls import ps_vm_api_router


AVAILABLE_ENDPOINTS = (
    *(basename for _, _, basename in ps_vm_api_router.registry),
    "clear_current_qpf",
    "clear_current_ps",
    "current_qpf_item",
    "current_ps_item",
)
WRITE_ENDPOINTS = frozenset(
    {
        "save_current_qpf",
        "save_current_ps",
        "clear_current_qpf",
        "clear_current_ps",
        "current_qpf_item",
        "current_ps_item",
    }
)
BASE_PATH = "/api"


@dataclass
class ApiCallResult:
    name: str
    method: str
    path: str
    params: dict[str, Any] = field(default_factory=dict)
    payload: Any = None
    status_code: int = 0
    ok: bool = False
    response_data: Any = None
    skipped: bool = False
    skip_reason: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "method": self.method,
            "path": self.path,
            "params": self.params,
            "payload": self.payload,
            "status_code": self.status_code,
            "ok": self.ok,
            "response_data": self.response_data,
            "skipped": self.skipped,
            "skip_reason": self.skip_reason,
            "meta": self.meta,
        }


def load_local_auth_data(auth_path: str | Path | None = None) -> AcrowebAuthData:
    auth_file = Path(auth_path or Path(settings.BASE_DIR) / "ps_vm" / "acroweb_local_auth_data.json")
    with auth_file.open("r", encoding="utf-8") as handle:
        raw_data = json.load(handle)
    return AcrowebAuthData.from_dict(raw_data)


class PsVmApiRunner:
    def __init__(self, auth_path: str | Path | None = None) -> None:
        self.target = "local"
        self.auth_path = Path(auth_path or Path(settings.BASE_DIR) / "ps_vm" / "acroweb_local_auth_data.json")
        self.auth = load_local_auth_data(self.auth_path)
        self.client = APIClient()
        self.client.raise_request_exception = False
        self.client.force_authenticate(user=self.auth, token="debug-local-token")
        self.client.defaults["HTTP_HOST"] = "localhost"
        self.client.defaults["HTTP_ORIGIN"] = "http://localhost"
        self.client.defaults["HTTP_AUTHORIZATION"] = "bearer REDACTED"
        self.client.defaults[self._domain_header_name()] = self.auth.domain or ""
        self._dispatch = self._build_dispatch()
        self._validate_dispatch_coverage()

    def _build_dispatch(self) -> dict[str, Any]:
        return {
            "background_layer": self._run_background_layer,
            "ancillary_layer": self._run_ancillary_layer,
            "base_map": self._run_base_map,
            "qpf_levels": self._run_qpf_levels,
            "ps_icons": self._run_ps_icons,
            "current_qpf": self._run_current_qpf,
            "current_ps": self._run_current_ps,
            "save_current_qpf": self._run_save_current_qpf,
            "save_current_ps": self._run_save_current_ps,
            "clear_current_qpf": self._run_clear_current_qpf,
            "clear_current_ps": self._run_clear_current_ps,
            "current_qpf_item": self._run_current_qpf_item,
            "current_ps_item": self._run_current_ps_item,
        }

    def run(self, endpoints: Iterable[str] | None = None, *, read_only: bool = False) -> list[ApiCallResult]:
        requested = list(endpoints or AVAILABLE_ENDPOINTS)
        if read_only:
            requested = [endpoint for endpoint in requested if endpoint not in WRITE_ENDPOINTS]

        results: list[ApiCallResult] = []
        with self._patched_side_effects():
            for endpoint in requested:
                results.extend(self._dispatch[endpoint]())
        return results

    def results_to_json(self, results: list[ApiCallResult]) -> str:
        payload = [result.to_dict() for result in results]
        return json.dumps(payload, indent=2, ensure_ascii=False, cls=DjangoJSONEncoder)

    def _domain_header_name(self) -> str:
        return f"HTTP_{self._domain_request_header_name().upper().replace('-', '_')}"

    def _domain_request_header_name(self) -> str:
        return getattr(settings, "DOMAIN_HEADERS_KEY", "acroweb3-domain")

    def _validate_dispatch_coverage(self) -> None:
        missing = [endpoint for endpoint in AVAILABLE_ENDPOINTS if endpoint not in self._dispatch]
        extras = [endpoint for endpoint in self._dispatch if endpoint not in AVAILABLE_ENDPOINTS]
        if missing or extras:
            message = {
                "missing_dispatch_handlers": missing,
                "unexpected_dispatch_handlers": extras,
            }
            raise ValueError(f"API runner dispatch mismatch: {message}")

    @contextmanager
    def _patched_side_effects(self):
        yield

    def _jsonable(self, data: Any) -> Any:
        if isinstance(data, dict):
            return {str(key): self._jsonable(value) for key, value in data.items()}
        if isinstance(data, (list, tuple, set)):
            return [self._jsonable(item) for item in data]
        if isinstance(data, bytes):
            return {
                "type": "bytes",
                "length": len(data),
            }
        try:
            return json.loads(json.dumps(data, cls=DjangoJSONEncoder))
        except TypeError:
            return str(data)

    def _extract_response_data(self, response) -> Any:
        if hasattr(response, "data"):
            return self._jsonable(response.data)

        content_type = ""
        if hasattr(response, "headers"):
            content_type = response.headers.get("Content-Type", "")
        content = getattr(response, "content", b"")
        if isinstance(content, bytes):
            content = content.decode("utf-8", errors="replace")
        if "json" in content_type:
            try:
                return json.loads(content)
            except Exception:
                return content
        return content

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        payload: Any = None,
        format_name: str = "json",
    ):
        caller = getattr(self.client, method.lower())
        if method.upper() == "GET":
            return caller(path, data=params or {}, format=format_name)
        return caller(path, data=payload or {}, format=format_name)

    def _call(
        self,
        *,
        name: str,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        payload: Any = None,
        format_name: str = "json",
        meta: dict[str, Any] | None = None,
    ) -> ApiCallResult:
        try:
            response = self._request(method, path, params=params, payload=payload, format_name=format_name)
            data = self._extract_response_data(response)
            status_code = response.status_code
            ok = 200 <= response.status_code < 300
        except Exception as exc:
            data = {
                "exception_type": exc.__class__.__name__,
                "exception": str(exc),
                "traceback": traceback.format_exc(),
            }
            status_code = 500
            ok = False

        return ApiCallResult(
            name=name,
            method=method.upper(),
            path=path,
            params=params or {},
            payload=self._jsonable(payload),
            status_code=status_code,
            ok=ok,
            response_data=data,
            meta=meta or {},
        )

    def _run_background_layer(self) -> list[ApiCallResult]:
        return [
            self._call(
                name="background_layer",
                method="GET",
                path=f"{BASE_PATH}/background_layer/",
            )
        ]

    def _run_ancillary_layer(self) -> list[ApiCallResult]:
        return [
            self._call(
                name="ancillary_layer",
                method="GET",
                path=f"{BASE_PATH}/ancillary_layer/",
            )
        ]

    def _run_base_map(self) -> list[ApiCallResult]:
        return [
            self._call(
                name="base_map",
                method="GET",
                path=f"{BASE_PATH}/base_map/",
            )
        ]

    def _run_qpf_levels(self) -> list[ApiCallResult]:
        """Legge il catalogo dei livelli QPF attivi nell'ordine previsto dal client."""
        return [
            self._call(
                name="qpf_levels",
                method="GET",
                path=f"{BASE_PATH}/qpf_levels/",
            )
        ]

    def _run_ps_icons(self) -> list[ApiCallResult]:
        """Legge i fenomeni PS attivi con il relativo catalogo di icone attive."""
        return [
            self._call(
                name="ps_icons",
                method="GET",
                path=f"{BASE_PATH}/ps_icons/",
            )
        ]

    def _run_current_qpf(self) -> list[ApiCallResult]:
        """Legge lo stato QPF corrente completo, raggruppato nelle mappe D0-D2."""
        return [
            self._call(
                name="current_qpf",
                method="GET",
                path=f"{BASE_PATH}/current_qpf/",
            )
        ]

    def _run_current_ps(self) -> list[ApiCallResult]:
        """Legge lo stato PS corrente completo, inclusi gli anchor delle icone."""
        return [
            self._call(
                name="current_ps",
                method="GET",
                path=f"{BASE_PATH}/current_ps/",
            )
        ]

    def _run_save_current_qpf(self) -> list[ApiCallResult]:
        """Verifica il salvataggio QPF rileggendo e riscrivendo invariato lo stato D0."""
        source = self._call(
            name="get_current_qpf_source",
            method="GET",
            path=f"{BASE_PATH}/current_qpf/",
            params={"map_id": "d0"},
        )
        if not source.ok:
            return [source]

        maps = source.response_data.get("maps", [])
        zones = maps[0].get("zones", []) if maps else []
        payload = {
            "map_id": "d0",
            "zones": [
                {
                    "zone_id": item["zone_id"],
                    "qpf_level_id": item["qpf"]["id"],
                    "custom_description": item.get("custom_description", ""),
                }
                for item in zones
            ],
        }
        return [
            source,
            self._call(
                name="save_current_qpf",
                method="POST",
                path=f"{BASE_PATH}/save_current_qpf/",
                payload=payload,
            ),
        ]

    def _run_save_current_ps(self) -> list[ApiCallResult]:
        """Verifica il salvataggio PS rileggendo e riscrivendo invariato lo stato D0."""
        source = self._call(
            name="get_current_ps_source",
            method="GET",
            path=f"{BASE_PATH}/current_ps/",
            params={"map_id": "d0"},
        )
        if not source.ok:
            return [source]

        maps = source.response_data.get("maps", [])
        icons = maps[0].get("icons", []) if maps else []
        payload = {
            "map_id": "d0",
            "icons": [
                {
                    "zone_id": item["zone_id"],
                    "phenomenon_type_id": item["phenomenon"]["id"],
                    "ps_level_id": item["ps_level"]["id"],
                    "icon_slot": item["icon_slot"],
                    "custom_description": item.get("custom_description", ""),
                }
                for item in icons
            ],
        }
        return [
            source,
            self._call(
                name="save_current_ps",
                method="POST",
                path=f"{BASE_PATH}/save_current_ps/",
                payload=payload,
            ),
        ]

    def _run_clear_current_qpf(self) -> list[ApiCallResult]:
        """Esegue il reset VM completo di D0 e ripristina lo stato precedente."""
        source = self._call(
            name="get_clear_current_qpf_source",
            method="GET",
            path=f"{BASE_PATH}/current_qpf/",
            params={"map_id": "d0"},
        )
        if not source.ok:
            return [source]

        maps = source.response_data.get("maps", [])
        zones = maps[0].get("zones", []) if maps else []
        clear_result = self._call(
            name="clear_current_qpf",
            method="DELETE",
            path=f"{BASE_PATH}/current_qpf/d0/",
        )
        restore_result = self._call(
            name="restore_after_clear_current_qpf",
            method="POST",
            path=f"{BASE_PATH}/save_current_qpf/",
            payload={
                "map_id": "d0",
                "zones": [
                    {
                        "zone_id": item["zone_id"],
                        "qpf_level_id": item["qpf"]["id"],
                        "custom_description": item.get("custom_description", ""),
                    }
                    for item in zones
                ],
            },
        )
        return [source, clear_result, restore_result]

    def _run_clear_current_ps(self) -> list[ApiCallResult]:
        """Cancella tutte le icone PS di D0 e ripristina lo stato precedente."""
        source = self._call(
            name="get_clear_current_ps_source",
            method="GET",
            path=f"{BASE_PATH}/current_ps/",
            params={"map_id": "d0"},
        )
        if not source.ok:
            return [source]

        maps = source.response_data.get("maps", [])
        icons = maps[0].get("icons", []) if maps else []
        clear_result = self._call(
            name="clear_current_ps",
            method="DELETE",
            path=f"{BASE_PATH}/current_ps/d0/",
        )
        restore_result = self._call(
            name="restore_after_clear_current_ps",
            method="POST",
            path=f"{BASE_PATH}/save_current_ps/",
            payload={
                "map_id": "d0",
                "icons": [
                    {
                        "zone_id": item["zone_id"],
                        "phenomenon_type_id": item["phenomenon"]["id"],
                        "ps_level_id": item["ps_level"]["id"],
                        "icon_slot": item["icon_slot"],
                        "custom_description": item.get("custom_description", ""),
                    }
                    for item in icons
                ],
            },
        )
        return [source, clear_result, restore_result]

    def _run_current_qpf_item(self) -> list[ApiCallResult]:
        """Verifica modifica e reset di una zona VM, poi ripristina il valore."""
        source = self._call(
            name="get_current_qpf_item_source",
            method="GET",
            path=f"{BASE_PATH}/current_qpf/",
            params={"map_id": "d0"},
        )
        if not source.ok:
            return [source]

        maps = source.response_data.get("maps", [])
        zones = maps[0].get("zones", []) if maps else []
        if not zones:
            return [
                source,
                ApiCallResult(
                    name="current_qpf_item",
                    method="PUT",
                    path=f"{BASE_PATH}/current_qpf/d0/{{zone_id}}/",
                    skipped=True,
                    skip_reason="La mappa d0 non contiene assegnazioni QPF.",
                ),
            ]

        item = zones[0]
        path = f"{BASE_PATH}/current_qpf/d0/{item['zone_id']}/"
        payload = {
            "qpf_level_id": item["qpf"]["id"],
            "custom_description": item.get("custom_description", ""),
        }
        return [
            source,
            self._call(
                name="current_qpf_item_upsert",
                method="PUT",
                path=path,
                payload=payload,
            ),
            self._call(
                name="current_qpf_item_reset",
                method="DELETE",
                path=path,
            ),
            self._call(
                name="restore_after_current_qpf_item",
                method="PUT",
                path=path,
                payload=payload,
            ),
        ]

    def _run_current_ps_item(self) -> list[ApiCallResult]:
        """Verifica modifica e cancellazione di un'icona PS, poi la ripristina."""
        source = self._call(
            name="get_current_ps_item_source",
            method="GET",
            path=f"{BASE_PATH}/current_ps/",
            params={"map_id": "d0"},
        )
        if not source.ok:
            return [source]

        maps = source.response_data.get("maps", [])
        icons = maps[0].get("icons", []) if maps else []
        if not icons:
            return [
                source,
                ApiCallResult(
                    name="current_ps_item",
                    method="PUT",
                    path=f"{BASE_PATH}/current_ps/d0/{{zone_id}}/{{icon_slot}}/",
                    skipped=True,
                    skip_reason="La mappa d0 non contiene icone PS.",
                ),
            ]

        item = icons[0]
        path = (
            f"{BASE_PATH}/current_ps/d0/"
            f"{item['zone_id']}/{item['icon_slot']}/"
        )
        payload = {
            "phenomenon_type_id": item["phenomenon"]["id"],
            "ps_level_id": item["ps_level"]["id"],
            "custom_description": item.get("custom_description", ""),
        }
        return [
            source,
            self._call(
                name="current_ps_item_upsert",
                method="PUT",
                path=path,
                payload=payload,
            ),
            self._call(
                name="current_ps_item_delete",
                method="DELETE",
                path=path,
            ),
            self._call(
                name="restore_after_current_ps_item",
                method="PUT",
                path=path,
                payload=payload,
            ),
        ]
