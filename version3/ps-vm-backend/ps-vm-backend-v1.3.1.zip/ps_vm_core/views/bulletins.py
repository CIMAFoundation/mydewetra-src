import logging
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from django.conf import settings
from django.http import HttpResponse
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from ps_vm_core.bulletin_serializers import (
    PsBulletinDetailSerializer,
    PsBulletinListSerializer,
    PsBulletinWriteSerializer,
    VmBulletinDetailSerializer,
    VmBulletinListSerializer,
    VmBulletinWriteSerializer,
)
from ps_vm_core.bulletins import finalize_draft, initialize_draft, refresh_draft
from ps_vm_core.models import (
    BulletinProduct,
    BulletinStatus,
    PsBulText,
    VmBulText,
)
from ps_vm_core.pdf_archive_storage import (
    PdfArchiveStorageError,
    build_filename,
    get_archive,
    read_pdf_bytes,
    save_pdf_bytes,
)
from ps_vm_core.print_service import PrintServicePdfError, get_printed_pdf


logger = logging.getLogger(__name__)


def _add_portaluser_to_template_url(template_url, portaluser):
    portaluser = str(portaluser or "").strip()
    if not template_url or not portaluser:
        return template_url

    parts = urlsplit(template_url)
    if parts.fragment:
        fragment_path, _separator, fragment_query = parts.fragment.partition("?")
        query = dict(parse_qsl(fragment_query, keep_blank_values=True))
        query["portaluser"] = portaluser
        fragment = f"{fragment_path}?{urlencode(query, safe='@')}"
        return urlunsplit(parts._replace(fragment=fragment))

    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    query["portaluser"] = portaluser
    return urlunsplit(parts._replace(query=urlencode(query, safe="@")))


class BulletinViewSet(viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    product = None
    detail_serializer_class = None
    list_serializer_class = None
    write_serializer_class = None

    def get_serializer_class(self):
        if self.action == "list":
            return self.list_serializer_class
        if self.action == "partial_update":
            return self.write_serializer_class
        return self.detail_serializer_class

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        return Response(self.list_serializer_class(queryset, many=True).data)

    def retrieve(self, request, *args, **kwargs):
        return Response(self.detail_serializer_class(self.get_object()).data)

    def partial_update(self, request, *args, **kwargs):
        bulletin = self.get_object()
        if bulletin.status != BulletinStatus.DRAFT:
            return Response(
                {"status": "Un bollettino finalizzato è immutabile."},
                status=status.HTTP_409_CONFLICT,
            )
        serializer = self.write_serializer_class(
            bulletin,
            data=request.data,
            partial=True,
        )
        serializer.is_valid(raise_exception=True)
        bulletin = serializer.save()
        return Response(self.detail_serializer_class(bulletin).data)

    @action(detail=False, methods=["post"], url_path="draft")
    def draft(self, request):
        bulletin, created = initialize_draft(self.product, request.user)
        response_status = status.HTTP_201_CREATED if created else status.HTTP_200_OK
        data = self.detail_serializer_class(bulletin).data
        data["created"] = created
        return Response(data, status=response_status)

    @action(detail=True, methods=["post"])
    def refresh(self, request, pk=None):
        bulletin = self.get_object()
        if bulletin.status != BulletinStatus.DRAFT:
            return Response(
                {"status": "Un bollettino finalizzato è immutabile."},
                status=status.HTTP_409_CONFLICT,
            )
        bulletin = refresh_draft(bulletin.pk, self.product)
        return Response(self.detail_serializer_class(bulletin).data)

    @action(detail=True, methods=["post"])
    def finalize(self, request, pk=None):
        self.get_object()
        bulletin, finalized = finalize_draft(pk, self.product, request.user)
        data = self.detail_serializer_class(bulletin).data
        data["finalized"] = finalized
        return Response(data)

    def _resolve_pdf_template_url(self, request, bulletin):
        base_url = settings.PRINT_CLIENT_PDF_BASE_URL
        if base_url:
            values = {
                "product": self.product,
                "bulletin_type": self.product,
                "bulletin_id": bulletin.pk,
                "id": bulletin.pk,
            }
            if "{" in base_url:
                try:
                    template_url = base_url.format(**values)
                except (KeyError, ValueError) as exc:
                    raise PrintServicePdfError(
                        "Errore: PRINT_CLIENT_PDF_BASE_URL non valido"
                    ) from exc
            else:
                # PS and VMN use independent tables, so both the product and id
                # are part of the client print route.
                template_url = (
                    f"{base_url.rstrip('/')}/{self.product}/{bulletin.pk}"
                )
        else:
            template_url = request.query_params.get("pdftemplateurl", "").strip()

        portaluser = (
            getattr(request.user, "user", None)
            or getattr(request.user, "username", None)
            or getattr(request.user, "email", None)
        )
        return _add_portaluser_to_template_url(template_url, portaluser)

    @action(detail=True, methods=["get"])
    def pdf(self, request, pk=None):
        """Render through the client template and archive the result on S3."""
        bulletin = self.get_object()
        force = request.query_params.get("force", "false").lower() == "true"
        archive = get_archive(bulletin)

        # Drafts can still change. Like a live preview, always render them from
        # the current client template; finalized bulletins use the S3 archive.
        use_archive = (
            archive is not None
            and archive.s3_bucket
            and archive.s3_key
            and bulletin.status == BulletinStatus.FINALIZED
            and not force
        )
        try:
            if use_archive:
                pdf_content = read_pdf_bytes(archive)
            else:
                template_url = self._resolve_pdf_template_url(request, bulletin)
                logger.info(
                    "Resolved printservice PDF template URL for %s bulletin %s: %s",
                    self.product,
                    bulletin.pk,
                    template_url,
                )
                pdf_content = get_printed_pdf(template_url)
                archive = save_pdf_bytes(bulletin, pdf_content)
        except (PrintServicePdfError, PdfArchiveStorageError) as exc:
            logger.error("Cannot produce %s bulletin PDF: %s", self.product, exc)
            return Response(str(exc), status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except Exception:
            logger.exception("Cannot archive %s bulletin PDF", self.product)
            return Response(
                "Errore: impossibile archiviare il PDF su S3",
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        filename = archive.filename if archive else build_filename(bulletin)
        disposition = (
            "attachment"
            if request.query_params.get("isdownload", "false").lower() == "true"
            else "inline"
        )
        response = HttpResponse(pdf_content, content_type="application/pdf")
        response["Access-Control-Expose-Headers"] = "Content-Disposition"
        response["Content-Disposition"] = f'{disposition}; filename="{filename}"'
        return response


class PsBulletinViewSet(BulletinViewSet):
    product = BulletinProduct.PS
    detail_serializer_class = PsBulletinDetailSerializer
    list_serializer_class = PsBulletinListSerializer
    write_serializer_class = PsBulletinWriteSerializer

    def get_queryset(self):
        return PsBulText.objects.select_related("user").order_by("-created_at", "-id")


class VmBulletinViewSet(BulletinViewSet):
    product = BulletinProduct.VMN
    detail_serializer_class = VmBulletinDetailSerializer
    list_serializer_class = VmBulletinListSerializer
    write_serializer_class = VmBulletinWriteSerializer

    def get_queryset(self):
        return VmBulText.objects.select_related("user").order_by("-created_at", "-id")
