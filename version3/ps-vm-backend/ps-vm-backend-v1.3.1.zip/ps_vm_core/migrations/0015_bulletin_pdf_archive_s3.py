from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("ps_vm_core", "0014_bulletin_previews"),
    ]

    operations = [
        migrations.AlterField(
            model_name="bulletinpdfarchive",
            name="file",
            field=models.FileField(
                blank=True,
                null=True,
                upload_to="bulletin_pdfs/",
            ),
        ),
        migrations.AddField(
            model_name="bulletinpdfarchive",
            name="s3_bucket",
            field=models.CharField(blank=True, max_length=255, null=True),
        ),
        migrations.AddField(
            model_name="bulletinpdfarchive",
            name="s3_content_type",
            field=models.CharField(default="application/pdf", max_length=64),
        ),
        migrations.AddField(
            model_name="bulletinpdfarchive",
            name="s3_etag",
            field=models.CharField(blank=True, max_length=128, null=True),
        ),
        migrations.AddField(
            model_name="bulletinpdfarchive",
            name="s3_key",
            field=models.CharField(
                blank=True,
                max_length=512,
                null=True,
                unique=True,
            ),
        ),
        migrations.AddField(
            model_name="bulletinpdfarchive",
            name="s3_last_uploaded_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="bulletinpdfarchive",
            name="s3_size",
            field=models.PositiveBigIntegerField(blank=True, null=True),
        ),
    ]
