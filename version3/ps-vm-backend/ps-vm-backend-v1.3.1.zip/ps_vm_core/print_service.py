import requests
from django.conf import settings


class PrintServicePdfError(Exception):
    pass


def build_pdf_request(template_url, timeout=None):
    template_url = (template_url or "").strip()
    if not template_url:
        raise PrintServicePdfError("Errore: parametro pdftemplateurl mancante")

    return {
        "url": template_url,
        "timeout": (
            settings.PRINTSERVICE_PDF_TIMEOUT if timeout is None else timeout
        ),
    }


def get_printed_pdf(template_url, timeout=None):
    """Ask the same URL-driven printservice used by RiskAlert for a PDF."""
    printservice_url = settings.PRINTSERVICE_PDF_URL.strip()
    if not printservice_url:
        raise PrintServicePdfError(
            "Errore: URL printservice PDF non configurato"
        )

    request_data = build_pdf_request(template_url, timeout=timeout)
    try:
        response = requests.post(
            printservice_url,
            json=request_data,
            headers={"Content-Type": "application/json"},
            timeout=request_data["timeout"],
        )
    except requests.RequestException as exc:
        raise PrintServicePdfError(
            f"Errore: impossibile contattare il printservice PDF ({exc})"
        ) from exc

    if response.status_code != 200:
        raise PrintServicePdfError(
            "Errore: printservice PDF ha risposto con stato "
            f"{response.status_code}"
        )

    content_type = response.headers.get("Content-Type", "").lower()
    accepted_types = ("application/pdf", "application/octet-stream")
    if content_type and not any(value in content_type for value in accepted_types):
        raise PrintServicePdfError(
            "Errore: content-type inatteso dal printservice PDF "
            f"({content_type})"
        )
    if not response.content:
        raise PrintServicePdfError(
            "Errore: il printservice PDF ha restituito un file vuoto"
        )

    return response.content
