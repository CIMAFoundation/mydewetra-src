from datetime import date
from types import SimpleNamespace
from unittest import mock

import requests
from django.test import SimpleTestCase, override_settings

from ps_vm_core.models import BulletinKind, PsBulText, VmBulText
from ps_vm_core.pdf_archive_storage import build_filename, build_s3_key
from ps_vm_core.print_service import PrintServicePdfError, get_printed_pdf
from ps_vm_core.views.bulletins import (
    VmBulletinViewSet,
    _add_portaluser_to_template_url,
)


class PdfServiceTests(SimpleTestCase):
    @override_settings(
        PRINTSERVICE_PDF_URL="http://printservice:8989/pdf",
        PRINTSERVICE_PDF_TIMEOUT=500,
    )
    @mock.patch("ps_vm_core.print_service.requests.post")
    def test_printservice_contract_matches_riskalert(self, post):
        post.return_value = mock.Mock(
            status_code=200,
            content=b"%PDF rendered",
            headers={"Content-Type": "application/pdf"},
        )

        result = get_printed_pdf("http://portal/bvps/#/print/ps/7")

        self.assertEqual(result, b"%PDF rendered")
        post.assert_called_once_with(
            "http://printservice:8989/pdf",
            json={
                "url": "http://portal/bvps/#/print/ps/7",
                "timeout": 500,
            },
            headers={"Content-Type": "application/json"},
            timeout=500,
        )

    @override_settings(
        PRINTSERVICE_PDF_URL="http://printservice:8989/pdf",
        PRINTSERVICE_PDF_TIMEOUT=500,
    )
    @mock.patch("ps_vm_core.print_service.requests.post")
    def test_printservice_network_error_is_normalized(self, post):
        post.side_effect = requests.Timeout("timeout")

        with self.assertRaises(PrintServicePdfError):
            get_printed_pdf("http://portal/bvps/#/print/ps/7")

    def test_portaluser_is_added_inside_hash_route(self):
        self.assertEqual(
            _add_portaluser_to_template_url(
                "http://portal/bvps/#/print/vmn/9",
                "mario.rossi@cimafoundation.org",
            ),
            "http://portal/bvps/#/print/vmn/9?"
            "portaluser=mario.rossi@cimafoundation.org",
        )

    @override_settings(
        PRINT_CLIENT_PDF_BASE_URL="http://cima-service-portal.bricks-dev/bvps/#/print/"
    )
    def test_vmn_template_url_contains_product_discriminator(self):
        view = VmBulletinViewSet()
        request = SimpleNamespace(
            query_params={},
            user=SimpleNamespace(username="operator"),
        )

        template_url = view._resolve_pdf_template_url(
            request,
            VmBulText(id=12),
        )

        self.assertEqual(
            template_url,
            "http://cima-service-portal.bricks-dev/bvps/"
            "#/print/vmn/12?portaluser=operator",
        )

    @override_settings(PDF_ARCHIVE_S3_BUCKET_BASE_PATH="ps-vm/pdf")
    def test_s3_key_separates_product_and_operational_date(self):
        bulletin = PsBulText(
            id=7,
            operational_date=date(2026, 9, 7),
            day_string="20260907",
            bull_type=BulletinKind.FIRST,
            is_preview=False,
            user_id=12,
        )

        self.assertEqual(
            build_filename(bulletin),
            "ps_12_20260907_first_7.pdf",
        )
        self.assertEqual(
            build_s3_key(bulletin),
            "ps-vm/pdf/ps/2026/09/07/ps_12_20260907_first_7.pdf",
        )
