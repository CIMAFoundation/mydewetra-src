import hashlib

import boto3
from botocore.exceptions import ClientError
from django.conf import settings
from django.utils import timezone

from ps_vm_core.models import (
    BulletinPdfArchive,
    BulletinProduct,
    PsBulText,
    VmBulText,
)


PDF_CONTENT_TYPE = "application/pdf"


class PdfArchiveStorageError(Exception):
    pass


def _s3_client():
    kwargs = {}
    access_key_id = REDACTED
    secret_access_key = REDACTED
    if access_key_id and secret_access_key:
        kwargs["aws_access_key_id"] = access_key_id
        kwargs["aws_secret_access_key"] = secret_access_key
    return boto3.client("s3", **kwargs)


def _configured_bucket():
    bucket = settings.PDF_ARCHIVE_S3_BUCKET_NAME
    if not bucket:
        raise PdfArchiveStorageError(
            "Il bucket S3 dell'archivio PDF non è configurato"
        )
    return bucket


def bulletin_product(bulletin):
    if isinstance(bulletin, PsBulText):
        return BulletinProduct.PS
    if isinstance(bulletin, VmBulText):
        return BulletinProduct.VMN
    raise TypeError("Tipo di bollettino non supportato")


def build_filename(bulletin):
    preview_suffix = "_preview" if bulletin.is_preview else ""
    user_id = bulletin.user_id if bulletin.user_id is not None else "system"
    return (
        f"{bulletin_product(bulletin)}_{user_id}_{bulletin.day_string}_"
        f"{bulletin.bull_type}{preview_suffix}_{bulletin.pk}.pdf"
    )


def build_s3_key(bulletin, prefix=None):
    base_path = (
        settings.PDF_ARCHIVE_S3_BUCKET_BASE_PATH if prefix is None else prefix
    )
    base_path = (base_path or "").strip("/")
    operational_date = bulletin.operational_date
    relative_path = (
        f"{bulletin_product(bulletin)}/{operational_date:%Y/%m/%d}/"
        f"{build_filename(bulletin)}"
    )
    return f"{base_path}/{relative_path}" if base_path else relative_path


def get_archive(bulletin):
    lookup = (
        {"ps_bulletin": bulletin}
        if bulletin_product(bulletin) == BulletinProduct.PS
        else {"vm_bulletin": bulletin}
    )
    return BulletinPdfArchive.objects.filter(is_signed=False, **lookup).first()


def save_pdf_bytes(bulletin, pdf_content, *, bucket=None, prefix=None, client=None):
    if not pdf_content:
        raise PdfArchiveStorageError("Impossibile archiviare un PDF vuoto")

    product = bulletin_product(bulletin)
    bucket = bucket or _configured_bucket()
    key = REDACTED
    client = client or _s3_client()
    previous_archive = get_archive(bulletin)
    previous_location = (
        (previous_archive.s3_bucket, previous_archive.s3_key)
        if previous_archive and previous_archive.s3_bucket and previous_archive.s3_key
        else None
    )
    response = client.put_object(
        Bucket=bucket,
        Key=REDACTED
        Body=pdf_content,
        ContentType=PDF_CONTENT_TYPE,
    )
    etag = (response.get("ETag") or "").strip('"') or None
    digest = hashlib.sha256(pdf_content).hexdigest()
    relation_fields = (
        {"ps_bulletin": bulletin, "vm_bulletin": None}
        if product == BulletinProduct.PS
        else {"ps_bulletin": None, "vm_bulletin": bulletin}
    )
    try:
        archive = previous_archive or BulletinPdfArchive(**relation_fields)
        archive.bulletin_type = product
        archive.file = None
        archive.filename = build_filename(bulletin)
        archive.content_type = PDF_CONTENT_TYPE
        archive.size = len(pdf_content)
        archive.sha256 = digest
        archive.is_signed = False
        archive.s3_bucket = bucket
        archive.s3_key = key
        archive.s3_etag = etag
        archive.s3_size = len(pdf_content)
        archive.s3_content_type = PDF_CONTENT_TYPE
        archive.s3_last_uploaded_at = timezone.now()
        archive.save()
    except Exception:
        if previous_location != (bucket, key):
            try:
                client.delete_object(Bucket=bucket, Key=key)
            except Exception:
                pass
        raise
    if previous_location and previous_location != (bucket, key):
        try:
            client.delete_object(
                Bucket=previous_location[0],
                Key=REDACTED
            )
        except Exception:
            # The new object and its authoritative DB metadata are already
            # valid; failure to clean a superseded preview must not undo them.
            pass
    return archive


def read_pdf_bytes(bulletin_or_archive, *, client=None):
    archive = (
        bulletin_or_archive
        if isinstance(bulletin_or_archive, BulletinPdfArchive)
        else get_archive(bulletin_or_archive)
    )
    if archive is None:
        raise PdfArchiveStorageError("PDF non presente in archivio")
    if not archive.s3_bucket or not archive.s3_key:
        raise PdfArchiveStorageError("Il PDF archiviato non ha metadati S3")

    client = client or _s3_client()
    try:
        response = client.get_object(Bucket=archive.s3_bucket, Key=archive.s3_key)
    except ClientError as exc:
        raise PdfArchiveStorageError(
            f"Impossibile leggere il PDF dall'archivio S3 ({exc})"
        ) from exc
    return response["Body"].read()
