# Conversione delle QPF sorgenti nei livelli delle ZVM intermedie

## Scopo

I valori QPF inseriti nelle mappe sorgente (`min`, `max` e durata) determinano
il livello e il colore di una Zona di Vigilanza Meteo (ZVM) nella mappa
intermedia. La conversione avviene con:

```http
POST /api/promote_source_maps/
```

La promozione ricostruisce le mappe intermedie `d0`, `d1` e `d2`, sostituendo
eventuali modifiche manuali precedenti.

## Soglie uniformi su max_mm

Tutte le ZVM usano le stesse soglie:

| Intervallo di `max_mm` | Livello | Codice backend | Colore |
| --- | ---: | --- | --- |
| `< 5 mm` | 0, Assenti o deboli non rilevanti | `assenti_o_deboli_non_rilevanti` | `#ffffff` |
| `5 ≤ max_mm < 20 mm` | 1, Deboli | `deboli` | `#c5ffff` |
| `20 ≤ max_mm < 60 mm` | 2, Moderate | `moderate` | `#7affff` |
| `60–100 mm` | 3, Elevate | `elevate` | `#009cff` |
| `> 100 mm` | 4, Molto elevate | `molto_elevate` | `#857bfe` |

La tabella `ps_vm_core_qpf_threshold_24h` contiene una riga per ZVM con i
campi `weak_mm=5`, `moderate_mm=20`, `elevated_mm=60` e
`very_elevated_mm=100`. Il nome storico della tabella resta invariato; le soglie
si applicano direttamente a `max_mm`, indipendentemente dalla durata. Le prime tre soglie usano un confronto inclusivo;
quella di `Molto elevate` usa il confronto stretto `>100`, come richiesto
dalla politica.

Le soglie devono rispettare:

```text
0 < weak_mm < moderate_mm < elevated_mm < very_elevated_mm
```

La configurazione effettiva è consultabile con:

```http
GET /api/qpf_thresholds/
```

## Calcolo

Per ogni riga (definizione QPF + intervallo giornaliero) il sistema considera
soltanto `max_mm`, senza riscalarlo in base a `duration_hours`.

La classificazione procede dalla soglia più severa:

```text
if max_mm > very_elevated_mm:
    severity = 4
elif max_mm >= elevated_mm:
    severity = 3
elif max_mm >= moderate_mm:
    severity = 2
elif max_mm >= weak_mm:
    severity = 1
else:
    severity = 0
```

Ogni riga viene classificata separatamente; alla zona viene assegnata la
severità massima tra tutte le durate e tutti gli intervalli giornalieri.
L'intervallo identifica quando è attesa la precipitazione, ma non modifica la
formula. `min_mm` e le classificazioni di precipitazione impulsiva e non
impulsiva non determinano il colore.

L'algoritmo condiviso da promozione e rollover si trova in
`ps_vm_core/qpf_conversion.py`:

- `amount_severity()` classifica una singola quantità;
- `qpf_amounts_severity()` sceglie la severità massima della zona.

`PromoteSourceMapsResView.post()` in `ps_vm_core/views/promotion.py` ricrea
le campiture intermedie. Il comando `rollover_current_maps` usa lo stesso
algoritmo per ricostruire il nuovo D0, dopo l'eliminazione delle quantità
mattutine e l'aggiornamento degli intervalli. Il ricalcolo sostituisce i livelli
manuali di D0; il passaggio D2 → D1 conserva invece lo stato intermedio.

Se manca la riga delle soglie per una ZVM presente nelle sorgenti, la
promozione restituisce `400 Bad Request`. L'operazione è atomica e lascia
invariate le mappe intermedie precedenti.

## Esempi

Per qualsiasi durata ammessa, i valori di confine producono:

| `max_mm` | Risultato |
| ---: | --- |
| 4 | Assenti o deboli non rilevanti |
| 5 | Deboli |
| 19 | Deboli |
| 20 | Moderate |
| 59 | Moderate |
| 60 | Elevate |
| 100 | Elevate |
| 101 | Molto elevate |

`max_mm=19` produce `Deboli` sia su 3 ore sia su 24 ore.

Se una zona contiene contemporaneamente `max_mm=60` su 24 ore (`Elevate`) e
`max_mm=19` su 3 ore (`Deboli`), anche se associati a intervalli
giornalieri diversi, prevale `Elevate`.

La struttura può inoltre contenere la stessa definizione, per esempio
`5-20 mm / 6h`, su `d0` `12-18`, `d1` `06-12` e `d1` `12-18`: tutte e tre le
righe partecipano al calcolo e il risultato della ZVM resta il peggiore.
