from datetime import date
from io import BytesIO, StringIO
from types import SimpleNamespace
from unittest import mock

from django.contrib.auth import get_user_model
from django.contrib.gis.geos import GEOSGeometry, Point
from django.core.management import call_command
from django.test import override_settings
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from ps_vm_core.models import (
    BulletinKind,
    BulletinPdfArchive,
    BulletinProduct,
    BulletinSequence,
    BulletinSettings,
    BulletinStatus,
    CurPs,
    CurQpf,
    DailyPrecipitationInterval,
    ImpulsivePrecipitationType,
    MapId,
    MapOperationalState,
    NonImpulsivePrecipitationType,
    PhenomenonType,
    PsBulText,
    PsLevel,
    QpfLevel,
    QpfThreshold24h,
    Region,
    SourceQpf,
    SourceQpfAmount,
    VmBulText,
    ZoneIconAnchor,
    ZoneVigilanzaMeteo,
    ZoneVigilanzaMeteoRegion,
)
from ps_vm_core.pdf_archive_storage import (
    build_s3_key,
    read_pdf_bytes,
    save_pdf_bytes,
)


class BulletinApiTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username="bulletin-user")
        self.client.force_authenticate(self.user)
        self.region = Region.objects.create(code="LAZ", name="Lazio")
        self.zone_a = self._zone("A", "Zona Alfa")
        self.zone_b = self._zone("B", "Zona Beta")
        self.zone_out = self._zone("OUT", "Zona esclusa")
        self.zone_a.regions.add(self.region)
        self.zone_b.regions.add(self.region)
        settings, _created = BulletinSettings.objects.get_or_create(
            bulletin_type=BulletinProduct.PS,
            user=None,
        )
        settings.is_active = True
        settings.save()
        settings.qpf_regions.set([self.region])

        self.rain = PhenomenonType.objects.get(code="piogge")
        self.rain_isolated = PsLevel.objects.get(
            phenomenon_type=self.rain,
            code="piogge_isolate",
        )
        self.rain_sparse = PsLevel.objects.get(
            phenomenon_type=self.rain,
            code="piogge_sparse",
        )
        self.storm = PhenomenonType.objects.get(code="temporali")
        self.shower_isolated = PsLevel.objects.get(
            phenomenon_type=self.storm,
            code="rovesci_isolati",
        )
        self.storm_isolated = PsLevel.objects.get(
            phenomenon_type=self.storm,
            code="temporali_isolati",
        )
        self.qpf = QpfLevel.objects.get(code="deboli")
        for zone in (self.zone_a, self.zone_b, self.zone_out):
            ZoneIconAnchor.objects.create(
                zone=zone,
                slot=1,
                point=Point(12, 42, srid=4326),
            )
            CurQpf.objects.create(
                map_id=MapId.TODAY,
                zone=zone,
                qpf_level=self.qpf,
            )

        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone_a,
            phenomenon_type=self.rain,
            ps_level=self.rain_isolated,
            icon_slot=1,
            custom_description="in serata",
        )
        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone_b,
            phenomenon_type=self.rain,
            ps_level=self.rain_isolated,
            icon_slot=1,
            custom_description="in serata",
        )
        self._source_qpf(MapId.TODAY, self.zone_a)
        self._source_qpf(MapId.TODAY, self.zone_b)
        self._source_qpf(MapId.DAY_AFTER_TOMORROW, self.zone_a)

    def _zone(self, code, name):
        return ZoneVigilanzaMeteo.objects.create(
            code=code,
            name=name,
            geometry=GEOSGeometry(
                "MULTIPOLYGON(((10 40, 10 41, 11 41, 11 40, 10 40)))",
                srid=4326,
            ),
        )

    def _source_qpf(self, map_id, zone):
        source = SourceQpf.objects.create(
            map_id=map_id,
            zone=zone,
            non_impulsive_type=NonImpulsivePrecipitationType.objects.get(
                code="piogge_sparse"
            ),
            impulsive_type=ImpulsivePrecipitationType.objects.get(
                code="temporali_isolati"
            ),
        )
        interval = DailyPrecipitationInterval.objects.filter(day=map_id).first()
        SourceQpfAmount.objects.create(
            source_qpf=source,
            duration_hours=6,
            min_mm=5,
            max_mm=20,
            daily_precipitation_interval=interval,
        )

    def test_drafts_are_idempotent_and_products_keep_independent_texts(self):
        first = self.client.post("/api/ps_bulletins/draft/", {}, format="json")
        second = self.client.post("/api/ps_bulletins/draft/", {}, format="json")
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json")

        self.assertEqual(first.status_code, status.HTTP_201_CREATED)
        self.assertEqual(second.status_code, status.HTTP_200_OK)
        self.assertEqual(first.data["id"], second.data["id"])
        self.assertEqual(vm.status_code, status.HTTP_201_CREATED)
        self.assertEqual(PsBulText.objects.count(), 1)
        self.assertEqual(VmBulText.objects.count(), 1)
        categories = first.data["generated_sections"]["days"][0]["categories"]
        self.assertEqual(
            [item["code"] for item in categories],
            ["precipitazioni", "visibilita", "temperature", "venti", "mari"],
        )
        self.assertIn("Zona Alfa", categories[0]["generated_text"])
        self.assertEqual(categories[1]["generated_text"], "nessun fenomeno significativo.")

        edited = first.data["text_sections"]
        edited["d0"]["precipitazioni"] = "Testo PS indipendente."
        response = self.client.patch(
            f"/api/ps_bulletins/{first.data['id']}/",
            {"text_sections": edited},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertNotEqual(
            response.data["text_sections"],
            vm.data["text_sections"],
        )

    def test_ps_draft_after_rollover_keeps_matching_qpf_amounts(self):
        QpfThreshold24h.objects.create(
            zone=self.zone_a, weak_mm=10, moderate_mm=20,
            elevated_mm=50, very_elevated_mm=100,
        )
        self._source_qpf(MapId.TOMORROW, self.zone_a)
        tomorrow = SourceQpf.objects.get(map_id=MapId.TOMORROW, zone=self.zone_a)
        # Morning quantity must disappear; afternoon quantities must reach the draft.
        for day, source in (
            (MapId.TOMORROW, tomorrow),
            (MapId.DAY_AFTER_TOMORROW, SourceQpf.objects.get(
                map_id=MapId.DAY_AFTER_TOMORROW, zone=self.zone_a
            )),
        ):
            for duration in (3, 6, 12):
                SourceQpfAmount.objects.create(
                    source_qpf=source,
                    daily_precipitation_interval=DailyPrecipitationInterval.objects.get(
                        day=day, time_interval="12:00 - 18:00"
                    ),
                    duration_hours=duration,
                    min_mm=duration,
                    max_mm=duration + 10,
                )
        MapOperationalState.objects.update(last_rollover_date=None)
        call_command("rollover_current_maps", stdout=StringIO())

        response = self.client.post("/api/ps_bulletins/draft/", {}, format="json")

        self.assertEqual(response.status_code, status.HTTP_201_CREATED, response.data)
        bulletin = PsBulText.objects.get(pk=response.data["id"])
        for day, count in ((MapId.TODAY, 3), (MapId.TOMORROW, 4)):
            zone = bulletin.qpf_zones.get(map_id=day, zone=self.zone_a)
            self.assertEqual(zone.amounts.count(), count)
            for amount in zone.amounts.select_related("daily_precipitation_interval"):
                self.assertEqual(amount.interval_day, day)
                self.assertEqual(amount.daily_precipitation_interval.day, day)
            self.assertEqual(
                set(zone.amounts.filter(time_interval="12:00 - 18:00").values_list(
                    "duration_hours", "min_mm", "max_mm"
                )),
                {(duration, duration, duration + 10) for duration in (3, 6, 12)},
            )

    def test_vm_draft_after_rollover_uses_recalculated_d0_and_preserved_d1(self):
        QpfThreshold24h.objects.create(
            zone=self.zone_a, weak_mm=10, moderate_mm=20,
            elevated_mm=50, very_elevated_mm=100,
        )
        self._source_qpf(MapId.TOMORROW, self.zone_a)
        SourceQpfAmount.objects.create(
            source_qpf=SourceQpf.objects.get(map_id=MapId.TOMORROW, zone=self.zone_a),
            daily_precipitation_interval=DailyPrecipitationInterval.objects.get(
                day=MapId.TOMORROW, time_interval="12:00 - 18:00"
            ),
            duration_hours=24, min_mm=10, max_mm=15,
        )
        for day in (MapId.TOMORROW, MapId.DAY_AFTER_TOMORROW):
            CurQpf.objects.create(
                map_id=day, zone=self.zone_a,
                qpf_level=QpfLevel.objects.get(code="molto_elevate"),
            )
        MapOperationalState.objects.update(last_rollover_date=None)
        call_command("rollover_current_maps", stdout=StringIO())

        response = self.client.post("/api/vm_bulletins/draft/", {}, format="json")

        self.assertEqual(response.status_code, status.HTTP_201_CREATED, response.data)
        bulletin = VmBulText.objects.get(pk=response.data["id"])
        self.assertEqual(
            bulletin.zones.get(map_id=MapId.TODAY, zone=self.zone_a).qpf_code, "deboli"
        )
        self.assertEqual(
            bulletin.zones.get(map_id=MapId.TOMORROW, zone=self.zone_a).qpf_code,
            "molto_elevate",
        )

    def test_optional_editorial_fields_accept_long_texts_for_each_product(self):
        ps = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data

        for field in (
            "subtitle",
            "preliminary_notes",
            "current_situation",
            "signature",
        ):
            self.assertEqual(ps[field], "")
        for field in ("subtitle", "preliminary_notes", "signature"):
            self.assertEqual(vm[field], "")
        self.assertNotIn("current_situation", vm)

        long_subtitle = "S" * 512
        ps_payload = {
            "subtitle": long_subtitle,
            "preliminary_notes": "Note preliminari PS",
            "current_situation": "Situazione corrente",
            "signature": "Firma PS",
        }
        ps_response = self.client.patch(
            f"/api/ps_bulletins/{ps['id']}/",
            ps_payload,
            format="json",
        )
        self.assertEqual(ps_response.status_code, status.HTTP_200_OK)
        for field, value in ps_payload.items():
            self.assertEqual(ps_response.data[field], value)
        saved_ps = PsBulText.objects.get(pk=ps["id"])
        for field, value in ps_payload.items():
            self.assertEqual(getattr(saved_ps, field), value)

        vm_payload = {
            "subtitle": long_subtitle,
            "preliminary_notes": "Note preliminari VMN",
            "signature": "Firma VMN",
        }
        vm_response = self.client.patch(
            f"/api/vm_bulletins/{vm['id']}/",
            vm_payload,
            format="json",
        )
        self.assertEqual(vm_response.status_code, status.HTTP_200_OK)
        for field, value in vm_payload.items():
            self.assertEqual(vm_response.data[field], value)
        saved_vm = VmBulText.objects.get(pk=vm["id"])
        for field, value in vm_payload.items():
            self.assertEqual(getattr(saved_vm, field), value)

    def test_new_editorial_fields_are_initialized_from_bulletin_settings(self):
        ps_settings = BulletinSettings.objects.get(
            bulletin_type=BulletinProduct.PS,
            user=None,
        )
        ps_settings.default_texts = {
            "preliminary_notes": "Note PS predefinite",
            "current_situation": "Situazione PS predefinita",
            "signature": "Firma PS predefinita",
        }
        ps_settings.save(update_fields=["default_texts", "updated_at"])
        vm_settings = BulletinSettings.objects.create(
            bulletin_type=BulletinProduct.VMN,
            default_texts={
                "preliminary_notes": "Note VMN predefinite",
                "signature": "Firma VMN predefinita",
            },
        )

        ps = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data

        self.assertEqual(ps["preliminary_notes"], "Note PS predefinite")
        self.assertEqual(ps["current_situation"], "Situazione PS predefinita")
        self.assertEqual(ps["signature"], "Firma PS predefinita")
        self.assertEqual(
            vm["preliminary_notes"],
            vm_settings.default_texts["preliminary_notes"],
        )
        self.assertEqual(vm["signature"], vm_settings.default_texts["signature"])

    def test_refresh_overwrites_manual_text_and_qpf_rows_are_grouped(self):
        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        qpf_row = draft["qpf_rows"][0]
        self.assertTrue(qpf_row["row_id"].startswith("qpf-"))
        self.assertEqual(qpf_row["zones_text"], "LAZIO A-B")

        edited = draft["text_sections"]
        edited["d0"]["precipitazioni"] = "Modifica manuale."
        patched = self.client.patch(
            f"/api/ps_bulletins/{draft['id']}/",
            {
                "text_sections": edited,
                "qpf_row_texts": [
                    {
                        "row_id": qpf_row["row_id"],
                        "zones_text": "A - B - C e settore costiero",
                    }
                ],
            },
            format="json",
        )
        self.assertEqual(patched.status_code, status.HTTP_200_OK)
        self.assertEqual(
            patched.data["qpf_rows"][0]["zones_text"],
            "A - B - C e settore costiero",
        )
        retrieved = self.client.get(f"/api/ps_bulletins/{draft['id']}/")
        self.assertEqual(
            retrieved.data["qpf_rows"][0]["zones_text"],
            "A - B - C e settore costiero",
        )

        response = self.client.post(
            f"/api/ps_bulletins/{draft['id']}/refresh/",
            {},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertNotEqual(
            response.data["text_sections"]["d0"]["precipitazioni"],
            "Modifica manuale.",
        )
        self.assertEqual(len(response.data["qpf_rows"]), 1)
        self.assertEqual(
            [zone["code"] for zone in response.data["qpf_rows"][0]["zones"]],
            ["A", "B"],
        )
        self.assertEqual(response.data["qpf_rows"][0]["zones_text"], "LAZIO A-B")

    def test_qpf_zone_text_lists_each_region_and_all_shared_zones(self):
        self.region.sort_order = 12
        self.region.save(update_fields=["sort_order"])
        abruzzo = Region.objects.create(code="ABR", name="Abruzzo", sort_order=13)
        molise = Region.objects.create(code="MOL", name="Molise", sort_order=14)
        BulletinSettings.objects.get(
            bulletin_type=BulletinProduct.PS, user=None,
        ).qpf_regions.add(abruzzo, molise)
        ZoneVigilanzaMeteoRegion.objects.create(
            zone=self.zone_a,
            region=abruzzo,
            description="ovest",
        )
        ZoneVigilanzaMeteoRegion.objects.create(
            zone=self.zone_b,
            region=abruzzo,
            description="(rilievi)",
        )
        ZoneVigilanzaMeteoRegion.objects.create(zone=self.zone_b, region=molise)

        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json")

        self.assertEqual(draft.status_code, status.HTTP_201_CREATED)
        expected = "LAZIO A-B\nABRUZZO A(ovest)-B(rilievi)\nMOLISE B"
        self.assertEqual(draft.data["qpf_rows"][0]["zones_text"], expected)
        self.assertEqual(
            self.client.get(f"/api/ps_bulletins/{draft.data['id']}/").data[
                "qpf_rows"
            ][0]["zones_text"],
            expected,
        )

    def test_ps_qpf_excludes_unconfigured_regions_from_shared_zone_text(self):
        excluded_region = Region.objects.create(code="EMR", name="Emilia-Romagna")
        ZoneVigilanzaMeteoRegion.objects.create(
            zone=self.zone_a, region=excluded_region, description="rilievi",
        )
        self.zone_out.regions.add(excluded_region)
        self._source_qpf(MapId.TODAY, self.zone_out)
        # A different signature would produce a separate row without the filter.
        SourceQpfAmount.objects.filter(source_qpf__zone=self.zone_out).update(max_mm=99)

        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json")

        self.assertEqual(draft.status_code, status.HTTP_201_CREATED, draft.data)
        bulletin = PsBulText.objects.get(pk=draft.data["id"])
        self.assertEqual(
            set(bulletin.qpf_zones.values_list("zone_code", flat=True)), {"A", "B"},
        )
        for response in (
            draft,
            self.client.get(f"/api/ps_bulletins/{bulletin.pk}/"),
            self.client.post(f"/api/ps_bulletins/{bulletin.pk}/refresh/", {}, format="json"),
        ):
            self.assertEqual(len(response.data["qpf_rows"]), 1)
            row = response.data["qpf_rows"][0]
            self.assertEqual(row["zones_text"], "LAZIO A-B")
            self.assertEqual([zone["code"] for zone in row["zones"]], ["A", "B"])

    def test_qpf_region_filter_does_not_limit_ps_vm_texts_or_vm_maps(self):
        excluded_region = Region.objects.create(code="EMR", name="Emilia-Romagna")
        self.zone_out.regions.add(excluded_region)
        for map_id in MapId.values:
            CurPs.objects.create(
                map_id=map_id,
                zone=self.zone_out,
                phenomenon_type=self.rain,
                ps_level=self.rain_isolated,
                icon_slot=1,
            )
            CurQpf.objects.get_or_create(
                map_id=map_id, zone=self.zone_out, defaults={"qpf_level": self.qpf},
            )

        for product in ("ps", "vm"):
            draft = self.client.post(f"/api/{product}_bulletins/draft/", {}, format="json")
            self.assertEqual(draft.status_code, status.HTTP_201_CREATED, draft.data)
            refreshed = self.client.post(
                f"/api/{product}_bulletins/{draft.data['id']}/refresh/", {}, format="json",
            )
            self.assertEqual(refreshed.status_code, status.HTTP_200_OK, refreshed.data)
            for response in (draft, refreshed):
                for map_id in MapId.values:
                    self.assertIn(
                        self.zone_out.name,
                        response.data["text_sections"][map_id]["precipitazioni"],
                    )
                for day in response.data["generated_sections"]["days"]:
                    self.assertIn(
                        self.zone_out.name, day["categories"][0]["generated_text"],
                    )
                if product == "vm":
                    for map_data in response.data["maps"]:
                        self.assertIn("OUT", [zone["zone_code"] for zone in map_data["zones"]])
                        self.assertIn("OUT", [icon["zone_code"] for icon in map_data["icons"]])

    def test_qpf_row_texts_validate_row_ids_and_allow_empty_text(self):
        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        row_id = draft["qpf_rows"][0]["row_id"]

        empty = self.client.patch(
            f"/api/ps_bulletins/{draft['id']}/",
            {"qpf_row_texts": [{"row_id": row_id, "zones_text": ""}]},
            format="json",
        )
        self.assertEqual(empty.status_code, status.HTTP_200_OK)
        self.assertEqual(empty.data["qpf_rows"][0]["zones_text"], "")

        unknown = self.client.patch(
            f"/api/ps_bulletins/{draft['id']}/",
            {"qpf_row_texts": [{"row_id": "qpf-unknown", "zones_text": "X"}]},
            format="json",
        )
        self.assertEqual(unknown.status_code, status.HTTP_400_BAD_REQUEST)

        duplicate = self.client.patch(
            f"/api/ps_bulletins/{draft['id']}/",
            {
                "qpf_row_texts": [
                    {"row_id": row_id, "zones_text": "A"},
                    {"row_id": row_id, "zones_text": "B"},
                ]
            },
            format="json",
        )
        self.assertEqual(duplicate.status_code, status.HTTP_400_BAD_REQUEST)

    def test_vm_map_collapses_only_display_levels(self):
        draft = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data
        icon = draft["maps"][0]["icons"][0]
        self.assertEqual(icon["original_level"]["code"], "piogge_isolate")
        self.assertEqual(icon["display_level"]["code"], "piogge_sparse")
        generated = draft["generated_sections"]["days"][0]["categories"][0]
        self.assertIn("Piogge isolate", generated["generated_text"])

        CurPs.objects.filter(map_id=MapId.TODAY).delete()
        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone_a,
            phenomenon_type=self.storm,
            ps_level=self.shower_isolated,
            icon_slot=1,
        )
        refreshed = self.client.post(
            f"/api/vm_bulletins/{draft['id']}/refresh/", {}, format="json"
        ).data
        icon = refreshed["maps"][0]["icons"][0]
        self.assertEqual(icon["original_level"]["code"], "rovesci_isolati")
        self.assertEqual(icon["display_level"]["code"], "temporali_isolati")

    def test_finalize_assigns_daily_type_and_independent_annual_sequences(self):
        ps1 = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        first = self.client.post(
            f"/api/ps_bulletins/{ps1['id']}/finalize/", {}, format="json"
        )
        ps2 = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        update = self.client.post(
            f"/api/ps_bulletins/{ps2['id']}/finalize/", {}, format="json"
        )
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data
        vm_first = self.client.post(
            f"/api/vm_bulletins/{vm['id']}/finalize/", {}, format="json"
        )

        self.assertEqual(first.data["bull_type"], BulletinKind.FIRST)
        self.assertEqual(first.data["progressive_number"], 1)
        self.assertEqual(update.data["bull_type"], BulletinKind.UPDATE)
        self.assertEqual(update.data["update_number"], 1)
        self.assertEqual(update.data["progressive_number"], 2)
        self.assertEqual(vm_first.data["progressive_number"], 1)
        self.assertEqual(
            BulletinSequence.objects.get(
                bulletin_type=BulletinProduct.PS,
                year=timezone.localdate().year,
            ).last_number,
            2,
        )

        immutable = self.client.patch(
            f"/api/ps_bulletins/{ps1['id']}/",
            {"title": "Non consentito"},
            format="json",
        )
        self.assertEqual(immutable.status_code, status.HTTP_409_CONFLICT)

    @override_settings(
        PRINT_CLIENT_PDF_BASE_URL="http://portal/bvps/#/print/",
        PRINTSERVICE_PDF_URL="http://printservice:8989/pdf",
        PDF_ARCHIVE_S3_BUCKET_NAME="bulletin-bucket",
    )
    @mock.patch("ps_vm_core.views.bulletins.save_pdf_bytes")
    @mock.patch("ps_vm_core.views.bulletins.get_printed_pdf")
    def test_pdf_uses_client_template_printservice_flow_and_archives_on_s3(
        self,
        get_printed_pdf,
        save_pdf_bytes_mock,
    ):
        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        pdf_bytes = b"%PDF-1.7 rendered"
        get_printed_pdf.return_value = pdf_bytes
        save_pdf_bytes_mock.return_value = SimpleNamespace(filename="bulletin.pdf")

        response = self.client.get(f"/api/ps_bulletins/{draft['id']}/pdf/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.content, pdf_bytes)
        get_printed_pdf.assert_called_once_with(
            "http://portal/bvps/#/print/ps/"
            f"{draft['id']}?portaluser=bulletin-user"
        )
        saved_bulletin, saved_content = save_pdf_bytes_mock.call_args.args
        self.assertEqual(saved_bulletin.pk, draft["id"])
        self.assertEqual(saved_content, pdf_bytes)
        self.assertEqual(
            response["Content-Disposition"],
            'inline; filename="bulletin.pdf"',
        )

    @mock.patch("ps_vm_core.views.bulletins.read_pdf_bytes")
    @mock.patch("ps_vm_core.views.bulletins.get_archive")
    def test_finalized_pdf_is_read_from_s3_without_calling_printservice(
        self,
        get_archive_mock,
        read_pdf_bytes_mock,
    ):
        draft = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data
        self.client.post(
            f"/api/vm_bulletins/{draft['id']}/finalize/",
            {},
            format="json",
        )
        archive = SimpleNamespace(
            filename="vmn.pdf",
            s3_bucket="bulletin-bucket",
            s3_key=REDACTED
        )
        get_archive_mock.return_value = archive
        read_pdf_bytes_mock.return_value = b"%PDF archived"

        with mock.patch("ps_vm_core.views.bulletins.get_printed_pdf") as print_mock:
            response = self.client.get(
                f"/api/vm_bulletins/{draft['id']}/pdf/?isdownload=true"
            )

        self.assertEqual(response.content, b"%PDF archived")
        read_pdf_bytes_mock.assert_called_once_with(archive)
        print_mock.assert_not_called()
        self.assertEqual(
            response["Content-Disposition"],
            'attachment; filename="vmn.pdf"',
        )

    @override_settings(
        PDF_ARCHIVE_S3_BUCKET_NAME="bulletin-bucket",
        PDF_ARCHIVE_S3_BUCKET_BASE_PATH="ps-vm/pdf",
    )
    def test_pdf_archive_storage_matches_webalert3_s3_pattern(self):
        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        bulletin = PsBulText.objects.get(pk=draft["id"])
        s3_client = mock.Mock()
        s3_client.put_object.return_value = {"ETag": '"abc123"'}
        s3_client.get_object.return_value = {"Body": BytesIO(b"%PDF stored")}

        archive = save_pdf_bytes(bulletin, b"%PDF stored", client=s3_client)

        self.assertEqual(archive.s3_bucket, "bulletin-bucket")
        self.assertEqual(archive.s3_key, build_s3_key(bulletin))
        self.assertTrue(archive.s3_key.startswith("ps-vm/pdf/ps/"))
        self.assertFalse(archive.file.name)
        self.assertEqual(archive.size, len(b"%PDF stored"))
        self.assertEqual(archive.s3_size, len(b"%PDF stored"))
        self.assertEqual(read_pdf_bytes(archive, client=s3_client), b"%PDF stored")
        self.assertEqual(BulletinPdfArchive.objects.count(), 1)
