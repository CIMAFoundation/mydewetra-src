from unittest import mock

from django.contrib.auth import get_user_model
from django.db import IntegrityError, transaction
from django.db.models.deletion import ProtectedError
from rest_framework.test import APITestCase

from ps_vm_core.models import (
    BulletinProduct,
    BulletinSettings,
    PsBulText,
    PsBulletinParticipant,
    PsParticipant,
    Region,
)
from ps_vm_core.bulletins import finalize_draft
from ps_vm_core.testing.api_runner import PsVmApiRunner
from ps_vm_core.views.bulletins import PsBulletinViewSet


class PsParticipantApiTests(APITestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(username="participants-user")
        cls.first = PsParticipant.objects.create(code="first", name="Ente Z", sort_order=10)
        cls.second = PsParticipant.objects.create(code="second", name="Ente A", sort_order=20)
        cls.inactive = PsParticipant.objects.create(
            code="inactive", name="Ente inattivo", is_active=False
        )
        settings, _created = BulletinSettings.objects.update_or_create(
            bulletin_type=BulletinProduct.PS, user=None, defaults={"is_active": True}
        )
        settings.qpf_regions.add(Region.objects.create(code="TEST", name="Regione test"))

    def setUp(self):
        self.client.force_authenticate(self.user)

    def _draft(self):
        response = self.client.post("/api/ps_bulletins/draft/", {}, format="json")
        self.assertEqual(response.status_code, 201, response.data)
        return response.data

    def _select(self, bulletin_id, ids, **fields):
        return self.client.patch(
            f"/api/ps_bulletins/{bulletin_id}/",
            {"participant_ids": ids, **fields},
            format="json",
        )

    def _snapshot(self, participant):
        return {
            "id": participant.pk,
            "code": participant.code,
            "name": participant.name,
            "sort_order": participant.sort_order,
        }

    def test_catalog_lists_only_active_entries_in_stable_order_and_is_read_only(self):
        response = self.client.get("/api/ps_participants/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, [self._snapshot(self.first), self._snapshot(self.second)])
        self.assertEqual(
            self.client.get(f"/api/ps_participants/{self.first.pk}/").data,
            self._snapshot(self.first),
        )
        self.assertEqual(
            self.client.get(f"/api/ps_participants/{self.inactive.pk}/").status_code, 404
        )
        self.assertEqual(
            self.client.post("/api/ps_participants/", {}, format="json").status_code, 405
        )
        self.assertEqual(
            self.client.patch(
                f"/api/ps_participants/{self.first.pk}/", {"name": "X"}, format="json"
            ).status_code, 405,
        )
        self.assertEqual(
            self.client.delete(f"/api/ps_participants/{self.first.pk}/").status_code, 405
        )

    @mock.patch("acroweb3_api.auth.AcrowebOAuth2Authentication.authenticate", return_value=None)
    def test_catalog_requires_authentication(self, authenticate):
        self.client.force_authenticate(user=None)
        self.assertEqual(self.client.get("/api/ps_participants/").status_code, 401)
        self.assertEqual(
            self.client.get(f"/api/ps_participants/{self.first.pk}/").status_code, 401
        )

    def test_selection_is_saved_with_editorial_fields_and_returned_in_catalog_order(self):
        draft = self._draft()
        self.assertEqual(draft["participants"], [])
        response = self._select(
            draft["id"], [self.second.pk, self.first.pk], title="PS con partecipanti"
        )
        expected = [self._snapshot(self.first), self._snapshot(self.second)]
        self.assertEqual(response.status_code, 200, response.data)
        self.assertEqual(response.data["participants"], expected)
        self.assertEqual(response.data["title"], "PS con partecipanti")
        self.assertEqual(
            self.client.get(f"/api/ps_bulletins/{draft['id']}/").data["participants"], expected
        )
        reopened = self.client.post("/api/ps_bulletins/draft/", {}, format="json")
        self.assertEqual(reopened.status_code, 200)
        self.assertEqual(reopened.data["participants"], expected)
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json")
        self.assertEqual(vm.status_code, 201)
        self.assertNotIn("participants", vm.data)

    def test_omitted_selection_is_preserved_and_present_selection_replaces_or_clears(self):
        draft = self._draft()
        self._select(draft["id"], [self.first.pk, self.second.pk])
        response = self.client.patch(
            f"/api/ps_bulletins/{draft['id']}/", {"notes": "Nota"}, format="json"
        )
        self.assertEqual(len(response.data["participants"]), 2)
        replaced = self._select(draft["id"], [self.second.pk])
        self.assertEqual(replaced.data["participants"], [self._snapshot(self.second)])
        cleared = self._select(draft["id"], [])
        self.assertEqual(cleared.status_code, 200)
        self.assertEqual(cleared.data["participants"], [])
        self.assertFalse(PsBulletinParticipant.objects.filter(bulletin_id=draft["id"]).exists())

    def test_invalid_selection_does_not_change_selection_or_editorial_fields(self):
        draft = self._draft()
        self._select(draft["id"], [self.first.pk])
        unknown = max(self.first.pk, self.second.pk, self.inactive.pk) + 1
        for ids in (
            [self.first.pk, self.first.pk], [unknown], [self.inactive.pk],
            [self.second.pk, unknown], None, "invalid", ["invalid"], [0], [-1], [1.5],
        ):
            with self.subTest(ids=ids):
                response = self._select(draft["id"], ids, title="Non salvare")
                self.assertEqual(response.status_code, 400, response.data)
                self.assertIn("participant_ids", response.data)
                detail = self.client.get(f"/api/ps_bulletins/{draft['id']}/").data
                self.assertEqual(detail["title"], draft["title"])
                self.assertEqual(detail["participants"], [self._snapshot(self.first)])

    def test_snapshot_survives_catalog_changes_refresh_and_repeated_save(self):
        draft = self._draft()
        selected = self._select(draft["id"], [self.first.pk, self.second.pk]).data["participants"]
        PsParticipant.objects.filter(pk=self.first.pk).update(
            code="renamed", name="Nuova denominazione", sort_order=99, is_active=False
        )
        repeated = self._select(draft["id"], [self.second.pk, self.first.pk])
        self.assertEqual(repeated.status_code, 200, repeated.data)
        self.assertEqual(repeated.data["participants"], selected)
        refreshed = self.client.post(
            f"/api/ps_bulletins/{draft['id']}/refresh/", {}, format="json"
        )
        self.assertEqual(refreshed.status_code, 200, refreshed.data)
        self.assertEqual(refreshed.data["participants"], selected)
        # Si può rimuovere una voce inattiva, ma non aggiungerla nuovamente.
        self._select(draft["id"], [self.second.pk])
        self.assertEqual(self._select(draft["id"], [self.first.pk]).status_code, 400)

    def test_finalization_freezes_selection_and_new_draft_starts_empty(self):
        draft = self._draft()
        selected = self._select(draft["id"], [self.first.pk]).data["participants"]
        finalized = self.client.post(
            f"/api/ps_bulletins/{draft['id']}/finalize/", {}, format="json"
        )
        self.assertEqual(finalized.status_code, 200)
        self.assertEqual(finalized.data["participants"], selected)
        PsParticipant.objects.filter(pk=self.first.pk).update(name="Nuovo nome", is_active=False)
        self.assertEqual(self._select(draft["id"], []).status_code, 409)
        refresh = self.client.post(f"/api/ps_bulletins/{draft['id']}/refresh/", {}, format="json")
        self.assertEqual(refresh.status_code, 409)
        for response in (
            self.client.get(f"/api/ps_bulletins/{draft['id']}/"),
            self.client.post(f"/api/ps_bulletins/{draft['id']}/finalize/", {}, format="json"),
        ):
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.data["participants"], selected)
        new_draft = self._draft()
        self.assertNotEqual(new_draft["id"], draft["id"])
        self.assertEqual(new_draft["participants"], [])
        self.assertEqual(self._select(new_draft["id"], [self.first.pk]).status_code, 400)

    def test_existing_bulletin_without_selection_returns_empty_array(self):
        bulletin = PsBulText.objects.create(day_string="20200101", operational_date="2020-01-01")
        response = self.client.get(f"/api/ps_bulletins/{bulletin.pk}/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["participants"], [])

    def test_reselecting_removed_active_participant_uses_current_catalog_values(self):
        draft = self._draft()
        self._select(draft["id"], [self.first.pk])
        PsParticipant.objects.filter(pk=self.first.pk).update(name="Nuova denominazione")
        self._select(draft["id"], [])
        response = self._select(draft["id"], [self.first.pk])
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["participants"][0]["name"], "Nuova denominazione")

    def test_patch_rechecks_status_after_fetching_a_draft_finalized_by_another_request(self):
        draft = self._draft()
        stale_draft = PsBulText.objects.get(pk=draft["id"])
        finalize_draft(draft["id"], BulletinProduct.PS, self.user)
        with mock.patch.object(PsBulletinViewSet, "get_object", return_value=stale_draft):
            response = self._select(draft["id"], [self.first.pk], title="Non salvare")
        self.assertEqual(response.status_code, 409)
        self.assertFalse(stale_draft.participants.exists())
        stale_draft.refresh_from_db()
        self.assertEqual(stale_draft.title, draft["title"])

    def test_saving_texts_and_selection_is_atomic_on_database_failure(self):
        draft = self._draft()
        self._select(draft["id"], [self.first.pk])
        with mock.patch(
            "ps_vm_core.bulletin_serializers.PsBulletinParticipant.objects.bulk_create",
            side_effect=RuntimeError("Errore simulato"),
        ):
            response = self._select(draft["id"], [self.second.pk], title="Non salvare")
        self.assertEqual(response.status_code, 500)
        bulletin = PsBulText.objects.get(pk=draft["id"])
        self.assertEqual(bulletin.title, draft["title"])
        self.assertEqual(list(bulletin.participants.values_list("participant_id", flat=True)), [self.first.pk])

    def test_selected_participant_cannot_be_deleted_and_duplicate_link_is_rejected(self):
        draft = self._draft()
        self._select(draft["id"], [self.first.pk])
        with self.assertRaises(ProtectedError):
            self.first.delete()
        with self.assertRaises(IntegrityError), transaction.atomic():
            PsBulletinParticipant.objects.create(
                bulletin_id=draft["id"], participant=self.first,
                code=self.first.code, name=self.first.name,
            )
        PsBulText.objects.get(pk=draft["id"]).delete()
        self.assertFalse(PsBulletinParticipant.objects.exists())

    def test_api_runner_dispatch_includes_new_catalog(self):
        with mock.patch(
            "ps_vm_core.testing.api_runner.load_local_auth_data", return_value=mock.Mock(domain="")
        ):
            runner = PsVmApiRunner()
        runner.client.force_authenticate(self.user)
        results = runner.run(endpoints=["ps_participants"], read_only=True)
        self.assertEqual(len(results), 1)
        self.assertTrue(results[0].ok)
        self.assertEqual(results[0].path, "/api/ps_participants/")
