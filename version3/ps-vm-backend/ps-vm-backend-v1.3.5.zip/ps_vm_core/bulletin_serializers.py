import json

from django.db import transaction
from django.db.models import Q
from rest_framework import serializers

from ps_vm_core.bulletins import CATEGORY_DEFINITIONS, ps_qpf_rows
from ps_vm_core.models import (
    MapId,
    PsBulText,
    PsBulletinParticipant,
    PsParticipant,
    VmBulText,
)


def _geometry(value):
    return json.loads(value.geojson) if value else None


def _anchor(value):
    if value is None:
        return None
    return {"longitude": value.x, "latitude": value.y}


class BulletinWriteSerializer(serializers.Serializer):
    title = serializers.CharField(required=False, allow_blank=True, max_length=255)
    subtitle = serializers.CharField(required=False, allow_blank=True)
    preliminary_notes = serializers.CharField(required=False, allow_blank=True)
    signature = serializers.CharField(required=False, allow_blank=True)
    notes = serializers.CharField(required=False, allow_blank=True)
    text_sections = serializers.JSONField(required=False)

    def validate_text_sections(self, value):
        expected_days = set(MapId.values)
        expected_categories = {code for code, _label, _types in CATEGORY_DEFINITIONS}
        if not isinstance(value, dict) or set(value) != expected_days:
            raise serializers.ValidationError(
                f"Sono richieste le sezioni complete per: {', '.join(MapId.values)}."
            )
        for map_id, categories in value.items():
            if not isinstance(categories, dict) or set(categories) != expected_categories:
                raise serializers.ValidationError(
                    f"Categorie non valide o incomplete per {map_id}."
                )
            if any(not isinstance(text, str) for text in categories.values()):
                raise serializers.ValidationError(
                    f"Tutti i testi di {map_id} devono essere stringhe."
                )
        return value

    def update(self, instance, validated_data):
        for field, value in validated_data.items():
            setattr(instance, field, value)
        instance.save(update_fields=[*validated_data, "updated_at"])
        return instance


class PsQpfRowTextSerializer(serializers.Serializer):
    row_id = serializers.CharField()
    zones_text = serializers.CharField(allow_blank=True, trim_whitespace=False)


class PsBulletinWriteSerializer(BulletinWriteSerializer):
    current_situation = serializers.CharField(required=False, allow_blank=True)
    qpf_row_texts = PsQpfRowTextSerializer(many=True, required=False)
    participant_ids = serializers.ListField(
        child=serializers.IntegerField(min_value=1), required=False
    )

    def validate_participant_ids(self, value):
        if len(value) != len(set(value)):
            raise serializers.ValidationError(
                "Ogni partecipante può comparire una sola volta."
            )
        # Una voce disattivata può essere mantenuta se già selezionata.
        existing_ids = self.instance.participants.values_list("participant_id", flat=True)
        participants = list(
            PsParticipant.objects.filter(pk__in=value).filter(
                Q(is_active=True) | Q(pk__in=existing_ids)
            )
        )
        invalid_ids = sorted(set(value) - {item.pk for item in participants})
        if invalid_ids:
            raise serializers.ValidationError(
                "Partecipanti inesistenti o non attivi: "
                + ", ".join(map(str, invalid_ids))
                + "."
            )
        return participants

    def validate_qpf_row_texts(self, value):
        row_ids = [item["row_id"] for item in value]
        if len(row_ids) != len(set(row_ids)):
            raise serializers.ValidationError(
                "Ogni row_id può comparire una sola volta."
            )

        valid_row_ids = {row["row_id"] for row in ps_qpf_rows(self.instance)}
        unknown_row_ids = sorted(set(row_ids) - valid_row_ids)
        if unknown_row_ids:
            raise serializers.ValidationError(
                f"Righe QPF non valide: {', '.join(unknown_row_ids)}."
            )
        return value

    @transaction.atomic
    def update(self, instance, validated_data):
        participants = validated_data.pop("participant_ids", None)
        row_texts = validated_data.pop("qpf_row_texts", None)
        if row_texts is not None:
            saved_texts = dict(instance.qpf_row_texts or {})
            saved_texts.update(
                {item["row_id"]: item["zones_text"] for item in row_texts}
            )
            validated_data["qpf_row_texts"] = saved_texts
        instance = super().update(instance, validated_data)
        if participants is not None:
            selected_ids = {item.pk for item in participants}
            instance.participants.exclude(participant_id__in=selected_ids).delete()
            existing_ids = set(
                instance.participants.values_list("participant_id", flat=True)
            )
            # Manteniamo gli snapshot delle voci già presenti, anche se il
            # catalogo è cambiato dall'ultimo salvataggio.
            PsBulletinParticipant.objects.bulk_create(
                [
                    PsBulletinParticipant(
                        bulletin=instance,
                        participant=participant,
                        code=participant.code,
                        name=participant.name,
                        sort_order=participant.sort_order,
                    )
                    for participant in participants
                    if participant.pk not in existing_ids
                ]
            )
        return instance


class VmBulletinWriteSerializer(BulletinWriteSerializer):
    pass


class BulletinListSerializer(serializers.ModelSerializer):
    class Meta:
        fields = (
            "id",
            "operational_date",
            "status",
            "bull_type",
            "update_number",
            "progressive_year",
            "progressive_number",
            "title",
            "is_preview",
            "finalized_at",
            "created_at",
            "updated_at",
        )


class PsBulletinListSerializer(BulletinListSerializer):
    class Meta(BulletinListSerializer.Meta):
        model = PsBulText


class VmBulletinListSerializer(BulletinListSerializer):
    class Meta(BulletinListSerializer.Meta):
        model = VmBulText


class BulletinDetailSerializer(serializers.ModelSerializer):
    user_id = serializers.IntegerField(read_only=True)

    class Meta:
        fields = (
            "id",
            "day_string",
            "operational_date",
            "user_id",
            "status",
            "bull_type",
            "update_number",
            "progressive_year",
            "progressive_number",
            "is_preview",
            "title",
            "subtitle",
            "preliminary_notes",
            "signature",
            "notes",
            "generated_sections",
            "text_sections",
            "finalized_at",
            "created_at",
            "updated_at",
        )


class PsBulletinParticipantSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(source="participant_id", read_only=True)

    class Meta:
        model = PsBulletinParticipant
        fields = ("id", "code", "name", "sort_order")


class PsBulletinDetailSerializer(BulletinDetailSerializer):
    qpf_rows = serializers.SerializerMethodField()
    participants = PsBulletinParticipantSerializer(many=True, read_only=True)

    class Meta(BulletinDetailSerializer.Meta):
        model = PsBulText
        fields = BulletinDetailSerializer.Meta.fields + (
            "current_situation",
            "qpf_rows",
            "participants",
        )

    def get_qpf_rows(self, obj):
        return ps_qpf_rows(obj)


class VmBulletinDetailSerializer(BulletinDetailSerializer):
    maps = serializers.SerializerMethodField()

    class Meta(BulletinDetailSerializer.Meta):
        model = VmBulText
        fields = BulletinDetailSerializer.Meta.fields + ("maps",)

    def get_maps(self, obj):
        zones_by_map = {map_id: [] for map_id in MapId.values}
        for zone in obj.zones.select_related("zone", "qpf_level").order_by(
            "map_id", "zone_code"
        ):
            zones_by_map[zone.map_id].append(
                {
                    "zone_id": zone.zone_id,
                    "zone_code": zone.zone_code,
                    "zone_name": zone.zone_name,
                    "geometry": _geometry(zone.zone_geometry),
                    "qpf": {
                        "id": zone.qpf_level_id,
                        "code": zone.qpf_code,
                        "text": zone.qpf_text,
                        "color": zone.color,
                        "svg": zone.svg,
                    },
                    "custom_description": zone.custom_description,
                }
            )

        icons_by_map = {map_id: [] for map_id in MapId.values}
        for icon in obj.icons.select_related(
            "zone", "phenomenon_type", "ps_level", "display_ps_level"
        ).order_by("map_id", "zone_code", "icon_slot"):
            icons_by_map[icon.map_id].append(
                {
                    "zone_id": icon.zone_id,
                    "zone_code": icon.zone_code,
                    "zone_name": icon.zone_name,
                    "zone_geometry": _geometry(icon.zone_geometry),
                    "icon_slot": icon.icon_slot,
                    "anchor": _anchor(icon.anchor),
                    "phenomenon_code": icon.phenomenon_code,
                    "original_level": {
                        "id": icon.ps_level_id,
                        "code": icon.ps_code,
                        "text": icon.ps_text,
                        "icon": icon.icon.url if icon.icon else None,
                        "svg": icon.svg,
                        "color": icon.color,
                    },
                    "display_level": {
                        "id": icon.display_ps_level_id,
                        "code": icon.display_ps_code,
                        "text": icon.display_ps_text,
                        "icon": icon.display_icon.url if icon.display_icon else None,
                        "svg": icon.display_svg,
                        "color": icon.display_color,
                    },
                    "custom_description": icon.custom_description,
                }
            )

        date_by_map = {
            day["map_id"]: day["valid_date"]
            for day in obj.generated_sections.get("days", [])
        }
        return [
            {
                "map_id": map_id,
                "valid_date": date_by_map.get(map_id),
                "zones": zones_by_map[map_id],
                "icons": icons_by_map[map_id],
            }
            for map_id in MapId.values
        ]
