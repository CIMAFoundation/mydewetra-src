# API PS/VM

Questa pagina documenta gli endpoint REST attualmente implementati dal backend
PS/VM. La base URL applicativa e':

```text
/api/
```

Sono inoltre disponibili le interfacce generate automaticamente:

```text
/docs/swagger/
/docs/redoc/
```

## Autenticazione

Tutti gli endpoint documentati richiedono un utente autenticato. In ambiente
integrato l'autenticazione e' gestita tramite il token Acroweb/OAuth2:

```http
Authorization: Bearer <access-token>
```

La selezione del dominio Acroweb puo' richiedere anche l'header configurato
dall'installazione, normalmente `acroweb3-domain`.

## Convenzioni temporali

Le mappe correnti usano identificativi relativi alla giornata operativa:

| `map_id` | Offset | Significato |
| --- | ---: | --- |
| `d0` | 0 | giorno operativo corrente |
| `d1` | 1 | giorno successivo |
| `d2` | 2 | secondo giorno successivo |

`operational_date` e' la data assunta come D0 dal server, calcolata usando il
fuso orario applicativo `Europe/Rome`. `valid_date` e' la data di calendario a
cui si riferisce la singola mappa ed e' calcolata aggiungendo a
`operational_date` l'offset di `map_id`.

Per esempio, con `operational_date` uguale a `2026-07-22`:

| `map_id` | `valid_date` |
| --- | --- |
| `d0` | `2026-07-22` |
| `d1` | `2026-07-23` |
| `d2` | `2026-07-24` |

Le date descrivono lo stato restituito, ma non identificano uno storico: le
tabelle `cur_qpf` e `cur_ps` continuano a rappresentare esclusivamente la
lavagna operativa corrente.

## Anagrafiche per la compilazione

Gli endpoint di questa sezione restituiscono soltanto elementi attivi, in un
ordine stabile e quindi direttamente utilizzabili dal client. Supportano sia la
lista sia il dettaglio (`/<id>/`) e richiedono autenticazione.

### `GET /api/weather_vigilance_zones/`

Restituisce l'anagrafica e le geometrie delle zone di vigilanza meteo attive,
ordinate per `code`, come `FeatureCollection` GeoJSON. Il campo `id` di ogni
feature corrisponde al campo `zone_id` restituito da `GET /api/current_qpf/` e
permette al client di unire geometria e stato corrente.

Risposta `200 OK`:

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "id": 12,
      "type": "Feature",
      "geometry": {
        "type": "MultiPolygon",
        "coordinates": []
      },
      "properties": {
        "code": "A1",
        "name": "Zona A1",
        "type": "zdv",
        "description": "Zona di vigilanza A1",
        "keywords": "",
        "is_active": true,
        "created_at": "2026-07-22T08:00:00+02:00",
        "updated_at": "2026-07-22T08:00:00+02:00"
      }
    }
  ]
}
```

E' disponibile anche il dettaglio
`GET /api/weather_vigilance_zones/<id>/`, restituito come singola feature
GeoJSON. Le zone non attive non sono esposte né nella lista né nel dettaglio.

### `GET /api/zone_icon_anchors/`

Restituisce gli slot nei quali il client può disegnare le icone PS, raggruppati
per zona di vigilanza meteo attiva e ordinati prima per `zone_code`, poi per
`slot`. Le zone attive prive di anchor sono comunque presenti con `anchors`
vuoto.

Risposta `200 OK`:

```json
[
  {
    "zone_id": 12,
    "zone_code": "A1",
    "zone_name": "Zona A1",
    "zone_type": "zdv",
    "anchors": [
      {
        "id": 20,
        "slot": 1,
        "label": "Slot 1",
        "longitude": 9.12,
        "latitude": 44.35
      }
    ]
  }
]
```

E' disponibile anche il dettaglio
`GET /api/zone_icon_anchors/<zone_id>/`. Le zone non attive sono escluse dalla
lista e restituiscono `404 Not Found` nel dettaglio.

### `GET /api/qpf_levels/`

Restituisce i livelli di severita' QPF attribuibili alle aree di vigilanza
meteo. `image` contiene l'URL del file quando configurato; `svg` permette in
alternativa di fornire la simbologia inline.

Risposta `200 OK`:

```json
[
  {
    "id": 3,
    "code": "moderate",
    "description": "Moderata",
    "level": 2,
    "text": "Precipitazioni moderate",
    "sort_order": 20,
    "image": null,
    "color": "#ffaa00",
    "svg": "",
    "is_active": true,
    "created_at": "2026-07-22T08:00:00+02:00",
    "updated_at": "2026-07-22T08:00:00+02:00"
  }
]
```

Ordinamento: `sort_order`, `level`, `code`.

### `GET /api/ps_icons/`

Restituisce l'anagrafica delle icone di Previsione Sinottica raggruppata per
fenomeno, cosi' da rappresentare direttamente controlli gerarchici come
pioggia, temporali, temperatura, neve, vento e mare. Sono esclusi i fenomeni
disattivi, le icone disattive e i fenomeni che non possiedono icone attive.

Risposta `200 OK`:

```json
[
  {
    "id": 2,
    "code": "rain",
    "name": "Pioggia",
    "type": "zdv",
    "description": "Caratteristiche delle precipitazioni previste",
    "sort_order": 10,
    "is_active": true,
    "icons": [
      {
        "id": 7,
        "phenomenon_type_id": 2,
        "code": "continuous",
        "description": "Piogge diffuse e continue",
        "level": 2,
        "text": "Piogge diffuse e continue",
        "sort_order": 20,
        "icon": "/media/ps_levels/icons/continuous-rain.svg",
        "color": "",
        "svg": "",
        "is_active": true,
        "created_at": "2026-07-22T08:00:00+02:00",
        "updated_at": "2026-07-22T08:00:00+02:00"
      }
    ]
  }
]
```

I fenomeni sono ordinati per `sort_order`, `name`, `code`; al loro interno le
icone sono ordinate per `sort_order`, `level`, `code`. Il campo `type` indica
se le icone del fenomeno sono applicabili alle zone di vigilanza (`zdv`), alle
zone marine (`sea`) oppure a entrambe (`all`).

## Layer cartografici

### `GET /api/background_layer/`

Restituisce le feature attive del layer di sfondo configurato come una
`FeatureCollection` GeoJSON. Se non esiste una configurazione valida, usa le
feature appartenenti ai layer di sfondo attivi.

Risposta `200 OK`:

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "id": 1,
      "type": "Feature",
      "geometry": {
        "type": "Polygon",
        "coordinates": []
      },
      "properties": {
        "layer": 1,
        "code": "italy",
        "name": "Italia",
        "description": "",
        "properties": {},
        "sort_order": 0,
        "is_active": true
      }
    }
  ]
}
```

Restituisce `500 Internal Server Error` se non sono disponibili feature di
sfondo valide.

### `GET /api/ancillary_layer/`

Restituisce i layer ancillari configurati con le rispettive feature attive. Se
non esiste una configurazione valida, usa tutti i layer ancillari attivi. I
layer senza feature attive non vengono inclusi.

Risposta `200 OK`:

```json
[
  {
    "layer": {
      "id": 2,
      "code": "italy_provinces",
      "name": "Province italiane",
      "description": "",
      "layer_type": "ancillary",
      "style": {},
      "sort_order": 0,
      "is_active": true,
      "created_at": "2026-07-22T08:00:00+02:00",
      "updated_at": "2026-07-22T08:00:00+02:00"
    },
    "geojson": {
      "type": "FeatureCollection",
      "features": []
    }
  }
]
```

Restituisce `500 Internal Server Error` se non e' disponibile alcun layer
ancillare con feature attive.

### `GET /api/base_map/`

Restituisce la configurazione della base map attiva. Una base map descrive il
provider usato dal client e pertanto non contiene geometrie GeoJSON. Se la
configurazione applicativa non indica una base map valida, viene usata la prima
base map attiva secondo l'ordinamento applicativo.

Risposta `200 OK`:

```json
{
  "id": 3,
  "code": "google_maps_sat",
  "name": "Google Satellite",
  "description": "",
  "layer_type": "base",
  "style": {
    "provider": "google",
    "mapType": "satellite"
  },
  "sort_order": 0,
  "is_active": true,
  "created_at": "2026-07-22T08:00:00+02:00",
  "updated_at": "2026-07-22T08:00:00+02:00"
}
```

Restituisce `500 Internal Server Error` se non e' disponibile alcuna base map
attiva.

## Mappe sorgente

Le mappe sorgente sono una lavagna operativa indipendente dalla mappa
intermedia. Accettano soltanto zone attive di tipo `zdv`; le icone sono inoltre
limitate ai fenomeni `piogge` e `temporali`.

### Cataloghi precipitazioni

```http
GET /api/non_impulsive_precipitation_types/
GET /api/impulsive_precipitation_types/
GET /api/qpf_thresholds/
```

Le risposte contengono gli elementi attivi ordinati tramite `sort_order`, con i
campi `id`, `code`, `name`, `severity` e i timestamp. Il catalogo delle
soglie restituisce invece una configurazione sulle 24 ore per ciascuna ZVM
attiva:

```json
[
  {
    "id": 9,
    "zone_id": 12,
    "zone_code": "A1",
    "zone_name": "Zona A1",
    "weak_mm": 5,
    "moderate_mm": 20,
    "elevated_mm": 60,
    "very_elevated_mm": 100,
    "created_at": "2026-08-27T08:00:00+02:00",
    "updated_at": "2026-08-27T08:00:00+02:00"
  }
]
```

Le soglie, uniformi per tutte le ZVM, devono essere strettamente crescenti e
maggiori di zero. Le prime tre soglie sono inclusive; `very_elevated_mm=100`
usa invece il confronto stretto `>100 mm`. Non sono previste ZDA né soglie
separate per durate inferiori alle 24 ore.

### Lettura e salvataggio QPF sorgente

La tendina degli intervalli giornalieri, condivisa dalle mappe sorgente `d0`,
`d1` e `d2`, si popola tramite:

```http
GET /api/daily_precipitation_intervals/
```

La risposta è ordinata come deve comparire nel client:

```json
[
  {"id": 1, "day": "d0", "time_interval": "12:00 - 18:00", "description": "Dalle 12:00 alle 18:00"},
  {"id": 2, "day": "d0", "time_interval": "18:00 - 24:00", "description": "Dalle 18:00 alle 24:00"},
  {"id": 3, "day": "d1", "time_interval": "00:00 - 06:00", "description": "Dalle 00:00 alle 06:00"},
  {"id": 4, "day": "d1", "time_interval": "06:00 - 12:00", "description": "Dalle 06:00 alle 12:00"},
  {"id": 5, "day": "d1", "time_interval": "12:00 - 18:00", "description": "Dalle 12:00 alle 18:00"},
  {"id": 6, "day": "d1", "time_interval": "18:00 - 24:00", "description": "Dalle 18:00 alle 24:00"},
  {"id": 7, "day": "d2", "time_interval": "00:00 - 06:00", "description": "Dalle 00:00 alle 06:00"},
  {"id": 8, "day": "d2", "time_interval": "06:00 - 12:00", "description": "Dalle 06:00 alle 12:00"},
  {"id": 9, "day": "d2", "time_interval": "12:00 - 18:00", "description": "Dalle 12:00 alle 18:00"},
  {"id": 10, "day": "d2", "time_interval": "18:00 - 24:00", "description": "Dalle 18:00 alle 24:00"}
]
```

Gli ID sono esempi: il client deve sempre usare quelli restituiti
dall'anagrafica.

```http
GET /api/source_qpf/
GET /api/source_qpf/?map_id=d1
POST /api/save_source_qpf/
```

Il salvataggio sostituisce atomicamente l'intero stato del `map_id` indicato.
Questo esempio mostra una stessa ZVM con due definizioni QPF di durata diversa
e la definizione `5-20 mm / 6h` associata a tre intervalli giornalieri:

```json
{
  "map_id": "d0",
  "zones": [
    {
      "zone_id": 12,
      "non_impulsive_type_id": 2,
      "impulsive_type_id": 4,
      "amounts": [
        {"duration_hours": 3, "min_mm": 5, "max_mm": 10, "daily_precipitation_interval_id": 1},
        {"duration_hours": 6, "min_mm": 5, "max_mm": 20, "daily_precipitation_interval_id": 1},
        {"duration_hours": 6, "min_mm": 5, "max_mm": 20, "daily_precipitation_interval_id": 4},
        {"duration_hours": 6, "min_mm": 5, "max_mm": 20, "daily_precipitation_interval_id": 5}
      ]
    }
  ]
}
```

Ogni zona deve avere entrambe le classificazioni e almeno una definizione QPF
completa. Le durate ammesse sono 3, 6, 12, 18 e 24 ore; min e max sono interi
non negativi e deve valere `min_mm <= max_mm`. È univoca la coppia
`duration_hours + daily_precipitation_interval_id`: la stessa durata può quindi
comparire più volte se gli intervalli sono diversi. Ciò permette sia più
definizioni per durata diversa (per esempio `5-10 mm / 3h` e `25-35 mm / 6h`),
sia una definizione ripetuta su più intervalli.

Nella risposta di `GET /api/source_qpf/` e delle scritture ogni amount restituisce
l'oggetto selezionato, così il client può ripristinare la tendina:

```json
{
  "duration_hours": 6,
  "min_mm": 5,
  "max_mm": 20,
  "daily_precipitation_interval": {
    "id": 4,
    "day": "d1",
    "time_interval": "06:00 - 12:00",
    "description": "Dalle 06:00 alle 12:00"
  }
}
```

Il campo di scrittura `daily_precipitation_interval_id` è obbligatorio per ogni
amount e la voce selezionata deve avere `day` uguale al `map_id` della QPF. Le
righe storiche con fascia nulla restano leggibili, ma non possono essere create
o risalvate tramite le API.

Sono disponibili anche le operazioni puntuali e la cancellazione completa:

```http
PUT|DELETE /api/source_qpf/{map_id}/{zone_id}/
DELETE /api/source_qpf/{map_id}/
```

Il `DELETE` QPF sorgente ha la stessa semantica di reset della mappa
intermedia. Non elimina la zona: assegna le classificazioni impulsiva e non
impulsiva `absent` e imposta a `0` sia il minimo sia il massimo per tutte le
durate (3, 6, 12, 18 e 24 ore), con intervallo giornaliero `null` (tendina non
selezionata). La cancellazione puntuale e' idempotente e crea
direttamente l'assegnazione predefinita se non esiste.

La cancellazione completa applica lo stesso stato a tutte le zone attive di
tipo `zdv` della mappa richiesta e conserva coerenti al default anche eventuali
assegnazioni riferite a zone disattivate. Restituisce `operation: "reset"`,
`deleted_count: 0` e il numero di zone riportate al default in `reset_count`.

### Lettura e salvataggio icone sorgente

```http
GET /api/source_ps/
GET /api/source_ps/?map_id=d1
POST /api/save_source_ps/
```

Il payload segue quello di `save_current_ps`: usa `zone_id`,
`phenomenon_type_id`, `ps_level_id`, `icon_slot` e la descrizione opzionale.
Livello e fenomeno devono essere coerenti e ogni slot da 1 a 4 puo' contenere
una sola icona.

```http
PUT|DELETE /api/source_ps/{map_id}/{zone_id}/{icon_slot}/
DELETE /api/source_ps/{map_id}/
```

Le scritture sorgente producono rispettivamente le notifiche
`updateSourceQpf` e `updateSourcePs` dopo il commit.

## Promozione sorgente-intermedia

```http
POST /api/promote_source_maps/
```

L'endpoint non richiede payload. Deve essere chiamato dal client quando
l'operatore passa dalla sezione mappe sorgente a quella delle mappe
intermedie. In un'unica transazione:

1. valida che ogni ZVM presente nelle sorgenti QPF abbia le soglie sulle 24 ore;
2. elimina integralmente QPF e PS intermedi di `d0`, `d1` e `d2`;
3. ricrea le campiture QPF calcolandole dai valori sorgente;
4. copia direttamente tutte le icone PS sorgenti.

Le sorgenti restano sempre autorevoli. Una nuova chiamata sostituisce anche le
modifiche manuali effettuate dopo una promozione precedente; nessun dato
intermedio viene mai riportato nello stato sorgente.

Per ciascuna riga QPF, indipendentemente dall'intervallo giornaliero, viene
considerato `max_mm` e ragguagliato linearmente
alle 24 ore:

```text
equivalent_24h_mm = max_mm * 24 / duration_hours
```

Il confronto con le prime tre soglie della ZVM è inclusivo, mentre quello con
`very_elevated_mm` è stretto (`>`). Viene scelto il livello più alto ottenuto
tra tutte le definizioni e tutti gli intervalli della ZVM. La corrispondenza
automatica è:

| Esito | Livello |
| --- | --- |
| sotto `weak_mm` | 0, `assenti_o_deboli_non_rilevanti` |
| da `weak_mm` | 1, `deboli` |
| da `moderate_mm` | 2, `moderate` |
| da `elevated_mm` | 3, `elevate` |
| oltre `very_elevated_mm` | 4, `molto_elevate` |

Il livello 4, `molto_elevate`, viene quindi assegnato automaticamente per
valori equivalenti superiori a `100 mm/24h`. `min_mm` e le
classificazioni impulsiva/non impulsiva non determinano il colore.

La risposta `200 OK` contiene `operation: "promote"`, la data operativa e,
per ciascun giorno, gli snapshot QPF e PS risultanti:

```json
{
  "operation": "promote",
  "operational_date": "2026-08-27",
  "maps": [
    {
      "map_id": "d0",
      "qpf": {
        "operation": "promote",
        "map_id": "d0",
        "zones": []
      },
      "ps": {
        "operation": "promote",
        "map_id": "d0",
        "icons": []
      }
    }
  ]
}
```

Se manca la configurazione di una o più ZVM, restituisce `400 Bad Request` e
non modifica alcuna mappa:

```json
{
  "thresholds": [
    "Soglie QPF 24h non configurate per le ZVM: A1, B2."
  ]
}
```

Dopo il commit vengono pubblicate una notifica `updateCurrentQpf` e una
`updateCurrentPs` per ciascuno dei tre giorni.

## Stato corrente delle mappe intermedie

Gli endpoint di questa sezione restituiscono risposte sparse: sono incluse
soltanto le assegnazioni presenti nelle tabelle correnti. L'assenza di una zona
o icona significa che non esiste un valore assegnato.

Senza filtri la risposta contiene sempre D0, D1 e D2, anche quando uno o piu'
giorni sono vuoti. E' possibile richiedere un solo giorno:

```http
GET /api/current_qpf/?map_id=d1
GET /api/current_ps/?map_id=d2
```

Un valore diverso da `d0`, `d1` o `d2` restituisce `400 Bad Request`:

```json
{
  "map_id": [
    "Valore non valido. Valori ammessi: d0, d1, d2."
  ]
}
```

### `GET /api/current_qpf/`

Restituisce le campiture QPF correnti delle zone di vigilanza, raggruppate per
giorno.

Risposta `200 OK`:

```json
{
  "operational_date": "2026-07-22",
  "maps": [
    {
      "map_id": "d0",
      "valid_date": "2026-07-22",
      "zones": [
        {
          "id": 31,
          "zone_id": 12,
          "zone_code": "A1",
          "zone_name": "Zona A1",
          "zone_type": "zdv",
          "qpf": {
            "id": 3,
            "code": "moderate",
            "description": "Moderata",
            "level": 2,
            "text": "Precipitazioni moderate",
            "image": null,
            "color": "#ffaa00",
            "svg": ""
          },
          "custom_description": "Nota del previsore",
          "updated_by_id": 7,
          "created_at": "2026-07-22T08:20:00+02:00",
          "updated_at": "2026-07-22T08:30:00+02:00"
        }
      ]
    },
    {
      "map_id": "d1",
      "valid_date": "2026-07-23",
      "zones": []
    },
    {
      "map_id": "d2",
      "valid_date": "2026-07-24",
      "zones": []
    }
  ]
}
```

### `GET /api/current_ps/`

Restituisce le icone/fenomeni di Previsione Sinottica correnti, raggruppati per
giorno. `anchor` vale `null` quando per la coppia zona/slot non sono state
configurate coordinate.

Risposta `200 OK`:

```json
{
  "operational_date": "2026-07-22",
  "maps": [
    {
      "map_id": "d0",
      "valid_date": "2026-07-22",
      "icons": [
        {
          "id": 41,
          "zone_id": 12,
          "zone_code": "A1",
          "zone_name": "Zona A1",
          "zone_type": "zdv",
          "phenomenon": {
            "id": 2,
            "code": "rain",
            "name": "Pioggia",
            "description": "Precipitazione piovosa"
          },
          "ps_level": {
            "id": 7,
            "code": "heavy",
            "description": "Forte",
            "level": 3,
            "text": "Pioggia forte",
            "icon": "/media/ps_levels/icons/heavy-rain.svg",
            "color": "",
            "svg": ""
          },
          "icon_slot": 1,
          "anchor": {
            "id": 20,
            "slot": 1,
            "label": "Centro zona",
            "longitude": 9.12,
            "latitude": 44.35
          },
          "custom_description": "Nota del previsore",
          "updated_by_id": 7,
          "created_at": "2026-07-22T08:20:00+02:00",
          "updated_at": "2026-07-22T08:30:00+02:00"
        }
      ]
    },
    {
      "map_id": "d1",
      "valid_date": "2026-07-23",
      "icons": []
    },
    {
      "map_id": "d2",
      "valid_date": "2026-07-24",
      "icons": []
    }
  ]
}
```

Nelle risposte QPF e PS, `zone_type` espone il valore libero del campo `type`
della zona (per esempio `zdv` o `sea`), così il client può distinguere le zone
di vigilanza dalle zone di mare.

## Salvataggio dello stato corrente

Gli endpoint di salvataggio sostituiscono atomicamente lo stato di una singola
mappa. Il payload deve quindi contenere l'intero stato da conservare per il
`map_id` indicato:

- le assegnazioni presenti vengono inserite o aggiornate;
- le assegnazioni precedenti omesse dal payload vengono eliminate;
- un array vuoto cancella lo stato della mappa richiesta;
- D0, D1 e D2 sono indipendenti: salvare una mappa non modifica le altre;
- se anche un solo elemento non e' valido, non viene applicata alcuna modifica.

Zone, livelli e fenomeni devono essere attivi. Quando l'identita' Acroweb
autenticata corrisponde a un utente Django esistente, questo viene registrato
nel campo `updated_by`.

### `POST /api/save_current_qpf/`

Sostituisce tutte le campiture QPF della mappa indicata. Ogni zona puo'
comparire una sola volta.

Richiesta:

```json
{
  "map_id": "d0",
  "zones": [
    {
      "zone_id": 12,
      "qpf_level_id": 3,
      "custom_description": "Nota del previsore"
    }
  ]
}
```

Risposta `200 OK`:

```json
{
  "map_id": "d0",
  "operation": "replace",
  "saved_count": 1,
  "deleted_count": 2,
  "zones": [
    {
      "id": 31,
      "zone_id": 12,
      "zone_code": "A1",
      "zone_name": "Zona A1",
      "zone_type": "zdv",
      "qpf": {
        "id": 3,
        "code": "moderate",
        "description": "Moderata",
        "level": 2,
        "text": "Precipitazioni moderate",
        "image": null,
        "color": "#ffaa00",
        "svg": ""
      },
      "custom_description": "Nota del previsore",
      "updated_by_id": 7,
      "created_at": "2026-07-22T08:20:00+02:00",
      "updated_at": "2026-07-22T09:10:00+02:00"
    }
  ]
}
```

Campi del payload:

| Campo | Tipo | Obbligatorio | Descrizione |
| --- | --- | --- | --- |
| `map_id` | stringa | sì | `d0`, `d1` oppure `d2` |
| `zones` | array | sì | stato QPF completo della mappa; l'array può essere vuoto |
| `zones[].zone_id` | intero | sì, per ogni elemento | ID di una zona attiva |
| `zones[].qpf_level_id` | intero | sì, per ogni elemento | ID di un livello QPF attivo |
| `zones[].custom_description` | stringa | no | nota opzionale; se omessa viene salvata una stringa vuota |

### `POST /api/save_current_ps/`

Sostituisce tutte le icone PS della mappa indicata. Uno slot fisico puo'
contenere una sola icona per zona. Il livello PS deve appartenere al fenomeno
indicato. L'anchor geografico non e' inviato dal client: viene ricavato dalla
configurazione della coppia zona/slot e puo' essere `null` nella risposta.

Richiesta:

```json
{
  "map_id": "d0",
  "icons": [
    {
      "zone_id": 12,
      "phenomenon_type_id": 2,
      "ps_level_id": 7,
      "icon_slot": 1,
      "custom_description": "Nota del previsore"
    }
  ]
}
```

Risposta `200 OK`:

```json
{
  "map_id": "d0",
  "operation": "replace",
  "saved_count": 1,
  "deleted_count": 0,
  "icons": [
    {
      "id": 41,
      "zone_id": 12,
      "zone_code": "A1",
      "zone_name": "Zona A1",
      "zone_type": "zdv",
      "phenomenon": {
        "id": 2,
        "code": "rain",
        "name": "Pioggia",
        "description": "Precipitazione piovosa"
      },
      "ps_level": {
        "id": 7,
        "code": "heavy",
        "description": "Forte",
        "level": 3,
        "text": "Pioggia forte",
        "icon": "/media/ps_levels/icons/heavy-rain.svg",
        "color": "",
        "svg": ""
      },
      "icon_slot": 1,
      "anchor": {
        "id": 20,
        "slot": 1,
        "label": "Centro zona",
        "longitude": 9.12,
        "latitude": 44.35
      },
      "custom_description": "Nota del previsore",
      "updated_by_id": 7,
      "created_at": "2026-07-22T08:20:00+02:00",
      "updated_at": "2026-07-22T09:10:00+02:00"
    }
  ]
}
```

Campi del payload:

| Campo | Tipo | Obbligatorio | Descrizione |
| --- | --- | --- | --- |
| `map_id` | stringa | sì | `d0`, `d1` oppure `d2` |
| `icons` | array | sì | stato PS completo della mappa; l'array può essere vuoto |
| `icons[].zone_id` | intero | sì, per ogni elemento | ID di una zona attiva |
| `icons[].phenomenon_type_id` | intero | sì, per ogni elemento | ID di un fenomeno attivo |
| `icons[].ps_level_id` | intero | sì, per ogni elemento | ID di un livello PS attivo e coerente con il fenomeno |
| `icons[].icon_slot` | intero | sì, per ogni elemento | slot da 1 a 4, univoco nella zona |
| `icons[].custom_description` | stringa | no | nota opzionale; se omessa viene salvata una stringa vuota |

Per entrambi gli endpoint gli errori di validazione restituiscono
`400 Bad Request`, con il dettaglio associato al campo non valido.

### Cancellazione o reset completo di una mappa

Per riportare in un'unica operazione una mappa allo stato iniziale:

```http
DELETE /api/current_qpf/{map_id}/
DELETE /api/current_ps/{map_id}/
```

Il primo endpoint esegue un reset: assegna a tutte le zone VM attive il livello
QPF `assenti_o_deboli_non_rilevanti` (`level=0`), azzera le descrizioni
personalizzate e conserva coerenti allo stesso default anche eventuali
assegnazioni riferite a zone disattivate. Il secondo elimina realmente tutte
le icone PS. Entrambe le operazioni riguardano soltanto la mappa indicata e non
modificano gli altri giorni.

Le operazioni sono atomiche e idempotenti e non richiedono payload. Il reset VM
restituisce `operation: "reset"` e il numero di zone riportate al default:

```json
{
  "map_id": "d0",
  "operation": "reset",
  "saved_count": 1,
  "deleted_count": 0,
  "reset_count": 1,
  "zones": [
    {
      "zone_id": 12,
      "qpf": {
        "code": "assenti_o_deboli_non_rilevanti",
        "level": 0
      },
      "custom_description": ""
    }
  ]
}
```

La cancellazione PS restituisce invece `operation: "clear"`, `saved_count: 0`,
il numero di record rimossi in `deleted_count` e `icons: []`. Al termine viene
pubblicata la consueta notifica `updateCurrentQpf` o `updateCurrentPs` con lo
snapshot risultante.

### Aggiornamenti incrementali

Per il normale editing il client modifica una sola chiave logica senza
reinviare l'intera mappa:

```http
PUT /api/current_qpf/{map_id}/{zone_id}/
DELETE /api/current_qpf/{map_id}/{zone_id}/

PUT /api/current_ps/{map_id}/{zone_id}/{icon_slot}/
DELETE /api/current_ps/{map_id}/{zone_id}/{icon_slot}/
```

Esempio QPF:

```json
{
  "qpf_level_id": 3,
  "custom_description": "Nota del previsore"
}
```

Esempio PS:

```json
{
  "phenomenon_type_id": 2,
  "ps_level_id": 7,
  "custom_description": "Nota del previsore"
}
```

Le richieste `DELETE` non richiedono un payload. Per una zona VM il `DELETE`
non rimuove il record: assegna in modo idempotente il livello
`assenti_o_deboli_non_rilevanti` (`level=0`), azzera la descrizione
personalizzata e restituisce `operation: "reset"` e `reset_count: 1`. Se
l'assegnazione non esiste, viene creata direttamente al valore di default.

Per un'icona PS il `DELETE` rimuove invece lo slot e restituisce
`operation: "delete"`. Tutte le risposte incrementali contengono lo snapshot
completo della mappa, così il client può sostituire direttamente lo stato
locale con `zones` o `icons`.

Le scritture seguono la politica `last write wins`: una modifica successiva
della stessa zona o dello stesso slot sostituisce quella precedente senza
controlli di versione.

### Notifiche dello stato corrente

Dopo il salvataggio di QPF o PS il backend pubblica sul canale
`<ACROWEB3_APP_NAME>.notifications` (normalmente `ps-vm.notifications`) una
notifica contenente lo stesso snapshot restituito dalla richiesta:

```json
{
  "type": "updateCurrentQpf",
  "msg": {
    "map_id": "d0",
    "operation": "upsert",
    "saved_count": 1,
    "deleted_count": 0,
    "zones": []
  },
  "dt": "2026-07-23T10:15:30.123456+02:00"
}
```

Il campo `type` vale `updateCurrentQpf` per ogni modifica QPF e
`updateCurrentPs` per ogni modifica PS. Nel secondo caso `msg` contiene `icons`
al posto di `zones`. La notifica viene inviata dopo il completamento atomico
del salvataggio; un errore del servizio di notifica non annulla le modifiche
gia' confermate sul database.

## Preview dei bollettini PS e VMN

Il flusso applicativo completo tra client e backend e' descritto in
[Interazioni client/backend per le preview dei bollettini PS e VMN](interazioni-preview-bollettini.md).

I due prodotti hanno endpoint e snapshot indipendenti:

```http
GET  /api/ps_bulletins/
GET  /api/ps_bulletins/{id}/
POST /api/ps_bulletins/draft/
PATCH /api/ps_bulletins/{id}/
POST /api/ps_bulletins/{id}/refresh/
POST /api/ps_bulletins/{id}/finalize/
GET  /api/ps_bulletins/{id}/pdf/

GET  /api/vm_bulletins/
GET  /api/vm_bulletins/{id}/
POST /api/vm_bulletins/draft/
PATCH /api/vm_bulletins/{id}/
POST /api/vm_bulletins/{id}/refresh/
POST /api/vm_bulletins/{id}/finalize/
GET  /api/vm_bulletins/{id}/pdf/
```

`POST .../draft/` crea la bozza condivisa della giornata oppure restituisce
quella già esistente. La creazione congela in modo atomico i dati correnti e
restituisce `201` con `created: true`; il riuso restituisce `200` e
`created: false`.

`generated_sections.days` contiene `d0`, `d1` e `d2`. Ogni giorno espone le
cinque categorie fisse `precipitazioni`, `visibilita`, `temperature`, `venti`
e `mari`, i gruppi zona/livello e il testo proposto. `text_sections` contiene
le corrispondenti stringhe modificabili dal client. Una categoria vuota vale
`nessun fenomeno significativo.`.

Il `PATCH` accetta `title`, `subtitle`, `notes` e l'intero oggetto
`text_sections`. Il refresh ricostruisce gli snapshot e sovrascrive anche i
testi manuali. Entrambe le operazioni sono rifiutate con `409` dopo la
finalizzazione.

Il dettaglio PS aggiunge `qpf_rows`, costruite dalle sole sorgenti `d0` e `d1`
nelle regioni configurate in `BulletinSettings.qpf_regions`; le ZVM con firma
completa identica sono raggruppate. Il dettaglio VMN aggiunge `maps`, con
geometrie QPF e icone originali/cartografiche. La riduzione
`piogge_isolate -> piogge_sparse` e
`rovesci_isolati -> temporali_isolati` riguarda esclusivamente
`display_level` delle mappe VMN.

La finalizzazione rende lo snapshot immutabile. Il backend assegna `first` o
`update`, il numero di aggiornamento giornaliero e un progressivo annuale
indipendente per PS e VMN.

`GET .../{id}/pdf/` usa il flusso HTML di RiskAlert: passa al printservice la
route del template client costruita da `PRINT_CLIENT_PDF_BASE_URL`, quindi
archivia il PDF nel bucket S3 configurato. Le bozze sono rigenerate a ogni
richiesta; per i finalizzati viene restituita la copia S3. Sono disponibili
`isdownload=true` per forzare il download, `force=true` per rigenerare un
finalizzato e `pdftemplateurl` come fallback quando la base URL client non è
configurata. I dettagli di route e configurazione sono descritti nel documento
del flusso client/backend collegato sopra.

## Codici di risposta comuni

| Codice | Significato |
| --- | --- |
| `200 OK` | richiesta completata |
| `400 Bad Request` | parametro non valido |
| `401 Unauthorized` | autenticazione assente o non valida |
| `409 Conflict` | tentativo di modificare un bollettino finalizzato |
| `500 Internal Server Error` | configurazione o risorsa cartografica richiesta non disponibile |

## API runner

Tutti gli endpoint documentati sono inclusi nel comando interno
`test_ps_vm_api`, utilizzabile sia contro l'applicazione locale sia contro
un'installazione remota. Gli scenari disponibili sono:

| Scenario | Metodo e endpoint | Modalita' |
| --- | --- | --- |
| `background_layer` | `GET /api/background_layer/` | lettura |
| `ancillary_layer` | `GET /api/ancillary_layer/` | lettura |
| `base_map` | `GET /api/base_map/` | lettura |
| `qpf_levels` | `GET /api/qpf_levels/` | lettura |
| `qpf_thresholds` | `GET /api/qpf_thresholds/` | lettura |
| `daily_precipitation_intervals` | `GET /api/daily_precipitation_intervals/` | lettura |
| `ps_icons` | `GET /api/ps_icons/` | lettura |
| `zone_icon_anchors` | `GET /api/zone_icon_anchors/` | lettura |
| `non_impulsive_precipitation_types` | `GET /api/non_impulsive_precipitation_types/` | lettura |
| `impulsive_precipitation_types` | `GET /api/impulsive_precipitation_types/` | lettura |
| `source_qpf` | `GET /api/source_qpf/` | lettura |
| `source_ps` | `GET /api/source_ps/` | lettura |
| `save_source_qpf` | snapshot seguito da `POST /api/save_source_qpf/` | scrittura |
| `save_source_ps` | snapshot seguito da `POST /api/save_source_ps/` | scrittura |
| `clear_source_qpf` | snapshot, `DELETE /api/source_qpf/{map_id}/`, ripristino | scrittura |
| `clear_source_ps` | snapshot, `DELETE /api/source_ps/{map_id}/`, ripristino | scrittura |
| `source_qpf_item` | snapshot, `PUT`, `DELETE` e ripristino della singola zona | scrittura |
| `source_ps_item` | snapshot, `PUT`, `DELETE` e ripristino della singola icona | scrittura |
| `promote_source_maps` | snapshot, `POST /api/promote_source_maps/`, ripristino di tutte le mappe intermedie | scrittura |
| `ps_bulletins` | `GET /api/ps_bulletins/` | lettura |
| `vm_bulletins` | `GET /api/vm_bulletins/` | lettura |
| `ps_bulletin_pdf` | cerca l'ultimo PS finalizzato e invoca `GET /api/ps_bulletins/{id}/pdf/` | scrittura S3 se non archiviato |
| `vm_bulletin_pdf` | cerca l'ultimo VMN finalizzato e invoca `GET /api/vm_bulletins/{id}/pdf/` | scrittura S3 se non archiviato |
| `current_qpf` | `GET /api/current_qpf/` | lettura |
| `current_ps` | `GET /api/current_ps/` | lettura |
| `save_current_qpf` | `GET /api/current_qpf/` seguito da `POST /api/save_current_qpf/` | scrittura |
| `save_current_ps` | `GET /api/current_ps/` seguito da `POST /api/save_current_ps/` | scrittura |
| `clear_current_qpf` | snapshot, `DELETE /api/current_qpf/{map_id}/`, ripristino | scrittura |
| `clear_current_ps` | snapshot, `DELETE /api/current_ps/{map_id}/`, ripristino | scrittura |
| `current_qpf_item` | snapshot, `PUT`, `DELETE` e ripristino della singola zona | scrittura |
| `current_ps_item` | snapshot, `PUT`, `DELETE` e ripristino della singola icona | scrittura |

Esempi:

```bash
python manage.py test_ps_vm_api --read-only
python manage.py test_ps_vm_api --endpoint qpf_levels
python manage.py test_ps_vm_api --endpoint ps_icons
python manage.py test_ps_vm_api --endpoint zone_icon_anchors
python manage.py test_ps_vm_api --endpoint current_qpf --endpoint current_ps
```

## Rollover operativo

Il comando eseguito dal CronJob Kubernetes a mezzanotte locale e':

```bash
python manage.py rollover_current_maps
```

Il comando sposta atomicamente D1 in D0 e D2 in D1 per mappe sorgente e
intermedie, quindi inizializza D2. E' idempotente per data e recupera
automaticamente uno o due giorni saltati; dopo almeno tre giorni elimina le
mappe ormai fuori dall'orizzonte. Per test o recuperi controllati accetta
`--date YYYY-MM-DD`.

Gli scenari di scrittura lavorano su D0. Quelli di cancellazione e quelli
incrementali acquisiscono prima uno snapshot e ripristinano lo stato originale
dopo aver esercitato `DELETE`; non modificano quindi intenzionalmente il
contenuto finale della lavagna. Restano comunque scenari di scrittura e vengono
esclusi con `--read-only`.

Il comando `python manage.py test_ps_vm_api --list-endpoints` elenca tutti i
nomi accettati da `--endpoint` e la relativa modalita'. Le stesse chiamate sono
disponibili con `--target remote`, usando le opzioni o le variabili d'ambiente
descritte dal comando.

Il file `.vscode/launch.json` espone una configurazione per l'intera suite e una
per ciascun endpoint. La destinazione locale/remota e le credenziali remote
sono lette dalle impostazioni VS Code `psVm.apiRunner.*`; i risultati vengono
salvati in `/home/andrea/sviluppo/tmp/ps-vm-api-debug/`. La configurazione
`All Endpoints` include anche gli scenari di scrittura.
