from datetime import date
from io import BytesIO
from types import SimpleNamespace
from unittest import mock

from django.contrib.auth import get_user_model
from django.contrib.gis.geos import GEOSGeometry, Point
from django.test import override_settings
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from ps_vm_core.models import (
    BulletinKind,
    BulletinPdfArchive,
    BulletinProduct,
    BulletinSequence,
    BulletinSettings,
    BulletinStatus,
    CurPs,
    CurQpf,
    DailyPrecipitationInterval,
    ImpulsivePrecipitationType,
    MapId,
    NonImpulsivePrecipitationType,
    PhenomenonType,
    PsBulText,
    PsLevel,
    QpfLevel,
    Region,
    SourceQpf,
    SourceQpfAmount,
    VmBulText,
    ZoneIconAnchor,
    ZoneVigilanzaMeteo,
)
from ps_vm_core.pdf_archive_storage import (
    build_s3_key,
    read_pdf_bytes,
    save_pdf_bytes,
)


class BulletinApiTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username="bulletin-user")
        self.client.force_authenticate(self.user)
        self.region = Region.objects.create(code="LAZ", name="Lazio")
        self.zone_a = self._zone("A", "Zona Alfa")
        self.zone_b = self._zone("B", "Zona Beta")
        self.zone_out = self._zone("OUT", "Zona esclusa")
        self.zone_a.regions.add(self.region)
        self.zone_b.regions.add(self.region)
        settings, _created = BulletinSettings.objects.get_or_create(
            bulletin_type=BulletinProduct.PS,
            user=None,
        )
        settings.is_active = True
        settings.save()
        settings.qpf_regions.set([self.region])

        self.rain = PhenomenonType.objects.get(code="piogge")
        self.rain_isolated = PsLevel.objects.get(
            phenomenon_type=self.rain,
            code="piogge_isolate",
        )
        self.rain_sparse = PsLevel.objects.get(
            phenomenon_type=self.rain,
            code="piogge_sparse",
        )
        self.storm = PhenomenonType.objects.get(code="temporali")
        self.shower_isolated = PsLevel.objects.get(
            phenomenon_type=self.storm,
            code="rovesci_isolati",
        )
        self.storm_isolated = PsLevel.objects.get(
            phenomenon_type=self.storm,
            code="temporali_isolati",
        )
        self.qpf = QpfLevel.objects.get(code="deboli")
        for zone in (self.zone_a, self.zone_b, self.zone_out):
            ZoneIconAnchor.objects.create(
                zone=zone,
                slot=1,
                point=Point(12, 42, srid=4326),
            )
            CurQpf.objects.create(
                map_id=MapId.TODAY,
                zone=zone,
                qpf_level=self.qpf,
            )

        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone_a,
            phenomenon_type=self.rain,
            ps_level=self.rain_isolated,
            icon_slot=1,
            custom_description="in serata",
        )
        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone_b,
            phenomenon_type=self.rain,
            ps_level=self.rain_isolated,
            icon_slot=1,
            custom_description="in serata",
        )
        self._source_qpf(MapId.TODAY, self.zone_a)
        self._source_qpf(MapId.TODAY, self.zone_b)
        self._source_qpf(MapId.DAY_AFTER_TOMORROW, self.zone_a)

    def _zone(self, code, name):
        return ZoneVigilanzaMeteo.objects.create(
            code=code,
            name=name,
            geometry=GEOSGeometry(
                "MULTIPOLYGON(((10 40, 10 41, 11 41, 11 40, 10 40)))",
                srid=4326,
            ),
        )

    def _source_qpf(self, map_id, zone):
        source = SourceQpf.objects.create(
            map_id=map_id,
            zone=zone,
            non_impulsive_type=NonImpulsivePrecipitationType.objects.get(
                code="piogge_sparse"
            ),
            impulsive_type=ImpulsivePrecipitationType.objects.get(
                code="temporali_isolati"
            ),
        )
        interval = DailyPrecipitationInterval.objects.filter(day=map_id).first()
        SourceQpfAmount.objects.create(
            source_qpf=source,
            duration_hours=6,
            min_mm=5,
            max_mm=20,
            daily_precipitation_interval=interval,
        )

    def test_drafts_are_idempotent_and_products_keep_independent_texts(self):
        first = self.client.post("/api/ps_bulletins/draft/", {}, format="json")
        second = self.client.post("/api/ps_bulletins/draft/", {}, format="json")
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json")

        self.assertEqual(first.status_code, status.HTTP_201_CREATED)
        self.assertEqual(second.status_code, status.HTTP_200_OK)
        self.assertEqual(first.data["id"], second.data["id"])
        self.assertEqual(vm.status_code, status.HTTP_201_CREATED)
        self.assertEqual(PsBulText.objects.count(), 1)
        self.assertEqual(VmBulText.objects.count(), 1)
        categories = first.data["generated_sections"]["days"][0]["categories"]
        self.assertEqual(
            [item["code"] for item in categories],
            ["precipitazioni", "visibilita", "temperature", "venti", "mari"],
        )
        self.assertIn("Zona Alfa", categories[0]["generated_text"])
        self.assertEqual(categories[1]["generated_text"], "nessun fenomeno significativo.")

        edited = first.data["text_sections"]
        edited["d0"]["precipitazioni"] = "Testo PS indipendente."
        response = self.client.patch(
            f"/api/ps_bulletins/{first.data['id']}/",
            {"text_sections": edited},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertNotEqual(
            response.data["text_sections"],
            vm.data["text_sections"],
        )

    def test_optional_editorial_fields_accept_long_texts_for_each_product(self):
        ps = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data

        for field in (
            "subtitle",
            "preliminary_notes",
            "current_situation",
            "signature",
        ):
            self.assertEqual(ps[field], "")
        for field in ("subtitle", "preliminary_notes", "signature"):
            self.assertEqual(vm[field], "")
        self.assertNotIn("current_situation", vm)

        long_subtitle = "S" * 512
        ps_payload = {
            "subtitle": long_subtitle,
            "preliminary_notes": "Note preliminari PS",
            "current_situation": "Situazione corrente",
            "signature": "Firma PS",
        }
        ps_response = self.client.patch(
            f"/api/ps_bulletins/{ps['id']}/",
            ps_payload,
            format="json",
        )
        self.assertEqual(ps_response.status_code, status.HTTP_200_OK)
        for field, value in ps_payload.items():
            self.assertEqual(ps_response.data[field], value)
        saved_ps = PsBulText.objects.get(pk=ps["id"])
        for field, value in ps_payload.items():
            self.assertEqual(getattr(saved_ps, field), value)

        vm_payload = {
            "subtitle": long_subtitle,
            "preliminary_notes": "Note preliminari VMN",
            "signature": "Firma VMN",
        }
        vm_response = self.client.patch(
            f"/api/vm_bulletins/{vm['id']}/",
            vm_payload,
            format="json",
        )
        self.assertEqual(vm_response.status_code, status.HTTP_200_OK)
        for field, value in vm_payload.items():
            self.assertEqual(vm_response.data[field], value)
        saved_vm = VmBulText.objects.get(pk=vm["id"])
        for field, value in vm_payload.items():
            self.assertEqual(getattr(saved_vm, field), value)

    def test_new_editorial_fields_are_initialized_from_bulletin_settings(self):
        ps_settings = BulletinSettings.objects.get(
            bulletin_type=BulletinProduct.PS,
            user=None,
        )
        ps_settings.default_texts = {
            "preliminary_notes": "Note PS predefinite",
            "current_situation": "Situazione PS predefinita",
            "signature": "Firma PS predefinita",
        }
        ps_settings.save(update_fields=["default_texts", "updated_at"])
        vm_settings = BulletinSettings.objects.create(
            bulletin_type=BulletinProduct.VMN,
            default_texts={
                "preliminary_notes": "Note VMN predefinite",
                "signature": "Firma VMN predefinita",
            },
        )

        ps = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data

        self.assertEqual(ps["preliminary_notes"], "Note PS predefinite")
        self.assertEqual(ps["current_situation"], "Situazione PS predefinita")
        self.assertEqual(ps["signature"], "Firma PS predefinita")
        self.assertEqual(
            vm["preliminary_notes"],
            vm_settings.default_texts["preliminary_notes"],
        )
        self.assertEqual(vm["signature"], vm_settings.default_texts["signature"])

    def test_refresh_overwrites_manual_text_and_qpf_rows_are_grouped(self):
        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        qpf_row = draft["qpf_rows"][0]
        self.assertTrue(qpf_row["row_id"].startswith("qpf-"))
        self.assertEqual(qpf_row["zones_text"], "A - B")

        edited = draft["text_sections"]
        edited["d0"]["precipitazioni"] = "Modifica manuale."
        patched = self.client.patch(
            f"/api/ps_bulletins/{draft['id']}/",
            {
                "text_sections": edited,
                "qpf_row_texts": [
                    {
                        "row_id": qpf_row["row_id"],
                        "zones_text": "A - B - C e settore costiero",
                    }
                ],
            },
            format="json",
        )
        self.assertEqual(patched.status_code, status.HTTP_200_OK)
        self.assertEqual(
            patched.data["qpf_rows"][0]["zones_text"],
            "A - B - C e settore costiero",
        )
        retrieved = self.client.get(f"/api/ps_bulletins/{draft['id']}/")
        self.assertEqual(
            retrieved.data["qpf_rows"][0]["zones_text"],
            "A - B - C e settore costiero",
        )

        response = self.client.post(
            f"/api/ps_bulletins/{draft['id']}/refresh/",
            {},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertNotEqual(
            response.data["text_sections"]["d0"]["precipitazioni"],
            "Modifica manuale.",
        )
        self.assertEqual(len(response.data["qpf_rows"]), 1)
        self.assertEqual(
            [zone["code"] for zone in response.data["qpf_rows"][0]["zones"]],
            ["A", "B"],
        )
        self.assertEqual(response.data["qpf_rows"][0]["zones_text"], "A - B")

    def test_qpf_row_texts_validate_row_ids_and_allow_empty_text(self):
        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        row_id = draft["qpf_rows"][0]["row_id"]

        empty = self.client.patch(
            f"/api/ps_bulletins/{draft['id']}/",
            {"qpf_row_texts": [{"row_id": row_id, "zones_text": ""}]},
            format="json",
        )
        self.assertEqual(empty.status_code, status.HTTP_200_OK)
        self.assertEqual(empty.data["qpf_rows"][0]["zones_text"], "")

        unknown = self.client.patch(
            f"/api/ps_bulletins/{draft['id']}/",
            {"qpf_row_texts": [{"row_id": "qpf-unknown", "zones_text": "X"}]},
            format="json",
        )
        self.assertEqual(unknown.status_code, status.HTTP_400_BAD_REQUEST)

        duplicate = self.client.patch(
            f"/api/ps_bulletins/{draft['id']}/",
            {
                "qpf_row_texts": [
                    {"row_id": row_id, "zones_text": "A"},
                    {"row_id": row_id, "zones_text": "B"},
                ]
            },
            format="json",
        )
        self.assertEqual(duplicate.status_code, status.HTTP_400_BAD_REQUEST)

    def test_vm_map_collapses_only_display_levels(self):
        draft = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data
        icon = draft["maps"][0]["icons"][0]
        self.assertEqual(icon["original_level"]["code"], "piogge_isolate")
        self.assertEqual(icon["display_level"]["code"], "piogge_sparse")
        generated = draft["generated_sections"]["days"][0]["categories"][0]
        self.assertIn("Piogge isolate", generated["generated_text"])

        CurPs.objects.filter(map_id=MapId.TODAY).delete()
        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone_a,
            phenomenon_type=self.storm,
            ps_level=self.shower_isolated,
            icon_slot=1,
        )
        refreshed = self.client.post(
            f"/api/vm_bulletins/{draft['id']}/refresh/", {}, format="json"
        ).data
        icon = refreshed["maps"][0]["icons"][0]
        self.assertEqual(icon["original_level"]["code"], "rovesci_isolati")
        self.assertEqual(icon["display_level"]["code"], "temporali_isolati")

    def test_finalize_assigns_daily_type_and_independent_annual_sequences(self):
        ps1 = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        first = self.client.post(
            f"/api/ps_bulletins/{ps1['id']}/finalize/", {}, format="json"
        )
        ps2 = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        update = self.client.post(
            f"/api/ps_bulletins/{ps2['id']}/finalize/", {}, format="json"
        )
        vm = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data
        vm_first = self.client.post(
            f"/api/vm_bulletins/{vm['id']}/finalize/", {}, format="json"
        )

        self.assertEqual(first.data["bull_type"], BulletinKind.FIRST)
        self.assertEqual(first.data["progressive_number"], 1)
        self.assertEqual(update.data["bull_type"], BulletinKind.UPDATE)
        self.assertEqual(update.data["update_number"], 1)
        self.assertEqual(update.data["progressive_number"], 2)
        self.assertEqual(vm_first.data["progressive_number"], 1)
        self.assertEqual(
            BulletinSequence.objects.get(
                bulletin_type=BulletinProduct.PS,
                year=timezone.localdate().year,
            ).last_number,
            2,
        )

        immutable = self.client.patch(
            f"/api/ps_bulletins/{ps1['id']}/",
            {"title": "Non consentito"},
            format="json",
        )
        self.assertEqual(immutable.status_code, status.HTTP_409_CONFLICT)

    @override_settings(
        PRINT_CLIENT_PDF_BASE_URL="http://portal/bvps/#/print/",
        PRINTSERVICE_PDF_URL="http://printservice:8989/pdf",
        PDF_ARCHIVE_S3_BUCKET_NAME="bulletin-bucket",
    )
    @mock.patch("ps_vm_core.views.bulletins.save_pdf_bytes")
    @mock.patch("ps_vm_core.views.bulletins.get_printed_pdf")
    def test_pdf_uses_client_template_printservice_flow_and_archives_on_s3(
        self,
        get_printed_pdf,
        save_pdf_bytes_mock,
    ):
        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        pdf_bytes = b"%PDF-1.7 rendered"
        get_printed_pdf.return_value = pdf_bytes
        save_pdf_bytes_mock.return_value = SimpleNamespace(filename="bulletin.pdf")

        response = self.client.get(f"/api/ps_bulletins/{draft['id']}/pdf/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.content, pdf_bytes)
        get_printed_pdf.assert_called_once_with(
            "http://portal/bvps/#/print/ps/"
            f"{draft['id']}?portaluser=bulletin-user"
        )
        saved_bulletin, saved_content = save_pdf_bytes_mock.call_args.args
        self.assertEqual(saved_bulletin.pk, draft["id"])
        self.assertEqual(saved_content, pdf_bytes)
        self.assertEqual(
            response["Content-Disposition"],
            'inline; filename="bulletin.pdf"',
        )

    @mock.patch("ps_vm_core.views.bulletins.read_pdf_bytes")
    @mock.patch("ps_vm_core.views.bulletins.get_archive")
    def test_finalized_pdf_is_read_from_s3_without_calling_printservice(
        self,
        get_archive_mock,
        read_pdf_bytes_mock,
    ):
        draft = self.client.post("/api/vm_bulletins/draft/", {}, format="json").data
        self.client.post(
            f"/api/vm_bulletins/{draft['id']}/finalize/",
            {},
            format="json",
        )
        archive = SimpleNamespace(
            filename="vmn.pdf",
            s3_bucket="bulletin-bucket",
            s3_key=REDACTED
        )
        get_archive_mock.return_value = archive
        read_pdf_bytes_mock.return_value = b"%PDF archived"

        with mock.patch("ps_vm_core.views.bulletins.get_printed_pdf") as print_mock:
            response = self.client.get(
                f"/api/vm_bulletins/{draft['id']}/pdf/?isdownload=true"
            )

        self.assertEqual(response.content, b"%PDF archived")
        read_pdf_bytes_mock.assert_called_once_with(archive)
        print_mock.assert_not_called()
        self.assertEqual(
            response["Content-Disposition"],
            'attachment; filename="vmn.pdf"',
        )

    @override_settings(
        PDF_ARCHIVE_S3_BUCKET_NAME="bulletin-bucket",
        PDF_ARCHIVE_S3_BUCKET_BASE_PATH="ps-vm/pdf",
    )
    def test_pdf_archive_storage_matches_webalert3_s3_pattern(self):
        draft = self.client.post("/api/ps_bulletins/draft/", {}, format="json").data
        bulletin = PsBulText.objects.get(pk=draft["id"])
        s3_client = mock.Mock()
        s3_client.put_object.return_value = {"ETag": '"abc123"'}
        s3_client.get_object.return_value = {"Body": BytesIO(b"%PDF stored")}

        archive = save_pdf_bytes(bulletin, b"%PDF stored", client=s3_client)

        self.assertEqual(archive.s3_bucket, "bulletin-bucket")
        self.assertEqual(archive.s3_key, build_s3_key(bulletin))
        self.assertTrue(archive.s3_key.startswith("ps-vm/pdf/ps/"))
        self.assertFalse(archive.file.name)
        self.assertEqual(archive.size, len(b"%PDF stored"))
        self.assertEqual(archive.s3_size, len(b"%PDF stored"))
        self.assertEqual(read_pdf_bytes(archive, client=s3_client), b"%PDF stored")
        self.assertEqual(BulletinPdfArchive.objects.count(), 1)
