# Interazioni client/backend per le preview dei bollettini PS e VMN

Questo documento descrive il flusso funzionale tra un client Acroweb e le API
di composizione dei bollettini **PS** (Previsione sinottica) e **VMN**
(Vigilanza meteo nazionale). Il contratto REST di riferimento e' descritto in
[API PS/VM - Preview dei bollettini PS e VMN](api.md#preview-dei-bollettini-ps-e-vmn).

## Obiettivo e attori

Il flusso permette a un operatore autenticato di:

1. aprire o creare la bozza giornaliera di uno specifico prodotto;
2. consultare i contenuti generati dai dati meteo correnti;
3. modificare titolo, sottotitolo, note e testi delle sezioni;
4. riallineare la bozza ai dati correnti tramite refresh;
5. finalizzare il bollettino rendendolo immutabile.

Gli attori coinvolti sono:

- **operatore**, che usa l'interfaccia client;
- **client Acroweb**, che mantiene lo stato editoriale e invoca le API;
- **backend PS/VM**, che crea snapshot, valida le modifiche e gestisce il ciclo
  di vita;
- **database**, che conserva bozze, snapshot e bollettini finalizzati.

PS e VMN seguono lo stesso ciclo di vita, ma hanno endpoint e snapshot
indipendenti. Un'operazione su PS non modifica la bozza VMN e viceversa.

## Endpoint e responsabilita' del client

| Operazione | Endpoint | Uso funzionale |
| --- | --- | --- |
| Elenco | `GET /api/{product}/` | Mostrare bozze e bollettini finalizzati dal piu' recente |
| Dettaglio | `GET /api/{product}/{id}/` | Caricare un record esistente in lettura o modifica |
| Apri/crea bozza | `POST /api/{product}/draft/` | Entrare nell'editor della giornata operativa |
| Salva | `PATCH /api/{product}/{id}/` | Salvare metadati e testi editoriali |
| Aggiorna dati | `POST /api/{product}/{id}/refresh/` | Ricreare snapshot e testi dai dati meteo correnti |
| Finalizza | `POST /api/{product}/{id}/finalize/` | Chiudere l'editing e numerare il bollettino |
| PDF | `GET /api/{product}/{id}/pdf/` | Renderizzare il template client con printservice e archiviare su S3 |

Il client non crea una bozza con un normale `POST` sulla collection: usa sempre
l'azione `draft/`, che gestisce anche il riuso della bozza giornaliera.

## Prerequisiti comuni

Tutte le richieste usano la base URL `/api/` e richiedono:

```http
Authorization: Bearer <access-token>
```

L'installazione puo' richiedere anche l'header `acroweb3-domain`. In assenza di
un'autenticazione valida il backend risponde `401 Unauthorized`.

Le richieste `POST` e `PATCH` inviano JSON e devono quindi aggiungere:

```http
Content-Type: application/json
```

Nel seguito `{product}` vale `ps_bulletins` oppure `vm_bulletins`.

## Ciclo di vita

```mermaid
stateDiagram-v2
    [*] --> Bozza: POST /{product}/draft/
    Bozza --> Bozza: PATCH /{product}/{id}/
    Bozza --> Bozza: POST /{product}/{id}/refresh/
    Bozza --> Finalizzato: POST /{product}/{id}/finalize/
    Finalizzato --> Finalizzato: finalize ripetuta
```

Gli stati restituiti nel campo `status` sono `draft` e `finalized`. Per ogni
prodotto puo' esistere una sola bozza per la data operativa del server. La
bozza e' condivisa fra tutti gli operatori autenticati, non e' personale. La
data operativa e' calcolata nel fuso `Europe/Rome`.

## Apertura dell'editor

Quando l'operatore apre l'editor, il client deve invocare direttamente
`POST /api/{product}/draft/`. Non e' necessario eseguire prima una ricerca
nella lista: l'operazione e' idempotente.

```mermaid
sequenceDiagram
    actor Operatore
    participant Client
    participant API as Backend PS/VM
    participant DB as Database

    Operatore->>Client: Apre l'editor del prodotto
    Client->>API: POST /api/{product}/draft/
    API->>DB: Cerca la bozza della data operativa
    alt Bozza assente
        API->>DB: Congela dati correnti e crea snapshot
        API-->>Client: 201, created=true, dettaglio bozza
    else Bozza presente
        API-->>Client: 200, created=false, dettaglio esistente
    end
    Client-->>Operatore: Mostra testi e anteprima
```

La risposta completa deve diventare lo stato locale dell'editor. In
particolare, il client conserva `id` per le richieste successive e usa
`text_sections` per inizializzare i campi modificabili.

La creazione congela in un'unica transazione i dati meteo disponibili. Le
modifiche successive alle mappe correnti non cambiano automaticamente la
bozza gia' aperta: diventano visibili solo dopo un refresh.

## Contenuto della risposta

Il dettaglio comune ai due prodotti contiene almeno:

| Campo | Uso lato client |
| --- | --- |
| `id` | Identificativo da usare per PATCH, refresh e finalize |
| `operational_date` | Data D0 assunta dal backend |
| `day_string` | Data operativa nel formato compatto usato dal bollettino |
| `user_id` | Utente associato alla creazione o all'ultima finalizzazione |
| `status` | Abilita l'editing solo quando vale `draft` |
| `is_preview` | `true` in bozza, `false` dopo la finalizzazione |
| `bull_type`, `update_number` | Tipo e numero dell'emissione giornaliera |
| `progressive_year`, `progressive_number` | Numerazione annuale assegnata alla finalizzazione |
| `title`, `subtitle`, `preliminary_notes`, `signature`, `notes` | Metadati modificabili comuni; sono opzionali |
| `current_situation` | Situazione corrente opzionale, presente solo nel dettaglio PS |
| `generated_sections` | Contenuto strutturato generato dal backend, non modificabile |
| `text_sections` | Testi editoriali modificabili |
| `finalized_at` | Istante di finalizzazione; `null` per una bozza |
| `created_at`, `updated_at` | Informazioni temporali della bozza |

`generated_sections.days` espone `d0`, `d1` e `d2`. Ogni giorno contiene le
cinque categorie `precipitazioni`, `visibilita`, `temperature`, `venti` e
`mari`. `text_sections` deve contenere gli stessi tre giorni e tutte le cinque
categorie. Il testo predefinito di una categoria vuota e'
`nessun fenomeno significativo.`.

Il dettaglio **PS** aggiunge `qpf_rows`, con i dati QPF di `d0` e `d1`
raggruppati per firma meteorologica identica nelle regioni configurate. Ogni
riga contiene:

- `row_id`, identificatore da usare per modificare il testo della riga;
- `zones`, array strutturato e non modificabile delle zone raggruppate;
- `zones_text`, testo editoriale libero, inizializzato concatenando i codici
  con ` - ` (per esempio `A - B`).

Il dettaglio **VMN** aggiunge `maps`, una voce per `d0`, `d1` e `d2`, con:

- geometrie e livello QPF delle zone;
- icone, posizione cartografica e livello originale;
- `display_level`, eventualmente normalizzato per la sola rappresentazione
  sulla mappa.

## Salvataggio delle modifiche editoriali

Il client salva tramite:

```http
PATCH /api/{product}/{id}/

{
  "title": "Titolo modificato",
  "subtitle": "Sottotitolo modificato",
  "preliminary_notes": "Note preliminari",
  "current_situation": "Situazione corrente (solo PS)",
  "signature": "Firma",
  "notes": "Nota operativa",
  "qpf_row_texts": [
    {
      "row_id": "qpf-41-42",
      "zones_text": "A - B - C e settore costiero"
    }
  ],
  "text_sections": {
    "d0": {
      "precipitazioni": "...",
      "visibilita": "...",
      "temperature": "...",
      "venti": "...",
      "mari": "..."
    },
    "d1": {
      "precipitazioni": "...",
      "visibilita": "...",
      "temperature": "...",
      "venti": "...",
      "mari": "..."
    },
    "d2": {
      "precipitazioni": "...",
      "visibilita": "...",
      "temperature": "...",
      "venti": "...",
      "mari": "..."
    }
  }
}
```

Tutti i campi sono opzionali nel `PATCH` e i campi testuali accettano anche una
stringa vuota. `subtitle` e i nuovi campi sono testi senza limite di 255
caratteri. `current_situation` e `qpf_row_texts` sono accettati solo
dall'endpoint PS. Se viene inviato `text_sections`, pero', l'oggetto deve essere
completo: tre giorni, cinque categorie per giorno e valori di tipo stringa.
`qpf_row_texts` è invece incrementale: può contenere una o più righe e quelle
omesse non sono modificate. `zones_text` è una stringa libera, anche vuota; il
backend non ne verifica la coerenza con l'array `zones`. Un `row_id` inesistente
o duplicato produce `400 Bad Request`.

In caso di `200 OK`, il client sostituisce lo stato locale con il dettaglio
restituito dal backend. Il salvataggio va disabilitato quando `status` non e'
piu' `draft`.

Non e' previsto un campo di versione, un `ETag` o un controllo di concorrenza
ottimistico. Poiche' `text_sections` viene inviato per intero, due operatori che
salvano la stessa bozza possono sovrascriversi: per questo il client deve
evitare salvataggi paralleli, aggiornare sempre lo stato dalla risposta e
coordinare l'editing condiviso a livello di interfaccia o di processo
operativo.

## Refresh dai dati correnti

Il refresh e' un'azione esplicitamente distruttiva rispetto alle modifiche
manuali:

```http
POST /api/{product}/{id}/refresh/
{}
```

Il backend rilegge i dati meteo correnti, ricrea lo snapshot specifico del
prodotto e rigenera sia `generated_sections` sia `text_sections`. Per PS ricrea
anche le righe QPF, assegna i nuovi `row_id` e ripristina ogni `zones_text`
concatenando i codici zona con ` - `. I testi modificati dall'operatore vengono
quindi sovrascritti.

Il client dovrebbe chiedere conferma quando esistono modifiche manuali o
salvataggi editoriali successivi all'ultimo refresh. Dopo `200 OK` deve
sostituire integralmente testi e anteprima con la risposta ricevuta.

```mermaid
sequenceDiagram
    actor Operatore
    participant Client
    participant API as Backend PS/VM

    Operatore->>Client: Richiede aggiornamento dati
    Client-->>Operatore: Conferma perdita modifiche manuali
    Operatore->>Client: Conferma
    Client->>API: POST /api/{product}/{id}/refresh/
    API-->>Client: 200, nuovo snapshot e nuovi testi
    Client-->>Operatore: Sostituisce editor e anteprima
```

## Finalizzazione

La finalizzazione avviene tramite:

```http
POST /api/{product}/{id}/finalize/
{}
```

Alla prima richiesta il backend:

- imposta `status` a `finalized` e `is_preview` a `false`;
- assegna `bull_type`: `first` per la prima emissione giornaliera, altrimenti
  `update`;
- assegna `update_number` per gli aggiornamenti della giornata;
- assegna `progressive_year` e `progressive_number` usando una sequenza annuale
  indipendente per PS e VMN;
- restituisce `200 OK` con `finalized: true`.

La finalizzazione e' idempotente. Una richiesta ripetuta sullo stesso record
restituisce il dettaglio invariato con `finalized: false` e non consuma un
nuovo progressivo.

Dopo la risposta il client deve rendere l'editor in sola lettura. Ogni
successivo `PATCH` o refresh riceve `409 Conflict`.

Per produrre un aggiornamento nella stessa giornata, il client richiama
`POST /api/{product}/draft/`: non essendoci piu' una bozza aperta, il backend
crea un nuovo snapshot, che alla finalizzazione ricevera' `bull_type=update`.

## Consultazione e riapertura

Il client puo' consultare l'archivio con:

```http
GET /api/{product}/
GET /api/{product}/{id}/
```

La lista contiene sia bozze sia bollettini finalizzati ed e' ordinata dal piu'
recente. La risposta di lista e' sintetica; prima di aprire un elemento il
client deve richiederne il dettaglio. Il dettaglio restituisce lo stesso
formato usato dalle operazioni di editing. Un record finalizzato puo' essere
visualizzato, ma non riaperto in modifica.

## Gestione degli errori lato client

| Risposta | Comportamento atteso del client |
| --- | --- |
| `400 Bad Request` | Evidenziare il payload non valido; per PS puo' indicare anche una configurazione QPF globale mancante |
| `401 Unauthorized` | Avviare il normale flusso di rinnovo autenticazione o login |
| `404 Not Found` | Chiudere l'editor o ricaricare la lista: il record richiesto non esiste |
| `409 Conflict` | Ricaricare il dettaglio e passare alla modalita' di sola lettura |
| `500 Internal Server Error` | Conservare le modifiche locali e consentire un nuovo tentativo |

Durante `PATCH`, refresh e finalize il client deve impedire invii duplicati e
mostrare uno stato di avanzamento. I controlli client migliorano l'esperienza,
ma lo stato restituito dal backend rimane la fonte autorevole.

## Flusso client consigliato

1. L'utente seleziona PS o VMN.
2. Il client esegue `POST .../draft/` e carica la risposta nell'editor.
3. Le modifiche vengono salvate con `PATCH`; la risposta sostituisce lo stato
   locale.
4. Un eventuale refresh viene preceduto da una conferma e sostituisce l'intero
   snapshot locale.
5. Prima della finalizzazione il client salva le modifiche ancora pendenti.
6. Il client esegue `POST .../finalize/` e, alla risposta, passa in sola lettura.
7. Per una nuova emissione giornaliera riparte da `POST .../draft/`.

## Generazione, download e archivio PDF

Il PDF non viene composto dal backend con un renderer locale. Il backend
costruisce la route di stampa del client a partire da
`PRINT_CLIENT_PDF_BASE_URL`, aggiunge prodotto e id (`.../ps/{id}` oppure
`.../vmn/{id}`) e la passa al medesimo printservice URL-driven usato da
RiskAlert. Il client deve quindi esporre su queste route un template di stampa
che carica il dettaglio del bollettino dalle API e segnala il completamento del
rendering secondo il contratto del printservice.

Sulla linea `bricks-dev` il client è pubblicato come `bvps`, quindi la base è
`http://cima-service-portal.bricks-dev/bvps/#/print/` e gli URL completi sono
`.../#/print/ps/{id}` e `.../#/print/vmn/{id}`. Il prodotto è obbligatorio:
gli identificativi PS e VMN appartengono a tabelle e sequenze distinte e
possono quindi coincidere.

```http
GET /api/{product}/{id}/pdf/
GET /api/{product}/{id}/pdf/?isdownload=true
```

Il primo formato risponde con `Content-Disposition: inline`; con
`isdownload=true` la risposta usa `attachment`. Una bozza viene renderizzata
ogni volta, perché può ancora cambiare. Per un bollettino finalizzato il backend
riusa il PDF già archiviato su S3; `force=true` forza una nuova generazione.

Se `PRINT_CLIENT_PDF_BASE_URL` contiene placeholder, sono supportati
`{product}`/`{bulletin_type}` e `{id}`/`{bulletin_id}`. In assenza della
configurazione, per compatibilità e diagnostica si può passare l'intera route
client con `pdftemplateurl`.

Ogni PDF generato viene scritto nel bucket configurato da
`PDF_ARCHIVE_S3_BUCKET_NAME`, sotto il prefisso
`PDF_ARCHIVE_S3_BUCKET_BASE_PATH` (default `ps-vm/pdf`). Nel database restano
chiave, bucket, ETag, dimensione, content type, hash SHA-256 e data di upload;
il contenuto binario non viene salvato nel database o sul filesystem locale.
Sulla linea `bricks-dev` il deployment usa il secret Kubernetes dedicato
`ps-vm-pdf-archive-s3`, con chiavi
`PDF_ARCHIVE_S3_AWS_ACCESS_KEY_ID` e
`PDF_ARCHIVE_S3_AWS_SECRET_ACCESS_KEY`; se non sono impostate, boto3 usa la
normale credential chain del workload (ad esempio un ruolo IAM associato al
pod).
