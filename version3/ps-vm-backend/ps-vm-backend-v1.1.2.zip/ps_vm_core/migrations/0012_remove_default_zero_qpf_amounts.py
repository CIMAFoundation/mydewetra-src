from django.db import migrations


def remove_default_zero_qpf_amounts(apps, schema_editor):
    SourceQpfAmount = apps.get_model("ps_vm_core", "SourceQpfAmount")
    SourceQpfAmount.objects.filter(
        min_mm=0,
        max_mm=0,
        daily_precipitation_interval__isnull=True,
    ).delete()


class Migration(migrations.Migration):
    dependencies = [
        ("ps_vm_core", "0011_daily_precipitation_intervals"),
    ]

    operations = [
        migrations.RunPython(
            remove_default_zero_qpf_amounts,
            migrations.RunPython.noop,
        ),
    ]
