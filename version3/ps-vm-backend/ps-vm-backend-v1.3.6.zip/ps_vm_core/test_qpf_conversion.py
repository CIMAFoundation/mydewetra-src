from types import SimpleNamespace

from django.test import SimpleTestCase

from ps_vm_core.qpf_conversion import amount_severity, qpf_amounts_severity


class QpfConversionTests(SimpleTestCase):
    thresholds = SimpleNamespace(
        weak_mm=5, moderate_mm=20, elevated_mm=60, very_elevated_mm=100,
    )

    def test_boundaries_ignore_duration_and_minimum(self):
        for maximum, expected in (
            (0, 0), (4, 0), (5, 0), (6, 1), (19, 1), (20, 1),
            (21, 2), (59, 2), (60, 2), (61, 3), (100, 3), (101, 4),
        ):
            for duration in (3, 6, 12, 18, 24):
                for minimum in (0, maximum):
                    with self.subTest(max_mm=maximum, duration=duration, min_mm=minimum):
                        amount = SimpleNamespace(
                            max_mm=maximum, min_mm=minimum, duration_hours=duration,
                        )
                        self.assertEqual(amount_severity(amount, self.thresholds), expected)

    def test_uses_configured_thresholds_as_inclusive_upper_limits(self):
        thresholds = SimpleNamespace(
            weak_mm=10, moderate_mm=30, elevated_mm=70, very_elevated_mm=120,
        )
        for maximum, expected in (
            (10, 0), (11, 1), (30, 1), (31, 2),
            (70, 2), (71, 3), (120, 3), (121, 4),
        ):
            with self.subTest(max_mm=maximum):
                amount = SimpleNamespace(max_mm=maximum)
                self.assertEqual(amount_severity(amount, thresholds), expected)

    def test_worst_maximum_wins_even_when_shorter_duration_has_lower_maximum(self):
        amounts = [
            SimpleNamespace(max_mm=19, min_mm=0, duration_hours=3),
            SimpleNamespace(max_mm=61, min_mm=0, duration_hours=24),
        ]
        self.assertEqual(qpf_amounts_severity(amounts, self.thresholds), 3)

    def test_no_amounts_defaults_to_lowest_level(self):
        self.assertEqual(qpf_amounts_severity([], self.thresholds), 0)
