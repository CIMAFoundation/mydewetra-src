"""Conversione QPF condivisa da promozione e rollover operativo."""

from django.core.exceptions import ImproperlyConfigured

from ps_vm_core.models import QpfLevel


PROMOTED_QPF_LEVEL_CODES = {
    0: "assenti_o_deboli_non_rilevanti",
    1: "deboli",
    2: "moderate",
    3: "elevate",
    4: "molto_elevate",
}


def qpf_levels():
    levels = {
        item.level: item
        for item in QpfLevel.objects.filter(
            code__in=PROMOTED_QPF_LEVEL_CODES.values(),
            is_active=True,
        )
    }
    missing = [
        code
        for level, code in PROMOTED_QPF_LEVEL_CODES.items()
        if level not in levels or levels[level].code != code
    ]
    if missing:
        raise ImproperlyConfigured(
            "Livelli QPF attivi richiesti dalla conversione non configurati: "
            + ", ".join(missing)
            + "."
        )
    return levels


def amount_severity(amount, thresholds):
    """Classifica max_mm superando le soglie DB, con limiti superiori inclusi."""
    maximum = amount.max_mm
    if maximum > thresholds.very_elevated_mm:
        return 4
    if maximum > thresholds.elevated_mm:
        return 3
    if maximum > thresholds.moderate_mm:
        return 2
    if maximum > thresholds.weak_mm:
        return 1
    return 0


def qpf_amounts_severity(amounts, thresholds):
    return max(
        (
            amount_severity(amount, thresholds)
            for amount in amounts
        ),
        default=0,
    )
