from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("ps_vm_core", "0018_ps_participants"),
    ]

    operations = [
        migrations.AddField(
            model_name="psparticipant",
            name="is_selected_by_default",
            field=models.BooleanField(
                default=False,
                help_text="Preseleziona il partecipante nelle nuove bozze PS, se attivo.",
            ),
        ),
    ]
