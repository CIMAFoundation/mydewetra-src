from rest_framework_gis.serializers import GeoFeatureModelSerializer
from rest_framework import serializers

from ps_vm_core.models import MapLayer, MapLayerFeature


class MapLayerSerializer(serializers.ModelSerializer):
    class Meta:
        model = MapLayer
        fields = (
            "id",
            "code",
            "name",
            "description",
            "layer_type",
            "style",
            "sort_order",
            "is_active",
            "created_at",
            "updated_at",
        )


class MapLayerFeatureSerializer(GeoFeatureModelSerializer):
    class Meta:
        model = MapLayerFeature
        geo_field = "geometry"
        fields = (
            "id",
            "layer",
            "code",
            "name",
            "description",
            "properties",
            "sort_order",
            "is_active",
            "created_at",
            "updated_at",
        )
