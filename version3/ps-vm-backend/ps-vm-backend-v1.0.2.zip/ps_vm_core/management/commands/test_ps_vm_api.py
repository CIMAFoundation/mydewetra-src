import json
import os
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.core.serializers.json import DjangoJSONEncoder

from ps_vm_core.testing import AVAILABLE_ENDPOINTS, WRITE_ENDPOINTS, PsVmApiRunner, RemotePsVmApiRunner


class Command(BaseCommand):
    help = "Run PS-VM API scenarios as an internal replacement for Postman flows."

    def add_arguments(self, parser):
        parser.add_argument(
            "--endpoint",
            action="append",
            choices=AVAILABLE_ENDPOINTS,
            dest="endpoints",
            help="Repeat to run only selected endpoints.",
        )
        parser.add_argument(
            "--auth-file",
            default="ps_vm/acroweb_local_auth_data.json",
            help="Path to the local auth JSON file used to emulate Acroweb authentication.",
        )
        parser.add_argument(
            "--target",
            choices=("local", "remote"),
            default=os.environ.get("PS_VM_API_RUNNER_TARGET", "local"),
            help="Execution target. Defaults to PS_VM_API_RUNNER_TARGET or local.",
        )
        parser.add_argument(
            "--remote-base-url",
            default=os.environ.get("PS_VM_API_REMOTE_BASE_URL", ""),
            help="Remote API base URL, for example https://host/api/ps-vm/api/.",
        )
        parser.add_argument(
            "--remote-cookie-0",
            default=os.environ.get("PS_VM_API_REMOTE_COOKIE_0", ""),
            help="Value of the _oauth2_proxy_0 cookie used by the remote API.",
        )
        parser.add_argument(
            "--remote-cookie-1",
            default=os.environ.get("PS_VM_API_REMOTE_COOKIE_1", ""),
            help="Value of the _oauth2_proxy_1 cookie used by the remote API.",
        )
        parser.add_argument(
            "--remote-domain",
            default=os.environ.get("PS_VM_API_REMOTE_DOMAIN", ""),
            help="Optional remote chosen domain, for example cf_centrale.",
        )
        parser.add_argument(
            "--read-only",
            action="store_true",
            help="Skip write endpoints.",
        )
        parser.add_argument(
            "--dump-dir",
            help="Directory where each request/response result is saved as JSON.",
        )
        parser.add_argument(
            "--fail-fast",
            action="store_true",
            help="Stop at the first failed endpoint.",
        )
        parser.add_argument(
            "--list-endpoints",
            action="store_true",
            help="Print the available endpoint names and exit.",
        )

    def handle(self, *args, **options):
        if options["list_endpoints"]:
            for endpoint in AVAILABLE_ENDPOINTS:
                mode = "write" if endpoint in WRITE_ENDPOINTS else "read"
                self.stdout.write(f"{endpoint} [{mode}]")
            return

        target = options["target"]
        if target == "remote":
            if not options["remote_base_url"]:
                raise CommandError("Remote mode requires --remote-base-url or PS_VM_API_REMOTE_BASE_URL.")
            if not options["remote_cookie_0"] or not options["remote_cookie_1"]:
                raise CommandError(
                    "Remote mode requires both remote cookies: "
                    "--remote-cookie-0/1 or PS_VM_API_REMOTE_COOKIE_0/1."
                )
            runner = RemotePsVmApiRunner(
                base_url=options["remote_base_url"],
                oauth2_proxy_0=options["remote_cookie_0"],
                oauth2_proxy_1=options["remote_cookie_1"],
                remote_domain=options["remote_domain"],
            )
        else:
            runner = PsVmApiRunner(auth_path=options["auth_file"])

        results = runner.run(options["endpoints"], read_only=options["read_only"])

        self.stdout.write(f"Target: {runner.target}")
        if runner.target == "remote":
            self.stdout.write(f"Remote base URL: {runner.base_url}")
        else:
            self.stdout.write(f"Auth file: {runner.auth_path}")
        self.stdout.write(f"Auth domain: {runner.auth.domain}")
        self.stdout.write("")

        failed_results = []
        for result in results:
            self.stdout.write(self._format_result_line(result))
            if result.skipped:
                self.stdout.write(f"  reason: {result.skip_reason}")
                continue
            if not result.ok:
                failed_results.append(result)
                excerpt = self._excerpt(result.response_data)
                if excerpt:
                    self.stdout.write(f"  response: {excerpt}")
                if options["fail_fast"]:
                    raise CommandError(f"Endpoint failed: {result.name}")

        if options["dump_dir"]:
            dump_dir = Path(options["dump_dir"])
            self._dump_results(dump_dir, results)
            self.stdout.write("")
            self.stdout.write(f"JSON dump written to {dump_dir}")

        if failed_results:
            raise CommandError(f"{len(failed_results)} endpoint(s) failed.")

        executed = len([result for result in results if not result.skipped])
        skipped = len([result for result in results if result.skipped])
        self.stdout.write("")
        self.stdout.write(f"Completed: {executed} executed, {skipped} skipped, 0 failed.")

    def _format_result_line(self, result):
        if result.skipped:
            status_label = "SKIP"
        elif result.ok:
            status_label = "OK"
        else:
            status_label = "ERR"
        summary = self._summarize_data(result.response_data)
        return f"[{status_label}] {result.name} {result.method} {result.path} -> {result.status_code or '-'} {summary}"

    def _summarize_data(self, data):
        if isinstance(data, list):
            return f"[{len(data)} item(s)]"
        if isinstance(data, dict):
            keys = REDACTED
            if data.get("type") == "FeatureCollection":
                features = data.get("features") or []
                return f"FeatureCollection[{len(features)} feature(s)]"
            return f"{{keys: {keys}}}"
        if data in (None, ""):
            return ""
        text = str(data).replace("\n", " ").strip()
        return text[:120]

    def _excerpt(self, data):
        if data in (None, ""):
            return ""
        try:
            text = json.dumps(data, ensure_ascii=False, cls=DjangoJSONEncoder)
        except TypeError:
            text = str(data)
        return text[:300]

    def _dump_results(self, dump_dir: Path, results):
        dump_dir.mkdir(parents=True, exist_ok=True)
        summary_file = dump_dir / "summary.json"
        summary_file.write_text(
            json.dumps([result.to_dict() for result in results], indent=2, ensure_ascii=False, cls=DjangoJSONEncoder) + "\n",
            encoding="utf-8",
        )
        for index, result in enumerate(results, start=1):
            output_file = dump_dir / self._result_file_name(index, result.name)
            output_file.write_text(
                json.dumps(result.to_dict(), indent=2, ensure_ascii=False, cls=DjangoJSONEncoder) + "\n",
                encoding="utf-8",
            )

    def _result_file_name(self, index: int, name: str) -> str:
        sanitized = "".join(char if char.isalnum() else "_" for char in name).strip("_").lower()
        return f"{index:02d}_{sanitized}.json"
