from django.contrib import admin

from ps_vm_core.models import MapLayer, MapLayerFeature


@admin.register(MapLayer)
class MapLayerAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "layer_type", "sort_order", "is_active")
    list_filter = ("layer_type", "is_active")
    search_fields = ("code", "name", "description")
    ordering = ("layer_type", "sort_order", "name")


@admin.register(MapLayerFeature)
class MapLayerFeatureAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "layer", "sort_order", "is_active")
    list_filter = ("layer__layer_type", "is_active")
    search_fields = ("code", "name", "description", "layer__code", "layer__name")
    autocomplete_fields = ("layer",)
    ordering = ("layer__sort_order", "layer__code", "sort_order", "name", "code")
