from rest_framework.routers import DefaultRouter

from ps_vm_core.views.map_layers import (
    AncillaryLayerResView,
    BackgroundResView,
    BaseMapResView,
)


ps_vm_api_router = DefaultRouter()

ps_vm_api_router.register(r"background_layer", BackgroundResView, basename="background_layer")
ps_vm_api_router.register(r"ancillary_layer", AncillaryLayerResView, basename="ancillary_layer")
ps_vm_api_router.register(r"base_map", BaseMapResView, basename="base_map")
