from django.contrib.auth import get_user_model
from django.contrib.gis.geos import GEOSGeometry
from rest_framework import status
from rest_framework.test import APITestCase

from ps_vm_core.models import AppSetting, LayerType, MapLayer, MapLayerFeature


class BackgroundResViewTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username="test-user",
            password=REDACTED
        )
        self.client.force_authenticate(user=self.user)

    def _create_background_layer(self, code, sort_order=0, is_active=True):
        layer = MapLayer.objects.create(
            code=code,
            name=code,
            layer_type=LayerType.BACKGROUND,
            style={"color": "#cccccc"},
            sort_order=sort_order,
            is_active=is_active,
        )
        MapLayerFeature.objects.create(
            layer=layer,
            code=f"{code}-feature",
            name=code,
            sort_order=sort_order,
            is_active=is_active,
            geometry=GEOSGeometry(
                "POLYGON((0 0, 0 1, 1 1, 1 0, 0 0))",
                srid=4326,
            ),
        )
        return layer

    def _create_layer(self, code, layer_type, sort_order=0, is_active=True):
        return MapLayer.objects.create(
            code=code,
            name=code,
            layer_type=layer_type,
            style={"color": "#cccccc"},
            sort_order=sort_order,
            is_active=is_active,
        )

    def _create_layer_feature(self, layer, code=None, sort_order=0, is_active=True):
        return MapLayerFeature.objects.create(
            layer=layer,
            code=code or f"{layer.code}-feature",
            name=code or layer.code,
            sort_order=sort_order,
            is_active=is_active,
            geometry=GEOSGeometry(
                "POLYGON((0 0, 0 1, 1 1, 1 0, 0 0))",
                srid=4326,
            ),
        )

    def test_returns_configured_background_layer(self):
        configured_layer = self._create_background_layer("configured")
        self._create_background_layer("fallback")
        AppSetting.objects.create(
            title="PS VM",
            background_layer=configured_layer,
            is_active=True,
        )

        response = self.client.get("/api/background_layer/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["features"]), 1)
        self.assertEqual(
            response.data["features"][0]["properties"]["code"],
            "configured-feature",
        )

    def test_falls_back_to_active_background_layers(self):
        self._create_background_layer("inactive", is_active=False)
        self._create_background_layer("active")

        response = self.client.get("/api/background_layer/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["features"]), 1)
        self.assertEqual(
            response.data["features"][0]["properties"]["code"],
            "active-feature",
        )

    def test_returns_configured_ancillary_layers(self):
        configured_layer = self._create_layer("configured", LayerType.ANCILLARY)
        fallback_layer = self._create_layer("fallback", LayerType.ANCILLARY)
        self._create_layer_feature(configured_layer, "configured-feature")
        self._create_layer_feature(fallback_layer, "fallback-feature")
        app_setting = AppSetting.objects.create(title="PS VM", is_active=True)
        app_setting.ancillary_layers.add(configured_layer)

        response = self.client.get("/api/ancillary_layer/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["layer"]["code"], "configured")
        self.assertEqual(response.data[0]["geojson"]["type"], "FeatureCollection")
        self.assertEqual(len(response.data[0]["geojson"]["features"]), 1)
        self.assertEqual(
            response.data[0]["geojson"]["features"][0]["properties"]["code"],
            "configured-feature",
        )

    def test_falls_back_to_active_ancillary_layers(self):
        inactive_layer = self._create_layer(
            "inactive",
            LayerType.ANCILLARY,
            is_active=False,
        )
        active_layer = self._create_layer("active", LayerType.ANCILLARY)
        self._create_layer_feature(inactive_layer, "inactive-feature")
        self._create_layer_feature(active_layer, "active-feature")

        response = self.client.get("/api/ancillary_layer/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["layer"]["code"], "active")

    def test_returns_configured_base_map(self):
        configured_base_map = self._create_layer("google_maps_sat", LayerType.BASE)
        self._create_layer("osm_standard", LayerType.BASE)
        AppSetting.objects.create(
            title="PS VM",
            base_map=configured_base_map,
            is_active=True,
        )

        response = self.client.get("/api/base_map/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["code"], "google_maps_sat")
        self.assertEqual(response.data["layer_type"], LayerType.BASE)

    def test_falls_back_to_active_base_map(self):
        self._create_layer("inactive", LayerType.BASE, is_active=False)
        self._create_layer("active", LayerType.BASE)

        response = self.client.get("/api/base_map/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["code"], "active")
