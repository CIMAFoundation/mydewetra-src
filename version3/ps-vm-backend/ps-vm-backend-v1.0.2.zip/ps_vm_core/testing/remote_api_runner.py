from __future__ import annotations

import traceback
from contextlib import contextmanager
from types import SimpleNamespace
from typing import Any
from urllib.parse import urlsplit

import requests

from ps_vm_core.testing.api_runner import ApiCallResult, PsVmApiRunner


class RemotePsVmApiRunner(PsVmApiRunner):
    def __init__(
        self,
        *,
        base_url: str,
        oauth2_proxy_0: str,
        oauth2_proxy_1: str,
        remote_domain: str | None = None,
    ) -> None:
        self.target = "remote"
        self.auth_path = None
        self.auth = SimpleNamespace(domain=(remote_domain or "").strip(), is_authenticated=True)
        self.remote_domain = (remote_domain or "").strip()
        self.base_url = self._normalize_base_url(base_url)
        self.client = requests.Session()
        self.client.headers.update(
            {
                "Accept": "application/json, text/plain, */*",
                "User-Agent": "ps-vm-api-runner/remote",
            }
        )
        if self.remote_domain:
            self.client.headers[self._domain_request_header_name()] = self.remote_domain
        self._set_cookie("_oauth2_proxy_0", oauth2_proxy_0)
        self._set_cookie("_oauth2_proxy_1", oauth2_proxy_1)
        self._dispatch = self._build_dispatch()
        self._validate_dispatch_coverage()

    def _normalize_base_url(self, base_url: str) -> str:
        return base_url.rstrip("/")

    def _set_cookie(self, name: str, value: str) -> None:
        host = urlsplit(self.base_url).hostname or ""
        self.client.cookies.set(name, value, domain=host, path="/")

    def _remote_url(self, path: str) -> str:
        trimmed = path.strip()
        if trimmed.startswith("http://") or trimmed.startswith("https://"):
            return trimmed
        normalized = trimmed.lstrip("/")
        if normalized == "api":
            normalized = ""
        elif normalized.startswith("api/"):
            normalized = normalized[4:]
        return f"{self.base_url}/{normalized}" if normalized else self.base_url

    @contextmanager
    def _patched_side_effects(self):
        yield

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        payload: Any = None,
        format_name: str = "json",
    ):
        request_kwargs: dict[str, Any] = {
            "allow_redirects": False,
            "params": params or None,
            "timeout": 120,
        }
        if method.upper() != "GET":
            if format_name == "json":
                request_kwargs["json"] = payload or {}
            else:
                request_kwargs["data"] = payload or {}
        return self.client.request(method.upper(), self._remote_url(path), **request_kwargs)

    def _call(
        self,
        *,
        name: str,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        payload: Any = None,
        format_name: str = "json",
        meta: dict[str, Any] | None = None,
    ) -> ApiCallResult:
        try:
            response = self._request(method, path, params=params, payload=payload, format_name=format_name)
            data = self._extract_response_data(response)
            status_code = response.status_code
            ok = 200 <= response.status_code < 300
        except Exception as exc:
            data = {
                "exception_type": exc.__class__.__name__,
                "exception": str(exc),
                "traceback": traceback.format_exc(),
            }
            status_code = 500
            ok = False

        return ApiCallResult(
            name=name,
            method=method.upper(),
            path=path,
            params=params or {},
            payload=self._jsonable(payload),
            status_code=status_code,
            ok=ok,
            response_data=data,
            meta={
                **(meta or {}),
                "remote_url": self._remote_url(path),
            },
        )
