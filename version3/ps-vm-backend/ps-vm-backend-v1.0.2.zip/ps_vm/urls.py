from django.contrib import admin
from django.urls import path, re_path
from django.urls.conf import include
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from rest_framework import permissions
from ps_vm_core.urls import ps_vm_api_router
from acroweb3_api.admin_auth import bypass_admin_login


schema_view = get_schema_view(
    openapi.Info(
        title="ps-vm backend api",
        default_version='...',
        description="ps-vm backend API",
        terms_of_service="...",
        contact=openapi.Contact(email="..."),
        license=openapi.License(name="BSD License"),
    ),
    permission_classes=[permissions.AllowAny],
)

urlpatterns = [
    re_path(r'^docs/swagger(?P<format>\.json|\.yaml)$', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    re_path(r'^docs/swagger/$', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    re_path(r'^docs/redoc/$', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),

    path('prometheus/', include('django_prometheus.urls')),

    re_path(r'^admin/login/', bypass_admin_login, name='bypass_admin_login'),
    re_path(r'^admin/', admin.site.urls),

    path('api/', include(ps_vm_api_router.urls)),
]

urlpatterns += staticfiles_urlpatterns()
