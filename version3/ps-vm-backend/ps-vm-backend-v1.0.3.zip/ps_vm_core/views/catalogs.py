from django.db.models import Prefetch
from rest_framework import permissions, viewsets

from ps_vm_core.models import PhenomenonType, PsLevel, QpfLevel
from ps_vm_core.serializers import (
    PsPhenomenonCatalogSerializer,
    QpfLevelCatalogSerializer,
)


class QpfLevelResView(viewsets.ReadOnlyModelViewSet):
    """Espone i livelli di severita' QPF attivi per le tendine client."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = QpfLevelCatalogSerializer

    def get_queryset(self):
        """Restituisce solo i livelli attivi nell'ordine usato dai controlli client."""
        return QpfLevel.objects.filter(is_active=True).order_by(
            "sort_order",
            "level",
            "code",
        )


class PsIconResView(viewsets.ReadOnlyModelViewSet):
    """Espone i fenomeni sinottici attivi con le rispettive icone attive."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = PsPhenomenonCatalogSerializer

    def get_queryset(self):
        """Restituisce fenomeni e icone attivi gia' ordinati per il client."""
        active_icons = PsLevel.objects.filter(is_active=True).order_by(
            "sort_order",
            "level",
            "code",
        )
        return (
            PhenomenonType.objects.filter(
                is_active=True,
                levels__is_active=True,
            )
            .prefetch_related(Prefetch("levels", queryset=active_icons))
            .order_by("sort_order", "name", "code")
            .distinct()
        )
