from datetime import timedelta

from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone
from rest_framework import permissions, status, viewsets
from rest_framework.response import Response

from ps_vm_core.models import CurPs, CurQpf, MapId, ZoneIconAnchor
from ps_vm_core.serializers import (
    CurrentPsSerializer,
    CurrentPsWriteSerializer,
    CurrentQpfSerializer,
    CurrentQpfWriteSerializer,
)


MAP_DAY_OFFSETS = {
    MapId.TODAY: 0,
    MapId.TOMORROW: 1,
    MapId.DAY_AFTER_TOMORROW: 2,
}


def _database_user(authenticated_user):
    """Associa l'identita' autenticata a un utente Django, quando disponibile."""
    user_model = get_user_model()
    if isinstance(authenticated_user, user_model):
        return authenticated_user

    external_identifier = getattr(authenticated_user, "user", None)
    if not external_identifier:
        return None
    return user_model.objects.filter(
        **{user_model.USERNAME_FIELD: external_identifier}
    ).first()


class CurrentStateViewSet(viewsets.GenericViewSet):
    """Base per gli endpoint che espongono lo stato corrente delle mappe."""

    permission_classes = [permissions.IsAuthenticated]
    result_key = REDACTED

    def _requested_map_ids(self, request):
        """Valida il filtro `map_id` e restituisce le mappe da includere."""
        map_id = request.query_params.get("map_id")
        if map_id is None:
            return list(MAP_DAY_OFFSETS)
        if map_id not in MAP_DAY_OFFSETS:
            return None
        return [map_id]

    def list(self, request, *args, **kwargs):
        """Restituisce lo stato raggruppato per giorno e le date di validita'."""
        map_ids = self._requested_map_ids(request)
        if map_ids is None:
            return Response(
                {
                    "map_id": [
                        f"Valore non valido. Valori ammessi: {', '.join(MAP_DAY_OFFSETS)}."
                    ]
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        operational_date = timezone.localdate()
        queryset = self.filter_queryset(self.get_queryset()).filter(map_id__in=map_ids)
        grouped = {map_id: [] for map_id in map_ids}
        for item in queryset:
            grouped[item.map_id].append(item)

        context = self.get_serializer_context()
        maps = []
        for map_id in map_ids:
            serializer = self.get_serializer(
                grouped[map_id],
                many=True,
                context=context,
            )
            maps.append(
                {
                    "map_id": map_id,
                    "valid_date": operational_date
                    + timedelta(days=MAP_DAY_OFFSETS[map_id]),
                    self.result_key: serializer.data,
                }
            )

        return Response(
            {
                "operational_date": operational_date,
                "maps": maps,
            },
            status=status.HTTP_200_OK,
        )


class CurrentQpfResView(CurrentStateViewSet):
    serializer_class = CurrentQpfSerializer
    result_key = REDACTED

    def get_queryset(self):
        """Carica le assegnazioni QPF evitando query aggiuntive per zona e livello."""
        return CurQpf.objects.select_related("zone", "qpf_level").order_by(
            "map_id",
            "zone__code",
        )


class CurrentPsResView(CurrentStateViewSet):
    serializer_class = CurrentPsSerializer
    result_key = REDACTED

    def get_queryset(self):
        """Carica le icone PS con zona, fenomeno e livello in un'unica query."""
        return CurPs.objects.select_related(
            "zone",
            "phenomenon_type",
            "ps_level",
        ).order_by("map_id", "zone__code", "icon_slot", "phenomenon_type__code")

    def get_serializer_context(self):
        """Indicizza gli anchor per associare rapidamente coordinate e slot."""
        context = super().get_serializer_context()
        context["anchors"] = {
            (anchor.zone_id, anchor.slot): anchor
            for anchor in ZoneIconAnchor.objects.all()
        }
        return context


class SaveCurrentQpfResView(viewsets.GenericViewSet):
    """Sostituisce lo stato QPF corrente di una singola mappa."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = CurrentQpfWriteSerializer

    def create(self, request, *args, **kwargs):
        """Valida e salva atomicamente tutte le campiture QPF del giorno."""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        map_id = serializer.validated_data["map_id"]
        assignments = serializer.validated_data["zones"]
        updated_by = _database_user(request.user)

        with transaction.atomic():
            existing = {
                item.zone_id: item
                for item in CurQpf.objects.select_for_update().filter(map_id=map_id)
            }
            saved = []
            for assignment in assignments:
                zone = assignment["zone"]
                item = existing.pop(zone.pk, None)
                if item is None:
                    item = CurQpf(map_id=map_id, zone=zone)
                item.qpf_level = assignment["qpf_level"]
                item.custom_description = assignment.get("custom_description", "")
                item.updated_by = updated_by
                item.save()
                saved.append(item)

            deleted_count = len(existing)
            if existing:
                CurQpf.objects.filter(pk__in=[item.pk for item in existing.values()]).delete()

        response_serializer = CurrentQpfSerializer(
            saved,
            many=True,
            context=self.get_serializer_context(),
        )
        return Response(
            {
                "map_id": map_id,
                "saved_count": len(saved),
                "deleted_count": deleted_count,
                "zones": response_serializer.data,
            },
            status=status.HTTP_200_OK,
        )


class SaveCurrentPsResView(viewsets.GenericViewSet):
    """Sostituisce lo stato delle icone PS correnti di una singola mappa."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = CurrentPsWriteSerializer

    def create(self, request, *args, **kwargs):
        """Valida e salva atomicamente tutte le icone PS del giorno."""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        map_id = serializer.validated_data["map_id"]
        assignments = serializer.validated_data["icons"]
        updated_by = _database_user(request.user)

        with transaction.atomic():
            existing = {}
            duplicate_ids = []
            for item in CurPs.objects.select_for_update().filter(map_id=map_id):
                key = REDACTED
                if key in existing:
                    duplicate_ids.append(item.pk)
                else:
                    existing[key] = item

            if duplicate_ids:
                CurPs.objects.filter(pk__in=duplicate_ids).delete()

            saved = []
            for assignment in assignments:
                zone = assignment["zone"]
                key = REDACTED
                item = existing.pop(key, None)
                if item is None:
                    item = CurPs(map_id=map_id, zone=zone)
                item.phenomenon_type = assignment["phenomenon_type"]
                item.ps_level = assignment["ps_level"]
                item.icon_slot = assignment["icon_slot"]
                item.custom_description = assignment.get("custom_description", "")
                item.updated_by = updated_by
                item.save()
                saved.append(item)

            deleted_count = len(existing) + len(duplicate_ids)
            if existing:
                CurPs.objects.filter(pk__in=[item.pk for item in existing.values()]).delete()

        anchors = {
            (anchor.zone_id, anchor.slot): anchor
            for anchor in ZoneIconAnchor.objects.filter(
                zone_id__in={item.zone_id for item in saved}
            )
        }
        response_serializer = CurrentPsSerializer(
            saved,
            many=True,
            context={**self.get_serializer_context(), "anchors": anchors},
        )
        return Response(
            {
                "map_id": map_id,
                "saved_count": len(saved),
                "deleted_count": deleted_count,
                "icons": response_serializer.data,
            },
            status=status.HTTP_200_OK,
        )
