from rest_framework.routers import DefaultRouter

from ps_vm_core.views.catalogs import PsIconResView, QpfLevelResView
from ps_vm_core.views.current_state import (
    CurrentPsResView,
    CurrentQpfResView,
    SaveCurrentPsResView,
    SaveCurrentQpfResView,
)
from ps_vm_core.views.map_layers import AncillaryLayerResView, BackgroundResView, BaseMapResView

ps_vm_api_router = DefaultRouter()

ps_vm_api_router.register(r"background_layer", BackgroundResView, basename="background_layer")
ps_vm_api_router.register(r"ancillary_layer", AncillaryLayerResView, basename="ancillary_layer")
ps_vm_api_router.register(r"base_map", BaseMapResView, basename="base_map")
ps_vm_api_router.register(r"qpf_levels", QpfLevelResView, basename="qpf_levels")
ps_vm_api_router.register(r"ps_icons", PsIconResView, basename="ps_icons")
ps_vm_api_router.register(r"current_qpf", CurrentQpfResView, basename="current_qpf")
ps_vm_api_router.register(r"current_ps", CurrentPsResView, basename="current_ps")
ps_vm_api_router.register(r"save_current_qpf", SaveCurrentQpfResView, basename="save_current_qpf")
ps_vm_api_router.register(r"save_current_ps", SaveCurrentPsResView, basename="save_current_ps")
