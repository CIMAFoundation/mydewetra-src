from datetime import timedelta

from django.contrib.auth import get_user_model
from django.contrib.gis.geos import GEOSGeometry, Point
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from ps_vm_core.models import (
    AppSetting,
    CurPs,
    CurQpf,
    LayerType,
    MapId,
    MapLayer,
    MapLayerFeature,
    PhenomenonType,
    PsLevel,
    QpfLevel,
    ZoneIconAnchor,
    ZoneVigilanzaMeteo,
)


class BackgroundResViewTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username="test-user",
            password=REDACTED
        )
        self.client.force_authenticate(user=self.user)

    def _create_background_layer(self, code, sort_order=0, is_active=True):
        layer = MapLayer.objects.create(
            code=code,
            name=code,
            layer_type=LayerType.BACKGROUND,
            style={"color": "#cccccc"},
            sort_order=sort_order,
            is_active=is_active,
        )
        MapLayerFeature.objects.create(
            layer=layer,
            code=f"{code}-feature",
            name=code,
            sort_order=sort_order,
            is_active=is_active,
            geometry=GEOSGeometry(
                "POLYGON((0 0, 0 1, 1 1, 1 0, 0 0))",
                srid=4326,
            ),
        )
        return layer

    def _create_layer(self, code, layer_type, sort_order=0, is_active=True):
        return MapLayer.objects.create(
            code=code,
            name=code,
            layer_type=layer_type,
            style={"color": "#cccccc"},
            sort_order=sort_order,
            is_active=is_active,
        )

    def _create_layer_feature(self, layer, code=None, sort_order=0, is_active=True):
        return MapLayerFeature.objects.create(
            layer=layer,
            code=code or f"{layer.code}-feature",
            name=code or layer.code,
            sort_order=sort_order,
            is_active=is_active,
            geometry=GEOSGeometry(
                "POLYGON((0 0, 0 1, 1 1, 1 0, 0 0))",
                srid=4326,
            ),
        )

    def test_returns_configured_background_layer(self):
        configured_layer = self._create_background_layer("configured")
        self._create_background_layer("fallback")
        AppSetting.objects.create(
            title="PS VM",
            background_layer=configured_layer,
            is_active=True,
        )

        response = self.client.get("/api/background_layer/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["features"]), 1)
        self.assertEqual(
            response.data["features"][0]["properties"]["code"],
            "configured-feature",
        )

    def test_falls_back_to_active_background_layers(self):
        self._create_background_layer("inactive", is_active=False)
        self._create_background_layer("active")

        response = self.client.get("/api/background_layer/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["features"]), 1)
        self.assertEqual(
            response.data["features"][0]["properties"]["code"],
            "active-feature",
        )

    def test_returns_configured_ancillary_layers(self):
        configured_layer = self._create_layer("configured", LayerType.ANCILLARY)
        fallback_layer = self._create_layer("fallback", LayerType.ANCILLARY)
        self._create_layer_feature(configured_layer, "configured-feature")
        self._create_layer_feature(fallback_layer, "fallback-feature")
        app_setting = AppSetting.objects.create(title="PS VM", is_active=True)
        app_setting.ancillary_layers.add(configured_layer)

        response = self.client.get("/api/ancillary_layer/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["layer"]["code"], "configured")
        self.assertEqual(response.data[0]["geojson"]["type"], "FeatureCollection")
        self.assertEqual(len(response.data[0]["geojson"]["features"]), 1)
        self.assertEqual(
            response.data[0]["geojson"]["features"][0]["properties"]["code"],
            "configured-feature",
        )

    def test_falls_back_to_active_ancillary_layers(self):
        inactive_layer = self._create_layer(
            "inactive",
            LayerType.ANCILLARY,
            is_active=False,
        )
        active_layer = self._create_layer("active", LayerType.ANCILLARY)
        self._create_layer_feature(inactive_layer, "inactive-feature")
        self._create_layer_feature(active_layer, "active-feature")

        response = self.client.get("/api/ancillary_layer/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["layer"]["code"], "active")

    def test_returns_configured_base_map(self):
        configured_base_map = self._create_layer("google_maps_sat", LayerType.BASE)
        self._create_layer("osm_standard", LayerType.BASE)
        AppSetting.objects.create(
            title="PS VM",
            base_map=configured_base_map,
            is_active=True,
        )

        response = self.client.get("/api/base_map/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["code"], "google_maps_sat")
        self.assertEqual(response.data["layer_type"], LayerType.BASE)

    def test_falls_back_to_active_base_map(self):
        self._create_layer("inactive", LayerType.BASE, is_active=False)
        self._create_layer("active", LayerType.BASE)

        response = self.client.get("/api/base_map/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["code"], "active")


class CatalogViewTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username="catalog-user",
            password=REDACTED
        )
        self.client.force_authenticate(user=self.user)

    def test_qpf_levels_returns_only_active_levels_in_client_order(self):
        second = QpfLevel.objects.create(
            code="heavy",
            description="Abbondante",
            level=3,
            text="Precipitazioni abbondanti",
            sort_order=20,
            color="#ff0000",
        )
        first = QpfLevel.objects.create(
            code="moderate",
            description="Moderata",
            level=2,
            text="Precipitazioni moderate",
            sort_order=10,
            color="#ffaa00",
        )
        inactive = QpfLevel.objects.create(
            code="legacy",
            description="Non selezionabile",
            level=1,
            sort_order=0,
            is_active=False,
        )

        response = self.client.get("/api/qpf_levels/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(
            [item["id"] for item in response.data],
            [first.pk, second.pk],
        )
        self.assertEqual(response.data[0]["code"], "moderate")
        self.assertEqual(response.data[0]["sort_order"], 10)
        self.assertEqual(response.data[0]["color"], "#ffaa00")
        self.assertNotIn(inactive.pk, [item["id"] for item in response.data])

    def test_qpf_level_detail_does_not_expose_inactive_levels(self):
        inactive = QpfLevel.objects.create(
            code="inactive",
            description="Disattivo",
            level=1,
            is_active=False,
        )

        response = self.client.get(f"/api/qpf_levels/{inactive.pk}/")

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_ps_icons_groups_active_icons_by_active_phenomenon(self):
        wind = PhenomenonType.objects.create(
            code="wind",
            name="Vento",
            sort_order=20,
        )
        rain = PhenomenonType.objects.create(
            code="rain",
            name="Pioggia",
            sort_order=10,
        )
        inactive_phenomenon = PhenomenonType.objects.create(
            code="legacy",
            name="Legacy",
            sort_order=0,
            is_active=False,
        )
        empty_phenomenon = PhenomenonType.objects.create(
            code="empty",
            name="Senza icone",
            sort_order=0,
        )
        heavy_rain = PsLevel.objects.create(
            phenomenon_type=rain,
            code="heavy",
            description="Piogge diffuse e continue",
            level=2,
            sort_order=20,
        )
        light_rain = PsLevel.objects.create(
            phenomenon_type=rain,
            code="light",
            description="Piogge leggere",
            level=1,
            sort_order=10,
        )
        PsLevel.objects.create(
            phenomenon_type=rain,
            code="inactive",
            description="Non selezionabile",
            level=0,
            sort_order=0,
            is_active=False,
        )
        wind_icon = PsLevel.objects.create(
            phenomenon_type=wind,
            code="strong",
            description="Venti forti",
            level=1,
        )
        PsLevel.objects.create(
            phenomenon_type=inactive_phenomenon,
            code="legacy",
            description="Legacy",
            level=1,
        )

        response = self.client.get("/api/ps_icons/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(
            [phenomenon["code"] for phenomenon in response.data],
            ["rain", "wind"],
        )
        self.assertEqual(
            [icon["id"] for icon in response.data[0]["icons"]],
            [light_rain.pk, heavy_rain.pk],
        )
        self.assertEqual(
            response.data[0]["icons"][0]["phenomenon_type_id"],
            rain.pk,
        )
        self.assertEqual(response.data[1]["icons"][0]["id"], wind_icon.pk)
        self.assertNotIn(
            empty_phenomenon.pk,
            [phenomenon["id"] for phenomenon in response.data],
        )

    def test_catalogs_require_authentication(self):
        self.client.force_authenticate(user=None)

        qpf_response = self.client.get("/api/qpf_levels/")
        ps_response = self.client.get("/api/ps_icons/")

        self.assertEqual(qpf_response.status_code, status.HTTP_401_UNAUTHORIZED)
        self.assertEqual(ps_response.status_code, status.HTTP_401_UNAUTHORIZED)


class CurrentStateViewTests(APITestCase):
    def setUp(self):
        """Crea le anagrafiche minime condivise dai test dello stato corrente."""
        self.user = get_user_model().objects.create_user(
            username="state-user",
            password=REDACTED
        )
        self.client.force_authenticate(user=self.user)
        self.zone = ZoneVigilanzaMeteo.objects.create(
            code="A1",
            name="Zona A1",
            geometry=GEOSGeometry(
                "MULTIPOLYGON(((0 0, 0 1, 1 1, 1 0, 0 0)))",
                srid=4326,
            ),
        )
        self.qpf_level = QpfLevel.objects.create(
            code="moderate",
            description="Moderata",
            level=2,
            text="Precipitazioni moderate",
            color="#ffaa00",
        )
        self.phenomenon = PhenomenonType.objects.create(
            code="rain",
            name="Pioggia",
        )
        self.ps_level = PsLevel.objects.create(
            phenomenon_type=self.phenomenon,
            code="heavy",
            description="Forte",
            level=3,
            text="Pioggia forte",
        )

    def test_current_qpf_returns_all_maps_and_sparse_assignments(self):
        """La risposta QPF include D0-D2 e soltanto le assegnazioni esistenti."""
        CurQpf.objects.create(
            map_id=MapId.TOMORROW,
            zone=self.zone,
            qpf_level=self.qpf_level,
            custom_description="Nota QPF",
            updated_by=self.user,
        )

        response = self.client.get("/api/current_qpf/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["operational_date"], timezone.localdate())
        self.assertEqual(
            [item["map_id"] for item in response.data["maps"]],
            [MapId.TODAY, MapId.TOMORROW, MapId.DAY_AFTER_TOMORROW],
        )
        self.assertEqual(response.data["maps"][0]["zones"], [])
        self.assertEqual(len(response.data["maps"][1]["zones"]), 1)
        assignment = response.data["maps"][1]["zones"][0]
        self.assertEqual(assignment["zone_code"], "A1")
        self.assertEqual(assignment["qpf"]["code"], "moderate")
        self.assertEqual(assignment["custom_description"], "Nota QPF")
        self.assertEqual(
            response.data["maps"][1]["valid_date"],
            timezone.localdate() + timedelta(days=1),
        )

    def test_current_qpf_can_filter_one_map(self):
        """Il filtro `map_id` limita la risposta a un solo giorno."""
        response = self.client.get("/api/current_qpf/?map_id=d2")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["maps"]), 1)
        self.assertEqual(response.data["maps"][0]["map_id"], MapId.DAY_AFTER_TOMORROW)

    def test_current_state_rejects_invalid_map_id(self):
        """Un identificativo giorno non previsto produce una risposta 400."""
        response = self.client.get("/api/current_ps/?map_id=d3")

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("map_id", response.data)

    def test_current_ps_returns_icon_and_anchor(self):
        """L'icona PS include fenomeno, livello e coordinate dello slot."""
        ZoneIconAnchor.objects.create(
            zone=self.zone,
            slot=1,
            label="Centro zona",
            point=Point(9.12, 44.35, srid=4326),
        )
        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            phenomenon_type=self.phenomenon,
            ps_level=self.ps_level,
            icon_slot=1,
            custom_description="Nota PS",
            updated_by=self.user,
        )

        response = self.client.get("/api/current_ps/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        icon = response.data["maps"][0]["icons"][0]
        self.assertEqual(icon["zone_code"], "A1")
        self.assertEqual(icon["phenomenon"]["code"], "rain")
        self.assertEqual(icon["ps_level"]["code"], "heavy")
        self.assertEqual(icon["anchor"]["slot"], 1)
        self.assertEqual(icon["anchor"]["longitude"], 9.12)
        self.assertEqual(icon["anchor"]["latitude"], 44.35)

    def test_current_state_requires_authentication(self):
        """Gli endpoint dello stato corrente rifiutano richieste anonime."""
        self.client.force_authenticate(user=None)

        response = self.client.get("/api/current_qpf/")

        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_save_current_qpf_replaces_only_requested_map(self):
        """Il salvataggio QPF sostituisce D0 senza modificare gli altri giorni."""
        other_zone = ZoneVigilanzaMeteo.objects.create(
            code="A2",
            name="Zona A2",
            geometry=GEOSGeometry(
                "MULTIPOLYGON(((2 2, 2 3, 3 3, 3 2, 2 2)))",
                srid=4326,
            ),
        )
        CurQpf.objects.create(
            map_id=MapId.TODAY,
            zone=other_zone,
            qpf_level=self.qpf_level,
        )
        CurQpf.objects.create(
            map_id=MapId.TOMORROW,
            zone=other_zone,
            qpf_level=self.qpf_level,
        )
        payload = {
            "map_id": MapId.TODAY,
            "zones": [
                {
                    "zone_id": self.zone.pk,
                    "qpf_level_id": self.qpf_level.pk,
                    "custom_description": "Nuova campitura",
                }
            ],
        }

        response = self.client.post(
            "/api/save_current_qpf/",
            payload,
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["saved_count"], 1)
        self.assertEqual(response.data["deleted_count"], 1)
        self.assertEqual(
            list(CurQpf.objects.filter(map_id=MapId.TODAY).values_list("zone_id", flat=True)),
            [self.zone.pk],
        )
        self.assertTrue(
            CurQpf.objects.filter(
                map_id=MapId.TOMORROW,
                zone=other_zone,
            ).exists()
        )
        saved = CurQpf.objects.get(map_id=MapId.TODAY, zone=self.zone)
        self.assertEqual(saved.updated_by, self.user)

    def test_save_current_qpf_empty_list_clears_map(self):
        """Un elenco QPF vuoto rimuove tutte le assegnazioni del giorno."""
        CurQpf.objects.create(
            map_id=MapId.DAY_AFTER_TOMORROW,
            zone=self.zone,
            qpf_level=self.qpf_level,
        )

        response = self.client.post(
            "/api/save_current_qpf/",
            {"map_id": MapId.DAY_AFTER_TOMORROW, "zones": []},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["saved_count"], 0)
        self.assertEqual(response.data["deleted_count"], 1)
        self.assertFalse(
            CurQpf.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists()
        )

    def test_save_current_qpf_rejects_duplicate_zone(self):
        """La stessa zona non puo' comparire due volte nel payload QPF."""
        assignment = {
            "zone_id": self.zone.pk,
            "qpf_level_id": self.qpf_level.pk,
        }

        response = self.client.post(
            "/api/save_current_qpf/",
            {"map_id": MapId.TODAY, "zones": [assignment, assignment]},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(CurQpf.objects.exists())

    def test_save_current_ps_replaces_icons_and_returns_anchor(self):
        """Il salvataggio PS sostituisce le icone e restituisce il loro anchor."""
        ZoneIconAnchor.objects.create(
            zone=self.zone,
            slot=1,
            label="Centro zona",
            point=Point(9.12, 44.35, srid=4326),
        )
        payload = {
            "map_id": MapId.TODAY,
            "icons": [
                {
                    "zone_id": self.zone.pk,
                    "phenomenon_type_id": self.phenomenon.pk,
                    "ps_level_id": self.ps_level.pk,
                    "icon_slot": 1,
                    "custom_description": "Nuova icona",
                }
            ],
        }

        response = self.client.post(
            "/api/save_current_ps/",
            payload,
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["saved_count"], 1)
        self.assertEqual(response.data["icons"][0]["anchor"]["longitude"], 9.12)
        saved = CurPs.objects.get(map_id=MapId.TODAY, zone=self.zone, icon_slot=1)
        self.assertEqual(saved.updated_by, self.user)

    def test_save_current_ps_rejects_incoherent_level(self):
        """Un livello PS appartenente a un altro fenomeno viene rifiutato."""
        other_phenomenon = PhenomenonType.objects.create(
            code="snow",
            name="Neve",
        )
        other_level = PsLevel.objects.create(
            phenomenon_type=other_phenomenon,
            code="heavy",
            description="Forte",
            level=3,
        )
        payload = {
            "map_id": MapId.TODAY,
            "icons": [
                {
                    "zone_id": self.zone.pk,
                    "phenomenon_type_id": self.phenomenon.pk,
                    "ps_level_id": other_level.pk,
                    "icon_slot": 1,
                }
            ],
        }

        response = self.client.post(
            "/api/save_current_ps/",
            payload,
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(CurPs.objects.exists())

    def test_save_current_ps_rejects_duplicate_slot(self):
        """Due icone non possono occupare lo stesso slot della stessa zona."""
        icon = {
            "zone_id": self.zone.pk,
            "phenomenon_type_id": self.phenomenon.pk,
            "ps_level_id": self.ps_level.pk,
            "icon_slot": 1,
        }

        response = self.client.post(
            "/api/save_current_ps/",
            {"map_id": MapId.TODAY, "icons": [icon, icon]},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(CurPs.objects.exists())

    def test_save_current_state_requires_authentication(self):
        """Gli endpoint di salvataggio rifiutano richieste anonime."""
        self.client.force_authenticate(user=None)

        response = self.client.post(
            "/api/save_current_qpf/",
            {"map_id": MapId.TODAY, "zones": []},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
