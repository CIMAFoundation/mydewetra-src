# API PS/VM

Questa pagina documenta gli endpoint REST attualmente implementati dal backend
PS/VM. La base URL applicativa e':

```text
/api/
```

Sono inoltre disponibili le interfacce generate automaticamente:

```text
/docs/swagger/
/docs/redoc/
```

## Autenticazione

Tutti gli endpoint documentati richiedono un utente autenticato. In ambiente
integrato l'autenticazione e' gestita tramite il token Acroweb/OAuth2:

```http
Authorization: Bearer <access-token>
```

La selezione del dominio Acroweb puo' richiedere anche l'header configurato
dall'installazione, normalmente `acroweb3-domain`.

## Convenzioni temporali

Le mappe correnti usano identificativi relativi alla giornata operativa:

| `map_id` | Offset | Significato |
| --- | ---: | --- |
| `d0` | 0 | giorno operativo corrente |
| `d1` | 1 | giorno successivo |
| `d2` | 2 | secondo giorno successivo |

`operational_date` e' la data assunta come D0 dal server, calcolata usando il
fuso orario applicativo `Europe/Rome`. `valid_date` e' la data di calendario a
cui si riferisce la singola mappa ed e' calcolata aggiungendo a
`operational_date` l'offset di `map_id`.

Per esempio, con `operational_date` uguale a `2026-07-22`:

| `map_id` | `valid_date` |
| --- | --- |
| `d0` | `2026-07-22` |
| `d1` | `2026-07-23` |
| `d2` | `2026-07-24` |

Le date descrivono lo stato restituito, ma non identificano uno storico: le
tabelle `cur_qpf` e `cur_ps` continuano a rappresentare esclusivamente la
lavagna operativa corrente.

## Anagrafiche per la compilazione

Gli endpoint di questa sezione restituiscono soltanto elementi attivi, gia'
ordinati tramite `sort_order` e quindi direttamente utilizzabili per popolare i
controlli di scelta del client. Entrambi supportano sia la lista sia il dettaglio
(`/<id>/`) e richiedono autenticazione.

### `GET /api/qpf_levels/`

Restituisce i livelli di severita' QPF attribuibili alle aree di vigilanza
meteo. `image` contiene l'URL del file quando configurato; `svg` permette in
alternativa di fornire la simbologia inline.

Risposta `200 OK`:

```json
[
  {
    "id": 3,
    "code": "moderate",
    "description": "Moderata",
    "level": 2,
    "text": "Precipitazioni moderate",
    "sort_order": 20,
    "image": null,
    "color": "#ffaa00",
    "svg": "",
    "is_active": true,
    "created_at": "2026-07-22T08:00:00+02:00",
    "updated_at": "2026-07-22T08:00:00+02:00"
  }
]
```

Ordinamento: `sort_order`, `level`, `code`.

### `GET /api/ps_icons/`

Restituisce l'anagrafica delle icone di Previsione Sinottica raggruppata per
fenomeno, cosi' da rappresentare direttamente controlli gerarchici come
pioggia, temporali, temperatura, neve, vento e mare. Sono esclusi i fenomeni
disattivi, le icone disattive e i fenomeni che non possiedono icone attive.

Risposta `200 OK`:

```json
[
  {
    "id": 2,
    "code": "rain",
    "name": "Pioggia",
    "description": "Caratteristiche delle precipitazioni previste",
    "sort_order": 10,
    "is_active": true,
    "icons": [
      {
        "id": 7,
        "phenomenon_type_id": 2,
        "code": "continuous",
        "description": "Piogge diffuse e continue",
        "level": 2,
        "text": "Piogge diffuse e continue",
        "sort_order": 20,
        "icon": "/media/ps_levels/icons/continuous-rain.svg",
        "color": "",
        "svg": "",
        "is_active": true,
        "created_at": "2026-07-22T08:00:00+02:00",
        "updated_at": "2026-07-22T08:00:00+02:00"
      }
    ]
  }
]
```

I fenomeni sono ordinati per `sort_order`, `name`, `code`; al loro interno le
icone sono ordinate per `sort_order`, `level`, `code`.

## Layer cartografici

### `GET /api/background_layer/`

Restituisce le feature attive del layer di sfondo configurato come una
`FeatureCollection` GeoJSON. Se non esiste una configurazione valida, usa le
feature appartenenti ai layer di sfondo attivi.

Risposta `200 OK`:

```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "id": 1,
      "type": "Feature",
      "geometry": {
        "type": "Polygon",
        "coordinates": []
      },
      "properties": {
        "layer": 1,
        "code": "italy",
        "name": "Italia",
        "description": "",
        "properties": {},
        "sort_order": 0,
        "is_active": true
      }
    }
  ]
}
```

Restituisce `500 Internal Server Error` se non sono disponibili feature di
sfondo valide.

### `GET /api/ancillary_layer/`

Restituisce i layer ancillari configurati con le rispettive feature attive. Se
non esiste una configurazione valida, usa tutti i layer ancillari attivi. I
layer senza feature attive non vengono inclusi.

Risposta `200 OK`:

```json
[
  {
    "layer": {
      "id": 2,
      "code": "italy_provinces",
      "name": "Province italiane",
      "description": "",
      "layer_type": "ancillary",
      "style": {},
      "sort_order": 0,
      "is_active": true,
      "created_at": "2026-07-22T08:00:00+02:00",
      "updated_at": "2026-07-22T08:00:00+02:00"
    },
    "geojson": {
      "type": "FeatureCollection",
      "features": []
    }
  }
]
```

Restituisce `500 Internal Server Error` se non e' disponibile alcun layer
ancillare con feature attive.

### `GET /api/base_map/`

Restituisce la configurazione della base map attiva. Una base map descrive il
provider usato dal client e pertanto non contiene geometrie GeoJSON. Se la
configurazione applicativa non indica una base map valida, viene usata la prima
base map attiva secondo l'ordinamento applicativo.

Risposta `200 OK`:

```json
{
  "id": 3,
  "code": "google_maps_sat",
  "name": "Google Satellite",
  "description": "",
  "layer_type": "base",
  "style": {
    "provider": "google",
    "mapType": "satellite"
  },
  "sort_order": 0,
  "is_active": true,
  "created_at": "2026-07-22T08:00:00+02:00",
  "updated_at": "2026-07-22T08:00:00+02:00"
}
```

Restituisce `500 Internal Server Error` se non e' disponibile alcuna base map
attiva.

## Stato corrente delle mappe

Gli endpoint di questa sezione restituiscono risposte sparse: sono incluse
soltanto le assegnazioni presenti nelle tabelle correnti. L'assenza di una zona
o icona significa che non esiste un valore assegnato.

Senza filtri la risposta contiene sempre D0, D1 e D2, anche quando uno o piu'
giorni sono vuoti. E' possibile richiedere un solo giorno:

```http
GET /api/current_qpf/?map_id=d1
GET /api/current_ps/?map_id=d2
```

Un valore diverso da `d0`, `d1` o `d2` restituisce `400 Bad Request`:

```json
{
  "map_id": [
    "Valore non valido. Valori ammessi: d0, d1, d2."
  ]
}
```

### `GET /api/current_qpf/`

Restituisce le campiture QPF correnti delle zone di vigilanza, raggruppate per
giorno.

Risposta `200 OK`:

```json
{
  "operational_date": "2026-07-22",
  "maps": [
    {
      "map_id": "d0",
      "valid_date": "2026-07-22",
      "zones": [
        {
          "id": 31,
          "zone_id": 12,
          "zone_code": "A1",
          "zone_name": "Zona A1",
          "qpf": {
            "id": 3,
            "code": "moderate",
            "description": "Moderata",
            "level": 2,
            "text": "Precipitazioni moderate",
            "image": null,
            "color": "#ffaa00",
            "svg": ""
          },
          "custom_description": "Nota del previsore",
          "updated_by_id": 7,
          "created_at": "2026-07-22T08:20:00+02:00",
          "updated_at": "2026-07-22T08:30:00+02:00"
        }
      ]
    },
    {
      "map_id": "d1",
      "valid_date": "2026-07-23",
      "zones": []
    },
    {
      "map_id": "d2",
      "valid_date": "2026-07-24",
      "zones": []
    }
  ]
}
```

### `GET /api/current_ps/`

Restituisce le icone/fenomeni di Previsione Sinottica correnti, raggruppati per
giorno. `anchor` vale `null` quando per la coppia zona/slot non sono state
configurate coordinate.

Risposta `200 OK`:

```json
{
  "operational_date": "2026-07-22",
  "maps": [
    {
      "map_id": "d0",
      "valid_date": "2026-07-22",
      "icons": [
        {
          "id": 41,
          "zone_id": 12,
          "zone_code": "A1",
          "zone_name": "Zona A1",
          "phenomenon": {
            "id": 2,
            "code": "rain",
            "name": "Pioggia",
            "description": "Precipitazione piovosa"
          },
          "ps_level": {
            "id": 7,
            "code": "heavy",
            "description": "Forte",
            "level": 3,
            "text": "Pioggia forte",
            "icon": "/media/ps_levels/icons/heavy-rain.svg",
            "color": "",
            "svg": ""
          },
          "icon_slot": 1,
          "anchor": {
            "id": 20,
            "slot": 1,
            "label": "Centro zona",
            "longitude": 9.12,
            "latitude": 44.35
          },
          "custom_description": "Nota del previsore",
          "updated_by_id": 7,
          "created_at": "2026-07-22T08:20:00+02:00",
          "updated_at": "2026-07-22T08:30:00+02:00"
        }
      ]
    },
    {
      "map_id": "d1",
      "valid_date": "2026-07-23",
      "icons": []
    },
    {
      "map_id": "d2",
      "valid_date": "2026-07-24",
      "icons": []
    }
  ]
}
```

## Salvataggio dello stato corrente

Gli endpoint di salvataggio sostituiscono atomicamente lo stato di una singola
mappa. Il payload deve quindi contenere l'intero stato da conservare per il
`map_id` indicato:

- le assegnazioni presenti vengono inserite o aggiornate;
- le assegnazioni precedenti omesse dal payload vengono eliminate;
- un array vuoto cancella lo stato della mappa richiesta;
- D0, D1 e D2 sono indipendenti: salvare una mappa non modifica le altre;
- se anche un solo elemento non e' valido, non viene applicata alcuna modifica.

Zone, livelli e fenomeni devono essere attivi. Quando l'identita' Acroweb
autenticata corrisponde a un utente Django esistente, questo viene registrato
nel campo `updated_by`.

### `POST /api/save_current_qpf/`

Sostituisce tutte le campiture QPF della mappa indicata. Ogni zona puo'
comparire una sola volta.

Richiesta:

```json
{
  "map_id": "d0",
  "zones": [
    {
      "zone_id": 12,
      "qpf_level_id": 3,
      "custom_description": "Nota del previsore"
    }
  ]
}
```

Risposta `200 OK`:

```json
{
  "map_id": "d0",
  "saved_count": 1,
  "deleted_count": 2,
  "zones": [
    {
      "id": 31,
      "zone_id": 12,
      "zone_code": "A1",
      "zone_name": "Zona A1",
      "qpf": {
        "id": 3,
        "code": "moderate",
        "description": "Moderata",
        "level": 2,
        "text": "Precipitazioni moderate",
        "image": null,
        "color": "#ffaa00",
        "svg": ""
      },
      "custom_description": "Nota del previsore",
      "updated_by_id": 7,
      "created_at": "2026-07-22T08:20:00+02:00",
      "updated_at": "2026-07-22T09:10:00+02:00"
    }
  ]
}
```

Campi obbligatori:

| Campo | Tipo | Descrizione |
| --- | --- | --- |
| `map_id` | stringa | `d0`, `d1` oppure `d2` |
| `zones` | array | stato QPF completo della mappa, anche vuoto |
| `zones[].zone_id` | intero | ID di una zona attiva |
| `zones[].qpf_level_id` | intero | ID di un livello QPF attivo |
| `zones[].custom_description` | stringa | nota opzionale, default stringa vuota |

### `POST /api/save_current_ps/`

Sostituisce tutte le icone PS della mappa indicata. Uno slot fisico puo'
contenere una sola icona per zona. Il livello PS deve appartenere al fenomeno
indicato. L'anchor geografico non e' inviato dal client: viene ricavato dalla
configurazione della coppia zona/slot e puo' essere `null` nella risposta.

Richiesta:

```json
{
  "map_id": "d0",
  "icons": [
    {
      "zone_id": 12,
      "phenomenon_type_id": 2,
      "ps_level_id": 7,
      "icon_slot": 1,
      "custom_description": "Nota del previsore"
    }
  ]
}
```

Risposta `200 OK`:

```json
{
  "map_id": "d0",
  "saved_count": 1,
  "deleted_count": 0,
  "icons": [
    {
      "id": 41,
      "zone_id": 12,
      "zone_code": "A1",
      "zone_name": "Zona A1",
      "phenomenon": {
        "id": 2,
        "code": "rain",
        "name": "Pioggia",
        "description": "Precipitazione piovosa"
      },
      "ps_level": {
        "id": 7,
        "code": "heavy",
        "description": "Forte",
        "level": 3,
        "text": "Pioggia forte",
        "icon": "/media/ps_levels/icons/heavy-rain.svg",
        "color": "",
        "svg": ""
      },
      "icon_slot": 1,
      "anchor": {
        "id": 20,
        "slot": 1,
        "label": "Centro zona",
        "longitude": 9.12,
        "latitude": 44.35
      },
      "custom_description": "Nota del previsore",
      "updated_by_id": 7,
      "created_at": "2026-07-22T08:20:00+02:00",
      "updated_at": "2026-07-22T09:10:00+02:00"
    }
  ]
}
```

Campi obbligatori:

| Campo | Tipo | Descrizione |
| --- | --- | --- |
| `map_id` | stringa | `d0`, `d1` oppure `d2` |
| `icons` | array | stato PS completo della mappa, anche vuoto |
| `icons[].zone_id` | intero | ID di una zona attiva |
| `icons[].phenomenon_type_id` | intero | ID di un fenomeno attivo |
| `icons[].ps_level_id` | intero | ID di un livello PS attivo e coerente con il fenomeno |
| `icons[].icon_slot` | intero | slot da 1 a 4, univoco nella zona |
| `icons[].custom_description` | stringa | nota opzionale, default stringa vuota |

Per entrambi gli endpoint gli errori di validazione restituiscono
`400 Bad Request`, con il dettaglio associato al campo non valido.

## Codici di risposta comuni

| Codice | Significato |
| --- | --- |
| `200 OK` | richiesta completata |
| `400 Bad Request` | parametro non valido |
| `401 Unauthorized` | autenticazione assente o non valida |
| `500 Internal Server Error` | configurazione o risorsa cartografica richiesta non disponibile |

## API runner

Tutti gli endpoint documentati sono inclusi nel comando interno
`test_ps_vm_api`, utilizzabile sia contro l'applicazione locale sia contro
un'installazione remota. Gli scenari disponibili sono:

| Scenario | Metodo e endpoint | Modalita' |
| --- | --- | --- |
| `background_layer` | `GET /api/background_layer/` | lettura |
| `ancillary_layer` | `GET /api/ancillary_layer/` | lettura |
| `base_map` | `GET /api/base_map/` | lettura |
| `qpf_levels` | `GET /api/qpf_levels/` | lettura |
| `ps_icons` | `GET /api/ps_icons/` | lettura |
| `current_qpf` | `GET /api/current_qpf/` | lettura |
| `current_ps` | `GET /api/current_ps/` | lettura |
| `save_current_qpf` | `GET /api/current_qpf/` seguito da `POST /api/save_current_qpf/` | scrittura |
| `save_current_ps` | `GET /api/current_ps/` seguito da `POST /api/save_current_ps/` | scrittura |

Esempi:

```bash
python manage.py test_ps_vm_api --read-only
python manage.py test_ps_vm_api --endpoint qpf_levels
python manage.py test_ps_vm_api --endpoint ps_icons
python manage.py test_ps_vm_api --endpoint current_qpf --endpoint current_ps
```

Gli scenari di salvataggio lavorano su D0: leggono lo stato corrente e lo
riscrivono invariato, esercitando l'endpoint senza modificare intenzionalmente
il contenuto della lavagna. Restano comunque scenari di scrittura e vengono
esclusi con `--read-only`.

Il comando `python manage.py test_ps_vm_api --list-endpoints` elenca tutti i
nomi accettati da `--endpoint` e la relativa modalita'. Le stesse chiamate sono
disponibili con `--target remote`, usando le opzioni o le variabili d'ambiente
descritte dal comando.

Il file `.vscode/launch.json` espone una configurazione per l'intera suite e una
per ciascun endpoint. La destinazione locale/remota e le credenziali remote
sono lette dalle impostazioni VS Code `psVm.apiRunner.*`; i risultati vengono
salvati in `/tmp/ps-vm-api-debug`. La configurazione `All Endpoints` include
anche i due scenari di scrittura.
