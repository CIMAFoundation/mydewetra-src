-- Importa public.layer_zone_vigilanza nell'anagrafica delle zone di vigilanza meteo.
-- Lo script e' idempotente: puo' essere rieseguito per aggiornare i dati.
-- Le geometrie vengono copiate dalla sorgente senza trasformazioni.
-- Tutte le tabelle coinvolte appartengono allo schema public.

BEGIN;

INSERT INTO public.ps_vm_core_zone_vigilanza_meteo (
    created_at,
    updated_at,
    code,
    name,
    description,
    keywords,
    is_active,
    geometry
)
SELECT
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    source_zone.code,
    source_zone.name,
    source_zone.name,
    '' AS keywords,
    TRUE AS is_active,
    source_zone.geometry
FROM (
    SELECT DISTINCT ON (TRIM(source_area.numero_are))
        TRIM(source_area.numero_are)::text AS code,
        COALESCE(
            NULLIF(TRIM(source_area.nome_area), ''),
            TRIM(source_area.numero_are)::text
        ) AS name,
        source_area.geom AS geometry
    FROM public.layer_zone_vigilanza AS source_area
    WHERE source_area.numero_are IS NOT NULL
      AND NULLIF(TRIM(source_area.numero_are), '') IS NOT NULL
      AND source_area.geom IS NOT NULL
    ORDER BY
        TRIM(source_area.numero_are),
        source_area.id
) AS source_zone
ORDER BY
    CASE
        WHEN source_zone.code ~ '^[0-9]+$' THEN source_zone.code::integer
    END NULLS LAST,
    source_zone.code
ON CONFLICT (code) DO UPDATE
SET
    updated_at = CURRENT_TIMESTAMP,
    name = EXCLUDED.name,
    description = EXCLUDED.description,
    keywords = REDACTED
    is_active = EXCLUDED.is_active,
    geometry = EXCLUDED.geometry;

COMMIT;

-- Verifica facoltativa dopo l'importazione:
-- SELECT
--     id,
--     code,
--     name,
--     is_active,
--     ST_GeometryType(geometry) AS geometry_type
-- FROM public.ps_vm_core_zone_vigilanza_meteo
-- ORDER BY
--     CASE
--         WHEN code ~ '^[0-9]+$' THEN code::integer
--     END NULLS LAST,
--     code;
--
-- Verifica facoltativa dei codici duplicati nella sorgente:
-- SELECT
--     numero_are,
--     COUNT(*) AS count
-- FROM public.layer_zone_vigilanza
-- WHERE numero_are IS NOT NULL
--   AND NULLIF(TRIM(numero_are), '') IS NOT NULL
-- GROUP BY numero_are
-- HAVING COUNT(*) > 1
-- ORDER BY numero_are;

