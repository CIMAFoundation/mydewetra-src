import logging
from enum import Enum

from acroweb3_api import tools
from django.conf import settings
from django.utils import timezone


logger = logging.getLogger(__name__)


class NotificationType(Enum):
    """Tipi di aggiornamento dello stato corrente inviati ai client."""

    UPDATE_CURRENT_QPF = "updateCurrentQpf"
    UPDATE_CURRENT_PS = "updateCurrentPs"


def send_notify_to_client(request, notification_type: NotificationType, message):
    """Pubblica una notifica senza invalidare un salvataggio gia' completato."""
    try:
        tools.send_notification(
            request,
            f"{settings.ACROWEB3_APP_NAME}.notifications",
            {
                "type": notification_type.value,
                "msg": message,
                "dt": timezone.now().isoformat(),
            },
        )
    except Exception:
        logger.exception(
            "Impossibile inviare la notifica %s ai client.",
            notification_type.value,
        )
