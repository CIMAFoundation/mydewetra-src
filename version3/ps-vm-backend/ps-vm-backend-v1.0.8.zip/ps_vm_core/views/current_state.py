from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.exceptions import ImproperlyConfigured
from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import permissions, status, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

from ps_vm_core.models import (
    CurPs,
    CurQpf,
    MapId,
    QpfLevel,
    ZoneIconAnchor,
    ZoneVigilanzaMeteo,
)
from ps_vm_core.notify import NotificationType, send_notify_to_client
from ps_vm_core.serializers import (
    CurrentPsItemWriteSerializer,
    CurrentPsSerializer,
    CurrentPsWriteSerializer,
    CurrentQpfItemWriteSerializer,
    CurrentQpfSerializer,
    CurrentQpfWriteSerializer,
)


MAP_DAY_OFFSETS = {
    MapId.TODAY: 0,
    MapId.TOMORROW: 1,
    MapId.DAY_AFTER_TOMORROW: 2,
}
DEFAULT_QPF_LEVEL_CODE = "assenti_o_deboli_non_rilevanti"


def _qpf_snapshot(
    request,
    map_id,
    operation,
    deleted_count=0,
    reset_count=None,
):
    items = list(
        CurQpf.objects.select_related("zone", "qpf_level")
        .filter(map_id=map_id)
        .order_by("zone__code")
    )
    serializer = CurrentQpfSerializer(
        items,
        many=True,
        context={"request": request},
    )
    data = {
        "map_id": map_id,
        "operation": operation,
        "saved_count": len(items),
        "deleted_count": deleted_count,
        "zones": serializer.data,
    }
    if reset_count is not None:
        data["reset_count"] = reset_count
    return data


def _ps_snapshot(request, map_id, operation, deleted_count=0):
    items = list(
        CurPs.objects.select_related("zone", "phenomenon_type", "ps_level")
        .filter(map_id=map_id)
        .order_by("zone__code", "icon_slot", "phenomenon_type__code")
    )
    anchors = {
        (anchor.zone_id, anchor.slot): anchor
        for anchor in ZoneIconAnchor.objects.filter(
            zone_id__in={item.zone_id for item in items}
        )
    }
    serializer = CurrentPsSerializer(
        items,
        many=True,
        context={"request": request, "anchors": anchors},
    )
    return {
        "map_id": map_id,
        "operation": operation,
        "saved_count": len(items),
        "deleted_count": deleted_count,
        "icons": serializer.data,
    }


def _notify_after_commit(request, notification_type, response_data):
    transaction.on_commit(
        lambda: send_notify_to_client(
            request,
            notification_type,
            response_data,
        )
    )


def _database_user(authenticated_user):
    """Associa l'identita' autenticata a un utente Django, quando disponibile."""
    user_model = get_user_model()
    if isinstance(authenticated_user, user_model):
        return authenticated_user

    external_identifier = getattr(authenticated_user, "user", None)
    if not external_identifier:
        return None
    return user_model.objects.filter(
        **{user_model.USERNAME_FIELD: external_identifier}
    ).first()


def _default_qpf_level():
    """Restituisce il livello VM usato per il reset dello stato."""
    try:
        return QpfLevel.objects.get(
            code=DEFAULT_QPF_LEVEL_CODE,
            level=0,
            is_active=True,
        )
    except QpfLevel.DoesNotExist as exc:
        raise ImproperlyConfigured(
            "Livello QPF di default attivo non configurato: "
            f"{DEFAULT_QPF_LEVEL_CODE} (level=0)."
        ) from exc


class CurrentStateViewSet(viewsets.GenericViewSet):
    """Base per gli endpoint che espongono lo stato corrente delle mappe."""

    permission_classes = [permissions.IsAuthenticated]
    result_key = REDACTED

    def _requested_map_ids(self, request):
        """Valida il filtro `map_id` e restituisce le mappe da includere."""
        map_id = request.query_params.get("map_id")
        if map_id is None:
            return list(MAP_DAY_OFFSETS)
        if map_id not in MAP_DAY_OFFSETS:
            return None
        return [map_id]

    def list(self, request, *args, **kwargs):
        """Restituisce lo stato raggruppato per giorno e le date di validita'."""
        map_ids = self._requested_map_ids(request)
        if map_ids is None:
            return Response(
                {
                    "map_id": [
                        f"Valore non valido. Valori ammessi: {', '.join(MAP_DAY_OFFSETS)}."
                    ]
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        queryset = self.filter_queryset(self.get_queryset()).filter(
            map_id__in=map_ids
        )

        operational_date = timezone.localdate()
        grouped = {map_id: [] for map_id in map_ids}
        for item in queryset:
            grouped[item.map_id].append(item)

        context = self.get_serializer_context()
        maps = []
        for map_id in map_ids:
            serializer = self.get_serializer(
                grouped[map_id],
                many=True,
                context=context,
            )
            maps.append(
                {
                    "map_id": map_id,
                    "valid_date": operational_date
                    + timedelta(days=MAP_DAY_OFFSETS[map_id]),
                    self.result_key: serializer.data,
                }
            )

        return Response(
            {
                "operational_date": operational_date,
                "maps": maps,
            },
            status=status.HTTP_200_OK,
        )


class CurrentQpfResView(CurrentStateViewSet):
    serializer_class = CurrentQpfSerializer
    result_key = REDACTED

    def get_queryset(self):
        """Carica le assegnazioni QPF evitando query aggiuntive per zona e livello."""
        return CurQpf.objects.select_related("zone", "qpf_level").order_by(
            "map_id",
            "zone__code",
        )


class CurrentPsResView(CurrentStateViewSet):
    serializer_class = CurrentPsSerializer
    result_key = REDACTED

    def get_queryset(self):
        """Carica le icone PS con zona, fenomeno e livello in un'unica query."""
        return CurPs.objects.select_related(
            "zone",
            "phenomenon_type",
            "ps_level",
        ).order_by("map_id", "zone__code", "icon_slot", "phenomenon_type__code")

    def get_serializer_context(self):
        """Indicizza gli anchor per associare rapidamente coordinate e slot."""
        context = super().get_serializer_context()
        context["anchors"] = {
            (anchor.zone_id, anchor.slot): anchor
            for anchor in ZoneIconAnchor.objects.all()
        }
        return context


class SaveCurrentQpfResView(viewsets.GenericViewSet):
    """Sostituisce lo stato QPF corrente di una singola mappa."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = CurrentQpfWriteSerializer

    def create(self, request, *args, **kwargs):
        """Valida e salva atomicamente tutte le campiture QPF del giorno."""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        map_id = serializer.validated_data["map_id"]
        assignments = serializer.validated_data["zones"]
        updated_by = _database_user(request.user)

        with transaction.atomic():
            existing = {
                item.zone_id: item
                for item in CurQpf.objects.select_for_update().filter(map_id=map_id)
            }
            for assignment in assignments:
                zone = assignment["zone"]
                item = existing.pop(zone.pk, None)
                if item is None:
                    item = CurQpf(map_id=map_id, zone=zone)
                item.qpf_level = assignment["qpf_level"]
                item.custom_description = assignment.get("custom_description", "")
                item.updated_by = updated_by
                item.save()

            deleted_count = len(existing)
            if existing:
                CurQpf.objects.filter(pk__in=[item.pk for item in existing.values()]).delete()

            response_data = _qpf_snapshot(
                request,
                map_id,
                operation="replace",
                deleted_count=deleted_count,
            )
            _notify_after_commit(
                request,
                NotificationType.UPDATE_CURRENT_QPF,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)


class SaveCurrentPsResView(viewsets.GenericViewSet):
    """Sostituisce lo stato delle icone PS correnti di una singola mappa."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = CurrentPsWriteSerializer

    def create(self, request, *args, **kwargs):
        """Valida e salva atomicamente tutte le icone PS del giorno."""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        map_id = serializer.validated_data["map_id"]
        assignments = serializer.validated_data["icons"]
        updated_by = _database_user(request.user)

        with transaction.atomic():
            existing = {}
            duplicate_ids = []
            for item in CurPs.objects.select_for_update().filter(map_id=map_id):
                key = REDACTED
                if key in existing:
                    duplicate_ids.append(item.pk)
                else:
                    existing[key] = item

            if duplicate_ids:
                CurPs.objects.filter(pk__in=duplicate_ids).delete()

            for assignment in assignments:
                zone = assignment["zone"]
                key = REDACTED
                item = existing.pop(key, None)
                if item is None:
                    item = CurPs(map_id=map_id, zone=zone)
                item.phenomenon_type = assignment["phenomenon_type"]
                item.ps_level = assignment["ps_level"]
                item.icon_slot = assignment["icon_slot"]
                item.custom_description = assignment.get("custom_description", "")
                item.updated_by = updated_by
                item.save()

            deleted_count = len(existing) + len(duplicate_ids)
            if existing:
                CurPs.objects.filter(pk__in=[item.pk for item in existing.values()]).delete()

            response_data = _ps_snapshot(
                request,
                map_id,
                operation="replace",
                deleted_count=deleted_count,
            )
            _notify_after_commit(
                request,
                NotificationType.UPDATE_CURRENT_PS,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)


class ClearCurrentStateResView(APIView):
    """Base per la cancellazione atomica dello stato di una singola mappa."""

    permission_classes = [permissions.IsAuthenticated]
    model = None
    snapshot = None
    notification_type = None

    def delete(self, request, map_id):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )

        with transaction.atomic():
            queryset = self.model.objects.select_for_update().filter(map_id=map_id)
            deleted_count = queryset.count()
            queryset.delete()
            response_data = self.snapshot(
                request,
                map_id,
                operation="clear",
                deleted_count=deleted_count,
            )
            _notify_after_commit(
                request,
                self.notification_type,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)


class ClearCurrentQpfResView(ClearCurrentStateResView):
    """Riporta al livello di default tutte le zone VM della mappa richiesta."""

    def delete(self, request, map_id):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )

        default_level = _default_qpf_level()
        updated_by = _database_user(request.user)
        with transaction.atomic():
            existing = {
                item.zone_id: item
                for item in CurQpf.objects.select_for_update().filter(map_id=map_id)
            }
            active_zones = ZoneVigilanzaMeteo.objects.filter(is_active=True)
            for zone in active_zones:
                item = existing.pop(zone.pk, None)
                if item is None:
                    item = CurQpf(map_id=map_id, zone=zone)
                item.qpf_level = default_level
                item.custom_description = ""
                item.updated_by = updated_by
                item.save()

            # Conserva coerenti anche eventuali assegnazioni storiche riferite
            # a zone nel frattempo disattivate.
            for item in existing.values():
                item.qpf_level = default_level
                item.custom_description = ""
                item.updated_by = updated_by
                item.save()

            reset_count = active_zones.count() + len(existing)
            response_data = _qpf_snapshot(
                request,
                map_id,
                operation="reset",
                reset_count=reset_count,
            )
            _notify_after_commit(
                request,
                NotificationType.UPDATE_CURRENT_QPF,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)


class ClearCurrentPsResView(ClearCurrentStateResView):
    """Elimina lo stato di tutte le icone PS della mappa richiesta."""

    model = CurPs
    snapshot = staticmethod(_ps_snapshot)
    notification_type = NotificationType.UPDATE_CURRENT_PS


class CurrentQpfItemResView(APIView):
    """Crea, aggiorna o riporta al default una singola zona VM."""

    permission_classes = [permissions.IsAuthenticated]

    def put(self, request, map_id, zone_id):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        zone = get_object_or_404(
            ZoneVigilanzaMeteo.objects.filter(is_active=True),
            pk=zone_id,
        )
        serializer = CurrentQpfItemWriteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        with transaction.atomic():
            CurQpf.objects.update_or_create(
                map_id=map_id,
                zone=zone,
                defaults={
                    "qpf_level": serializer.validated_data["qpf_level"],
                    "custom_description": serializer.validated_data.get(
                        "custom_description",
                        "",
                    ),
                    "updated_by": _database_user(request.user),
                },
            )
            response_data = _qpf_snapshot(
                request,
                map_id,
                operation="upsert",
            )
            _notify_after_commit(
                request,
                NotificationType.UPDATE_CURRENT_QPF,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)

    def delete(self, request, map_id, zone_id):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        zone = get_object_or_404(
            ZoneVigilanzaMeteo.objects.filter(is_active=True),
            pk=zone_id,
        )
        default_level = _default_qpf_level()
        with transaction.atomic():
            CurQpf.objects.update_or_create(
                map_id=map_id,
                zone=zone,
                defaults={
                    "qpf_level": default_level,
                    "custom_description": "",
                    "updated_by": _database_user(request.user),
                },
            )
            response_data = _qpf_snapshot(
                request,
                map_id,
                operation="reset",
                reset_count=1,
            )
            _notify_after_commit(
                request,
                NotificationType.UPDATE_CURRENT_QPF,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)


class CurrentPsItemResView(APIView):
    """Crea, aggiorna o elimina una singola icona PS."""

    permission_classes = [permissions.IsAuthenticated]

    def put(self, request, map_id, zone_id, icon_slot):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if icon_slot not in range(1, 5):
            return Response(
                {"icon_slot": ["Lo slot deve essere compreso tra 1 e 4."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        zone = get_object_or_404(
            ZoneVigilanzaMeteo.objects.filter(is_active=True),
            pk=zone_id,
        )
        serializer = CurrentPsItemWriteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        with transaction.atomic():
            CurPs.objects.update_or_create(
                map_id=map_id,
                zone=zone,
                icon_slot=icon_slot,
                defaults={
                    "phenomenon_type": serializer.validated_data[
                        "phenomenon_type"
                    ],
                    "ps_level": serializer.validated_data["ps_level"],
                    "custom_description": serializer.validated_data.get(
                        "custom_description",
                        "",
                    ),
                    "updated_by": _database_user(request.user),
                },
            )
            response_data = _ps_snapshot(
                request,
                map_id,
                operation="upsert",
            )
            _notify_after_commit(
                request,
                NotificationType.UPDATE_CURRENT_PS,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)

    def delete(self, request, map_id, zone_id, icon_slot):
        if map_id not in MAP_DAY_OFFSETS:
            return Response(
                {"map_id": ["Valore non valido."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if icon_slot not in range(1, 5):
            return Response(
                {"icon_slot": ["Lo slot deve essere compreso tra 1 e 4."]},
                status=status.HTTP_400_BAD_REQUEST,
            )
        with transaction.atomic():
            deleted_count, _ = CurPs.objects.filter(
                map_id=map_id,
                zone_id=zone_id,
                icon_slot=icon_slot,
            ).delete()
            if not deleted_count:
                return Response(
                    {"detail": "Icona PS non trovata."},
                    status=status.HTTP_404_NOT_FOUND,
                )

            response_data = _ps_snapshot(
                request,
                map_id,
                operation="delete",
                deleted_count=1,
            )
            _notify_after_commit(
                request,
                NotificationType.UPDATE_CURRENT_PS,
                response_data,
            )
        return Response(response_data, status=status.HTTP_200_OK)
