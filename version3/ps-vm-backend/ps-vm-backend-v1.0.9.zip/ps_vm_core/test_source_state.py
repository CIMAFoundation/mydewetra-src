from datetime import timedelta
from io import StringIO

from django.contrib.auth import get_user_model
from django.contrib.gis.geos import GEOSGeometry, Point
from django.core.management import call_command
from django.test import TestCase
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from ps_vm_core.models import (
    CurPs,
    CurQpf,
    ImpulsivePrecipitationType,
    MapId,
    MapOperationalState,
    NonImpulsivePrecipitationType,
    PhenomenonType,
    PsLevel,
    QpfLevel,
    QpfThreshold24h,
    SourcePs,
    SourceQpf,
    SourceQpfAmount,
    ZoneIconAnchor,
    ZoneVigilanzaMeteo,
)


def create_zone(code, *, zone_type="zdv"):
    return ZoneVigilanzaMeteo.objects.create(
        code=code,
        name=f"Zona {code}",
        type=zone_type,
        geometry=GEOSGeometry(
            "MULTIPOLYGON(((0 0, 0 1, 1 1, 1 0, 0 0)))",
            srid=4326,
        ),
    )


class SourceStateApiTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username="source-user")
        self.client.force_authenticate(user=self.user)
        self.zone = create_zone("A1")
        self.sea_zone = create_zone("M1", zone_type="sea")
        self.non_impulsive = NonImpulsivePrecipitationType.objects.get(
            code="scattered"
        )
        self.impulsive = ImpulsivePrecipitationType.objects.get(code="isolated30")
        self.default_non_impulsive = NonImpulsivePrecipitationType.objects.get(
            code="absent"
        )
        self.default_impulsive = ImpulsivePrecipitationType.objects.get(code="absent")
        self.rain = PhenomenonType.objects.get(code="piogge")
        self.rain_level = PsLevel.objects.filter(
            phenomenon_type=self.rain,
            is_active=True,
        ).first()
        self.snow = PhenomenonType.objects.get(code="nevicate")
        self.snow_level = PsLevel.objects.filter(
            phenomenon_type=self.snow,
            is_active=True,
        ).first()

    def test_source_catalogs_expose_seeded_values(self):
        non_impulsive = self.client.get(
            "/api/non_impulsive_precipitation_types/"
        )
        impulsive = self.client.get("/api/impulsive_precipitation_types/")

        self.assertEqual(non_impulsive.status_code, status.HTTP_200_OK)
        self.assertEqual(impulsive.status_code, status.HTTP_200_OK)
        self.assertEqual(
            [item["code"] for item in non_impulsive.data],
            ["isolated", "scattered", "widespread", "absent"],
        )
        self.assertEqual(
            [item["code"] for item in impulsive.data],
            ["absent", "isolated10", "isolated30", "scattered", "widespread"],
        )

    def test_save_source_qpf_replaces_map_and_returns_sorted_amounts(self):
        response = self.client.post(
            "/api/save_source_qpf/",
            {
                "map_id": "d1",
                "zones": [
                    {
                        "zone_id": self.zone.pk,
                        "non_impulsive_type_id": self.non_impulsive.pk,
                        "impulsive_type_id": self.impulsive.pk,
                        "amounts": [
                            {"duration_hours": 12, "min_mm": 10, "max_mm": 30},
                            {"duration_hours": 3, "min_mm": 2, "max_mm": 8},
                        ],
                    }
                ],
            },
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["saved_count"], 1)
        self.assertEqual(
            [item["duration_hours"] for item in response.data["zones"][0]["amounts"]],
            [3, 12],
        )
        saved = SourceQpf.objects.get(map_id="d1", zone=self.zone)
        self.assertEqual(saved.updated_by, self.user)
        self.assertEqual(saved.amounts.count(), 2)

        read_response = self.client.get("/api/source_qpf/?map_id=d1")
        self.assertEqual(read_response.status_code, status.HTTP_200_OK)
        self.assertEqual(read_response.data["maps"][0]["valid_date"], timezone.localdate() + timedelta(days=1))
        self.assertEqual(len(read_response.data["maps"][0]["zones"]), 1)

    def test_source_qpf_rejects_invalid_amounts_and_non_zdv_zone(self):
        base = {
            "map_id": "d0",
            "zones": [
                {
                    "zone_id": self.zone.pk,
                    "non_impulsive_type_id": self.non_impulsive.pk,
                    "impulsive_type_id": self.impulsive.pk,
                    "amounts": [
                        {"duration_hours": 6, "min_mm": 20, "max_mm": 10}
                    ],
                }
            ],
        }
        invalid_range = self.client.post("/api/save_source_qpf/", base, format="json")
        base["zones"][0]["zone_id"] = self.sea_zone.pk
        base["zones"][0]["amounts"] = [
            {"duration_hours": 6, "min_mm": 10, "max_mm": 20}
        ]
        invalid_zone = self.client.post("/api/save_source_qpf/", base, format="json")

        self.assertEqual(invalid_range.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(invalid_zone.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(SourceQpf.objects.exists())

    def test_source_qpf_rejects_duplicate_duration(self):
        response = self.client.post(
            "/api/save_source_qpf/",
            {
                "map_id": "d0",
                "zones": [
                    {
                        "zone_id": self.zone.pk,
                        "non_impulsive_type_id": self.non_impulsive.pk,
                        "impulsive_type_id": self.impulsive.pk,
                        "amounts": [
                            {"duration_hours": 3, "min_mm": 1, "max_mm": 2},
                            {"duration_hours": 3, "min_mm": 2, "max_mm": 3},
                        ],
                    }
                ],
            },
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(SourceQpf.objects.exists())

    def test_save_source_ps_accepts_rain_and_rejects_other_phenomena(self):
        ZoneIconAnchor.objects.create(
            zone=self.zone,
            slot=1,
            label="Slot 1",
            point=Point(9.0, 44.0, srid=4326),
        )
        valid = self.client.post(
            "/api/save_source_ps/",
            {
                "map_id": "d0",
                "icons": [
                    {
                        "zone_id": self.zone.pk,
                        "phenomenon_type_id": self.rain.pk,
                        "ps_level_id": self.rain_level.pk,
                        "icon_slot": 1,
                        "custom_description": "Pioggia prevista",
                    }
                ],
            },
            format="json",
        )
        invalid = self.client.post(
            "/api/save_source_ps/",
            {
                "map_id": "d1",
                "icons": [
                    {
                        "zone_id": self.zone.pk,
                        "phenomenon_type_id": self.snow.pk,
                        "ps_level_id": self.snow_level.pk,
                        "icon_slot": 1,
                    }
                ],
            },
            format="json",
        )

        self.assertEqual(valid.status_code, status.HTTP_200_OK)
        self.assertEqual(valid.data["icons"][0]["anchor"]["slot"], 1)
        self.assertEqual(invalid.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(SourcePs.objects.filter(map_id="d1").exists())

    def test_source_qpf_item_put_delete_and_bulk_reset(self):
        put_response = self.client.put(
            f"/api/source_qpf/d0/{self.zone.pk}/",
            {
                "non_impulsive_type_id": self.non_impulsive.pk,
                "impulsive_type_id": self.impulsive.pk,
                "amounts": [{"duration_hours": 24, "min_mm": 0, "max_mm": 5}],
            },
            format="json",
        )
        delete_response = self.client.delete(
            f"/api/source_qpf/d0/{self.zone.pk}/"
        )
        second_delete_response = self.client.delete(
            f"/api/source_qpf/d0/{self.zone.pk}/"
        )
        second_put_response = self.client.put(
            f"/api/source_qpf/d0/{self.zone.pk}/",
            {
                "non_impulsive_type_id": self.non_impulsive.pk,
                "impulsive_type_id": self.impulsive.pk,
                "amounts": [
                    {"duration_hours": 24, "min_mm": 0, "max_mm": 5}
                ],
            },
            format="json",
        )
        reset_response = self.client.delete("/api/source_qpf/d0/")

        self.assertEqual(put_response.status_code, status.HTTP_200_OK)
        self.assertEqual(delete_response.status_code, status.HTTP_200_OK)
        self.assertEqual(delete_response.data["operation"], "reset")
        self.assertEqual(delete_response.data["reset_count"], 1)
        self.assertEqual(second_delete_response.status_code, status.HTTP_200_OK)
        self.assertEqual(second_put_response.status_code, status.HTTP_200_OK)
        self.assertEqual(reset_response.status_code, status.HTTP_200_OK)
        self.assertEqual(reset_response.data["operation"], "reset")
        self.assertEqual(reset_response.data["deleted_count"], 0)
        self.assertEqual(reset_response.data["reset_count"], 1)
        saved = SourceQpf.objects.get(map_id="d0", zone=self.zone)
        self.assertEqual(saved.non_impulsive_type, self.default_non_impulsive)
        self.assertEqual(saved.impulsive_type, self.default_impulsive)
        self.assertEqual(
            list(
                saved.amounts.values_list(
                    "duration_hours",
                    "min_mm",
                    "max_mm",
                )
            ),
            [(3, 0, 0), (6, 0, 0), (12, 0, 0), (18, 0, 0), (24, 0, 0)],
        )

    def test_source_qpf_item_delete_creates_missing_default_assignment(self):
        response = self.client.delete(
            f"/api/source_qpf/d1/{self.zone.pk}/"
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["operation"], "reset")
        self.assertEqual(response.data["reset_count"], 1)
        assignment = SourceQpf.objects.get(map_id="d1", zone=self.zone)
        self.assertEqual(assignment.non_impulsive_type, self.default_non_impulsive)
        self.assertEqual(assignment.impulsive_type, self.default_impulsive)

    def test_source_qpf_bulk_reset_creates_all_active_zdv_zones_only(self):
        other_zone = create_zone("A2")

        first_response = self.client.delete("/api/source_qpf/d2/")
        second_response = self.client.delete("/api/source_qpf/d2/")

        self.assertEqual(first_response.status_code, status.HTTP_200_OK)
        self.assertEqual(first_response.data["operation"], "reset")
        self.assertEqual(first_response.data["reset_count"], 2)
        self.assertEqual(second_response.status_code, status.HTTP_200_OK)
        self.assertEqual(second_response.data["reset_count"], 2)
        self.assertEqual(
            set(
                SourceQpf.objects.filter(map_id="d2").values_list(
                    "zone_id", flat=True
                )
            ),
            {self.zone.pk, other_zone.pk},
        )
        self.assertFalse(SourceQpf.objects.filter(zone=self.sea_zone).exists())

    def test_source_ps_read_item_put_delete_and_bulk_clear(self):
        ZoneIconAnchor.objects.create(
            zone=self.zone,
            slot=2,
            label="Slot 2",
            point=Point(9.0, 44.0, srid=4326),
        )
        path = f"/api/source_ps/d0/{self.zone.pk}/2/"
        payload = {
            "phenomenon_type_id": self.rain.pk,
            "ps_level_id": self.rain_level.pk,
            "custom_description": "Temporali previsti",
        }

        put_response = self.client.put(path, payload, format="json")
        read_response = self.client.get("/api/source_ps/?map_id=d0")
        delete_response = self.client.delete(path)
        second_put_response = self.client.put(path, payload, format="json")
        clear_response = self.client.delete("/api/source_ps/d0/")

        self.assertEqual(put_response.status_code, status.HTTP_200_OK)
        self.assertEqual(read_response.status_code, status.HTTP_200_OK)
        self.assertEqual(read_response.data["maps"][0]["icons"][0]["icon_slot"], 2)
        self.assertEqual(delete_response.status_code, status.HTTP_200_OK)
        self.assertEqual(delete_response.data["operation"], "delete")
        self.assertEqual(second_put_response.status_code, status.HTTP_200_OK)
        self.assertEqual(clear_response.status_code, status.HTTP_200_OK)
        self.assertEqual(clear_response.data["deleted_count"], 1)
        self.assertFalse(SourcePs.objects.exists())

    def test_source_endpoints_require_authentication(self):
        self.client.force_authenticate(user=None)
        self.assertEqual(
            self.client.get("/api/source_qpf/").status_code,
            status.HTTP_401_UNAUTHORIZED,
        )
        self.assertEqual(
            self.client.post(
                "/api/save_source_ps/", {"map_id": "d0", "icons": []}, format="json"
            ).status_code,
            status.HTTP_401_UNAUTHORIZED,
        )


class PromoteSourceMapsApiTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username="promoter")
        self.client.force_authenticate(user=self.user)
        self.zone = create_zone("P1")
        self.other_zone = create_zone("P2")
        self.non_impulsive = NonImpulsivePrecipitationType.objects.get(
            code="scattered"
        )
        self.impulsive = ImpulsivePrecipitationType.objects.get(code="isolated30")
        self.rain = PhenomenonType.objects.get(code="piogge")
        self.rain_level = PsLevel.objects.filter(
            phenomenon_type=self.rain,
            is_active=True,
        ).first()
        self.snow = PhenomenonType.objects.get(code="nevicate")
        self.snow_level = PsLevel.objects.filter(
            phenomenon_type=self.snow,
            is_active=True,
        ).first()
        self.manual_qpf = QpfLevel.objects.get(code="molto_elevate")

    def _source_qpf(self, map_id, zone, amounts):
        item = SourceQpf.objects.create(
            map_id=map_id,
            zone=zone,
            non_impulsive_type=self.non_impulsive,
            impulsive_type=self.impulsive,
        )
        SourceQpfAmount.objects.bulk_create(
            [SourceQpfAmount(source_qpf=item, **amount) for amount in amounts]
        )
        return item

    def test_promote_replaces_all_maps_and_scales_qpf_amounts_to_24_hours(self):
        QpfThreshold24h.objects.create(
            zone=self.zone,
            weak_mm=100,
            moderate_mm=150,
            elevated_mm=200,
        )
        QpfThreshold24h.objects.create(
            zone=self.other_zone,
            weak_mm=80,
            moderate_mm=160,
            elevated_mm=240,
        )
        self._source_qpf(
            MapId.TODAY,
            self.zone,
            [
                {"duration_hours": 3, "min_mm": 10, "max_mm": 20},
                {"duration_hours": 24, "min_mm": 40, "max_mm": 90},
            ],
        )
        self._source_qpf(
            MapId.TOMORROW,
            self.other_zone,
            [{"duration_hours": 3, "min_mm": 1, "max_mm": 10}],
        )
        SourcePs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            phenomenon_type=self.rain,
            ps_level=self.rain_level,
            icon_slot=1,
            custom_description="Piogge promosse",
        )
        CurQpf.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            qpf_level=self.manual_qpf,
        )
        CurQpf.objects.create(
            map_id=MapId.DAY_AFTER_TOMORROW,
            zone=self.other_zone,
            qpf_level=self.manual_qpf,
        )
        CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            phenomenon_type=self.snow,
            ps_level=self.snow_level,
            icon_slot=2,
        )
        CurPs.objects.create(
            map_id=MapId.DAY_AFTER_TOMORROW,
            zone=self.other_zone,
            phenomenon_type=self.snow,
            ps_level=self.snow_level,
            icon_slot=1,
        )

        response = self.client.post("/api/promote_source_maps/", {}, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["operation"], "promote")
        self.assertEqual(
            [item["map_id"] for item in response.data["maps"]],
            [MapId.TODAY, MapId.TOMORROW, MapId.DAY_AFTER_TOMORROW],
        )
        # 20 mm / 3h equivalgono a 160 mm / 24h: livello moderato.
        self.assertEqual(
            CurQpf.objects.get(map_id=MapId.TODAY, zone=self.zone).qpf_level.code,
            "moderate",
        )
        # Il confronto e' inclusivo: 10 mm / 3h equivalgono alla soglia 80 mm / 24h.
        self.assertEqual(
            CurQpf.objects.get(
                map_id=MapId.TOMORROW,
                zone=self.other_zone,
            ).qpf_level.code,
            "deboli",
        )
        self.assertFalse(
            CurQpf.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists()
        )
        promoted_icon = CurPs.objects.get(map_id=MapId.TODAY)
        self.assertEqual(promoted_icon.phenomenon_type, self.rain)
        self.assertEqual(promoted_icon.icon_slot, 1)
        self.assertEqual(promoted_icon.custom_description, "Piogge promosse")
        self.assertEqual(promoted_icon.updated_by, self.user)
        self.assertFalse(
            CurPs.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists()
        )

    def test_promote_without_zone_thresholds_is_atomic(self):
        self._source_qpf(
            MapId.TODAY,
            self.zone,
            [{"duration_hours": 24, "min_mm": 10, "max_mm": 20}],
        )
        previous_qpf = CurQpf.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            qpf_level=self.manual_qpf,
        )
        previous_ps = CurPs.objects.create(
            map_id=MapId.TODAY,
            zone=self.zone,
            phenomenon_type=self.snow,
            ps_level=self.snow_level,
            icon_slot=1,
        )

        response = self.client.post("/api/promote_source_maps/", {}, format="json")

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("P1", response.data["thresholds"][0])
        self.assertTrue(CurQpf.objects.filter(pk=previous_qpf.pk).exists())
        self.assertTrue(CurPs.objects.filter(pk=previous_ps.pk).exists())

    def test_qpf_threshold_catalog_and_promotion_require_authentication(self):
        QpfThreshold24h.objects.create(
            zone=self.zone,
            weak_mm=100,
            moderate_mm=150,
            elevated_mm=200,
        )
        catalog = self.client.get("/api/qpf_thresholds/")
        self.assertEqual(catalog.status_code, status.HTTP_200_OK)
        self.assertEqual(catalog.data[0]["zone_code"], "P1")

        self.client.force_authenticate(user=None)
        self.assertEqual(
            self.client.post("/api/promote_source_maps/", {}, format="json").status_code,
            status.HTTP_401_UNAUTHORIZED,
        )
        self.assertEqual(
            self.client.get("/api/qpf_thresholds/").status_code,
            status.HTTP_401_UNAUTHORIZED,
        )


class CurrentMapsRolloverTests(TestCase):
    def setUp(self):
        self.zone = create_zone("R1")
        self.non_impulsive = NonImpulsivePrecipitationType.objects.get(code="isolated")
        self.impulsive = ImpulsivePrecipitationType.objects.get(code="absent")
        self.default_qpf = QpfLevel.objects.get(
            code="assenti_o_deboli_non_rilevanti"
        )
        self.other_qpf = QpfLevel.objects.get(code="moderate")
        self.rain = PhenomenonType.objects.get(code="piogge")
        self.rain_level = PsLevel.objects.filter(phenomenon_type=self.rain).first()
        self.state = MapOperationalState.objects.get(key="current_maps")
        self.target_date = timezone.localdate()
        self.state.last_rollover_date = self.target_date - timedelta(days=1)
        self.state.save(update_fields=["last_rollover_date"])

    def _source_qpf(self, map_id, min_mm):
        item = SourceQpf.objects.create(
            map_id=map_id,
            zone=self.zone,
            non_impulsive_type=self.non_impulsive,
            impulsive_type=self.impulsive,
        )
        SourceQpfAmount.objects.create(
            source_qpf=item,
            duration_hours=3,
            min_mm=min_mm,
            max_mm=min_mm + 1,
        )

    def test_rollover_shifts_all_maps_initializes_d2_and_is_idempotent(self):
        self._source_qpf(MapId.TODAY, 1)
        self._source_qpf(MapId.TOMORROW, 10)
        self._source_qpf(MapId.DAY_AFTER_TOMORROW, 20)
        for map_id, slot in ((MapId.TOMORROW, 1), (MapId.DAY_AFTER_TOMORROW, 2)):
            SourcePs.objects.create(
                map_id=map_id,
                zone=self.zone,
                phenomenon_type=self.rain,
                ps_level=self.rain_level,
                icon_slot=slot,
            )
            CurPs.objects.create(
                map_id=map_id,
                zone=self.zone,
                phenomenon_type=self.rain,
                ps_level=self.rain_level,
                icon_slot=slot,
            )
            CurQpf.objects.create(
                map_id=map_id,
                zone=self.zone,
                qpf_level=self.other_qpf,
            )

        call_command(
            "rollover_current_maps",
            target_date=self.target_date.isoformat(),
            stdout=StringIO(),
        )

        self.assertEqual(
            SourceQpf.objects.get(map_id=MapId.TODAY).amounts.get().min_mm,
            10,
        )
        self.assertEqual(
            SourceQpf.objects.get(map_id=MapId.TOMORROW).amounts.get().min_mm,
            20,
        )
        self.assertFalse(SourceQpf.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists())
        self.assertEqual(SourcePs.objects.get(map_id=MapId.TODAY).icon_slot, 1)
        self.assertEqual(SourcePs.objects.get(map_id=MapId.TOMORROW).icon_slot, 2)
        self.assertFalse(SourcePs.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists())
        self.assertEqual(CurPs.objects.get(map_id=MapId.TODAY).icon_slot, 1)
        self.assertEqual(CurPs.objects.get(map_id=MapId.TOMORROW).icon_slot, 2)
        self.assertFalse(CurPs.objects.filter(map_id=MapId.DAY_AFTER_TOMORROW).exists())
        self.assertEqual(
            CurQpf.objects.get(map_id=MapId.DAY_AFTER_TOMORROW, zone=self.zone).qpf_level,
            self.default_qpf,
        )

        before = list(SourceQpf.objects.values_list("map_id", "id"))
        output = StringIO()
        call_command(
            "rollover_current_maps",
            target_date=self.target_date.isoformat(),
            stdout=output,
        )
        self.assertEqual(before, list(SourceQpf.objects.values_list("map_id", "id")))
        self.assertIn("gia' eseguito", output.getvalue())

    def test_rollover_after_three_days_discards_expired_maps(self):
        self.state.last_rollover_date = self.target_date - timedelta(days=3)
        self.state.save(update_fields=["last_rollover_date"])
        self._source_qpf(MapId.DAY_AFTER_TOMORROW, 20)
        CurPs.objects.create(
            map_id=MapId.DAY_AFTER_TOMORROW,
            zone=self.zone,
            phenomenon_type=self.rain,
            ps_level=self.rain_level,
            icon_slot=1,
        )

        call_command(
            "rollover_current_maps",
            target_date=self.target_date.isoformat(),
            stdout=StringIO(),
        )

        self.assertFalse(SourceQpf.objects.exists())
        self.assertFalse(CurPs.objects.exists())
        self.assertTrue(
            CurQpf.objects.filter(
                map_id=MapId.DAY_AFTER_TOMORROW,
                zone=self.zone,
                qpf_level=self.default_qpf,
            ).exists()
        )
