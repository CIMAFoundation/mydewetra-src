from django.core.exceptions import ImproperlyConfigured
from django.db import transaction
from django.utils import timezone
from rest_framework import permissions, serializers, status
from rest_framework.response import Response
from rest_framework.views import APIView

from ps_vm_core.models import (
    CurPs,
    CurQpf,
    MapId,
    QpfLevel,
    QpfThreshold24h,
    SourcePs,
    SourceQpf,
)
from ps_vm_core.notify import NotificationType
from ps_vm_core.operational import lock_map_operational_state
from ps_vm_core.views.current_state import (
    MAP_DAY_OFFSETS,
    _database_user,
    _notify_after_commit,
    _ps_snapshot,
    _qpf_snapshot,
)


PROMOTED_QPF_LEVEL_CODES = {
    0: "assenti_o_deboli_non_rilevanti",
    1: "deboli",
    2: "moderate",
    3: "elevate",
}


def _promotion_qpf_levels():
    levels = {
        item.level: item
        for item in QpfLevel.objects.filter(
            code__in=PROMOTED_QPF_LEVEL_CODES.values(),
            is_active=True,
        )
    }
    missing = [
        code
        for level, code in PROMOTED_QPF_LEVEL_CODES.items()
        if level not in levels or levels[level].code != code
    ]
    if missing:
        raise ImproperlyConfigured(
            "Livelli QPF attivi richiesti dalla promozione non configurati: "
            + ", ".join(missing)
            + "."
        )
    return levels


def _amount_severity_24h(amount, thresholds):
    """Classifica max_mm dopo il ragguaglio lineare alla durata di 24 ore."""
    normalized_max = amount.max_mm * 24
    duration = amount.duration_hours
    if normalized_max >= thresholds.elevated_mm * duration:
        return 3
    if normalized_max >= thresholds.moderate_mm * duration:
        return 2
    if normalized_max >= thresholds.weak_mm * duration:
        return 1
    return 0


def _source_qpf_severity(source_qpf, thresholds):
    return max(
        (
            _amount_severity_24h(amount, thresholds)
            for amount in source_qpf.amounts.all()
        ),
        default=0,
    )


class PromoteSourceMapsResView(APIView):
    """Ricostruisce integralmente le mappe intermedie dalle mappe sorgente."""

    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        map_ids = list(MAP_DAY_OFFSETS)
        updated_by = _database_user(request.user)

        with transaction.atomic():
            lock_map_operational_state()
            levels = _promotion_qpf_levels()
            thresholds_by_zone = {
                item.zone_id: item
                for item in QpfThreshold24h.objects.select_related("zone")
            }
            source_qpf = list(
                SourceQpf.objects.select_related("zone")
                .prefetch_related("amounts")
                .filter(map_id__in=map_ids)
                .order_by("map_id", "zone__code")
            )
            missing_thresholds = sorted(
                {
                    item.zone.code
                    for item in source_qpf
                    if item.zone_id not in thresholds_by_zone
                }
            )
            if missing_thresholds:
                raise serializers.ValidationError(
                    {
                        "thresholds": [
                            "Soglie QPF 24h non configurate per le ZVM: "
                            + ", ".join(missing_thresholds)
                            + "."
                        ]
                    }
                )

            source_ps = list(
                SourcePs.objects.select_related(
                    "zone",
                    "phenomenon_type",
                    "ps_level",
                )
                .filter(map_id__in=map_ids)
                .order_by("map_id", "zone__code", "icon_slot")
            )
            deleted_qpf = {
                map_id: CurQpf.objects.filter(map_id=map_id).count()
                for map_id in map_ids
            }
            deleted_ps = {
                map_id: CurPs.objects.filter(map_id=map_id).count()
                for map_id in map_ids
            }

            CurQpf.objects.filter(map_id__in=map_ids).delete()
            CurPs.objects.filter(map_id__in=map_ids).delete()
            CurQpf.objects.bulk_create(
                [
                    CurQpf(
                        map_id=item.map_id,
                        zone=item.zone,
                        qpf_level=levels[
                            _source_qpf_severity(
                                item,
                                thresholds_by_zone[item.zone_id],
                            )
                        ],
                        custom_description="",
                        updated_by=updated_by,
                    )
                    for item in source_qpf
                ]
            )
            CurPs.objects.bulk_create(
                [
                    CurPs(
                        map_id=item.map_id,
                        zone=item.zone,
                        phenomenon_type=item.phenomenon_type,
                        ps_level=item.ps_level,
                        icon_slot=item.icon_slot,
                        custom_description=item.custom_description,
                        updated_by=updated_by,
                    )
                    for item in source_ps
                ]
            )

            maps = []
            for map_id in map_ids:
                qpf_data = _qpf_snapshot(
                    request,
                    map_id,
                    operation="promote",
                    deleted_count=deleted_qpf[map_id],
                )
                ps_data = _ps_snapshot(
                    request,
                    map_id,
                    operation="promote",
                    deleted_count=deleted_ps[map_id],
                )
                maps.append(
                    {
                        "map_id": map_id,
                        "qpf": qpf_data,
                        "ps": ps_data,
                    }
                )
                _notify_after_commit(
                    request,
                    NotificationType.UPDATE_CURRENT_QPF,
                    qpf_data,
                )
                _notify_after_commit(
                    request,
                    NotificationType.UPDATE_CURRENT_PS,
                    ps_data,
                )

        return Response(
            {
                "operation": "promote",
                "operational_date": timezone.localdate(),
                "maps": maps,
            },
            status=status.HTTP_200_OK,
        )
