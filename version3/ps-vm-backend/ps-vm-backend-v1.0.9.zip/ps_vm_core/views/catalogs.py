from django.db.models import Prefetch
from rest_framework import permissions, viewsets

from ps_vm_core.models import (
    ImpulsivePrecipitationType,
    NonImpulsivePrecipitationType,
    PhenomenonType,
    PsLevel,
    QpfLevel,
    QpfThreshold24h,
    ZoneIconAnchor,
    ZoneVigilanzaMeteo,
)
from ps_vm_core.serializers import (
    ImpulsivePrecipitationTypeSerializer,
    NonImpulsivePrecipitationTypeSerializer,
    PsPhenomenonCatalogSerializer,
    QpfLevelCatalogSerializer,
    QpfThreshold24hSerializer,
    ZoneIconAnchorCatalogSerializer,
    WeatherVigilanceZoneSerializer,
)


class NonImpulsivePrecipitationTypeResView(viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = NonImpulsivePrecipitationTypeSerializer

    def get_queryset(self):
        return NonImpulsivePrecipitationType.objects.filter(is_active=True).order_by(
            "sort_order", "severity", "code"
        )


class ImpulsivePrecipitationTypeResView(viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = ImpulsivePrecipitationTypeSerializer

    def get_queryset(self):
        return ImpulsivePrecipitationType.objects.filter(is_active=True).order_by(
            "sort_order", "severity", "code"
        )


class QpfLevelResView(viewsets.ReadOnlyModelViewSet):
    """Espone i livelli di severita' QPF attivi per le tendine client."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = QpfLevelCatalogSerializer

    def get_queryset(self):
        """Restituisce solo i livelli attivi nell'ordine usato dai controlli client."""
        return QpfLevel.objects.filter(is_active=True).order_by(
            "sort_order",
            "level",
            "code",
        )


class QpfThreshold24hResView(viewsets.ReadOnlyModelViewSet):
    """Espone le soglie QPF sulle 24 ore configurate per le ZVM attive."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = QpfThreshold24hSerializer

    def get_queryset(self):
        return QpfThreshold24h.objects.select_related("zone").filter(
            zone__is_active=True,
            zone__type="zdv",
        ).order_by("zone__code")


class WeatherVigilanceZoneResView(viewsets.ReadOnlyModelViewSet):
    """Espone geometrie e anagrafica delle zone di vigilanza meteo attive."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = WeatherVigilanceZoneSerializer

    def get_queryset(self):
        """Restituisce le zone attive in ordine stabile per il client."""
        return ZoneVigilanzaMeteo.objects.filter(is_active=True).order_by("code")


class ZoneIconAnchorResView(viewsets.ReadOnlyModelViewSet):
    """Espone gli slot icona raggruppati per zona di vigilanza attiva."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = ZoneIconAnchorCatalogSerializer

    def get_queryset(self):
        """Carica zone e anchor ordinati senza eseguire query per ogni zona."""
        anchors = ZoneIconAnchor.objects.order_by("slot")
        return (
            ZoneVigilanzaMeteo.objects.filter(is_active=True)
            .prefetch_related(Prefetch("icon_anchors", queryset=anchors))
            .order_by("code")
        )


class PsIconResView(viewsets.ReadOnlyModelViewSet):
    """Espone i fenomeni sinottici attivi con le rispettive icone attive."""

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = PsPhenomenonCatalogSerializer

    def get_queryset(self):
        """Restituisce fenomeni e icone attivi gia' ordinati per il client."""
        active_icons = PsLevel.objects.filter(is_active=True).order_by(
            "sort_order",
            "level",
            "code",
        )
        return (
            PhenomenonType.objects.filter(
                is_active=True,
                levels__is_active=True,
            )
            .prefetch_related(Prefetch("levels", queryset=active_icons))
            .order_by("sort_order", "name", "code")
            .distinct()
        )
