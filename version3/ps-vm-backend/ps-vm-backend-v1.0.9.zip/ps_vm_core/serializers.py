from rest_framework_gis.serializers import GeoFeatureModelSerializer
from rest_framework import serializers

from ps_vm_core.models import (
    CurPs,
    CurQpf,
    ImpulsivePrecipitationType,
    MapId,
    MapLayer,
    MapLayerFeature,
    NonImpulsivePrecipitationType,
    PhenomenonType,
    PsLevel,
    QpfDuration,
    QpfLevel,
    QpfThreshold24h,
    SourcePs,
    SourceQpf,
    SourceQpfAmount,
    ZoneIconAnchor,
    ZoneVigilanzaMeteo,
)


SOURCE_PHENOMENON_CODES = ("piogge", "temporali")


class MapLayerSerializer(serializers.ModelSerializer):
    class Meta:
        model = MapLayer
        fields = (
            "id",
            "code",
            "name",
            "description",
            "layer_type",
            "style",
            "sort_order",
            "is_active",
            "created_at",
            "updated_at",
        )


class MapLayerFeatureSerializer(GeoFeatureModelSerializer):
    class Meta:
        model = MapLayerFeature
        geo_field = "geometry"
        fields = (
            "id",
            "layer",
            "code",
            "name",
            "description",
            "properties",
            "sort_order",
            "is_active",
            "created_at",
            "updated_at",
        )


class WeatherVigilanceZoneSerializer(GeoFeatureModelSerializer):
    """Zona di vigilanza meteo esposta come feature GeoJSON."""

    class Meta:
        model = ZoneVigilanzaMeteo
        geo_field = "geometry"
        fields = (
            "id",
            "code",
            "name",
            "type",
            "description",
            "keywords",
            "is_active",
            "created_at",
            "updated_at",
        )


class ZoneIconAnchorSerializer(serializers.ModelSerializer):
    """Coordinate di uno slot icona configurato per una zona."""

    longitude = serializers.FloatField(source="point.x", read_only=True)
    latitude = serializers.FloatField(source="point.y", read_only=True)

    class Meta:
        model = ZoneIconAnchor
        fields = (
            "id",
            "slot",
            "label",
            "longitude",
            "latitude",
        )


class ZoneIconAnchorCatalogSerializer(serializers.ModelSerializer):
    """Raggruppa gli anchor disponibili sotto la relativa zona."""

    zone_id = serializers.IntegerField(source="id", read_only=True)
    zone_code = serializers.CharField(source="code", read_only=True)
    zone_name = serializers.CharField(source="name", read_only=True)
    zone_type = serializers.CharField(source="type", read_only=True)
    anchors = ZoneIconAnchorSerializer(
        source="icon_anchors",
        many=True,
        read_only=True,
    )

    class Meta:
        model = ZoneVigilanzaMeteo
        fields = (
            "zone_id",
            "zone_code",
            "zone_name",
            "zone_type",
            "anchors",
        )


class QpfLevelCatalogSerializer(serializers.ModelSerializer):
    """Livello di severita' selezionabile per una zona di vigilanza."""

    class Meta:
        model = QpfLevel
        fields = (
            "id",
            "code",
            "description",
            "level",
            "text",
            "sort_order",
            "image",
            "color",
            "svg",
            "is_active",
            "created_at",
            "updated_at",
        )


class QpfThreshold24hSerializer(serializers.ModelSerializer):
    """Soglie di ingresso dei livelli QPF automatici, ragguagliate a 24h."""

    zone_code = serializers.CharField(source="zone.code", read_only=True)
    zone_name = serializers.CharField(source="zone.name", read_only=True)

    class Meta:
        model = QpfThreshold24h
        fields = (
            "id",
            "zone_id",
            "zone_code",
            "zone_name",
            "weak_mm",
            "moderate_mm",
            "elevated_mm",
            "created_at",
            "updated_at",
        )


class PsIconCatalogSerializer(serializers.ModelSerializer):
    """Icona/livello selezionabile per un fenomeno sinottico."""

    phenomenon_type_id = serializers.IntegerField(read_only=True)

    class Meta:
        model = PsLevel
        fields = (
            "id",
            "phenomenon_type_id",
            "code",
            "description",
            "level",
            "text",
            "sort_order",
            "icon",
            "color",
            "svg",
            "is_active",
            "created_at",
            "updated_at",
        )


class PsPhenomenonCatalogSerializer(serializers.ModelSerializer):
    """Fenomeno sinottico con la relativa anagrafica di icone attive."""

    icons = PsIconCatalogSerializer(source="levels", many=True, read_only=True)

    class Meta:
        model = PhenomenonType
        fields = (
            "id",
            "code",
            "name",
            "type",
            "description",
            "sort_order",
            "is_active",
            "icons",
        )


class NonImpulsivePrecipitationTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = NonImpulsivePrecipitationType
        fields = (
            "id",
            "code",
            "name",
            "severity",
            "sort_order",
            "is_active",
            "created_at",
            "updated_at",
        )


class ImpulsivePrecipitationTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ImpulsivePrecipitationType
        fields = (
            "id",
            "code",
            "name",
            "severity",
            "sort_order",
            "is_active",
            "created_at",
            "updated_at",
        )


class QpfLevelStateSerializer(serializers.ModelSerializer):
    class Meta:
        model = QpfLevel
        fields = (
            "id",
            "code",
            "description",
            "level",
            "text",
            "image",
            "color",
            "svg",
        )


class CurrentQpfSerializer(serializers.ModelSerializer):
    zone_code = serializers.CharField(source="zone.code", read_only=True)
    zone_name = serializers.CharField(source="zone.name", read_only=True)
    zone_type = serializers.CharField(source="zone.type", read_only=True)
    qpf = QpfLevelStateSerializer(source="qpf_level", read_only=True)

    class Meta:
        model = CurQpf
        fields = (
            "id",
            "zone_id",
            "zone_code",
            "zone_name",
            "zone_type",
            "qpf",
            "custom_description",
            "updated_by_id",
            "created_at",
            "updated_at",
        )


class PhenomenonTypeStateSerializer(serializers.ModelSerializer):
    class Meta:
        model = PhenomenonType
        fields = ("id", "code", "name", "description")


class PsLevelStateSerializer(serializers.ModelSerializer):
    class Meta:
        model = PsLevel
        fields = (
            "id",
            "code",
            "description",
            "level",
            "text",
            "icon",
            "color",
            "svg",
        )


class CurrentPsSerializer(serializers.ModelSerializer):
    zone_code = serializers.CharField(source="zone.code", read_only=True)
    zone_name = serializers.CharField(source="zone.name", read_only=True)
    zone_type = serializers.CharField(source="zone.type", read_only=True)
    phenomenon = PhenomenonTypeStateSerializer(
        source="phenomenon_type",
        read_only=True,
    )
    ps_level = PsLevelStateSerializer(read_only=True)
    anchor = serializers.SerializerMethodField()

    class Meta:
        model = CurPs
        fields = (
            "id",
            "zone_id",
            "zone_code",
            "zone_name",
            "zone_type",
            "phenomenon",
            "ps_level",
            "icon_slot",
            "anchor",
            "custom_description",
            "updated_by_id",
            "created_at",
            "updated_at",
        )

    def get_anchor(self, obj):
        """Restituisce le coordinate dell'anchor previsto per zona e slot."""
        anchor = self.context.get("anchors", {}).get((obj.zone_id, obj.icon_slot))
        if anchor is None:
            return None
        return {
            "id": anchor.id,
            "slot": anchor.slot,
            "label": anchor.label,
            "longitude": anchor.point.x,
            "latitude": anchor.point.y,
        }


class SourceQpfAmountSerializer(serializers.ModelSerializer):
    class Meta:
        model = SourceQpfAmount
        fields = (
            "id",
            "duration_hours",
            "min_mm",
            "max_mm",
            "created_at",
            "updated_at",
        )


class SourceQpfSerializer(serializers.ModelSerializer):
    zone_code = serializers.CharField(source="zone.code", read_only=True)
    zone_name = serializers.CharField(source="zone.name", read_only=True)
    zone_type = serializers.CharField(source="zone.type", read_only=True)
    non_impulsive_type = NonImpulsivePrecipitationTypeSerializer(read_only=True)
    impulsive_type = ImpulsivePrecipitationTypeSerializer(read_only=True)
    amounts = SourceQpfAmountSerializer(many=True, read_only=True)

    class Meta:
        model = SourceQpf
        fields = (
            "id",
            "zone_id",
            "zone_code",
            "zone_name",
            "zone_type",
            "non_impulsive_type",
            "impulsive_type",
            "amounts",
            "updated_by_id",
            "created_at",
            "updated_at",
        )


class SourcePsSerializer(CurrentPsSerializer):
    class Meta(CurrentPsSerializer.Meta):
        model = SourcePs


class SourceQpfAmountWriteSerializer(serializers.Serializer):
    duration_hours = serializers.ChoiceField(choices=QpfDuration.choices)
    min_mm = serializers.IntegerField(min_value=0)
    max_mm = serializers.IntegerField(min_value=0)

    def validate(self, attrs):
        if attrs["min_mm"] > attrs["max_mm"]:
            raise serializers.ValidationError(
                {"max_mm": "Il valore massimo deve essere maggiore o uguale al minimo."}
            )
        return attrs


class SourceQpfWriteItemSerializer(serializers.Serializer):
    zone_id = serializers.PrimaryKeyRelatedField(
        source="zone",
        queryset=ZoneVigilanzaMeteo.objects.filter(is_active=True, type="zdv"),
    )
    non_impulsive_type_id = serializers.PrimaryKeyRelatedField(
        source="non_impulsive_type",
        queryset=NonImpulsivePrecipitationType.objects.filter(is_active=True),
    )
    impulsive_type_id = serializers.PrimaryKeyRelatedField(
        source="impulsive_type",
        queryset=ImpulsivePrecipitationType.objects.filter(is_active=True),
    )
    amounts = SourceQpfAmountWriteSerializer(many=True, allow_empty=False)

    def validate_amounts(self, amounts):
        durations = [item["duration_hours"] for item in amounts]
        if len(durations) != len(set(durations)):
            raise serializers.ValidationError(
                "Ogni durata puo' comparire una sola volta per zona."
            )
        return amounts


class SourceQpfWriteSerializer(serializers.Serializer):
    map_id = serializers.ChoiceField(choices=MapId.choices)
    zones = SourceQpfWriteItemSerializer(many=True, allow_empty=True)

    def validate_zones(self, zones):
        zone_ids = [item["zone"].pk for item in zones]
        if len(zone_ids) != len(set(zone_ids)):
            raise serializers.ValidationError(
                "Ogni zona puo' comparire una sola volta."
            )
        return zones


class SourcePsWriteItemSerializer(serializers.Serializer):
    zone_id = serializers.PrimaryKeyRelatedField(
        source="zone",
        queryset=ZoneVigilanzaMeteo.objects.filter(is_active=True, type="zdv"),
    )
    phenomenon_type_id = serializers.PrimaryKeyRelatedField(
        source="phenomenon_type",
        queryset=PhenomenonType.objects.filter(
            is_active=True,
            code__in=SOURCE_PHENOMENON_CODES,
        ),
    )
    ps_level_id = serializers.PrimaryKeyRelatedField(
        source="ps_level",
        queryset=PsLevel.objects.filter(is_active=True),
    )
    icon_slot = serializers.IntegerField(min_value=1, max_value=4)
    custom_description = serializers.CharField(required=False, allow_blank=True)

    def validate(self, attrs):
        if attrs["ps_level"].phenomenon_type_id != attrs["phenomenon_type"].pk:
            raise serializers.ValidationError(
                {"ps_level_id": "Il livello PS non appartiene al fenomeno indicato."}
            )
        return attrs


class SourcePsWriteSerializer(serializers.Serializer):
    map_id = serializers.ChoiceField(choices=MapId.choices)
    icons = SourcePsWriteItemSerializer(many=True, allow_empty=True)

    def validate_icons(self, icons):
        slots = [(item["zone"].pk, item["icon_slot"]) for item in icons]
        if len(slots) != len(set(slots)):
            raise serializers.ValidationError(
                "Ogni slot di una zona puo' contenere una sola icona."
            )
        return icons


class SourceQpfItemWriteSerializer(serializers.Serializer):
    non_impulsive_type_id = serializers.PrimaryKeyRelatedField(
        source="non_impulsive_type",
        queryset=NonImpulsivePrecipitationType.objects.filter(is_active=True),
    )
    impulsive_type_id = serializers.PrimaryKeyRelatedField(
        source="impulsive_type",
        queryset=ImpulsivePrecipitationType.objects.filter(is_active=True),
    )
    amounts = SourceQpfAmountWriteSerializer(many=True, allow_empty=False)

    def validate_amounts(self, amounts):
        durations = [item["duration_hours"] for item in amounts]
        if len(durations) != len(set(durations)):
            raise serializers.ValidationError(
                "Ogni durata puo' comparire una sola volta per zona."
            )
        return amounts


class SourcePsItemWriteSerializer(serializers.Serializer):
    phenomenon_type_id = serializers.PrimaryKeyRelatedField(
        source="phenomenon_type",
        queryset=PhenomenonType.objects.filter(
            is_active=True,
            code__in=SOURCE_PHENOMENON_CODES,
        ),
    )
    ps_level_id = serializers.PrimaryKeyRelatedField(
        source="ps_level",
        queryset=PsLevel.objects.filter(is_active=True),
    )
    custom_description = serializers.CharField(required=False, allow_blank=True)

    def validate(self, attrs):
        if attrs["ps_level"].phenomenon_type_id != attrs["phenomenon_type"].pk:
            raise serializers.ValidationError(
                {"ps_level_id": "Il livello PS non appartiene al fenomeno indicato."}
            )
        return attrs


class CurrentQpfWriteItemSerializer(serializers.Serializer):
    zone_id = serializers.PrimaryKeyRelatedField(
        source="zone",
        queryset=ZoneVigilanzaMeteo.objects.filter(is_active=True),
    )
    qpf_level_id = serializers.PrimaryKeyRelatedField(
        source="qpf_level",
        queryset=QpfLevel.objects.filter(is_active=True),
    )
    custom_description = serializers.CharField(required=False, allow_blank=True)


class CurrentQpfWriteSerializer(serializers.Serializer):
    map_id = serializers.ChoiceField(choices=MapId.choices)
    zones = CurrentQpfWriteItemSerializer(many=True, allow_empty=True)

    def validate_zones(self, zones):
        """Impedisce assegnazioni QPF duplicate per la stessa zona."""
        zone_ids = [item["zone"].pk for item in zones]
        if len(zone_ids) != len(set(zone_ids)):
            raise serializers.ValidationError(
                "Ogni zona puo' comparire una sola volta."
            )
        return zones


class CurrentPsWriteItemSerializer(serializers.Serializer):
    zone_id = serializers.PrimaryKeyRelatedField(
        source="zone",
        queryset=ZoneVigilanzaMeteo.objects.filter(is_active=True),
    )
    phenomenon_type_id = serializers.PrimaryKeyRelatedField(
        source="phenomenon_type",
        queryset=PhenomenonType.objects.filter(is_active=True),
    )
    ps_level_id = serializers.PrimaryKeyRelatedField(
        source="ps_level",
        queryset=PsLevel.objects.filter(is_active=True),
    )
    icon_slot = serializers.IntegerField(min_value=1, max_value=4)
    custom_description = serializers.CharField(required=False, allow_blank=True)

    def validate(self, attrs):
        """Verifica che il livello PS appartenga al fenomeno indicato."""
        if attrs["ps_level"].phenomenon_type_id != attrs["phenomenon_type"].pk:
            raise serializers.ValidationError(
                {"ps_level_id": "Il livello PS non appartiene al fenomeno indicato."}
            )
        return attrs


class CurrentPsWriteSerializer(serializers.Serializer):
    map_id = serializers.ChoiceField(choices=MapId.choices)
    icons = CurrentPsWriteItemSerializer(many=True, allow_empty=True)

    def validate_icons(self, icons):
        """Garantisce che ogni slot fisico di una zona contenga una sola icona."""
        slots = [(item["zone"].pk, item["icon_slot"]) for item in icons]
        if len(slots) != len(set(slots)):
            raise serializers.ValidationError(
                "Ogni slot di una zona puo' contenere una sola icona."
            )
        return icons


class CurrentQpfItemWriteSerializer(serializers.Serializer):
    qpf_level_id = serializers.PrimaryKeyRelatedField(
        source="qpf_level",
        queryset=QpfLevel.objects.filter(is_active=True),
    )
    custom_description = serializers.CharField(required=False, allow_blank=True)


class CurrentPsItemWriteSerializer(serializers.Serializer):
    phenomenon_type_id = serializers.PrimaryKeyRelatedField(
        source="phenomenon_type",
        queryset=PhenomenonType.objects.filter(is_active=True),
    )
    ps_level_id = serializers.PrimaryKeyRelatedField(
        source="ps_level",
        queryset=PsLevel.objects.filter(is_active=True),
    )
    custom_description = serializers.CharField(required=False, allow_blank=True)

    def validate(self, attrs):
        """Verifica che il livello PS appartenga al fenomeno indicato."""
        if attrs["ps_level"].phenomenon_type_id != attrs["phenomenon_type"].pk:
            raise serializers.ValidationError(
                {"ps_level_id": "Il livello PS non appartiene al fenomeno indicato."}
            )
        return attrs
