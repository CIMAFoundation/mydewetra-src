import java.io.File;
import java.util.Date;

import it.acrotec.lib.sso.InvalidTokenException;

public class TEST {

	public static void main(String[] args) {
		String SESSION_SEPARATOR = "#";
		String token = "---";
		String toks[] = token.split("\\"+SESSION_SEPARATOR);
		if (toks.length<2) throw new InvalidTokenException();
		try {
			long ts = Long.parseLong(toks[1]);
			Date dt = new Date(ts);
			
			System.out.println("TS: " + ts + " - USER: " + toks[0]);
			
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new InvalidTokenException();
		}
	}
	
}
