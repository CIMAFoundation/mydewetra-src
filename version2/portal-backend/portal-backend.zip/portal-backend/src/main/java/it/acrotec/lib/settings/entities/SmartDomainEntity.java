package it.acrotec.lib.settings.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="settings.domains")
@XmlRootElement
public class SmartDomainEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="descr")
	private String descr;
	
	@Column(name="lonw")
	private float lonW;
	
	@Column(name="lone")
	private float lonE;

	@Column(name="lats")
	private float latS;
	
	@Column(name="latn")
	private float latN;
	
	@Column(name="circle")
	private int circleId;
	
	@Column(name="masterHat")
	private int masterHatId;
	
	@Column(name="starhat")
	private int starHatId;

	

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "circle", insertable=false, updatable=false)
	private CircleEntity circle;
	
	@ManyToOne(fetch = FetchType.EAGER, optional=true)
	@JoinColumn(name = "masterhat", insertable=false, updatable=false)
	private HatEntity masterHat;
	
	@Column(name="prefix")
	private String code;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public float getLonW() {
		return lonW;
	}

	public void setLonW(float lonW) {
		this.lonW = lonW;
	}

	public float getLonE() {
		return lonE;
	}

	public void setLonE(float lonE) {
		this.lonE = lonE;
	}

	public float getLatS() {
		return latS;
	}

	public void setLatS(float latS) {
		this.latS = latS;
	}

	public float getLatN() {
		return latN;
	}

	public void setLatN(float latN) {
		this.latN = latN;
	}

	public int getCircleId() {
		return circleId;
	}

	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}

	public int getMasterHatId() {
		return masterHatId;
	}

	public void setMasterHatId(int masterHatId) {
		this.masterHatId = masterHatId;
	}

	public CircleEntity getCircle() {
		return circle;
	}

	public void setCircle(CircleEntity circle) {
		this.circle = circle;
	}

	public HatEntity getMasterHat() {
		return masterHat;
	}

	public void setMasterHat(HatEntity masterHat) {
		this.masterHat = masterHat;
	}
	
	public String getCode(){
		return code;
	}
	
	public void setCode(String code){
		this.code=code;
	}
	
	public int getStarHatId() {
		return starHatId;
	}

	public void setStarHatId(int starHatId) {
		this.starHatId = starHatId;
	}
	
}
