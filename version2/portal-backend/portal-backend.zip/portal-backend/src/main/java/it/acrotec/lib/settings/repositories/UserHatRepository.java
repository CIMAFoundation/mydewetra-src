package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.UserHatEntity;

public class UserHatRepository extends Repository<UserHatEntity> {

	public UserHatRepository() {
		super("acroweb");
	}

}
