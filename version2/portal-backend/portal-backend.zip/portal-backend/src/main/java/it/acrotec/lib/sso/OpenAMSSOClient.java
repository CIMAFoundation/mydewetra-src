package it.acrotec.lib.sso;

import it.acrotec.lib.Acroweb;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Properties;

/**
 * utility class for authentication with OpenAM
 * @author doy
 */
public class OpenAMSSOClient extends SSO {

	private static final String PASSWORD_ATTR_NAME = "userPassword";
	
	/**
	 * server URL
	 */
	private String ssoUrl;
	/**
	 * realm
	 */
	private String realm;
	/**
	 * admin user id
	 */
	private String adminUser;
	/**
	 * admin user password
	 */
	private String adminPwd;
	/**
	 * admin session token
	 */
	private String adminToken = null;
	
	@Override
	public void setProperties(Properties prop) {
		try {
			this.ssoUrl = prop.getProperty("sso.url");
			this.realm = prop.getProperty("sso.realm");
			this.adminUser = prop.getProperty("sso.adminUser");
			this.adminPwd = prop.getProperty("sso.adminPassword");
		} catch (Exception e) {
			Acroweb.error("Error building sso client", "acroweb", e);
			this.ssoUrl = "http://sso.cimafoundation.org/sso";
			this.realm = "/";
		}
	}
	
	/* (non-Javadoc)
	 * @see it.acrotec.lib.sso.ISSOClient#authenticate(java.lang.String, java.lang.String)
	 */
	@Override
	public String authenticate(String uid, String pwd) throws AuthenticationFailedException {
		String ssoToken = getAuthenticationToken(uid, pwd);
		return ssoToken;
	}

	/* (non-Javadoc)
	 * @see it.acrotec.lib.sso.ISSOClient#checkToken(java.lang.String)
	 */
	@Override
	public String checkToken(String token) {
		if (token==null || token.isEmpty()) throw new InvalidTokenException();
		String uid = GetUserAttribute(token, "uid", null);
		if (uid==null) throw new InvalidTokenException();
		return uid;
	}
	
	/* (non-Javadoc)
	 * @see it.acrotec.lib.sso.ISSOClient#logout(java.lang.String)
	 */
	@Override
	public void logout(String token) throws InvalidTokenException {
		callURL(ssoUrl + "/identity/logout?subjectid=" + token);
	}

	/* (non-Javadoc)
	 * @see it.acrotec.lib.sso.ISSOClient#existsUser(java.lang.String)
	 */
	@Override
	public boolean existsUser(String uid) {
		try {
			//try to read user attributes
			checkAdminToken();
			String s = ssoUrl +
					"/identity/read?admin=" + adminToken + 
					"&name=" + encodeURLData(uid) + 
					"&attributes_names=realm&attributes_values_realm="  + encodeURLData(realm);
			String ret = callURL(s);
			return ret.contains("identitydetails.name=" + uid);
		} catch (Throwable e) {
		}
		return false;
	}
	/* (non-Javadoc)
	 * @see it.acrotec.lib.sso.ISSOClient#createUser(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public void createUser(String uid, String name, String password) throws InvalidTokenException {
		checkAdminToken();
		String s = ssoUrl;
		s += "/identity/create?admin=" + adminToken;
		s += "&identity_name=" + encodeURLData(uid);
		s += "&identity_realm=" +  encodeURLData(realm);
		s += "&identity_attribute_names=cn";
		s += "&identity_attribute_values_cn=" + encodeURLData(name);
		s += "&identity_attribute_names=sn";
		s += "&identity_attribute_values_sn=User";
		s += "&identity_attribute_names=" + PASSWORD_ATTR_NAME;
		s += "&identity_attribute_values_" + PASSWORD_ATTR_NAME + "=" + password;
		s += "&identity_type=user";
		callURL(s);		
	}

	/* (non-Javadoc)
	 * @see it.acrotec.lib.sso.ISSOClient#setPassword(java.lang.String, java.lang.String)
	 */
	@Override
	public void setPassword(String uid, String password) throws InvalidTokenException {
		checkAdminToken();
		String s = ssoUrl;
		s += "/identity/update?admin=" + adminToken;
		s += "&identity_name=" + encodeURLData(uid);
		s += "&identity_realm=" +  encodeURLData(realm);
		s += "&identity_attribute_names=" + PASSWORD_ATTR_NAME;
		s += "&identity_attribute_values_" + PASSWORD_ATTR_NAME + "=" + password;
		callURL(s);
	}
	
	/* (non-Javadoc)
	 * @see it.acrotec.lib.sso.ISSOClient#removeUser(java.lang.String)
	 */
	@Override
	public void removeUser(String uid) throws InvalidTokenException {
		checkAdminToken();
		String s = ssoUrl;
		s += "/identity/delete?admin=" + adminToken;
		s += "&identity_name=" + encodeURLData(uid);
		s += "&identity_realm=" +  encodeURLData(realm);
		s += "&identity_type=user";
		
		callURL(s);
	}		

	private void checkAdminToken() {
		if (adminToken == null) {
			adminToken = getAuthenticationToken(adminUser, adminPwd);
		} else {
			String s = ssoUrl;
			s += "/identity/isTokenValid?tokenid=" + adminToken;		
			try {
				String res = callURL(s);
				if (!res.equalsIgnoreCase("boolean=true")) {
					//try to reconnect
					adminToken = getAuthenticationToken(adminUser, adminPwd);
				}
			} catch (Exception e) {
				//try to reconnect
				adminToken = getAuthenticationToken(adminUser, adminPwd);
			}
		}
	}

	private String callURL(String s) throws InvalidTokenException {
		try {
			URL url = new URL(s);
			BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
			String line = reader.readLine();
			return line;
		} catch (MalformedURLException e) {
			Acroweb.error("Error calling sso url", "acroweb", e);
			throw new InvalidTokenException();
		} catch (IOException e) {
			Acroweb.error("Error calling sso url", "acroweb", e);
			throw new InvalidTokenException();
		}
	}

	private String encodeURLData(String s) throws InvalidTokenException {
		try {
			return URLEncoder.encode(s,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			Acroweb.error("Error encoding sso url data", "acroweb", e);
			throw new InvalidTokenException();
		}
	}

	private String GetUserAttribute(String token, String attrName, String defaultValue) throws InvalidTokenException  {
		try {
			
			//URL url = new URL(ssoUrl + "/identity/attributes?subjectid=" + token + "&attributenames=" + attrName);
			URL url = new URL(ssoUrl + "/identity/attributes?refresh=true&subjectid=" + token + "&attributenames=" + attrName);
			//System.out.println("url: "+url);
			BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
			String line = reader.readLine();			
			while (line != null) {
				String tokens[] = line.split("=");
				if (tokens.length>=2 && tokens[0].equals("userdetails.attribute.value")) {
					return tokens[1];
				}
				line = reader.readLine();
			}
			
			return defaultValue;
		} catch (MalformedURLException e) {
			Acroweb.error("Error retrieving user attribute from sso", "acroweb", e);
			throw new InvalidTokenException();
		} catch (IOException e) {
			Acroweb.error("Error retrieving user attribute from sso", "acroweb", e);
			throw new InvalidTokenException();
		}
	}
	
	private String getAuthenticationToken(String uid, String pwd) throws AuthenticationFailedException {
		try {
			String s = ssoUrl + "/identity/authenticate?username=" + uid + "&password=" + pwd + "&uri=realm=" + realm;
			URL url = new URL(s);
			BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
			String line = reader.readLine();
			if (line==null) throw new AuthenticationFailedException("no responce received");
			String tokens[] = line.split("=");
			if (tokens.length>2 || !tokens[0].equals("token.id")) throw new AuthenticationFailedException("invalid credentials");
			
			//recupero il default hat per l'utente
			String ssoToken = tokens[1];
			return ssoToken;
		} catch (MalformedURLException e) {
			throw new AuthenticationFailedException("malformed url");
		} catch (IOException e) {
			throw new AuthenticationFailedException("network error");
		}
	}
}
