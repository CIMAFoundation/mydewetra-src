package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.HibernateUtils;
import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.PortEntity;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

public class PortRepository extends Repository<PortEntity> {

	public PortRepository() {
		super("acroweb");
	}

	public PortEntity getPort(final String host) {
		List<PortEntity> entities = selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery(
						"select settings.ports.* from settings.ports "
						+ "inner join settings.portshosts on settings.ports.id = settings.portshosts.port "
						+ "and strpos(:host, settings.portshosts.host)>0");
				q.addEntity(PortEntity.class);
				q.setString("host", host);
				return q;
			}
		});
		
		return entities.isEmpty() ? null : entities.get(0);
	}
}
