package it.acrotec.lib.settings.repositories;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.ApplicationEntity;

public class ApplicationRepository extends Repository<ApplicationEntity> {

	public ApplicationRepository() {
		super("acroweb");
	}

	/*
	 * Ritorna tutte le app che hanno almeno una configurazione nel dominio specificato
	 */
	
	public List<ApplicationEntity> selectByDomain(final int domainId) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery(
						"select distinct a.*  from settings.applications a "
						+ " left join settings.configurations c on c.application=a.id "
						+ " left join settings.hatsconfigurations hc on hc.configuration=c.id "
						+ " left join settings.hats h on h.id=hc.hat "
						+ " where h.domain= :domainid  ");
				q.addEntity(ApplicationEntity.class);
				q.setInteger("domainid", domainId);
				return q;
			}
		});		
	}


}
