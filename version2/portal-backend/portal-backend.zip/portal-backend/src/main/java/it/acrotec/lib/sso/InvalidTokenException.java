package it.acrotec.lib.sso;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


public class InvalidTokenException extends WebApplicationException {

	private static final long serialVersionUID = 2675260261751266365L;

	public InvalidTokenException() {
		super("invalid authentication token", Response.status(Status.UNAUTHORIZED).entity("invalid authentication token").type(MediaType.TEXT_PLAIN).build());
	}

}
