package it.acrotec.lib.settings.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="settings.configurationresources")
@XmlRootElement
public class ConfigurationResourceEntity implements Serializable {

	@Id
	@Column(name="configuration")
	private int configuration;
	
	@Id
	@Column(name="resource")
	private String resource;
	
	@Column(name="value")
	private String value;
	
	public ConfigurationResourceEntity() {
	}

	
	public ConfigurationResourceEntity(int configuration, String resource, String value) {
		super();
		this.configuration = configuration;
		this.resource = resource;
		this.value = value;
	}

	public int getConfiguration() {
		return configuration;
	}

	public void setConfiguration(int configuration) {
		this.configuration = configuration;
	}

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
