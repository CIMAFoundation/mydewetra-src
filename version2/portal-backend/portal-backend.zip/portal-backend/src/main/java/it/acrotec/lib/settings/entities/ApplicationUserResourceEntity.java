package it.acrotec.lib.settings.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="settings.appuserresources")
@XmlRootElement
public class ApplicationUserResourceEntity implements Serializable {

	@Id
	@Column(name="application")
	private String application;

	@Id
	@Column(name="usr")
	private String user;
	
	@Id
	@Column(name="resource")
	private String resource;

	@Column(name="value")
	private String value;

	public ApplicationUserResourceEntity() {
	}

	public ApplicationUserResourceEntity(String id, String user, String resource, String value) {
		super();
		this.application = id;
		this.user = user;
		this.resource = resource;
		this.value = value;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
