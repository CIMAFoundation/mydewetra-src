package it.acrotec.lib.settings;

import it.acrotec.lib.settings.entities.CircleEntity;
import it.acrotec.lib.settings.repositories.CircleRepository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CircleTree {
	
	/**
	 * node value
	 */
	private CircleEntity circle;
	
	/**
	 * childs
	 */
	private List<CircleTree> childs = new ArrayList<CircleTree>();
	
	public CircleTree() {
	}
	
	public CircleTree(CircleEntity circle) {
		this.circle = circle;
	}
	
	public CircleEntity getCircle() {
		return circle;
	}
	
	public void setCircle(CircleEntity circle) {
		this.circle = circle;
	}
	
	public List<CircleTree> getChilds() {
		return childs;
	}
	
	public void setChilds(List<CircleTree> childs) {
		this.childs = childs;
	}
	
	@Override
	public String toString() {
		return circle.toString();
	}

	
	private static CircleTree buildTree(CircleTree tree, List<CircleEntity> list, int i, boolean[] done) {

		CircleEntity current = list.get(i);
		if (tree==null) {
			tree = new CircleTree(current);
			done[i] = true;
		}
		
//		System.out.println("esploro " + current.getDescr() + " con l'albero " + tree.getCircle().getDescr());
		
		CircleTree parent = null;
		int parentIndex = 0;
		for (int j = 0; j < list.size(); j++) {
			if (done[j]) continue;
			CircleEntity cp = list.get(j);
			CircleTree newTree = new CircleTree(cp);
			if (cp.getParent()!=null && cp.getParent()==current.getId()) {
				done[j] = true;
				//ho trovato un figlio diretto
				tree.childs.add(buildTree(newTree, list, j, done));
			}
			if (current.getParent()!=null && current.getParent() == cp.getId()) {
				//ho trovato il padre
				parent = newTree;
				parentIndex = j;
				done[j] = true;
			}
		}
		if (parent!=null) {
			parent.childs.add(tree);
			return buildTree(parent, list, parentIndex, done);
		}
		return tree;
	}
	
	
	public static ArrayList<CircleTree> buildTrees(List<CircleEntity> circles) {
		boolean[] done = new boolean[circles.size()];
		Arrays.fill(done, false);
		
		ArrayList<CircleTree> trees = new ArrayList<CircleTree>();
		
		boolean allDones = false;
		while (!allDones) {
			allDones = true;
			for (int i = 0; i < done.length; i++) {
				if (!done[i]) {
					trees.add(buildTree(null, circles, i, done));
				}
			}
		}
		
		return trees;
	}
	
	public static void main(String[] args) {
		List<CircleEntity> circles = new CircleRepository().selectAll(CircleEntity.class);
		ArrayList<CircleTree> trees = CircleTree.buildTrees(circles);
		System.out.println();
	}
	
}
