package it.acrotec.lib.settings.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="settings.usercircles")
@XmlRootElement
public class UserCircleEntity implements Serializable {

	private static final long serialVersionUID = 5590986247366059751L;

	@Id 
	@Column(name="usr")
	String user;

	@Id
	@Column(name="circle")
	private int circle;
	
	public UserCircleEntity() {
	}
	
	public UserCircleEntity(String user, int circle) {
		super();
		this.user = user;
		this.circle = circle;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public int getCircle() {
		return circle;
	}

	public void setCircle(int circle) {
		this.circle = circle;
	}

}
