package it.acrotec.lib.logbook.repositories;

import it.acrotec.lib.Acroweb;
import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.logbook.entities.Activity;
import it.acrotec.lib.logbook.entities.Session;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;

public class LogbookRepository extends Repository<Session> {

	private Repository<Activity> activityRepo;

	public LogbookRepository() {
		super("acroweb");
		activityRepo = new Repository<Activity>("acroweb");
	}

	/**
	 * add a new activity to logbook
	 * @param ssotoken
	 * @param application
	 * @param clientIp 
	 * @param skin 
	 * @param activity
	 */
	public void addActivity(final String ssotoken, String application, String clientIp, String skin, String activity) {
		
		final String[] splitToken = Acroweb.auth().splitToken(ssotoken);
		final String token = splitToken[0];
		
		//retrieve session
		List<Session> sessions = selectByQuery(new QueryBuilder() {
			@Override
			public Query build(org.hibernate.Session s) {
				Query q = s.createQuery("from Session where token = :token");
				q.setString("token", token);
				return q;
			}
		});
		
		Session session = null;
		if ((sessions == null) || sessions.isEmpty()) {
			//get user data
			String uid = Acroweb.auth().verifySessionToken(ssotoken);
			if (skin == null || skin.isEmpty()) {
				Acroweb.warning("unable to add logbook activity for user " + uid + " (logbook not initialized): " + activity, application);
			} else {
				//create new session
				session = new Session(uid, token, clientIp, skin, Integer.parseInt(splitToken[1]));
				session.getActivities().add(new Activity(session, application, activity));
				save(session);
			}
			
		} else {
			//add new activity to existing session
			session = sessions.get(0);
			Activity a = new Activity(session, application, activity);
			activityRepo.save(a);
		}
	}
	
	public List<Activity> getActivities(final int sessionId) {
		return activityRepo.selectByQuery(new QueryBuilder() {
			@Override
			public Query build(org.hibernate.Session s) {
				Query q = s.createQuery("from Activity where session = :session order by date desc");
				q.setInteger("session", sessionId);
				return q;
			}
		});
	}
}
