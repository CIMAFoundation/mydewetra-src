package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.DomainWithCircleEntity;
import it.acrotec.lib.settings.entities.SmartDomainEntity;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

public class SmartDomainRepository extends Repository<SmartDomainEntity> {

	public SmartDomainRepository() {
		super("acroweb");
	}
	
	/**
	 * search for the domain associated by the circle.
	 * @param circle
	 * @return domain if circle has an associated domain, null otherwise
	 */
	public SmartDomainEntity getAssociatedDomain(final int circle){
		List result = doQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery("select * from settings.domains where circle = :circle");
				q.setInteger("circle", circle);
				q.addEntity(SmartDomainEntity.class);
				return q;

			}
		});
		
		if (result==null || result.isEmpty()) return null;
		return (SmartDomainEntity)result.get(0);		
	}
	
	/**
	 * search for the domain controlled by the hat.
	 * @param hat
	 * @return domain if hat is a master hat, null otherwise
	 */
	public DomainWithCircleEntity getControlledDomain(final int hat) {
		
		List result = doQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery("select id, circle, descr from settings.domains where masterhat = :hat");
				q.setInteger("hat", hat);
				q.addEntity(DomainWithCircleEntity.class);
				return q;

			}
		});
		
		if (result==null || result.isEmpty()) return null;
		return (DomainWithCircleEntity)result.get(0);		
	}
	
	/**
	 * serch for the domain of an hat
	 * @param hat
	 * @return
	 */
	public DomainWithCircleEntity getHatDomain(final int hat) {
		List result = doQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery("select D.id, D.circle, D.descr from settings.domains D inner join settings.hats H on D.id = H.domain where H.id = :hat");
				q.setInteger("hat", hat);
				q.addEntity(DomainWithCircleEntity.class);
				return q;
			}
		});
		
		if (result==null || result.isEmpty()) return null;
		return (DomainWithCircleEntity)result.get(0);				
	}
	
	public static void main(String[] args) {
		SmartDomainEntity e = new SmartDomainRepository().select(11, SmartDomainEntity.class);
		
		System.out.println("ciao");
	}
	
}
