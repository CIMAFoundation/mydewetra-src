package it.acrotec.lib;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QueryManager {

	public static abstract class QueryExecutor {
		public abstract void execute(Connection cnx) throws SQLException;
		public void executionEnd(Connection cnx) throws SQLException {}
	}

	public static class QueryExecutionListener {
		public void setStatement(PreparedStatement stm) throws SQLException {}
		public void rsRow(ResultSet rs) throws SQLException {}
	}

	private File propFile;

	public QueryManager(File propFile) {
		this.propFile = propFile;
	}
	
	
	public void executeQuery(QueryExecutor executor) throws Exception {
		Connection cnx = null;		
		try {			
			cnx = PGConnectionManager.GetConnection(propFile);
			executor.execute(cnx);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new Exception("invalid property file");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("error querying database");
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception("error reading property file");
		} finally {
			try {				
				if (cnx!=null) {
					executor.executionEnd(cnx); 
					cnx.close();
				}
			} catch (SQLException e) {
			}
		}				
	}
	
	public void executeQuery(final boolean update, final String query, final QueryExecutionListener listener) throws Exception {
		
		executeQuery(new QueryExecutor() {
			
			@Override
			public void execute(Connection cnx) throws SQLException {
				doStatement(update, query, cnx, listener);
			}
			
		});		
	}
	
	public void doStatement(final boolean update, final String query, Connection cnx, final QueryExecutionListener listener) throws SQLException {
		PreparedStatement stm = cnx.prepareStatement(query);			
		listener.setStatement(stm);
		if (update) {
			stm.executeUpdate();
		} else {
			ResultSet rs = stm.executeQuery();
			while (rs.next()) {
				listener.rsRow(rs);
			}				
		}
	}
	
	
	public void executeQueriesInTransaction(QueryExecutor[] executors) throws Exception {
		Connection cnx = null;		
		try {			
			cnx = PGConnectionManager.GetConnection(propFile);
			cnx.setAutoCommit(true);
			for (QueryExecutor executor : executors) {
				executor.execute(cnx);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new Exception("invalid property file");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("error querying database");
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception("error reading property file");
		} finally {
			try {				
				if (cnx!=null) {
					for (QueryExecutor executor : executors) {
						executor.executionEnd(cnx);
					}
					cnx.setAutoCommit(false);
					cnx.close();
				}
			} catch (SQLException e) {
			}
		}				
	}
	
	public void executeQueriesInTransaction(boolean updates[], String queries[], QueryExecutionListener listeners[]) throws Exception {
		Connection cnx = null;		
		try {			
			cnx = PGConnectionManager.GetConnection(propFile);
			cnx.setAutoCommit(false);
			
			for (int i = 0; i < listeners.length; i++) {
				doStatement(updates[i], queries[i], cnx, listeners[i]);
			}
			
			cnx.commit();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new Exception("invalid property file");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception("error querying database");
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception("error reading property file");
		} finally {
			try {				
				if (cnx!=null) {
					cnx.setAutoCommit(false);
					cnx.close();
				}
			} catch (SQLException e) {
			}
		}				
	}
	
	
}
