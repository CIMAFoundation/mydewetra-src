package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.HibernateUtils;
import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.Configuration;
import it.acrotec.lib.settings.entities.HatApplicationResourceEntity;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public class HatApplicationResourceRepository extends Repository<HatApplicationResourceEntity> {

	public HatApplicationResourceRepository() {
		super("acroweb");
	}

	public Configuration getConfiguration(final int hat, final String application) {
		List<HatApplicationResourceEntity> entities = selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				Query q = s.createQuery("from HatApplicationResourceEntity where hat = :hat and application = :application");
				q.setInteger("hat", hat);
				q.setString("application", application);
				return q;
			}
		});
		
		Configuration conf = new Configuration();
		
		for (HatApplicationResourceEntity e : entities) {
			conf.put(e.getResource(), e.getValue());
		}
		
		return conf;
	}

//	public static void main(String[] args) {
//		Configuration m = new HatApplicationResourceRepository().getConfiguration(6, "datamonitor");
//		
//		HibernateUtils.shutdown();
//	}
}
