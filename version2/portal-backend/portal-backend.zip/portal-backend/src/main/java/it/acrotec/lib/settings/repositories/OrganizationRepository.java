package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.OrganizationEntity;

public class OrganizationRepository extends Repository<OrganizationEntity> {

	public OrganizationRepository() {
		super("acroweb");
	}

}
