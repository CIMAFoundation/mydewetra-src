package it.acrotec.lib.sso;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.Properties;
import java.util.Random;
import java.util.UUID;

import javax.xml.bind.DatatypeConverter;

public class AcrowebSSO extends SSO {
	//win
	//private static final String SESSION_SEPARATOR = "#";
	
	private static final String SESSION_SEPARATOR = "|";


	private static class TokenData {		
		File f;
		String uid;
		Date dt;
		public TokenData(File f, String uid, Date dt) {
			super();
			this.f = f;
			this.uid = uid;
			this.dt = dt;
		}
	}
	
	private final static SimpleDateFormat sessionDirFormatter = new SimpleDateFormat("yyyy/MM/dd");

	File dbDir = null;
	File usersDir = null;
	File sessionsDir = null;
	
	private boolean checkDBDir() {
		if (dbDir.isDirectory()) {
			usersDir = new File(dbDir, "users");
			if (usersDir.exists() || usersDir.mkdirs()) {
				sessionsDir = new File(dbDir, "sessions");
				return sessionsDir.exists() || sessionsDir.mkdirs();				
			}
		}
		return false;
	}
	
	private String getFileContent(File f) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String s = br.readLine();
			br.close();
			return s;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void touch(File file, long timestamp) throws IOException {
		if (!file.exists()) {
			new FileOutputStream(file).close();
		}
	    file.setLastModified(timestamp);
	}
	
	private String newSession(String uid) {
		Date dt = new Date();
		String token = uid + SESSION_SEPARATOR + dt.getTime() + SESSION_SEPARATOR + UUID.randomUUID().toString();
		try {
			File sessionFile = getSessionFile(dt, token);
			touch(sessionFile, dt.getTime());
			return token;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}


	private File getSessionFile(Date dt, String token) {
		File sessionFileDir = new File(sessionsDir, sessionDirFormatter.format(dt));
		if (!sessionFileDir.exists()) sessionFileDir.mkdirs();
		File sessionFile = new File(sessionFileDir, token);
		return sessionFile;
	}
	
	private TokenData getTokenData(String token) {
		String toks[] = token.split("\\"+SESSION_SEPARATOR);
		if (toks.length<2) throw new InvalidTokenException();
		try {
			long ts = Long.parseLong(toks[1]);
			Date dt = new Date(ts);
			File f = getSessionFile(dt, token);
			if (!f.exists()) throw new InvalidTokenException();
			return new TokenData(f, toks[0], dt);
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new InvalidTokenException();
		}
	}
	
	private void savePassword(String password, File userFile) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(userFile));
			writer.write(getSSHAHash(password));
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new AuthenticationFailedException("unable to save user password");
		}
	}

	@Override
	public void setProperties(Properties prop) {
		String s = prop.getProperty("sso.baseDir");
		if (s!=null) {
			dbDir = new File(s);
			checkDBDir();
		}		
	}
	
	@Override
	public String authenticate(String uid, String pwd) throws AuthenticationFailedException {
		if (uid==null || pwd==null) throw new AuthenticationFailedException("invalid credentials");
		if (!checkDBDir()) throw new AuthenticationFailedException("invalid users db directory: " + dbDir.getAbsolutePath());
		File userFile = new File(usersDir, uid);
		if (!userFile.canRead()) throw new AuthenticationFailedException("invalid user: " + uid);
		String readPwd = getFileContent(userFile);	
		if (readPwd == null) throw new AuthenticationFailedException("found null password");
		if (readPwd.startsWith("{SSHA}")) {
			if (!checkSSHAPassword(readPwd, pwd)) throw new AuthenticationFailedException("invalid SSHA password");
		} else { 
			if (!readPwd.equals(pwd)) throw new AuthenticationFailedException("invalid password");
			savePassword(pwd, userFile);
		}
		String token = newSession(uid); 
		if (token==null) throw new AuthenticationFailedException("unable to create session");
		return token;
	}

	@Override
	public String checkToken(String token) {
		if (!checkDBDir()) throw new AuthenticationFailedException("invalid users db directory: " + dbDir.getAbsolutePath());
		TokenData data = getTokenData(token);
		return data.uid;
	}

	@Override
	public void logout(String token) throws InvalidTokenException {
		if (!checkDBDir()) throw new AuthenticationFailedException("invalid users db directory: " + dbDir.getAbsolutePath());
		TokenData data = getTokenData(token);
		data.f.delete();
	}

	@Override
	public boolean existsUser(String uid) {
		if (!checkDBDir()) throw new AuthenticationFailedException("invalid users db directory: " + dbDir.getAbsolutePath());
		File userFile = new File(usersDir, uid);
		return userFile.canRead();
	}

	@Override
	public void createUser(String uid, String name, String password) throws InvalidTokenException {
		if (!checkDBDir()) throw new AuthenticationFailedException("invalid users db directory: " + dbDir.getAbsolutePath());
		File userFile = new File(usersDir, uid);
		if (userFile.canRead()) throw new AuthenticationFailedException("user already exists");
		savePassword(password, userFile);
	}

	@Override
	public void setPassword(String uid, String password) throws InvalidTokenException {
		if (!checkDBDir()) throw new AuthenticationFailedException("invalid users db directory: " + dbDir.getAbsolutePath());
		File userFile = new File(usersDir, uid);
		if (!userFile.canRead()) throw new AuthenticationFailedException("user does not exists");
		savePassword(password, userFile);
	}

	@Override
	public void removeUser(String uid) throws InvalidTokenException {
		if (!checkDBDir()) throw new AuthenticationFailedException("invalid users db directory: " + dbDir.getAbsolutePath());
		File userFile = new File(usersDir, uid);
		if (!userFile.canRead()) throw new AuthenticationFailedException("user does not exists");
		userFile.delete();
	}

	
	private String getSSHAHash(String password) {
		try {
			byte[] salt = new byte[4];
			new Random().nextBytes(salt);
			
			byte[] bytes = password.getBytes(StandardCharsets.UTF_8);
			
			MessageDigest cript = MessageDigest.getInstance("SHA-1");
			cript.reset();
			cript.update(bytes);
			cript.update(salt);
			byte[] digest = cript.digest();
			
			byte[] hash = Arrays.copyOf(digest, digest.length + salt.length);
			for (int i = 0; i < salt.length; i++) {
				hash[i+digest.length] = salt[i];
			}
			
			return "{SSHA}" + base64Encode(hash);//Base64.getEncoder().encodeToString(hash);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return password;
	}
	
	private String base64Encode(byte[] hash){
		//java 7 e precedenti
		return DatatypeConverter.printBase64Binary(hash);
		//java 8
		//return Base64.getEncoder().encodeToString(hash);
	}
	
	private byte[] base64Decode(String val){
		//java 7 e precedenti
		return DatatypeConverter.parseBase64Binary(val);
		//java 8
		//return Base64.getDecoder().decode(val);
	}
	
	private boolean checkSSHAPassword(String hash, String password) {
		try {
			String substring = hash.substring(6);
			byte[] challenge_bytes = base64Decode(substring); //Base64.getDecoder().decode(substring);
			byte[] digest = Arrays.copyOfRange(challenge_bytes, 0, 20);
			byte[] salt = Arrays.copyOfRange(challenge_bytes, 20, challenge_bytes.length);			
			MessageDigest cript = MessageDigest.getInstance("SHA-1");
			cript.reset();
			
			byte[] bytes = password.getBytes(StandardCharsets.UTF_8);
			cript.update(bytes);
			cript.update(salt);
			byte[] pwdDigest = cript.digest();

			boolean authenticated = MessageDigest.isEqual(digest, pwdDigest);
			return authenticated;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	
	public static void main(String[] args) {

		AcrowebSSO sso = (AcrowebSSO)SSO.instantiate(new File("/home/doy/workspaces/acroweb/acroweb/web/src/main/webapp/WEB-INF/auth.properties"));
		
	}

	
	

}
