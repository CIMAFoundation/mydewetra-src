package it.acrotec.lib.settings;

import java.util.HashMap;

public class Configuration extends HashMap<String, String> {

	public String getResource(String name, String defaultValue) {
		String v = get(name);
		return v==null || v.isEmpty() ? defaultValue : v;
	}
	
}
