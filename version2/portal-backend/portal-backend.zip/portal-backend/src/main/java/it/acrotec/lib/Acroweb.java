package it.acrotec.lib;

import it.acrotec.lib.logbook.repositories.LogbookRepository;
import it.acrotec.lib.settings.Configuration;
import it.acrotec.lib.settings.repositories.HatApplicationResourceRepository;
import it.acrotec.lib.sso.OpenAMSSOClient;
import it.acrotec.lib.sso.SSO;

import java.io.File;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * class for framework shared objects
 * @author doy
 *
 */
public class Acroweb {

	/**
	 * request prameter name for authentication token
	 */
	public static final String AUTH_TOKEN_PARAMETER = "acroweb_token";
	
	/**
	 * request prameter name for user id
	 */
	public static final String UID_TOKEN_PARAMETER = "acroweb_userid";

	/**
	 * request prameter name for user id
	 */
	public static final String HAT_TOKEN_PARAMETER = "acroweb_hatid";
	
	/**
	 * single sign on client
	 */
	private static Auth sso;

	/**
	 * application logger
	 */
	private static Logger logger = Logger.getLogger("acroweb");
	
	/**
	 * application logbook
	 */
	private static LogbookRepository logbook;
	
	/**
	 * api mode (test/official)
	 */
	private static String mode = null;
	
	private static boolean initialized = false;
	
	/**
	 * initialization from an etc folder
	 * @param etcDir
	 */
	public static void init(File etcDir) {
	
		if (!initialized) {
			initialized = true;

			//initialize the sso client
			File p = new File(etcDir, "auth.properties");
			sso = new Auth(SSO.instantiate(p));

			//initialize the logger
			logger.setLevel(Level.ALL); //TODO parametrize the log level

			//initialize the logbook
			logbook = new LogbookRepository();
		}
		
	}
	
	/**
	 * obtain the sso client
	 * @return
	 */
	public static Auth auth() {
		if (sso == null) throw new InternalServerException("web framwork not initialized");
		return sso;
	}
	
	/**
	 * write an info log
	 * @param message
	 * @param app
	 */
	public static void info(String message, String app) {
		String msg = app==null? message : app + ": " + message;
		logger.log(Level.INFO, msg);
	}
	
	/**
	 * write a warning log
	 * @param message
	 * @param app
	 */
	public static void warning(String message, String app) {
		String msg = app==null? message : app + ": " + message;
		logger.log(Level.WARNING, msg);
	}
	
	/**
	 * write an error log
	 * @param message
	 * @param app
	 * @param e
	 */
	public static void error(String message, String app, Throwable e) {
		String msg = app==null? message : app + ": " + message;
		if (e!=null) {
			logger.log(Level.SEVERE, msg, e);
		} else {
			logger.log(Level.SEVERE, msg);
		}
		
	}

	/**
	 * write an activity in the logbook	
	 * @param token
	 * @param application
	 * @param clientIp
	 * @param skin 
	 * @param activity 
	 */
	public static void initLogbook(String token, String application, String clientIp, String skin, String activity) {
		if (!amIInTesting()) logbook.addActivity(token, application, clientIp, skin, activity);
	}

	/**
	 * write an activity in the logbook	
	 * @param token
	 * @param application
	 * @param clientIp
	 * @param skin 
	 * @param activity 
	 */
	public static void logbookActivity(String token, String application, String clientIp, String activity) {
		if (!amIInTesting()) logbook.addActivity(token, application, clientIp, null, activity);
	}
	
	/**
	 * loads a confguration for an hat and an application
	 * @param hat
	 * @param application
	 * @return
	 */
	public static Configuration getConfiguration(int hat, String application) {
		return new HatApplicationResourceRepository().getConfiguration(hat, application);
	}

	
	public static void setMode(String uri) {
		String luri = uri.toLowerCase();
		mode = (luri.contains("api_test")) ? "test" : "official";
	}
	
	public static boolean isModeSpecified() {
		return mode!=null;
	}
	
	public static boolean amIInTesting() {
		return !isModeSpecified() || mode.equals("test");
	}
}
