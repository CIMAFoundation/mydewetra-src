package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.ApplicationWithConfigurationsEntity;

public class ApplicationWithConfigurationsRepository extends Repository<ApplicationWithConfigurationsEntity> {

	public ApplicationWithConfigurationsRepository() {
		super("acroweb");
	}

}
