package it.acrotec.lib.settings.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="settings.hatappresources")
@XmlRootElement
public class HatApplicationResourceEntity implements Serializable {

	@Id
	@Column(name="hat")
	private int hat;
	
	@Id
	@Column(name="application")
	private String application;

	@Id
	@Column(name="resource")
	private String resource;
	
	@Column(name="value")
	private String value;

	public int getHat() {
		return hat;
	}

	public void setHat(int hat) {
		this.hat = hat;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}	
}
