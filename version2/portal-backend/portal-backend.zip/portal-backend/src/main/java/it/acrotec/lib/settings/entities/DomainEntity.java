package it.acrotec.lib.settings.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="settings.domains")
@XmlRootElement
public class DomainEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="descr")
	private String descr;
	
	@Column(name="lonw")
	private double lonw=0;

	@Column(name="lone")
	private double lone=0;

	@Column(name="lats")
	private double lats=0;

	@Column(name="latn")
	private double latn=0;
	
	@Column(name="prefix")
	private String code;
	
	@Column(name="circle")
	private int circleId;
	
	@Column(name="masterhat")
	private int masterhatId;
	
	@Column(name="starhat")
	private int starHatId=-1;
	
	

	public DomainEntity() {
	}
	
	public DomainEntity(int id, String descr) {
		super();
		this.id = id;
		this.descr = descr;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}
	
	public void setLonw(double val){
		lonw=val;
	}
	public double getLonw(){
		return lonw;
	}
	public void setLone(double val){
		lone=val;
	}
	public double getLone(){
		return lone;
	}
	public void setLats(double val){
		lats=val;
	}
	public double getLats(){
		return lats;
	}
	public void setLatn(double val){
		latn=val;
	}
	public double getLatn(){
		return latn;
	}

	public String getCode(){
		return code;
	}
	
	public void setCode(String code){
		this.code=code;
	}
	
	public int getCircleId(){
		return circleId;
	}
	
	public void setCircleId(int val){
		this.circleId=val;
	}
	public int getMasterhatId(){
		return masterhatId;
	}
	public void setMasterhatId(int val){
		this.masterhatId=val;
	}
	public int getStarHatId() {
		return starHatId;
	}

	public void setStarHatId(int starHatId) {
		this.starHatId = starHatId;
	}
}
