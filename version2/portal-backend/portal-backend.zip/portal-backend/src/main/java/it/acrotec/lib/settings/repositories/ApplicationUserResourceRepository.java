package it.acrotec.lib.settings.repositories;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.ApplicationUserResourceEntity;

public class ApplicationUserResourceRepository extends Repository<ApplicationUserResourceEntity> {

	public ApplicationUserResourceRepository() {
		super("acroweb");
	}
	
	public List<ApplicationUserResourceEntity> getResources(final String user, final String app) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				Query q = s.createQuery("from ApplicationUserResourceEntity where user = :user and application = :app");
				q.setString("user", user);
				q.setString("app", app);
				return q;
			}
		});
	}

}
