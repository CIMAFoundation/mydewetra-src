package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.UserEntity;

public class UserRepository extends Repository<UserEntity> {

	public UserRepository() {
		super("acroweb");
	}
}
