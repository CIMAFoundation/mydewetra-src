package it.acrotec.lib;

public interface DaemonRunnable extends Runnable {

	/**
	 * Ritardo della prima esecuzione (secondi)
	 * @return
	 */
	public long getInitialDelay();
	
	/**
	 * Intervallo in secondi delle successive esecuzioni
	 * @return
	 */
	public long getPeriod();
	
	
	
}
