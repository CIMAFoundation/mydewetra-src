package it.acrotec.rest.api;

import java.io.IOException;

import org.glassfish.jersey.media.sse.OutboundEvent;
import org.glassfish.jersey.media.sse.SseBroadcaster;
import org.glassfish.jersey.server.ChunkedOutput;

public class CustomSseBroadcaster extends SseBroadcaster {

	
	@Override
	public void onClose(ChunkedOutput<OutboundEvent> chunkedOutput) {
			super.onClose(chunkedOutput);
			try {
				if (!chunkedOutput.isClosed())
							chunkedOutput.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
