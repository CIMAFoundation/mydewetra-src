package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.ConfigurationResourceEntity;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public class ConfigurationResourceRepository extends Repository<ConfigurationResourceEntity> {

	public ConfigurationResourceRepository() {
		super("acroweb");
	}
	
	public List<ConfigurationResourceEntity> getConfigurationResources(final int conf) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				Query q = s.createQuery("from ConfigurationResourceEntity where configuration = :conf");
				q.setInteger("conf", conf);
				return q;
			}
		});
	}

}
