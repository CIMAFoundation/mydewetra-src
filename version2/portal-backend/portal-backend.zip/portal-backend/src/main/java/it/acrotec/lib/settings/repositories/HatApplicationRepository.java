package it.acrotec.lib.settings.repositories;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.HatApplicationEntity;

public class HatApplicationRepository extends Repository<HatApplicationEntity> {

	public HatApplicationRepository() {
		super("acroweb");
	}
	
	/**
	 * obtains all applications that are accessible for a hat
	 * @param hat
	 * @return
	 */
	public List<HatApplicationEntity> getApplications(final int hat) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				Query q = s.createQuery("from HatApplicationEntity where hat = :hat");
				q.setInteger("hat", hat);
				return q;
			}
		});
	}
	
	/**
	 * verify that a hat has a configuration for an application
	 * @param hat
	 * @param app
	 * @return
	 */
	public boolean hasAccess(final int hat, final String app) {
		List<HatApplicationEntity> l = selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				Query q = s.createQuery("from HatApplicationEntity where hat = :hat and id = :app");
				q.setInteger("hat", hat);
				q.setString("app", app);
				return q;
			}
		});
		return !l.isEmpty();
	}

}
