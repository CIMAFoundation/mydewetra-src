package it.acrotec.lib.settings.repositories;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.HatEntity;

public class HatRepository extends Repository<HatEntity> {

	public HatRepository() {
		super("acroweb");
	}
	
	/**
	 * search for all hats of a specific domain
	 * @param domainId
	 * @return
	 */
	public List<HatEntity> getDomainHats(final int domainId) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				Query q = s.createQuery("from HatEntity where domain = :domain");
				q.setInteger("domain", domainId);
				return q;
			}
		});
	}
	
	/**
	 * search for all hats who hold a configuration for the application.
	 * @param appId
	 * @return
	 */
	public List<HatEntity> getHatsConfiguration(final String appId) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery(
						  " select settings.hats.* from settings.hats "
						+ " left join settings.hatsconfigurations on settings.hats.id=settings.hatsconfigurations.hat "
						+ " left join settings.configurations  on settings.hatsconfigurations.configuration=settings.configurations.id "
						+ " where settings.configurations.application = :appid");
				q.addEntity(HatEntity.class);
				q.setString("appid", appId);
				return q;
			}
		});	
	
	}
	
}
