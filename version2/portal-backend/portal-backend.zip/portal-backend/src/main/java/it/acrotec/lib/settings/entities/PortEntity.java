package it.acrotec.lib.settings.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="settings.ports")
@XmlRootElement
public class PortEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="descr")
	private String descr;
	
	@Column(name="skin")
	private String skin;

	@Column(name="dashboard")
	private String dashboard;
	
	@Column(name="prefix")
	private String prefix;
	
	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name="settings.portsapps", joinColumns={@JoinColumn(name="portid", referencedColumnName="id")}, inverseJoinColumns={@JoinColumn(name="appid", referencedColumnName="id")})
	private List<ApplicationEntity> applications;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "circle", insertable=false, updatable=false)
	private CircleEntity circle;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public String getSkin() {
		return skin;
	}

	public void setSkin(String skin) {
		this.skin = skin;
	}

	public String getDashboard() {
		return dashboard;
	}

	public void setDashboard(String dashboard) {
		this.dashboard = dashboard;
	}
	public CircleEntity getPubliccircle(){
		return circle;
	}
	public void setPubliccircle(CircleEntity val){
		circle=val;
	}
	public String getPrefix(){
		return prefix;
	}
	public void setPrefix(String val){
		prefix=val;
	}
	
	public List<ApplicationEntity> getApplications() {
		return applications;
	}

	public void setApplications(List<ApplicationEntity> applications) {
		this.applications = applications;
	}
}
