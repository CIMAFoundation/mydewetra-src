package it.acrotec.lib.settings.repositories;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.ApplicationWithConfigurationEntity;

public class ApplicationWithConfigurationRepository extends Repository<ApplicationWithConfigurationEntity> {

	private static final String USER_APPLICATION_QUERY = "select distinct a.id, a.descr, c.descr as configuration, h.descr as hat "
			+ "from settings.applications a "
			+ "inner join settings.configurations c on a.id=c.application "
			+ "inner join settings.hatsconfigurations hc on hc.configuration = c.id "
			+ "inner join settings.userhats uh on uh.hat = hc.hat "
			+ "inner join settings.hats h on h.id = uh.hat "
			+ "where uh.usr = :user";
	
	public ApplicationWithConfigurationRepository() {
		super("acroweb");
	}

	
	public List<ApplicationWithConfigurationEntity> getUserApplications(final String user) {
		
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery(USER_APPLICATION_QUERY);
				q.setString("user", user);
				q.addEntity(ApplicationWithConfigurationEntity.class);
				return q;
			}
		});
		
	}
	
	
//	public static void main(String[] args) {
//		List<ApplicationWithConfigurationEntity> list = new ApplicationWithConfigurationRepository().getUserApplications("doy");
//		System.out.println("ciao");
//	}
}
