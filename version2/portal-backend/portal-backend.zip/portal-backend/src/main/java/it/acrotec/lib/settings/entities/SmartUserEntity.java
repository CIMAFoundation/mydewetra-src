package it.acrotec.lib.settings.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="settings.users")
@XmlRootElement
public class SmartUserEntity {

	@Id
	@Column(name="id")
	private String id;
	
	@Column(name="name")
	private String name;

	@Column(name="email")
	private String email;

	@Column(name="phone")
	private String phone;
	
	@Transient
	private String avatar;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "domain")
	private DomainEntity domain;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "organization")
	private OrganizationEntity organization;
	
	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name="settings.userhats", joinColumns={@JoinColumn(name="usr", referencedColumnName="id")}, inverseJoinColumns={@JoinColumn(name="hat", referencedColumnName="id")})
	private List<HatEntity> hats;

	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name="settings.usercircles", joinColumns={@JoinColumn(name="usr", referencedColumnName="id")}, inverseJoinColumns={@JoinColumn(name="circle", referencedColumnName="id")})
	private List<CircleEntity> circles;
	
	@Column(name="emailnotification")
	private boolean emailnotification;
	
	@Column(name="phonenotification")
	private boolean phonenotification;
	
	public SmartUserEntity() {
	}

	public SmartUserEntity(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {		
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public DomainEntity getDomain() {
		return domain;
	}
	
	public void setDomain(DomainEntity domain) {
		this.domain = domain;
	}

	public OrganizationEntity getOrganization() {
		return organization;
	}

	public void setOrganization(OrganizationEntity organization) {
		this.organization = organization;
	}

	public List<HatEntity> getHats() {
		return hats;
	}

	public void setHats(List<HatEntity> hats) {
		this.hats = hats;
	}

	public List<CircleEntity> getCircles() {
		return circles;
	}

	public void setCircles(List<CircleEntity> circles) {
		this.circles = circles;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	
	public boolean getEmailnotification(){
		return emailnotification;
	}
	
	public void setEmailnotification(boolean val){
		emailnotification=val;
	}
	
	public boolean getPhonenotification(){
		return phonenotification;
	}
	
	public void setPhonenotification(boolean val){
		phonenotification=val;
	}
}
