package it.acrotec.rest.api;

import it.acrotec.lib.Acroweb;
import it.acrotec.rest.api.event.EventData;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Singleton;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.sse.EventOutput;
import org.glassfish.jersey.media.sse.OutboundEvent;
import org.glassfish.jersey.media.sse.SseBroadcaster;
import org.glassfish.jersey.media.sse.SseFeature;
import org.glassfish.jersey.server.BroadcasterListener;
import org.glassfish.jersey.server.ChunkedOutput;

@Singleton
@Path("event")
public class Event {
	
	/**
	 * event broadcasters map indexed on event source
	 */
	private static Map<String, SseBroadcaster> broadcasters = new HashMap<String, SseBroadcaster>();
	private static Map<String, EventOutput> evnts = new HashMap<String, EventOutput>();

	@GET
	@Path("{source}")
	@Produces(SseFeature.SERVER_SENT_EVENTS)
	public EventOutput hang(
			final @PathParam("source") String source) {		
		
//		final EventOutput eventOutput = new EventOutput();
//		SseBroadcaster b = getBroadcaster(source);   
//		Acroweb.info("added listener for source '" + source + "'", "EVENT");
//		b.add(eventOutput);

//		return eventOutput;
		return  null;
	}
	
	@GET
	@Path("{source}/{uid}")
	@Produces(SseFeature.SERVER_SENT_EVENTS)
	public EventOutput hanguid(
			final @PathParam("source") String source,
			final @PathParam("uid") String uid) {		
		
		final EventOutput eventOutput = new EventOutput();
		SseBroadcaster b = getBroadcaster(source);   
		Acroweb.info("added listener for source '" + source + "' id: "+uid, "EVENT");
		b.add(eventOutput);
		evnts.put(uid, eventOutput);
		System.out.println("#connections: "+evnts.size());
		return eventOutput;
	}
	
	@POST
	@Path("close/{source}/{uid}")
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML,MediaType.TEXT_PLAIN})
	@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_XML,MediaType.TEXT_PLAIN})
	public Response closeEvents(final @PathParam("source") String source,
			final @PathParam("uid") String uid){
		Acroweb.info("Close connection. id: "+uid+" source: "+source,"EVENT");
		if (evnts.get(uid)!=null){
				try {
					evnts.get(uid).close();
					//provo a non rimuovere
//					SseBroadcaster b = getBroadcaster(source);
//					b.remove(evnts.get(uid)); 
					evnts.remove(uid);
				} catch (IOException e) {
					Acroweb.error("Errore durante la chiusura della connessione "+uid, "EVENT", e);
					e.printStackTrace();
				}
		} else Acroweb.info("Connection not found id: "+uid, "EVENT");
		System.out.println("#connections: "+evnts.size());
		return Response.ok("ok").build();
	}
	
	
	@POST
	@Path("{source}")
	@Produces(MediaType.TEXT_PLAIN)
    @Consumes(MediaType.APPLICATION_JSON)
    public void trigger(
			@Context HttpServletResponse response,
			@Context HttpServletRequest request,
			final @PathParam("source") String source,
			String message) {
		
		request.setAttribute("org.apache.catalina.ASYNC_SUPPORTED", true);
		
		dispatch(new EventData(source, message));
    }

	
	/**
	 * event dispatcher
	 * @param data
	 */
	public static void dispatch(EventData data) {
		OutboundEvent.Builder eventBuilder = new OutboundEvent.Builder();
		eventBuilder.mediaType(MediaType.APPLICATION_JSON_TYPE);
        eventBuilder.data(EventData.class, data);
        OutboundEvent event = eventBuilder.build();
 
        SseBroadcaster b = getBroadcaster(data.getSource());  
        
        Acroweb.info("sending '" + data.getMessage() + "' for source '" + data.getSource() + "'", "EVENT");
        b.broadcast(event);
	}


	private static SseBroadcaster getBroadcaster(String source) {
		SseBroadcaster b = broadcasters.get(source);
		
		if (b==null) {
			b = new SseBroadcaster();
			b.add(new BroadcasterListener<OutboundEvent>() {
				
				@Override
				public void onException(ChunkedOutput<OutboundEvent> chunkedOutput, Exception exception) {
					Acroweb.warning("exception in event broadcaster: " + exception.getMessage(), "EVENT");
					try {
						chunkedOutput.close();
					} catch (IOException e) {
						Acroweb.warning("exception closing : " + exception.getMessage(), "EVENT");
					}
				}
				
				@Override
				public void onClose(ChunkedOutput<OutboundEvent> chunkedOutput) {
					Acroweb.info("listener closed", "EVENT");
				}
			});
			broadcasters.put(source, b);
		}
		return b;
	}

}
