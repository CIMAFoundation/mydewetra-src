package it.acrotec.lib.settings.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="settings.circles")
@XmlRootElement
public class CircleEntity implements Comparable<CircleEntity>{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="descr")
	private String descr;
	
	@Column(name="parent")
	private Integer parent;
	
	@Column(name="hierarchical")
	private Boolean hierarchical;

	public CircleEntity() {
	}
	
	public CircleEntity(String descr) {
		super();
		this.descr = descr;
	}
	
	public CircleEntity(int id, String descr) {
		super();
		this.id = id;
		this.descr = descr;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}
	
	public Integer getParent() {
		return parent;
	}

	public void setParent(Integer parent) {
		this.parent = parent;
	}
	
	public void setHierarchical(Boolean val){
		this.hierarchical=val;
	}
	public Boolean getHierarchical(){
		return this.hierarchical;
	}

	@Override
	public String toString() {
		return getDescr();
	}

	@Override
	public int compareTo(CircleEntity arg0) {
		return id-arg0.getId();
	}
	
}
