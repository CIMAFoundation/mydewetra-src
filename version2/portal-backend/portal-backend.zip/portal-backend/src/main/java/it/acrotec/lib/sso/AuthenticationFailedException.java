package it.acrotec.lib.sso;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


public class AuthenticationFailedException extends WebApplicationException {

	private static final long serialVersionUID = 3463834741945848465L;

	public AuthenticationFailedException() {
		super(Response.status(Status.UNAUTHORIZED).entity("authentication failed").type(MediaType.TEXT_PLAIN).build());
	}

	public AuthenticationFailedException(String message) {
		super(message, Response.status(Status.UNAUTHORIZED).entity("authentication failed: " + message).type(MediaType.TEXT_PLAIN).build());
	}

}
