package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.CircleEntity;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

public class CircleRepository extends Repository<CircleEntity> {

	private static final String PARENTS_BASE_QUERY = 
			"with recursive tmp(id, descr, parent,hierarchical) as ( " +
			"select C.id, C.descr, C.parent,C.hierarchical from settings.circles C where C.id = :circle " + 
			"union " +
			"select C.id, C.descr, C.parent, C.hierarchical from settings.circles C, tmp P where P.parent = C.id) ";
	
	private static final String CHILDS_BASE_QUERY = 
			"with recursive tmp(id, descr, parent,hierarchical) as ( " +
			"select C.id, C.descr, C.parent,C.hierarchical from settings.circles C where C.id = :circle " + 
			"union " +
			"select C.id, C.descr, C.parent,C.hierarchical from settings.circles C, tmp P where P.id = C.parent) ";

	public CircleRepository() {
		super("acroweb");
	}
	
	public List<CircleEntity> getParents(final int circleId) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery(PARENTS_BASE_QUERY + " select id, descr, parent,hierarchical from tmp");
				q.setInteger("circle", circleId);
				q.addEntity(CircleEntity.class);
				return q;
			}
		});
	}
	
	public List<CircleEntity> getChilds(final int circleId) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery(CHILDS_BASE_QUERY + " select id, descr,parent,hierarchical from tmp");
				q.setInteger("circle", circleId);
				q.addEntity(CircleEntity.class);
				return q;
			}
		});
	}
	
//	public List<CircleEntityWithParent> getCirclesWithParent() {
//		List list = doQuery(new QueryBuilder() {
//			@Override
//			public Query build(Session s) {
//				SQLQuery q = s.createSQLQuery("select id, descr, parent from settings.circles");
//				q.addEntity(CircleEntityWithParent.class);
//				return q;
//			}
//		});
//		return (List<CircleEntityWithParent>)list;
//	}
	
	
//	private static class CircleTree {
//		private CircleEntity circle;
//		private List<CircleTree> childs = new ArrayList<CircleRepository.CircleTree>();
//		public CircleTree(CircleEntityWithParent circle) {
//			super();
//			this.circle = new CircleEntity(circle.getId(), circle.getDescr());
//		}
//		public CircleEntity getCircle() {
//			return circle;
//		}
//		public void setCircle(CircleEntity circle) {
//			this.circle = circle;
//		}
//		public List<CircleTree> getChilds() {
//			return childs;
//		}
//		public void setChilds(List<CircleTree> childs) {
//			this.childs = childs;
//		}
//		@Override
//		public String toString() {
//			return circle.toString();
//		}
//	}
//	
//	
//	private static CircleTree buildTree(CircleTree tree, List<CircleEntityWithParent> list, int i, boolean[] done) {
//
//		CircleEntityWithParent current = list.get(i);
//		if (tree==null) {
//			tree = new CircleTree(current);
//			done[i] = true;
//		}
//		
//		System.out.println("esploro " + current.getDescr() + " con l'albero " + tree.getCircle().getDescr());
//		
//		CircleTree parent = null;
//		int parentIndex = 0;
//		for (int j = 0; j < list.size(); j++) {
//			if (done[j]) continue;
//			CircleEntityWithParent cp = list.get(j);
//			CircleTree newTree = new CircleTree(cp);
//			if (cp.getParent()!=null && cp.getParent()==current.getId()) {
//				done[j] = true;
//				//ho trovato un figlio diretto
//				tree.childs.add(buildTree(newTree, list, j, done));
//			}
//			if (current.getParent()!=null && current.getParent() == cp.getId()) {
//				//ho trovato il padre
//				parent = newTree;
//				parentIndex = j;
//				done[j] = true;
//			}
//		}
//		if (parent!=null) {
//			parent.childs.add(tree);
//			return buildTree(parent, list, parentIndex, done);
//		}
//		return tree;
//	}
//	
//	
//	public static void main(String[] args) {
//		
//		List<CircleEntityWithParent> circles = new CircleRepository().getCirclesWithParent();
//		
//		boolean[] done = new boolean[circles.size()];
//		Arrays.fill(done, false);
//		
//		ArrayList<CircleTree> trees = new ArrayList<CircleRepository.CircleTree>();
//		
//		boolean allDones = false;
//		while (!allDones) {
//			allDones = true;
//			for (int i = 0; i < done.length; i++) {
//				if (!done[i]) {
//					trees.add(buildTree(null, circles, i, done));
//				}
//			}
//		}
//		
//		System.out.println();
//	}

}
