package it.acrotec.lib.settings.repositories;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.hibernate.Repository.QueryBuilder;
import it.acrotec.lib.settings.entities.HatEntity;
import it.acrotec.lib.settings.entities.SmartHatEntity;

public class SmartHatRepository extends Repository<SmartHatEntity> {

	public SmartHatRepository() {
		super("acroweb");
	}
	
	
	/**
	 * search for all hats of a specific domain
	 * @param domainId
	 * @return
	 */
	public List<SmartHatEntity> getDomainHats(final int domainId) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				Query q = s.createQuery("from SmartHatEntity where domain = :domain");
				q.setInteger("domain", domainId);
				return q;
			}
		});
	}
	
	
	public static void main(String[] args) {
		List<SmartHatEntity> l = new SmartHatRepository().getDomainHats(5);
		
		
		System.out.println("ciao");
	}
		
}
