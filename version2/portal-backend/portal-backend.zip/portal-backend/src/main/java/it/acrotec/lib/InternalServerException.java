package it.acrotec.lib;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

/**
 * generic exception of type "internal server error"
 * @author doy
 *
 */
public class InternalServerException extends WebApplicationException {

	private static final long serialVersionUID = -1117511389402920260L;

	public InternalServerException(String msg) {
		super(Response.status(Status.INTERNAL_SERVER_ERROR).entity(msg).type(MediaType.TEXT_PLAIN).build());
	}

}
