package it.acrotec.rest.api;

import it.acrotec.lib.Acroweb;
import it.acrotec.lib.sso.InvalidTokenException;

import java.io.IOException;
import java.util.List;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.PreMatching;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.ext.Provider;

import org.glassfish.jersey.server.ContainerRequest;

@Provider
@PreMatching
public class AuthRequestFilter implements ContainerRequestFilter {

	private static String urlToPass[] = {
		"/event/.*",
		"/views/.*",
		"/auth/login",
		"/portal/port",
		"/kumale/sendPostParam",	//temporaneo
		"/kumale/sendCommentParam",	//temporaneo
		"/kumale/offlineposts",
		"/kumale/image/.*",
		"/kumale/send/mail",
		"/defconregione/lastbulletin",
		"/defcon/getMaxCityAlarm",
		"/eyes/stations",
		"/eyes/station/.*",
		"/eyes/stationsdata/.*",
		"/eyes/networkstations/.*",
		"/admin/servertime",
		"/admin/version",
		"/creasylistener/connect",
		"/sseevent/connect",
		"/allertaliguria/download/.*",
		"/allertaliguria/last",
		"/registrazione/.*",
		"/acrogest/image/.*",
		"/acrogest/doc/.*",
		"/acrogest/public/.*",
		"/acrogest/download/.*",
		"/logbook/statistics/.*",
		"/registration/.*",
		"/allertaliguria/synchComunication/.*",
		"/allertaliguria/arpal/fenomeni",
		"/stations/configuration/read/.*",
		"/acronet/.*",
		"/people/image/.*",
		"/people/download/.*",
		"/people/tracking/.*",
		"/people/public/.*",
		"/bot/incoming/.*"
		//,"/floodcat/.*"
		
	};
	
	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		
		ContainerRequest req = (ContainerRequest)requestContext.getRequest();
		
		String path = req.getPath(true);
		boolean bypass = false;
		for (String check : urlToPass) {
			if (path.matches(check)) {
				bypass = true;
				break;
			}
		}
		
		if (!bypass) {
			
			MultivaluedMap<String, String> parameters = req.getUriInfo().getQueryParameters();
			
			List<String> l = parameters.get(Acroweb.AUTH_TOKEN_PARAMETER);		
			if (l!=null && !l.isEmpty()) {
				String token = l.get(0);

				String uid = Acroweb.auth().verifySessionToken(token);
				int hat = Acroweb.auth().getCurrentHat(token);
				
				UriBuilder ub = UriBuilder.fromUri(req.getRequestUri());
				ub.queryParam(Acroweb.UID_TOKEN_PARAMETER, uid);
				ub.queryParam(Acroweb.HAT_TOKEN_PARAMETER, hat);
				
				req.setRequestUri(ub.build());
				
			} else {
				
				Acroweb.info("rifiutata richiesta (token non specificato)" + req.getRequestUri(), "acroweb");
				throw new InvalidTokenException();
			}
			
		}
		
	}

}
