package it.acrotec.lib.sso;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import it.acrotec.lib.Acroweb;

public abstract class SSO {

	
	public static SSO instantiate(File propFile) {		
		try {
			
			Properties prop = new Properties();
			prop.load(new FileInputStream(propFile));
			String component = prop.getProperty("sso.component");
			Object obj = Class.forName(component).newInstance();
			if (obj instanceof SSO) {
				SSO sso = (SSO) obj;
				sso.setProperties(prop);
				return sso;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public abstract void setProperties(Properties prop);
	
	/**
	 * authenticate a user
	 * @param uid user id
	 * @param pwd password
	 * @return authentication token
	 * @throws AuthenticationFailedException
	 */
	public abstract String authenticate(String uid, String pwd) throws AuthenticationFailedException;

	/**
	 * check the validity of a session and returnn the user id owner of the session
	 * @param token
	 * @return
	 */
	public abstract String checkToken(String token);

	/**
	 * do logout of an authenticated token
	 * @param token
	 * @throws InvalidTokenException
	 */
	public abstract void logout(String token) throws InvalidTokenException;

	/**
	 * check if user exists
	 * @param uid
	 * @return
	 */
	public abstract boolean existsUser(String uid);

	/**
	 * creates a new user
	 * @param uid
	 * @param name
	 * @param password
	 * @throws InvalidTokenException
	 */
	public abstract void createUser(String uid, String name, String password) throws InvalidTokenException;

	/**
	 * sets password for a user
	 * @param uid
	 * @param password
	 * @throws InvalidTokenException
	 */
	public abstract void setPassword(String uid, String password) throws InvalidTokenException;

	/**
	 * removes a user
	 * @param uid
	 * @throws InvalidTokenException
	 */
	public abstract void removeUser(String uid) throws InvalidTokenException;

}