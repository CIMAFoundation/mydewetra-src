package it.acrotec.lib.settings.repositories;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.HatConfigurationEntity;

public class HatConfigurationRepository extends Repository<HatConfigurationEntity> {

	public HatConfigurationRepository() {
		super("acroweb");
	}
	
	public List<HatConfigurationEntity> getConfigurationHat(final int conf) {
		List<HatConfigurationEntity> lstHats = selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				Query q = s.createQuery("from HatConfigurationEntity where configuration = :conf");
				q.setInteger("conf", conf);
				return q;
			}
		});		
		return lstHats;
	}
	

}
