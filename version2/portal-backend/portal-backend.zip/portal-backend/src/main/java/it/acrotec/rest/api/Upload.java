package it.acrotec.rest.api;

import it.acrotec.lib.Acroweb;
import it.acrotec.lib.InternalServerException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

@Singleton
@Path("upload")
public class Upload {
	
	private static File avatarDirectory = null;
	
	private static String avatarBaseUrl = "";
	
	static {
		try {
			Properties props = new Properties();
			props.load(Upload.class.getResourceAsStream("/uploads.properties"));
			
			avatarDirectory = new File(props.getProperty("avatarlocation"));
			if (!avatarDirectory.exists()) {
				if (!avatarDirectory.mkdirs()) throw new IOException("cannot create directory " + avatarDirectory.getAbsolutePath());
			} else {
				if (!avatarDirectory.isDirectory()) throw new IOException("invalid directory " + avatarDirectory.getAbsolutePath());
			}
			
			avatarBaseUrl = props.getProperty("avatarbaseurl", "");
			
		} catch (IOException e) {
			Acroweb.error("cannot initializa uploads", "portal", e);
		}
		
	}
	

	@POST
	@Path("avatar/{user}")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
    public void avatar(
			final @PathParam("user") String userId,
            @FormDataParam("file") InputStream fileInputStream,
            @FormDataParam("file") FormDataContentDisposition contentDispositionHeader) {
		
			
		if (avatarDirectory==null) throw new InternalServerException("invalid upload directory");
		
		File dst = new File(avatarDirectory, userId);
		saveFile(fileInputStream, dst);
		
		Acroweb.info("uploaded avatar for user " + userId + ": " + dst.getAbsolutePath(), "portal");
		
    }

	/**
	 * writes uploaded strean to a file
	 * @param inStream
	 * @param dst
	 * @return
	 */
	private boolean saveFile(InputStream inStream, File dst) {
		try {
			OutputStream outStream = new FileOutputStream(dst);
			int read = 0;
			byte[] bytes = new byte[1024];
			while ((read = inStream.read(bytes)) != -1) {
				outStream.write(bytes, 0, read);
			}
			outStream.flush();
			outStream.close();
			return true;
		} catch (IOException e) {
			Acroweb.error("cannot save file", "portal", e);
		}
		return false;
	}

	
	public static String getAvatarBaseUrl() {
		return avatarBaseUrl;
	}
	public static String getAvatarPath(String userid){
		File dst = new File(avatarDirectory, userid);
		if (dst.exists())
			return avatarBaseUrl+userid;
		return avatarBaseUrl+"userdefault";
	}
}
