package it.acrotec.lib.hibernate;

import it.acrotec.lib.Acroweb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.LockOptions;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


public class Repository<T> {
	
	public static interface QueryBuilder {
		public Query build(Session s);
	}
	
	
	protected String connectionName;

	public Repository(String connectionName) {
		this.connectionName = connectionName;
	}

	
	public List<T> selectByQuery(QueryBuilder builder) {
		Session s = null;

		List<T> result = new ArrayList<T>();

		try {
			s = getSessionFactory().openSession();
			s.beginTransaction();
			Query query = builder.build(s);
			result = query.list();
			s.getTransaction().commit();			
		}
		catch(Throwable e) {
			System.err.println(e.toString());
			e.printStackTrace();
			
			// P.Campanella 22/01/2015: added rollback in case of exception
			if (s!=null)
			{
				if (s.getTransaction()!=null) {
					try {
						s.getTransaction().rollback();
					}
					catch(Throwable e2) {
						Acroweb.error("error rolling back transaction", "acroweb", e2);					
					}					
				}
			}
		}
		finally {
			if (s!=null) s.close();
		}

		return result;
	}
	
	public List<T> selectAll(final Class<T> c) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				return s.createQuery("from " + c.getSimpleName());
			}
		});
	}
	
	public T select(Serializable id, Class<T> cl) {

		Session session = null;

		T entity = null;

		try {				
			session = getSessionFactory().openSession();
			session.beginTransaction();
			entity = (T) session.load(cl, id, LockOptions.UPGRADE);
			session.getTransaction().commit();
		} catch (ObjectNotFoundException e) {
		} catch(Throwable e) {
			Acroweb.error("error selecting entity", "acroweb", e);
			if (session!=null)  {
				try {
					session.getTransaction().rollback();
				}
				catch(Throwable e2) {
					Acroweb.error("error rolling back transaction", "acroweb", e2);					
				}
			}
		}		
		finally {
			if (session!=null) session.close();
		}

		return entity;
	}

	public boolean executeUpdate(QueryBuilder builder) {
		Session s = null;

		try {
			s = getSessionFactory().openSession();
			s.beginTransaction();
			Query query = builder.build(s);
			query.executeUpdate();
			s.getTransaction().commit();
			return true;
		}
		catch(Throwable e) {
			System.err.println(e.toString());
			e.printStackTrace();
			
			// P.Campanella 22/01/2015: added rollback in case of exception
			if (s!=null)
			{
				if (s.getTransaction()!=null) {
					try {
						s.getTransaction().rollback();
					}
					catch(Throwable e2) {
						Acroweb.error("error rolling back transaction", "acroweb", e2);					
					}					
				}
			}			
		}
		finally {
			if (s!=null) s.close();
		}
		return false;
	}
	
	public boolean save(T entity) {
		Session oSession = null;
		try {
			oSession = getSessionFactory().openSession();
			oSession.beginTransaction();
			oSession.saveOrUpdate(entity);
			oSession.getTransaction().commit();
			return true;
		}
		catch(Throwable oEx) {
			System.err.println(oEx.toString());
			oEx.printStackTrace();

			try {
				oSession.getTransaction().rollback();
			}
			catch(Throwable oEx2) {
				System.err.println(oEx2.toString());
				oEx2.printStackTrace();					
			}

			return false;
		}
		finally {
			if (oSession!=null)  oSession.close();
		}

	}
	
	public boolean insert(T entity) {
		Session oSession = null;
		try {
			oSession = getSessionFactory().openSession();
			oSession.beginTransaction();
			oSession.save(entity);
			oSession.getTransaction().commit();
			return true;
		}
		catch(Throwable oEx) {
			System.err.println(oEx.toString());
			oEx.printStackTrace();

			try {
				oSession.getTransaction().rollback();
			}
			catch(Throwable oEx2) {
				System.err.println(oEx2.toString());
				oEx2.printStackTrace();					
			}

			return false;
		}
		finally {
			if (oSession!=null)  oSession.close();
		}

	}

	public boolean update(T entity) {
		Session oSession = null;
		try {
			oSession = getSessionFactory().openSession();
			oSession.beginTransaction();
			oSession.update(entity);
			oSession.getTransaction().commit();
			return true;
		}
		catch(Throwable oEx) {
			System.err.println(oEx.toString());
			oEx.printStackTrace();

			try {
				oSession.getTransaction().rollback();
			}
			catch(Throwable oEx2) {
				System.err.println(oEx2.toString());
				oEx2.printStackTrace();					
			}

			return false;
		}
		finally {
			if (oSession!=null)  oSession.close();
		}

	}
	
	public boolean delete(T entity) {
		Session oSession = null;
		try {
			oSession = getSessionFactory().openSession();
			oSession.beginTransaction();
			oSession.delete(entity);
			oSession.getTransaction().commit();
			return true;
		}
		catch(Throwable oEx) {
			System.err.println(oEx.toString());
			oEx.printStackTrace();

			try {
				oSession.getTransaction().rollback();
			}
			catch(Throwable oEx2) {
				System.err.println(oEx2.toString());
				oEx2.printStackTrace();					
			}

			return false;
		}
		finally {
			if (oSession!=null)  oSession.close();
		}

	}
	
	public int getNumTotalRecords(QueryBuilder builder) {
		Session s = null;

		int result = 0;

		try {
			s = getSessionFactory().openSession();
			s.beginTransaction();
			Query query = builder.build(s);
			result = ((Long) query.uniqueResult()).intValue();
			s.getTransaction().commit();			
		}
		catch(Throwable e) {
			System.err.println(e.toString());
			e.printStackTrace();
			
			// P.Campanella 22/01/2015: added rollback in case of exception
			if (s!=null)
			{
				if (s.getTransaction()!=null) {
					try {
						s.getTransaction().rollback();
					}
					catch(Throwable e2) {
						Acroweb.error("error rolling back transaction", "acroweb", e2);					
					}					
				}
			}			
		}
		finally {
			if (s!=null) s.close();
		}

		return result;
	}
	
	public List doQuery(QueryBuilder manager) {
		Session s = null;
		try {
			s = getSessionFactory().openSession();
			s.beginTransaction();
			Query query = manager.build(s);
			List result = query.list();
			s.getTransaction().commit();		
			return result;
		}
		catch(Throwable e) {
			System.err.println(e.toString());
			e.printStackTrace();
			
			// P.Campanella 22/01/2015: added rollback in case of exception
			if (s != null)  
			{
				if (s.getTransaction()!=null) {
					try {
						s.getTransaction().rollback();
					}
					catch(Throwable e2) {
						Acroweb.error("error rolling back transaction", "acroweb", e2);					
					}					
				}
			}			
		}
		finally {
			if (s!=null) s.close();
		}
		return new ArrayList();
	}
	
	
	protected SessionFactory getSessionFactory() {
		
		return HibernateUtils.getSessionFactory(connectionName);
		
	} 
	

}
