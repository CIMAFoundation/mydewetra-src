package it.acrotec.lib.logbook.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.logbook.entities.LogbookSession;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;

public class LogbookSessionRepository extends Repository<LogbookSession> {

	public LogbookSessionRepository() {
		super("acroweb");
	}

	public List<LogbookSession> getSessions(final int from, final int to, final int domainId) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(org.hibernate.Session s) {
				String query = "from LogbookSession where date between :from and :to ";
				if (domainId>=0) query += "and domainId = :domain ";
				query += "order by date desc";
				Query q = s.createQuery(query);
				q.setInteger("from", from);
				q.setInteger("to", to);
				if (domainId>=0) q.setInteger("domain", domainId);
				return q;
			}
		});
	}
}
