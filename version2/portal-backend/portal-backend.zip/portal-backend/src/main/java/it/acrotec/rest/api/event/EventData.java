package it.acrotec.rest.api.event;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EventData {

	private long time;
	
	private String source;
	
	private String message;
	
	public EventData() {
		// TODO Auto-generated constructor stub
	}
	
	public EventData(String source, String message) {
		super();
		this.source = source;
		this.message = message;
		this.time = System.currentTimeMillis();
	}
	
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	
}
