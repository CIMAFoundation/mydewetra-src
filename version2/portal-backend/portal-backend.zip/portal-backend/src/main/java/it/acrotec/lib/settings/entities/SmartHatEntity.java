package it.acrotec.lib.settings.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="settings.hats")
@XmlRootElement
public class SmartHatEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="descr")
	private String descr;
	
	@Column(name="domain")
	private int domainId;	
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "domain", insertable=false, updatable=false)
	private SmartDomainEntity domain;
	
	public SmartHatEntity() {
	}

	public SmartHatEntity(String descr, int domainId) {
		super();
		this.descr = descr;
		this.domainId = domainId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public SmartDomainEntity getDomain() {
		return domain;
	}

	public void setDomain(SmartDomainEntity domain) {
		this.domain = domain;
	}

	public int getDomainId() {
		return domainId;
	}

	public void setDomainId(int domainId) {
		this.domainId = domainId;
	}

}
