package it.acrotec.lib;

import it.acrotec.lib.settings.entities.HatEntity;
import it.acrotec.lib.settings.entities.SmartUserEntity;
import it.acrotec.lib.settings.repositories.SmartUserRepository;
import it.acrotec.lib.sso.AuthenticationFailedException;
import it.acrotec.lib.sso.SSO;
import it.acrotec.lib.sso.InvalidTokenException;
import it.acrotec.rest.api.Upload;

import java.util.List;

/**
 * authentication halper class
 * @author doy
 *
 */
public class Auth {

	/**
	 * sso client for authentication
	 */
	private SSO sso;

	public Auth(SSO sso) {
		super();
		this.sso = sso;
	}
	
	/**
	 * authenticate a user and return his session token
	 * @param uid
	 * @param password
	 * @return
	 */
	public String authenticate(String uid, String password) {
		//authenticate in sso
		String ssoToken = sso.authenticate(uid, password);
		//retrieve the default hat
		List<HatEntity> hats = getUserData(uid).getHats();
		int hatId = 0;
		if ((hats != null) && !hats.isEmpty()) hatId = hats.get(0).getId(); 
		ssoToken += ";" + hatId;
		return ssoToken;
	}

	/**
	 * close a user session
	 * @param token
	 * @throws InvalidTokenException
	 */
	public void logout(String token) throws InvalidTokenException {
		sso.logout(token);
	}

	/**
	 * tries to obtain the uer id associated with the authentication token
	 * @param token
	 * @return
	 */
	public String verifySessionToken(String token) {		
		String[] toks = splitToken(token);
		return sso.checkToken(toks[0]);
	}
	
	/**
	 * retrieves the current hat from the token
	 * @param token
	 * @return
	 */
	public int getCurrentHat(String token) {
		String[] toks = splitToken(token);
		return Integer.parseInt(toks[1]);
	}

	/**
	 * remove a user
	 * @param uid
	 */
	public void removeUser(String uid) {
		sso.removeUser(uid);
	}
	
	/**
	 * add a new user
	 * @param uid
	 * @param name
	 * @param password
	 */
	public void createUser(String uid, String name, String password)  throws InvalidTokenException {
		sso.createUser(uid, name, password);
	}

	/**
	 * check if user exists
	 * @param id
	 * @return
	 */
	public boolean existsUser(String uid) {
		return sso.existsUser(uid);
	}

	/**
	 * obtail user data
	 * @param uid
	 * @return
	 */
	public SmartUserEntity getUserData(String uid) {
		SmartUserEntity e = new SmartUserRepository().select(uid, SmartUserEntity.class);
		//e.setAvatar(Upload.getAvatarBaseUrl() + uid);
		e.setAvatar(Upload.getAvatarPath(uid));
		return e;
	}

	/**
	 * sets a user password
	 * @param uid
	 * @param password
	 * @throws InvalidTokenException
	 */
	public void setPassword(String uid, String password) throws InvalidTokenException {
		sso.setPassword(uid, password);
	}

	public String[] splitToken(String token) {
		if (token==null || token.isEmpty()) throw new InvalidTokenException();
		String toks[] = token.split(";");
		if (toks.length != 2) throw new InvalidTokenException();
		return toks;
	}


}
