package it.acrotec.lib.hibernate;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtils {
	
	public static Map<String, SessionFactory> factories = new HashMap<String, SessionFactory>();
	
	
	private static SessionFactory buildSessionFactory(String connectionName) {
		
		try {
			// Create the SessionFactory from hibernate.cfg.xml
			Configuration conf = new  Configuration().configure("hibernate." + connectionName + ".cfg.xml");			
			return conf.buildSessionFactory();
		} catch (Throwable ex) {
			// Make sure you log the exception, as it might be swallowed
			ex.printStackTrace();
			throw new ExceptionInInitializerError(ex);
		}
		
	}
	
	
	public static SessionFactory getSessionFactory(String connectionName) {
		
		SessionFactory factory = factories.get(connectionName);
		if (factory == null) {
			factory = buildSessionFactory(connectionName);
			factories.put(connectionName, factory);
		}
		
		return factory;
		
	}
 
	public static void shutdown() {
		// Close caches and connection pools
		for (SessionFactory f : factories.values()) {
			f.close();	
		}
		factories.clear();
	}
	
	
}
