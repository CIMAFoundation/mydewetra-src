package it.acrotec.lib.settings.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="settings.userhats")
@XmlRootElement
public class UserHatEntity implements Serializable {

	private static final long serialVersionUID = 5590986247366059751L;

	@Id 
	@Column(name="usr")
	String user;

	@Id
	@Column(name="hat")
	private int hat;
	
	public UserHatEntity() {
	}
	
	public UserHatEntity(String user, int hat) {
		super();
		this.user = user;
		this.hat = hat;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public int getHat() {
		return hat;
	}

	public void setHat(int hat) {
		this.hat = hat;
	}
}
