package it.acrotec.lib.settings.repositories;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.DomainEntity;

public class DomainRepository extends Repository<DomainEntity> {

	
	public DomainRepository() {
		super("acroweb");
	}
	
	
	public List<DomainEntity> getMyDomains(final String userId) {

		return selectByQuery(new QueryBuilder() {

			@Override
			public Query build(Session s) {

				SQLQuery q = s.createSQLQuery(
						"select settings.domains.* from settings.domains " + 
						"inner join settings.userhats on settings.domains.masterhat = settings.userhats.hat " + 
						"and settings.userhats.usr = :userId");

				q.addEntity(DomainEntity.class);
				q.setString("userId", userId);

				return q;

			}

		});	

	}
	

	public Map<Integer, Integer> getMasterCircles() {
		List rs = doQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery("select distinct settings.domains.circle, settings.domains.id from settings.domains");
				return q;
			}
		});
		Map<Integer, Integer> m = new HashMap<Integer, Integer>();
		for (Object[] a : (List<Object[]>)rs) {
			m.put((int)a[0], (int)a[1]);
		}		
		return m;		
	}	

	public Map<Integer, Integer> getMasterHats() {
		List rs = doQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery("select distinct settings.domains.masterhat, settings.domains.id from settings.domains");
				return q;
			}
		});
		Map<Integer, Integer> m = new HashMap<Integer, Integer>();
		for (Object[] a : (List<Object[]>)rs) {
			m.put((int)a[0], (int)a[1]);
		}		
		return m;	
	}
	
	
	public static void main(String[] args) {
		new DomainRepository().getMasterCircles();
	}
}



