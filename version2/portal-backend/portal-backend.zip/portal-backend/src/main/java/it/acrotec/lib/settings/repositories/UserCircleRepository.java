package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.UserCircleEntity;

public class UserCircleRepository extends Repository<UserCircleEntity> {

	public UserCircleRepository() {
		super("acroweb");
	}

}
