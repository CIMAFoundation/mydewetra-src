package it.acrotec.lib.logbook.entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="logbook.sessions")
@XmlRootElement
public class Session {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	int id;
	
	@Column(name="usr")
	String user;

	@Column(name="token")
	String token;
	
	@Column(name="client_ip")
	String clientIP;
	
	@Column(name="skin")
	String skin;
	
	@Column(name="hat")
	int hat;
	
	@Column(name="date", insertable=false)
	Date date;
	
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name="session")
	List<Activity> activities = new ArrayList<Activity>();

	
	public Session() {
		
	}	
	
	public Session(String user, String token, String ip, String skin, int hat) {
		super();
		this.user = user;
		this.token = token;
		this.clientIP = ip;
		this.skin = skin;
		this.hat = hat;
	}
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getClientIP() {
		return clientIP;
	}

	public void setClientIP(String clientIP) {
		this.clientIP = clientIP;
	}

	public String getSkin() {
		return skin;
	}

	public void setSkin(String skin) {
		this.skin = skin;
	}

	public int getHat() {
		return hat;
	}

	public void setHat(int hat) {
		this.hat = hat;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public List<Activity> getActivities() {
		return activities;
	}

}
