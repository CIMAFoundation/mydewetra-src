package it.acrotec.lib.settings.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="settings.hatsconfigurations")
@XmlRootElement
public class HatConfigurationEntity implements Serializable {

	private static final long serialVersionUID = 5590986247366059751L;

	@Id 
	@Column(name="hat")
	private int hat;

	@Id
	@Column(name="configuration")
	private int configuration;

	public HatConfigurationEntity() {
	}

	public HatConfigurationEntity(int hat, int configuration) {
		super();
		this.hat = hat;
		this.configuration = configuration;
	}

	public int getHat() {
		return hat;
	}

	public void setHat(int hat) {
		this.hat = hat;
	}

	public int getConfiguration() {
		return configuration;
	}

	public void setConfiguration(int configuration) {
		this.configuration = configuration;
	}
	
}
