package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.SmartUserEntity;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

public class SmartUserRepository extends Repository<SmartUserEntity> {

	public SmartUserRepository() {
		super("acroweb");
	}

	public void removeUser(final String user) {
		executeUpdate(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				Query q = s.createQuery("delete users where user = :u");
				q.setString("u", user);
				return q;
			}
		});
	}
	
	public List<SmartUserEntity> getDomainUsers(final int domainId) {
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery("select distinct U.* from settings.users U inner join settings.userhats UH on U.id=UH.usr inner join settings.hats H on UH.hat=H.id where H.domain=:domain");
				q.setInteger("domain", domainId);
				q.addEntity(SmartUserEntity.class);
				return q;
			}
		});
	}

	public SmartUserEntity search(final String userName) {
		List<SmartUserEntity> l = selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery("select distinct U.* from settings.users U where U.name=:uname");
				q.setString("uname", userName);
				q.addEntity(SmartUserEntity.class);
				return q;
			}
		});
		
		return l.isEmpty() ? null: l.get(0);
	}
	
//	public static void main(String[] args) {
//		List<SmartUserEntity> l = new SmartUserRepository().getDomainUsers(5);
//		System.out.println();
//	}
}
