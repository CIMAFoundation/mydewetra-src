package it.acrotec.rest.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.inject.Singleton;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.sse.EventOutput;
import org.glassfish.jersey.media.sse.OutboundEvent;
import org.glassfish.jersey.media.sse.SseBroadcaster;
import org.glassfish.jersey.media.sse.SseFeature;


@Singleton
@Path("sseevent")
public class SSEEvent {
	private static long TIMEOUT_CONNECTION=300000;
	private static long TIMEOUT_CHECKCONNECTION=60000;
	private static boolean active=false;
	private static SseBroadcaster broadcaster = new SseBroadcaster();
	private static ArrayList<EventOutput> lst=new ArrayList<EventOutput>();
	private static HashMap<Integer,Long> tms=new HashMap<Integer,Long>();
	static{
		//usare scheduler
		Thread th = new Thread(new Runnable(){
			public void run() {
				while(true){
					try {
						checkconnections();
						Thread.sleep(TIMEOUT_CHECKCONNECTION);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
			}});
		if (active) th.start();
	}
	 
	 
	 
	 

	@GET
    @Path("connect")
    @Produces(SseFeature.SERVER_SENT_EVENTS)
    public EventOutput listenToBroadcast() {
    	if (active){
	    	System.out.println("SSE: connection from client!");
	        final EventOutput eventOutput = new EventOutput();
	        synchronized(lst){
		        lst.add(eventOutput);
	        }
	        tms.put(eventOutput.hashCode(),System.currentTimeMillis());
	        broadcaster.add(eventOutput);
	        return eventOutput;
    	} else return null;
			
    }
	
   public static void dispatchEvent(String receiver,String message){
    	if (active){
	    	try{
	    		System.out.println("SSE: dispatch event: "+receiver+"-"+message);
		    	 OutboundEvent.Builder eventBuilder = new OutboundEvent.Builder();
		         OutboundEvent event = eventBuilder.name("message")
		             .mediaType(MediaType.TEXT_PLAIN_TYPE)
		             .data(String.class, receiver+";"+message)
		             .build();
		         broadcaster.broadcast(event);
	    	}catch(Exception ex){
	    		System.out.println("SSE: Errore invio messaggio: "+ex.getMessage());
	    		ex.printStackTrace();
	    	}
    	} 
    }
	private synchronized static void checkconnections(){
		synchronized(lst){
			for (Iterator<EventOutput> iterator = lst.iterator(); iterator.hasNext();) {
				EventOutput itm = iterator.next();
			    if (itm.isClosed()){
			    	broadcaster.remove(itm);
			    	tms.remove(itm.hashCode());
			    	iterator.remove();
			    }else{
			    	long tme=System.currentTimeMillis()-tms.get(itm.hashCode());
		        	System.out.println("SSE: connection: "+Integer.toHexString(itm.hashCode())+" time: "+tme);
		        	try {
		        		if (tme>TIMEOUT_CONNECTION){
		        			System.out.println("\tchiudo");
		        			itm.close();
		        		}
					} catch (Exception e) {
						e.printStackTrace();
					}
			    }
			}
			System.out.println("SSE: active connection: "+lst.size());
		}
	}
}
