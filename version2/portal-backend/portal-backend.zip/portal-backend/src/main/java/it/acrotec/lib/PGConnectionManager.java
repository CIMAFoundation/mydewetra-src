package it.acrotec.lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.postgresql.ds.PGPoolingDataSource;

/**
 * classe per la gestione delle connessioni al DB postgres
 * @author doy
 *
 */
public class PGConnectionManager {
	
	/** numero di connessioni per pool*/
	public static int NumConnectionsPerPool = 2;	

	/**
	 * rappresenta la chiave per un pool di connessioni
	 * @author doy
	 */
	private static class PoolKey {
		String ip;
		String db;
		String user;
		String password;
		
		public PoolKey(String ip, String db, String user, String password) {
			if (ip==null || db==null || user==null || password==null) throw new IllegalArgumentException();
			this.ip = ip;
			this.db = db;
			this.user = user;
			this.password = password;
		}

		@Override
		public boolean equals(Object obj) {
			if (obj instanceof PoolKey) {
				PoolKey key = (PoolKey) obj;
				return key.ip.equals(ip) && key.db.equals(db) && key.user.equals(user) && key.password.equals(password);
			}
			return super.equals(obj);
		}
		
		@Override
		public int hashCode() {
			return (ip+db+user+password).hashCode();
		}
	}
	
	/**mappa di connection pool*/
	private static Map<PoolKey, PGPoolingDataSource> poolMap = new HashMap<PoolKey, PGPoolingDataSource>();
	
	
	public static Connection GetConnection(File propFile) throws SQLException, FileNotFoundException, IOException {
		Properties prop = new Properties();
		prop.load(new FileInputStream(propFile));
		return GetConnection(prop.getProperty("postgres.server"), prop.getProperty("postgres.database"), prop.getProperty("postgres.user"), prop.getProperty("postgres.password"));
	}
	
	
	public static Connection GetConnection(String ip, String db, String user, String password) throws SQLException {
		
		PoolKey key = new PoolKey(ip, db, user, password);
		PGPoolingDataSource ds = poolMap.get(key);
		if (ds == null) {
			ds = new PGPoolingDataSource();
	        ds.setDataSourceName(UUID.randomUUID().toString());
	        ds.setServerName(ip);
	        ds.setDatabaseName(db);
	        ds.setUser(user);
	        ds.setPassword(password);
	        ds.setMaxConnections(NumConnectionsPerPool);
	        poolMap.put(key, ds);
		}

		return ds.getConnection();
		
	}
	
	
}
