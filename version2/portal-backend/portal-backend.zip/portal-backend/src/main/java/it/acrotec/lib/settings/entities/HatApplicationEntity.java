package it.acrotec.lib.settings.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="settings.hatapplications")
@XmlRootElement
public class HatApplicationEntity {

	@Id
	@Column(name="id")
	private String id;

	@Column(name="hat")
	private int hat;
	
	@Column(name="descr")
	private String descr;
	
	public HatApplicationEntity() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}
	
}
