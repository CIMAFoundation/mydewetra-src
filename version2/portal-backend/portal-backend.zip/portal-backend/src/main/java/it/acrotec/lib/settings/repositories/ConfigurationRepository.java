package it.acrotec.lib.settings.repositories;

import it.acrotec.lib.hibernate.Repository;
import it.acrotec.lib.settings.entities.ConfigurationEntity;
import it.acrotec.lib.settings.entities.ConfigurationResourceEntity;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

public class ConfigurationRepository extends Repository<ConfigurationEntity> {

	public ConfigurationRepository() {
		super("acroweb");
	}
	
	
	public List<ConfigurationEntity> getHatConfigurations(final int hatId) {
		
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery(
						"select settings.configurations.* from settings.configurations "
						+ "inner join settings.hatsconfigurations on settings.configurations.id = settings.hatsconfigurations.configuration "
						+ "and settings.hatsconfigurations.hat = :hat");
				q.addEntity(ConfigurationEntity.class);
				q.setInteger("hat", hatId);
				return q;
			}
		});		
	}

	public List<ConfigurationEntity> getDomainConfigurations(final int domainId,final String app){
		
		return selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery(
						"select distinct c.* from settings.hats h "
						+ " left join settings.hatsconfigurations hc on hc.hat=h.id "
						+ " left join settings.configurations c on c.id=hc.configuration "
						+ " where h.domain= :domainid and c.application= :app ");
				q.addEntity(ConfigurationEntity.class);
				q.setInteger("domainid", domainId);
				q.setString("app",app);
				return q;
			}
		});		
		
	}
	
	public ConfigurationEntity getHatConfiguration(final int hatId, final String app) {
		
		List<ConfigurationEntity> l = selectByQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery(
						"select settings.configurations.* from settings.configurations "
						+ "inner join settings.hatsconfigurations on settings.configurations.id = settings.hatsconfigurations.configuration "
						+ "and settings.hatsconfigurations.hat = :hat and settings.configurations.application = :app");
				q.addEntity(ConfigurationEntity.class);
				q.setInteger("hat", hatId);
				q.setString("app", app);
				return q;
			}
		});
		
		if (l.isEmpty()) return null;
		
		return l.get(0);		
	}
	
	public String getConfigurationResourceValue(final String app, final String confName, final String resource) {
		
		List rs = doQuery(new QueryBuilder() {
			@Override
			public Query build(Session s) {
				SQLQuery q = s.createSQLQuery(
						"select settings.configurationresources.value from settings.configurations "
						+ "inner join settings.configurationresources on settings.configurations.id = settings.configurationresources.configuration "
						+ "and settings.configurationresources.resource = :res and settings.configurations.descr = :conf and settings.configurations.application = :app");
				q.setString("res", resource);
				q.setString("conf", confName);
				q.setString("app", app);
				return q;
			}
		});
		return rs.isEmpty() ? null : rs.get(0).toString();		
	}
	
	
	public static void main(String[] args) {
		System.out.println(new ConfigurationRepository().getConfigurationResourceValue("eyes", "app_configuration", "networks"));
	}
	
}
