from dewetra2.core.resources import DewetraResourceMeta
from dewetra2.models import TagStatistics
from acroweb.core.auth import whoAmI
from acroweb.core.resources import AcrowebResource, URLHelper


class TagStatisticsResource(AcrowebResource):
    
    class Meta(DewetraResourceMeta):
        resource_name = 'statistics'
        
    def getMyUrl(self):
        return [
                URLHelper('/tagsupdate', 'updatetagsstat'),
                URLHelper('/tagsrank', 'mostused'),
                ]
        
        
    def updatetagsstat(self, request, **kwargs):
        self.method_check(request, allowed=['post'])
        
        #if the request is not autenticated don't do anything
#         if not request.user or not request.user.is_authenticated():
#             return self.create_response(request, '')      
        
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        if isinstance(data, list):
            #get the acroweb user id        
            uid = whoAmI(request)
            if uid is not None:            
                for tag in data:
                    stat, _ = TagStatistics.objects.get_or_create(acuid=uid, tag_id=tag)
                    stat.count += 1
                    stat.save()
        
        return self.create_response(request, '') 


    def mostused(self, request, **kwargs):
        self.method_check(request, allowed=['get'])
        
        #if the request is not autenticated don't do anything
#         if not request.user or not request.user.is_authenticated():
#             return self.create_response(request, '')      

        uid = whoAmI(request)
        stats = TagStatistics.objects.filter(acuid=uid).order_by('-count')
        
        data = [s.tag_id for s in stats]
        
        return self.create_response(request, data)
        