from dewetra2.models import Event, Layer
from acroweb.core.resources import AcrowebResource, URLHelper
from dewetra2.core.resources import DewetraResourceMeta
from django.forms.models import model_to_dict

import json

class EventRes(AcrowebResource):
    
    class Meta(DewetraResourceMeta):
        resource_name = 'events'


    def getMyUrl(self):
        return [
                URLHelper('/list', 'events_list'),
        #                 URLHelper('/widget/%s' %(self.strParam('widget_id')), 'widget_details'),
                ]


    def events_list(self, request, **kwargs):        

    #   if request.user is None or not request.user.is_authenticated(): 
    #       return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['get'])
        res = []
        events = Event.objects.all()
        for event in events:
            layers = event.layer_set.all()
            list_layer = []
            for x in layers:
                layer_dict = model_to_dict(x)
                layer_dict['server'] = model_to_dict(x.server)
                layer_dict['type'] = model_to_dict(x.type)
                layer_dict['tags'] = [model_to_dict(t) for t in x.tags.all()]
                list_layer.append(layer_dict)

            res.append({
                'name': event.name,
                'description': event.description,
                'date': event.date,
                'lat': event.lat,
                'lon': event.lon,
                'data_type': event.data_type,
                'hazard': event.hazard,
                'layers': list_layer
                })
        return self.create_response(request, res)