from dewetra2.dds.dds_client import DDSClient
import urllib
#import xmltodict
import requests

class DDSError(Exception): pass

class DDSDropsClient(DDSClient):
    """
    dds drops client
    """
    def get(self, method, paramData=None):
        with self.lock:
            url = '%s/rest/%s' % (self.url, method)
            payload= {}
            if paramData:
                payload={'data': paramData}
            r = requests.get(url, 
                             auth=(self.user, self.password),
                             params=payload)
    #         if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))

            if r.status_code != 200: raise DDSError('%s'%(r.content))
            return r.json()

    def post(self, method, data):
        with self.lock:
            r = requests.post('%s/rest/%s'%(self.url, method),
                              headers = {'content-type': 'application/json'}, 
                              auth=(self.user, self.password),
                              json=data)
    #         if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))        
            if r.status_code != 200: raise DDSError('%s'%(r.content))
            # print("TEXT: "+r.text)
            # print("JSON: "+r.json())
            return r.json()
    
    
    
    def getSensorClasses(self):
        """
        gets a list of sensor classes
        :return: list of sensor classes
        """    
        return self.get('drops_sensors/classes')


    
    def getSensorAnag(self, sensor_class, raggr): 
        """
        gets a list of sensor anagraphical data for the selected sensor_class and raggr
        :param sensor_class: selected sensor class
        :param raggr: selected raggr
        :return: list of sensors objects
        """
        url = 'drops_sensors/anag/%s/%s' % (sensor_class, raggr)
        encodedurl = urllib.quote(url)
        return self.get(encodedurl)


    def getSensorData(self, sensor_class, sensors_id, date_from, date_to, aggr_time=None): 
        """
        get sensor data from selected sensors on the selected date range
        :param sensor_class: sensor class string
        :param sensors_id: SensorList Object, or list of Sensors or list of sensors id
        :param date_from: date from
        :param date_to: date to
        :param aggr_time: aggregation step in seconds
        :return: data as json
        """
        url = 'drops_sensors/serie'
        data =  {
                    'sensorClass': sensor_class,
                    'from': date_from,
                    'to': date_to,
                    'ids': sensors_id
                    }
                
        if aggr_time: 
            url = '/drops_sensors/serieaggr'  
            data['step'] = aggr_time

        return self.post(url, data)
