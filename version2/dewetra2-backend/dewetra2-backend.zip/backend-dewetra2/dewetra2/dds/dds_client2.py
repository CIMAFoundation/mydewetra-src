
import django
django.setup()

import requests
import xmltodict
import time
import datetime
import calendar
import thread
from threading import Lock
from time import sleep
import json
from dewetra2.dds.dds_client import DDSError

class DDSClient2():    
    """
    dds client base class
    """
    def __init__(self, url, user, password):
        self.url = url
        self.user = user
        self.password = password
        self.lock = Lock()

    def get(self, method, paramData=None):
        with self.lock:
            url = '%s/rest/%s' % (self.url, method)
            payload= {}
            if paramData:
                payload={'data': paramData}
            r = requests.get(url, 
                             auth=(self.user, self.password),
                             params=payload)
    #         if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))        
            if r.status_code != 200: raise DDSError('%s'%(r.content))
            return r.json()

    def postPunctualSeries(self, method, data):
        with self.lock:
            r = requests.post('%s/rest/%s'%(self.url, method),
                              headers = {'content-type': 'application/json'}, 
                              auth=(self.user, self.password),
                              data=json.dumps(data))
    #         if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))        
            if r.status_code != 200: raise DDSError('%s'%(r.content))
            return r.json()
        
    def post(self, method, data):
        with self.lock:
            print '%s/rest/%s'%(self.url, method)
            print data
            r = requests.post('%s/rest/%s'%(self.url, method),
                              headers = {'content-type': 'application/json'}, 
                              auth=(self.user, self.password),
                              json=data)
    #         if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))        
            if r.status_code != 200: raise DDSError('%s'%(r.content))
            return r.json()

    

class DDSMapClient2(DDSClient2):
    """
    dds movie client
    """
    def movieTimeline(self, dataId,timelineId):
        print timelineId
        return self.get('ddsmovie/timeline/%s/%s' %(dataId, timelineId))
    def getMovie(self, dataId):
        return self.get('ddsmovie/movie/%s' % dataId)  
    def createMovie(self, dataId):
        return self.get('ddsmovie/create/%s' % dataId)   
    def supportedDatasMovie(self):
        return self.get('ddsmovie/supported')
    """
    dds map client
    """
    def supported(self):    
        return self.get('ddsmap/supported')
    def properties(self, dataId):
        prop = self.get('ddsmap/properties/%s/' % dataId)
        if 'attributes' in prop:
            for attr in prop['attributes']:
                if 'visible' in attr: attr['visible'] = str(attr['visible']).lower()
                if 'entries' in attr:
                    for entry in attr['entries']:
                        if 'referredValues' in entry:
                            ref_entries = []
                            for key in entry['referredValues']:
                                ref_entries.append({'key': key, 'value':entry['referredValues'][key]}) 
                            entry['referredValues'] = {'entry': ref_entries} if ref_entries else None
                    if attr['selectedEntry'] and 'referredValues' in attr['selectedEntry']:
                        ref_entries = []
                        for key in attr['selectedEntry']['referredValues']:
                            ref_entries.append({'key': key, 'value':attr['selectedEntry']['referredValues'][key]}) 
                        attr['selectedEntry']['referredValues'] = {'entry': ref_entries} if ref_entries else None
                        
        return {'layerProperties': prop}


    def _buildAvailabiltyRequestPunctualSeries(self, props, t1, t2):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        tinyProps = props['layerProperties'] if 'layerProperties' in props else props
        for attr in tinyProps['attributes']:
            if 'entries' in attr and isinstance(attr, dict): del attr['entries']
            ref_values = attr['selectedEntry']['referredValues']
            if ref_values and 'entry' in ref_values:
                rv_dict = {}
                for rv in ref_values['entry']:
                    rv_dict[rv['key']] = rv['value']
                    attr['selectedEntry']['referredValues'] = rv_dict
        reqData = {
                   #'availabilityRequest': {
                        'from':dt1.isoformat(), 
                        'to':dt2.isoformat(), 
                        'prop':tinyProps
                    #}
                }
        return reqData

    def _buildAvailabiltyRequest(self, props, t1, t2):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        tinyProps = props['layerProperties'] if 'layerProperties' in props else props
        for attr in tinyProps['attributes']:
            if 'entries' in attr and isinstance(attr, dict): del attr['entries']
            ref_values = attr['selectedEntry']['referredValues']
            if ref_values and 'entry' in ref_values:
                rv_dict = {}
                for rv in ref_values['entry']:
                    rv_dict[rv['key']] = rv['value']
                    attr['selectedEntry']['referredValues'] = rv_dict
        reqData = {
                #    'availabilityRequest': {
                        'from':dt1.isoformat(), 
                        'to':dt2.isoformat(), 
                        'prop':tinyProps
                    # }
                }
        return reqData

    def availability(self, props, t1, t2):
        reqData = self._buildAvailabiltyRequest(props, t1, t2)
        datas = self.post('ddsmap/availables', reqData)        
        return datas
        
    def publish(self, props, data, t1, t2):
        avReqData = self._buildAvailabiltyRequest(props, t1, t2)
        reqData = { 
                   'request': avReqData,
                   'data': data
                   }
        datas = self.post('ddsmap/publish', reqData)
        retDict = {
            'layerid': datas['layer'],
            'layertype': datas['type']
            }

        return retDict 
 
    def permanent(self, layerId):
        return self.get('ddsmap/permanent/%s/'%layerId)
 
#     def getLayerStyle(self, layerId):
#         return self.getAsText('dds_layer_style.json', layerId)
 
    def getLayerBBox(self, layerId):
        return self.get('ddsmap/boundingbox/%s/'%layerId)

    def getLayerStyle(self, layerId):
        return self.get('dds/layer_style/%s/'%layerId)
    
    def areaSerie(self, props, t1, t2, geoJson):
        reqData = self._buildAvailabiltyRequestPunctualSeries(props, t1, t2)
        reqData.update({'geoJson':geoJson})
        datas = self.postPunctualSeries('ddsmap/areaserie', reqData)
        return datas
    
    def punctualSerie(self, props, t1, t2, lon, lat):
        reqData = self._buildAvailabiltyRequestPunctualSeries(props, t1, t2)
        reqData.update({'lon':lon, 'lat':lat})
        datas = self.postPunctualSeries('ddsmap/punctualserie', reqData)        
        return datas
    
    def restore(self, props, days):
        data = {
            'prop': props,
            'days': days
            }
        return self.post('ddsmap/restore', data)





class DDSSerieClient2(DDSClient2):
    """
    dds serie client
    """
    
    def supported(self):
        return self.get('ddsserie/supported')

    def properties(self, dataId):
        prop_dict = self.get('ddsserie/properties/%s/'%dataId)
        return prop_dict
    
#     def _getSeries(self, dataId, featureId, t1, t2, method):
#         dt1 = datetime.datetime.fromtimestamp(t1)
#         dt2 = datetime.datetime.fromtimestamp(t2)
#         reqData = {
#                    'serieRequest': {
#                         'serieId': dataId,
#                         'featureId': featureId,
#                         'from': dt1.isoformat(),
#                         'to': dt2.isoformat()
#                         }
#                    }
#         # reqDataXml = xmltodict.unparse(reqData)
#         datas = self.post(method, reqData)
# #         if 'series' in datas and 'data' in datas['series']:
# #             return datas['series']['data']
# #         if 'serie' in datas:
# #             return datas['serie']
#         return datas
    
    def series(self, dataId, featureId, t1, t2):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        reqData = {
                #    'serieRequest': {
                        'serieId': dataId,
                        'featureId': featureId,
                        'from': dt1.isoformat(),
                        'to': dt2.isoformat()
                        # }
                   }
        series = self.post('ddsserie/series', reqData)
        if len(series) == 1: series=series[0]
        return series
    
    def rasorImpactURL(self, dataId, featureId, t1, t2, scenario, hydrogram=None):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        reqData = {
                   'rasorImpactRequest': {
                        'serieId': dataId,
                        'featureId': featureId,
                        'from': dt1.isoformat(),
                        'to': dt2.isoformat(),
                        'scenario': scenario,
                        'hydrogram': hydrogram
                        }
                   }
        datas = self.post('ddsserie/serie_rasor_impact_scenario', reqData)
        return datas['rasorImpactResult'] if 'rasorImpactResult' in datas else None
    
    def features(self, server, props):
        url = "%s/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=%s"%(server.url,props['layer'])
        r = requests.get(url)
        if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))
        return r.json()
    
    def featuresDDS(self, dataId, t1, t2, props=None):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        reqData = {
                #    'serieFeaturesRequest': {
                        'serieId': dataId,
                        'from': dt1.isoformat(),
                        'to': dt2.isoformat()
                        # }
                   }
        
        if props and isinstance(props, dict):
            reqData['props'] = {'entry':[]}
            for key in props:
                reqData['props']['entry'].append({
                    'key': key,
                    'value': props[key]
                })


        geojson = self.post("ddsserie/features", reqData)
        return json.loads(geojson)

    def availability(self, dataId, t1, t2, props=None):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        reqData = {
#                    'serieFeaturesRequest': {
                        'serieId': dataId,
                        'from': dt1.isoformat(),
                        'to': dt2.isoformat()
#                         }
                   }
        
        if props is not None and isinstance(props, dict):
            reqData['props'] = {'entry':[]}
            for key in props:
                reqData['props']['entry'].append({
                    'key': key,
                    'value': props[key]
                })

        datas = self.post("ddsserie/availables", reqData)
        return datas['availability']['data'] if 'availability' in datas and 'data' in datas['availability'] else [] 

    def compatibles(self, dataId):
        datas = self.get('ddsserie/compatibles_series/%s/'%dataId)
        if 'seriePropertiesSet' in datas and 'data' in datas['seriePropertiesSet']: return datas['seriePropertiesSet']['data']
        if 'data' in datas: return datas['data']
        if 'html' in datas: return None #error: method not implemented in server
        return []


if __name__=='__main__':
        

    client = DDSMapClient2("http://localhost:8080/dds", "admin", "geoserver")
    # client = DDSMapClient2("http://dds.cimafoundation.org/dds", "admin", "geoDDS2013")


    props = client.properties('COSMO_I5')
    t2 = 1624008630
    t1 = t2 - 1*86400

    print (json.dumps(props))
    print (t1)
    print (t2)

    # s = client.punctualSerie(props, t1, t2, 8, 44)
    
    # print s['timeline']
    # print s['categories']
    # print s['values']

    
    av = client.availability(props, t1, t2)
    
    for d in av['data']:
        print d['description']








