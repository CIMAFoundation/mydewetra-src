from dewetra2.core.exceptions import DewetraError
from dewetra2.models import Server
import requests
from dewetra2.dds.dds_client2 import DDSMapClient2, DDSSerieClient2
from dewetra2.dds.dds_client import DDSMapClient, DDSSerieClient
import re

class DDSClientRouter(): 

    def __init__(self):
        self.dds_map_client_cache = {}
        self.dds_serie_client_cache = {}


    def allow_client2(self, dds):
        print('checking dds version')
        url = '%s/rest/dds/apiversion' % (dds.url)
        r = requests.get(url, auth=(dds.user, dds.password))
        version = r.content.replace('"', '')
        allow_client2 = r.status_code == 200 and re.match("^\d+?\.\d+?$", version) and version >= "2.0"
        return allow_client2
        
    def get_dds_map_client(self, dds_id):
        
        if dds_id in self.dds_map_client_cache:
            return self.dds_map_client_cache[dds_id]
        
        dds = Server.objects.get(pk=dds_id)
        if dds is None: raise DewetraError('DDS server not found')
        
#         client = self.get_dds_map_client_from_server(dds)
#         self.dds_map_client_cache[dds_id] = client
#          
#         return client
#  
#     def get_dds_map_client_from_server(self, dds):
        allow_client2 = self.allow_client2(dds)
        
        client = DDSMapClient2(dds.url, dds.user, dds.password) if allow_client2 else DDSMapClient(dds.url, dds.user, dds.password)
        return client
    
    def get_dds_serie_client(self, dds_id):
        
        if dds_id in self.dds_serie_client_cache:
            return self.dds_serie_client_cache[dds_id]
        
        dds = Server.objects.get(pk=dds_id)
        if dds is None: raise DewetraError('DDS server not found')
        
#         client = self.get_dds_serie_client_from_server(dds_id, dds)
#         self.dds_serie_client_cache[dds_id] = client
#         return client
#  
#     def get_dds_serie_client_from_server(self, dds):
        allow_client2 = self.allow_client2(dds)
        
        client = DDSSerieClient2(dds.url, dds.user, dds.password) if allow_client2 else DDSSerieClient(dds.url, dds.user, dds.password)
        
        return client
