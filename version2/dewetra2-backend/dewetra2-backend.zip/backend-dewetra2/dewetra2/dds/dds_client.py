import requests
import xmltodict
import time
import datetime
import calendar
import thread
from threading import Lock
from time import sleep
import json

class DDSError(Exception): pass

class DDSClient():    
    """
    dds client base class
    """
    def __init__(self, url, user, password):
        self.url = url
        self.user = user
        self.password = password
        self.lock = Lock()

    def get(self, method, paramData=None):
        with self.lock:
            url = '%s/rest/%s.json' % (self.url, method)
            payload= {}
            if paramData:
                payload={'data': paramData}
            r = requests.get(url, 
                             auth=(self.user, self.password),
                             params=payload)
    #         if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))        
            if r.status_code != 200: raise DDSError('%s'%(r.content))
            return r.json()

    def getAsText(self, method, paramData=None):
        with self.lock:
            url = '%s/rest/%s.txt' % (self.url, method)
            payload= {}
            if paramData:
                payload={'data': paramData}
            #with self.lock:
            r = requests.get(url, 
                             auth=(self.user, self.password),
                             params=payload)
    #         if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))        
            if r.status_code != 200: raise DDSError('%s'%(r.content))
            return r.text

    def getAsItIs(self, method, paramData=None):
        with self.lock:
            url = '%s/rest/%s' % (self.url, method)
            payload= {}
            if paramData:
                payload={'data': paramData}
            #with self.lock:
            r = requests.get(url, 
                             auth=(self.user, self.password),
                             params=payload)
    #         if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))        
            if r.status_code != 200: raise DDSError('%s'%(r.content))
            return r.text

    def post(self, method, data):
        with self.lock:
            r = requests.post('%s/rest/%s.json'%(self.url, method),
                              headers = {'content-type': 'application/json'}, 
                              auth=(self.user, self.password),
                              data=data)
    #         if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))        
            if r.status_code != 200: raise DDSError('%s'%(r.content))
            return r.json()

    def postPunctualSeries(self, method, data):
        with self.lock:
            r = requests.post('%s/rest/%s'%(self.url, method),
                              headers = {'content-type': 'application/json'}, 
                              auth=(self.user, self.password),
                              data=json.dumps(data))
    #         if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))        
            if r.status_code != 200: raise DDSError('%s'%(r.content))
            return r.json()


    def postAsText(self, method, data, paramData=None):
        payload= {}
        if paramData:
            payload={'data': paramData}
        with self.lock:
            r = requests.post('%s/rest/%s.txt'%(self.url, method),
                              headers = {'content-type': 'application/json'}, 
                              auth=(self.user, self.password),
                              data=data, params=payload)
    #         if r.status_code != 200 and r.status_code != 201: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))
            if r.status_code != 200 and r.status_code != 201: raise DDSError('%s'%(r.content))
            return r.text


class DDSMapClient(DDSClient):
    """
    dds map client
    """
    
    def supported(self):    
        return self.get('dds_support')
    
    def properties(self, dataId):
        xml = self.getAsText('dds_properties', dataId)
        return xmltodict.parse(xml)

    def _buildMovieTimelineRequest(self, dataId, timelineId):
        reqData = {
            'timelineRequest': {
                'movieId':dataId, 
                'timelineId':timelineId
            }
        }
        reqDataXml = xmltodict.unparse(reqData)
        return reqDataXml

    def _buildAvailabiltyRequestPunctualSeries(self, props, t1, t2):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        tinyProps = props['layerProperties'] if 'layerProperties' in props else props
        for attr in tinyProps['attributes']:
            if 'entries' in attr and isinstance(attr, dict): del attr['entries']
            ref_values = attr['selectedEntry']['referredValues']
            if ref_values and 'entry' in ref_values:
                rv_dict = {}
                for rv in ref_values['entry']:
                    rv_dict[rv['key']] = rv['value']
                    attr['selectedEntry']['referredValues'] = rv_dict
        reqData = {
                   #'availabilityRequest': {
                        'from':dt1.isoformat(), 
                        'to':dt2.isoformat(), 
                        'prop':tinyProps
                    #}
                }
        return reqData




    def _buildAvailabiltyRequest(self, props, t1, t2):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        if 'layerProperties' not in props: raise DDSError('cannot find "layerProperties" key in properties dictionary')
        tinyProps = props['layerProperties']
        for attr in tinyProps['attributes']:
            if 'entries' in attr and isinstance(attr, dict): del attr['entries']
        reqData = {
                   'availabilityRequest': {
                        'from':dt1.isoformat(), 
                        'to':dt2.isoformat(), 
                        'prop':tinyProps
                    }
                }
        return reqData

    def availability(self, props, t1, t2):
        reqData = self._buildAvailabiltyRequest(props, t1, t2)
        reqDataXml = xmltodict.unparse(reqData)
#        print props['layerProperties']['id']
#         xml = self.getAsText('dds_available', reqDataXml) if len(reqDataXml)<=3000 else self.postAsText('dds_available', reqDataXml)
        
        xml = self.postAsText('dds_available', reqDataXml, props['layerProperties']['id'])
        datas = xmltodict.parse(xml)
        if datas and 'layerDataList' in datas and datas['layerDataList'] and 'datas' in datas['layerDataList']:
            if isinstance(datas['layerDataList']['datas'], dict): return [datas['layerDataList']['datas']] 
            return datas['layerDataList']['datas']
        return []
        
    def publish(self, props, data, t1, t2):
        avReqData = self._buildAvailabiltyRequest(props, t1, t2)
        reqData = { 
                   'publicationRequest': {
                       'request': avReqData['availabilityRequest'],
                       'data': data
                       }
                   }
        reqDataXml = xmltodict.unparse(reqData)
        
        try:
#             resString = self.getAsText('dds_publication2', reqDataXml) if len(reqDataXml) <= 3000 else self.postAsText('dds_publication', reqDataXml)
            resString = self.postAsText('dds_publication2', reqDataXml, props['layerProperties']['id'])
            datas = xmltodict.parse(resString)
            retDict = {
                'layerid': datas['publicationResult']['layer'],
                'layertype': datas['publicationResult']['type']
                }
        except Exception as e:
#             resString = self.getAsText('dds_publication', reqDataXml) if len(reqDataXml) <= 3000 else self.postAsText('dds_publication', reqDataXml)
            resString = self.postAsText('dds_publication', reqDataXml)
            retDict = {'layerid': resString}
        
        return retDict 

    def permanent(self, layerId):
        return self.getAsText('dds_permanent', layerId)

    def getLayerStyle(self, layerId):
        return self.getAsText('dds_layer_style.json', layerId)

    def getLayerBBox(self, layerId):
        return self.getAsItIs('ddsmap/boundingbox/%s'%layerId)

    def supportedDatasMovie(self):
        xml = self.getAsText('dds_support_movie')
        datas = xmltodict.parse(xml)
        return datas["movieConfigurations"]

    def createMovie(self, data):
        return self.get('ddsmovie/create/%s', data)
    
    def getMovie(self, data):
        xml=self.getAsText('dds_movie', data)
        datas=xmltodict.parse(xml)
        
        return datas['movieDefinition']

    def movieTimeline(self, dataId, timelineId):
        reqData = self._buildMovieTimelineRequest(dataId, timelineId)
        xml= self.getAsText('dds_movie_timeline', reqData)
        datas=xmltodict.parse(xml)
        return datas['timelineData']

    def areaSerie(self, props, t1, t2, geoJson):
        reqData = self._buildAvailabiltyRequestPunctualSeries(props, t1, t2)
        reqData.update({'geoJson':geoJson})
        datas = self.postPunctualSeries('ddsmap/areaserie', reqData)
        return datas

    def punctualSerie(self, props, t1, t2, lon, lat):
        reqData = self._buildAvailabiltyRequestPunctualSeries(props, t1, t2)
        reqData.update({'lon':lon, 'lat':lat})
        datas = self.postPunctualSeries('ddsmap/punctualserie', reqData)
        return datas

class DDSSerieClient(DDSClient):
    """
    dds serie client
    """
    
    def supported(self):
        return self.get('dds_serie_support')

    def properties(self, dataId):
        xml = self.getAsText('dds_serie_properties', dataId)
        datas = xmltodict.parse(xml)
        if 'serieProperties' in datas: return datas['serieProperties']
        return {}
    
    def _getSeries(self, dataId, featureId, t1, t2, method):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        reqData = {
                   'serieRequest': {
                        'serieId': dataId,
                        'featureId': featureId,
                        'from': dt1.isoformat(),
                        'to': dt2.isoformat()
                        }
                   }
        reqDataXml = xmltodict.unparse(reqData)
        xml = self.getAsText(method, reqDataXml)
        datas = xmltodict.parse(xml)
        if 'series' in datas and 'data' in datas['series']:
            return datas['series']['data']
        if 'serie' in datas:
            return datas['serie']
    
    def serie(self, dataId, featureId, t1, t2):
        return self._getSeries(dataId, featureId, t1, t2, 'dds_serie')

    def series(self, dataId, featureId, t1, t2):
        return self._getSeries(dataId, featureId, t1, t2, 'dds_series')
    
    def rasorImpactURL(self, dataId, featureId, t1, t2, scenario, hydrogram=None):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        reqData = {
                   'rasorImpactRequest': {
                        'serieId': dataId,
                        'featureId': featureId,
                        'from': dt1.isoformat(),
                        'to': dt2.isoformat(),
                        'scenario': scenario,
                        'hydrogram': hydrogram
                        }
                   }
        reqDataXml = xmltodict.unparse(reqData)
        xml = self.getAsText('dds_serie_rasor_impact_scenario', reqDataXml)
        datas = xmltodict.parse(xml)
        return datas['rasorImpactResult'] if 'rasorImpactResult' in datas else None
    
    def features(self, server, props):
        url = "%s/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=%s"%(server.url,props['layer'])
        r = requests.get(url)
        if r.status_code != 200: raise DDSError('dds response: %s (%d - %s)'%(r.content, r.status_code, r.reason))
        return r.json()
    
    def featuresDDS(self, dataId, t1, t2, props=None):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        reqData = {
                   'serieFeaturesRequest': {
                        'serieId': dataId,
                        'from': dt1.isoformat(),
                        'to': dt2.isoformat()
                        }
                   }
        
        if props is not None and isinstance(props, dict):
            reqData['serieFeaturesRequest']['props'] = {'entry':[]}
            for key in props:
                reqData['serieFeaturesRequest']['props']['entry'].append({
                    'key': key,
                    'value': props[key]
                })

        
        reqDataXml = xmltodict.unparse(reqData)
        geojson = self.getAsText("dds_serie_features.txt", reqDataXml)
        return json.loads(geojson)

    def availability(self, dataId, t1, t2, props=None):
        dt1 = datetime.datetime.fromtimestamp(t1)
        dt2 = datetime.datetime.fromtimestamp(t2)
        reqData = {
                   'serieFeaturesRequest': {
                        'serieId': dataId,
                        'from': dt1.isoformat(),
                        'to': dt2.isoformat()
                        }
                   }
        
        if props is not None and isinstance(props, dict):
            reqData['serieFeaturesRequest']['props'] = {'entry':[]}
            for key in props:
                reqData['serieFeaturesRequest']['props']['entry'].append({
                    'key': key,
                    'value': props[key]
                })

        reqDataXml = xmltodict.unparse(reqData)
        xml = self.postAsText("dds_serie_availability", reqDataXml)
        datas = xmltodict.parse(xml)
        return datas['availability']['data'] if datas and 'availability' in datas and datas['availability'] and 'data' in datas['availability'] else [] 

    def compatibles(self, dataId):
        xml = self.getAsText('dds_compatibles_series', dataId)
        datas = xmltodict.parse(xml)
        if 'seriePropertiesSet' in datas and 'data' in datas['seriePropertiesSet']: return datas['seriePropertiesSet']['data']
        if 'html' in datas: return None #error: method not implemented in server
        return []


if __name__=='__main__':
        

    client = DDSMapClient("http://localhost:8080/geoserver", "admin", "geoserver")
 #   client = DDSMapClient2("http://dds.cimafoundation.org/dds", "admin", "geoDDS2013")

    s = client.supportedDatasMovie()
    print (s)

    s=client.createMovie('COSMO_I2')
    print (s)

    s=client.getMovie('COSMO_I2')
    print (s)

    s=client.movieTimeline('COSMO_I2','COSMO_I2_qv_s;-_1_NOTHING')
    print (s)

    props = client.properties('COSMO_I2')
    t2 = 1612790365.962
    t1 = t2 - 1*86400

    print (json.dumps(props))
    print (t1)
    print (t2)



#     av = client.availability(props, t1, t2)
#     
#     print 'archived: %s'%av['archivedDays']
#     print 'processing: %s'%av['processingDays']
#     for d in av['data']:
#         print d['description']
# 
#     restoreResult = client.restore(props, av['archivedDays'])
# 
#     print 'ok: %s'%restoreResult['ok']
#     print 'ko: %s'%restoreResult['ko']
#     print 'errors: %s'%restoreResult['errors']
