"""
dds client resources
"""
from geojson.geometry import MultiPolygon, Polygon
from dewetra2.core.resources import DewetraResourceMeta
from dewetra2.dds.dds_client import DDSSerieClient
from tastypie.http import HttpApplicationError, HttpNotFound, HttpUnauthorized
from dewetra2.models import Server, Layer
from dewetra2.core.exceptions import DewetraError
from acroweb.core.resources import AcrowebResource, URLHelper
import json
from geojson import Feature, Point, FeatureCollection
from dewetra2.dds import DDSClientRouter


class DDSMapResource(AcrowebResource):
    
    class Meta(DewetraResourceMeta):
        resource_name = 'ddsmap'
        
    def getMyUrl(self):
        return [
                URLHelper('/%s/supported'%self.strParam('server'), 'supported'),
                URLHelper('/%s/%s/properties'%(self.strParam('server'), self.strParam('data')), 'properties'),
                URLHelper('/%s/availability'%self.strParam('server'), 'availability'),
                URLHelper('/%s/publish'%self.strParam('server'), 'publish'),
                URLHelper('/layer', 'layer'),
                URLHelper('/%s/punctualserie'%self.strParam('server'), 'punctualserie'),
                URLHelper('/%s/areaserie'%self.strParam('server'), 'areaserie'),
                URLHelper('/permanent/%s/%s'%(self.strParam('server'), self.strParam('layer')), 'permanent'),
                URLHelper('/layerstyle/%s/%s'%(self.strParam('server'), self.strParam('layer')), 'layerstyle'),
                URLHelper('/layerbbox/%s/%s'%(self.strParam('server'), self.strParam('layer')), 'layerbbox'),
                URLHelper('/supportedmovie/%s'%(self.strParam('server')), 'supportedDatasMovie'),
                URLHelper('/createmovie/%s/%s'%(self.strParam('server'), self.strParam('data')), 'createMovie'),
                URLHelper('/getmovie/%s/%s'%(self.strParam('server'), self.strParam('data')), 'getMovie'),
                URLHelper('/getmovietimeline/%s/%s/%s'%(self.strParam('server'), self.strParam('data'),self.strParam('timeline')), 'getMovieTimeline'),
                ]
    
    def _getClient(self, ddsId):
        return DDSClientRouter().get_dds_map_client(ddsId)
    
    def _adaptPropsForClient2(self, props):
        for attr in props['attributes']:
            if 'selectedEntry' in attr and 'referredValues' in attr['selectedEntry']:
                if attr['selectedEntry']['referredValues']:
                    new_rv = {}
                    rv = attr['selectedEntry']['referredValues']
                    for entry in rv:
                        if isinstance(rv[entry], dict):
                            if 'key' in rv[entry] and 'value' in rv[entry]:
                                new_rv[rv[entry]['key']] = rv[entry]['value']
                        else:
                            for item in rv[entry]:
                                if 'key' in item and 'value' in item:
                                    new_rv[item['key']] = item['value']
                    if len(new_rv) > 0:
                        attr['selectedEntry']['referredValues'] = new_rv
                
    def supported(self, request, **kwargs):        
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['get'])
        supported = self._getClient(kwargs['server']).supported()        
        return self.create_response(request, supported)

    def properties(self, request, **kwargs):		
		
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['get'])
        props = self._getClient(kwargs['server']).properties(kwargs['data'])        
        return self.create_response(request, props)

    def availability(self, request, **kwargs):
        
        if request.user is None or not request.user.is_authenticated(): 
           return self.create_response(request, 'not authenticated', HttpUnauthorized)
		
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        if not all([p in data for p in ['props', 'from', 'to']]): 
            return self.create_response(request, 'invalid post datas', HttpApplicationError)        
        av = self._getClient(kwargs['server']).availability(data['props'], data['from'], data['to'])
        return self.create_response(request, av)
    
    def areaserie(self, request, **kwargs):	
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        if not all([p in data for p in ['props', 'from', 'to', 'points']]):
            return self.create_response(request, 'invalid post datas', HttpApplicationError)
        self._adaptPropsForClient2(data['props'])

        points = data['points'][0]
        coords = []
        coords.append(points)
        features = []
        polygon = MultiPolygon(coordinates=[points])
        prop = {'id' : '0'}
        features.append(Feature(geometry=polygon, properties=prop))

        feature_collection = FeatureCollection(features)
        geo_str= json.dumps(feature_collection)

        s = self._getClient(kwargs['server']).areaSerie(data['props'], data['from'], data['to'], geo_str)
#        s = self._getClient(kwargs['server']).areaSerie(data['props'], data['from'], data['to'],data['geoJson'])
        return self.create_response(request, s)

    def punctualserie(self, request, **kwargs):	
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        if not all([p in data for p in ['props', 'from', 'to', 'lon', 'lat']]): 
            return self.create_response(request, 'invalid post datas', HttpApplicationError)
        self._adaptPropsForClient2(data['props'])   
        s = self._getClient(kwargs['server']).punctualSerie(data['props'], data['from'], data['to'], data['lon'], data['lat'])
        return self.create_response(request, s)

    def publish(self, request, **kwargs):
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        if not all([p in data for p in ['props', 'data', 'from', 'to']]): 
            return self.create_response(request, 'invalid post datas', HttpApplicationError)
        
        client = self._getClient(kwargs['server'])
        props = client.properties(data['props']['layerProperties']['id'])

        for attr in data['props']['layerProperties']['attributes']:
            # Modificato il 16/06/2021: se il layer ha solo 1 attributo non riusciva a ciclare
            if len(data['props']['layerProperties']['attributes'])>1:
                for attr2 in props['layerProperties']['attributes']:
                    if attr2['descr'] == attr['descr']:
                        attr2['selectedEntry'] = attr['selectedEntry']
            else:
                try:
                    if props['layerProperties']['attributes'][0]['descr'] == attr['descr']:
                        props['layerProperties']['attributes'][0]['selectedEntry'] = attr['selectedEntry']
                except KeyError:
                    if props['layerProperties']['attributes']['descr'] == attr['descr']:
                        props['layerProperties']['attributes']['selectedEntry'] = attr['selectedEntry']

        layerData = self._getClient(kwargs['server']).publish(props, data['data'], data['from'], data['to'])            
        return self.create_response(request, layerData)
    
    def getAttributeDescr(self, attribute, names, default):
        for name in names:
            if attribute['name'] == name:
                return attribute.get('selectedEntry', {}).get('descr', default)
        return default
        
    
    def buildDescrProperties(self, prop):
        descr_prop = {}
        descr_prop['variable'] = 'unknown'
        descr_prop['spatial_aggr'] = 'native'
        descr_prop['time_aggr'] = 'instant'
        descr_prop['instrument'] = 'unknown'
        descr_prop['source'] = 'unknown'
        descr_prop['processing'] = 'unknown'
        
        attributes = prop['layerProperties']['attributes']

        if not isinstance(attributes, list): attributes = [attributes] 
        
        for attribute in attributes:
            
            #Aggregazione spaziale
            descr_prop['spatial_aggr'] = self.getAttributeDescr(attribute, ['shp'], descr_prop['spatial_aggr']);
            
            #Variabile
            descr_prop['variable'] = self.getAttributeDescr(attribute, ['variable'], descr_prop['variable']);
        
            #Aggregazione Temporale
            descr_prop['time_aggr'] = self.getAttributeDescr(attribute, ['aggregation'], descr_prop['time_aggr']);
            
            #Strumento    
            descr_prop['instrument'] = self.getAttributeDescr(attribute, ['instrument'], descr_prop['instrument']);
            
            #Fonte Dati
            descr_prop['source'] = self.getAttributeDescr(attribute, ['source'], descr_prop['source']);
            
            #Elaborazione prodotto    
            descr_prop['processing'] = self.getAttributeDescr(attribute, ['processing'], descr_prop['processing']);
        
        return descr_prop
        
    def layer(self, request, **kwargs):
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        if not all([p in data for p in ['layer', 'from', 'to']]): 
            return self.create_response(request, 'invalid post datas', HttpApplicationError)        
        layer = Layer.objects.get(pk=data['layer'])
        if layer is None: raise DewetraError('layer not found')
        client = self._getClient(layer.server.id)
        
        props = client.properties(layer.dataid)
        
        availables = client.availability(props, data['from'], data['to'])
        if len(availables) == 0: 
            return self.create_response(request, 'no data found', HttpNotFound)
        
        layerData = client.publish(props, availables[0], data['from'], data['to'])               
        
        ret = {
            'serverurl':layer.server.url, 
            'properties':props, 
            'descr_props':self.buildDescrProperties(props),
            'item':availables[0]
            }        
        ret.update(layerData)

        return self.create_response(request, ret)

    def permanent(self, request, **kwargs):      
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
          
        self.method_check(request, allowed=['get'])
        l = self._getClient(kwargs['server']).permanent(kwargs['layer'])        
        return self.create_response(request, l)

    def layerstyle(self, request, **kwargs):        
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['get'])
        styleJson = self._getClient(kwargs['server']).getLayerStyle(kwargs['layer'])
        styleObj = json.loads(styleJson)        
        return self.create_response(request, styleObj)

    def layerbbox(self, request, **kwargs):        
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['get'])
        styleJson = self._getClient(kwargs['server']).getLayerBBox(kwargs['layer'])
        styleObj = json.loads(styleJson)        
        return self.create_response(request, styleObj)

    def supportedDatasMovie(self, request, **kwargs):      
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
          
        self.method_check(request, allowed=['get'])
        l = self._getClient(kwargs['server']).supportedDatasMovie()        
        return self.create_response(request, l)

    def createMovie(self, request, **kwargs):      
        
        if request.user is None or not request.user.is_authenticated(): 
           return self.create_response(request, 'not authenticated', HttpUnauthorized)
          
        self.method_check(request, allowed=['get'])
        l = self._getClient(kwargs['server']).createMovie(kwargs['data'])
        return self.create_response(request, l)

    def getMovie(self, request, **kwargs):      
        
        if request.user is None or not request.user.is_authenticated(): 
           return self.create_response(request, 'not authenticated', HttpUnauthorized)
          
        self.method_check(request, allowed=['get'])
        l = self._getClient(kwargs['server']).getMovie(kwargs['data'])
        return self.create_response(request, l)

    def getMovieTimeline(self, request, **kwargs):      
        
        if request.user is None or not request.user.is_authenticated(): 
           return self.create_response(request, 'not authenticated', HttpUnauthorized)
          
        self.method_check(request, allowed=['get'])
   #     data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        l = self._getClient(kwargs['server']).movieTimeline(kwargs['data'],kwargs['timeline'])
        return self.create_response(request, l)

class DDSSerieResource(AcrowebResource):
    
    class Meta(DewetraResourceMeta):
        resource_name = 'ddsserie'
        
    def getMyUrl(self):
        return [
                URLHelper('/%s/supported'%self.strParam('server'), 'supported'),                
                URLHelper('/%s/%s/properties'%(self.strParam('server'), self.strParam('data')), 'properties'),
                URLHelper('/%s/series'%self.strParam('server'), 'series'),
                URLHelper('/%s/rasorimpacturl'%self.strParam('server'), 'rasorimpacturl'),
                URLHelper('/%s/seriefeatures'%self.strParam('server'), 'serieFeatures'),
                URLHelper('/%s/serieavailability'%self.strParam('server'), 'serieAvailability'),
                URLHelper('/features', 'features'),
                ]
    
    def _getClient(self, ddsId):
        return DDSClientRouter().get_dds_serie_client(ddsId)
    
    def supported(self, request, **kwargs):        
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['get'])
        supported = self._getClient(kwargs['server']).supported()        
        return self.create_response(request, supported)

    def properties(self, request, **kwargs):        

        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        
        self.method_check(request, allowed=['get'])
        serieId = kwargs['data'].replace('__', '.')
        props = self._getClient(kwargs['server']).properties(serieId)        
        return self.create_response(request, props)

    def series(self, request, **kwargs):        
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        if not all([p in data for p in ['id', 'feature', 'from', 'to']]): 
            return self.create_response(request, 'invalid post datas', HttpApplicationError)
        series = self._getClient(kwargs['server']).series(data['id'], data['feature'], data['from'], data['to'])
        return self.create_response(request, series)
            
    def serieFeatures(self, request, **kwargs):        
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        if not all([p in data for p in ['id', 'from', 'to']]): 
            return self.create_response(request, 'invalid post datas', HttpApplicationError)
        props = data['props'] if 'props' in data else None
        series = self._getClient(kwargs['server']).featuresDDS(data['id'],data['from'], data['to'], props=props)
        return self.create_response(request, series)

    def serieAvailability(self, request, **kwargs):        
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        if not all([p in data for p in ['id', 'from', 'to']]): 
            return self.create_response(request, 'invalid post datas', HttpApplicationError)
        props = data['props'] if 'props' in data else None
        series = self._getClient(kwargs['server']).availability(data['id'],data['from'], data['to'], props=props)
        return self.create_response(request, series)

    def rasorimpacturl(self, request, **kwargs):        
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        res = None
        if all([p in data for p in ['id', 'feature', 'hydrogram']]): 
            res = self._getClient(kwargs['server']).rasorImpactURL(data['id'], data['feature'], 0, 0, '', data['hydrogram'])
        elif all([p in data for p in ['id', 'feature', 'from', 'to', 'scenario']]):
            res = self._getClient(kwargs['server']).rasorImpactURL(data['id'], data['feature'], data['from'], data['to'], data['scenario']) 
        
        if not res:
            return self.create_response(request, 'invalid post datas', HttpApplicationError)
        
        return self.create_response(request, res)

    def features(self, request, **kwargs):                
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        #=======================================================================
        # retrieve all features accessible by the user
        #=======================================================================
        self.method_check(request, allowed=['get'])
        features = []
        layers = Layer.objects.filter(type__name__in=['sensor', 'section', 'station', 'Raingauge'])
        for l in layers:
            client = DDSSerieClient(l.server.url, l.server.user, l.server.password)
            try:
                props = client.properties(l.dataid)
                #retrieve all features by a WFS request
                geojson = client.features(l.server, props)
                for f in geojson['features']:
                    features.append({
                                     'server': l.server.id,
                                     'layer': l.name,
                                     'code': l.type.code,
                                     'name': f['properties'][props['descrField']],
                                     'fid': f['properties'][props['fidField']],
                                     'serie': l.dataid,
                                     'properties': f['properties']
                                     })
            except:
                print ('FEATURES: ERROR reading properties for serie %s' %l.dataid)
                
            
        return self.create_response(request, features)

        
    def static_features(self, request, **kwargs):
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['get'])
        features = []
        
        #=======================================================================
        # retrieve all "static" features        
        #=======================================================================
        
        
        
        return self.create_response(request, features)    




