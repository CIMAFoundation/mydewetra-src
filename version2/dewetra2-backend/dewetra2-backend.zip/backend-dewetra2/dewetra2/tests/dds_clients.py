'''
Created on Apr 14, 2020

@author: doy
'''
import time
from dewetra2.models import Server
import django
django.setup()

from dewetra2.dds.dds_client import DDSError


from dewetra2.dds import DDSClientRouter


if __name__ == '__main__':
    
    # layer_id = 'COSMO_I2'
    layer_id = 'MSG_IR108'
    t2 =  time.time() #1624008630
    t1 = t2 - 1*86400
    
    serie_id = 'autpor.dusts'
    
    
    dds_server = [
        Server(url="https://dds-test.cimafoundation.org/dds", user="admin", password="---"),
    ]


    for dds in dds_server:
        
        print '\n\n------------------------------------------------------ %s\n'%dds.url
         
        print '\n--------------------- MAP %s\n'%dds.url
         
        client = DDSClientRouter().get_dds_map_client_from_server(dds)
 
        supported_datas = client.supported()
        for d in supported_datas:
            # if d==layer_id:
            #     print 'FOUND!!! %s --> %s'%(d, supported_datas[d])
            #     break;
            layer_id=d

            prop = client.properties(layer_id)
            for attr in prop['layerProperties']['attributes']:                
                if 'visible' in attr and attr['visible'] != 'false' and "var" in attr['name']:
                    
                    if not isinstance(attr['entries'], list):  attr['entries'] = [attr['entries']]
                    for entry in attr['entries']:
                        print '%s,%s'%(supported_datas[layer_id].encode('utf-8'), entry['value'].encode('utf-8'))
                        



        # print '\nPROPERTIES'
        # prop = client.properties(layer_id)
        # for attr in prop['layerProperties']['attributes']:
        #     if 'visible' in attr and attr['visible'] != 'false':
        #         print attr['name']
        #         if not isinstance(attr['entries'], list):  attr['entries'] = [attr['entries']]
        #         print '\ttype: %s'%attr['type']
        #         print '\tentries:'
        #         for entry in attr['entries']:
        #             print '\t\t%s'%entry['value']
        #             if 'referredValues' in entry and entry['referredValues']:
        #                 print '\t\t\treferred values'
        #                 if not isinstance(entry['referredValues']['entry'], list):  entry['referredValues']['entry'] = [entry['referredValues']['entry']]
        #                 for rv in entry['referredValues']['entry']:
        #                     print '\t\t\t\t%s --> %s'%(rv['key'], rv['value'])
        #         #if attr['name'] != 'variable': attr['selectedEntry'] = attr['entries'][2]
        #         print '\tselected entry: %s'%attr['selectedEntry']['value']
                 
         
        # print '\nAVAILABLES'    
        # dates = client.availability(prop, t1, t2)
        # for d in dates:
        #     print '\t%s --> TS: %s - ID: %s'%(d['description'], d['date'], d['id'])
             
             
        # print '\nPUBBLICATIONS'
        # for d in dates:
        #     pub_result = client.publish(prop, d, t1, t2)
        #     print '\t%s --> %s (%s)'%(d['description'], pub_result['layerid'], pub_result['layertype'])
        #     style = client.getLayerStyle(pub_result['layerid'])
        #     print '\t\tstyle: %s'%style
        #     bbox = client.getLayerBBox(pub_result['layerid'])
        #     print '\t\tBBOX: %s'%bbox
        #     break;
            
            
            
        # print '\n--------------------- SERIE %s\n'%dds.url
        
        
        # client = DDSClientRouter().get_dds_serie_client_from_server(dds)

        # supported_datas = client.supported()
        # for d in supported_datas:
        #     if d==serie_id:
        #         print 'FOUND!!! %s --> %s'%(d, supported_datas[d])
        #         break;
            
            
        # print '\nPROPERTIES'
        # prop = client.properties(serie_id)
        # for p in prop:
        #     print '%s --> %s'%(p,prop[p])
        # fidField = prop['fidField']
        
        # print '\nCOMPATIBLES:'
        # compatibles = client.compatibles(serie_id)
        # for c in compatibles:
        #     print '\t%s'%c['descr']
        
        # print '\nAVAILABLES:'
        # availability = client.availability(serie_id, t1, t2)
        # print availability
        
        # print '\nFEATURES'
        # features = client.featuresDDS(serie_id, t1, t2, {})
        # for f in features['features']:
        #     print f
        #     fid = f['properties'][fidField]
        #     print '\t%s:'%fid
        #     try:
        #         series = client.series(serie_id, fid, t1, t2)
        #         if not isinstance(series, list): series = [series] 
        #         for serie in series:
        #             print '\t\t%s'%(serie['values'])
        #         break
        #     except DDSError as e:
        #         print '\t\tDDS ERROR: %s'%(str(e))
        
        
        
        
        
        
        
                
