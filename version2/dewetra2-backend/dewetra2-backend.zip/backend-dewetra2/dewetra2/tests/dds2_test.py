'''
Created on Apr 14, 2020

@author: doy
'''
import django
from dewetra2.dds.dds_client import DDSError
django.setup()


from dewetra2.dds import DDSClientRouter


if __name__ == '__main__':
    
    layer_ids = [
        'BOLIVIA_SMI',
        'BOLIVIA_SWDI',
        'BOLIVIA_FAPAR',
        'BOLIVIA_VHI',
        'BOLIVIA_ESI',
        'BOLIVIA_SPEI',
        'BOLIVIA_SPI',
        'BOLIVIA_PDSI'
        ]
    t1 = 1575162000
    t2 = 1575248400
    
    serie_id = None #'erg.floodproofs.deterministiclami'
    
    dds_id = 31
    
    
    for layer_id in layer_ids:
        
        print '\n--------------------- MAP %s\n'%dds_id
            
        client = DDSClientRouter().get_dds_map_client(dds_id)
        
        supported_datas = client.supported()
        for d in supported_datas:
            if d==layer_id:
                print 'FOUND!!! %s --> %s'%(d, supported_datas[d])
                break;
             
        print '\nPROPERTIES'
        prop = client.properties(layer_id)
        for attr in prop['layerProperties']['attributes']:
            if 'visible' in attr and attr['visible'] != 'false':
                print attr['name']
                if not isinstance(attr['entries'], list):  attr['entries'] = [attr['entries']]
                print '\ttype: %s'%attr['type']
                print '\tentries:'
                for entry in attr['entries']:
                    print '\t\t%s'%entry['value']
                    if 'referredValues' in entry and entry['referredValues']:
                        print '\t\t\treferred values'
                        if not isinstance(entry['referredValues']['entry'], list):  entry['referredValues']['entry'] = [entry['referredValues']['entry']]
                        for rv in entry['referredValues']['entry']:
                            print '\t\t\t\t%s --> %s'%(rv['key'], rv['value'])
                if attr['name'] != 'variable': attr['selectedEntry'] = attr['entries'][2]
                print '\tselected entry: %s'%attr['selectedEntry']['value']
                 
         
        print '\nAVAILABLES'    
        dates = client.availability(prop, t1, t2)
        for d in dates:
            print '\t%s --> TS: %s - ID: %s'%(d['description'], d['date'], d['id'])
             
             
        print '\nPUBBLICATIONS'
        for d in dates:
            pub_result = client.publish(prop, d, t1, t2)
            print '\t%s --> %s (%s)'%(d['description'], pub_result['layerid'], pub_result['layertype'])
            style = client.getLayerStyle(pub_result['layerid'])
            print '\t\tstyle: %s'%style
            bbox = client.getLayerBBox(pub_result['layerid'])
            print '\t\tBBOX: %s'%bbox
            
            
    
    if serie_id is not None:
        
        print '\n--------------------- SERIE %s\n'%dds_id
        
        
        client = DDSClientRouter().get_dds_serie_client(dds_id)
        
        supported_datas = client.supported()
        for d in supported_datas:
            if d==serie_id:
                print 'FOUND!!! %s --> %s'%(d, supported_datas[d])
                break;
            
            
        print '\nPROPERTIES'
        prop = client.properties(serie_id)
        for p in prop:
            print '%s --> %s'%(p,prop[p])
        fidField = prop['fidField']
        
        print '\nCOMPATIBLES:'
        compatibles = client.compatibles(serie_id)
        for c in compatibles:
            print '\t%s'%c['descr']
        
        print '\nAVAILABLES:'
        availability = client.availability(serie_id, t1, t2)
        print availability
        
        print '\nFEATURES'
        features = client.featuresDDS(serie_id, t1, t2)
        for f in features['features']:
            fid = f['properties'][fidField]
            print '\t%s:'%fid
            try:
                series = client.series(serie_id, fid, t1, t2)
                if not isinstance(series, list): series = [series] 
                for serie in series:
                    print '\t\t%s'%(serie['values'])
            except DDSError as e:
                print '\t\tDDS ERROR: %s'%(str(e))
           
            
        
        
        
        
        
                