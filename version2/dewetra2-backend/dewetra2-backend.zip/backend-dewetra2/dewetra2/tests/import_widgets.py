'''
Created on May 14, 2020

@author: doy
'''
import django
django.setup()

import json
from dewetra2.models import Widget, Layer, WidgetPropAttr

if __name__ == '__main__':
    with open('/share/widgets_data/widgets.json', 'r') as f:
        widgets = json.loads(f.read())
        
    for w in widgets:
        layers = Layer.objects.filter(dataid=w['data_id'])
        if len(layers) > 0:
            name = '%s_%s'%(w['data_id'], w['attributes'][0]['attr_value'])
            widget = Widget.objects.create(name=name, layer=layers[0])
            for attr in w['attributes']:
                if len(attr['attr_value'])>0:
                    WidgetPropAttr.objects.create(name=attr['attr_name'], value=attr['attr_value'], widget=widget)
    