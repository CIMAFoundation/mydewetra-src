"""
dds client resources
"""
from dewetra2.core.resources import DewetraResourceMeta
from tastypie.http import HttpApplicationError, HttpUnauthorized
from acroweb.core.resources import AcrowebResource, URLHelper
import importlib

    
class AlgorithResource(AcrowebResource):
    
    class Meta(DewetraResourceMeta):
        resource_name = 'alg'
        
    def getMyUrl(self):
        return [
                URLHelper('/run', 'run'),
                ]
    
    def run(self, request, **kwargs):
        
#         if request.user is None or not request.user.is_authenticated(): 
#             return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        if not all([p in data for p in ['alg', 'input']]): 
            return self.create_response(request, 'invalid post datas', HttpApplicationError)        

        [module_name, run_function_name] = data['alg'].split('.')

        alg_module = importlib.import_module('dewetra2.algorithms.%s.run'%(module_name))
        alg_run_function = getattr(alg_module, run_function_name)
        res = alg_run_function(data['input'])
        
        return self.create_response(request, res)
    
