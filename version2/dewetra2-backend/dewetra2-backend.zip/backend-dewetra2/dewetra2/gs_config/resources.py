import json

from tastypie.http import HttpUnauthorized, HttpApplicationError, HttpNotFound

from acroweb.core.resources import AcrowebResource, URLHelper
from dewetra2.gs_config.gs_manager import GsManager


class GsManagerResource(AcrowebResource):
    class Meta():
        resource_name = 'gsconfig'

    def getMyUrl(self):
        return [
            URLHelper( '/gssettings', 'gssettings' ),
            URLHelper( '/publishdatas', 'publishdatas'),
            URLHelper( '/publishstyle', 'publishstyle'),
            URLHelper( '/styles', 'styles'),
            URLHelper( '/setlayerstyle', 'setlayerstyle'),
        ]

    #return a list of geoservers settings (gs_descr, gs_url, gs_usr, gs_psw) for a specific dewetra_django_user (dewetra configuration)
    def gssettings(self, request, **kwargs):

        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['get'])
        
        gsSettingsList =[]
        
        #qui va implementata la query sul modello per avere i geoserver di competenza dello specifico utente
        
        #example
        gsSettings = {"gs_descr" : "mygeoserver",
                      "gs_url" : "http://localhost:8080/geoserver",
                      "gs_user" : "admin",
                      "gs_psw" : "geoserver"
                    }
        
        gsSettingsList.append(gsSettings)
        
        return self.create_response(request, gsSettings)

    
    #publish shapefile or geotiff in geoserver  
    def publishdatas(self, request, **kwargs):


        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        
        datas = request.POST
#         gsUrl, gsUser, gsPsw = self.getGsSettings(self, request, datas)
#         gsManager = GsManager(gsUrl, gsUser, gsPsw)
        
        gsSettings = self.getGsSettings(request, datas)
        gsManager = GsManager(*gsSettings)

        response = ""

        if request.FILES.values():
            uploadedFile = request.FILES.values()[0]

            try:
                response = gsManager.publish_data(uploadedFile)

            except Exception, error:
                errMsg = '%s' % (error)
                return self.create_response(request, errMsg, HttpApplicationError)

        else:
            response = 'error: not a valid data sent'
            print response
            return self.create_response(request, response)

        return self.create_response(request, response)
    
    
    #publish STYLE in geoserver
    def publishstyle(self, request, **kwargs):


        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        
        datas = request.POST
#         gsUrl, gsUser, gsPsw = self.getGsSettings(self, request, datas)
#         gsManager = GsManager(gsUrl, gsUser, gsPsw)
        
        gsSettings = self.getGsSettings(request, datas)
        gsManager = GsManager(*gsSettings)

        response = ""
        
        if request.FILES.values():
            uploadedFile = request.FILES.values()[0]
            
        try:
            response = gsManager.publish_style(uploadedFile)

        except Exception, error:
            errMsg = '%s' % (error)
            return self.create_response(request, errMsg, HttpApplicationError)

        return self.create_response(request, response)
    
    
    #return a list of geoserver styles
    def styles(self, request, **kwargs):

        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['get'])
        
        
        datas = request.POST
        gsSettings = self.getGsSettings(request, datas)
        gsManager = GsManager(*gsSettings)

        stylesList = []
      
        try:
            stylesList = gsManager.get_styles()
        except Exception, error:
            errMsg = '%s' % (error)
            return self.create_response(request, errMsg, HttpApplicationError)
       
        return self.create_response(request, stylesList)
   
    
    #set STYLE for a specific layer in geoserver
    def setlayerstyle(self, request, **kwargs):

        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        
        datas = request.POST
#         gsUrl, gsUser, gsPsw = self.getGsSettings(self, request, datas)
#         gsManager = GsManager(gsUrl, gsUser, gsPsw)
        if not ('layer' in datas) or not ('style' in datas):
            return self.create_response( request, 'cannot set style', HttpNotFound)
        
        gsSettings = self.getGsSettings(request, datas)
        gsManager = GsManager(*gsSettings)

        response = ""
      
        try:
            idLayer = datas['layer']
            idStyle = datas['style']
            response = gsManager.set_layer_style(idLayer, idStyle)

        except Exception, error:
            errMsg = '%s' % (error)
            return self.create_response(request, errMsg, HttpApplicationError)

        return self.create_response(request, response)
    
    
    def getGsSettings(self, request,datas):
        
        if not ('gs_settings' in datas):
            return self.create_response( request, 'cannot find geoserver parameters', HttpNotFound)
         
        gs_settings_json = json.loads(datas['gs_settings'])
       
        gsUrl = gs_settings_json['gs_url']
        gsUser = gs_settings_json['gs_user']
        gsPsw = gs_settings_json['gs_psw']
        
        return (gsUrl, gsUser, gsPsw)
        
        
        
        
    