import glob
import os
import zipfile

from geoserver.catalog import Catalog
import geoserver.util

from dewetra2.settings import GS_DATA_DIR, GS_WS


class GsManager:

    def __init__(self, gsUrl, gsUser, gsPsw):
        try:
            self.gsUrl = gsUrl
            gs_rest = '%s/%s' % (self.gsUrl, 'rest/')   
            self.cat = Catalog(gs_rest, username=gsUser, password=gsPsw)
            self.ws = self.cat.get_workspace(GS_WS)
            if not(self.ws):
                self.ws = self.cat.create_workspace(GS_WS, '%s/%s' % (self.gsUrl,GS_WS))

        except Exception as e:
            errMsg = 'geoserver error - %s' % (e)
            print(errMsg)
            if "This request requires HTTP authentication" in e.message:
                raise Exception("no valid authentication found for geoserver")
            else:
                raise Exception(errMsg)



    def publish_data(self, uFile):

        try:
            uFilePath = '%s%s' % (GS_DATA_DIR, uFile.name)

            with open(uFilePath, 'wb+') as destination:
                for chunk in uFile.chunks():
                    destination.write(chunk)
        except Exception as e:
            errMsg = 'cannot save uploaded file - %s' % (e)
            print(errMsg)
            raise Exception(errMsg)

        try:
            if zipfile.is_zipfile(uFilePath):
                extractDir, ext = os.path.splitext(uFilePath)

                with zipfile.ZipFile(uFilePath, 'r') as zip_ref:
                    zip_ref.extractall(extractDir)

                filesInDir = '%s/*.*' % extractDir
                shapefilePath = None
                for file in glob.glob(filesInDir):
                    if file.endswith(".shp"):
                        shapefilePath, ext = os.path.splitext(file)

                if (shapefilePath):
                    gsLayerId = self.publish_shapefile(shapefilePath)
                    data ={"gs_url" : self.gsUrl,
                           "layer_id" : gsLayerId
                           }
                    return data
                else:
                    raise Exception('not a valid shapefile!')

            else:

                gsLayerId = self.publish_geotiff(uFilePath)
                data ={"gs_url" : self.gsUrl,
                       "layer_id" : gsLayerId
                       }
                return data

        except Exception as e:
            errMsg = '%s' % (e)
            #print(errMsg)
            raise Exception(errMsg)


        return "data is published correctly!"



    def publish_shapefile(self, shapefilePath):

        try:
            shapefilesListPath = geoserver.util.shapefile_and_friends(shapefilePath)
            shapefileName = os.path.basename(shapefilePath)
        
            self.cat.create_featurestore(shapefileName, workspace=self.ws, data=shapefilesListPath)
            return '%s:%s' % (GS_WS, shapefileName)
        except Exception as e:
            print('cannot publish uploaded shapefile - %s' % (e))
            raise Exception('cannot publish uploaded shapefile - %s' % (e))


    def publish_geotiff(self, geoTiffPath):

        try:
            geoTiffFullName = os.path.basename(geoTiffPath)
            geoTiffName = os.path.splitext(geoTiffFullName)[0]
        
            self.cat.create_coveragestore(geoTiffName, workspace=self.ws, data=geoTiffPath)
            return '%s:%s' % (GS_WS, geoTiffName)
        except Exception as e:
            print('cannot publish uploaded geotiff - %s' % (e))
            raise Exception('cannot publish uploaded geotiff - %s' % (e))


    def get_styles(self):
        
        try:
            return self.cat.get_styles()
        except Exception as e:
            print('cannot get a valid list of styles - %s' % (e))
            raise Exception('cannot get a valid list of styles - %s' % (e))      

    def publish_style(self, styleFile):
        
        try:
            styleName = os.path.splitext(styleFile.name)[0]
            self.cat.create_style(name=styleName,data=styleFile)
            return styleName
        except Exception as e:
            print('cannot publish style - %s' % (e))
            raise Exception('cannot publish style - %s' % (e))   
        
        
    def set_layer_style(self, idLayer, idStyle):   
        
        layer = self.cat.get_layer(idLayer)
        if not (layer):
            print("cannot find layer '%s' in catalog" % (idLayer))
            raise Exception("cannot find layer '%s' in catalog" % (idLayer))  
        
        style = self.cat.get_style(idStyle)
        if not (style):
            print("cannot find style '%s' in catalog" % (idStyle))
            raise Exception("cannot find style '%s' in catalog" % (idStyle))   
       
        try:
            layer.default_style = style       
            self.cat.save(layer)  
            return "set style '%s' for layer '%s'" % (idStyle, idLayer)
    
        except Exception as e:
            print("cannot set style '%s' for layer '%s' - %s" % (idStyle, idLayer, e))
            raise Exception("cannot set style '%s' for layer '%s' - %s"  % (idStyle, idLayer, e))   
        
        
        
        
        
        