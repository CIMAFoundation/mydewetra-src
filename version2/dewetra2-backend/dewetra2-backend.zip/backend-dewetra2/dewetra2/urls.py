"""dewetra2 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from dewetra2.core.qweb_resources import QWebResources
from dewetra2.sentinel.resources import SentinelSensors, SentinelThr
from dewetra2.sentinel.resources_rl import SentinelSensorsRL, SentinelThrRL
from tastypie.api import Api
from dewetra2.dds.resources import DDSMapResource, DDSSerieResource
from django.conf.urls import patterns, url, include
from django.contrib import admin
from dewetra2.models import Layer, Tag, Server, LayerType, LayerGroupPermission,\
    Group, LayerCategory, UserSettings
from dewetra2.core.models_resources import LayerResource, TagResource,\
    LayerTypeResource, ServerResource, LayerDescrResource, UserSettingsResource, LayerCategoryResource,\
    LayerServerResource, ToolByUserResource, GeoScaleResource
from dewetra2.core.config_resources import  ConfigLayersNameRes, ConfigServerRes,  ConfigLayerRes, ConfigUtilLayersRes,\
    ConfigServerResFiltered
    
from dewetra2.core.auth import DewetraUserResource
from dewetra2.profiles.resources import TagStatisticsResource
from dewetra2.layers.floodproof.resources import FloodProofResource
from dewetra2.core.report_resources import ReportUtilRes
from dewetra2.core.util_resources import UtilRes
from dewetra2.algorithms.resources import AlgorithResource
from dewetra2.core.tools_resources import ToolsResource
from dewetra2.widgets.resources import WidgetRes
from dewetra2.events.resources import EventRes

dewetraApi = Api(api_name="dewapi")

dewetraApi.register(DewetraUserResource())

dewetraApi.register(DDSMapResource())
dewetraApi.register(DDSSerieResource())

dewetraApi.register(LayerResource())
dewetraApi.register(LayerServerResource())
dewetraApi.register(LayerDescrResource())
dewetraApi.register(TagResource())
dewetraApi.register(GeoScaleResource())
dewetraApi.register(LayerTypeResource())
dewetraApi.register(LayerCategoryResource())
dewetraApi.register(ServerResource())

dewetraApi.register(UserSettingsResource())

dewetraApi.register(TagStatisticsResource())

dewetraApi.register(FloodProofResource())


dewetraApi.register(ToolByUserResource())
dewetraApi.register(ToolsResource())

dewetraApi.register(ConfigServerRes())
dewetraApi.register(ConfigServerResFiltered())
dewetraApi.register(ConfigLayersNameRes())
dewetraApi.register(ConfigLayerRes())
dewetraApi.register(ConfigUtilLayersRes())

dewetraApi.register(ReportUtilRes())


dewetraApi.register(UtilRes())

dewetraApi.register(AlgorithResource())

dewetraApi.register(WidgetRes())
dewetraApi.register(EventRes())
dewetraApi.register(SentinelSensors())
dewetraApi.register(SentinelThr())
dewetraApi.register(SentinelSensorsRL())
dewetraApi.register(SentinelThrRL())
dewetraApi.register(QWebResources())

urlpatterns = patterns('',
    url(r'^admin/', include(admin.site.urls)),
    url(r'', include(dewetraApi.urls)),
)
