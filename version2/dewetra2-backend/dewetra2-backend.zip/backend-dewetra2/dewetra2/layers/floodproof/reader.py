'''
Created on 20 Jan 2016

@author: doy
'''
from datetime import datetime
import os
from time import strftime, strptime
import re
import time
from dewetra2.appsettings import FLOOD_PROOF_LAYER_ARCHIVE_DIR

class FloodProofReader(object):
    '''
    native reader for the flood proofs series
    '''    
    
    dirFormat = '%Y/%m/%d'
    runDateFormat = '%Y%m%d%H%M'
    
    baseDir = FLOOD_PROOF_LAYER_ARCHIVE_DIR

    serieDef = {
                'italy.floodproofs.probabilisticlami': 'ProbabilisticLami',
                'italy.floodproofs.gaugeobservation': 'GaugeObservation',
                }


    def __init__(self, serieId):
        '''
        Constructor
        '''
        self.path = os.path.join(self.baseDir, self.serieDef[serieId])
    
    
    def _checkFileName(self, f):
        toks = f.split('_')
        if len(toks)>=4 and len(toks[3])>=12:
            try:
                return toks[2], toks[3][:12], toks[1] #section, time, basin
            except:
                raise ValueError('invalid file name: %s'%f)
        raise ValueError('invalid file name: %s'%f)
    
    def _readFile(self, f, obj, t1, t2):
        
        maxValue = -9999
        trend = 0
        
        tStart = 0
        tStep = 0
        
        for line in open(f):
            
            if line.startswith('DateMeteoModel=') or line.startswith('SscenariosNumber') or line.startswith('Procedure='):
                continue
            
            if line.startswith('Temp.Resolution='):
                tStep = float(line.split('=')[1].strip())*60
                continue

            if line.startswith('DateStart='):
                tStart = time.mktime(strptime(line.split('=')[1].strip(), self.runDateFormat))
                continue
            
            toks = [s for s in line.split(' ') if s and s!= '\n']
            #build indexes
            i1 = int((t1-tStart) / tStep)
            if i1<0: i1=0
            
            toks = toks[i1:]
            
            found = False            
            for tok in toks:
                v = float(tok)
                if maxValue<v: 
                    maxValue=v
                    trend = 0
                    found = True
            if found and len(toks)>1:
                dv = float(toks[-1])-float(toks[-2])
                trend = 1 if dv > 0 else -1 if dv < 0 else 0            
        
        obj['stats'] = {
                        'maxvalue': maxValue,
                        'trend': trend
                        }
    
    def read(self, features, fidField, t1, t2):
        
        sections = {}
        useCompositeFid = False 
        for f in features:
            fid = f['properties'][fidField]
            toks = re.split(',|;', fid)
            if len(toks)==1:
                
                #skip section with non composite field if already found one with compsite field
                if useCompositeFid: continue 
                
                fidValue = fid
            else:                
                fidValue = '%s,%s'%(toks[0].strip(),toks[1].strip())
                useCompositeFid = True
            sections[fidValue] = {}
        
        t = t2
        while t>=t1-86400:
            d = datetime.fromtimestamp(t)
            dayDir = os.path.join(self.path, d.strftime(self.dirFormat))
            if os.path.isdir(dayDir):
                for f in os.listdir(dayDir):
                    try:
                        theFile = os.path.join(dayDir, f)
                        if os.path.isfile(theFile):
                            section, runDate, basin = self._checkFileName(f)
                            fidValue = '%s,%s'%(basin,section) if useCompositeFid else section
                            
                            runTime = time.mktime(strptime(runDate, "%Y%m%d%H%M"))
                            
                            if runTime < t1: continue
                            
                            if fidValue in sections and ('stats' not in sections[fidValue] or runDate>sections[fidValue]['stats']['run']):
                                self._readFile(theFile, sections[fidValue], t1, t2)
                                sections[fidValue]['stats']['run'] = runDate  
                    except:
                        pass
            t-=86400
            
        for f in features:
            fid = f['properties'][fidField]
            
            toks = re.split(',|;', fid)
            fidValue = fid if len(toks)==1 else '%s,%s'%(toks[0].strip(),toks[1].strip())
            if 'stats' in sections[fidValue]:
                f['properties']['maxvalue']  = sections[fidValue]['stats']['maxvalue']
                f['properties']['trend']  = sections[fidValue]['stats']['trend']
                f['properties']['run']  = sections[fidValue]['stats']['run']
            else:
                f['properties']['maxvalue']  = -9999
                f['properties']['trend']  = -9999
                

