'''
Created on 10 Dec 2015

@author: doy
'''
from acroweb.core.resources import AcrowebResource, URLHelper
from dewetra2.models import Server
from dewetra2.core.exceptions import DewetraError
from dewetra2.dds.dds_client import DDSSerieClient, DDSError
import time
import dateutil
from dewetra2.layers.floodproof.reader import FloodProofReader
from tastypie.http import HttpUnauthorized
from dewetra2.dds import DDSClientRouter

class FloodProofResource(AcrowebResource):
    '''
    resource for flood proof layer management
    '''

    class Meta():
        resource_name = 'floodproof'
        
    def getMyUrl(self):
        return [
                URLHelper('/layer/%s/%s/%s'%(self.strParam('server'), self.strParam('serie'), self.intParam('time')), 'layer'),
                URLHelper('/layer/%s/%s'%(self.strParam('server'), self.strParam('serie')), 'layer'),
                URLHelper('/compatibles/%s/%s'%(self.strParam('server'), self.strParam('serie')), 'compatibles'),
                ]
    
    def _getClient(self, ddsId):
        return DDSClientRouter().get_dds_serie_client(ddsId)
                
    def layer(self, request, **kwargs):
        self.method_check(request, allowed=['get'])
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
         
        ddsId = kwargs['server']
        serieId = kwargs['serie']
        if 'time' in kwargs:
            t2 = int(kwargs['time'])
        else:
            t2 = int(time.time())
        t1 = t2-43200 #12 hours ago
        
        dds = Server.objects.get(pk=ddsId)
        if dds is None: raise DewetraError('DDS server not found')
        
        ddsClient = self._getClient(kwargs['server'])
         
        features = ddsClient.featuresDDS(serieId, t1, t2)

        return self.create_response(request, features)
        

    def layerNative(self, request, **kwargs):
        self.method_check(request, allowed=['get'])      
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)  
        
        ddsId = kwargs['server']
        serieId = kwargs['serie']
        if 'time' in kwargs:
            t2 = int(kwargs['time'])
        else:
            t2 = int(time.time())
        
        dds = Server.objects.get(pk=ddsId)
        if dds is None: raise DewetraError('DDS server not found')
        #ddsClient = DDSSerieClient(dds.url, dds.user, dds.password)
        ddsClient = self._getClient(ddsId)
        
        props = ddsClient.properties(serieId)
        features = ddsClient.features(dds, props)
        
        t1 = t2-43200 #12 hours ago
        
        fpr = FloodProofReader(serieId)

        fpr.read(features['features'], props['fidField'], t1, t2)
        
        return self.create_response(request, features)

        
    def compatibles(self, request, **kwargs):
        self.method_check(request, allowed=['get'])        
        
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
        
        ddsId = kwargs['server']
        serieId = kwargs['serie']
        
        #dds = Server.objects.get(pk=ddsId)
        #if dds is None: raise DewetraError('DDS server not found')
        #ddsClient = DDSSerieClient(dds.url, dds.user, dds.password)
        ddsClient = self._getClient(ddsId)
        
        compatibleSeries = ddsClient.compatibles(serieId)
        
        if compatibleSeries is None:
            props = ddsClient.properties(serieId)
             
            supportedSeries = ddsClient.supported();        
            compatibleSeries = []        
            for s in supportedSeries:
                tmpProps = ddsClient.properties(s)
                if props['layer'] == tmpProps['layer']:
                     compatibleSeries.append(tmpProps)
             
        
        return self.create_response(request, compatibleSeries)
        
        
        
        
        
        
        
