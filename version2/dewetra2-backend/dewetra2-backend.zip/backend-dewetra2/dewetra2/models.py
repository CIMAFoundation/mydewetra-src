from django.db import models
from django.contrib.auth.models import User
from pandas import describe_option



#===============================================================================
# dds management models
#===============================================================================

class Server(models.Model):
    name = models.CharField(max_length=255)
    descr = models.TextField(blank=True)
    url = models.CharField(max_length=255)
    user = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    def __unicode__(self):
        return self.descr

#===============================================================================
# layers management models
#===============================================================================

class LayerType(models.Model):
    name = models.CharField(max_length=255)
    code = models.CharField(max_length=255)
    def __unicode__(self):
        return self.name

class Tag(models.Model):
    name = models.CharField(max_length=255)
    descr = models.TextField(blank=True)
    icon = models.CharField(max_length=255, null=True, blank=True)
    def __unicode__(self):
        return self.descr

class Group(models.Model):
    hierarchy = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    def __unicode__(self):
        return '%s (%s)'%(self.name, self.hierarchy)

class Path(models.Model):
    hierarchy = models.CharField(max_length=255)
    def __unicode__(self):
        return self.hierarchy

class LayerCategory(models.Model):
    name = models.CharField(max_length=255)
    def __unicode__(self):
        return self.name

class GeoScale(models.Model):
    name = models.CharField(max_length=255)
    descr = models.TextField(blank=True)
    def __unicode__(self):
        return self.descr

#===============================================================================
# Event
#===============================================================================
class Event(models.Model):
    name = models.CharField(max_length=255, unique = True)
    description = models.CharField(max_length=255)
    date = models.DateTimeField()
    lat = models.FloatField()
    lon = models.FloatField()
    data_type = models.CharField(max_length=255)
    hazard = models.CharField(max_length=255)
    def __unicode__(self):
        return self.description

class Layer(models.Model):
    dataid = models.CharField(max_length=255) #identifier of the wms layer for a static layer and identifier of the data in dds for a dynamic layer
    name = models.CharField(max_length=255)
    descr = models.TextField(blank=True)    
    thumb = models.CharField(max_length=255, blank=True)
    metadata = models.TextField(blank=True)
    metadataurl = models.CharField(max_length=255, blank=True)
    lonw = models.FloatField()
    lone = models.FloatField()
    lats = models.FloatField()
    latn = models.FloatField()
    type = models.ForeignKey(LayerType)
    server = models.ForeignKey(Server)
    tags = models.ManyToManyField(Tag)
    groups = models.ManyToManyField(Group, related_name = 'layers')
    path = models.ForeignKey(Path, null=True)
    pathdrr = models.ForeignKey(Path, null=True, blank = True, related_name='pathdrr')
    category = models.ForeignKey(LayerCategory)
    icon = models.CharField(max_length=255, null=True, blank=True)
    source = models.CharField(max_length=255, blank=True, null=True, default=None)
    customprops = models.TextField(blank=True, null=True, default=None)
    geoscale = models.ForeignKey(GeoScale, null=True, default=None)
    event = models.ForeignKey(Event, null = True, blank = True, default = None)
    def __unicode__(self):
#        return '%s - %s (%s)'%(self.dataid, self.descr,self.category.name)
        return '%s %s (%s) (%s)'%(self.name, self.dataid,self.type.name, self.category.name)

#===============================================================================
# permission management models
#===============================================================================
 
class LayerGroupPermission(models.Model):
    user = models.ForeignKey(User, unique=True)
    groups = models.ManyToManyField(Group)
    def __unicode__(self):
        return '%s'%(self.user)
     
class UserSettings(models.Model):
    user = models.ForeignKey(User, unique=True)
    stationgroup = models.CharField(max_length=255)
    def __unicode__(self):
        return '%s - %s'%(self.user,self.stationgroup)
      
#===============================================================================
# profile models
#===============================================================================

class TagStatistics(models.Model):
    acuid = models.CharField(max_length=255)
    tag = models.ForeignKey(Tag)
    count = models.BigIntegerField(default=0)

#===============================================================================
# tool model
#===============================================================================
class Tool(models.Model):
    dataid = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    descr = models.TextField(blank=True)   
    config = models.TextField(blank=True) 
    manager = models.CharField(max_length=255)
    icon = models.CharField(max_length=255, null=True, blank=True)
    users = models.ManyToManyField(User)
     
    def __unicode__(self):
        return '%s - %s (%s)'%(self.dataid, self.name, self.descr)
    
#===============================================================================
# widget
#===============================================================================
class Widget(models.Model):
    name = models.CharField(max_length=255, unique=True)
    layer = models.ForeignKey(Layer)
    mode = models.CharField(max_length=255, null=True)
    envparams = models.TextField(null=True)
    alwaysupdate = models.BooleanField(default=False)
      
      
class WidgetPropAttr(models.Model):
    name = models.CharField(max_length=255)
    value = models.CharField(max_length=255)
    widget = models.ForeignKey(Widget, related_name='props')