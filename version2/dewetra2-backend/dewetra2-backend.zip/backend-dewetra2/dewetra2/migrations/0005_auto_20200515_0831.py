# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('dewetra2', '0004_auto_20200514_1931'),
    ]

    operations = [
        migrations.AlterField(
            model_name='widget',
            name='name',
            field=models.CharField(unique=True, max_length=255),
        ),
    ]
