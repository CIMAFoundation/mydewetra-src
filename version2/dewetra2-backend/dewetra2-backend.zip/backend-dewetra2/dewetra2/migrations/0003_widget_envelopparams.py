# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('dewetra2', '0002_auto_20200514_1539'),
    ]

    operations = [
        migrations.AddField(
            model_name='widget',
            name='envelopparams',
            field=models.TextField(null=True),
            preserve_default=True,
        ),
    ]
