# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('dewetra2', '0007_widget_alwaysupdate'),
    ]

    operations = [
        migrations.CreateModel(
            name='Event',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(unique=True, max_length=255)),
                ('description', models.CharField(max_length=255)),
                ('date', models.DateTimeField(auto_now=True)),
                ('lat', models.FloatField()),
                ('lon', models.FloatField()),
                ('data_type', models.CharField(max_length=255)),
                ('hazard', models.CharField(max_length=255)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='layer',
            name='event',
            field=models.ForeignKey(default=None, to='dewetra2.Event', null=True),
            preserve_default=True,
        ),
    ]
