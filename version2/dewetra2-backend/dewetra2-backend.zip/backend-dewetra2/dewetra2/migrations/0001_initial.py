# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='GeoScale',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255)),
                ('descr', models.TextField(blank=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Group',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('hierarchy', models.CharField(max_length=255)),
                ('name', models.CharField(max_length=255)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Layer',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('dataid', models.CharField(max_length=255)),
                ('name', models.CharField(max_length=255)),
                ('descr', models.TextField(blank=True)),
                ('thumb', models.CharField(max_length=255, blank=True)),
                ('metadata', models.TextField(blank=True)),
                ('metadataurl', models.CharField(max_length=255, blank=True)),
                ('lonw', models.FloatField()),
                ('lone', models.FloatField()),
                ('lats', models.FloatField()),
                ('latn', models.FloatField()),
                ('icon', models.CharField(max_length=255, null=True, blank=True)),
                ('source', models.CharField(default=None, max_length=255, null=True, blank=True)),
                ('customprops', models.TextField(default=None, null=True, blank=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='LayerCategory',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='LayerGroupPermission',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('groups', models.ManyToManyField(to='dewetra2.Group')),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL, unique=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='LayerType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255)),
                ('code', models.CharField(max_length=255)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Path',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('hierarchy', models.CharField(max_length=255)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Server',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255)),
                ('descr', models.TextField(blank=True)),
                ('url', models.CharField(max_length=255)),
                ('user', models.CharField(max_length=255)),
                ('password', models.CharField(max_length=255)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Tag',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255)),
                ('descr', models.TextField(blank=True)),
                ('icon', models.CharField(max_length=255, null=True, blank=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='TagStatistics',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('acuid', models.CharField(max_length=255)),
                ('count', models.BigIntegerField(default=0)),
                ('tag', models.ForeignKey(to='dewetra2.Tag')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Tool',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('dataid', models.CharField(max_length=255)),
                ('name', models.CharField(max_length=255)),
                ('descr', models.TextField(blank=True)),
                ('config', models.TextField(blank=True)),
                ('manager', models.CharField(max_length=255)),
                ('icon', models.CharField(max_length=255, null=True, blank=True)),
                ('users', models.ManyToManyField(to=settings.AUTH_USER_MODEL)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='UserSettings',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('stationgroup', models.CharField(max_length=255)),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL, unique=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='layer',
            name='category',
            field=models.ForeignKey(to='dewetra2.LayerCategory'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='layer',
            name='geoscale',
            field=models.ForeignKey(default=None, to='dewetra2.GeoScale', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='layer',
            name='groups',
            field=models.ManyToManyField(related_name=b'layers', to='dewetra2.Group'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='layer',
            name='path',
            field=models.ForeignKey(to='dewetra2.Path', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='layer',
            name='server',
            field=models.ForeignKey(to='dewetra2.Server'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='layer',
            name='tags',
            field=models.ManyToManyField(to='dewetra2.Tag'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='layer',
            name='type',
            field=models.ForeignKey(to='dewetra2.LayerType'),
            preserve_default=True,
        ),
    ]
