
from acroweb.core.resources import AcrowebResource, URLHelper
from dewetra2.core.resources import DewetraResourceMeta
from tastypie.http import HttpUnauthorized, HttpNotFound
from dewetra2.models import Widget
from dewetra2.appsettings import WIDGETS_DATA_DIR
import os
import json
from wsgiref.util import FileWrapper
from django.http.response import HttpResponse


class WidgetRes(AcrowebResource):
    
    class Meta(DewetraResourceMeta):
        resource_name = 'widgets'
        
    def getMyUrl(self):
        return [
                URLHelper('/list', 'widgets_list'),
#                 URLHelper('/widget/%s' %(self.strParam('widget_id')), 'widget_details'),
                URLHelper('/img/%s' %(self.strParam('widget_id')), 'widget_image'),
                ]
    
    def __widget_data(self, widget):
        res = []
        img_paths = {}
        widget_data_dir = os.path.join(WIDGETS_DATA_DIR, '%s' % widget.id)
        folders = [f for f in os.listdir(widget_data_dir) if os.path.isdir(os.path.join(widget_data_dir, f))]
        for f in folders:
            img_file = os.path.join(widget_data_dir, f, 'img.png')
            data_file = os.path.join(widget_data_dir, f, 'data.json')
            if os.path.exists(img_file) and os.path.exists(data_file):
                with open(data_file) as fp:
                    data = json.load(fp)
                res.append(data)
                img_paths[data['id']] = img_file
        return res, img_paths
    
    def widgets_list(self, request, **kwargs):        
 
#         if request.user is None or not request.user.is_authenticated(): 
#             return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['get'])
        res = []
        widgets = Widget.objects.all()
        for widget in widgets:
            data, _ = self.__widget_data(widget)
            
            attrs = {}
            for attr in widget.props.all():
                attrs[attr.name] = attr.value
             
            res.append({
                'id': widget.id,
                'name': widget.name,
                'dataid': widget.layer.dataid,
                'attr': attrs,
                'data': data
                })
        return self.create_response(request, res)
        

#     def widget_details(self, request, **kwargs):        
#  
#         if request.user is None or not request.user.is_authenticated(): 
#             return self.create_response(request, 'not authenticated', HttpUnauthorized)   
#         
#         self.method_check(request, allowed=['get'])
#         
#         # TODO return all the widget details
        
    def widget_image(self, request, **kwargs):        
 
#         if request.user is None or not request.user.is_authenticated(): 
#             return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['get'])
        
        if Widget.objects.filter(pk=kwargs['widget_id']).exists():
            data, img_paths = self.__widget_data(Widget.objects.get(pk=kwargs['widget_id']))
            
            if len(data)==0 or len(img_paths)==0:
                return self.create_response(request, 'data not found', HttpNotFound)
            
            data_id = request.GET['dataid'] if 'dataid' in request.GET else data[0]['id']
            
            img = img_paths[data_id]
            
            response = HttpResponse(FileWrapper(open(img, 'r')), content_type='image/png')
            #response['Content-Disposition'] = 'attachment; filename=%s' % theFileName
            response['Content-Length'] = os.stat(img).st_size
    
            return response
            
# 
# 
# if __name__ == '__main__':
#     widget_id = 94
#     res = []
#     img_paths = {}
#     widget_data_dir = os.path.join(WIDGETS_DATA_DIR, '%s' % widget_id)
#     folders = [f for f in os.listdir(widget_data_dir) if os.path.isdir(os.path.join(widget_data_dir, f))]
#     for f in folders:
#         img_file = os.path.join(widget_data_dir, f, 'img.png')
#         data_file = os.path.join(widget_data_dir, f, 'data.json')
#         if os.path.exists(img_file) and os.path.exists(data_file):
#             with open(data_file) as fp:
#                 data = json.load(fp)
#             res.append(data)
#             img_paths[data['id']] = img_file
#             
#             
#             
#             
#     print res
#     
#     print img_paths
