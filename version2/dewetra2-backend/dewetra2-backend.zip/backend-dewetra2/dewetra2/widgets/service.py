'''
Created on May 14, 2020

@author: doy
'''
import django
from _ast import Is
import time
import requests
import os
import traceback
django.setup()


import json
import threading

from acroweb.message.rabbit import Dispatcher
from dewetra2.appsettings import WIDGET_RABBIT_NOTIFY_HOST, \
    WIDGET_RABBIT_NOTIFY_USER, WIDGET_RABBIT_NOTIFY_PASSWORD, \
    WIDGET_RABBIT_NOTIFY_VHOST, WIDGET_RABBIT_NOTIFY_EXCHANGE, \
    WIDGET_DDS_REQUET_URL_TEMPLATE, WIDGET_DDS_REQUET_URL_EXTRA_PARAMS,\
    WIDGETS_DATA_DIR, WIDGET_DDS_WEBSOCKET
from dewetra2.models import Widget
from dewetra2.dds import DDSClientRouter
import websocket

class WidgetService(threading.Thread):
    '''
    cbe monitoring class
    '''
  
    def __init__(self):
        '''
        constructor
        '''
        super(WidgetService, self).__init__()
        
        self.dds_client_router = DDSClientRouter()
        try:
            self.dispatcher = Dispatcher(WIDGET_RABBIT_NOTIFY_HOST, 
                                         WIDGET_RABBIT_NOTIFY_USER, 
                                         WIDGET_RABBIT_NOTIFY_PASSWORD, 
                                         WIDGET_RABBIT_NOTIFY_VHOST,
                                         WIDGET_RABBIT_NOTIFY_EXCHANGE)
        except:
            self.dispatcher = None
            print("WIDGET SERVICE ERROR: unable to connect to rabbit for client notification dispach")
        

    def __connect(self):
        print('WIDGET SERVICE: connecting to acquisition websocket')
        
        self.ws = websocket.WebSocketApp(WIDGET_DDS_WEBSOCKET, on_message=lambda ws, message:self.on_message(ws, message), 
            on_error=lambda ws, error:self.on_error(ws, error), 
            on_close=lambda ws:self.on_close(ws))
        
        self.ws.run_forever()

    def run(self):
        
        #updtaing all widgets
        widgets = Widget.objects.all()
        for widget in widgets:
            self.update(widget)
        
        #connection to websocket
        websocket.enableTrace(True)
        self.__connect()


    def on_error(self, ws, error):
        print('WIDGET SERVICE: websocket error: %s'%error)
    
    def on_close(self, ws):
        print('WIDGET SERVICE: websocket closed. reconnectiong in 10 seconds')
        time.sleep(10)
        self.__connect()     

    def download_image(self, widget, av, properties, t1, t2, dds_client, pos):
        result_dir = os.path.join(WIDGETS_DATA_DIR, '%s' % widget.id, '%s' % pos)
        file_path = os.path.join(result_dir, 'img.png')
        data_file_path = os.path.join(result_dir, 'data.json')
        
        #check if he layer is up to date
        if not widget.alwaysupdate and os.path.exists(data_file_path) and os.path.exists(file_path):
            with open(data_file_path, 'r') as f:
                current_av = json.loads(f.read())
                if av == current_av:
                    print('WIDGET SERVICE:\t\tdata up to date!')
                    return
                
        
        if not os.path.exists(result_dir): os.makedirs(result_dir)
        
        layer = dds_client.publish(properties, av, t1, t2)
        
        evelope_params = widget.envparams if widget.envparams is not None else WIDGET_DDS_REQUET_URL_EXTRA_PARAMS
        url = WIDGET_DDS_REQUET_URL_TEMPLATE % (widget.layer.server.url, layer['layerid'], evelope_params)
        r = requests.get(url)
        tmp_file_path = os.path.join(result_dir, '_img.png')
        with open(tmp_file_path, 'wb') as f:
            f.write(r.content)
        os.rename(tmp_file_path, file_path)
        with open(data_file_path, 'w') as f:
            f.write(json.dumps(av))

    def update(self, widget):
        try:
            print 'WIDGET SERVICE: updating %s'%widget.name
            
            dds_client = self.dds_client_router.get_dds_map_client(widget.layer.server.id)
            
            #get and update properties
            print 'WIDGET SERVICE:\tproperties...'
            properties = dds_client.properties(widget.layer.dataid)
            widget_attrs_rows = widget.props.all()
            widget_attrs = {}
            for row in widget_attrs_rows:
                widget_attrs[row.name] = row.value
            for attr in properties['layerProperties']['attributes']:
                if attr['name'] in widget_attrs:
                    if isinstance(attr['entries'], dict):
                        if attr['entries']['value'] == widget_attrs[attr['name']]:
                            attr['selectedEntry'] = attr['entries']
                    else:
                        for entry in attr['entries']:
                            if entry['value'] == widget_attrs[attr['name']]:
                                attr['selectedEntry'] = entry
                                break;
            
            #availability
            print 'WIDGET SERVICE:\tavailability...'
            t2 = int(time.time())
            t1 = t2-86400
            availability = dds_client.availability(properties, t1, t2)
            
            
            #publish layer
            if widget.mode == 'all':
                pos = 0
                for av in availability:
                    print 'WIDGET SERVICE:\tpublishing %s...'%av
                    self.download_image(widget, av, properties, t1, t2, dds_client, pos)
                    pos+=1
            else:
                av = availability[0]
                print 'WIDGET SERVICE:\tpublishing %s...'%av
                self.download_image(widget, av, properties, t1, t2, dds_client, 0)
        
        except Exception as e:
            print('WIDGET SERVICE: Error updating %s: %s'%(widget.name, str(e)))

    def on_message(self, ws, message):        
#         myalert_logger.debug(f'message from {routing_key}: {body}')        
        try:
            
            print message
            toks = message.split(';')
            if len(toks) == 2:
                data_id = toks[1]
                 
                print 'WIDGET SERVICE: managing widget update for: %s'%data_id
                 
                widgets = Widget.objects.filter(layer__dataid=data_id)
                if widgets.exists():
                     
                    for widget in widgets:
                        self.update(widget)
                         
                    if self.dispatcher: self.dispatcher.send('dashboard.widget', {'data_id': data_id})
            else:
                print('WIDGET SERVICE: received invalid acquisition message: %s'%message)
                
        except Exception as e:
            traceback.print_exc()
#             print('WIDGET_SERVICE: ERROR managing message %s'%str(body))
       

if __name__ == '__main__':
 
    WidgetService().start()


     
