'''
Created on 19 Nov 2015

@author: doy
'''
from acroweb.core.resources import URLHelper
import requests
from dewetra2.sentinel import SentinelReource


class SentinelSensorsRL(SentinelReource):
    
    def __init__(self):
        self.api_base_name = 'rlsensors'

    class Meta():
        resource_name = 'sentinel/rlsensors'
        
    def getMyUrl(self):
        return [
                URLHelper('/layer/%s/%s/%s'%(self.strParam('sensor_group'), self.strParam('thr_group'), self.strParam('variable')), 'layer'),
                ]
        
    def layer(self, request, **kwargs):
        self._check_request(request)
        
        sensor_group = kwargs['sensor_group']
        #TODO: check if sensor group is allowed for user
        variable = int(kwargs['variable'])
        thr_group = kwargs['thr_group']
        sentinel_url = '%s/%s/%s'%(
            requests.utils.quote(sensor_group),
            requests.utils.quote(thr_group),
            requests.utils.quote(variable)
            )
        
        if 'ts' in request.GET:
            sentinel_url = '%s?ts=%s'%(sentinel_url, request.GET['ts'])

        return self._sentinel_request_get(request, sentinel_url)




class SentinelThrRL(SentinelReource):
    
    def __init__(self):
        self.api_base_name = 'rlthresholds'

    class Meta():
        resource_name = 'sentinel/rlthresholds'
        
    def getMyUrl(self):
        return [
                URLHelper('/bysensor/%s/%s'%(self.strParam('sensor'), self.strParam('db')), 'by_sensor'),
                URLHelper('/modifications/%s'%(self.strParam('thr_id')), 'modifications'),
                URLHelper('/newthr', 'new_thr'),
                URLHelper('/updatethr/%s'%(self.strParam('thr_id')), 'update_thr'),
                URLHelper('/deletethr/%s'%(self.strParam('thr_id')), 'delete_thr'),
                ]


    def by_sensor(self, request, **kwargs):
        self._check_request(request)
        
        sensor_id = kwargs['sensor']
        db_id = kwargs['db']
        sentinel_url = 'bysensor/%s/%s'%(
            sensor_id,
            db_id
            )
        
        return self._sentinel_request_get(request, sentinel_url)


    def modifications(self, request, **kwargs):
        self._check_request(request)
        
        thr_id = kwargs['thr_id']
        sentinel_url = 'modifications/%s'%(
            thr_id
            )
        
        return self._sentinel_request_get(request, sentinel_url)                


    def new_thr(self, request, **kwargs):
        self._check_request(request, ['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        return self._sentinel_request_post(request, 'thr', data)

    def update_thr(self, request, **kwargs):
        self._check_request(request, ['patch'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        thr_id = kwargs['thr_id']
        sentinel_url = 'thr/%s'%(
            thr_id
            )
        return self._sentinel_request_patch(request, sentinel_url, data)

    def delete_thr(self, request, **kwargs):
        self._check_request(request, ['delete'])
        thr_id = kwargs['thr_id']
        sentinel_url = 'thr/%s'%(
            thr_id
            )
        return self._sentinel_request_delete(request, sentinel_url)
