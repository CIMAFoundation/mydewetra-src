from dewetra2.appsettings import SENTINEL_SERVICE_URL
from acroweb.core.resources import AcrowebResource
from django.http import HttpResponse
from tastypie.http import HttpUnauthorized, HttpApplicationError,\
    HttpNotImplemented
import requests 

class SentinelReource(AcrowebResource):
    
    def __init__(self):
        self.api_base_name = ''

    def __build_url(self, url_path):
        sentinel_url = '%s/%s/%s/'%(SENTINEL_SERVICE_URL, self.api_base_name, url_path)
        print(sentinel_url)
        return sentinel_url

    def __build_response(self, response):
        return HttpResponse(
                content=response.content,
                status=response.status_code,
                content_type=response.headers['Content-Type']
            )

    def _sentinel_request_get(self, request, url_path):
        try:
            response = requests.get(self.__build_url(url_path))
        except requests.ConnectionError as e:
            return self.create_response(request, "sentinel service connection error", HttpApplicationError)
        except Exception as e:
            return self.create_response(request, "sentinel service error: %s"%e.message, HttpApplicationError)
        return self.__build_response(response)

    def _sentinel_request_post(self, request, url_path, body):
        try:
            response = requests.post(self.__build_url(url_path),
                              headers = {'content-type': 'application/json'},
                              data=body)
        except requests.ConnectionError as e:
            return self.create_response(request, "sentinel service connection error", HttpApplicationError)
        except Exception as e:
            return self.create_response(request, "sentinel service error: %s"%e.message, HttpApplicationError)
        return self.__build_response(response)


    def _sentinel_request_patch(self, request, url_path, body):
        try:
            response = requests.patch(self.__build_url(url_path),
                              headers = {'content-type': 'application/json'},
                              data=body)
        except requests.ConnectionError as e:
            return self.create_response(request, "sentinel service connection error", HttpApplicationError)
        except Exception as e:
            return self.create_response(request, "sentinel service error: %s"%e.message, HttpApplicationError)
        return self.__build_response(response)


    def _sentinel_request_delete(self, request, url_path):
        try:
            response = requests.delete(self.__build_url(url_path))
        except requests.ConnectionError as e:
            return self.create_response(request, "sentinel service connection error", HttpApplicationError)
        except Exception as e:
            return self.create_response(request, "sentinel service error: %s"%e.message, HttpApplicationError)
        return self.__build_response(response)

    def _check_request(self, request, allowed_methods = ['get']):
        self.method_check(request, allowed=allowed_methods)
        # if request.user is None:
        #     return self.create_response(request, "permission denied", HttpUnauthorized)
