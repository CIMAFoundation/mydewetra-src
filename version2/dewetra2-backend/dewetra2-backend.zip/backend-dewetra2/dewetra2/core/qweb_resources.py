from acroweb.core.resources import AcrowebResource, URLHelper
from dewetra2.core.resources import DewetraResourceMeta
import requests
import pandas as pd
from tastypie.http import HttpApplicationError, HttpUnauthorized
from datetime import datetime, timedelta
import json
from django.http.response import HttpResponse
URL_QWEB = 'https://qweb.hightek.it/'

TOKEN_QWEB = '4a89b463e78f2a522700562c42392da6583f4dc37a5d36ea14923de2d82af1e6'

class QWebResources(AcrowebResource):
    class Meta(DewetraResourceMeta):
        resource_name = 'qweb'
    
    def getMyUrl(self):
        return [
            URLHelper('/listmissions/%s/%s' %(self.strParam('from'), self.strParam('to')), 'listmissions'),
            URLHelper('/getmission/%s' %(self.strParam('mission')), 'getmission')
            ]
            
    def listmissions(self, request, **kwargs):    
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
		
        self.method_check(request, allowed=['get'])
        date_from = datetime.strptime(kwargs['from'], "%Y-%m-%d")
        date_to = datetime.strptime(kwargs['to'], "%Y-%m-%d")
        
        delta = date_to - date_from   # returns timedelta
        missions = []
        for i in range(delta.days + 1):
            day = date_from + timedelta(days=i)
            day_string = day.strftime("%Y-%m-%d")
            resp = requests.get(URL_QWEB+'api/listMissions/'+day_string+'/'+TOKEN_QWEB)
            elements = json.loads(resp.content)
            if(elements["status"] == "OK" and elements["missionsCount"]> 0):
                for mission in elements["missions"]:
                    missions.append(mission)
        return self.create_response(request, missions)
       
    def getmission(self,request,**kwargs):
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)
		
        self.method_check(request, allowed=['get'])
        resp = requests.get(URL_QWEB+'api/getMission/'+kwargs["mission"]+'/'+TOKEN_QWEB)
        mission = json.loads(resp.content)["original"]
        
        properties = mission["mission"]
        coords = []
        for det in mission["detections"]:
            lat =  det["positionData"]["LATITUDE"] 
            lon =  det["positionData"]["LONGITUDE"]
            
            coords.append([lon,lat])
        feature = {
            'type': 'Feature',
            'geometry': {
                'type': 'LineString',
                'coordinates': coords
            },
            'properties': properties
        }
        geojson = {
            'type': 'FeatureCollection',
            'features': [
                feature
            ]
        }
        
        return self.create_response(request, geojson)
            