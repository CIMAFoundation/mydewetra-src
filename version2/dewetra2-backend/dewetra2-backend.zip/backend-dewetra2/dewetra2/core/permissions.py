from tastypie.authorization import Authorization
from tastypie.exceptions import Unauthorized
from dewetra2.models import LayerGroupPermission, Tool, Layer
from django.db.models import Q


class DewetraBaseAuthorization(Authorization):
        
    def read_list(self, object_list, bundle):                
        raise Unauthorized("operation not allowd")    
    
    def read_detail(self, object_list, bundle):
        raise Unauthorized("operation not allowd")
    
    def create_list(self, object_list, bundle):
        raise Unauthorized("operation not allowd")
    
    def create_detail(self, object_list, bundle):
        raise Unauthorized("operation not allowd")

    def update_list(self, object_list, bundle):
        raise Unauthorized("operation not allowd")
    
    def update_detail(self, object_list, bundle):
        raise Unauthorized("operation not allowd")

    def delete_list(self, object_list, bundle):
        raise Unauthorized("operation not allowed")

    def delete_detail(self, object_list, bundle):
        raise Unauthorized("operation not allowed")


#===============================================================================
# authorization for layers
#===============================================================================
class DewetraLayerAuthorization(DewetraBaseAuthorization):
        

    def _getFilteredLayersByUser(self, object_list, bundle):
        user = bundle.request.user
        username = 'anonymous'
        if user is not None:
            username = user.username #read all the groups the user access
        try:
            row = LayerGroupPermission.objects.get(user__username=username)
            gids = [g.id for g in row.groups.all()]
        except:
            gids = []
        
        return object_list.filter(Q(groups__id__in=gids)).distinct()
    
    def read_list(self, object_list, bundle):        
        return self._getFilteredLayersByUser(object_list, bundle)
    
    def read_detail(self, object_list, bundle):
        return True if self._getFilteredLayersByUser(object_list, bundle).exists() else False
    
    def create_list(self, object_list, bundle):
        return self._getFilteredLayersByUser(object_list, bundle)
    
    def create_detail(self, object_list, bundle):
         return True if self._getFilteredLayersByUser(object_list, bundle).exists() else False

    def update_list(self, object_list, bundle):
        return self._getFilteredLayersByUser(object_list, bundle)
    
    def update_detail(self, object_list, bundle):
        return True if self._getFilteredLayersByUser(object_list, bundle).exists() else False

    def delete_list(self, object_list, bundle):
        return self._getFilteredLayersByUser(object_list, bundle)

    def delete_detail(self, object_list, bundle):
        return True if self._getFilteredLayersByUser(object_list, bundle).exists() else False
    
    
    
#===============================================================================
# authorization for user settings
#===============================================================================
class DewetraUserSettingsAutorization(Authorization):    
    
    def read_list(self, object_list, bundle):        
        
        user=bundle.request.user
        username = 'anonymous'
        if user is not None: username = user.username
        
        #read all the groups the user access        
        return object_list.filter(user__username=username)
    
    
#===============================================================================
# authorization for groups
#===============================================================================  
class DewetraGroupAuthorization(DewetraBaseAuthorization):
        

    def _getFilteredGroupsByUser(self, object_list, bundle):
        user = bundle.request.user
        username = 'anonymous'
        if user is not None:
            username = user.username #read all the groups the user access
        try:
            row = LayerGroupPermission.objects.get(user__username=username)
            gids = [g.id for g in row.groups.all()]
        except:
            gids = []
        
        return object_list.filter(Q(id__in=gids)).distinct()
    
    def read_list(self, object_list, bundle):        
        return self._getFilteredGroupsByUser(object_list, bundle)
    

#===============================================================================
# authorization for tools
#===============================================================================
class DewetraToolAutorization(DewetraBaseAuthorization):
        

    def _getFilteredToolsByUser(self, object_list, bundle):
        user = bundle.request.user
        uname = 'anonymous'
        if user is not None:
            uname = user.username #read all the tools the user access
        try:
            toolid = Tool.objects.filter(users__username=uname)
        except:
            toolid = []
        
        return toolid
    
    def read_list(self, object_list, bundle):        
        return self._getFilteredToolsByUser(object_list, bundle)
  

#===============================================================================
# authorization for tools
#===============================================================================
class DewetraServerAutorization(DewetraLayerAuthorization):

    def _getFilteredServersByUser(self, object_list, bundle):
        try:
            layers  = DewetraLayerAuthorization._getFilteredLayersByUser(self, Layer.objects.all(), bundle)
            server_ids = set([l.server.id for l in layers])
        except:
            server_ids = []
                    
        return object_list.filter(Q(id__in=server_ids)).distinct()
    
    
    def read_list(self, object_list, bundle):        
        return self._getFilteredServersByUser(object_list, bundle)
    
