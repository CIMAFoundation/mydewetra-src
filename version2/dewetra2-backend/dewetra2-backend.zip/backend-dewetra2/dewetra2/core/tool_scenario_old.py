import numpy
from urllib import urlencode
from owslib.wfs import WebFeatureService
from owslib.wcs import WebCoverageService
from osgeo import gdal, ogr, osr
import json


class ScenarioRasterOld:
    
    def __init__(self, layer):
        self.layer = layer
       

    def getRasterSumScenario(self, filterPoly):
        
        wcs = WebCoverageService(url=self.layer['wmsServer'], version='1.0.0')
        contents = wcs.contents[self.layer['wmsId']]
        resolx = float(contents.grid.offsetvectors[0][0])
        resoly = abs(float(contents.grid.offsetvectors[1][1]))
        rfmt = "GeoTIFF"
        rCRS = contents.boundingboxes[0]['nativeSrs']
        rEPSG = int(rCRS.split(':')[1])
        sourceSR = osr.SpatialReference()
        sourceSR.ImportFromEPSG(4326)
        targetSR = osr.SpatialReference()
        targetSR.ImportFromEPSG(rEPSG)
        coordTrans = osr.CoordinateTransformation(sourceSR, targetSR)
        
        #create ring
        ring = ogr.Geometry(ogr.wkbLinearRing)
        for coords in filterPoly:
            ring.AddPoint(coords['lng'], coords['lat'])  
               
        #create polygon
        ogrPoly = ogr.Geometry(ogr.wkbPolygon)
        ogrPoly.AddGeometry(ring)
                
        ogrPoly.Transform(coordTrans)
        polyBBox = ogrPoly.GetEnvelope()
               
        minx = self.getReGriddedCoord(polyBBox[0], float(contents.boundingBoxWGS84[0]), resolx) - resolx
        miny = self.getReGriddedCoord(polyBBox[2], float(contents.boundingBoxWGS84[1]), resoly) - resoly
        maxx = self.getReGriddedCoord(polyBBox[1], float(contents.boundingBoxWGS84[0]), resolx) + resolx
        maxy = self.getReGriddedCoord(polyBBox[3], float(contents.boundingBoxWGS84[1]), resoly) + resoly
        filterBBOX = (minx, miny, maxx, maxy) 
        
        wcsId = contents.id

        wcsUrl = self.composeWcs100Url(baseUrl=self.layer['wmsServer'], identifier=wcsId, bbox=filterBBOX, format=rfmt, resx=resolx, resy=resoly, crs=rCRS)
        print wcsUrl 
        
        #DEREGISTRO il DRIVER DODS che impedisce di aprire correttamente la geotiff
        registeredDriver = gdal.AllRegister()
        dodsDriver = gdal.GetDriverByName('DODS')
        if dodsDriver is not None:
            dodsDriver.Deregister()
    #                     for i in range(gdal.GetDriverCount()):
    #                         print gdal.GetDriver(i).ShortName
        raster = gdal.Open(wcsUrl)
        rSum, rAverage = self.getRasterFilteredPoly_stats(ogrPoly, raster, rEPSG)
       
        #costruisco il json per la response
        properties = {u'properties':{u'Sum' : int(rSum)}
                      }
        feature=[]
        #aggiungo una unica feature nella quale mettere i risultati
        feature.append(properties)
        rasterFeatures = {u'features' : feature}                       
                 
        return rasterFeatures


    def getRasterFilteredPoly_stats(self, filterPoly, raster, rEPSG):
    
        # Save extent to a new Shapefile
    #     filterShapefile = "/andrea/tmp/wcs/tmp.shp"
    #     driver = ogr.GetDriverByName("ESRI Shapefile")
    # 
    #     # Remove output shapefile if it already exists
    #     if os.path.exists(filterShapefile):
    #         driver.DeleteDataSource(filterShapefile)
    # 
    #     filterDataSource = driver.CreateDataSource(filterShapefile)
        
        driver = ogr.GetDriverByName('MEMORY')
        filterDataSource = driver.CreateDataSource('')
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(rEPSG)
        
        
        filterLayer = filterDataSource.CreateLayer("poly_filter", srs=srs, geom_type=ogr.wkbPolygon)
        # Add an ID field
        idField = ogr.FieldDefn("id", ogr.OFTInteger)
        filterLayer.CreateField(idField)
        # Create the feature and set values
        featureDefn = filterLayer.GetLayerDefn()
        feature = ogr.Feature(featureDefn)    
        feature.SetGeometry(filterPoly)
        feature.SetField("id", 1)
        filterLayer.CreateFeature(feature)
        
        bandRaster = raster.GetRasterBand(1)
        noDataValue = bandRaster.GetNoDataValue()
        geoTransRaster = raster.GetGeoTransform()
        
        dataRaster = numpy.array(bandRaster.ReadAsArray())
        xcount = dataRaster.shape[1]
        ycount = dataRaster.shape[0]
    
        # Create memory target raster
        target_ds = gdal.GetDriverByName('MEM').Create('', xcount, ycount, 1, gdal.GDT_Byte)
        target_ds.SetGeoTransform(geoTransRaster)
    
        # Create for target raster the same projection as for the value raster
        raster_srs = osr.SpatialReference()
        raster_srs.ImportFromWkt(raster.GetProjectionRef())
        target_ds.SetProjection(raster_srs.ExportToWkt())
    
        # Rasterize polygon to raster
        options = ['ALL_TOUCHED=TRUE']
        gdal.RasterizeLayer(target_ds, [1], filterLayer, burn_values=[1], options=options)
    
    
        #POLIGONO rasterizzato in formato array
        bandMask = target_ds.GetRasterBand(1)
        dataMask =numpy.array(bandMask.ReadAsArray())
        
        #RASTER in formato array senza nodatavalue
        dataRasterNoData = numpy.ma.masked_where(dataRaster == noDataValue, dataRaster)
        
        filteredRaster = numpy.multiply(dataRasterNoData,dataMask)
        
        #return numpy.sum(filteredRaster), numpy.average(filteredRaster), numpy.mean(filteredRaster),numpy.median(filteredRaster),numpy.std(filteredRaster),numpy.var(filteredRaster)
        return numpy.sum(filteredRaster), numpy.average(filteredRaster)


    def getReGriddedCoord(self, coord, rasterOriginCoord, rasterRes):
        numPixels, rest = divmod((coord - rasterOriginCoord), rasterRes)
        reGriddedCoord = rasterOriginCoord + (numPixels * rasterRes) 
        return reGriddedCoord
    

    def composeWcs100Url(self, baseUrl=None, identifier=None, bbox=None, time=None, format = None,  crs=None, width=None, height=None, resx=None, resy=None, resz=None,parameter=None,method='Get',**kwargs):
       
        #process kwargs
        request = {'version': '1.0.0', 'request': 'GetCoverage', 'service':'WCS'}
        assert len(identifier) > 0
        request['Coverage']=identifier
        #request['identifier'] = ','.join(identifier)
        if bbox:
            request['BBox']=','.join([self.__makeString(x) for x in bbox])
        else:
            request['BBox']=None
        if time:
            request['time']=','.join(time)
        if crs:
            request['crs']=crs
        request['format']=format
        if width:
            request['width']=width
        if height:
            request['height']=height
        if resx:
            request['resx']=resx
        if resy:
            request['resy']=resy
        if resz:
            request['resz']=resz
          
        #anything else e.g. vendor specific parameters must go through kwargs
        if kwargs:
            for kw in kwargs:
                request[kw]=kwargs[kw]
          
        url = '%s?%s' % (baseUrl, urlencode(request))
                
        return url
 
 
    def __makeString(self, value):
        if type(value) is not str:
            sval=repr(value)
        else:
            sval = value
        return sval




class ScenarioVectorOld:
    
    def __init__(self, layer):
        
        self.layer = layer
        self.wfs11 = WebFeatureService(url=layer['wmsServer'], version='1.1.0')  
    
    def getWFSGeometryTypeName(self):
         
        #schema = wfs11.get_schema('scenario:ScuoleStatali_DPC')
        #Visto che wfs11.get_schema non funziona uso un espediente:
        try:  
            featSchema = self.wfs11.getfeature(typename=self.layer['wmsId'], maxfeatures = 1, outputFormat='application/json')
            jsonFeatSchema = json.loads(featSchema.read())
        except Exception as e:
            print 'cannot obtain WFS jsonFeatSchema - %s' % (e)
            raise Exception('no valid data found - %s' % (e))    
        
        if 'features' in jsonFeatSchema:
            features = jsonFeatSchema['features']   
            if 'geometry_name' in features[0]:
                geomPropName = features[0]['geometry_name']
            else:
                raise Exception('no valid data found in WFS')
            
            if 'geometry' in features[0]:
                geom = features[0]['geometry']
                if 'type' in geom:
                    geomType = geom['type']
                else:
                    raise Exception('no valid data found in WFS')
            else:
                raise Exception('no valid data found in WFS')
            
        else:
            raise Exception('no valid data found in WFS')
        
        return geomType, geomPropName
    
    
    def getVectorScenario(self, geomPropName, filterPolyCoords):
                
        filterxml = """<Filter>
                      <Intersects>
                        <PropertyName>""" + geomPropName + """</PropertyName>
                        <Polygon srsName="http://www.opengis.net/gml/srs/epsg.xml#4326">
                          <exterior>
                            <LinearRing>
                              <coordinates>""" + filterPolyCoords + """</coordinates>
                            </LinearRing>
                          </exterior>
                        </Polygon>
                      </Intersects>
                </Filter>"""
        filterxml.decode("utf-8")
        feature = self.wfs11.getfeature(typename=self.layer['wmsId'], outputFormat='application/json', filter=filterxml)
       #response.append(json.loads(feature.read()))
        
        result = json.loads(feature.read())
        
        return result
    

    
    

    
