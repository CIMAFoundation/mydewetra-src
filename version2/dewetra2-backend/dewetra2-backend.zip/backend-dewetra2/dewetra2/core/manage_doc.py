'''
Created on 13/dic/2016

@author: andrea
'''
from docx import Document
from docx.shared import Pt
from docx.shared import Mm
from PIL import Image as PilImage
import os
import datetime
import urllib2
import StringIO
from dewetra2.settings import DEWETRA2REPORT_BASE_DIR, DEWETRA2_RESOURCE_BASE
import math



class DocUtil(object):
    

    def __init__(self, report, user):
        
        self.report = report 
        self.user = user 
        self.outputPath, self.outputFile, self.fullRelPath = self.getDocPath()
        if not os.path.exists(self.outputPath):
            os.makedirs(self.outputPath)
       
     
    
    def createDoc(self):
        
        document = Document(DEWETRA2_RESOURCE_BASE +  '/bol_template.docx')   
        obj_styles = document.styles
        obj_charstyle = obj_styles.add_style('TitleStyle', 1)
        obj_font = obj_charstyle.font
        obj_font.size = Pt(18)
        obj_font.name = 'Times New Roman'
          
        titleParagr = document.add_paragraph(self.report['title'])
        titleParagr.style = document.styles['TitleStyle']
          
            
        obj_styles = document.styles
        obj_charstyle = obj_styles.add_style('DateStyle', 1)
        obj_font = obj_charstyle.font
        obj_font.size = Pt(14)
        obj_font.name = 'Times New Roman' 
            
        dateParagr = document.add_paragraph(self.report['date_creation'])
        dateParagr.style = document.styles['DateStyle']
          
              
        dateParagr.add_run().add_break()
                      
        prefaceParagr = document.add_paragraph()
        prefaceParagr.add_run().add_break()
        prefaceParagr.add_run(self.report['txt'])     
        prefaceParagr.add_run().add_break()   
        document.add_page_break()
         
                        
        #sezione SITUAZIONE ATTUALE
        if ('prevReport' in self.report): 
            self.addReportSection(document, self.report['prevReport'])
        if ('currReport' in self.report): 
            self.addReportSection(document, self.report['currReport'])
        if ('foreReport' in self.report): 
            self.addReportSection(document, self.report['foreReport'])
                                
        
        documentPath = '%s%s' % (self.outputPath, self.outputFile)
        document.save(documentPath)
        
        return self.fullRelPath
        
    
    
    def addReportSection(self, document, sectReport):
        if ('title' not in sectReport): return
        sectionTitleParagr = document.add_paragraph()
        sectionTitleParagr.add_run().add_break()
        sectionTitleParagr.add_run(sectReport['title'])
        sectionTitleParagr.style = document.styles['TitleStyle']
        sectionTitleParagr.add_run().add_break()
        
        fromDateTime = self.getUtcDateTimeFromSec(sectReport['fromUTCSecond'])
        toDateTime = self.getUtcDateTimeFromSec(sectReport['toUTCSecond'])
        dateSectionText = '%s %s - %s' % (self.report['analysisPeriod'], fromDateTime, toDateTime)
        dateSectionParagr = document.add_paragraph(dateSectionText)
        dateSectionParagr.style = document.styles['DateStyle']
        
        if ('text' in sectReport):
            sectionTxtParagr = document.add_paragraph()
            sectionTxtParagr.add_run().add_break()
            sectionTxtParagr.add_run(sectReport['text'])
        document.add_page_break()
        if 'layers' in sectReport:
            imgsPageNum = sectReport['nImgs']['value']
            imgNum = 1
            nRow = 0
            nCol = 0
            table = None
            if (imgsPageNum == 2):
                table = document.add_table(rows=2, cols=1)
            elif (imgsPageNum == 4):
                table = document.add_table(rows=2, cols=2)
            for layer in sectReport['layers']:
                       
                if ('cumul' in layer and layer['cumul'] is not None) : 
                    #nel caso di TIME RANGE
                    if (layer['cumul']['id'] == 8):
                        gapSecs = (sectReport['toUTCSecond'] - sectReport['fromUTCSecond'])
                        h = int(math.floor(gapSecs / 3600));
                        m = int(math.floor(gapSecs % 3600 / 60));
                        cumulPeriod =  str(h) + " ORE : " +  str(m) + " MINUTI";
                    else:
                        cumulPeriod = layer['cumul']['descr'] 
                
                cumulDescr = '%s: %s' % (self.report['cumulLabel'], cumulPeriod) if 'cumul' in layer and layer['cumul'] is not None else None
                aggrDescr = '%s: %s' % (self.report['aggrLabel'], layer['aggr']['descr']) if 'aggr' in layer and layer['aggr'] is not None else None
                runDescr = '%s: %s' % ('run', layer['run_selected']['descr']) if 'run_selected' in layer and layer['run_selected'] is not None else None
                
                toDateTime = self.getUtcDateTimeFromSec(sectReport['toUTCSecond'])
                layerTitle = '%s (%s)' % (layer['name'], toDateTime)
                if (cumulDescr):
                    layerTitle = '%s - %s' % (layerTitle, cumulDescr)
                if (aggrDescr):
                    layerTitle = '%s - %s' % (layerTitle, aggrDescr)
                if (runDescr):
                    layerTitle = '%s - %s' % (layer['name'], runDescr)   
                 
                width1=Mm(170)
                height1=Mm(180)
                width2=Mm(85) 
                height2=Mm(90)
                width3=Mm(75) 
                height3=Mm(80) 
                 
                if 'isForecast' in layer and layer['isForecast'] == True:    
                    layerImgPath = layer['mapurl']
                    width1=Mm(165)
                    height1=Mm(125)
                    width2=Mm(120) 
                    height2=Mm(90)
                    width3=Mm(75) 
                    height3=Mm(60)
                elif 'isUploaded' in layer and layer['isUploaded'] == True:
                    layerImgPath = DEWETRA2REPORT_BASE_DIR + layer['mapurl'].replace('_','/')
                else:
                    layerImgPath = self.getImgAndPalette(layer['mapurl'], layer['palette_img_url'])
                   
                try:
                    if (imgsPageNum == 1):
                        document.add_picture(layerImgPath, width1, height1)
                        imageNum = 'img. %s: %s' % (imgNum, layerTitle)
                        layerParagr = document.add_paragraph(imageNum)
                        layerParagr.alignment = 1
                        imgNum += 1
                        document.add_page_break()
                    elif (imgsPageNum == 2):
                        table.alignment = 1
                        row = table.rows[nRow]
                        paragraph = row.cells[nCol].paragraphs[0]
                        paragraph.alignment = 1
                        run = paragraph.add_run()
                        run.add_picture(layerImgPath, width2, height2)
                        run.add_break()
                        imageNum = 'img. %s: %s' % (imgNum, layerTitle)
                        run.add_text(imageNum)
                        if (imgNum % imgsPageNum == 0 and imgNum < len(sectReport['layers'])):
                            table = document.add_table(rows=2, cols=1)
                            nRow = 0
                            nCol = 0
                        else:
                            nRow += 1
                        imgNum += 1
                    elif (imgsPageNum == 4):
                        table.alignment = 1
                        row = table.rows[nRow]
                        paragraph = row.cells[nCol].paragraphs[0]
                        paragraph.alignment = 1
                        run = paragraph.add_run()
                        run.add_picture(layerImgPath, width3, height3)
                        run.add_break()
                        imageNum = 'img. %s: %s' % (imgNum, layerTitle)
                        run.add_text(imageNum)
                        if (imgNum % imgsPageNum == 0 and imgNum < len(sectReport['layers'])):
                            table = document.add_table(rows=2, cols=2)
                            nRow = 0
                            nCol = 0
                        elif (imgNum % imgsPageNum == 2):
                            nRow += 1
                            nCol = 0
                        else:
                            nCol += 1
                        imgNum += 1
                except:
                    document.add_page_break()
         
        if (imgsPageNum == 2 or imgsPageNum == 4):
            document.add_page_break()
        if 'raings' in sectReport and sectReport['raings']:
            toDateTime = self.getUtcDateTimeFromSec(sectReport['toUTCSecond'])
            raingsTitle = '%s (%s) - %s %s' % (sectReport['raings_title'], toDateTime, self.report['cumulLabel'], sectReport['raings_cumul'])
            raingsParagr = document.add_paragraph(raingsTitle)
            raingsParagr.style = document.styles['TitleStyle']
            run = raingsParagr.add_run()
            run.add_break()
            tableRows = len(sectReport['raings'])
            #tableCols = 6
            tableCols = 5
            table = document.add_table(rows=tableRows + 1, cols=tableCols)
            table.style = 'Table Grid'
            table_cells = table._cells
            hdr_cells = table_cells[0:tableCols]
            hdr_cells[0].text = 'STAZIONE'
            hdr_cells[1].text = 'COMUNE'
            hdr_cells[2].text = 'PROVINCIA'
            hdr_cells[3].text = 'REGIONE'
            hdr_cells[4].text = 'VALORE'
            #hdr_cells[5].text = 'SOGLIA'
            for imgNum in range(tableRows):
                raing = sectReport['raings'][imgNum]
                row_cells = table_cells[(imgNum + 1) * tableCols:(imgNum + 2) * tableCols]
                if ('stationname' in raing):
                    row_cells[0].text = raing['stationname']
                if ('munic' in raing):
                    row_cells[1].text = raing['munic']
                if ('district' in raing):
                    row_cells[2].text = raing['district']
                if ('region' in raing):
                    row_cells[3].text = raing['region']
                if ('value' in raing):
                    mu = str(raing['mu']) if('mu' in raing) else ''
                    row_cells[4].text = str(raing['value']) + mu
#                 if ('threshold' in raing):
#                     row_cells[5].text = raing['threshold']
            
            document.add_page_break()
            
        if 'hydros' in sectReport and sectReport['hydros']:
            toDateTime = self.getUtcDateTimeFromSec(sectReport['toUTCSecond'])
            hydrosTitle = '%s  (%s)' % (sectReport['hydros_title'], toDateTime)
            hydrosParagr = document.add_paragraph(hydrosTitle)
            hydrosParagr.style = document.styles['TitleStyle']
            run = hydrosParagr.add_run()
            run.add_break()
            tableRows = len(sectReport['hydros'])
            tableCols = 6
            table2 = document.add_table(rows=tableRows + 1, cols=tableCols)
            table2.style = 'Table Grid'
            table_cells = table2._cells
            hdr_cells = table_cells[0:6]
            hdr_cells[0].text = 'STAZIONE'
            hdr_cells[1].text = 'COMUNE'
            hdr_cells[2].text = 'PROVINCIA'
            hdr_cells[3].text = 'REGIONE'
            hdr_cells[4].text = 'VALORE'
            hdr_cells[5].text = 'SOGLIA'
            for imgNum in range(tableRows):
                hydro = sectReport['hydros'][imgNum]
                row_cells = table_cells[(imgNum + 1) * tableCols:(imgNum + 2) * tableCols]
                if ('stationname' in hydro):
                    row_cells[0].text = hydro['stationname']
                if ('munic' in hydro):
                    row_cells[1].text = hydro['munic']
                if ('district' in hydro):
                    row_cells[2].text = hydro['district']
                if ('region' in hydro):
                    row_cells[3].text = hydro['region']
                if ('value' in hydro):
                    mu = str(hydro['mu']) if('mu' in hydro) else ''
                    row_cells[4].text = str(hydro['value']) + mu
                if ('threshold' in hydro):
                    row_cells[5].text = hydro['threshold']
                    
            document.add_page_break()
      
    def getDocPath(self):
        
        dateTimeNow = datetime.datetime.now()
        timeString = dateTimeNow.strftime("%H%M%S")  
        outputFile = 'report_%s_%s.docx' % (self.user, timeString)
        dirRelPath = dateTimeNow.strftime("/%Y/%m/%d/")
        fullRelPath = '%s%s' % (dirRelPath, outputFile)
        outputPath = DEWETRA2REPORT_BASE_DIR + dirRelPath
        return outputPath, outputFile, fullRelPath
    
    
    def getImgAndPalette(self,layerImgUrl, paletteImgUrl):
        
        layerImgFromUrl = urllib2.urlopen(layerImgUrl)   
        io_ImgLayerUrl = StringIO.StringIO()
        io_ImgLayerUrl.write(layerImgFromUrl.read())
        io_ImgLayerUrl.seek(0)   
        layerImg = PilImage.open(io_ImgLayerUrl)
        
        if(paletteImgUrl) :
            paletteImgFromUrl = urllib2.urlopen(paletteImgUrl)  
            
            io_ImgPaletteUrl = StringIO.StringIO()
            io_ImgPaletteUrl.write(paletteImgFromUrl.read())
            io_ImgPaletteUrl.seek(0)  
            paletteImg = PilImage.open(io_ImgPaletteUrl)
        
            layerImgWidth, layerImgHeight = layerImg.size
            paletteImgWidth, paletteImgHeight = paletteImg.size
    
            layerImg.paste(paletteImg, (20, layerImgHeight - paletteImgHeight - 20))
 
        io_fullImgUrl = StringIO.StringIO()
        layerImg.save(io_fullImgUrl,"PNG")
    
        return io_fullImgUrl
       
         
#     def getlocalDateTimeFromSec(self, utcEpochSec):
#         utcDateTime = datetime.datetime.fromtimestamp(utcEpochSec)
#         from_zone = tz.gettz('UTC')
#         to_zone = tz.gettz('Europe/Rome')
#         utcDateTime = utcDateTime.replace(tzinfo=from_zone)
#         localDateTime = utcDateTime.astimezone(to_zone)   
#                     
#         return  localDateTime.strftime('%d/%m/%Y %H:%M')  
    
    def getUtcDateTimeFromSec(self, utcEpochSec):
        utcDateTime = datetime.datetime.utcfromtimestamp(utcEpochSec)
        utcDateString = '%s UTC' % (utcDateTime.strftime('%d/%m/%Y %H:%M'))   
        return utcDateString
    
    
    