from tastypie.resources import ModelResource
from dewetra2.core.resources import DewetraResourceMeta
from dewetra2.models import Layer, Tag, LayerType, Server, LayerCategory,\
     Group, Path, LayerGroupPermission, GeoScale
from tastypie.constants import ALL_WITH_RELATIONS, ALL
from tastypie import fields
from dewetra2.core.permissions import DewetraLayerAuthorization,\
    DewetraServerAutorization
from acroweb.core.resources import AcrowebResource, URLHelper
from tastypie.http import HttpUnauthorized, HttpApplicationError
from owslib.wms import WebMapService
from django.forms.models import model_to_dict
from dewetra2.core.models_resources import LayerTypeResource, ServerResource,\
    PathResource, TagResource, GroupResource, LayerCategoryResource,\
    GeoScaleResource
from dewetra2.settings import ADD_WMS_LAYER_FILTER
from django.db.models.query_utils import Q
import json



## CONFIG RESOURCES

class ConfigServerRes(ModelResource):
    class Meta(DewetraResourceMeta):
        limit = 10000
        queryset = Server.objects.all()
        resource_name = 'config/servers'
        list_allowed_methods = ['get'] 
        fields = ['id', 'name', 'descr', 'url']       


class ConfigServerResFiltered(ModelResource):
    class Meta(DewetraResourceMeta):
        authorization = DewetraServerAutorization()
        limit = 10000
        queryset = Server.objects.all()
        resource_name = 'config/filteredservers'
        list_allowed_methods = ['get'] 
        fields = ['id', 'name', 'descr', 'url']     
  

class ConfigLayersNameRes(ModelResource):
    class Meta(DewetraResourceMeta):
        limit = 10000
        authorization = DewetraLayerAuthorization()
        queryset = Layer.objects.all()
        resource_name = 'config/layersname'
        list_allowed_methods = ['get']
        fields = ['id', 'name']  
   


class ConfigLayerRes(ModelResource):

    type = fields.ForeignKey(LayerTypeResource, 'type', full = True)
    server = fields.ForeignKey(ServerResource, 'server', full = True)
    path = fields.ForeignKey(PathResource, 'path', null=True, blank=True, full = True)
    pathdrr = fields.ForeignKey(PathResource, 'pathdrr', null=True, blank=True, full = True)
    tags = fields.ToManyField(TagResource, 'tags', full = True)
    groups = fields.ToManyField(GroupResource, 'groups', full = True)    
    category = fields.ForeignKey(LayerCategoryResource, 'category', full = True)
    geoscale = fields.ForeignKey(GeoScaleResource, 'geoscale', null=True, blank=True, full = True)
   
    class Meta(DewetraResourceMeta):
        authorization = DewetraLayerAuthorization()
        limit = 10000
        queryset = Layer.objects.all()
        resource_name = 'config/layers'
        list_allowed_methods = ['get']
        filtering = {
            'id': ALL,
            'tags': ALL_WITH_RELATIONS,
            'server': ALL_WITH_RELATIONS,
            'type': ALL_WITH_RELATIONS,
            'group': ALL_WITH_RELATIONS,
            'category': ALL_WITH_RELATIONS,
            'geoscale': ALL_WITH_RELATIONS,
        }
        
    def dehydrate(self, b):
        b.data['customprops'] =  json.loads(b.data['customprops']) if(b.data['customprops']) else  None
            
        return b


class ConfigUtilLayersRes(AcrowebResource):
    
    class Meta(DewetraResourceMeta):
        resource_name = 'configUtils'
        
    def getMyUrl(self):
        return [
                URLHelper('/getWmsLayers', 'getWmsLayers'),
                URLHelper('/getWmsLayerDetail', 'getWmsLayerDetail'),
                URLHelper('/getLayerBaseSettings', 'getLayerBaseSettings'),
                URLHelper('/saveLayer', 'saveLayer'),
                URLHelper('/removeLayer', 'removeLayer'),
                URLHelper('/addServer', 'addServer'),
                URLHelper('/addType', 'addType'),
                URLHelper('/addPath', 'addPath'),
                URLHelper('/addCategory', 'addCategory'),
                URLHelper('/addTag', 'addTag')
                
                ]
      
    def getWmsLayers(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
                    
        wmsServerUrl = data['url']
        
        try:
            wms = WebMapService(wmsServerUrl, version='1.1.1')
            response = list(wms.contents)
        except Exception, myerror:
            
            return self.create_response(request, myerror, HttpApplicationError)
           
        if wmsServerUrl in ADD_WMS_LAYER_FILTER:
            filters = ADD_WMS_LAYER_FILTER[wmsServerUrl]
            filtered=[]
            for l in response:
                ok = True
                for f in filters:
                    if l.startswith(f):
                        ok = False
                        break
                if ok: filtered.append(l)
            response=filtered
        
        
        return self.create_response(request, response)
    
    
    def getWmsLayerDetail(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        wmsServer = data['server']
        #wmsServerUrl = data['url']       
        wmsServerUrl = data['server']['url']      
        wmsLayerId = data['layerId']
        
        try:
            wms = WebMapService(wmsServerUrl, version='1.1.1')
            details = wms[wmsLayerId]
            response = {
                    'server' : wmsServer,  
                    'id' : details.id,  
                    'title': details.title, 
                    'bbox': details.boundingBoxWGS84
                    }
            
        except Exception, myerror:
            
            return self.create_response(request, myerror, HttpApplicationError)
           
           
        return self.create_response(request, response)
    
    

    def getLayerBaseSettings(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['get'])
                  
        try:

            #servers = list(Server.objects.all().values())  
            servers = list(self.getFilteredServersByUser(request.user))
                    
            types = list(LayerType.objects.all().values()) 
            tags = list(Tag.objects.all().values())    
            paths = list(Path.objects.all().values()) 
            categories = list(LayerCategory.objects.all().values())       
           
            row = LayerGroupPermission.objects.get(user__username=request.user)
            groups = list(row.groups.all().values())
            geoscales = list(GeoScale.objects.all().values()) 
              
            response = {
                    'servers' : servers,  
                    'types': types,
                    'tags': tags,
                    'paths': paths,
                    'categories': categories,
                    'groups': groups,
                    'geoscales': geoscales
                    
                    }
            
        except Exception, error:
            return self.create_response(request, error, HttpApplicationError)
           
           
        return self.create_response(request, response)
    
       
   
    def saveLayer(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        try:
            #Salvo o aggiorno il LAYER
            oLayer = Layer.objects.get(id=data['id']) if ('id' in data) else Layer()
                            
            oLayer.dataid = data['dataid']        
            oLayer.name = data['name']        
            oLayer.descr = data['descr']      
            oLayer.thumb = data['thumb'] if ('thumb' in data ) else ''
            oLayer.metadata = data['metadata'] if ('metadata' in data) else ''
            oLayer.metadataurl = data['metadataurl'] if ('metadataurl' in data) else ''
            oLayer.lonw = data['minx']   
            oLayer.lone = data['maxx']   
            oLayer.lats = data['miny']   
            oLayer.latn = data['maxy']   
            
            oType = LayerType()
            oType.id = data['type']['id']
            oLayer.type = oType
            
            oServer = Server()
            oServer.id = data['server']['id']
            oLayer.server = oServer
            
            if('path' in data and data['path']):
                oPath = Path()
                oPath.id = data['path']['id']
                oLayer.path = oPath
            
            if('pathdrr' in data and data['pathdrr']):
                oPathDrr = Path()
                oPathDrr.id = data['pathdrr']['id']
                oLayer.pathdrr = oPathDrr
            
            oCategory = LayerCategory()
            oCategory.id = data['category']['id']
            oLayer.category = oCategory
           
            oLayer.icon = data['icon'] if ('icon' in data) else ''
            
            if('geoscale' in data and data['geoscale']):
                oGeoscale = GeoScale()
                oGeoscale.id = data['geoscale']['id']
                oLayer.geoscale = oGeoscale
            
            oLayer.customprops = json.dumps(data['customprops']) if ('customprops' in data) else ''
            
            oLayer.save() 
            
            #Salvo i GROUPS associati al layer 
            groupArray = data['group_array']
            
            oLayer.groups.clear()
            for group in groupArray :
                oGroup = Group.objects.get(id=group['id'])
                oLayer.groups.add(oGroup)  

            #Salvo i TAGS associati al layer 
            tagArray = data['tag_array']
           
            oLayer.tags.clear()
            for tag in tagArray :
                oTag = Tag.objects.get(id=tag['id'])
                oLayer.tags.add(oTag)  
                        
                        
            response = {'layer' : oLayer.name}
                        
        except Exception, error:
            
            return self.create_response(request, error, HttpApplicationError)
           
           
        return self.create_response(request, response)
    
    
    
    def removeLayer(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        
        try:
            #Rimuovo il LAYER e le relazioni molti a molti (groups, tags) dal db
            oLayer = Layer.objects.get(id=data['id'])
                            
            oLayer.groups.clear()
            oLayer.tags.clear()
            oLayer.delete()
                        
            response = {'layer' : oLayer.name}
            
            
        except Exception, error:
            
            return self.create_response(request, error, HttpApplicationError)
           
           
        return self.create_response(request, response)
    
    
    
    def addServer(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        
        try:
            oServer = Server()
            oServer.name = data['name']        
            oServer.descr = data['descr']      
            oServer.url = data['url']
            oServer.user = data['user'] if ('user' in data) else '.'
            oServer.password = data['password'] if ('password' in data) else '.'
            oServer.save()  
                       
            response = model_to_dict(oServer)
            
            
        except Exception, error:
            
            return self.create_response(request, error, HttpApplicationError)
           
           
        return self.create_response(request, response)
    
    
    def addType(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        try:
            oLayerType = LayerType()
            oLayerType.name = data['name']        
            oLayerType.code = data['code']      
            oLayerType.save()  
                       
            response = model_to_dict(oLayerType)
            
        except Exception, error:
            
            return self.create_response(request, error, HttpApplicationError)
           
        return self.create_response(request, response)
    
    
    def addPath(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        try:
            oPath = Path()
            oPath.hierarchy = data['hierarchy']         
            oPath.save()  
                       
            response = model_to_dict(oPath)
             
        except Exception, error:
            
            return self.create_response(request, error, HttpApplicationError)
           
           
        return self.create_response(request, response)
    
    
    def addCategory(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        try:
            oLayerCategory = LayerCategory()
            oLayerCategory.name = data['name']         
            oLayerCategory.save()  
                       
            response = model_to_dict(oLayerCategory)
             
        except Exception, error:
            
            return self.create_response(request, error, HttpApplicationError)
           
           
        return self.create_response(request, response)

    
    def addTag(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        try:
            oTag = Tag()
            oTag.name = data['name']        
            oTag.descr = data['descr']        
            oTag.save()  
                       
            response = model_to_dict(oTag)
             
        except Exception, error:
            
            return self.create_response(request, error, HttpApplicationError)
           
           
        return self.create_response(request, response)
    
    
    def getFilteredServersByUser(self, user):
        
        servers = Server.objects.all().values()
        
        try:
            layers  = self.getFilteredLayersByUser(user)
            server_ids = set([l.server.id for l in layers])
        except:
            server_ids = []
                    
        return servers.filter(Q(id__in=server_ids)).distinct()
    
    def getFilteredLayersByUser(self, user):
        layers = Layer.objects.all()
        username = 'anonymous'
        if user is not None:
            username = user.username #read all the groups the user access
        try:
            row = LayerGroupPermission.objects.get(user__username=username)
            gids = [g.id for g in row.groups.all()]
        except:
            gids = []
        
        return layers.filter(Q(groups__id__in=gids)).distinct()
