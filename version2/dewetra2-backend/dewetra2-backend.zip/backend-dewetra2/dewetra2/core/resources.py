"""
core reasources and base classes 
"""


class DewetraResourceMeta():    
    """
    base class for all resources Meta classes
    """
    include_resource_uri = False
    
