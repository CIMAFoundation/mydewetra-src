import csv
import datetime
import os
from osgeo import ogr
from dewetra2.core.exceptions import DewetraError
from dewetra2.dds.dds_drops_client import DDSDropsClient
from dewetra2.models import UserSettings
from dewetra2.settings import EXPORTDATA_DDS_URL, EXPORTDATA_DDS_USER, EXPORTDATA_DDS_PSW, \
    EXPORTDATA_SENSORS_DB_IP, EXPORTDATA_SENSORS_DB_NAME, EXPORTDATA_SENSORS_DB_USR, EXPORTDATA_SENSORS_DB_PSW
from dewetra2.appsettings import EXPORTDATA_RESOURCE, EXPORTDATA_BASE_URL



class ExportData:
        
    def __init__(self):
                       
        try: 
            self.relPathDir = datetime.datetime.utcnow().strftime('%Y%m%d%H%M%S%f')[:-3]                     
            self.workingDir = '%s/%s' % (EXPORTDATA_RESOURCE, self.relPathDir)
            if not os.path.exists(self.workingDir):
                os.makedirs(self.workingDir)
             
        except Exception as e:
            print('cannot create Exportdata - %s' % (e))   
       
    def getSpatialFilters(self, coords, spatialFilters):
       
        #GET COORDS
        lng = -9999.0
        lat = -9999.0
        if ('lng' in coords and 'lat' in coords):    
            lng = coords['lng']
            lat = coords['lat']
        else: 
            print('not defined coords')
            raise Exception('not defined coords') 
        
            
        conn = self.getSensorsDbConn() 
       
        filterResult = []
        
        for filter in spatialFilters:
            if('db_table' in filter and 'table_fld_id' in filter and 'table_fld_descr' in filter and 'table_fld_geom' in filter):
                table = filter['db_table'].encode('utf-8')
                id_field = filter['table_fld_id'].encode('utf-8')
                descr_field = filter['table_fld_descr'].encode('utf-8')
                geom_field = filter['table_fld_geom'].encode('utf-8')   
                          
                SQL = "SELECT t.%s AS id, t.%s AS descr " \
                      "FROM %s t " \
                      "WHERE ST_Intersects(ST_SetSRID(ST_MakePoint(%f, %f),4326), t.%s); " % (id_field, descr_field, table, lng, lat, geom_field)
                                            
                filteredRes = conn.ExecuteSQL(SQL)
                #conn.FlushCache()
               
                for feature in filteredRes:
                        if(feature.items()['id'] and feature.items()['descr']):
                                               
                            filterVal = {"id": filter['id'],
                                         "descr": filter['descr'],
                                         "value_descr": feature.items()['descr'],
                                         "value": feature.items()['id']
                                        }
                            
                            filterResult.append(filterVal)
                
                filteredRes = None                      
        
        conn.Destroy()   
           
        return filterResult
      

    def getStationsSensor(self, dewetraUserId, sensorClass):
        
        classStations =[]
      
        dropsClient = DDSDropsClient(EXPORTDATA_DDS_URL, EXPORTDATA_DDS_USER, EXPORTDATA_DDS_PSW)
        if dropsClient is None: 
            raise DewetraError('DDS Drops Classes Client not found')
        
        #check if is valid sensors classe     
        try:
            classes = dropsClient.getSensorClasses()
            if not sensorClass in classes:
                print('not a valid sensor class')
                raise DewetraError('not a valid sensor class')
                      
        except Exception as e:
            print('cannot get Sensors classes - %s' % (e))
            raise Exception('cannot get Sensors classes - %s' % (e))
        
          
        #get drops sensors anagraphic
        dropsAnagDict = self.getDropsAnag(dewetraUserId, dropsClient, sensorClass)       
        for stId in dropsAnagDict.keys():
            classStations.append({'value': dropsAnagDict[stId]['id'],  "value_descr": dropsAnagDict[stId]['stationName']})
             
        return sorted(classStations, key=lambda k: k['value_descr'])  
   

    def getDatas(self, time_range, sensors, filters, cumulated, format, dewetraUserId, configSettings):
                 
        dateStart = datetime.datetime.strptime(time_range['start_dt'], "%Y%m%d%H%M")
        dateEnd = datetime.datetime.strptime(time_range['end_dt'], "%Y%m%d%H%M")
        dateRange = dateEnd - dateStart
          
        if (dateRange.days>31):
            raise Exception('Intervallo temporale di interrogazione superiore a un mese')                                           
        
        dropsClient = DDSDropsClient(EXPORTDATA_DDS_URL, EXPORTDATA_DDS_USER, EXPORTDATA_DDS_PSW)
        if dropsClient is None: 
            raise DewetraError('DDS Drops Classes Client not found')
               
        sensorClass = ""
        #check if is valid sensors classe
        try:
            classes = dropsClient.getSensorClasses()
            if sensors['id'] in classes:
                sensorClass = sensors['id']
            else:
                print('not a valid sensor class')
                raise DewetraError('not a valid sensor class')
        except Exception as e:
            print('cannot get Sensors classes - %s' % (e))
            raise Exception('cannot get Sensors classes - %s' % (e))
        
        #GET FILTERED ANAG
          
        #get drops sensors anagraphic
        dropsAnagDict = self.getDropsAnag(dewetraUserId, dropsClient, sensorClass)
                
        sensorIdList = list()
        for sensAnagId in dropsAnagDict.keys():
            sensorIdList.append("'%s'" % sensAnagId) 
        
        sensorIdStringList =', '.join(sensorIdList)
        
                         
        dbConn = self.getSensorsDbConn()
            
        #get stations ids filtered by selected spatial filter   
        filteredSensors = []
        filteredAnagDict = {}
                    
        try:   
            if(filters['descr'] == 'Station'): 
                sensorId_db = filters['value'].encode('utf-8')
                sensorId = int(sensorId_db.split('_')[0])
                sensordb = sensorId_db.split('_')[1]
                      
            SQL = "SELECT sensor, db, station, name, supplier_name, region_id, region, district_id, district, " \
                  "munic_id, municipality, wa_id, warning_area, catchment_id, catchment " \
                  "FROM public.sensors_anag_cache "             
            
            if(filters['descr'] == 'Station'):
                SQL += "WHERE sensor = %d and db = %s;" % (sensorId,sensordb)
            
            elif(filters['descr'] == 'All data'):
                SQL += "WHERE sensor||'_'||db IN (%s)" % (sensorIdStringList.encode('utf-8'))
                
            else:  
                if(filters['descr'] == 'Region'): 
                    SQL += "WHERE region_id = %s " % (filters['value'])
                elif(filters['descr'] == 'District'):
                    SQL += "WHERE district_id = %s " % (filters['value'])
                elif(filters['descr'] == 'Municipality'):
                    SQL += "WHERE munic_id = %s " % (filters['value'])
                elif(filters['descr'] == 'Warning_Area'):
                    SQL += "WHERE wa_id = %s " % (filters['value'])
                elif(filters['descr'] == 'Catchment'):
                    SQL += "WHERE catchment_id = %s " % (filters['value'])
                
                SQL += "AND sensor||'_'||db IN (%s)" % (sensorIdStringList.encode('utf-8'))
               
                    
            filteredSensorsLy = dbConn.ExecuteSQL(SQL)
                      
            for feature in filteredSensorsLy:
                featureItem = feature.items()
                if(featureItem['sensor']):
                    sensor_id = "%s_%s" % (str(featureItem['sensor']), str(featureItem['db']))
                    #check if sensor id is in dropsAnag
                                  
                    sensorAnag = dropsAnagDict[sensor_id]
                                                                  
                    database = ''
                    if (featureItem['db'] == 1):
                        database = 'CF' 
                    elif  (featureItem['db'] == 2):
                        database = 'RUPA' 
                          
                    sensorFullAnag = {
                        'id':sensor_id, 
                        'data_source':database,
                        'station':featureItem['name'], 
                        'region':featureItem['region'], 
                        'district':featureItem['district'], 
                        'municipality':featureItem['municipality'], 
                        'catchment':featureItem['catchment'],
                        'warning_area':featureItem['warning_area'], 
                        'lon':sensorAnag['lon'], 
                        'lat':sensorAnag['lat'], 
#                       'alt':sensorAnag['alt'],
                        'mu':unicode(sensorAnag['sensorMU']).encode("utf-8")
                       }
                    
                    filteredAnagDict[sensor_id] = sensorFullAnag
                    filteredSensors.append(sensor_id) 
                                       
            filteredSensorsLy = None                      
            dbConn.Destroy()     
          
        except Exception as e:
            dbConn.Destroy()
            print('cannot get stations ids filtered by selected spatial filter - %s' % (e))
                       
       
        print('BEFORE getSensorData')
        #get filtered sensors data
        try:
            aggr_time = int(cumulated['value']) * 3600 if (sensors['id'] == 'PLUVIOMETRO') else None
            sensorsData = dropsClient.getSensorData(sensorClass, filteredSensors, time_range['start_dt'].encode('utf-8'), time_range['end_dt'].encode('utf-8'), aggr_time)
        except Exception as e:
            print('cannot get Sensors classes - %s' % (e))
            raise Exception('cannot get Sensors classes - %s' % (e))

        print('BEFORE CSV')
               
        csvFileName = 'exportData.csv'
        csvFilePath = '%s/%s' % (self.workingDir, csvFileName)
        csvFileRelPath = '%s/%s' % (self.relPathDir, csvFileName)
        with open(csvFilePath, "wb") as csv_file:

            wr = csv.writer(csv_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
            valueLabel = 'CUMULATED %s' % (cumulated['descr']) if (sensors['id'] == 'PLUVIOMETRO') else 'VALUE'
            wr.writerow(['DATA SOURCE', 'STATION', 'REGION', 'DISTRICT', 'MUNICIPALITY', 'CATCHMENT', 'WARNING AREA', 'LON','LAT', 'DATE/TIME', valueLabel, 'UNIT OF MEASURE'])
           
            if(format['id'] == 'it_IT'):
                dateFormat = "%y/%m/%d %H.%M"
            elif (format['id'] == 'en_US'):
                dateFormat = "%y/%m/%d %H.%M"       
            else:
                print('%s fromat is not valid' % (format['id']))
                raise Exception('%s fromat is not valid' % (format['id']))


            round_dec = 2 if (sensors['id'] == 'IDROMETRO') else 1
            for data in sensorsData:
                
                anag = filteredAnagDict[data['sensorId']]
                for j in range(len(data['timeline'])):
                    if(data['timeline'][j] != time_range['start_dt']):
                        wr.writerow([anag['data_source'], anag['station'], anag['region'], anag['district'], anag['municipality'], \
                            anag['catchment'], anag['warning_area'], anag['lon'], anag['lat'], '%s/%s/%s %s.%s' %( data['timeline'][j][0:4],  data['timeline'][j][4:6],  data['timeline'][j][6:8],  data['timeline'][j][8:10],  data['timeline'][j][10:12]), round(data['values'][j], round_dec), anag['mu']])

        print('BEFORE DOWNLOAD')
        
        csvUrl = {'csvUrl': EXPORTDATA_BASE_URL + csvFileRelPath}
        return csvUrl  
 
    def getStationsGeoInfo(self, configSettings):
       
       #get reg, distr, munic, wareas... for all stations
        if('filters' in configSettings):
            geoInfos = configSettings['filters']
        
        try:
            dbCn = self.getSensorsDbConn()
            
            sql_select = "SELECT DISTINCT sen.sensor, sen.db, s.station "
            sql_join = ""
            sql_where ="WHERE "
            i=1
            for geoInfo in geoInfos:
                if('db_table' in geoInfo and 'table_fld_id' in geoInfo and 'table_fld_descr' in geoInfo and 'table_fld_geom' in geoInfo):
                    descr = geoInfo['descr'].encode('utf-8')
                    table = geoInfo['db_table'].encode('utf-8')
                    id_field = geoInfo['table_fld_id'].encode('utf-8')
                    descr_field = geoInfo['table_fld_descr'].encode('utf-8')
                    geom_field = geoInfo['table_fld_geom'].encode('utf-8')     
                    
                    tableAlias = "t%d" % (i)
                    sql_select += ", %s.%s AS %s " % (tableAlias, descr_field, descr)
                    sql_join += "LEFT JOIN %s %s ON st_intersects(s.geom, %s.%s) " % (table, tableAlias, tableAlias, geom_field)
                    sql_where += "%s.%s is not NULL or " % (tableAlias, id_field)
                    
                    i+=1
                
            sql_select +=  "FROM stations s "
            sql_join += "LEFT JOIN sensors sen ON s.station = sen.station "
            SQL = "%s %s %s" % (sql_select, sql_join, sql_where[:-3])
                
            geoInfoStation = dbCn.ExecuteSQL(SQL)   
            geoInfoStationDic = dict() 
            for feature in geoInfoStation:
                if(feature.items()['sensor']):
                    geodata = {"region": feature.items()['region'], 
                               "district": feature.items()['district'], 
                               "catchment": feature.items()['catchment'], 
                               "warning_area": feature.items()['warning_area']
                               }
                    
                    dicKey = "%s_%s" % (feature.items()['sensor'], feature.items()['db'])
                    st_geodata ={dicKey : geodata}
                    geoInfoStationDic.update(st_geodata)
                 
                    
            geoInfoStation = None                      
            dbCn.Destroy()    
        except Exception as e:
            dbCn.Destroy()
            print('cannot obtain region, district, municipality, warning-areas for all stations - %s' % (e))
            raise Exception('cannot obtain region, district, municipality, warning-areas for all stations - %s' % (e)) 
           
        return geoInfoStationDic
      
    
    
    def getDropsAnag(self,dewetraUserId, dropsClient, sensorClass):
        
        dropsAnag= None
        try:
            #get stationgroup from user
            userSetting = UserSettings.objects.filter(user_id = dewetraUserId).first()
            dewStationGroupId = userSetting.stationgroup
            groupId = int(dewStationGroupId.encode('utf-8'))
            
            sensDbconn = self.getSensorsDbConn()
            
            SQLquery = "SELECT type, name FROM public.groups WHERE idgroup = %d;" % (groupId)
            stationsGroupLy = sensDbconn.ExecuteSQL(SQLquery)
            #sensDbconn.FlushCache()
            for stationsgroup in stationsGroupLy:
                percent ='%'
                group = '%s%s%s' % (stationsgroup.type, percent, stationsgroup.name)
                break
            
            stationsGroupLy = None                      
            sensDbconn.Destroy()       
                 
            dropsAnag = dropsClient.getSensorAnag(sensorClass, group)
            
            dropsAnagDict = {x["id"]: x for x in dropsAnag}
                                   
        except Exception as e:
            sensDbconn.Destroy()
            print('cannot get Sensors anagraphic - %s' % (e))
            raise Exception('cannot get Sensors anagraphic - %s' % (e))
        
        return dropsAnagDict
    
         
    
    
    def getSensorsDbConn(self):
        
        conn = None       
        try:
            postgisDrvName = "PostgreSQL"
            postgisDriver = ogr.GetDriverByName(postgisDrvName)
            if postgisDriver is None:
                print('%s driver not available.\n' % postgisDrvName)
            connString = "PG: host=%s dbname=%s user=%s password=%s" % (EXPORTDATA_SENSORS_DB_IP, EXPORTDATA_SENSORS_DB_NAME, EXPORTDATA_SENSORS_DB_USR, EXPORTDATA_SENSORS_DB_PSW)
              
            conn = ogr.Open(connString)
        except Exception as e:
            print('cannot connect to Sensors Database - %s' % (e))
            raise Exception('cannot connect to Sensors Database - %s' % (e))  
    
        return conn
    
    
       
    