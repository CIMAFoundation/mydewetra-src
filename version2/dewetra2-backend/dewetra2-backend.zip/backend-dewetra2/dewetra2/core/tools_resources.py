from tastypie.http import HttpUnauthorized, HttpApplicationError, HttpNotFound
from acroweb.core.resources import AcrowebResource, URLHelper
from dewetra2.core.resources import DewetraResourceMeta
from dewetra2.models import Tool
import json
from django.forms.models import model_to_dict
from dewetra2.core.tool_scenario import ScenarioRaster, ScenarioVector,\
    ScenarioUtility, Scenario
from dewetra2.core.tool_scenario_old import ScenarioRasterOld, ScenarioVectorOld
from django.http.response import HttpResponse
import base64
from dewetra2.core.export_data import ExportData


class ToolsResource(AcrowebResource):
    
    class Meta(DewetraResourceMeta):
        resource_name = 'tools'
        
    def getMyUrl(self):
        return [
                #GET TOOL BY ID
                URLHelper('/getToolById', 'getToolById'),
                
                #SAVE TOOL
                URLHelper('/saveTool', 'saveTool'),
                
                #TOOL SCENARIO
                URLHelper('/getScenario', 'getScenario'),
                
                #GET POLYGON SHAPEFILE FROM GEOJSON
                URLHelper('/polytoshapefile', 'polytoshapefile'),
                
                #Upload SHAPEFILE and return points array
                URLHelper('/shapefiletopoly', 'shapefiletopoly'),
                
                #OLD TOOL SCENARIO
                URLHelper('/getWFSFilteredFeatures', 'getWFSFilteredFeatures'),
                                
                #GET EXPORT DATA SPATIAL FILTER BY COORDS
                URLHelper('/exportdata_filters', 'exportdata_filters'),
                
                #GET EXPORT DATA STATIONS
                URLHelper('/exportdata_stations', 'exportdata_stations'),
                
                #TOOL EXPORT DATA
                URLHelper('/exportdata', 'exportdata'),
                
                ]
      
    def getToolById(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['get'])         
        toolId = int(request.GET['id'])
        
        try:
           
            tool = Tool.objects.filter(id__exact=toolId).last()
            if tool == None:
                 return self.create_response(request, 'no data found', HttpNotFound)
               
            response = model_to_dict(tool) 
            response["config"] = json.loads(response["config"])
            del response['users']
                        
        except Exception, error:
            return self.create_response(request, error, HttpApplicationError)
                      
           
        return self.create_response(request, response)
    
    
    def saveTool(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        
       
        toolDatas = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json')) 
             
        response = ""
        try:
            if ('id' in toolDatas and toolDatas['id']): 
                #update tool
                tool = Tool(**toolDatas)
                tool.config = json.dumps(tool.config)
                tool.save()
               
            else:
                #insert new tool
                tool = Tool(**toolDatas)
                tool.config = json.dumps(tool.config)
                tool.save()
                
                #save tool-user 
                tool.users.add(request.user)
                tool.save()

            response = "saved"
                        
        except Exception, error:
            print 'error: cannot save tool - %s' % (error)
            return self.create_response(request, error, HttpApplicationError)
                      
           
        return self.create_response(request, response)
    
    
        

    def getScenario(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        datas = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json')) 
        
        response = []
               
        if ('layers' in datas):    
            layers = datas['layers']
        else:
            return self.create_response(request, 'not defined layers', HttpNotFound)  
       
        hazardZone = None
        
        if ('hazard_zones' in datas): 
            if datas['hazard_zones']:               
                hazardZone = datas['hazard_zones'][0]
            else:
                hazardZone = None
                
        if ('polygonFilter' in datas):     
            polygon = datas['polygonFilter']              
        else:
            return self.create_response(request, 'not defined polygon', HttpNotFound)  
                
        #Create Scenario Working dir
        scenario = None
        try: 
            scenario = Scenario(hazardZone, polygon)
          
        except Exception as error:  
            scenario.delWorkingDir()
            response = 'error: cannot create Scenario - %s' % (error)
            print response
            return self.create_response(request, response, HttpApplicationError)
        
                
        for layer in layers:
            
            #RASTER SUM SCENARIO
            if('isRaster' in layer and layer['isRaster']== True):
                
                try:
                    scenarioRaster = ScenarioRaster(layer, scenario)  
                                      
                    print layer['wmsId'] + ' IS RASTER LAYER'
                   
                    result = scenarioRaster.getRasterSumScenario()
                    response.append(result)
                                        
                except Exception as error:
                    print 'error: cannot processing ' + layer['wmsId']
                              
            else:    
                               
                try:  
                    scenarioVector = ScenarioVector(layer, scenario)
                                        
                    #VECTORIAL LINE SUM SCENARIO             
                    if(scenarioVector.geomType=='LineString' or scenarioVector.geomType=='MultiLineString'):
                        print layer['wmsId'] + ' IS VECTORIAL LINE LAYER' 
                        result = scenarioVector.getLineScenario()   
                        response.append(result)  
                        result = scenarioVector.getVectorScenario()                 
                        response.append(result)  
#                     VECTORIAL POINT POLYGON MAP SCENARIO
                    else:
                        print layer['wmsId'] + ' IS VECTORIAL POINT OR POLY LAYER'
                        result = scenarioVector.getVectorScenario()                 
                        response.append(result)    
                                       
                except Exception, error:
                    print 'error: cannot processing ' + layer['wmsId']
                  
                    
        if scenario is not None: 
            scenario.delWorkingDir()            
         
        return self.create_response(request, response)
    
    
    
    def polytoshapefile(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        
        datas = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json')) 
             
        response = ""
        
        scenarioUtility = ScenarioUtility()
        
        try:
            if ('polygon' in datas):    
                polygon = datas['polygon']
                zipFileBuffer = scenarioUtility.getZippedShapeFile(polygon)
                zipFileBase64 = base64.b64encode(zipFileBuffer.getvalue())
                
                #response = HttpResponse(zipFileBuffer.getvalue(), content_type='application/zip')
                response = HttpResponse(zipFileBase64, content_type='application/octet-stream')
                #response = HttpResponse(zipFileBuffer.getvalue(), content_type='application/octet-stream')
                response['Content-Disposition'] = 'attachment; filename=area_of_interest.zip'
                
                scenarioUtility.delWorkingDir()

                return response
            else:
                scenarioUtility.delWorkingDir()
                resp = 'error: not a valid data sent'
                print resp
                return self.create_response(request, resp)
                        
        except Exception, error:
            
            scenarioUtility.delWorkingDir()
            errMsg = 'error: cannot export AOI polygon shapefile - %s' % (error)
            print errMsg
            return self.create_response(request, errMsg, HttpApplicationError)
                      
           
        return self.create_response(request, response)

    
    def shapefiletopoly(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
         
        scenarioUtility = ScenarioUtility() 
                 
        response =""
         
        if request.FILES.values():
            uFile = request.FILES.values()[0]
            
            try:
                
                response = scenarioUtility.getPolyFromZipShapeFile(uFile) 
                scenarioUtility.delWorkingDir()
            except Exception, error:
            
                scenarioUtility.delWorkingDir()
                response = 'error: cannot export AOI json polygon - %s' % (error)
                print response
                return self.create_response(request, response, HttpApplicationError)
        
        else:
            scenarioUtility.delWorkingDir()
            response = 'error: not a valid data sent'
            print response
            return self.create_response(request, response)                     
        
        return self.create_response(request, response)
    
    
    
     
    def getWFSFilteredFeatures(self, request, **kwargs):        
        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        datas = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json')) 
        
        response = []
        filterPolyCoords=""
        
        if ('layers' in datas):    
            layers = datas['layers']
        else:
            return self.create_response(request, 'not defined layers', HttpNotFound)  
                
        if ('polygonFilter' in datas):    
              
            polygon = datas['polygonFilter']
            for coords in polygon:
                filterPolyCoords += "%s,%s " % (coords['lng'], coords['lat'])
                            
        else:
            return self.create_response(request, 'not defined polygon', HttpNotFound)  
                
        for layer in layers:
            
            #RASTER SUM SCENARIO
            if('isRaster' in layer and layer['isRaster']== True):
                                                                    
                try:
                    print layer['wmsId'] + ' IS RASTER LAYER'
                    scenarioRaster = ScenarioRasterOld(layer)
                    result = scenarioRaster.getRasterSumScenario(polygon)
                    response.append(result)

                except Exception as error:
                    print 'error: cannot processing ' + layer['wmsId']
                    #return self.create_response(request, 'cannot manage layer: ' + layer['wmsId'], HttpApplicationError) 
                              
            else:  
                    
                try:  
                    scenarioVector = ScenarioVectorOld(layer)
                    geomType, geomFieldName = scenarioVector.getWFSGeometryTypeName()
                    
                    print layer['wmsId'] + ' IS VECTORIAL POINT OR POLY LAYER'   
                    result = scenarioVector.getVectorScenario(geomFieldName, filterPolyCoords)                 
                    response.append(result)
                    
                    
                except Exception, error:
                    print 'error: cannot processing ' + layer['wmsId']
                    #return self.create_response(request, error, HttpApplicationError)     
                    
         
        return self.create_response(request, response)
    
    
    
    def exportdata_filters(self, request, **kwargs):
                
        if request.user is None or not request.user.is_authenticated(): 
                return self.create_response(request, 'not authenticated', HttpUnauthorized)   
            
        self.method_check(request, allowed=['post'])
        datas = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json')) 
    
        response = ""
        
        if ('pt_coords' in datas and 'filters' in datas):    
            ptCoords = datas['pt_coords']
            spatialFilters = datas['filters']
        else:
            return self.create_response(request, 'not defined point or filters', HttpNotFound)  
       
        try:
            response = ExportData().getSpatialFilters(ptCoords, spatialFilters) 
                     
        except Exception, error:
        
            response = 'error: cannot get Export data spatial filters - %s' % (error)
            print response
            return self.create_response(request, response, HttpApplicationError)
        
        return self.create_response(request, response)
    
    
    def exportdata_stations(self, request, **kwargs):
                 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['get'])         
       
        response=""
        try: 
            sensorClass = request.GET['class']
            response = ExportData().getStationsSensor(request.user.id, sensorClass) 
                            
        except Exception, error:
          
            response = 'error: cannot get stations by sensor class - %s' % (error)
            print response
            return self.create_response(request, response, HttpApplicationError)                  
           
        return self.create_response(request, response)
     
           
    def exportdata(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
                return self.create_response(request, 'not authenticated', HttpUnauthorized)   
            
        self.method_check(request, allowed=['post'])
        datas = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json')) 
      
        
        if ('time_range' in datas and 'sensors' in datas and 'filters' in datas and 'cumulated' in datas and 'format' in datas and 'config' in datas):    
            time_range = datas['time_range']
            sensors = datas['sensors']
            filters = datas['filters']
            cumulated = datas['cumulated']
            format = datas['format']
            configSettings = datas['config']
            
        else:
            return self.create_response(request, 'not defined filters', HttpNotFound)  
               
        #exportData = None
        try:
            response = ExportData().getDatas(time_range, sensors, filters, cumulated, format, request.user.id, configSettings) 
                      
        except Exception, error:
            #exportData.delWorkingDir()
            response = 'impossibile esportare i dati - %s' % (error)
            print response
            return self.create_response(request, response, HttpApplicationError)
        
        return self.create_response(request, response)
    
