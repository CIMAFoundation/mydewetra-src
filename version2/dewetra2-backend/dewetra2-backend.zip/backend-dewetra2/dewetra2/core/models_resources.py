from tastypie.resources import ModelResource
from dewetra2.core.resources import DewetraResourceMeta
from dewetra2.models import Layer, Tag, LayerType, Server, LayerCategory,\
    UserSettings, Group, Path, Tool, GeoScale
from tastypie.constants import ALL_WITH_RELATIONS, ALL
from django.db.models import Q
from tastypie import fields
from dewetra2.core.permissions import DewetraLayerAuthorization,\
    DewetraUserSettingsAutorization, DewetraToolAutorization
from django.contrib.auth.models import User


class TagResource(ModelResource):
    class Meta(DewetraResourceMeta):
        queryset = Tag.objects.all()
        resource_name = 'settings/tags'
        list_allowed_methods = ['get']
        filtering = { 
            'name': ALL,           
            'id': ALL,
        }

class GeoScaleResource(ModelResource):
    class Meta(DewetraResourceMeta):
        queryset = GeoScale.objects.all()
        resource_name = 'settings/geoscales'
        list_allowed_methods = ['get']
        filtering = { 
            'name': ALL,           
            'id': ALL,
        }

class GroupResource(ModelResource):
    class Meta(DewetraResourceMeta):
        queryset = Group.objects.all()
        resource_name = 'settings/groups'
        list_allowed_methods = ['get']
        filtering = { 
            'name': ALL,           
            'id': ALL,
        }
        
class PathResource(ModelResource):
    class Meta(DewetraResourceMeta):
        queryset = Path.objects.all()
        resource_name = 'settings/paths'
        list_allowed_methods = ['get']

class ServerResource(ModelResource):
    class Meta(DewetraResourceMeta):
        queryset = Server.objects.all().order_by('id')

        resource_name = 'settings/servers'
        list_allowed_methods = ['get'] 
        fields = ['id', 'name', 'descr', 'url']       


class LayerTypeResource(ModelResource):
    class Meta(DewetraResourceMeta):
        queryset = LayerType.objects.all()
        resource_name = 'settings/layertypes'
        list_allowed_methods = ['get']
        filtering = {
            'name': ALL
        }

class LayerCategoryResource(ModelResource):
    class Meta(DewetraResourceMeta):
        queryset = LayerCategory.objects.all()
        resource_name = 'settings/layercategories'
        list_allowed_methods = ['get']
        filtering = {
            'name': ALL
        }

class LayerDescrResource(ModelResource):
    #tags = fields.ToManyField(TagResource, 'tags', full = True)
    class Meta(DewetraResourceMeta):
        limit = 0
        authorization = DewetraLayerAuthorization()
        queryset = Layer.objects.all()
        resource_name = 'settings/layersdescr'
        fields = ['id', 'name', 'dataid', 'descr']
#         fields = ['id', 'name', 'dataid', 'descr', 'tags']  
#     def dehydrate(self, bundle):
#         s = ''
#         for t in bundle.data['tags']:
#             s += t.data['name'] + ' '
#             
#         bundle.data['tags'] = s
#         return bundle

class UserSettingsResource(ModelResource):
    class Meta(DewetraResourceMeta):
        authorization = DewetraUserSettingsAutorization()
        queryset = UserSettings.objects.all()
        resource_name = 'settings/settings'
        
class LayerServerResource(ModelResource):
    server = fields.ForeignKey(ServerResource, 'server', full = True)
    class Meta(DewetraResourceMeta):
        fields = ['id', 'name', 'dataid']
        queryset = Layer.objects.all()
        resource_name = 'settings/layerserver'
        filtering = {
            'id': ALL,
            'name': ALL,
            'dataid': ALL,
        }
                
class LayerResource(ModelResource):
    type = fields.ForeignKey(LayerTypeResource, 'type', full = True)
    server = fields.ForeignKey(ServerResource, 'server', full = True)
    path = fields.ForeignKey(PathResource, 'path', null=True, blank=True, full = True)
    pathdrr = fields.ForeignKey(PathResource, 'pathdrr', null=True, blank=True, full = True)
    geoscale = fields.ForeignKey(GeoScaleResource, 'geoscale', null=True, blank=True, full = True)
    tags = fields.ToManyField(TagResource, 'tags', full = True)
    #groups = fields.ToManyField(GroupResource, 'groups', full = True)    
    category = fields.ForeignKey(LayerCategoryResource, 'category', full = True)
    class Meta(DewetraResourceMeta):
        authorization = DewetraLayerAuthorization()
        queryset = Layer.objects.all()
        resource_name = 'settings/layers'
        #list_allowed_methods = ['get']
        filtering = {
            'id': ALL,
            'tags': ALL_WITH_RELATIONS,
            'server': ALL_WITH_RELATIONS,
            'type': ALL_WITH_RELATIONS,
            'category': ALL_WITH_RELATIONS,
        }
        
    def build_filters(self, filters={}):
        orm_filters = super(ModelResource, self).build_filters(filters)
        if 'extent' in filters:
            orm_filters.update({'extent': filters['extent']})
        return orm_filters

    def apply_filters(self, request, applicable_filters):
        extent = applicable_filters.pop('extent', None)
        semi_filtered = super(ModelResource, self).apply_filters(request, applicable_filters)
        
        filtered = semi_filtered
        if extent:
            filtered = self.filter_bbox(filtered, extent)
        return filtered

    def filter_bbox(self, queryset, bbox):
        bbox = bbox.split(',')
        bbox = map(str, bbox)
        intersects = ~(Q(lonw__gt=bbox[2]) | Q(lone__lt=bbox[0]) |
                       Q(lats__gt=bbox[3]) | Q(latn__lt=bbox[1]))
        return queryset.filter(intersects)
    
    def dehydrate(self, bundle):
#         del bundle.data['category']
        #bundle.data['hierarchies'] = [g.data['hierarchy'] for g in bundle.data['groups']]
        #del bundle.data['groups']
        if bundle.data['path'] is not None: bundle.data['hierarchy'] = bundle.data['path'].data['hierarchy']
        del bundle.data['path']
        if bundle.data['pathdrr'] is not None: bundle.data['hierarchydrr'] = bundle.data['pathdrr'].data['hierarchy']
        del bundle.data['pathdrr']
        bundle.data['category'] = bundle.data['category'].data['name']
        return bundle


class ToolByUserResource(ModelResource):
    class Meta(DewetraResourceMeta):
        authorization = DewetraToolAutorization()
        queryset = Tool.objects.all()
        resource_name = 'settings/tools'

