import numpy
from urllib import urlencode
from owslib.wfs import WebFeatureService
from owslib.wcs import WebCoverageService
from osgeo import gdal, ogr, osr
import json
import shutil
import os
import glob
from datetime import datetime
from dewetra2.settings import DEWETRA2_TOOLS_RESOURCE
import zipfile
from _io import BytesIO

UNDEF_CLASS_NAME = 'NO_HAZARD'

class Scenario:
    
    def __init__(self, hazardZone, polygon):
                       
        try:                        
            self.workingDir = '%s/%s' % (DEWETRA2_TOOLS_RESOURCE, datetime.utcnow().strftime('%Y%m%d%H%M%S%f')[:-3])
            if not os.path.exists(self.workingDir):
                os.makedirs(self.workingDir)
            
            self.filterPoly = self.getFilterPoly(polygon)
            self.filterPolyCoords = self.getPolyCoords(polygon) 
            
            self.hazardFilteredLayerName = None
            self.hazardZoneClassField = None
            if(hazardZone is not None):
                self.hazardZoneClassField = str(hazardZone['classField'])
                self.hazardFilteredLayerName = self.getHazardScenario(hazardZone) 
                   
                
        except Exception as e:
            print 'cannot create Scenario - %s' % (e)
     
     
    def getFilterPoly(self, polygon): 
     
        filterPolygon = ogr.Geometry(ogr.wkbPolygon)
        polyRing = ogr.Geometry(ogr.wkbLinearRing)
        
        for coords in polygon:
            polyRing.AddPoint(coords['lng'], coords['lat'])
            
        filterPolygon.AddGeometry(polyRing) 
        
        return filterPolygon
     
     
       
    def getPolyCoords(self, polygon):
        
        filterPolyCoords = ""
              
        for coords in polygon:
            filterPolyCoords += "%s,%s " % (coords['lng'], coords['lat'])
        
        return filterPolyCoords
    
    def getHazardScenario(self, hazardZone):
                
        # COPY Hazard Zone shapefile to Workig directory
        shapefileOrgPath = str(hazardZone['filePath'])
                
        try:
            hzShapefile, hazardZone_layer_name = self.copyShapeToWorkingDir(shapefileOrgPath)
        except Exception as e:
            print 'cannot copy hazardZone shapefile to workingDir - %s' % (e)
            raise Exception('cannot copy hazardZone shapefile to workingDir - %s' % (e))   
        
        # Crate and save Filtered Hazard shapefile by filter polygon
        hazardFilteredLayerName = None
        try:
            hazardFilteredLayerName = self.getFilteredHazardLayer(self.filterPoly, hazardZone_layer_name)    
        except Exception as e:
            print 'cannot create hazard layer filtered by polygon - %s' % (e)
            raise Exception('cannot create hazard layer filtered by polygon - %s' % (e)) 
                    
        return hazardFilteredLayerName
    
    
    def getFilteredHazardLayer(self, filterPoly, hazardZone_layer_name):

        polyFilter_layer_name = 'poly_filter'
        polyfilePath = '%s/%s.shp' % (self.workingDir, polyFilter_layer_name)
        shpDriver = ogr.GetDriverByName('ESRI Shapefile')
        polyFilterDs = shpDriver.CreateDataSource(polyfilePath)
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(4326)
        polyFilterLayer = polyFilterDs.CreateLayer(polyFilter_layer_name, srs=srs, geom_type=ogr.wkbPolygon)
        idField = ogr.FieldDefn("id", ogr.OFTInteger)
        polyFilterLayer.CreateField(idField)
        featureDefn = polyFilterLayer.GetLayerDefn()
        feature = ogr.Feature(featureDefn)
        feature.SetGeometry(filterPoly)
        feature.SetField("id", 1)
        polyFilterLayer.CreateFeature(feature)
        polyFilterDs.Destroy()
        del polyFilterDs
        
        wdir_ds = ogr.Open(self.workingDir, True)     
        SQL1 = "SELECT H.geometry AS geometry, H.%s FROM %s AS H, %s AS P WHERE ST_Intersects(H.geometry, P.geometry);" % (self.hazardZoneClassField, hazardZone_layer_name, polyFilter_layer_name)
      
        hazardPolyLayer = wdir_ds.ExecuteSQL(SQL1, dialect='SQLITE')
        wdir_ds.FlushCache()

        hazardFiltered_layer_name = '%s_filtered' % hazardZone_layer_name   
        wdir_ds.CopyLayer(hazardPolyLayer, hazardFiltered_layer_name)
            
        
        wdir_ds.ReleaseResultSet(hazardPolyLayer)       
        polyFilterLayer = None
        hazardPolyLayer = None                    
        wdir_ds.Destroy()
        del wdir_ds
        
        return hazardFiltered_layer_name 


    def copyShapeToWorkingDir(self, shapefileOrgPath):
        shapefileFromName = os.path.splitext(os.path.basename(shapefileOrgPath))[0]
        shapefileFrom = '%s.*' % (os.path.splitext(shapefileOrgPath)[0])     
        
        for file in glob.glob(shapefileFrom):            
            shutil.copy(file, self.workingDir)
            if(file.split('.')[1] == 'shp'):
                shapefileWorking = '%s/%s.shp' % (self.workingDir, shapefileFromName)
                shapefileWorkingName = os.path.splitext(os.path.basename(shapefileWorking))[0]
                    
                    
        return shapefileWorking, shapefileWorkingName

    # DELETE WORKING DIR
    def delWorkingDir(self):
        if os.path.exists(self.workingDir):
            shutil.rmtree(self.workingDir)


class ScenarioRaster:
        
    def __init__(self, layer, scenario):
        
        try:
                 
            self.layer = layer
            slayerId = self.layer['wmsId'].encode('utf8')
            self.layerId = slayerId.replace(":", "_").replace(" ", "_")            
            self.workingDir = scenario.workingDir
            self.filterPoly = scenario.filterPoly
            self.filterPolyCoords = scenario.filterPolyCoords
            self.hazardFilteredLayerName = scenario.hazardFilteredLayerName
            self.hazardZoneClassField = scenario.hazardZoneClassField
            
        except Exception as e:
            print 'cannot create Scenario Raster - %s' % (e)
        
              

    def getRasterSumScenario(self):
        
        try:   
            ogrPoly, exposedRaster, rEPSG  = self.GetFilteredExposedFromWCS()
                        
                        
            try:  
                bandRaster = exposedRaster.GetRasterBand(1)
                noDataValue = bandRaster.GetNoDataValue()
           
                rasterArray = bandRaster.ReadAsArray()          
                dataRaster = numpy.array(rasterArray)
                
                if(numpy.all(dataRaster == noDataValue)):
                    result = {'data':[{'hazardZone': UNDEF_CLASS_NAME, 'sum':0}], 
                              'output':'impacts_sum',
                              'layer_id': self.layer['wmsId']
                              }
                    return result
            
            except Exception as e:
                print 'cannot get array from raster - %s' % (e) 
                raise Exception('cannot get array from raster - %s' % (e)) 
            
            
            
        except Exception as e:
            print 'cannot obtain Exposed Raster from WCS - %s' % (e)
            raise Exception('cannot obtain Exposed Raster from WCS - %s' % (e)) 
       
        
        if(self.hazardFilteredLayerName):
            
            try:
                hazardZone_sum_list = self.getHazardExposedFilteredSumList(ogrPoly, exposedRaster, rEPSG)
                   
            except Exception as e:
                print 'cannot obtain filtered raster - %s' % (e)
                raise Exception('cannot obtain filtered raster - %s' % (e))          
        
        
        else:    
           
            try:
                hazardZone_sum_list = self.getExposedFilteredSumList(ogrPoly, exposedRaster, rEPSG)
           
            except Exception as e:
                print 'cannot obtain filtered raster - %s' % (e)
                raise Exception('cannot obtain filtered raster - %s' % (e))  
           
                
        result = {'data':hazardZone_sum_list, 
                  'output':'impacts_sum',
                  'layer_id': self.layer['wmsId']
                  }
       
            
        return result



    def GetFilteredExposedFromWCS(self):
        
        wcs = WebCoverageService(url=self.layer['wmsServer'], version='1.0.0')
        contents = wcs.contents[self.layer['wmsId']]
        resolx = float(contents.grid.offsetvectors[0][0])
        resoly = abs(float(contents.grid.offsetvectors[1][1]))
        rfmt = "GeoTIFF"
        rCRS = contents.boundingboxes[0]['nativeSrs']
        rEPSG = int(rCRS.split(':')[1])
        sourceSR = osr.SpatialReference()
        sourceSR.ImportFromEPSG(4326)
        targetSR = osr.SpatialReference()
        targetSR.ImportFromEPSG(rEPSG)
        coordTrans = osr.CoordinateTransformation(sourceSR, targetSR)
       
        #create polygon
        ogrPoly = self.filterPoly
        ogrPoly.Transform(coordTrans)
        polyBBox = ogrPoly.GetEnvelope()
        
        minx = self.getReGriddedCoord(polyBBox[0], float(contents.boundingBoxWGS84[0]), resolx) - resolx
        miny = self.getReGriddedCoord(polyBBox[2], float(contents.boundingBoxWGS84[1]), resoly) - resoly
        maxx = self.getReGriddedCoord(polyBBox[1], float(contents.boundingBoxWGS84[0]), resolx) + resolx
        maxy = self.getReGriddedCoord(polyBBox[3], float(contents.boundingBoxWGS84[1]), resoly) + resoly
        filterBBOX = minx, miny, maxx, maxy
        wcsId = contents.id
        wcsUrl = self.composeWcs100Url(baseUrl=self.layer['wmsServer'], identifier=wcsId, bbox=filterBBOX, format=rfmt, resx=resolx, resy=resoly, crs=rCRS)
                
        try:
            registeredDriver = gdal.AllRegister()
            dodsDriver = gdal.GetDriverByName('DODS')
            if dodsDriver is not None:
                dodsDriver.Deregister()
               #for i in range(gdal.GetDriverCount()):
               #    print gdal.GetDriver(i).ShortName
            raster = gdal.Open(wcsUrl) #DEREGISTRO il DRIVER DODS che impedisce di aprire correttamente la geotiff
        
        except Exception as e:
            print 'cannot open raster - %s' % (e)
            raise Exception('cannot open raster - %s' % (e))
        
        return ogrPoly, raster, rEPSG


    

    def getExposedFilteredSumList(self, filterPoly, raster, rEPSG):
           
        driver = ogr.GetDriverByName('MEMORY')
        filterDataSource = driver.CreateDataSource('')
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(rEPSG)
        filterLayer = filterDataSource.CreateLayer("poly_filter", srs=srs, geom_type=ogr.wkbPolygon)
        # Add an ID field
        idField = ogr.FieldDefn("id", ogr.OFTInteger)
        filterLayer.CreateField(idField) # Create the feature and set values
        featureDefn = filterLayer.GetLayerDefn()
        feature = ogr.Feature(featureDefn)
        feature.SetGeometry(filterPoly)
        feature.SetField("id", 1)
        filterLayer.CreateFeature(feature)
 
        bandRaster = raster.GetRasterBand(1)
        noDataValue = bandRaster.GetNoDataValue()
        geoTransRaster = raster.GetGeoTransform()
  
        try:               
            dataRaster = numpy.array(bandRaster.ReadAsArray())
        except Exception as e:
            print 'ERROR 2A - %s' % (e) 
            raise Exception('cannot sum raster - %s' % (e))  
        
        xcount = dataRaster.shape[1]
        ycount = dataRaster.shape[0]
    
  
        # Create memory target raster
        target_ds = gdal.GetDriverByName('MEM').Create('', xcount, ycount, 1, gdal.GDT_Byte)
        target_ds.SetGeoTransform(geoTransRaster)
                    
        
        # Create for target raster the same projection as for the value raster
        raster_srs = osr.SpatialReference()
        raster_srs.ImportFromWkt(raster.GetProjectionRef())
        target_ds.SetProjection(raster_srs.ExportToWkt())
    
        # Rasterize polygon to raster
        options = ['ALL_TOUCHED=TRUE']
        try:
            gdal.RasterizeLayer(target_ds, [1], filterLayer, burn_values=[1], options=options)
        except Exception as e:
            print 'ERROR Rasterize Layer - %s' % (e) 
    
        #POLIGONO rasterizzato in formato array
        bandMask = target_ds.GetRasterBand(1)
        dataMask =numpy.array(bandMask.ReadAsArray())
        
        #RASTER in formato array senza nodatavalue
        dataRasterNoData = numpy.ma.masked_where(dataRaster == noDataValue, dataRaster)
        
        dataMask = dataMask.astype('float')
        dataMask[dataMask == 0] = numpy.nan
        
        filteredRaster = numpy.multiply(dataRasterNoData,dataMask)
        
        hazardZone_sum_list = [] 
        measureUnit = '(%s)' % self.layer['resultMu'] if 'resultMu' in self.layer else ''
        if ('resultType' in self.layer and self.layer['resultType']=='average'):
            #rAverage = numpy.nanmean(filteredRaster)
            rAverage = filteredRaster[filteredRaster>0].mean()
            #hazardZone_sum = {'hazardZone':UNDEF_CLASS_NAME, 'average': round(rAverage,2)}
            hazardZone_sum = {'hazardZone':UNDEF_CLASS_NAME, 'average': '%s %s' % (round(rAverage,2), measureUnit)}
        else:
            rSum = numpy.nansum(filteredRaster)  
            #hazardZone_sum = {'hazardZone':UNDEF_CLASS_NAME, 'sum': int(rSum)} 
            hazardZone_sum = {'hazardZone':UNDEF_CLASS_NAME, 'sum': '%s %s' % (int(rSum), measureUnit)} 
            
        hazardZone_sum_list.append(hazardZone_sum)
    
        return hazardZone_sum_list

       
    def getHazardExposedFilteredSumList(self, filterPoly, popRaster, rEPSG):
        
        driver = ogr.GetDriverByName('MEMORY')
        filterDataSource = driver.CreateDataSource('')
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(rEPSG)
        filterLayer = filterDataSource.CreateLayer("poly_filter", srs=srs, geom_type=ogr.wkbPolygon)
        # Add an ID field
        idField = ogr.FieldDefn("id", ogr.OFTInteger)
        filterLayer.CreateField(idField) # Create the feature and set values
        featureDefn = filterLayer.GetLayerDefn()
        feature = ogr.Feature(featureDefn)
        feature.SetGeometry(filterPoly)
        feature.SetField("id", 1)
        filterLayer.CreateFeature(feature)
 
        bandRaster = popRaster.GetRasterBand(1)
        noDataValue = bandRaster.GetNoDataValue()
        geoTransRaster = popRaster.GetGeoTransform()     
        popDataRaster = numpy.array(bandRaster.ReadAsArray())        
        xcount = popDataRaster.shape[1]
        ycount = popDataRaster.shape[0]
    
        ##################################################
        #FILTER POLY RASTERIZED
        ##################################################
        # Create memory target raster for Filtered 
        target_ds = gdal.GetDriverByName('MEM').Create('', xcount, ycount, 1, gdal.GDT_Byte)
        target_ds.SetGeoTransform(geoTransRaster) 
        
        # Create for target raster the same projection as for the value raster
        raster_srs = osr.SpatialReference()
        raster_srs.ImportFromWkt(popRaster.GetProjectionRef())
        target_ds.SetProjection(raster_srs.ExportToWkt())
    
        # Rasterize polygon to raster
        options = ['ALL_TOUCHED=TRUE']
        try:
            gdal.RasterizeLayer(target_ds, [1], filterLayer, burn_values=[1], options=options)
        except Exception as e:
            print 'ERROR Rasterize Filter Polygon - %s' % (e) 
    
        #POLIGONO rasterizzato in formato array
        bandMask = target_ds.GetRasterBand(1)
        dataMask =numpy.array(bandMask.ReadAsArray())
         
        ##################################################
        #FILTER POP RASTER ON RASTERIZED POLY
        ##################################################     
        #RASTER Degli Esposti in formato array senza nodatavalue
        popDataRasterNoData = numpy.ma.masked_where(popDataRaster == noDataValue, popDataRaster)
        popFilteredRaster = numpy.multiply(popDataRasterNoData,dataMask)
        popFilteredRaster[popFilteredRaster<0] = 0
        
        ##################################################
        #HAZARD SHAPEFILE RASTERIZED
        ##################################################
  
        hzShpFilePath = '%s/%s.shp' % (self.workingDir, self.hazardFilteredLayerName)
        
        shpDriver = ogr.GetDriverByName("ESRI Shapefile")
        hzShpDs = shpDriver.Open(hzShpFilePath, True)
        hzShpLayer = hzShpDs.GetLayer()
       
        hzFieldIDF = ogr.FieldDefn("IDF", ogr.OFTInteger64)
        hzShpLayer.CreateField(hzFieldIDF)
            
        hz_IDF_CLASS_Dic ={}    
        for feature in hzShpLayer:
            idf = feature.GetFID() + 1
            classVal = feature.GetField(self.hazardZoneClassField)
            feature.SetField("IDF", idf)
            hzShpLayer.SetFeature(feature)  
            hz_IDF_CLASS_Dic.update({idf:classVal})
            feature.Destroy()
 

        hzRaster_ds = gdal.GetDriverByName('MEM').Create('', xcount, ycount, 1, gdal.GDT_Byte)
        hzRaster_ds.SetGeoTransform(geoTransRaster) 
        hzRaster_ds.SetProjection(raster_srs.ExportToWkt())
        band = hzRaster_ds.GetRasterBand(1)
        band.SetNoDataValue(0)
        band.FlushCache()
        
        hzOptions = ['ALL_TOUCHED=TRUE', "ATTRIBUTE=IDF"]
        try:
            gdal.RasterizeLayer(hzRaster_ds, [1], hzShpLayer, burn_values=[1], options=hzOptions)
        except Exception as e:
            print 'ERROR Rasterize Filter Polygon - %s' % (e) 
        
        
        hzRasterBand = hzRaster_ds.GetRasterBand(1)
        hzRasterData = numpy.array(hzRasterBand.ReadAsArray())

        #MATRICE FILTRATA SUL POLIGONO DEGLI HAZARD PER FID
        hzfilteredRaster = numpy.multiply(hzRasterData,dataMask)
        min_len = numpy.max(hzfilteredRaster)+1
        
        measureUnit = '(%s)' % self.layer['resultMu'] if 'resultMu' in self.layer else ''
        
        #gestione del caso con media
        if ('resultType' in self.layer and self.layer['resultType']=='average'):
            aggregated_total_sum = None
            aggregated_occurrence = None
            hazardFullSum = 0.0
            hazardFullOccur = 0
            for i, row in enumerate(hzfilteredRaster):
                #forzo a zero gli elementi del hazard se l'elemento dell'esposto uguale a  zero, per scartare le occurrence che non devo considerare
                for index, elem in enumerate(popFilteredRaster[i]):
                    if (elem == 0): row[index]=0
                tmp = numpy.bincount(row, minlength=min_len, weights=popFilteredRaster[i])
                #valuto per la media i soli valori diversi da zero (row>0)
                val, nOccur = numpy.unique(row[row>0], return_counts=True)
                tmpOccur = numpy.zeros(shape=(min_len))
                for key in dict(zip(val, nOccur)): 
                    tmpOccur[key] = int(dict(zip(val, nOccur))[key])
                
                aggregated_total_sum = tmp if aggregated_total_sum is None else aggregated_total_sum + tmp         
                aggregated_occurrence = tmpOccur if aggregated_occurrence is None else aggregated_occurrence + tmpOccur   
                
            outputDic ={}
            occurDict ={}
            for key, value in hz_IDF_CLASS_Dic.iteritems(): 
                #associo ad ogni classe la somma dei valori e il numero di istanze
                if(aggregated_occurrence[key]>0):
                    if(key<min_len):
                        hazardFullSum += aggregated_total_sum[key]
                        hazardFullOccur += aggregated_occurrence[key]   
                        if(value in outputDic):
                            outputDic[value] = outputDic[value] + aggregated_total_sum[key]
                            occurDict[value] = occurDict[value] + aggregated_occurrence[key]
                        else:       
                            outputDic.update({value : aggregated_total_sum[key]})
                            occurDict.update({value : aggregated_occurrence[key]}) 
        
            hazardZone_list = []

            for key, value in outputDic.iteritems(): 
                #hazardZone_average = {'hazardZone':key, 'average': round((value/occurDict[key]),2)}
                hazardZone_average = {'hazardZone':key, 'average': '%s %s' % (round((value/occurDict[key]),2), measureUnit)}
                hazardZone_list.append(hazardZone_average)
                
            fullSum = numpy.sum(popFilteredRaster)
            fullOccur = popFilteredRaster[popFilteredRaster>0].size
            #media fatta come somma dei valori di tutte le celle>0 meno quelle degli hazard >0), diviso per il numero di celle non hazard
            if(fullOccur == hazardFullOccur):
                hazardZone_sum = {'hazardZone': UNDEF_CLASS_NAME, 'average': '-' }
            else:    
                unclass_average = (fullSum - hazardFullSum) / (fullOccur - hazardFullOccur)
                #hazardZone_sum = {'hazardZone': UNDEF_CLASS_NAME, 'average': round(unclass_average,2) }
                hazardZone_sum = {'hazardZone': UNDEF_CLASS_NAME, 'average': '%s %s' % (round(unclass_average,2), measureUnit)}
            hazardZone_list.append(hazardZone_sum)
        #gestione del caso con somma    
        else:
            aggregated_total_pop = None
            for i, row in enumerate(hzfilteredRaster):
                tmp = numpy.bincount(row, minlength=min_len, weights=popFilteredRaster[i])
                aggregated_total_pop = tmp if aggregated_total_pop is None else aggregated_total_pop + tmp         
    
            outputDic ={}
            for key, value in hz_IDF_CLASS_Dic.iteritems(): 
                #associo ad ogni classe il valore
                if(key<min_len): 
                    if(value in outputDic):
                        outputDic[value] = outputDic[value] + aggregated_total_pop[key] 
                    else:       
                        outputDic.update({value : aggregated_total_pop[key]})       
            
            hazardZone_list = []
            tot_class_pop = 0
                  
            for key, value in outputDic.iteritems(): 
                #hazardZone_sum = {'hazardZone':key, 'sum': int(value)}
                hazardZone_sum = {'hazardZone': key, 'sum': '%s %s' % (int(value), measureUnit)}
                hazardZone_list.append(hazardZone_sum)
                tot_class_pop += int(value)
                
            rSum = numpy.sum(popFilteredRaster)  
            unclass_pop = int(rSum) - tot_class_pop
            #hazardZone_sum = {'hazardZone': UNDEF_CLASS_NAME, 'sum': unclass_pop}
            hazardZone_sum = {'hazardZone': UNDEF_CLASS_NAME, 'sum': '%s %s' % (unclass_pop, measureUnit)}
            hazardZone_list.append(hazardZone_sum)
        
        
        hzShpDs.Destroy()
        del hzShpDs
        
        return hazardZone_list


    def getReGriddedCoord(self, coord, rasterOriginCoord, rasterRes):
        numPixels, rest = divmod((coord - rasterOriginCoord), rasterRes)
        reGriddedCoord = rasterOriginCoord + (numPixels * rasterRes) 
        return reGriddedCoord


    def composeWcs100Url(self, baseUrl=None, identifier=None, bbox=None, time=None, format = None,  crs=None, width=None, height=None, resx=None, resy=None, resz=None,parameter=None,method='Get',**kwargs):
       
        #process kwargs
        request = {'version': '1.0.0', 'request': 'GetCoverage', 'service':'WCS'}
        assert len(identifier) > 0
        
        request['Coverage']=identifier
        #request['identifier'] = ','.join(identifier)
        if bbox:
            request['BBox']=','.join([self.__makeString(x) for x in bbox])
        else:
            request['BBox']=None
        if time:
            request['time']=','.join(time)
        if crs:
            request['crs']=crs
        request['format']=format
        if width:
            request['width']=width
        if height:
            request['height']=height
        if resx:
            request['resx']=resx
        if resy:
            request['resy']=resy
        if resz:
            request['resz']=resz
          
        #anything else e.g. vendor specific parameters must go through kwargs
        if kwargs:
            for kw in kwargs:
                request[kw]=kwargs[kw]
          
        url = '%s?%s' % (baseUrl, urlencode(request))
                
        return url
 
 
    def __makeString(self, value):
        if type(value) is not str:
            sval=repr(value)
        else:
            sval = value
        return sval
    
    def copyShapeToWorkingDir(self, shapefileOrgPath):
        shapefileFromName = os.path.splitext(os.path.basename(shapefileOrgPath))[0]
        shapefileFrom = '%s.*' % (os.path.splitext(shapefileOrgPath)[0])     
         
        for file in glob.glob(shapefileFrom):            
            shutil.copy(file, self.workingDir)
            if(file.split('.')[1] == 'shp'):
                shapefileWorking = '%s/%s.shp' % (self.workingDir, shapefileFromName)
                shapefileWorkingName = os.path.splitext(os.path.basename(shapefileWorking))[0]
                     
                     
        return shapefileWorking, shapefileWorkingName


class ScenarioVector:
    
    def __init__(self, layer, scenario):
                       
        try: 
            self.layer = layer
            slayerId = self.layer['wmsId'].encode('utf8')
            self.layerId = slayerId.replace(":", "_").replace(" ", "_")
            self.wfs11 = WebFeatureService(url=layer['wmsServer'], version='1.1.0')
            self.geomType, self.geomFieldName = self.getWFSGeometryTypeName()
            
            self.workingDir = scenario.workingDir
            self.filterPoly = scenario.filterPoly
            self.filterPolyCoords = scenario.filterPolyCoords
            self.hazardFilteredLayerName = scenario.hazardFilteredLayerName
            self.hazardZoneClassField = scenario.hazardZoneClassField
            
        except Exception as e:
            print 'cannot create Scenario Vector - %s' % (e)
            
    
    def getWFSGeometryTypeName(self):
         
        #schema = wfs11.get_schema('scenario:ScuoleStatali_DPC')
        #Visto che wfs11.get_schema non funziona uso un espediente:
        try:  
            featSchema = self.wfs11.getfeature(typename=self.layer['wmsId'], maxfeatures = 1, outputFormat='application/json')
            jsonFeatSchema = json.loads(featSchema.read())
        except Exception as e:
            print 'cannot obtain WFS jsonFeatSchema - %s' % (e)
            raise Exception('no valid data found - %s' % (e))    
        
        if 'features' in jsonFeatSchema:
            features = jsonFeatSchema['features']   
            if 'geometry_name' in features[0]:
                geomPropName = features[0]['geometry_name']
            else:
                raise Exception('no valid data found in WFS')
            
            if 'geometry' in features[0]:
                geom = features[0]['geometry']
                if 'type' in geom:
                    geomType = geom['type']
                else:
                    raise Exception('no valid data found in WFS')
            else:
                raise Exception('no valid data found in WFS')
            
        else:
            raise Exception('no valid data found in WFS')
        
                
        return geomType, geomPropName
    

    def getVectorScenario(self):
        
        try:   
            exposedData = self.GetFilteredExposedFromWFS()
            
            expDataDic = json.loads(exposedData)
            if(not expDataDic['features']): 
                geojson_empty={"type": "FeatureCollection",
                               "features": []
                               }
                
                
                result = {'data' : geojson_empty, 
                          'output':'impacts_map',
                          'layer_id': self.layer['wmsId'] }
        
        
                return result
            
        except Exception as e:
            print 'cannot obtain Exposed data from WFS - %s' % (e)
            raise Exception('cannot obtain Exposed data from WFS - %s' % (e)) 
       
        try:   
            exposedDataOut = self.saveGeoJsonExposedToShape(exposedData)
        except Exception as e:
            print 'cannot save geoJson Exposed to shapefile in working dir - %s' % (e)
            raise Exception('cannot save geoJson Exposed to shapefile in working dir - %s' % (e))    
        
        
        if(self.hazardFilteredLayerName):
  
            SQL = "SELECT E.geometry AS geometry, E.*, " \
                  "CASE " \
                  "WHEN H.%s IS NULL THEN '%s' " \
                  "ELSE H.%s " \
                  "END AS %s " \
                  "FROM %s E " \
                  "LEFT JOIN %s H " \
                  "ON ST_Intersects(E.geometry, H.geometry);" % (self.hazardZoneClassField, UNDEF_CLASS_NAME, self.hazardZoneClassField, self.hazardZoneClassField, self.layerId, self.hazardFilteredLayerName)
             
            wdir_ds2 = ogr.Open(self.workingDir, True)       
            outLayer = wdir_ds2.ExecuteSQL(SQL, dialect='SQLITE')     
        
            exposedDataOut = {
                'crs': {'type': 'EPSG', 'properties' : {'code': '4326'}},
                'type': 'FeatureCollection',
                'features': []
                }
     
            for feature in outLayer:    
                exposedDataOut['features'].append(feature.ExportToJson(as_object=True))
             
            wdir_ds2.ReleaseResultSet(outLayer)  
            outLayer = None
            wdir_ds2.Destroy()
            del wdir_ds2
                   
        result = {'data' : exposedDataOut, 
                  'output':'impacts_map',
                  'layer_id': self.layer['wmsId'] }
        
        
        #return result
        return json.loads(json.dumps(result).encode('utf-8'))
    

    def getLineScenario(self):
        
        try:   
            exposedData = self.GetFilteredExposedFromWFS()
            
            expDataDic = json.loads(exposedData)
            if(not expDataDic['features']): 
                                
                result = {'data':[{'hazardZone': UNDEF_CLASS_NAME, 'sum':0}], 
                          'output':'impacts_sum',
                          'layer_id': self.layer['wmsId'] }
        
                return result
                        
        except Exception as e:
            print 'cannot obtain Exposed data from WFS - %s' % (e)
            raise Exception('cannot obtain Exposed data from WFS - %s' % (e)) 
        
        try:   
            exposedDataOut = self.saveGeoJsonExposedToShape(exposedData)
        except Exception as e:
            print 'cannot save geoJson Exposed to shapefile in working dir - %s' % (e)
            raise Exception('cannot save geoJson Exposed to shapefile in working dir - %s' % (e))    
        
        hazardZone_sum_list = [] 
        
        measureUnit = '(%s)' % self.layer['resultMu'] if 'resultMu' in self.layer else ''

        if(self.hazardFilteredLayerName):  
                          
            wdir_ds = ogr.Open(self.workingDir, True)
             
            SQL = "SELECT SUM(ST_Length(E.geometry, 1)) AS SUM " \
              "FROM %s E;" % (self.layerId) 
             
            layerAll = wdir_ds.ExecuteSQL(SQL, dialect='SQLITE')
               
            for feature in layerAll:
                if(feature.items()['SUM']):
                    sumMeters =  int(float(feature.items()['SUM']))
                    allSumKm = sumMeters/1000
                else:
                    allSumKm = 0
                feature.Destroy()
           
            wdir_ds.ReleaseResultSet(layerAll) 
            layerAll = None
                        
            SQL = "SELECT SUM(ST_Length(ST_Intersection(E.geometry, H.geometry), 1)) AS SUM, H.%s " \
                  "FROM %s E, %s H " \
                  "WHERE ST_Intersects(E.geometry, H.geometry) " \
                  "GROUP BY %s;" % (self.hazardZoneClassField, self.layerId, self.hazardFilteredLayerName, self.hazardZoneClassField) 
              
            layer = wdir_ds.ExecuteSQL(SQL, dialect='SQLITE')
 
            filteredSumKm = 0
            for feature in layer:
                hZone = feature.items()[self.hazardZoneClassField]
                if(feature.items()['SUM']):
                    sumMeters =  int(float(feature.items()['SUM']))
                    sumKm = sumMeters/1000
                    filteredSumKm += sumKm
                else:
                    sumKm = 0
                
                #hazardZone_sum_list.append({'hazardZone':hZone, 'sum':sumKm})
                hazardZone_sum_list.append({'hazardZone':hZone, 'sum':'%s %s' % (sumKm, measureUnit)})
                feature.Destroy()
           
            wdir_ds.ReleaseResultSet(layer)
            layer = None
            
            unfilteredSumKm = allSumKm - filteredSumKm
            #hazardZone_sum_list.append({'hazardZone': UNDEF_CLASS_NAME, 'sum':unfilteredSumKm})
            hazardZone_sum_list.append({'hazardZone': UNDEF_CLASS_NAME, 'sum':'%s %s' % (unfilteredSumKm, measureUnit)})

             
            wdir_ds.Destroy()
            del wdir_ds
        else:
            
            SQL = "SELECT SUM(ST_Length(E.geometry, 1)) AS SUM " \
              "FROM %s E;" % (self.layerId) 
             
            wdir_ds = ogr.Open(self.workingDir, True)
            layer = wdir_ds.ExecuteSQL(SQL, dialect='SQLITE')
               
            for feature in layer:
                hZone = UNDEF_CLASS_NAME
                if(feature.items()['SUM']):
                    sumMeters =  int(float(feature.items()['SUM']))
                    sumKm = sumMeters/1000
                else:
                    sumKm = 0
                
                #hazardZone_sum_list.append({'hazardZone':hZone, 'sum':sumKm})
                hazardZone_sum_list.append({'hazardZone':hZone, 'sum':'%s %s' % (sumKm, measureUnit)})
                feature.Destroy()
            
            wdir_ds.ReleaseResultSet(layer)
            layer = None
            
            wdir_ds.Destroy()
            del wdir_ds
                 
        result = {'data':hazardZone_sum_list, 
                  'output':'impacts_sum',
                  'layer_id': self.layer['wmsId'] }
       
        
        return result
        
        
    def GetFilteredExposedFromWFS(self):
        filterxml = """<Filter>
                  <Intersects>
                    <PropertyName>""" + self.geomFieldName + """</PropertyName>
                    <Polygon srsName="http://www.opengis.net/gml/srs/epsg.xml#4326">
                      <exterior>
                        <LinearRing>
                          <coordinates>""" + self.filterPolyCoords + """</coordinates>
                        </LinearRing>
                      </exterior>
                    </Polygon>
                  </Intersects>
            </Filter>"""
        filterxml.decode("utf-8")
        # get filtered Exposed layer as GeoJson
        filteredExposed = self.wfs11.getfeature(typename=self.layer['wmsId'], outputFormat='application/json', filter=filterxml)
        exposedData = filteredExposed.read()
        return exposedData


    def saveGeoJsonExposedToShape(self, exposedData):
        
        # SAVE Exposed GeoJson to Workig directory
        jsonLayerName = self.layerId
        jsonFilePath = '%s/%s.json' % (self.workingDir, jsonLayerName)
        with open(jsonFilePath, 'w') as f:
            f.write(exposedData)
        gjDriver = ogr.GetDriverByName("GeoJSON")
        gjDataSource = gjDriver.Open(jsonFilePath, 0)
             
        #SWAP GEOJSON COORDINATES (FROM WFS1.1.0) TO BE COMPLIANT...
        sql = "SELECT SwapCoordinates(geometry) AS geometry, * FROM %s" % (jsonLayerName)
         
        swappedLayer = gjDataSource.ExecuteSQL(sql, dialect='SQLITE')
        
        geoJson = {
            'crs': {'type': 'EPSG', 'properties' : {'code': '4326'}},
            'type': 'FeatureCollection',
            'features': []
            }
       
        for feature in swappedLayer:    
            geoJson['features'].append(feature.ExportToJson(as_object=True))
         
               
        #CREATE A SHAPEFILE IN WORKINDIR FOR INTERSECTION
        shpLayerName = self.layerId
        shpFilePath = '%s/%s.shp' % (self.workingDir, shpLayerName)
        shpDriver = ogr.GetDriverByName("ESRI Shapefile")
        shpDataSource = shpDriver.CreateDataSource(shpFilePath)       
        shpDataSource.CopyLayer(swappedLayer, shpLayerName)       
        
        
        
        shpDataSource.Destroy()
        del shpDataSource
        
        gjDataSource.ReleaseResultSet(swappedLayer)
        swappedLayer = None
        gjDataSource.Destroy()
        del gjDataSource
        
        return geoJson
               
            
class ScenarioUtility:
    
    def __init__(self):
        
        try:
            self.workingDir = '%s/%s' % (DEWETRA2_TOOLS_RESOURCE, datetime.utcnow().strftime('%Y%m%d%H%M%S%f')[:-3])
            #self.scenarioPolyDir = '%s/%s' % (self.workingDir, 'scenarioPoly')
            if not os.path.exists(self.workingDir):
                os.makedirs(self.workingDir)
        except Exception as e:
            print 'cannot create Scenario Utility - %s' % (e)
        
        
            
    def getZippedShapeFile(self, polygon):
        
        ogrPoly = ogr.Geometry(ogr.wkbPolygon)
        ogrRing = ogr.Geometry(ogr.wkbLinearRing)
        for coords in polygon:
            ogrRing.AddPoint(coords['lng'], coords['lat'])
         
        ogrPoly.AddGeometry(ogrRing)
        
        #commentato il controllo per incompatibilita con alcune versioni delle gdal
#         if (not ogrPoly.IsValid()): 
#             raise Exception('is not a valid polygon')  
      
        driver = ogr.GetDriverByName('ESRI Shapefile')
        polylayerName = 'polygon_filter'
        polyfilePath = '%s/%s.shp' % (self.workingDir, polylayerName)
        ds = driver.CreateDataSource(polyfilePath)
        
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(4326)
                 
        layer = ds.CreateLayer('poly', srs=srs, geom_type=ogr.wkbPolygon)
        
        # Add an ID field
        idField = ogr.FieldDefn("id", ogr.OFTInteger)
        layer.CreateField(idField)      
        
        feature = ogr.Feature(layer.GetLayerDefn())
        feature.SetGeometry(ogrPoly)
        feature.SetField("id", 1)
        
        layer.CreateFeature(feature)
                
        feature.Destroy()
        ds.Destroy()
        del ds 
        
#         #Zip shapefile
#         zipFileName = '%s/%s.zip' % (self.workingDir, polylayerName)
#          
#         if not os.path.exists(zipFileName):
#             
#             zipf = zipfile.ZipFile(zipFileName, 'w', zipfile.ZIP_DEFLATED)
#         
#             for root, dirs, files in os.walk(self.workingDir):
#                 for file in files:
#                     #zipf.write(os.path.join(root, file))
#                     zipf.write(os.path.join(root, file), os.path.basename(file))
#             zipf.close()   
        

        #zipFileBuffer = StringIO.StringIO()
        zipFileBuffer = BytesIO()
        zipf= zipfile.ZipFile( zipFileBuffer, "w" )
        for root, dirs, files in os.walk(self.workingDir):
            for file in files:
                zipf.write(os.path.join(root, file), os.path.basename(file))
       
        zipf.close()
        
        return zipFileBuffer
    
    
    def getPolyFromZipShapeFile(self, uFile):
        
        try:
            zipFilePath = '%s/%s' % (self.workingDir, uFile.name)
                
            with open(zipFilePath, 'wb+') as destination:
                for chunk in uFile.chunks():
                    destination.write(chunk)
        except Exception as e:
            errMsg = 'cannot save zip file - %s' % (e) 
            print(errMsg)
            raise Exception(errMsg) 
        
        
        try:
            if zipfile.is_zipfile(zipFilePath):   
                with zipfile.ZipFile(zipFilePath, 'r') as zip_ref:
                    zip_ref.extractall(self.workingDir)
        except Exception as e:
            errMsg = 'cannot extract zip file - %s' % (e) 
            print(errMsg)
            raise Exception(errMsg) 
        
                
        jsonPoly =""
        
        
        try:
                         
            driver = ogr.GetDriverByName('ESRI Shapefile')
                        
            fileToFind = '%s/*.shp' % self.workingDir
            shpFilesList = glob.glob(fileToFind) 
            #se shpFilesList length diverso da zero...
            if not shpFilesList:
                  raise Exception('not a valid shapefile')
                
            data_source = driver.Open(shpFilesList[0], 0)
            lyr = data_source.GetLayer()
            if not lyr:
                  raise Exception('not a valid layer')
            
            spatialRef = lyr.GetSpatialRef()
            epsgVal = spatialRef.GetAttrValue('AUTHORITY',1)      
            
            if not epsgVal == '4326':
                raise Exception('not a valid SRS! It needs EPSG:4326')
            
            #prendo un solo poligono
            shpFeature = lyr[0]
            geom = shpFeature.GetGeometryRef()
            #commentato il controllo per incompatibilita con alcune versioni delle gdal
#             if (not geom.IsValid()) or (not geom.IsSimple()):
#                 raise Exception('not a valid shapefile')
            
            
            if (geom.GetGeometryName() == 'POLYGON' or geom.GetGeometryName() == 'MULTIPOLYGON'):
                jsonPoly = {"polygonFilter":[]
                        }
                
                ring = geom.GetGeometryRef(0)
                ringNumPoints=0
                if (ring.GetPointCount()>0):
                    ringNumPoints = ring.GetPointCount()
                elif (ring.GetGeometryCount() > 0):
                    ring = ring.GetGeometryRef(0)
                    ringNumPoints = ring.GetPointCount()

                for pt in xrange(ringNumPoints):
                    lon, lat = ring.GetPoint_2D(pt)
                   
                    ptCoords = {"lat":lat,
                                "lng":lon
                                }
                    jsonPoly["polygonFilter"].append(ptCoords)
                    
                
         
        except Exception as e:
            errMsg = 'cannot get polygon from shapefile - %s' % (e) 
            print(errMsg)
            raise Exception(errMsg)
        
        
        return jsonPoly
     
    
     # DELETE WORKING DIR
    def delWorkingDir(self):
        if os.path.exists(self.workingDir):
            shutil.rmtree(self.workingDir)

    