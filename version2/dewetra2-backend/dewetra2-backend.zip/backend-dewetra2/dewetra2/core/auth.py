"""authorization management

- a user is equivalent to an acroweb configuration ( = dewetra profile)

- each request is processed in this way: 
if it contains the acroweb token query param then the configuration name for dewetra2 is asked to the acroweb api 
if a valid configuration is returned then get the "configuration user"
if the "configuration user" does not exists, raise an error "configuration not defined"
"""
from django.contrib.auth.models import User

from dewetra2.settings import DEW_LOGGER
from acroweb.core.auth import AcrowebAuthBackend, AcrowebUserResource
from acroweb.core.auth_oidc import AcrowebOIDCAuthMiddleware
from dewetra2.appsettings import KEYCLOACK_DEW2_CLIENT_ID,\
    KEYCLOACK_DEW2_CLIENT_SECRET

class Dewetra2AuthBackend(AcrowebAuthBackend): 
    """
    authenticate each user in the portal auth system
    use the user hat as django user id
    """
        
    def getApplicationName(self):
        return 'dewetra2'
        
    def getUserProfile(self, username):
        try:
            user = User.objects.get(username=username) #TODO ripristinare username    
            return user
        except:
            DEW_LOGGER.error('dewetra profile not defined: %s'%username)
            return User.objects.get(username='anonymous')
    

class Dewetra2OIDCAuthMiddleware(AcrowebOIDCAuthMiddleware): 
    """
    """
        
    def get_application_id(self):
        """
        return the client_id and the client_secret
        each backend must override and return his data
        """
        #TODO: get from settings (environment variables)
        return KEYCLOACK_DEW2_CLIENT_ID, KEYCLOACK_DEW2_CLIENT_SECRET
    
    def get_user(self, token_obj, role):
        """
        return the user object given the token object
        each backend must override and return the request object
        """
        if role is None: 
            print('dewetra2_api: received authenticated request without acroweb role')
            return None
        return User.objects.get(username=role)
    

    
class DewetraUserResource(AcrowebUserResource):
    """
    user resource
    """
    class Meta:
        queryset = User.objects.all()
        fields = ['first_name', 'last_name', 'email']
        allowed_methods = ['get', 'post']
        resource_name = 'user'        

