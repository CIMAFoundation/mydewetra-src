from dewetra2.core.resources import DewetraResourceMeta
from acroweb.core.resources import AcrowebResource, URLHelper
from tastypie.http import HttpUnauthorized, HttpApplicationError
from dewetra2.core.manage_doc import DocUtil
from dewetra2.settings import DEWETRA2REPORT_BASE_URL,\
    REPORTER_FORECAST_DATAS_BASE_PATH, DEWETRA2REPORT_BASE_DIR
import glob
from os.path import os
import datetime



class ReportUtilRes(AcrowebResource):
    
    class Meta(DewetraResourceMeta):
        resource_name = 'reportUtils'
        
    def getMyUrl(self):
        return [
                URLHelper('/getReportDocUrl', 'getReportDocUrl'),
                URLHelper('/uploadImg', 'uploadImg'),
                URLHelper('/forecastDatas/availability', 'getForecastDatasAvailability')
                ]
      
      
    def getReportDocUrl(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
        report = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
      
        try:            
            docUtil = DocUtil(report, request.user)
            relDocPath = docUtil.createDoc() 
             
        except Exception, myerror:
            return self.create_response(request, 'Error: cannot create report doc!', HttpApplicationError)
           

        response = {
                    'reportUrl': DEWETRA2REPORT_BASE_URL + relDocPath
                    
                } 
        
        
        return self.create_response(request, response)
    
    
    # *********  Uppload Bulletin  ********  
    def uploadImg(self, request, **kwargs):        
         
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized) 
                               
        self.method_check(request, allowed=['post'])
        
        #posso uploadare  un solo file
        if request.FILES.values():
            uFile = request.FILES.values()[0]
            
            uploadDir = DEWETRA2REPORT_BASE_DIR + uFile.name.replace('_','/')
            outputDirPath = os.path.dirname(uploadDir)
            if not os.path.exists(outputDirPath):
                os.makedirs(outputDirPath) 
            
            with open(uploadDir, 'wb+') as temp_file:
                for chunk in uFile.chunks():
                    temp_file.write(chunk)
                           
        return self.create_response(request, uploadDir)
    
     
    
    def getForecastDatasAvailability(self, request, **kwargs):     
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
         
        self.method_check(request, allowed=['post'])
        prevDatasReq = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        if ('dataTypeId' not in prevDatasReq) or prevDatasReq['dataTypeId'] == None:
            return self.create_response(request, '"dataTypeId" parameter is missing', HttpApplicationError)    
        if ('from' not in prevDatasReq) or prevDatasReq['from'] == None:
            return self.create_response(request, '"from" parameter is missing', HttpApplicationError)      
        if ('to' not in prevDatasReq) or prevDatasReq['to'] == None:
            return self.create_response(request, '"to" parameter is missing', HttpApplicationError)  
        
        dataType = prevDatasReq['dataTypeId']
        toUtcSec = int(prevDatasReq['to'])
        fromUtcSec = int(prevDatasReq['from'])
        fromUtcDateTime = datetime.datetime.utcfromtimestamp(fromUtcSec)
        toUtcDateTime = datetime.datetime.utcfromtimestamp(toUtcSec)
        
        fromYear = fromUtcDateTime.strftime('%Y')
        fromMonth = fromUtcDateTime.strftime('%m')
        fromDay = fromUtcDateTime.strftime('%d')
        fromHour = fromUtcDateTime.hour
        
        toYear = toUtcDateTime.strftime('%Y')
        toMonth = toUtcDateTime.strftime('%m')
        toDay = toUtcDateTime.strftime('%d')
        toHour = toUtcDateTime.hour
        
        run = "0000" if (toHour<12) else "1200"
        
        relPath = '%s/%s/%s/%s/'%(toYear, toMonth, toDay, run)
        dirPath = '%s%s'%(REPORTER_FORECAST_DATAS_BASE_PATH, relPath)
        run_date = None
            
        if os.path.exists(dirPath):
            run_hour = '00' if (run == "0000") else '12'
            run_date = "%s/%s/%s %sUTC" % (toYear, toMonth, toDay, run_hour)
        else: 
            if run == "1200":
                relPath = '%s/%s/%s/0000/'%(toYear, toMonth, toDay)
                dirPath = '%s%s'%(REPORTER_FORECAST_DATAS_BASE_PATH, relPath)
                if os.path.exists(dirPath):
                    run_date = "%s/%s/%s 00UTC" % (toYear, toMonth, toDay)
            else:
                relPath = '%s/%s/%s/1200/'%(fromYear, fromMonth, fromDay)
                dirPath = '%s%s'%(REPORTER_FORECAST_DATAS_BASE_PATH, relPath)
                if os.path.exists(dirPath):
                    run_date = "%s/%s/%s 12UTC" % (fromYear, fromMonth, fromDay)
            
            
        if (run_date == None):
            return self.create_response(request, 'cannot find forecast datas', HttpApplicationError)
        
        try:   
            #searchPattern = "%s*%s*@(@_006|@_012)*.PNG" % (dirPath,dataType)   
            forecastHourList = ['006', 
                                '012',
                                '018',
                                '024', 
                                '030',
                                '036',
                                '042',
                                '048']
            
            forecastDatasList = []
            
            for forecastHour in forecastHourList:
                searchPattern = "%s*%s*@_%s*.PNG" % (dirPath,dataType,forecastHour)
                dataPath = glob.glob(searchPattern)[0] if (glob.glob(searchPattern)) else None
                run_descr = "%s +%s" % (run_date, forecastHour)
                
                runDatas ={
                           'descr': run_descr,  
                           'path': dataPath
                          }    
                if(dataPath): forecastDatasList.append(runDatas)
           
        except Exception, error:
            return self.create_response(request, 'cannot find forecast datas: ' + error, HttpApplicationError)
           
        response = {'runs': forecastDatasList
                    } 
                
        return self.create_response(request, response)
    
        
    if __name__ == '__main__':
        
        getForecastDatasAvailability(None, None)
    
