import json
from mimetypes import guess_type
import os


from django.http.response import HttpResponse
import requests
from tastypie.http import HttpUnauthorized, HttpApplicationError, HttpNotFound
from wsgiref.util import FileWrapper

from acroweb.core.resources import AcrowebResource, URLHelper
from dewetra2.core.resources import DewetraResourceMeta
from dewetra2.settings import AUTPOR_REPORT_BASE_DIR


class UtilRes(AcrowebResource):
    
    class Meta(DewetraResourceMeta):
        resource_name = 'utils'
        
    def getMyUrl(self):
        return [
                URLHelper('/download_apreport', 'downloadAutporReport'),
                URLHelper('/proxy', 'proxy'),
                URLHelper('/wmsproxy/%s' %(self.strParam('wmsproxyid')), 'wmsproxy'),
                URLHelper('/genericproxy', 'genericproxy')
                ]
      
    def downloadAutporReport(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['get'])
                
        reqFileName = request.GET['filename']
        
        if reqFileName.startswith('/'):
            return self.create_response(request, 'absolute file path not allowed', HttpApplicationError)
        
        theFile = os.path.join(AUTPOR_REPORT_BASE_DIR, reqFileName)

        print theFile
        
        if not os.path.exists(theFile):
            return self.create_response(request, 'file not found', HttpNotFound)

        theFileName = os.path.basename(theFile)
        
        theType = guess_type(theFileName)[0]
        response = HttpResponse(FileWrapper(open(theFile, 'r')), content_type=theType)
        response['Content-Disposition'] = 'attachment; filename=%s' % theFileName
        response['Content-Length'] = os.stat(theFile).st_size

        return response
    
    def proxy(self, request, **kwargs):        
 
        if request.user is None or not request.user.is_authenticated(): 
            return self.create_response(request, 'not authenticated', HttpUnauthorized)   
        
        self.method_check(request, allowed=['post'])
                
        data = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        
        method = data.get('method', 'get')
        json_response = data.get('json_response', 'true')
        
        if method == 'post':
            response = requests.post(
                      data.get('url'),
                      params = data.get('paramas', {}),
                      headers = data.get('header', {'content-type': 'application/json'}),
                      json = json.dumps(data.get('body', {}))
                      )
        else:
            response = requests.get(
                      data.get('url'),
                      params = data.get('paramas', {}),
                      headers = data.get('header', {'content-type': 'application/json'}),
                      )
        
        if response is None:
            return self.create_response(request, 'error proxying request: Null responce received', HttpApplicationError)
        
        return self.create_response(request, {
            'status': response.status_code,
            'reason': response.reason,
            'content': json.loads(response.content) if json_response=='true' else response.content 
            })
    
    
   

    def wmsproxy(self, request, **kwargs):        
                     
        self.method_check(request, allowed=['get'])     
        #self.getClientInfo(request)     
        
        wmsRequest = None
        
        if (kwargs['wmsproxyid'] == 'safe'):
            wmsParams =''
            for key, value in request.REQUEST.iteritems():
                wmsParams += '&%s=%s' % (key, value)
            
            wmsRequest = 'https://www.efas.eu/api/wms/?token=43d659407f49373ea8d7c02046d3c8d2' + wmsParams
                              
        else:
            return self.create_response(request, 'error proxying request: Not a valid wms proxy id', HttpApplicationError)
       
        wmsResponse = requests.get(wmsRequest)
        if wmsResponse is None:
            return self.create_response(request, 'error proxing request: Null responce received', HttpApplicationError)
        else:
            return self.getHttpResponse(wmsResponse)
     
        
    def genericproxy(self, request, **kwargs):        
         
#         if request.user is None or not request.user.is_authenticated(): 
#             return self.create_response(request, 'not authenticated', HttpUnauthorized) 
                     
        self.method_check(request, allowed=['get'])      
               
        urlRequest = None
        wmsParams = ''
        for key, value in request.REQUEST.iteritems():
            if(key =='url'): 
                urlRequest = value
            else:
                wmsParams += '&%s=%s' % (key, value)
        
        if urlRequest is not None:
            try:            
                wmsResponse = requests.get(urlRequest+wmsParams)
            except Exception as e:
                return self.create_response(request, 'error proxing request: not a valid url parameter - %s' % (e), HttpApplicationError)  
           
        else:    
            return self.create_response(request, 'error proxing request: url parameter is not defined', HttpApplicationError)  
        
        if wmsResponse is None:
            return self.create_response(request, 'error proxing request: No responce received', HttpApplicationError)
        else:
            return self.getHttpResponse(wmsResponse)
        
    def getHttpResponse(self, wmsResponse):
        
        httpResponse = HttpResponse(wmsResponse.content)
        
        for headerKey in wmsResponse.headers.keys():
        #print('%s - %s' % (headerKey, wmsResponse.headers[headerKey]))
#             if (headerKey != 'Keep-Alive' and headerKey != 'Connection' and headerKey != 'Transfer-Encoding' and headerKey != 'Content-Encoding'):
#                 httpResponse.__setitem__(headerKey, wmsResponse.headers[headerKey])
            if (headerKey.lower() == 'Content-Type'.lower() or headerKey.lower() == 'Date'.lower()):
                httpResponse.__setitem__(headerKey, wmsResponse.headers[headerKey])
                
        return httpResponse   


    def getClientInfo(self, request):
       
        host = request.META.get('HTTP_HOST')
        if(host): print('host: %s' % host)
              
        remoteHost = request.META.get('REMOTE_HOST')
        if(remoteHost): print('remoteHost: %s' % remoteHost)
               
        ip_address = request.META.get('REMOTE_ADDR')
        if(ip_address): print('ip_address: %s' % ip_address)
        
        referer = request.META.get('HTTP_REFERER')
        if(referer): print('referer: %s' % referer)
                 
        server = request.META.get('SERVER_NAME')
        if(server): print('server: %s' % server)
        
        return "done"
    
