'''
Created on 2 Dec 2015

@author: doy
'''
from django.contrib.admin.options import ModelAdmin
from django.contrib import admin
from dewetra2.models import Layer, Tag, Server, LayerType, LayerCategory, Group,\
    LayerGroupPermission, UserSettings, Path, GeoScale, Widget, WidgetPropAttr, Event

class Dewetra2LayerAdmin(ModelAdmin):
    save_as = True
    filter_horizontal = ('tags','groups',)
    list_max_show_all = 1000
    list_per_page = 200
    search_fields = ['dataid','name']
    
    

admin.autodiscover()

admin.site.register(Layer, Dewetra2LayerAdmin)
admin.site.register(Tag)
admin.site.register(GeoScale)
admin.site.register(Server)
admin.site.register(LayerType)
admin.site.register(LayerCategory)
admin.site.register(Group)
admin.site.register(Path)
admin.site.register(LayerGroupPermission)
admin.site.register(UserSettings)
admin.site.register(Event)

admin.site.register(Widget)
admin.site.register(WidgetPropAttr)
