import os
import time
import glob
import shutil
import traceback
from datetime import datetime, timedelta

import django
django.setup()

from dewetra2.dds.dds_client import DDSMapClient


if __name__ == '__main__':
    
    output_dir = '/var/lib/geoserver_data/ddsData/simb'
    published_dir = '/var/lib/geoserver_data/ddsData'
    
    dds_server = ("http://bolivia.dewetra.cimafoundation.org/geoserver", "admin", "geoBOL2013")

    data = {
        'CPTEC_WRF5KM': {
            'Temperature;2.0': {},
            'Relative_humidity;2.0': {},
            'Total_precipitation;-': {
                'aggregation': '24'
            },
            'MODULE;10.0': {},
        },
        'RISICOBOLIVIA_CPTECWRF': {
            'RISICOBOLIVIA-CPTECWRF_V-MAX;0': {}
        },
        'RISICOBOLIVIA_CPTECWRF_AGGR': {
            'RISICOBOLIVIA-CPTECWRF_GEN-PERC75-V': {},
        },
    }

    expected_timeline_hours = {
        'CPTEC_WRF5KM': 18,
        'RISICOBOLIVIA_CPTECWRF_AGGR': 0,
        'RISICOBOLIVIA_CPTECWRF': 0
    }
            
    expected_variable_timeline_add_hours = {
        'CPTEC_WRF5KM.Total_precipitation;-': 6,
    }

    t2 =  time.time()
    t1 = t2 - 1*86400
    
    client = DDSMapClient(*dds_server)

    for layer_id in data:

        for layer_variable in data[layer_id]:

            try:

                search_run = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
                search_timeline = search_run.replace(hour=expected_timeline_hours[layer_id])
                key = '%s.%s'%(layer_id, layer_variable)
                if key in expected_variable_timeline_add_hours:
                    search_timeline = search_timeline + timedelta(hours=expected_variable_timeline_add_hours[key])

                prop = client.properties(layer_id)
        
                attr_to_set = {}
                for attr in prop['layerProperties']['attributes']:
                    if 'visible' in attr and attr['visible'] != 'false' and "var" in attr['name']:                
                        if not isinstance(attr['entries'], list):  attr['entries'] = [attr['entries']]
                        for entry in attr['entries']:
                            variable_id = entry['value'].encode('utf-8')
                            if variable_id == layer_variable:
                                attr_to_set = data[layer_id][variable_id]
                                print('\tfound variable %s --> %s'%(layer_id, entry['value'].encode('utf-8')))
                                attr['selectedEntry'] = entry
                                break;

                for attr in prop['layerProperties']['attributes']:
                    if attr['name'] in attr_to_set:
                        for entry in attr['entries']:
                            entry_value = entry['value'].encode('utf-8')
                            if entry_value == attr_to_set[attr['name']]:
                                attr['selectedEntry'] = entry
                                print('\t\tsetting attribute %s to %s'%(attr['name'], entry_value))

                            
                dates = client.availability(prop, t1, t2)
                for d in dates:
                    ts = d['id'].split(';')
                    run_date = datetime.fromtimestamp(float(ts[0])/1000)
                    timeline_date = datetime.fromtimestamp(float(ts[1])/1000)
                    if run_date == search_run and timeline_date == search_timeline:
                        print('\tpublishing RUN: %s --> TS: %s'%(run_date, timeline_date))

                        pub_result = client.publish(prop, d, t1, t2)
                        published_layer_id = pub_result['layerid']
                        layer_type = pub_result['layertype']
                        src_base_file = os.path.join(published_dir, published_layer_id)

                        for file in glob.glob('%s.*'%src_base_file):
                            filename, file_extension = os.path.splitext(file)
                            variable = variable_id.split(';')[0]              
                            output_file = os.path.join(output_dir, '%s-%s%s'%(layer_id, variable, file_extension))
                            print ('\t\t\tCOPYING %s to %s'%(file, output_file))
                            
                            # shutil.copy(file, output_file)
                        break

            except Exception as e:
                print("ERROR: %s"%str(e))
                traceback.print_exc()
