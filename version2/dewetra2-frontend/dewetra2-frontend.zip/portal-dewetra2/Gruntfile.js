
module.exports = function(grunt) {
    var target = grunt.option('target');

    var skinOption = grunt.option('skin');

    var skin = 'dewetraless';

    if(skinOption){
        skin = skinOption;
    }
    //region=EN&language=en
    const lang = {
        'world': 'region=EN&language=en',
        'world_ssl': 'region=EN&language=en',
        'world_test': 'region=EN&language=en',
        'world_test_nokeycloak': 'region=EN&language=en',
        'seawetra': 'region=EN&language=en',
        'seawetra_dev': 'region=EN&language=en',
        'test': 'region=IT&language=it',
        'staging': 'region=IT&language=it',
        'ufficiale': 'region=IT&language=it',
        'caribbean': 'region=En&language=en',
        'bolivia': 'region=ES&language=es',
    }

    let localization = 'region=EN&language=en';

    if (target && Object.keys(lang).indexOf(target)>-1){
        console.log('Lang: ', lang[target]);
        localization = lang[target];
    }

    console.log(skin);

    // Project configuration.
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        gitinfo:{},
        watch: {
            css: {
                files: [
                    // '../../portals/mydewetra/skin/style.css',
                    // '../../portals/mydewetra/skin/authless.css',
                    // '../../portals/mydewetra/skin/mydewetra.css',
                    '../../apps/dewetra2/css/style_app.css',
                    '../../apps/dewetra2/css/style_layers.css',
                    '../../apps/dewetra2/css/inspire-themes.css',
                    '../../apps/dewetra2/css/style_provenienza.css',
                    '../../apps/dewetra2/fonts/icone-scenario/style.css',
                    '../../apps/dewetra2/fonts/icons_user/style.css',
                    // '../../apps/dewetra2/css/gridtools.css',
                    '../../apps/dewetra2/css/scenario_world.css',
                    '../../apps/dewetra2/css/laminazione.css',
                    '../../apps/dewetra2/css/efas.css',
                    '../../apps/dewetra2/css/floodwave.css',

                    //TODO DARIO NUOVA CONFIG
                    '../../apps/dewetra2/css/'+ skin +'_mydewetra.css'
                ],
                tasks: ['concat:css']
            },
            js: {
                files: ['js/tools.js','js/app.js', 'js/services/*', 'js/controllers/*','js/layer_managers/*', 'js/directives/*', 'js/chart/**/*','js/components/**/*.js'],
                tasks: ['concat:js']
            },
            html: {
                files: ['views/**','js/components/**'],
                tasks: ['concat:js']
            },
            config: {
                files: [ 'js/config/*'],
                tasks: ['concat','uglify:config']
            }
        },


        copy: {
            build: {
                files: [
                    {cwd:'', src: 'js/config/config.min.js', dest: 'build/'},
                    {cwd:'', src: 'index_mydewetra.html', dest: 'build/'},
                    {cwd:'', src: 'js/components/**/*.html', dest: 'build/'},
                    {cwd:'', src: 'js/dewetra2.node_modules.js', dest: 'build/'},
                    {cwd:'', src: 'css/dewetra2.node_modules.css', dest: 'build/'},
                    {cwd:'', src: 'css/scenario_world.css', dest: 'build/'},
                    {cwd:'', src: 'css/scenario_erra.css', dest: 'build/'},
                    {cwd:'', src: 'css/events.css', dest: 'build/'},
                    {cwd:'', src: 'css/gridtools.css', dest: 'build/'},
                    {cwd:'', src: 'css/docked.css', dest: 'build/'},
                    {cwd:'', src: 'css/events.css', dest: 'build/'},
                    {cwd:'', src: 'css/efas.css', dest: 'build/'},
                    {cwd:'', src: 'css/floodwave.css', dest: 'build/'},
                    {cwd:'', src: 'js/dewetra2.<%= gitinfo.local.branch.current.shortSHA %>.min.js', dest: 'build/'},
                    {cwd:'', src: 'css/dewetra2.<%= gitinfo.local.branch.current.shortSHA %>.min.css', dest: 'build/'},
                    // includes files within path and its sub-directories
                    // {expand: true, src: ['css/**'], dest: 'build/'},
                    {expand: true, src: ['fonts/**'], dest: 'build/'},
                    {expand: true, src: ['img/**'], dest: 'build/'},
                    {expand: true, src: ['views/**'], dest: 'build/'},
                    {expand: true, src: ['sound/**'], dest: 'build/'},
                    {expand: true, cwd: 'node_modules/font-awesome/fonts/',src: ['**'], dest:'build/fonts/',filter: 'isFile'},
                    {expand: true, cwd: 'node_modules/leaflet-measure/assets/',src: ['**'], dest:'build/css/assets/',filter: 'isFile'},
                    {expand: true, cwd: 'node_modules/leaflet/dist/images/',src: ['**'], dest:'build/css/images/',filter: 'isFile'},
                    // {expand: true, src: ['node_modules/**'], dest: 'build/'},
                    // {cwd:'',src: 'index_mydewetra.html', dest: 'build/index.html'},
                ],
            },

        },


        uglify: {

            options: {
                banner: '/*! <%= pkg.name %> <%= grunt.template.today("yyyy-mm-dd HH:mm") %> */\n'
            },

            build: {
                src: 'js/<%= pkg.name %>.js',
                dest: 'js/<%= pkg.name %>.<%= gitinfo.local.branch.current.shortSHA %>.min.js'
            },
            config: {
                src: 'js/config/config_'+target+'_dev.js',
                dest: 'js/config/config.min.js',
            },
            // framework: {
            //     src: '../../framework/js/framework.js',
            //     dest: '../../framework/js/framework.min.js',
            // }
        },//end uglify

        concat: {
            css: {

                src: [
                    // '../../portals/mydewetra/skin/style.css',
                    // '../../portals/mydewetra/skin/authless.css',
                    // '../../portals/mydewetra/skin/mydewetra.css',
                    '../../apps/dewetra2/css/style_app.css',
                    '../../apps/dewetra2/css/style_layers.css',
                    '../../apps/dewetra2/css/inspire-themes.css',
                    '../../apps/dewetra2/css/style_provenienza.css',
                    '../../apps/dewetra2/fonts/icone-scenario/style.css',
                    '../../apps/dewetra2/fonts/icons_user/style.css',
                    // '../../apps/dewetra2/css/gridtools.css',
                    '../../apps/dewetra2/css/scenario_world.css',
                    '../../apps/dewetra2/css/laminazione.css',
                    '../../apps/dewetra2/css/efas.css',
                    '../../apps/dewetra2/css/floodwave.css',
                    '../../apps/dewetra2/css/'+ skin +'_mydewetra.css'
                ],

                dest: 'css/<%= pkg.name %>.css'
            },

            js: {
                src: [

                    'js/tools.js',
                    'js/app.js',
                    'js/services/*',
                    'js/controllers/*',
                    'js/layer_managers/*',
                    'js/directives/*',
                    'js/chart/**/*',
                    'js/components/**/*.js'
                ],
                dest: 'js/<%= pkg.name %>.js'
            },
            node_modules:{
                src:[
                    'node_modules/angular/angular.min.js',
                    'node_modules/angular-sanitize/angular-sanitize.min.js',
                    'node_modules/angular-translate/dist/angular-translate.min.js',
                    'node_modules/angular-translate-loader-partial/angular-translate-loader-partial.min.js',
                    'node_modules/angular-dynamic-locale/dist/tmhDynamicLocale.min.js',
                    'node_modules/jquery/dist/jquery.min.js',
                    'node_modules/popper.js/dist/umd/popper.min.js',
                    'node_modules/bootstrap/dist/js/bootstrap.min.js',
                    'node_modules/jquery-ui-dist/jquery-ui.min.js',
                    'node_modules/leaflet/dist/leaflet.js',
                    'node_modules/leaflet-measure/dist/leaflet-measure.it.js',
                    'node_modules/leaflet-measure/dist/leaflet-measure.en.js',
                    'node_modules/leaflet-draw/dist/leaflet.draw.js',
                    'node_modules/leaflet.gridlayer.googlemutant/dist/Leaflet.GoogleMutant.js',
                    'node_modules/leaflet-rotatedmarker/leaflet.rotatedMarker.js',
                    'js/lib/leaflet/singleTile.WMS.js',
                    'js/lib/turf.min.js',
                    'js/lib/geotiff0.3.6.js',
                    'js/lib/overlappingMarkerSpiderfier.min.js',
                    'node_modules/d3/dist/d3.min.js',
                    'node_modules/leaflet-geotiff/leaflet-geotiff.js',
                    'node_modules/leaflet-geotiff/leaflet-geotiff-plotty.js',
                    'node_modules/plotty/dist/plotty.min.js',
                    'node_modules/leaflet.markercluster/dist/leaflet.markercluster.js',
                    'node_modules/ih-leaflet-canvaslayer-field/dist/leaflet.canvaslayer.field.js',
                    'node_modules/ui-select/dist/select.min.js',
                    'node_modules/xml-js/dist/xml-js.min.js',
                    'node_modules/underscore/underscore-min.js',
                    'node_modules/ng-sortable/dist/ng-sortable.min.js',
                    'node_modules/angular-ui-bootstrap/dist/ui-bootstrap-tpls.js',
                    'node_modules/highcharts/highstock.js',
                    'node_modules/highcharts/highcharts-more.js',
                    'node_modules/highcharts/modules/exporting.js',
                    'node_modules/highcharts/modules/export-data.js',
                    'node_modules/moment/min/moment-with-locales.min.js',
                    'node_modules/daterangepicker/daterangepicker.js',
                    'node_modules/sockjs-client/dist/sockjs.min.js',
                    'node_modules/stomp-websocket/lib/stomp.js',
                    'node_modules/angularjs-bootstrap-datetimepicker/src/js/datetimepicker.js',
                    'node_modules/angularjs-bootstrap-datetimepicker/src/js/datetimepicker.templates.js',
                    'node_modules/w3c-schemas/lib/XLink_1_0.js',
                    'node_modules/ogc-schemas/lib/WMS_1_3_0.js',
                    'node_modules/chroma-js/chroma.min.js',
                    'node_modules/jsonix/jsonix.js',
                    'node_modules/jwt-decode/build/jwt-decode.js',
                    'node_modules/lz-string/libs/lz-string.js',
                    'node_modules/@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.min.js',
                    'node_modules/wms-capabilities/dist/wms-capabilities.min.js'
                ],
                dest: 'js/<%= pkg.name %>.node_modules.js'
            },
            node_modules_css:{
                src:[
                    'node_modules/font-awesome/css/font-awesome.min.css',
                    'node_modules/animate.css/animate.min.css',
                    'node_modules/leaflet/dist/leaflet.css',
                    'node_modules/leaflet.markercluster/dist/MarkerCluster.css',
                    'node_modules/leaflet.markercluster/dist/MarkerCluster.Default.css',
                    'node_modules/leaflet-measure/dist/leaflet-measure.css',
                    'node_modules/leaflet-draw/dist/leaflet.draw.css',
                    'node_modules/angularjs-bootstrap-datetimepicker/src/css/datetimepicker.css',
                    'apps/dewetra2/node_modules/daterangepicker/daterangepicker.css',
                    'node_modules/ui-select/dist/select.css',
                    'node_modules/@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css'
                ],
                dest: 'css/<%= pkg.name %>.node_modules.css'
            },


        },


        cssmin: {
            target: {
                src: [
                    "css/<%= pkg.name %>.css"
                ],
                dest : "css/<%= pkg.name %>.<%= gitinfo.local.branch.current.shortSHA %>.min.css"
            }
        },
        clean: {
            js: ['js/dewetra2.*.min.js'],
            //js: ['js/dewetra2*.js', '!path/to/dir/*.min.js'],
            css: [ 'css/dewetra2.*.min.css'],
            build: ['build/**']
        },
        'string-replace': {
            build: {
                files: {
                    'index_mydewetra.html': 'index.html',
                },
                options: {
                    replacements: [
                            {
                                pattern: '<script src="apps/dewetra2/js/dewetra2.js"></script>',
                                replacement: '<script src="apps/dewetra2/js/dewetra2.<%= gitinfo.local.branch.current.shortSHA %>.min.js"></script>'
                            },
                            {
                                pattern: '<link rel="stylesheet" type="text/css"  href="apps/dewetra2/css/dewetra2.css">',
                                replacement: '<link rel="stylesheet" type="text/css"  href="apps/dewetra2/css/dewetra2.<%= gitinfo.local.branch.current.shortSHA %>.min.css">'
                            },
                            {
                                pattern: '<script src="//maps.google.com/maps/api/js?key=AIzaSyAvYTmOk3I2I10sdWmbx1fBE0yXce4fzzw"></script>',
                                replacement: '<script src="//maps.google.com/maps/api/js?key=AIzaSyAvYTmOk3I2I10sdWmbx1fBE0yXce4fzzw&'+ localization +'&v=weekly"></script>'
                            }
                    ]
                }
            },
            version: {
                files: {
                    'js/config/config.min.js':'js/config/config.min.js',
                },
                options: {
                    replacements: [
                        {
                            pattern: 'version:""',
                            replacement: 'version:"<%= gitinfo.local.branch.current.shortSHA %>"'
                        }
                    ]
                }
            }
        }


    });

    grunt.registerTask('versionlog', 'Write', function () {
        var git = grunt.config('gitinfo');
        console.log(git.local.branch.current.shortSHA);
    });

    grunt.registerTask('version', function() {
        //Run gitinfo task
        grunt.task.run('gitinfo');

        //Run your write function
        grunt.task.run('versionlog');

    });


    grunt.loadNpmTasks('grunt-contrib-uglify-es');

    grunt.loadNpmTasks('grunt-contrib-concat');

    grunt.loadNpmTasks('grunt-contrib-cssmin');

    grunt.loadNpmTasks('grunt-contrib-watch');

    grunt.loadNpmTasks('grunt-contrib-copy');

    grunt.loadNpmTasks('grunt-string-replace');

    grunt.loadNpmTasks('grunt-gitinfo');//<%= gitinfo.local.branch.current.SHA %> .local.branch.current.lastCommitNumber

    grunt.loadNpmTasks('grunt-contrib-clean');


    grunt.registerTask('build', ['clean','gitinfo','concat','cssmin','uglify','string-replace','versionlog']);

    grunt.registerTask('build_new', ['clean','gitinfo','concat','cssmin','uglify','string-replace','versionlog' , 'copy:build']);

    // grunt.registerTask('framework', ['concat:framework','uglify:framework']);

    grunt.registerTask('build_dev', ['concat','uglify:config']);

};
