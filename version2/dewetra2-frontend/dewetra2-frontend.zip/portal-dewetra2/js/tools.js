/**
 * Created by Dario Rubado on 20/05/15.
 */



//url function
function removeParam(key, sourceURL) {

    var rtn = sourceURL.split("?")[0],
        param,
        params_arr = [],
        queryString = (sourceURL.indexOf("?") !== -1) ? sourceURL.split("?")[1] : "";
    if (queryString !== "") {
        params_arr = queryString.split("&");
        for (var i = params_arr.length - 1; i >= 0; i -= 1) {
            param = params_arr[i].split("=")[0];
            if (param === key) {
                params_arr.splice(i, 1);
            }
        }
        rtn = rtn + "?" + params_arr.join("&");
    }
    return rtn;
}

function insertParam(key, value){
    key = escape(key); value = escape(value);
    var kvp = document.location.search.substr(1).split('&');
    var i=kvp.length; var x; while(i--)
    {
        x = kvp[i].split('=');

        if (x[0]==key)
        {
            x[1] = value;
            kvp[i] = x.join('=');
            break;
        }
    }
    if(i<0) {kvp[kvp.length] = [key,value].join('=');}

    //this will reload the page, it's likely better to store this until finished
    //document.location.search = kvp.join('&');
    return kvp.join('&');
}

//url function EDN

//move array element
Array.prototype.move = function (old_index, new_index) {
    if (new_index >= this.length) {
        var k = new_index - this.length;
        while ((k--) + 1) {
            this.push(undefined);
        }
    }
    this.splice(new_index, 0, this.splice(old_index, 1)[0]);
    return this
};


isInViewport = function (elem) {
    const bounding = elem.getBoundingClientRect();
    return (
        bounding.top >= 0 &&
        bounding.left >= 0 &&
        bounding.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        bounding.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
};


function move(array, fromIndex, toIndex) {
    array.splice(toIndex, 0, array.splice(fromIndex, 1)[0] );
    return array;
}

//funzione per capire come inizia la stringa
function stringStartsWith (string, prefix) {
    return string.slice(0, prefix.length) == prefix;
}
//funzione per capire come finisce la stringa
function stringEndsWith (string, suffix) {
    return suffix == '' || string.slice(-suffix.length) == suffix;
}

//get index of an object in an array of object
function findIndexByKeyValue(arraytosearch, key, valuetosearch) {

    for (var i = 0; i < arraytosearch.length; i++) {

        if (arraytosearch[i][key] == valuetosearch) {
            return i;
        }
    }
    return null;
}

/**
 * GROUP BY
 * @param datas
 * @param key
 * @returns {*}
 */
function groupBy(datas, key) {
    return datas.reduce(function(rv, x) {
        (rv[x[key]] = rv[x[key]] || []).push(x);
        return rv;
    }, {});
};


// Removes an item from a given array
function removeArrayItem(arr, item) {
    var i = 0;
    while (i < arr.length) {
        if (arr[i] == item) {
            arr.splice(i, 1);
        } else {
            i++;
        }
    }
}

//MakeID

function makeid(length) {
    var result           = [];
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
        result.push(characters.charAt(Math.floor(Math.random() *
            charactersLength)));
    }
    return result.join('');
}

/**
 * Get randomDate
 * @param start
 * @param end
 * @returns Date Object
 */
function randomDate(start, end)  {
    return  new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

// Given a map object return a point in the bound
function getRandomLatLng(map) {
    var bounds = map.getBounds(),
        southWest = bounds.getSouthWest(),
        northEast = bounds.getNorthEast(),
        lngSpan = northEast.lng - southWest.lng,
        latSpan = northEast.lat - southWest.lat;

    return new L.LatLng(
        southWest.lat + latSpan * Math.random(),
        southWest.lng + lngSpan * Math.random());
}

//XML PARSER

function parseXml(xml) {
    var dom = null;
    if (window.DOMParser) {
        try {
            dom = (new DOMParser()).parseFromString(xml, "text/xml");
        }
        catch (e) { dom = null; }
    }
    else if (window.ActiveXObject) {
        try {
            dom = new ActiveXObject('Microsoft.XMLDOM');
            dom.async = false;
            if (!dom.loadXML(xml)) // parse error ..

                window.alert(dom.parseError.reason + dom.parseError.srcText);
        }
        catch (e) { dom = null; }
    }
    else
        alert("cannot parse xml string!");
    return dom;
}

 //convert XMLtoJSON
function xml2json(xml, tab) {
    var X = {
        toObj: function(xml) {
            var o = {};
            if (xml.nodeType==1) {   // element node ..
                if (xml.attributes.length)   // element with attributes  ..
                    for (var i=0; i<xml.attributes.length; i++)
                        o["@"+xml.attributes[i].nodeName] = (xml.attributes[i].nodeValue||"").toString();
                if (xml.firstChild) { // element has child nodes ..
                    var textChild=0, cdataChild=0, hasElementChild=false;
                    for (var n=xml.firstChild; n; n=n.nextSibling) {
                        if (n.nodeType==1) hasElementChild = true;
                        else if (n.nodeType==3 && n.nodeValue.match(/[^ \f\n\r\t\v]/)) textChild++; // non-whitespace text
                        else if (n.nodeType==4) cdataChild++; // cdata section node
                    }
                    if (hasElementChild) {
                        if (textChild < 2 && cdataChild < 2) { // structured element with evtl. a single text or/and cdata node ..
                            X.removeWhite(xml);
                            for (var n=xml.firstChild; n; n=n.nextSibling) {
                                if (n.nodeType == 3)  // text node
                                    o["#text"] = X.escape(n.nodeValue);
                                else if (n.nodeType == 4)  // cdata node
                                    o["#cdata"] = X.escape(n.nodeValue);
                                else if (o[n.nodeName]) {  // multiple occurence of element ..
                                    if (o[n.nodeName] instanceof Array)
                                        o[n.nodeName][o[n.nodeName].length] = X.toObj(n);
                                    else
                                        o[n.nodeName] = [o[n.nodeName], X.toObj(n)];
                                }
                                else  // first occurence of element..
                                    o[n.nodeName] = X.toObj(n);
                            }
                        }
                        else { // mixed content
                            if (!xml.attributes.length)
                                o = X.escape(X.innerXml(xml));
                            else
                                o["#text"] = X.escape(X.innerXml(xml));
                        }
                    }
                    else if (textChild) { // pure text
                        if (!xml.attributes.length)
                            o = X.escape(X.innerXml(xml));
                        else
                            o["#text"] = X.escape(X.innerXml(xml));
                    }
                    else if (cdataChild) { // cdata
                        if (cdataChild > 1)
                            o = X.escape(X.innerXml(xml));
                        else
                            for (var n=xml.firstChild; n; n=n.nextSibling)
                                o["#cdata"] = X.escape(n.nodeValue);
                    }
                }
                if (!xml.attributes.length && !xml.firstChild) o = null;
            }
            else if (xml.nodeType==9) { // document.node
                o = X.toObj(xml.documentElement);
            }
            else
                alert("unhandled node type: " + xml.nodeType);
            return o;
        },
        toJson: function(o, name, ind) {
            var json = name ? ("\""+name+"\"") : "";
            if (o instanceof Array) {
                for (var i=0,n=o.length; i<n; i++)
                    o[i] = X.toJson(o[i], "", ind+"\t");
                json += (name?":[":"[") + (o.length > 1 ? ("\n"+ind+"\t"+o.join(",\n"+ind+"\t")+"\n"+ind) : o.join("")) + "]";
            }
            else if (o == null)
                json += (name&&":") + "null";
            else if (typeof(o) == "object") {
                var arr = [];
                for (var m in o)
                    arr[arr.length] = X.toJson(o[m], m, ind+"\t");
                json += (name?":{":"{") + (arr.length > 1 ? ("\n"+ind+"\t"+arr.join(",\n"+ind+"\t")+"\n"+ind) : arr.join("")) + "}";
            }
            else if (typeof(o) == "string")
                json += (name&&":") + "\"" + o.toString() + "\"";
            else
                json += (name&&":") + o.toString();
            return json;
        },
        innerXml: function(node) {
            var s = ""
            if ("innerHTML" in node)
                s = node.innerHTML;
            else {
                var asXml = function(n) {
                    var s = "";
                    if (n.nodeType == 1) {
                        s += "<" + n.nodeName;
                        for (var i=0; i<n.attributes.length;i++)
                            s += " " + n.attributes[i].nodeName + "=\"" + (n.attributes[i].nodeValue||"").toString() + "\"";
                        if (n.firstChild) {
                            s += ">";
                            for (var c=n.firstChild; c; c=c.nextSibling)
                                s += asXml(c);
                            s += "</"+n.nodeName+">";
                        }
                        else
                            s += "/>";
                    }
                    else if (n.nodeType == 3)
                        s += n.nodeValue;
                    else if (n.nodeType == 4)
                        s += "<![CDATA[" + n.nodeValue + "]]>";
                    return s;
                };
                for (var c=node.firstChild; c; c=c.nextSibling)
                    s += asXml(c);
            }
            return s;
        },
        escape: function(txt) {
            return txt.replace(/[\\]/g, "\\\\")
                .replace(/[\"]/g, '\\"')
                .replace(/[\n]/g, '\\n')
                .replace(/[\r]/g, '\\r');
        },
        removeWhite: function(e) {
            e.normalize();
            for (var n = e.firstChild; n; ) {
                if (n.nodeType == 3) {  // text node
                    if (!n.nodeValue.match(/[^ \f\n\r\t\v]/)) { // pure whitespace text node
                        var nxt = n.nextSibling;
                        e.removeChild(n);
                        n = nxt;
                    }
                    else
                        n = n.nextSibling;
                }
                else if (n.nodeType == 1) {  // element node
                    X.removeWhite(n);
                    n = n.nextSibling;
                }
                else                      // any other node
                    n = n.nextSibling;
            }
            return e;
        }
    };
    if (xml.nodeType == 9) // document node
        xml = xml.documentElement;
    var json = X.toJson(X.toObj(X.removeWhite(xml)), xml.nodeName, "\t");
    return "{\n" + tab + (tab ? json.replace(/\t/g, tab) : json.replace(/\t|\n/g, "")) + "\n}";
}

function fakeLayer (code, dataId,ddsServerId, ddsServerUrl) {
    const fakeLayer = {
        "category": "fakecategory",//observation
        "customprops": null,
        "dataid": (dataId)?dataId:'fake_id',
        "descr": "fake description",
        "geoscale": null,
        "hierarchy": "fake.layer",
        "icon": "rainmap",
        "id": 30,
        "latn": 48.0,
        "lats": 32.0,
        "lone": 15.0,
        "lonw": 6.0,
        "metadata": "",
        "metadataurl": "//www.cimafoundation.org",
        "name": "fake name",
        "server": {
            "descr": "Dewetra Data Server at Cima Foundation",
            "id": ddsServerId?ddsServerId:'https://geoserver.cimafoundation.org/geoserver/wms',
            "name": "ddscima",
            "url": ddsServerUrl?ddsServerUrl:'https://geoserver.cimafoundation.org/geoserver/wms'
        },
        "source": null,
        "tags": [
            {
                "descr": "fake",
                "icon": "",
                "id": 23,
                "name": "fake"
            }
        ],
        "thumb": "",
        "type": {
            "code": code,
            "id": 1,
            "name": "fake"
        }
    }

    return fakeLayer;
}

// Does a given array contain a item
function contains(a, obj) {
    var i = a.length;
    while (i--) {
        if (a[i] === obj) {
            return true;
        }
    }
    return false;
}
// Returns a random number between min (inclusive) and max (exclusive)
function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
}

function closestDataAvailable (num, arr) {
    //num in second
    // arr == array of available
    num = num*1000;
    var curr = moment(arr[0].date).valueOf();
    var diff = Math.abs (num - curr);
    for (var val = 0; val < arr.length; val++) {
        var newdiff = Math.abs (num - moment(arr[val].date).valueOf());
        if (newdiff < diff) {
            diff = newdiff;
            curr = arr[val].date;
            var index= val
        }
    }
    return index;
}


/**
 * RGB TO HEX
 * @param r
 * @param g
 * @param b
 * @returns {string}
 */
function rgbToHex(r, g, b) {
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

/**
 * HEX to RGB
 * @param hex
 * @returns {*}
 */
function hexToRgb(hex) {
    // Expand shorthand form (e.g. "03F") to full form (e.g. "0033FF")
    var shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shorthandRegex, function(m, r, g, b) {
        return r + r + g + g + b + b;
    });

    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

/**
 * EXTEND OBJECT
 * @param obj
 * @param src
 * @returns {*}
 */
function extend(obj, src) {
    Object.keys(src).forEach(function(key) { obj[key] = src[key]; });
    return obj;
}

function saveAs(uri, filename) {

    var link = document.createElement('a');

    if (typeof link.download === 'string') {

        link.href = uri;
        link.download = filename;

        //Firefox requires the link to be in the body
        document.body.appendChild(link);

        //simulate click
        link.click();

        //remove the link when done
        document.body.removeChild(link);

    } else {

        window.open(uri);

    }
}

// function closestPositiveDataAvailable (num, arr) {
//     //num in second
//     // arr == array of available
//     num = num*1000;
//     var curr = moment(arr[0].date).valueOf();
//     var diff = Math.abs (num - curr);
//     for (var val = 0; val < arr.length; val++) {
//         var newdiff = Math.abs (num - moment(arr[val].date).valueOf());
//         if (newdiff < diff) {
//             diff = newdiff;
//             curr = arr[val].date;
//             var index= val
//         }
//     }
//     return index;
// }
//
// function closestNegativeDataAvailable (num, arr) {
//     //num in second
//     // arr == array of available
//     num = num*1000;
//     var curr = moment(arr[0].date).valueOf();
//     var diff = Math.abs (num - curr);
//     for (var val = 0; val < arr.length; val++) {
//         var newdiff = Math.abs (num - moment(arr[val].date).valueOf());
//         if (newdiff < diff) {
//             diff = newdiff;
//             curr = arr[val].date;
//             var index= val
//         }
//     }
//     return index;
// }


/******************* Charts utilities *******************/

// Imposto la serie di indefiniti
function getUndefSeries(timeline, obs, start, end) {

    var dtStart = (start * 1000);
    var dtEnd = (end * 1000);

    var ts, undef = null, undefSeries = [];

    if (timeline) {

        for (var i = 0; i < timeline.length; i++) {

            if (parseFloat(obs[i]) == -9999) {

                // E' il primo di una serie ...
                if (undef == null) {

                    ts = moment.utc(timeline[i]).valueOf();

                    //inizio di un periodo di indefinito...
                    undef = {
                        from : ts,
                        to: ts
                    };
                    //se il precedente valore e' definitio lo aggiungo
                    if (i > 0) undef.from = moment.utc(timeline[i-1]).valueOf();

                }

            } else {

                if (undef != null) {
                    undef.to = moment.utc(timeline[i-1]).valueOf();
                    undefSeries.push(undef);
                    undef = null;
                }

            }

        }

    }

    if (undef != null) {
        undef.to = dtEnd;
        undefSeries.push(undef);
    } else  {
        undefSeries.push({
            from : (timeline? moment.utc(timeline[timeline.length - 1]).valueOf() : dtStart),
            to: dtEnd
        });

    }

    return undefSeries;

}

function getMax(values, defaultMax) {

    var val, maxVal = defaultMax? defaultMax : Number.NEGATIVE_INFINITY;

    if (values) {

        for (var i = 0; i < values.length; i++) {

            val = parseFloat(values[i]);
            if (val > maxVal) maxVal = val;

        }

    }

    if (defaultMax) maxVal = (Math.ceil(maxVal/Math.abs(defaultMax)) * Math.abs(defaultMax));

    return maxVal;

}

function getMin(values, defaultMin) {

    var val, minVal = defaultMin? defaultMin : Number.POSITIVE_INFINITY;

    if (values) {

        for (var i = 0; i < values.length; i++) {

            val = parseFloat(values[i]);
            if ((val > -9998) && (val < minVal)) minVal = val;

        }

    }

    if (defaultMin) minVal = (Math.floor(minVal/Math.abs(defaultMin)) * Math.abs(defaultMin));

    return minVal;

}

/**
 *
 * NOTA: I primi 2 idrogrammi di questa serie rappresentano la Curva Invaso della diga per convertire i volumi in livelli
 *      hydrogram.values[0]: scala di livelli
 *      hydrogram.values[1]: scala di volumi
 *      hydrogram.values[2]: oss
 *      hydrogram.values[3]: model
 *
 **/
function volume2Level(hydrogram, volume) {

    var level = -9999;

    if (hydrogram.values.length > 2) {

        for (var i = 0; i < hydrogram.values[1].length; i++) {

            if (volume <= hydrogram.values[1][i]) {

                level = hydrogram.values[0][i] - ((hydrogram.values[1][i] - volume) * ((hydrogram.values[0][i] - hydrogram.values[0][i-1]) / (hydrogram.values[1][i] - hydrogram.values[1][i-1])));

                break;

            }

        }

    }

    return level;

}

function addDownloadChartOption() {

    var ix = -1;
    for (var i = 0; i < Highcharts.getOptions().exporting.buttons.contextButton.menuItems.length; i++) {
        if (Highcharts.getOptions().exporting.buttons.contextButton.menuItems[i].textKey == 'downloadCSV') {
            ix = i;
            break;
        }
    }
    if (ix < 0)
        Highcharts.getOptions().exporting.buttons.contextButton.menuItems.push({
            textKey: 'downloadCSV',
            text: 'Download CSV',
            onclick: function() {
                downloadChartSeries(this);
            }
        });
    else
        Highcharts.getOptions().exporting.buttons.contextButton.menuItems[ix].onclick = function() {
            downloadChartSeries(this);
        }

}

function downloadChartSeries(chart) {

    var csv = '';
    var sensor;
    var id_split;
    var station = null;
    chart.series.forEach(function(s) {

        if (s.id) {

            id_split = s.id.split('_');
            if (!station) station = id_split[0];
            sensor = ((id_split[1] && (id_split[1].length > 0))? id_split[1] : 'Osservazioni');
            csv += 'Data;' + sensor + '\n';

            s.options.data.forEach(function(item){
                if (item[1] != null) csv += (moment(item[0]/1000, 'X').format('DD/MM/YYYY HH:mm') + ';' + item[1].toFixed(2) + '\n');
            });

        }

    });

    if (csv.length > 0) {

        var dateFrom = null;
        var dateTo = null;

        if (chart.xAxis[0].isDatetimeAxis) {
            dateFrom = moment(chart.xAxis[0].min/1000, 'X').format('YYYYMMDDHH00');
            dateTo = moment(chart.xAxis[0].max/1000, 'X').format('YYYYMMDDHH00');
        }

        var saving = document.createElement('a');
        saving.setAttribute('href', 'data:attachment/csv,' + encodeURIComponent(csv));
        saving.setAttribute('download', station + (dateFrom? ('-' + dateFrom + '-' + dateTo) : '') + '.csv');

        //a.href = window.URL.createObjectURL(new Blob(['Test,Text'], {type: 'text/csv'}));
        //a.download = 'test.csv';

        // Append anchor to body.
        document.body.appendChild(saving);
        saving.click();

        // Remove anchor from body
        document.body.removeChild(saving);

        //saving.href = 'data:attachment/csv,' + encodeURIComponent(csv);
        //saving.download = station + '-' + dateFrom + '-' + dateTo + '.csv';

    }

}


/******************* FINE Charts utilities *******************/



function getQueryVariable(variable) {
    var query = window.location.href;
    var vars = query.split('&');
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        if (decodeURIComponent(pair[0]) == variable) {
            return decodeURIComponent(pair[1]);
        }
    }
    console.log('Query variable %s not found', variable);
}


function minuteNumberToFormattedDate(iDeltaMinutes) {
    var sTimeDelta = "";
    if (iDeltaMinutes>0){
        if (iDeltaMinutes<60 ) {
            // Less then 1h
            sTimeDelta += iDeltaMinutes + " min. fa";
        }
        else if (iDeltaMinutes< 60*24) {
            // Less then 1d
            var iDeltaHours =  Math.round(iDeltaMinutes/60);
            sTimeDelta += iDeltaHours + " ore fa";
        }
        else {
            // More than 1d
            var iDeltaDays =  Math.round(iDeltaMinutes/(60*24));
            sTimeDelta += iDeltaDays + " giorni fa";
        }
    }else{
        if (iDeltaMinutes> -60 ) {
            // Less then 1h
            sTimeDelta += "Fra: "+Math.abs(iDeltaMinutes)+" Minuti" ;
        }
        else if (iDeltaMinutes > -60*24) {
            // Less then 1d
            var iDeltaHours =  Math.round(iDeltaMinutes/60);
            sTimeDelta += "Fra: "+Math.abs(iDeltaHours)+" Ore" ;
        }
        else {
            // More than 1d
            var iDeltaDays =  Math.round(iDeltaMinutes/(60*24));
            sTimeDelta += "Fra: "+Math.abs(iDeltaDays)+" Giorni";
        }
    }

    return sTimeDelta;
}

/**
 *
 * @param values_x
 * @param values_y
 * @returns {[null,null]}
 */
function linearRegression(values_x, values_y) {
    var sum_x = 0;
    var sum_y = 0;
    var sum_xy = 0;
    var sum_xx = 0;
    var count = 0;

    /*
     * We'll use those variables for faster read/write access.
     */
    var x = 0;
    var y = 0;
    var values_length = values_x.length;

    if (values_length != values_y.length) {
        throw new Error('The parameters values_x and values_y need to have same size!');
    }

    /*
     * Nothing to do.
     */
    if (values_length === 0) {
        return [ [], [] ];
    }

    /*
     * Calculate the sum for each of the parts necessary.
     */
    for (var v = 0; v = values_length; v++) {
        x = values_x[v];
        y = values_y[v];
        sum_x += x;
        sum_y += y;
        sum_xx += x*x;
        sum_xy += x*y;
        count++;
    }

    /*
     * Calculate m and b for the formular:
     * y = x * m + b
     */
    var m = (count*sum_xy - sum_x*sum_y) / (count*sum_xx - sum_x*sum_x);
    var b = (sum_y/count) - (m*sum_x)/count;

    /*
     * We will make the x and y result line now
     */
    var result_values_x = [];
    var result_values_y = [];

    for (var v = 0; v = values_length; v++) {
        x = values_x[v];
        y = x * m + b;
        result_values_x.push(x);
        result_values_y.push(y);
    }

    return [result_values_x, result_values_y];
}



function iconServiceFunction($http,$interval,$timeout,$rootScope,$window,_){

    console.log("Icon Service Initializated");
    function getTriangleIcon(size, fillColor, borderColor, opacity) {

        var icon = new L.Icon.Canvas({iconSize: new L.Point(size, size)});
        icon.draw = function(ctx, w, h) {
            ctx.globalAlpha = opacity;
            ctx.beginPath();
            ctx.moveTo(w/2,h);
            ctx.lineTo(w,0);
            ctx.lineTo(0,0);
            ctx.fillStyle= fillColor;
            ctx.fill();

            ctx.beginPath();
            ctx.moveTo(w/2,h);
            ctx.lineTo(w,0);
            ctx.lineTo(0,0);
            ctx.strokeStyle= (borderColor? borderColor : "black");
            ctx.stroke();
        };

        return icon;

    }

    var ICON_SIZE = 14;

    var markerFloodOption = {
        radius : 4,
        weight : 1,
        color : "#000",
        opacity : 1,
        fillOpacity: 0.8
    };

    /**
     *
     * @param size
     * @param fillColor
     * @param borderColor
     * @param opacity
     * @param direction prop 1 ,0, -1
     * @returns {*}
     */
    function getTriangleIcon(size, fillColor, borderColor, opacity, direction) {

        var icon = new L.Icon.Canvas({iconSize: new L.Point(size, size)});


        switch (direction) {
            case -1:
                icon.draw = function (ctx, w, h) {
                    ctx.globalAlpha = opacity;
                    ctx.beginPath();
                    ctx.moveTo(w / 2, h);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(0, 0);
                    ctx.fillStyle = fillColor;
                    ctx.fill();

                    ctx.beginPath();
                    ctx.moveTo(w / 2, h);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(0, 0);
                    ctx.lineTo(w / 2, h);
                    ctx.strokeStyle = (borderColor ? borderColor : "black");
                    ctx.lineWidth =(borderColor != "black")? 3 : 1;
                    ctx.stroke();
                };

                break;
            case 0:

                icon.draw = function (ctx, w, h) {
                    ctx.globalAlpha = opacity;
                    ctx.beginPath();
                    ctx.moveTo(0, 0);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.fillStyle = fillColor;
                    ctx.fill();

                    ctx.beginPath();
                    ctx.moveTo(0, 0);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.lineTo(0, 0);
                    ctx.strokeStyle = (borderColor ? borderColor : "black");
                    ctx.lineWidth =(borderColor != "black")? 3 : 1;
                    ctx.stroke();
                };
                break;
            case 1:
                icon.draw = function (ctx, w, h) {
                    ctx.globalAlpha = opacity;
                    ctx.beginPath();
                    ctx.moveTo(w / 2, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.lineTo(w / 2, 0);
                    ctx.fillStyle = fillColor;
                    ctx.fill();

                    ctx.beginPath();
                    ctx.moveTo(w / 2, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.lineTo(w / 2, 0);
                    ctx.strokeStyle = (borderColor ? borderColor : "black");
                    ctx.lineWidth =(borderColor != "black")? 3 : 1;
                    ctx.stroke();
                };

                break;
            default:
                icon.draw = function (ctx, w, h) {
                    ctx.globalAlpha = opacity;
                    ctx.beginPath();
                    ctx.moveTo(0, 0);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.fillStyle = fillColor;
                    ctx.fill();

                    ctx.beginPath();
                    ctx.moveTo(0, 0);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.lineTo(0, 0);
                    ctx.strokeStyle = (borderColor ? borderColor : "black");
                    ctx.lineWidth =(borderColor != "black")? 3 : 1;
                    ctx.stroke();
                };

        }



        return icon;
    }

    function getTriangleIconWarningsHydro(size, fillColor, borderColor, opacity, state) {

        if (state > 0){
            var icon = new L.Icon.Canvas({iconSize: new L.Point(size, size)});
            icon.draw = function (ctx, w, h) {
                ctx.globalAlpha = opacity;
                ctx.beginPath();
                ctx.moveTo(w / 2, 0);
                ctx.lineTo(w, h);
                ctx.lineTo(0, h);
                ctx.fillStyle = fillColor;
                ctx.fill();

                ctx.beginPath();
                ctx.moveTo(w / 2, 0);
                ctx.lineTo(w, h);
                ctx.lineTo(0, h);
                ctx.strokeStyle = (borderColor ? borderColor : "black");
                ctx.stroke();
            };
        }else{
            var icon = new L.Icon.Canvas({iconSize: new L.Point(size, size)});
            icon.draw = function (ctx, w, h) {
                ctx.globalAlpha = opacity;
                ctx.beginPath();
                ctx.moveTo(w / 2, h);
                ctx.lineTo(w, 0);
                ctx.lineTo(0, 0);
                ctx.fillStyle = fillColor;
                ctx.fill();

                ctx.beginPath();
                ctx.moveTo(w / 2, h);
                ctx.lineTo(w, 0);
                ctx.lineTo(0, 0);
                ctx.strokeStyle = (borderColor ? borderColor : "black");
                ctx.stroke();
            };
        }



        return icon;
    }

    //var warningPluvioPalette = {
    //    '-2' : '#8A8787',//undef
    //    '-1' : '#FFFFFF',
    //    '0'  : '#00FF00',//safe bianco
    //    '1'  : '#FFFF00',//ordinaria verde
    //    '2'  : '#FA8B3C',//moderata arancione
    //    '3'  : '#FF0000',//alta rossa
    //    '4'  : '#0000ff'//blu
    //}

    // var warningPluvioPalette = {
    //     '-1' : '#8A8787',//undef
    //     '0' : '#FFFFFF',//bianco
    //     '1'  : '#00FF00',//safe verde
    //     '2'  : '#FFFF00',//ordinaria giallo
    //     '3'  : '#FA8B3C',//moderata arancione
    //     '4'  : '#FF0000'//alta rossa
    //
    // };

    var warningPluvioPalette = {
        // '-3'  : '#3B46DB', //test per pluvio
        '-2' : '#8A8787',//undef
        '-1' : '#FFFFFF',//bianco
        '0'  : '#00FF00',//safe verde
        '1'  : '#FFFF00',//ordinaria giallo
        '2'  : '#FA8B3C',//moderata arancione
        '3'  : '#FF0000'//alta rossa

    };

    var warningFireIndexPalette = {
        '-2' : '#8A8787',   // undef
        '0'  : '#00FF00',   // safe verde
        '1'  : '#FFFF00',   // alert giallo
        '2'  : '#FF0000'    // alarm rossa
    };

    var markerWarningOptions = {
            radius : 5,
            weight : 1,
            color : "#000",
            opacity : 1,
            fillOpacity: 0.8
    };
    var markerFloodOptions = {
            radius : 4,
            weight : 1,
            color : "#000",
            opacity : 1,
            fillOpacity: 0.8
    };
    //hydrometer
    var warningHydroPalette = {
        '-2' : '#8A8787',//undef
        '-1' : '#FFFFFF',
        '0'  : '#00FF00',//safe verde
        '1'  : '#FFFF00',//ordinaria giallo
        '2'  : '#FA8B3C',//moderata arancione
        '3'  : '#FF0000',//alta rossa
        '4'  : '#C13BDB',//alta viola
        '5'  : '#3B46DB' //suparamento massimo storico blu
    };
    //hydrometer end

    var warningThermoPalette = {
        //'-2' : '#8A8787',
        '-1' : '#8A8787',//undef
        '0'  : '#00FF00',//safe
        '1'  : '#FFFF00',//arancione
        '2'  : '#FF0000',//Rosso
        '3'  : '#00c0ff',//azzurro
        '4'  : '#0000ff'//blu
    };

    var rasorDamagePalette = {
        '0' : '#FFFFFF',//safe
        '1'  : '#FFFF00',//low
        '2'  : '#FA8B3C',//giallo
        '3'  : '#FF0000',//moderata arancione
        '4'  : '#C13BDB',//Rosso
    };
    var thermometerPalette = {
        //'-2' : '#555',
        '-1' : '#555',
        '0'  : '#c0c0c0',
        '1'  : '#9800ff',
        '2'  : '#6100ff',
        '3'  : '#2552ff',
        '4' : '#00ffff',
        '5' : '#00cc12',
        '6'  : '#00ff18',
        '7'  : '#f8ff28',
        '8'  : '#f8ff28',
        '9'  : '#ff8000',
        '10'  : '#ff0000',
        '11' : '#d30000',
        '12' : '#ff5afe',
        '13'  : '#ff00fe'
    };
    var raingaugePalette = {
        //'-2' : '#555',
        '-1' : '#cbcbcb',
        '0'  : '#FFF',
        '1'  : '#e1ffe1',
        '2'  : '#c8ffc8',
        '3'  : '#50f050',
        '4' : '#1eb41e',
        '5' : '#0f8c0f',
        '6'  : '#0f640f',
        '7'  : '#0f3c0f',
        '8'  : '#ffff00',
        '9'  : '#dcdc00',
        '10' : '#b9b900',
        '11' : '#969600',
        '12'  : '#737300',
        '13'  : '#505000',
        '14'  : '#ff0000',
        '15'  : '#dc0000',
        '16' : '#b90000',
        '17' : '#960000',
        '18'  : '#ff80ff',
        '19'  : '#f000f0',
        '20'  : '#b700b7',
        '21'  : '#780078',
        '22' : '#99ccff',
        '23'  : '#66ccff',
        '24'  : '#3399ff',
        '25'  : '#3366ff',
        //'26'  : '#0000CC'
    };

    var nivometerPalette = {
        '-2' : '#555',
        '-1' : '#cbcbcb',
        '0'  : '#FFF',
        '1'  : '#e0ebff',
        '2'  : '#b5c9ff',
        '3'  : '#8eb2ff',
        '4' : '#7f96ff',
        '5' : '#6370f7',
        '6'  : '#009f1e',
        '7'  : '#3cbc3d',
        '8'  : '#b9f96e',
        '9'  : '#fff914',
        '10' : '#fac81e',
        '11' : '#eb9628',
        '12'  : '#fa3c3c',
        '13'  : '#cd005a',
        '14'  : '#b400b4',
        '15'  : '#9600c8',
        '16' : '#a064dc',
        '17' : '#be8cc8',
        '18'  : '#e1afc3',
        '19'  : '#e1c8be',
        '20'  : '#f0dce1',
        // '21'  : '#780078',
        // '22'  : '#780078'
    };

    // var hygrometerPalette = {
    //     //'-2' : '#555',
    //     '-1' : '#555',
    //     '0'  : '#3a00b9',
    //     '1'  : '#0018b9',
    //     '2'  : '#0056b9',
    //     '3'  : '#009ab9',
    //     '4' : '#00b98a',
    //     '5' : '#00b949',
    //     '6'  : '#31b900',
    //     '7'  : '#8ab900',
    //     '8'  : '#b99400',
    //     '9'  : '#b94300',
    //     '10' : '#b90000',
    //     '11' : '#0a0a0a'
    //
    // };

    var hygrometerPalette = {
        //'-2' : '#555',
        '-1' : '#555',
        '0'  : '#0a0a0a',
        '1'  : '#b90000',
        '2'  : '#b94300',
        '3'  : '#b99400',
        '4' : '#8ab900',
        '5' : '#31b900',
        '6'  : '#00b949',
        '7'  : '#00b98a',
        '8'  : '#009ab9',
        '9'  : '#0056b9',
        '10' : '#0018b9',
        '11' : '#3a00b9'

    };

    var anemometerPalette = {
        '0'  : '#555',
        '1'  : '#FFFFFF',
        '2'  : '#99ddb4',
        '3'  : '#30b4fb',
        '4' : '#1991f9',
        '5' : '#6ea254',
        '6'  : '#acce64',
        '7'  : '#fed67f',
        '8'  : '#dca535',
        '9'  : '#df6430',
        '10' : '#c3333f',
        '11' : '#9600c8',
        '12' : '#a064dc'
    };

    function windPalette(data) {

        if (data <= -9998) {
            return 0;
        }else if ((data<=2)) {
            return 1;
        }else if ((data<=6)&&(data>=2)) {
            return 2;
        }else if ((data<=11)&&(data>6)) {
            return 3;
        }else if ((data<=18)&&(data>11)) {
            return 4;
        }else if ((data<=30)&&(data>18)) {
            return 5;
        }else if ((data<=39)&&(data>30)) {
            return 6;
        }else if ((data<=50)&&(data>39)) {
            return 7;
        }else if ((data<=61)&&(data>50)) {
            return 8;
        }else if ((data<=74)&&(data>61)) {
            return 9;
        }else if ((data<=87)&&(data>74)) {
            return 10;
        }else if ((data<=102)&&(data>87)) {
            return 11;
        }else if(data>102) return 12;
    }

    function getWindDirection(dir) {

        if ((dir >= 11.25) && (dir < 33.75)) return 'NNE';
        else if ((dir >= 33.75) && (dir < 56.25)) return 'NE';
        else if ((dir >= 56.25) && (dir < 78.75)) return 'ENE';
        else if ((dir >= 78.75) && (dir < 101.25)) return 'E';
        else if ((dir >= 101.25) && (dir < 123.75)) return 'ESE';
        else if ((dir >= 123.75) && (dir < 146.25)) return 'SE';
        else if ((dir >= 146.25) && (dir < 168.75)) return 'SSE';
        else if ((dir >= 168.75) && (dir < 191.25)) return 'S';
        else if ((dir >= 191.25) && (dir < 213.75)) return 'SSW';
        else if ((dir >= 213.75) && (dir < 236.25)) return 'SW';
        else if ((dir >= 236.25) && (dir < 258.75)) return 'WSW';
        else if ((dir >= 258.75) && (dir < 281.25)) return 'W';
        else if ((dir >= 281.25) && (dir < 303.75)) return 'WNW';
        else if ((dir >= 303.75) && (dir < 326.25)) return 'NW';
        else if ((dir >= 326.25) && (dir < 348.75)) return 'NNW';
        else return 'N';

    }

    function palette_thermo(data) {

        if (data== -9999||data== -9998) {
            return -1;
        }else if(data<-25){
            return 0;
        }else if ((data<=-15)&&(data>-25)) {
            return 1;
        }else if ((data<=-5)&&(data>-15)) {
            return 2;
        }else if ((data<=-0)&&(data>-5)) {
            return 3;
        }else if ((data<=5)&&(data>0)) {
            return 4
        }else if ((data<=10)&&(data>5)) {
            return 5
        }else if ((data<=15)&&(data>10)) {
            return 6;
        }else if ((data<=20)&&(data>15)) {
            return 7;
        }else if ((data<=25)&&(data>20)) {
            return 8;
        }else if ((data<=30)&&(data>25)) {
            return 9;
        }else if ((data<=35)&&(data>30)) {
            return 10;
        }else if ((data<=38)&&(data>35)) {
            return 11;
        }else if ((data<=40)&&(data>38)) {
            return 12;
        }else if ((data<=50)&&(data>40)) {
            return 13;
        }
    }

    function palette_pluvio(data) {

        if (data <= -9998) {
            return -1;
        }else if ((data==0)) {
            return 0;
        }else if ((data<=5)) {
            return 1;
        }else if ((data<=10)&&(data>5)) {
            return 2;
        }else if ((data<=15)&&(data>10)) {
            return 3;
        }else if ((data<=20)&&(data>15)) {
            return 4;
        }else if ((data<=25)&&(data>20)) {
            return 5;
        }else if ((data<=30)&&(data>25)) {
            return 6;
        }else if ((data<=40)&&(data>30)) {
            return 7;
        }else if ((data<=50)&&(data>40)) {
            return 8;
        }else if ((data<=60)&&(data>50)) {
            return 9;
        }else if ((data<=70)&&(data>60)) {
            return 10;
        }else if ((data<=80)&&(data>70)) {
            return 11;
        }else if ((data<=90)&&(data>80)) {
            return 12;
        }else if ((data<=100)&&(data>90)) {
            return 13;
        }else if ((data<=125)&&(data>100)) {
            return 14;
        }else if ((data<=150)&&(data>125)) {
            return 15;
        }else if ((data<=175)&&(data>150)) {
            return 16;
        }else if ((data<=200)&&(data>175)) {
            return 17;
        }else if ((data<=300)&&(data>200)) {
            return 18;
        }else if ((data<=400)&&(data>300)) {
            return 19;
        }else if ((data<=500)&&(data>400)) {
            return 20;
        }else if ((data<=600)&&(data>500)) {
            return 21;
        }else if ((data<=700)&&(data>600)) {
            return 22;
        }else if ((data<=800)&&(data>700)) {
            return 23;
        }else if ((data<=900)&&(data>800)) {
            return 24;
        }else if ((data>900)) {
            return 25;
        }
    }

    function palette_nivo(data) {

        if (data <= -9998) {
            return -1;
        }else if ((data<=1)) {
            return 1;
        }else if ((data<=5)&&(data>=1)) {
            return 2;
        }else if ((data<=10)&&(data>5)) {
            return 3;
        }else if ((data<=20)&&(data>10)) {
            return 4;
        }else if ((data<=40)&&(data>20)) {
            return 5;
        }else if ((data<=60)&&(data>40)) {
            return 6;
        }else if ((data<=80)&&(data>60)) {
            return 7;
        }else if ((data<=100)&&(data>80)) {
            return 8;
        }else if ((data<=125)&&(data>100)) {
            return 9;
        }else if ((data<=150)&&(data>125)) {
            return 10;
        }else if ((data<=175)&&(data>150)) {
            return 11;
        }else if ((data<=200)&&(data>175)) {
            return 12;
        }else if ((data<=225)&&(data>200)) {
            return 13;
        }else if ((data<=250)&&(data>225)) {
            return 14;
        }else if ((data<=275)&&(data>250)) {
            return 15;
        }else if ((data<=300)&&(data>275)) {
            return 16;
        }else if ((data<=325)&&(data>300)) {
            return 17;
        }else if ((data<=350)&&(data>325)) {
            return 18;
        }else if ((data<=375)&&(data>350)) {
            return 19;
        }else if ((data<=400)&&(data>375)) {
            return 20;
        }
        // else if ((data<=500)&&(data>400)) {
        //     return 21;
        // }else if ((data>500)) {
        //     return 22;
        // }

    }

    function baseIconMarker(feature) {

        var sFillColor = feature.properties.warning_palette;
        var geojsonMarkerOptions = {
            radius: markerWarningOptions.radius,
            fillColor: hygrometerPalette[sFillColor],
            color: markerWarningOptions.color,
            weight: markerWarningOptions.weight,
            opacity: markerWarningOptions.opacity,
            fillOpacity: markerWarningOptions.fillOpacity

        };
        return geojsonMarkerOptions
    }




    var sensorClass={
        2:{//rainfall
            paletter:function (data) {

                if (data <= -9998) {
                    return -1;
                }else if ((data==0)) {
                    return 0;
                }else if ((data<=2)) {
                    return 1;
                }else if ((data<=5)&&(data>=2)) {
                    return 2;
                }else if ((data<=10)&&(data>5)) {
                    return 3;
                }else if ((data<=15)&&(data>10)) {
                    return 4;
                }else if ((data<=20)&&(data>15)) {
                    return 5;
                }else if ((data<=25)&&(data>20)) {
                    return 6;
                }else if ((data<=30)&&(data>25)) {
                    return 7;
                }else if ((data<=40)&&(data>30)) {
                    return 8;
                }else if ((data<=50)&&(data>40)) {
                    return 9;
                }else if ((data<=60)&&(data>50)) {
                    return 10;
                }else if ((data<=70)&&(data>60)) {
                    return 11;
                }else if ((data<=80)&&(data>70)) {
                    return 12;
                }else if ((data<=90)&&(data>80)) {
                    return 13;
                }else if ((data<=100)&&(data>90)) {
                    return 14;
                }else if ((data<=125)&&(data>100)) {
                    return 15;
                }else if ((data<=150)&&(data>125)) {
                    return 16;
                }else if ((data<=175)&&(data>150)) {
                    return 17;
                }else if ((data<=200)&&(data>175)) {
                    return 18;
                }else if ((data<=300)&&(data>200)) {
                    return 19;
                }else if ((data<=400)&&(data>300)) {
                    return 20;
                }else if ((data<=500)&&(data>400)) {
                    return 21;
                }else if ((data<=600)&&(data>500)) {
                    return 22;
                }else if ((data<=700)&&(data>600)) {
                    return 23;
                }else if ((data<=800)&&(data>700)) {
                    return 24;
                }else if ((data<=900)&&(data>800)) {
                    return 25;
                }else if ((data>900)) {
                    return 26;
                }
            },
            palette:{
                '-2' : '#555',
                '-1' : '#cbcbcb',
                '0'  : '#FFF',
                '1'  : '#e1ffe1',
                '2'  : '#c8ffc8',
                '3'  : '#50f050',
                '4' : '#1eb41e',
                '5' : '#0f8c0f',
                '6'  : '#0f640f',
                '7'  : '#0f3c0f',
                '8'  : '#ffff00',
                '9'  : '#dcdc00',
                '10' : '#b9b900',
                '11' : '#969600',
                '12'  : '#737300',
                '13'  : '#505000',
                '14'  : '#ff0000',
                '15'  : '#dc0000',
                '16' : '#b90000',
                '17' : '#960000',
                '18'  : '#ff80ff',
                '19'  : '#f000f0',
                '20'  : '#b700b7',
                '21'  : '#780078',
                '22' : '#99ccff',
                '23'  : '#66ccff',
                '24'  : '#3399ff',
                '25'  : '#3366ff',
                '26'  : '#0000CC'
            },

            Style:function () {

            },
            Icon:function (feature, latlng, markerOption) {

                if(markerOption) markerWarningOptions = markerOption;

                var sFillColor = feature.properties.warning_palette;
                var geojsonMarkerOptions = {
                    radius: markerWarningOptions.radius,
                    fillColor: sensorClass[9].palette[sFillColor],
                    color: markerWarningOptions.color,
                    weight: markerWarningOptions.weight,
                    opacity: markerWarningOptions.opacity,
                    fillOpacity: markerWarningOptions.fillOpacity

                };

                return L.circleMarker(latlng, geojsonMarkerOptions);
            },
            Print:function (layer) {
                var iconFunction = sensorClass[9];
                var l = L.geoJson(layer.geoJsonLayer, {
                    pointToLayer: function(feature, latlng) {
                        return L.circleMarker(latlng, iconFunction.Icon(feature)); }
                });

                return l;
            }
        },
        3:{//hydrometer
            paletter:function (data) {

                if (data <= -9998) {
                    return -2;
                }else return 0;
            },
            palette:{
                '-2' : '#555',
                '-1' : '#cbcbcb',
                '0'  : '#FFF',
                '1'  : '#e1ffe1',
                '2'  : '#c8ffc8',
                '3'  : '#50f050',
                '4' : '#1eb41e',
                '5' : '#0f8c0f',
                '6'  : '#0f640f',
                '7'  : '#0f3c0f',
                '8'  : '#ffff00',
                '9'  : '#dcdc00',
                '10' : '#b9b900',
                '11' : '#969600',
                '12'  : '#737300',
                '13'  : '#505000',
                '14'  : '#ff0000',
                '15'  : '#dc0000',
                '16' : '#b90000',
                '17' : '#960000',
                '18'  : '#ff80ff',
                '19'  : '#f000f0',
                '20'  : '#b700b7',
                '21'  : '#780078',
                '22' : '#99ccff',
                '23'  : '#66ccff',
                '24'  : '#3399ff',
                '25'  : '#3366ff',
                '26'  : '#0000CC'
            },

            Style:function () {

            },
            Icon:function (feature, latlng, markerOption) {

                if(markerOption) markerWarningOptions = markerOption;

                var sFillColor = feature.properties.warning_palette;
                var geojsonMarkerOptions = {
                    radius: markerWarningOptions.radius,
                    fillColor: sensorClass[9].palette[sFillColor],
                    color: markerWarningOptions.color,
                    weight: markerWarningOptions.weight,
                    opacity: markerWarningOptions.opacity,
                    fillOpacity: markerWarningOptions.fillOpacity

                };

                return L.circleMarker(latlng, geojsonMarkerOptions);
            },
            Print:function (layer) {
                var iconFunction = sensorClass[9];
                var l = L.geoJson(layer.geoJsonLayer, {
                    pointToLayer: function(feature, latlng) {
                        return L.circleMarker(latlng, iconFunction.Icon(feature)); }
                });

                return l;
            }
        },
        9:{//igrometer
            paletter:function (data) {

                if (data <= -9998) {
                    return -1;
                }else if ((data<=10)) {
                    return 1;
                }else if ((data<=20)&&(data>=10)) {
                    return 2;
                }else if ((data<=30)&&(data>20)) {
                    return 3;
                }else if ((data<=40)&&(data>30)) {
                    return 4;
                }else if ((data<=50)&&(data>40)) {
                    return 5;
                }else if ((data<=60)&&(data>50)) {
                    return 6;
                }else if ((data<=70)&&(data>60)) {
                    return 7;
                }else if ((data<=80)&&(data>70)) {
                    return 8;
                }else if ((data<=90)&&(data>80)) {
                    return 9;
                }else if ((data<=100)&&(data>90)) {
                    return 10;
                }else return 11
            },
            palette:{
                '-1' : '#555',
                // '0'  : '#0a0a0a',
                '1'  : '#b90000',
                '2'  : '#b94300',
                '3'  : '#b99400',
                '4' : '#8ab900',
                '5' : '#31b900',
                '6'  : '#00b949',
                '7'  : '#00b98a',
                '8'  : '#009ab9',
                '9'  : '#0056b9',
                '10' : '#0018b9',
                //'11' : '#3a00b9'

            },

            Style:function () {

            },
            Icon:function (feature, latlng, markerOption) {

                if(markerOption) markerWarningOptions = markerOption;

                var sFillColor = feature.properties.warning_palette;
                var geojsonMarkerOptions = {
                    radius: markerWarningOptions.radius,
                    fillColor: sensorClass[9].palette[sFillColor],
                    color: markerWarningOptions.color,
                    weight: markerWarningOptions.weight,
                    opacity: markerWarningOptions.opacity,
                    fillOpacity: markerWarningOptions.fillOpacity

                };

                return L.circleMarker(latlng, geojsonMarkerOptions);
            },
            Print:function (layer) {
                var iconFunction = sensorClass[9];
                var l = L.geoJson(layer.geoJsonLayer, {
                    pointToLayer: function(feature, latlng) {
                        return L.circleMarker(latlng, iconFunction.Icon(feature)); }
                });

                return l;
            }
        },
        12:{//atm pressure
            paletter:function (data) {

                if (data <= -9998) {
                    return -1;
                }else if ((data<=982)) {
                    return 1;
                }else if ((data<=984)&&(data>=982)) {
                    return 2;
                }else if ((data<=986)&&(data>984)) {
                    return 3;
                }else if ((data<=988)&&(data>986)) {
                    return 4;
                }else if ((data<=990)&&(data>988)) {
                    return 5;
                }else if ((data<=992)&&(data>990)) {
                    return 6;
                }else if ((data<=994)&&(data>992)) {
                    return 7;
                }else if ((data<=996)&&(data>994)) {
                    return 8;
                }else if ((data<=998)&&(data>996)) {
                    return 9;
                }else if ((data<=1000)&&(data>998)) {
                    return 10;
                }else if ((data<=1002)&&(data>1000)) {
                    return 11;
                }else if ((data<=1004)&&(data>=1002)) {
                    return 12;
                }else if ((data<=1006)&&(data>1004)) {
                    return 13;
                }else if ((data<=1008)&&(data>1006)) {
                    return 14;
                }else if ((data<=1010)&&(data>1008)) {
                    return 15;
                }else if ((data<=1012)&&(data>1010)) {
                    return 16;
                }else if ((data<=1014)&&(data>1012)) {
                    return 17;
                }else if ((data<=1016)&&(data>1014)) {
                    return 18;
                }else if ((data<=1018)&&(data>1016)) {
                    return 19;
                }else if ((data<=1020)&&(data>1018)) {
                    return 20;
                }else if ((data<=1022)&&(data>1020)) {
                    return 21;
                }else if ((data<=1024)&&(data>=1022)) {
                    return 22;
                }else if ((data<=1026)&&(data>1024)) {
                    return 23;
                }else if ((data<=1028)&&(data>1026)) {
                    return 24;
                }else if ((data<=1030)&&(data>1028)) {
                    return 25;
                }else if ((data<=1032)&&(data>1030)) {
                    return 26;
                }else if ((data<=1034)&&(data>1032)) {
                    return 27;
                }else if ((data<=1036)&&(data>1034)) {
                    return 28;
                }else if ((data<=1038)&&(data>1036)) {
                    return 29;
                }else if ((data<=1040)&&(data>1038)) {
                    return 30;
                }else if ((data<=1042)&&(data>1040)) {
                    return 31;
                }else if ((data<=1044)&&(data>1042)) {
                    return 32;
                }else if ((data<=1046)&&(data>1044)) {
                    return 33;
                }else if ((data<=1048)&&(data>1046)) {
                    return 34;
                }else return 35
            },
            palette:{
                '-1' : '#555',
                // '0'  : '#0a0a0a',
                '1'  : '#666df7',
                '2'  : '#1991f9',
                '3'  : '#3ea2f4',
                '4' : '#30b4fb',
                '5' : '#78c8ed',
                '6'  : '#8adeed',
                '7'  : '#99ddb4',
                '8'  : '#6ed3a0',
                '9'  : '#44c98a',
                '10' : '#00bc3d',
                '11' : '#009e1e',
                '12'  : '#6ea254',
                '13'  : '#7db04d',
                '14' : '#7dbe54',
                '15' : '#acce64',
                '16'  : '#fed67f',
                '17'  : '#efc075',
                '18'  : '#eda64b',
                '19'  : '#e5863f',
                '20' : '#df6430',
                '21' : '#cc4942',
                '22'  : '#c3333f',
                '23'  : '#bb153d',
                '24' : '#ce264e',
                '25' : '#ea1253',
                '26'  : '#fe4d5d',
                '27'  : '#ff6171',
                '28'  : '#ff7f8f',
                '29'  : '#ff93a3',
                '30' : '#ffa2b2',
                '31' : '#ffacbc',
                '32'  : '#ffb6c6',
                '33'  : '#ffc3cd',
                '34' : '#ffc3cd',
                '35' : '#ffc3cd'

            },

            Style:function () {

            },
            Icon:function (feature, latlng, markerOption) {

                if(markerOption) markerWarningOptions = markerOption;

                var sFillColor = feature.properties.warning_palette;
                var geojsonMarkerOptions = {
                    radius: markerWarningOptions.radius,
                    fillColor: sensorClass[12].palette[sFillColor],
                    color: markerWarningOptions.color,
                    weight: markerWarningOptions.weight,
                    opacity: markerWarningOptions.opacity,
                    fillOpacity: markerWarningOptions.fillOpacity

                };

                return L.circleMarker(latlng, geojsonMarkerOptions);
            },
            Print:function (layer) {
                var iconFunction = sensorClass[12];
                var l = L.geoJson(layer.geoJsonLayer, {
                    pointToLayer: function(feature, latlng) {
                        return L.circleMarker(latlng, iconFunction.Icon(feature)); }
                });

                return l;
            }
        },
        13:{//radiation
            paletter:function (data) {
                console.log(data)
                if (data <= -9998) {
                    return -1;
                }else if ((data<=100)) {
                    return 1;
                }else if ((data<=200)&&(data>=100)) {
                    return 2;
                }else if ((data<=300)&&(data>200)) {
                    return 3;
                }else if ((data<=400)&&(data>300)) {
                    return 4;
                }else if ((data<=500)&&(data>400)) {
                    return 5;
                }else if ((data<=600)&&(data>500)) {
                    return 6;
                }else if ((data<=700)&&(data>600)) {
                    return 7;
                }else if ((data<=800)&&(data>700)) {
                    return 8;
                }else if ((data<=900)&&(data>800)) {
                    return 9;
                }else if ((data<=1000)&&(data>900)) {
                    return 10;
                }else if ((data<=1100)&&(data>1000)) {
                    return 11;
                }else if ((data<=1200)&&(data>=1100)) {
                    return 12;
                }else return 13
            },
            palette:{
                '-1' : '#555',
                '1'  : '#0a0a0a',
                '2'  : '#1991f9',
                '3'  : '#8adeed',
                '4'  : '#44c98a',
                '5' : '#00bc3d',
                '6' : '#009e1e',
                '7'  : '#6ea254',
                '8' : '#acce64',
                '9'  : '#fed67f',
                '10'  : '#eda64b',
                '11' : '#df6430',
                '12'  : '#c3333f',
                '13' : '#ea1253',


            },

            Style:function () {

            },
            Icon:function (feature, latlng, markerOption) {

                if(markerOption) markerWarningOptions = markerOption;

                var sFillColor = feature.properties.warning_palette;
                var geojsonMarkerOptions = {
                    radius: markerWarningOptions.radius,
                    fillColor: sensorClass[13].palette[sFillColor],
                    color: markerWarningOptions.color,
                    weight: markerWarningOptions.weight,
                    opacity: markerWarningOptions.opacity,
                    fillOpacity: markerWarningOptions.fillOpacity

                };

                return L.circleMarker(latlng, geojsonMarkerOptions);
            },
            Print:function (layer) {
                var iconFunction = sensorClass[13];
                var l = L.geoJson(layer.geoJsonLayer, {
                    pointToLayer: function(feature, latlng) {
                        return L.circleMarker(latlng, iconFunction.Icon(feature)); }
                });

                return l;
            }
        },
        60:{//soil temperature
            paletter:function (data) {

                if (data <= -9998) {
                    return -1;
                }else if ((data<=10)) {
                    return 1;
                }else if ((data<=12)&&(data>=10)) {
                    return 2;
                }else if ((data<=14)&&(data>12)) {
                    return 3;
                }else if ((data<=16)&&(data>14)) {
                    return 4;
                }else if ((data<=18)&&(data>16)) {
                    return 5;
                }else if ((data<=20)&&(data>18)) {
                    return 6;
                }else if ((data<=22)&&(data>20)) {
                    return 7;
                }else if ((data<=24)&&(data>22)) {
                    return 8;
                }else if ((data<=26)&&(data>24)) {
                    return 9;
                }else if ((data<=28)&&(data>26)) {
                    return 10;
                }else if ((data<=30)&&(data>28)) {
                    return 11;
                }else if ((data<=32)&&(data>=30)) {
                    return 12;
                }else return 13
            },
            palette:{
                '-1' : '#555',
                '1'  : '#0a0a0a',
                '2'  : '#1991f9',
                '3'  : '#8adeed',
                '4'  : '#44c98a',
                '5' : '#00bc3d',
                '6' : '#009e1e',
                '7'  : '#6ea254',
                '8' : '#acce64',
                '9'  : '#fed67f',
                '10'  : '#eda64b',
                '11' : '#df6430',
                '12'  : '#c3333f',
                '13' : '#ea1253',


            },

            Style:function () {

            },
            Icon:function (feature, latlng, markerOption) {

                if(markerOption) markerWarningOptions = markerOption;

                var sFillColor = feature.properties.warning_palette;
                var geojsonMarkerOptions = {
                    radius: markerWarningOptions.radius,
                    fillColor: sensorClass[60].palette[sFillColor],
                    color: markerWarningOptions.color,
                    weight: markerWarningOptions.weight,
                    opacity: markerWarningOptions.opacity,
                    fillOpacity: markerWarningOptions.fillOpacity

                };

                return L.circleMarker(latlng, geojsonMarkerOptions);
            },
            Print:function (layer) {
                var iconFunction = sensorClass[60];
                var l = L.geoJson(layer.geoJsonLayer, {
                    pointToLayer: function(feature, latlng) {
                        return L.circleMarker(latlng, iconFunction.Icon(feature)); }
                });

                return l;
            }
        },
        90:{//soil mosture
            uniformData:function(data){

                for (var i in  data.features){
                    for (var o in data.features[i].properties){
                        if(stringStartsWith(o,'v_') && stringEndsWith(o,'_0')){
                            if(data.features[i].properties[o]>100) {
                                console.log(`${data.features[i].properties[o]} after -- ${data.features[i].properties[o]/10}`)
                                data.features[i].properties[o]= data.features[i].properties[o]/10
                            }
                        }
                    }

                }
                return data
            },
            paletter:function palette_igro(data) {



                // if(data > 100) data = (data/10);

                if (data <= -9998) {
                    return -1;
                }else if ((data<=1)) {
                    return 1;
                }else if ((data<=5)&&(data>=1)) {
                    return 2;
                }else if ((data<=10)&&(data>5)) {
                    return 3;
                }else if ((data<=20)&&(data>10)) {
                    return 4;
                }else if ((data<=30)&&(data>20)) {
                    return 5;
                }else if ((data<=40)&&(data>30)) {
                    return 6;
                }else if ((data<=50)&&(data>40)) {
                    return 7;
                }else if ((data<=60)&&(data>50)) {
                    return 8;
                }else if ((data<=70)&&(data>60)) {
                    return 9;
                }else if ((data<=80)&&(data>70)) {
                    return 10;
                }else if ((data<=90)&&(data>80)) {
                    return 11;
                }else if ((data<=100)&&(data>=90)) {
                    return 12;
                }else {
                    return -1
                }
            },
            palette:{
                '-1' : '#555',
                '12'  : '#1991f9',
                '11'  : '#8adeed',
                '10'  : '#44c98a',
                '9' : '#00bc3d',
                '8' : '#009e1e',
                '7'  : '#6ea254',
                '6' : '#acce64',
                '5'  : '#fed67f',
                '4'  : '#eda64b',
                '3' : '#df6430',
                '2'  : '#c3333f',
                '1' : '#ea1253',


            },

            Style:function () {

            },
            Icon:function (feature, latlng, markerOption) {

                if(markerOption) markerWarningOptions = markerOption;

                let key = Object.keys(feature.properties).filter((p)=>{
                        return (stringStartsWith(p,'v_') && stringEndsWith(p,'0'))
                })[0];

                let sFillColor = sensorClass[90].paletter(feature.properties[key]);
                let geojsonMarkerOptions = {
                    radius: markerWarningOptions.radius,
                    fillColor: sensorClass[90].palette[sFillColor],
                    color: markerWarningOptions.color,
                    weight: markerWarningOptions.weight,
                    opacity: markerWarningOptions.opacity,
                    fillOpacity: markerWarningOptions.fillOpacity

                };

                return L.circleMarker(latlng, geojsonMarkerOptions);
            },
            Print:function (layer) {
                var iconFunction = sensorClass[90];
                var l = L.geoJson(layer.geoJsonLayer, {
                    pointToLayer: function(feature, latlng) {
                        return L.circleMarker(latlng, iconFunction.Icon(feature)); }
                });

                return l;
            }
        },
        98:{//fuel stick
            uniformData:function(data){

                for (var i in  data.features){
                    for (var o in data.features[i].properties){
                        if(stringStartsWith(o,'v_') && stringEndsWith(o,'_0')){
                            if(data.features[i].properties[o]>100) {
                                console.log(`${data.features[i].properties[o]} after -- ${data.features[i].properties[o]/10}`)
                                data.features[i].properties[o]= data.features[i].properties[o]/10
                            }
                        }
                    }

                }
                return data
            },
            paletter:function palette_igro(data) {



                // if(data > 100) data = (data/10);

                if (data <= -9998) {
                    return -1;
                }else if ((data<=1)) {
                    return 1;
                }else if ((data<=5)&&(data>=1)) {
                    return 2;
                }else if ((data<=10)&&(data>5)) {
                    return 3;
                }else if ((data<=20)&&(data>10)) {
                    return 4;
                }else if ((data<=30)&&(data>20)) {
                    return 5;
                }else if ((data<=40)&&(data>30)) {
                    return 6;
                }else if ((data<=50)&&(data>40)) {
                    return 7;
                }else if ((data<=60)&&(data>50)) {
                    return 8;
                }else if ((data<=70)&&(data>60)) {
                    return 9;
                }else if ((data<=80)&&(data>70)) {
                    return 10;
                }else if ((data<=90)&&(data>80)) {
                    return 11;
                }else if ((data<=100)&&(data>=90)) {
                    return 12;
                }else {
                    return -1
                }
            },
            palette:{
                '-1' : '#555',
                '12'  : '#1991f9',
                '11'  : '#8adeed',
                '10'  : '#44c98a',
                '9' : '#00bc3d',
                '8' : '#009e1e',
                '7'  : '#6ea254',
                '6' : '#acce64',
                '5'  : '#fed67f',
                '4'  : '#eda64b',
                '3' : '#df6430',
                '2'  : '#c3333f',
                '1' : '#ea1253',


            },

            Style:function () {

            },
            Icon:function (feature, latlng, markerOption) {

                if(markerOption) markerWarningOptions = markerOption;

                let key = Object.keys(feature.properties).filter((p)=>{
                    return (stringStartsWith(p,'v_') && stringEndsWith(p,'0'))
                })[0];

                let sFillColor = sensorClass[98].paletter(feature.properties[key]);
                let geojsonMarkerOptions = {
                    radius: markerWarningOptions.radius,
                    fillColor: sensorClass[98].palette[sFillColor],
                    //fillColor: 'green',
                    color: markerWarningOptions.color,
                    weight: markerWarningOptions.weight,
                    opacity: markerWarningOptions.opacity,
                    fillOpacity: markerWarningOptions.fillOpacity

                };

                return L.circleMarker(latlng, geojsonMarkerOptions);
            },
            Print:function (layer) {
                var iconFunction = sensorClass[90];
                var l = L.geoJson(layer.geoJsonLayer, {
                    pointToLayer: function(feature, latlng) {
                        return L.circleMarker(latlng, iconFunction.Icon(feature)); }
                });

                return l;
            }
        }
    };


    function desinventar_paletter() {

    }


    return{

        sensorClassStylist:sensorClass,

        palette_pluvio : palette_pluvio,

        palette_nivo : palette_nivo,

        markerWarningOptions: markerWarningOptions,

        markerFloodOptions: markerFloodOptions,

        warningHydroPalette: warningHydroPalette,

        warningPluvioPalette : warningPluvioPalette,

        warningThermoPalette: warningThermoPalette,

        thermometerPalette : thermometerPalette,

        raingaugePalette : raingaugePalette,

        hygrometerPalette : hygrometerPalette,

        anemometerPalette : anemometerPalette,

        nivometerPalette : nivometerPalette,

        warningFireIndexPalette : warningFireIndexPalette,

        rasorDamagePalette:rasorDamagePalette,

        phenologicalPalette:{
            "fase_igsi": [
                    {color: "#3f1e00", value: 0,  label: '0.00'},
                    {color: "#412404", value: 4,  label: '0.40'},
                    {color: "#422a07", value: 8,  label: '0.80'},
                    {color: "#43300a", value: 12, label: '0.12'},
                    {color: "#44360c", value: 16, label: '0.16'},
                    {color: "#453c0e", value: 20, label: '0.20'},
                    {color: "#464210", value: 24, label: '0.24'},
                    {color: "#464812", value: 28, label: '0.28'},
                    {color: "#474e14", value: 32, label: '0.32'},
                    {color: "#475317", value: 36, label: '0.36'},
                    {color: "#475919", value: 40, label: '0.40'},
                    {color: "#465f1b", value: 44, label: '0.44'},
                    {color: "#46651d", value: 48, label: '0.48'},
                    {color: "#456b1f", value: 52, label: '0.52'},
                    {color: "#437222", value: 56, label: '0.56'},
                    {color: "#427824", value: 60, label: '0.60'},
                    {color: "#407e26", value: 64, label: '0.64'},
                    {color: "#3d8429", value: 68, label: '0.68'},
                    {color: "#3a8a2b", value: 72, label: '0.72'},
                    {color: "#36902d", value: 76, label: '0.76'},
                    {color: "#319730", value: 80, label: '0.80'},
                    {color: "#2b9d32", value: 84, label: '0.84'},
                    {color: "#23a335", value: 88, label: '0.88'},
                    {color: "#18aa37", value: 92, label: '0.92'},
                    {color: "#00b03a", value: 96, label: '0.96'},
                    {color: "#00c030", value: 100, label: '1.00'}
            ],
            "fase_gsi": [
                {color: "#3f1e00", value: 0,  label: '0.00'},
                {color: "#412404", value: 4,  label: '0.40'},
                {color: "#422a07", value: 8,  label: '0.80'},
                {color: "#43300a", value: 12, label: '0.12'},
                {color: "#44360c", value: 16, label: '0.16'},
                {color: "#453c0e", value: 20, label: '0.20'},
                {color: "#464210", value: 24, label: '0.24'},
                {color: "#464812", value: 28, label: '0.28'},
                {color: "#474e14", value: 32, label: '0.32'},
                {color: "#475317", value: 36, label: '0.36'},
                {color: "#475919", value: 40, label: '0.40'},
                {color: "#465f1b", value: 44, label: '0.44'},
                {color: "#46651d", value: 48, label: '0.48'},
                {color: "#456b1f", value: 52, label: '0.52'},
                {color: "#437222", value: 56, label: '0.56'},
                {color: "#427824", value: 60, label: '0.60'},
                {color: "#407e26", value: 64, label: '0.64'},
                {color: "#3d8429", value: 68, label: '0.68'},
                {color: "#3a8a2b", value: 72, label: '0.72'},
                {color: "#36902d", value: 76, label: '0.76'},
                {color: "#319730", value: 80, label: '0.80'},
                {color: "#2b9d32", value: 84, label: '0.84'},
                {color: "#23a335", value: 88, label: '0.88'},
                {color: "#18aa37", value: 92, label: '0.92'},
                {color: "#00b03a", value: 96, label: '0.96'},
                {color: "#00c030", value: 100, label: '1.00'}
            ],
            "fase_fenologica":{
                "1":"#FF0000",
                "2":"#70f5ff",
                "3":"#00ff00",
                "4":"#FFFF00",
                "5":"#ffaf00",
            },
            "fase_erbacee":{
                "1":"#FF0000",
                "2":"#AFFCE0",
                "3":"#00FF00",
                "4":"#FFFF00",
            },
            "cfr_anno;fase_erbacee":{
                "-1":"#B8B8B8",
                "0":"#00FF00",
                "1":"#FF0000",
                "2":"#FFFF00",
            },
            "cfr_anno;fase_fenologica":{
                "-1":"#B8B8B8",
                "0":"#00FF00",
                "1":"#FF0000",
                "2":"#FFFF00",
            }
        },

        thermoPalette : palette_thermo,

        windPalette : windPalette,

        windIcon: function (val) {
            return  L.icon({
                iconUrl: 'apps/dewetra2/img/wind/wind_'+val+'.png',
                iconSize:     [30, 30]
            })
        },

        getWindDirection: getWindDirection,

        // warnings_hydro_Icon :function(feature){
        //
        //     var sFillColor = feature.properties.warning_palette;
        //     var geojsonMarkerOptions = {
        //         radius: markerWarningOptions.radius,
        //         fillColor: warningPluvioPalette[sFillColor],
        //         color: markerWarningOptions.color,
        //         weight: markerWarningOptions.weight,
        //         opacity: markerWarningOptions.opacity,
        //         fillOpacity: markerWarningOptions.fillOpacity
        //
        //     };
        //     return geojsonMarkerOptions
        // },

        warnings_pluvio_Icon : function (feature) {

            var sFillColor = feature.properties.warning_palette;
            var geojsonMarkerOptions = {
                radius: markerWarningOptions.radius,
                fillColor: warningPluvioPalette[sFillColor],
                color: markerWarningOptions.color,
                weight: markerWarningOptions.weight,
                opacity: markerWarningOptions.opacity,
                fillOpacity: markerWarningOptions.fillOpacity

            };
            return geojsonMarkerOptions
        },

        warnings_thermo_Icon :function(feature){

            var sFillColor = feature.properties.warning_palette;
            var geojsonMarkerOptions = {
                radius: markerWarningOptions.radius,
                fillColor: warningPluvioPalette[sFillColor],
                color: markerWarningOptions.color,
                weight: markerWarningOptions.weight,
                opacity: markerWarningOptions.opacity,
                fillOpacity: markerWarningOptions.fillOpacity

            };
            return geojsonMarkerOptions
        },

        raingauge_Icon :function(feature){

            var sFillColor = feature.properties.warning_palette;

            if(_.isUndefined(feature.properties.warning_palette)){
                feature.properties.warning_palette = palette_pluvio(feature.properties.lastvalue);
                sFillColor =feature.properties.warning_palette;
            }

            var geojsonMarkerOptions = {
                radius: markerWarningOptions.radius,
                fillColor: raingaugePalette[sFillColor],
                color: markerWarningOptions.color,
                weight: markerWarningOptions.weight,
                opacity: markerWarningOptions.opacity,
                fillOpacity: markerWarningOptions.fillOpacity

            };
            return geojsonMarkerOptions
        },

        thermometer_Icon :function(feature){

            var sFillColor = feature.properties.warning_palette;

            if(_.isUndefined(feature.properties.warning_palette)){
                feature.properties.warning_palette = palette_thermo(feature.properties.lastvalue);
                sFillColor =feature.properties.warning_palette;
            }

            var geojsonMarkerOptions = {
                radius: markerWarningOptions.radius,
                fillColor: thermometerPalette[sFillColor],
                color: markerWarningOptions.color,
                weight: markerWarningOptions.weight,
                opacity: markerWarningOptions.opacity,
                fillOpacity: markerWarningOptions.fillOpacity

            };
            return geojsonMarkerOptions
        },

        hygrometer_Icon :function(feature){

            var sFillColor = feature.properties.warning_palette;
            var geojsonMarkerOptions = {
                radius: markerWarningOptions.radius,
                fillColor: hygrometerPalette[sFillColor],
                color: markerWarningOptions.color,
                weight: markerWarningOptions.weight,
                opacity: markerWarningOptions.opacity,
                fillOpacity: markerWarningOptions.fillOpacity

            };
            return geojsonMarkerOptions
        },

        sensor_class_Icon:function (feature) {

            var sFillColor = feature.properties.warning_palette;
            var geojsonMarkerOptions = {
                radius: markerWarningOptions.radius,
                fillColor: hygrometerPalette[sFillColor],
                color: markerWarningOptions.color,
                weight: markerWarningOptions.weight,
                opacity: markerWarningOptions.opacity,
                fillOpacity: markerWarningOptions.fillOpacity

            };
            return geojsonMarkerOptions
        },

        fire_index_Icon :function(feature){

            var sFillColor = feature.properties.warning_palette;
            var geojsonMarkerOptions = {
                radius: markerWarningOptions.radius,
                fillColor: warningPluvioPalette[sFillColor],
                color: markerWarningOptions.color,
                weight: markerWarningOptions.weight,
                opacity: markerWarningOptions.opacity,
                fillOpacity: markerWarningOptions.fillOpacity

            };
            return geojsonMarkerOptions
        },


        //nuovo metodo di stampa

        warnings_pluvio_Print : function (layer){
            var iconFunction = this;
            var l = L.geoJson(layer.geoJsonLayer, {
                pointToLayer: function(feature, latlng) {

                    let o = iconFunction.markerWarningOptions
                    o.fillColor =iconFunction.warningPluvioPalette[feature.properties.warning_palette];
                    return L.circleMarker(latlng, o); }
            });

            return l;
        },

        fire_index_Print:function(layer){
            var iconFunction = this;
            var l = L.geoJson(layer.geoJsonLayer, {
                pointToLayer: function(feature, latlng) {
                    return L.circleMarker(latlng, iconFunction.fire_index_Icon(feature)); }
            });

            return l;
        },

        coau_Icon:function (feature, latlng) {
            return L.marker(latlng, {icon: L.icon({
                iconUrl: 'apps/dewetra2/img/canadair.svg',
                // iconColor:     "black",
                iconSize:     [30, 30]
            })});
        },

        coau_Print:function (layer) {
            var iconFunction = this;
            var l = L.geoJson(layer.geoJsonLayer, {
                pointToLayer: iconFunction.coau_Icon,
            });

            return l;
        },

        terna_Icon:function (feature, latlng) {
            return L.marker(latlng, {icon: L.icon({
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/terna.svg',
                    // iconColor:     "black",
                    iconSize:     [30, 30]
                })});
        },

        terna_Print:function (layer) {
            var iconFunction = this;
            var l = L.geoJson(layer.geoJsonLayer, {
                pointToLayer: iconFunction.terna_Icon,
            });

            return l;
        },

        status_radar_Icon : function (feature, latlng) {
            let color = (feature.properties.active)?'green':'grey';
            return L.circleMarker(latlng,
                {
                    radius: 8,
                    fillColor: color,
                    color: "#000",
                    weight: 1,
                    opacity: 1,
                    fillOpacity: 0.8
                });

        },

        status_radar_Print : function (layer) {
            var iconFunction = this;

            var l = L.geoJson(layer.geoJsonLayer, {
                pointToLayer: iconFunction.status_radar_Icon,
            });

            return l;
        },

        dam_italia_Icon : function (feature, latlng) {

            let v = Object.keys(feature.properties).filter((key)=>{
                return key.startsWith('v_');
            });
            var color;
            if(v.length > 0){
                let vSplitted = v[0].split('_');
                let timeOfData = moment.unix(parseInt(vSplitted[1]));
                // let now = moment.utc();
                let dateFromService = parseInt(feature.properties.now);
                let now = moment.unix(dateFromService).add(10, 'minutes');
                let nowMinusOneHour = moment.unix(dateFromService).subtract(1, 'hours');
                let nowMinus24Hour = moment.unix(dateFromService).subtract(24, 'hours');

                if(timeOfData.isBetween(nowMinusOneHour, now)){
                    color = 'green';
                }else if(timeOfData.isBetween(nowMinus24Hour,nowMinusOneHour)){
                    color = 'white';
                }else if (timeOfData.isBefore(nowMinus24Hour)){
                    color = 'grey';
                }
            }else{
                color = 'grey';
            }

            return L.circleMarker(latlng,
                {
                    radius: 6,
                    fillColor: color,
                    color: "#000",
                    weight: 1,
                    opacity: 1,
                    fillOpacity: 0.8
                });

        },

        dam_italia_Print : function (layer) {
            var iconFunction = this;
            var l = L.geoJson(layer.geoJsonLayer, {
                pointToLayer: iconFunction.dam_italia_Icon
            });

            return l;
        },

        frp_Icon:function (feature, latlng) {
            return L.marker(latlng, {icon: L.icon({
                    iconUrl: 'apps/dewetra2/img/flame.svg',
                    // iconColor:     "black",
                    iconSize:     [30, 30]
                })});
        },

        frp_Print:function (layer) {
            var iconFunction = this;
            var l = L.geoJson(layer.geoJsonLayer, {
                pointToLayer: iconFunction.frp_Icon,
            });

            return l;
        },

        scenario_Icon :function( latlng ,type){

            var scenarioIconConfig = {
                'hospital':{
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/hospital.svg',
                    iconColor:     "black",
                    iconSize:     [30, 30]
                },
                'plane':{
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/plane.svg',
                    iconColor:     "black",
                    iconSize:     [30, 30]
                },
                'power':{
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/power.svg',
                    iconColor:     "black",
                    iconSize:     [30, 30]
                },
                'boat':{
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/boat.svg',
                    iconColor:     "black",
                    iconSize:     [30, 30]
                },
                'museum':{
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/museum.svg',
                    iconColor:     "black",
                    iconSize:     [30, 30]
                },
                'population':{
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/population.svg',
                    iconColor:     "black",
                    iconSize:     [30, 30]
                },
                'road':{
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/road.svg',
                    iconColor:     "black",
                    iconSize:     [30, 30]
                },
                'school':{
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/school.svg',
                    iconColor:     "black",
                    iconSize:     [30, 30]
                },
                'train':{
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/train.svg',
                    iconColor:     "black",
                    iconSize:     [30, 30]
                },
                'dams':{
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/dams.svg',
                    iconColor:     "black",
                    iconSize:     [30, 30]
            },

            }


            return L.marker(latlng, {icon: L.icon(scenarioIconConfig[type])})
        },
        scenario_Print :function(){

        },

        warnings_hydro_Print:function(layer){
            var iconFunction = this;

            var aggregation = _.filter(layer.props.aggregation,function (obj) {
                return obj.selected == true
            });


            if (aggregation[0].type !="STAZIONI"){
                var l = L.geoJson(layer.geoJsonLayer, {
                    style: function(feature, latlng) {
                        var sFillColor = feature.properties.warning_palette;
                            var geojsonMarkerOptions = {
                                radius: markerWarningOptions.radius,
                                fillColor: warningHydroPalette[sFillColor],
                                color: markerWarningOptions.color,
                                fillOpacity: markerWarningOptions.fillOpacity,
                                weight: markerWarningOptions.weight,

                            };
                            return geojsonMarkerOptions
                    }
                });

            }else{
                var l = L.geoJson(layer.geoJsonLayer, {
                    pointToLayer: function(feature, latlng) {
                        return L.marker(latlng, {icon: iconFunction.warnings_hydro_Icon(feature, 1)});
                    }
                });

                for(var p in l._layers){
                    l._layers[p].setZIndexOffset(p*l._layers[p].feature.properties.warning_palette)
                }
            }

            return l;

        },

        wind_Icon :function(feature, latlng){

            var iconFunction = this;


            var val = iconFunction.windPalette((feature.properties.speed)?feature.properties.speed.value:1);

            if(!angular.isDefined(val)) val = 0;

            //feature.properties."v_1574512200_0": 105.0

            if(feature && feature.properties){

                for(var i in feature.properties){
                    if (stringStartsWith(i,'v_')){
                        feature.properties.value =feature.properties[i]

                    }

                }

            }

            return  L.marker(latlng, {icon: L.icon({
                iconUrl: 'apps/dewetra2/img/wind/wind_'+val+'.png',
                iconSize:     [30, 30]
            }),rotationAngle : feature.properties.value });
        },

        //RASOR_DAMAGE



        rasor_damage_Palette_Contour:function (feature) {

            if(feature.properties.indicator_77 == 1) return 4;
            else if(feature.properties.indicator_76 == 1) return 3;
            else if(feature.properties.indicator_75 == 1) return 2;
            else if(feature.properties.indicator_74 == 1) return 1;
            else return 0;
0
        },

        rasor_damage_Palette_fill:function (feature) {

        },

        rasor_damage_Icon:function (feature, indicator) {

            return {
                color: rasorDamagePalette[this.rasor_damage_Palette_Contour(feature)], "weight": 1, opacity: 1, fillColor: feature[indicator.name+"_color"], fillOpacity: 0.6
            };
        },

        // RASOR_DAMAGE_END



        phenological_analysis_Icon :function(feature){

            var sFillColor = feature.properties.fillColor;
            var geojsonMarkerOptions = {
                radius: markerWarningOptions.radius,
                fillColor: sFillColor,
                color: markerWarningOptions.color,
                weight: markerWarningOptions.weight,
                opacity: markerWarningOptions.opacity,
                fillOpacity: markerWarningOptions.fillOpacity

            };
            return geojsonMarkerOptions
        },


        wind_Print:function(layer){
            var iconFunction = this;
            return L.geoJson(layer.geoJsonLayer, {
                pointToLayer: function(feature, latlng) {

                    var val = iconFunction.windPalette((feature.properties.speed) ? feature.properties.speed.value : 1);

                    if(!angular.isDefined(val)) val = 0;

                    return L.marker(latlng, {icon: L.icon({
                        iconUrl: 'apps/dewetra2/img/wind/wind_'+val+'.png',
                        iconSize:     [30, 30]
                    }),rotationAngle : feature.properties.value});
                }


            })
        },




        geocradle_soil_analysis_Print:function(layer){
            var iconFunction = this;

            var l = L.geoJson(layer.geoJsonLayer, {
                pointToLayer: function(feature, latlng) {
                    var geojsonMarkerOptions = {

                        radius : 5,
                        weight : 1,
                        color : "#000000",
                        opacity : 1,
                        fillOpacity: 0.8,
                        fillColor: feature.properties.fillColor

                    }
                    return L.circleMarker(latlng, geojsonMarkerOptions )}
            });

            return l;
        },


        bulletin_fire_Colors :[ '#A1FFA7',
            'orange',
            'red',
        ],

        bulletin_fire_Print:function (layer) {

            var iconFunction = this;
            return L.geoJson(layer.geoJsonLayer, {
                style: function(feature, latlng) {

                    return {color: "#000000", "weight": 1, opacity: 1, fillColor: iconFunction.bulletin_fire_Colors[feature.properties.crit_fire], fillOpacity: 0.6};
                }


            })
        },


        bulletin_hydro_Colors:[
            '#A1FFA7',
            'yellow',
            'orange',
            'red',
            'url(apps/dewetra2/index_mydewetra.html#diagonalHatch_yellow)',
            'url(apps/dewetra2/index_mydewetra.html#diagonalHatch_orange)',
            'url(apps/dewetra2/index_mydewetra.html#diagonalHatch_red)',
            'url(apps/dewetra2/index_mydewetra.html#tempHatch_yellow)',
            'url(apps/dewetra2/index_mydewetra.html#tempHatch_orange)',
            'url(apps/dewetra2/index_mydewetra.html#tempHatch_red)'
        ],



        bulletin_hydro_Icon:function(idro_crit, geo_crit, temp_crit){

            if(temp_crit == 3) alert('3333333');

            var max_lev = Math.max(idro_crit, geo_crit, temp_crit);
            if (idro_crit == max_lev) return idro_crit;
            else if (temp_crit == max_lev) return temp_crit + 6;
            else if (geo_crit == max_lev) return geo_crit + 3;

        },

        bulletin_hydro_StyleFunction:function (feature) {
            var iconFunction = this;
            return {color: "#000000", "weight": 1, opacity: 1, fillColor: iconFunction.bulletin_hydro_Colors[iconFunction.bulletin_hydro_Icon(feature.properties.crit_idro,feature.properties.crit_idrogeo,feature.properties.crit_temp)], fillOpacity: 0.6};
        },

        bulletin_hydro_Print:function(layer){

            var iconFunction = this;
            return L.geoJson(layer.geoJsonLayer, {
                style: function (feature) {
                    return iconFunction.bulletin_hydro_StyleFunction(feature)
                }


            })

        },

        nivometer_Icon:function (feature, latlng) {
            var iconFunction = this;

            var sFillColor = feature.properties.warning_palette;
            var geojsonMarkerOptions = {
                radius: markerWarningOptions.radius,
                fillColor: nivometerPalette[sFillColor],
                color: markerWarningOptions.color,
                weight: markerWarningOptions.weight,
                opacity: markerWarningOptions.opacity,
                fillOpacity: markerWarningOptions.fillOpacity
            };
            return L.circleMarker(latlng, geojsonMarkerOptions);
        },


        hygrometer_Icon:function (feature, latlng) {
            var iconFunction = this;

            var sFillColor = feature.properties.warning_palette;
            var geojsonMarkerOptions = {
                radius: markerWarningOptions.radius,
                fillColor: hygrometerPalette[sFillColor],
                color: markerWarningOptions.color,
                weight: markerWarningOptions.weight,
                opacity: markerWarningOptions.opacity,
                fillOpacity: markerWarningOptions.fillOpacity
            };
            return L.circleMarker(latlng, geojsonMarkerOptions);
        },

        hygrometer_Print:function (layer) {
            var iconFunction = this;
            return L.geoJson(layer.geoJsonLayer, {
                pointToLayer: function (feature, latlng) {
                    return iconFunction.hygrometer_Icon(feature, latlng)
                }


            })
        },


        section_gauge_observation_Print : function (layer) {
            var iconFuntion = this;
            return L.geoJson(layer.geoJsonLayer,{
                pointToLayer:function (feature, latlng) {
                    return L.marker(latlng, {icon:iconFuntion.section_gauge_observation_Icon(feature)});
                }
            });

        },

        section_probabilistic_lami_Print :function (layer) {
            var iconFuntion = this;
            return L.geoJson(layer.geoJsonLayer,{
                pointToLayer:function (feature, latlng) {
                    return L.marker(latlng, {icon:iconFuntion.section_gauge_observation_Icon(feature)});
                }
            });
        },

        editabl_layer_Print:function (layer) {

        },

        // warning_hydro_Print:function (layer) {
        //     var iconFunction = this;
        //     return L.geoJson(layer.geoJsonLayer, {
        //         pointToLayer: function (feature, latlng) {
        //             return iconFunction.hygrometer_Icon(feature, latlng)
        //         }
        //
        //
        //     })
        // },

        warnings_hydro_Icon:function (feature, opacity) {

            return getTriangleIcon(ICON_SIZE, warningHydroPalette[feature.properties.warning_palette], "black", opacity, feature.properties.seriestate);
        },

        droughtproods_SPI_Icon: function (feature, opacity){
            let color = (feature.properties.maxvalue > -9998)?'white':'grey';

            feature.properties.trend = 0;

            if(feature.properties.maxvalue <= -9997){
                return getTriangleIcon(ICON_SIZE, 'grey', "black", 1,feature.properties.trend);
            }else if(feature.properties.Q_ALLARME &&feature.properties.Q_ALLARME != -9999 && feature.properties.maxvalue < feature.properties.Q_ALLARME ){
                return getTriangleIcon(ICON_SIZE, 'red', "black", 1,feature.properties.trend);
            }else if(feature.properties.Q_ALLERTA &&feature.properties.Q_ALLERTA != -9999 && feature.properties.maxvalue < feature.properties.Q_ALLERTA){
                return getTriangleIcon(ICON_SIZE, 'yellow', "black", 1,feature.properties.trend);
            } else return getTriangleIcon(ICON_SIZE, 'white', "black", 1,feature.properties.trend);

        },

        droughtproods_GUY_Icon: function (feature, opacity){
            let color = (feature.properties.maxvalue > -9998)?'white':'grey';

            feature.properties.trend = 0;

            if(feature.properties.maxvalue <= -9997){
                return getTriangleIcon(ICON_SIZE, 'grey', "black", 1,feature.properties.trend);
            }else if(feature.properties.Q_ALLARME &&feature.properties.Q_ALLERTA != -9999 && feature.properties.maxvalue > feature.properties.Q_ALLERTA ){
                return getTriangleIcon(ICON_SIZE, 'red', "black", 1,feature.properties.trend);
            }else if(feature.properties.Q_ALLERTA &&feature.properties.Q_ALLARME != -9999 && feature.properties.maxvalue > feature.properties.Q_ALLARME){
                return getTriangleIcon(ICON_SIZE, 'yellow', "black", 1,feature.properties.trend);
            } else return getTriangleIcon(ICON_SIZE, 'white', "black", 1,feature.properties.trend);

        },

        spi_spei_stations_Icon: function (feature, opacity){
            let color = (feature.properties.maxvalue > -9998)?'white':'grey';

            feature.properties.trend = 0;


            if(feature.properties.maxvalue <= -9997){
                return getTriangleIcon(ICON_SIZE, 'grey', "black", 1,-1);
            }else if(feature.properties.Q_ALLARME &&feature.properties.Q_ALLARME != -9999 && feature.properties.maxvalue < feature.properties.Q_ALLARME ){
                return getTriangleIcon(ICON_SIZE, 'red', "black", 1, -1);
            }else if(feature.properties.Q_ALLERTA &&feature.properties.Q_ALLERTA != -9999 && feature.properties.maxvalue < feature.properties.Q_ALLERTA ){
                return getTriangleIcon(ICON_SIZE, 'yellow', "black", 1,-1);
            } else return getTriangleIcon(ICON_SIZE, 'white', "black", 1,-1);

        },

        serie_generic_Icon: function (feature, opacity){
            let color = (feature.properties.maxvalue > -9998)?'white':'grey';

            feature.properties.trend = 0;

            if(feature.properties.maxvalue <= -9997){
                return getTriangleIcon(ICON_SIZE, 'grey', "black", 1,feature.properties.trend);
            }else if(feature.properties.Q_THR3 &&feature.properties.Q_THR3 != -9999 && feature.properties.maxvalue > feature.properties.Q_THR3 ){
                return getTriangleIcon(ICON_SIZE, 'red', "black", 1,feature.properties.trend);
            }else if(feature.properties.Q_THR2 &&feature.properties.Q_THR2 != -9999 && feature.properties.maxvalue > feature.properties.Q_THR2 ){
                return getTriangleIcon(ICON_SIZE, 'orange', "black", 1,feature.properties.trend);
            }else if(feature.properties.Q_THR1 &&feature.properties.Q_THR1 != -9999 && feature.properties.maxvalue > feature.properties.Q_THR1 ){
                return getTriangleIcon(ICON_SIZE, 'yellow', "black", 1,feature.properties.trend);
            } else return getTriangleIcon(ICON_SIZE, 'white', "black", 1,feature.properties.trend);

        },

        serie_FP_auc_Icon: function (feature, opacity){
            let color = (feature.properties.maxvalue > -9998)?'white':'grey';

            feature.properties.trend = 0;

            if(feature.properties.maxvalue <= -9997){
                return getTriangleIcon(ICON_SIZE, 'grey', "black", 1,feature.properties.trend);
            }else if(feature.properties.Q_THR3 &&feature.properties.Q_THR3 != -9999 && feature.properties.maxvalue > feature.properties.Q_THR3 ){
                return getTriangleIcon(ICON_SIZE, 'red', "black", 1,feature.properties.trend);
            }else if(feature.properties.Q_THR2 &&feature.properties.Q_THR2 != -9999 && feature.properties.maxvalue > feature.properties.Q_THR2 ){
                return getTriangleIcon(ICON_SIZE, 'orange', "black", 1,feature.properties.trend);
            }else if(feature.properties.Q_THR1 &&feature.properties.Q_THR1 != -9999 && feature.properties.maxvalue > feature.properties.Q_THR1 ){
                return getTriangleIcon(ICON_SIZE, 'yellow', "black", 1,feature.properties.trend);
            } else return getTriangleIcon(ICON_SIZE, 'white', "black", 1,feature.properties.trend);

        },


        section_gauge_observation_Icon: function(feature, opacity){

            //console.log(feature.properties.trend)

            var sBorderColor = (feature.properties.obs && feature.properties.obs== 1)?"#8a2be2":"black";

            var sectionIconUndefined = getTriangleIcon(ICON_SIZE, "grey", sBorderColor, (opacity)?opacity:markerFloodOption.opacity,feature.properties.trend);

            var sectionIconNoThresholdLow = getTriangleIcon(ICON_SIZE, "white", sBorderColor, (opacity)?opacity:markerFloodOption.opacity,feature.properties.trend);

            var sectionIconNoThresholdHigh = getTriangleIcon(ICON_SIZE, "lime", sBorderColor, (opacity)?opacity:markerFloodOption.opacity,feature.properties.trend);

            var sectionIconOrdinaria = getTriangleIcon(ICON_SIZE, "yellow", sBorderColor, (opacity)?opacity:markerFloodOption.opacity,feature.properties.trend);

            var sectionIconElevata = getTriangleIcon(ICON_SIZE, "red", sBorderColor, (opacity)?opacity:markerFloodOption.opacity,feature.properties.trend);

            var sectionIconNoRain = getTriangleIcon(ICON_SIZE, "cyan", sBorderColor, (opacity)?opacity:markerFloodOption.opacity,feature.properties.trend);

            var sectionIconNoMeteoModel = getTriangleIcon(ICON_SIZE, "#4d5d53", sBorderColor, (opacity)?opacity:markerFloodOption.opacity,feature.properties.trend);

            var sectionIconRunNow = getTriangleIcon(ICON_SIZE, "#b1d0ca", sBorderColor, (opacity)?opacity:markerFloodOption.opacity,feature.properties.trend);

            var value = feature.properties.maxvalue;

            //Creo array soglie
            var aThreshold = [];
            if(value != -9999 && value != -7777 && value != -6666 && value != -5555) {
                for (var prop in feature.properties) {
                    if ((stringStartsWith(prop, "Q_ALLARME")) || (stringStartsWith(prop, "Q_ALLERTA"))) {
                        if (feature.properties[prop] != -9999 && feature.properties[prop] != 0) {
                            var obj = {
                                prop: feature.properties[prop],
                                exceded: (value > feature.properties[prop]) ? true : false
                            };
                            aThreshold.push(obj)
                        }
                    }
                }
            }



            if (value == -7777 ){
                return sectionIconNoRain;
            }else if(value == -6666 ){
                return sectionIconNoMeteoModel;
            }else if (value == -5555){
                return sectionIconRunNow;
            }

            var superati = _.filter(aThreshold, function(obj){
                return obj.exceded
            });

            var icon;

            switch(aThreshold.length){
                case 0:
                    if (value != -9999 && value != -7777 && value != -6666 && value != -5555) {
                        return sectionIconNoThresholdLow;
                    }else {
                        return sectionIconUndefined;
                    }

                    break;
                case 1:
                    (superati.length == 1) ? icon = sectionIconElevata : icon = null;
                    if (superati.length == 0){
                        feature.properties.trend > 0?icon = sectionIconNoThresholdHigh:icon = sectionIconNoThresholdLow
                    }
                    break;
                case 2:
                    if (superati.length == 1)icon = sectionIconOrdinaria;
                    if (superati.length == 2)icon = sectionIconElevata;
                    if (superati.length == 0){
                        feature.properties.trend > 0?icon = sectionIconNoThresholdHigh:icon = sectionIconNoThresholdLow
                    }
                    break;
            }
            return icon;
        },

        section_gauge_observation_level_Icon: function(feature, opacity){

            var sectionIconUndefined = getTriangleIcon(ICON_SIZE, "grey", "black", (opacity)?opacity:markerFloodOption.opacity, feature.properties.trend);

            var sectionIconNoThresholdLow = getTriangleIcon(ICON_SIZE, "white", "black", (opacity)?opacity:markerFloodOption.opacity, feature.properties.trend);

            var sectionIconNoThresholdHigh = getTriangleIcon(ICON_SIZE, "lime", "black", (opacity)?opacity:markerFloodOption.opacity, feature.properties.trend);

            var sectionIconOrdinaria = getTriangleIcon(ICON_SIZE, "yellow", "black", (opacity)?opacity:markerFloodOption.opacity, feature.properties.trend);

            var sectionIconElevata = getTriangleIcon(ICON_SIZE, "red", "black", (opacity)?opacity:markerFloodOption.opacity, feature.properties.trend);

            var sectionIconMax = getTriangleIcon(ICON_SIZE, "purple", "black", (opacity)?opacity:markerFloodOption.opacity, feature.properties.trend);

            var sectionIconNoRain = getTriangleIcon(ICON_SIZE, "cyan", "black", (opacity)?opacity:markerFloodOption.opacity, feature.properties.trend);

            var sectionIconNoMeteoModel = getTriangleIcon(ICON_SIZE, "#4d5d53", "black", (opacity)?opacity:markerFloodOption.opacity, feature.properties.trend);

            var sectionIconRunNow = getTriangleIcon(ICON_SIZE, "#b1d0ca", "black", (opacity)?opacity:markerFloodOption.opacity, feature.properties.trend);

            var value = feature.properties.maxvalue;

            //Creo array soglie
            var aThreshold = [];
            if(value != -9999 && value != -7777 && value != -6666 && value != -5555) {

                var asTrhresholds = ["THR1","THR2","THR3","THR4"];

                //Creo array soglie
                for(var prop in feature.properties){
                    if(asTrhresholds.indexOf(prop)>-1){
                        if (feature.properties[prop] != -9999 && feature.properties[prop] != 0 ){
                            var obj = {
                                thresholdValue : feature.properties[prop],
                                name: prop,
                                exceded : (value > feature.properties[prop])?true:false
                            };
                            aThreshold.push(obj)
                        }
                    }
                }

            }



            if (value == -7777 ){
                return sectionIconNoRain;
            }else if(value == -6666 ){
                return sectionIconNoMeteoModel;
            }else if (value == -5555){
                return sectionIconRunNow;
            }else if(value == -9999) {
                return sectionIconUndefined;
            }


            var superati = _.filter(aThreshold, function(obj){
                return obj.exceded
            });


            switch (superati.length) {
                case 0:
                    if(feature.properties.trend> 0) {
                        return sectionIconNoThresholdHigh
                    }
                    return sectionIconNoThresholdLow;
                    break;
                case 1:
                    return sectionIconOrdinaria
                    break;
                case 2:
                    return sectionIconElevata
                    break;
                case 3:
                    return sectionIconMax
                    break;
            }

            // switch(aThreshold.length){
            //     case 0:
            //         return sectionIconNoThresholdLow;
            //         break;
            //     case 1:
            //         (superati.length == 1) ? icon = sectionIconElevata : icon = null;
            //         if (superati.length == 0){
            //             feature.properties.trend > 0?icon = sectionIconNoThresholdHigh:icon = sectionIconNoThresholdLow
            //         }
            //         break;
            //     case 2:
            //         if (superati.length == 1)icon = sectionIconOrdinaria;
            //         if (superati.length == 2)icon = sectionIconElevata;
            //         if (superati.length == 0){
            //             feature.properties.trend > 0?icon = sectionIconNoThresholdHigh:icon = sectionIconNoThresholdLow
            //         }
            //         break;
            //     case 3:
            //         if (superati.length == 1)icon = sectionIconOrdinaria;
            //         if (superati.length == 2)icon = sectionIconElevata;
            //         if (superati.length == 0){
            //             feature.properties.trend > 0?icon = sectionIconNoThresholdHigh:icon = sectionIconNoThresholdLow
            //         }
            //         break;
            //     case 4:
            //         return sectionIconMax
            //         break;
            // }
            // return icon;
        },

        section_fews_po_Icon: function(feature, opacity){


            var thrs_colors = ['white','yellow','orange', 'red'];

            var direction = -1;

            var sectionIconUndefined = getTriangleIcon(ICON_SIZE, "grey", "black", (opacity)?opacity:markerFloodOption.opacity, direction);

            var sectionIconNoThresholdHigh = getTriangleIcon(ICON_SIZE, "white", "black", (opacity)?opacity:markerFloodOption.opacity, direction);

            var sectionIconOrdinaria = getTriangleIcon(ICON_SIZE, "yellow", "black", (opacity)?opacity:markerFloodOption.opacity, direction);

            var sectionIconModerata = getTriangleIcon(ICON_SIZE, "orange", "black", (opacity)?opacity:markerFloodOption.opacity, direction);

            var sectionIconElevata = getTriangleIcon(ICON_SIZE, "red", "black", (opacity)?opacity:markerFloodOption.opacity, direction);



            var value = feature.properties.maxvalue;
            // if(feature.properties.NOME == "Pontelagoscuro"){
            //
            // }

            //Creo array soglie
            var aThreshold = [];
            if(value != -9999 && value != -7777 && value != -6666 && value != -5555) {

                var asTrhresholds = ["THR_LEV_1","THR_LEV_2","THR_LEV_3"];

                //Creo array soglie
                for(var prop in feature.properties){
                    if(asTrhresholds.indexOf(prop)>-1){
                        if (feature.properties[prop] > -9998 && feature.properties[prop] != 0 ){
                            var obj = {
                                thresholdValue : feature.properties[prop],
                                name: prop,
                                severity: parseInt(prop.split('_')[2]),
                                exceded : (value > feature.properties[prop])?true:false
                            };
                            aThreshold.push(obj)
                        }
                    }
                }
            }else {
                return getTriangleIcon(ICON_SIZE, 'grey', "black", (opacity)?opacity:markerFloodOption.opacity, direction)
            }





            var superati = _.filter(aThreshold, function(obj){
                return obj.exceded
            });

            if(superati.length == 0) {
               return  getTriangleIcon(ICON_SIZE, thrs_colors[0], "black", (opacity) ? opacity : markerFloodOption.opacity, direction)
            }else {

                let maxSeverity = _.max(superati, (sup) => sup.severity);
                let color = thrs_colors[maxSeverity.severity];
                return getTriangleIcon(ICON_SIZE, color, "black", (opacity)?opacity:markerFloodOption.opacity, direction)
            }








        },

        comunege_idro:function(feature, opacity){
            var sectionIconUndefined = getTriangleIcon(ICON_SIZE, "grey", "black", (opacity)?opacity:markerFloodOption.opacity);
            var sectionIconNoThresholdLow = getTriangleIcon(ICON_SIZE, "white", "black", (opacity)?opacity:markerFloodOption.opacity);

            if(feature.properties.maxvalue != -9999) return sectionIconNoThresholdLow
            return sectionIconUndefined


        },

        sensor_generic_Icon: function (feature,latlng) {

            var iconFunction = this;

            var sensor_association = {
                2: iconFunction.raingauge_Icon,
                // 3: iconFunction.hydrometer,
                5: iconFunction.thermometer_Icon,
                9: iconFunction.hygrometer_Icon,
                10: iconFunction.wind_Icon,

            };

            var geojsonMarkerOptions = sensor_association[feature.properties.sensorclass](feature);

            return L.circleMarker(latlng, geojsonMarkerOptions);

        },



        getLegend:function(model){


            var oBuilder={
                WARNINGS_PLUVIO : {
                    buildData: function(model){
                        $scope.legendType = 'SENSOR';
                        return model.palette
                    }
                },
                WARNINGS_THERMO : {
                    buildData: function(model){
                        $scope.legendType = 'SENSOR';
                        return model.palette
                    }
                },
                WARNINGS_HYDRO : {
                    buildData: function(model){
                        $scope.legendType = 'SENSOR';
                        return model.model.palette
                    }
                },
                RAINGAUGE : {
                    buildData: function(model){
                        $scope.legendType = 'SENSOR';
                        return model.model.palette
                    }
                },

                THERMOMETER : {
                    buildData: function(model){
                        $scope.legendType = 'SENSOR';
                        return model.model.palette
                    }
                },

                RAINFALL_FIELD : {
                    buildData: function(model){
                        $scope.legendType = 'FROMGEOSERVER';
                        return model.mapLayer()._url + "?request=GetLegendGraphic&format=image/png&WIDTH=12&HEIGHT=12&LAYER=" + model.mapLayer().wmsParams.layers + "&legend_options=fontAntiAliasing:true;fontSize:10";
                    }
                },
                DYNAMIC : {
                    buildData: function(model){
                        $scope.legendType = 'FROMGEOSERVER';
                        return model.mapLayer()._url + "?request=GetLegendGraphic&format=image/png&WIDTH=12&HEIGHT=12&LAYER=" + model.mapLayer().wmsParams.layers + "&legend_options=fontAntiAliasing:true;fontSize:10";
                    }
                },
                STATIC : {
                    buildData: function(model){
                        $scope.legendType = 'FROMGEOSERVER';
                        return model.url + "?request=GetLegendGraphic&format=image/png&WIDTH=12&HEIGHT=12&LAYER=" + model.layers + "&legend_options=fontAntiAliasing:true;fontSize:10";
                    }
                },
                STATIC_RASOR : {
                    buildData: function(model){
                        $scope.legendType = 'FROMGEOSERVER';
                        return model.mapLayer()._url + "?request=GetLegendGraphic&format=image/png&WIDTH=12&HEIGHT=12&LAYER=" + model.mapLayer().wmsParams.layers + "&legend_options=fontAntiAliasing:true;fontSize:10";
                    }
                },
            };
        }

    }
}


