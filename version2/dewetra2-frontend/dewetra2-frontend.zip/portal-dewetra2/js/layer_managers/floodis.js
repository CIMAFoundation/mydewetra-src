/**
 * Created by Dario Rubado on 14/07/16.
 */
function layerManager_floodis(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService){

    var ICON_SIZE = 14;

    var visible=true;

    var authUrl = "https://api-floodis.azurewebsites.net/token";
    var access_token = null;
    var baseUrl = "https://api-floodis.azurewebsites.net/";
    // var baseUrl = "http://floodis.cloudapp.net/FloodisServices/api/Repot/Dewetra?Type=Both&North=90&East=180&South=-90&West=-180&Start=2000-01-08T07:50:22Z&End=2016-12-08T07:50:22Z&Page=0&PageSize=10";

    var from = moment(menuService.getDateFrom()).subtract(100,"days");
    var to = moment(menuService.getDateTo());
    var type ="Both";

    var url ="https://api-floodis.azurewebsites.net/api/Report/Dewetra?Type="+type+"&North=90&East=180&South=-90&West=-180&Start="+from.format('YYYY-MM-DDTHH:mm:ss')+'Z'+"&End="+to.format('YYYY-MM-DDTHH:mm:ss')+'Z'+"&Page=0&PageSize=10"
    // https://api-floodis.azurewebsites.net

    var props = {
        data:{
            dateToFloodis:to,
            dateFromFloodis:from,
            layer:{
                name:"SEGNALATION_FLOODIS",
                descr:"SEGNALATION_FLOODIS_DESCR",
                url:"Report/Dewetra?Type=%T&North=90&East=180&South=-90&West=-180&Start=%D&End=%D",
                date :true,
                type:true,
                typeSelected:{
                    name:"both_name",
                    descr:"both_descr",
                    value:"Both"
                },
                typeAttr:[
                    {
                        name:"both_name",
                        descr:"both_descr",
                        value:"Both"
                    },{
                        name:"pro_name",
                        descr:"pro_descr",
                        value:"pro"
                    },{
                        name:"unpro_name",
                        descr:"unpro_descr",
                        value:"unpro"
                    }
                ]
            }
        },
        attributes:[{
            name:"SEGNALATION_FLOODIS",
            descr:"SEGNALATION_FLOODIS_DESCR",
            url:"Report/Dewetra?Type=%T&North=90&East=180&South=-90&West=-180&Start=%D&End=%D",
            date :true,
            type:true,
            typeSelected:{
                name:"both_name",
                descr:"both_descr",
                value:"Both"
            },
            typeAttr:[
                {
                    name:"both_name",
                    descr:"both_descr",
                    value:"Both"
                },{
                    name:"pro_name",
                    descr:"pro_descr",
                    value:"pro"
                },{
                    name:"unpro_name",
                    descr:"unpro_descr",
                    value:"unpro"
                }
            ]
        },{
            name:"SEGNALATOR_FLOODIS",
            descr:"SEGNALATOR_FLOODIS_DESCR",
            url:"User/Dewetra?Page=1&PageSize=500&North=90&East=180&South=-90&West=-180",
            date :false,
            type: false
        }]
    }


    function update(newProps,newData, onFinish) {
        console.log(newProps)
        props = newProps
        if(newProps.data.layer.type){
            type = newProps.data.layer.typeSelected.value
            from = newProps.data.dateFromFloodis;
            to = newProps.data.dateToFloodis;
            url ="https://api-floodis.azurewebsites.net/api/Report/Dewetra?Type="+type+"&North=90&East=180&South=-90&West=-180&Start="+from.format('YYYY-MM-DDTHH:mm:ss')+'Z'+"&End="+to.format('YYYY-MM-DDTHH:mm:ss')+'Z'+"&Page=0&PageSize=10"
        }else {
            url = "https://api-floodis.azurewebsites.net/api/User/Dewetra?Page=1&PageSize=500&North=90&East=180&South=-90&West=-180"
        }
        setNewLayer(onFinish);
    }

    function setNewLayer(onFinish){
        var obj = {
            grant_type:"password",
            username: "demo01.pro@floodis.eu",
            password:"---"
        }


        apiService.postFloodis(authUrl,obj,
            function(data){
                //console.log(data)
                if(mapLayer) mapService.removeLayer(mapLayer)
                access_token = data.data.access_token
                apiService.getFloodis(url, access_token,function(data){
                        theGeoJson = data.data
                        var geojsonMarkerOptions = {
                            radius: 5,
                            fillColor: '#0000FF',
                            color: '#000',
                            weight: 1,
                            opacity: 1,
                            fillOpacity: 0.8
                        }
                        mapLayer = mapService.addGeoJsonLayer(theGeoJson.features, layer['descr'], {

                            pointToLayer: function(feature, latlng) {
                                return L.marker(latlng, geojsonMarkerOptions);
                            }

                        }, stationClickListener,stationInfoMouseOver, stationInfoMouseOut);

                        if (onFinish) onFinish()
                        console.log(data);

                    },
                    function(data){
                        console.log(data)
                        console.log("error loading floodis feature")
                    })

            },
            function(data){
                console.log(data)
            })
    }

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;

    var markerFloodOption = {
        radius : iconService.markerFloodOptions.radius,
        weight : iconService.markerFloodOptions.weight,
        color : iconService.markerFloodOptions.color,
        opacity : iconService.markerFloodOptions.opacity,
        fillOpacity: iconService.markerFloodOptions.fillOpacity
    };


    //add External Layer End

    function stationInfoMouseOver(s){
        if(infoPopUP){
            infoPopUP.mouseOver('FLOODIS',mapLayer._leaflet_id, s.target.feature.properties  )
        }
    }

    function stationInfoMouseOut(){
        if(infoPopUP){
            infoPopUP.mouseOut('FLOODIS',mapLayer._leaflet_id)
        }
    }

    function stationClickListener(s) {

        if(!angular.isDefined(s.target.feature.properties.id )){
            alert($translate.instant('UNAVAILABLE_DATA'));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/floodis_click_detail.html',
            controller: function($scope, $uibModal, $uibModalInstance,feature){
                $scope.featureProp = feature.properties;
            },
            size: 'lg',
            keyboard: false,
            resolve: {

                feature: function () {

                    return {

                        properties : s.target.feature.properties

                    };

                }

            }
        })

    }






    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        canMovie: function(){
            return false
        },
        
        load: function(onFinish) {



            setNewLayer(onFinish)

            console.log("stop");

        },

        layerTooltip: function(){

            // var manager = mapService.getLayerManager(mapLayer);


            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : this.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : this.typeDescr()
                }

            ];
            return tooltipObj;
        },

        // onDateChange:function(onFinish){
        //
        //     if (mapLayer) mapService.removeLayer(mapLayer);
        //     this.load(onFinish)
        //
        // },

        legend:function () {

        },

        setOpacity : function(value){

            if (value){
                markerFloodOption.opacity = value;
                markerFloodOption.fillOpacity = value
            }
        },

        getOpacity : function(){
            return markerFloodOption.opacity
        },

        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.descr
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        typeDescr: function () {
            return "FLOODIS"
        },

        refreshable : function () {
            return true;
        },

        refresh:function(onFinish){
            if (menuService.isRealTime() ) {
                update(props, props, onFinish)
            }
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi
        },

        setVisible: function (b) {

            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        },

        // update: function(obj, onFinish){
        //     update(obj.props, obj.data, onFinish)
        // },
        
        showProps: function(onFinish) {
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties_floodis.html',
                controller: function ($scope, layerService, mapService, menuService, $uibModalInstance, params, $interval, $translate, _) {

                    // $scope.data ={}
                    // $scope.data.attributes =[]

                    $scope.update = function () {
                        $uibModalInstance.close($scope.data);
                    };
                    $scope.closePopup = function () {
                        $uibModalInstance.dismiss()
                    };

                    $scope.selectFloodis= function(){
                        // $scope.data.layer = opt
                    }
                    $scope.selectTypeAttr = function(){

                    }
                    
                    $scope.onDateFromFloodisSet = function (newDate, oldDate) {
                        $scope.data.data.dateFromFloodis = moment(newDate);
                    }
                    $scope.onDateToFloodisSet = function (newDate, oldDate) {
                        $scope.data.data.dateToFloodis = moment(newDate);
                    }


                    $scope.data = params.props

                    $scope.data.data.layer.typeSelected = params.props.data.layer.typeSelected

                    $scope.data.data.layer = params.props.data.layer

                    console.log("test")


                },
                size: "lg",
                resolve: {
                    params: function() {
                        return {
                            from: from,
                            to: to,
                            type: type,
                            props:props,
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj, obj, onFinish)
            }, function () {
                console.log("CANCEL")
            });
        }

    }

}