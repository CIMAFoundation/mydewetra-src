/**
 * Created by Mirko on 26/02/18.
 */

function encodeData(data) {
    return Object.keys(data).map(function(key) {
        return [key, data[key]].map(encodeURIComponent).join("=");
    }).join("&");
}


function layerManager_dynamic_external_wmst_nasa_old(layerObj, mapService,
                                                     layerService, serieService,
                                                     menuService, $uibModal,
                                                     acEvent, audioService,
                                                     tagService, apiService,
                                                     _, sentinelService,
                                                     $interval, floodproofsService,
                                                     $translate, iconService, $timeout) {

    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService,
        menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,
        $interval, floodproofsService, $translate,iconService, $timeout);
    var $q = angular.injector(["ng"]).get("$q");

    var items = null;
    var visible = true;
    var layer = null;

    manager.date_from = moment(menuService.getDateFrom()).startOf('day');
    manager.date_to = moment(menuService.getDateTo()).startOf('day');

    manager.layerId = layerObj.dataid;

    manager.getWMSParams = function(){
        var WMSParams = {
            service: 'WMS',
            //request: 'GetMap',
            //version: '1.3.0',
            layers: manager.layerId,
            TIME: manager.date_from.format('YYYY-MM-DD') + '/' +  manager.date_to.format('YYYY-MM-DD'),
            //styles: '',
            //format: 'image/png',
            //transparent: true
        };
        return WMSParams;
    }

    manager.hardcodedProperties = function() {
        return true;
    };

    manager.legend = function () {
        var legend_url = layerObj.server.url;
        return {
            type: 'DYNAMIC',
            layers: layerObj.dataid,
            url: legend_url
        }
    };

    function update(newProps, newItem, onFinish, bScrambling) {
        var entry = newProps.layerProperties.attributes[0].selectedEntry;
        manager.setProps(newProps);
        manager.setItem(newItem);

        if (manager.mapLayer()) {
            manager.setlayerOpacity(manager.mapLayer().options.opacity);
            mapService.removeLayer(manager.mapLayer());
        }

        if (manager.layerOpacity()) {
            manager.mapLayer().setOpacity(manager.layerOpacity())
        }
        var time_frame_values = entry.value.split(" ");
        var time_value = Number(time_frame_values[0]);
        var time_unit = time_frame_values[1];
        manager.date_to = newItem.date;
        manager.date_from = moment(newItem.date).subtract(time_value, time_unit);
        manager.setLayerOnMap();
        if (onFinish) onFinish();
    }

    manager.setLayerOnMap = function(){
        var url = layerObj.server.url + '?' + encodeData(manager.getWMSParams());
        manager.setMapLayer(mapService.addWmsLayer(url, manager.layerId));
    }

    manager.load = function(onFinish) {
        manager.setLayerOnMap();
        if (onFinish) onFinish();
    }


    manager.layerProps = {
        "layerProperties": {
            "attributes": [{
                "descr": "Time",
                "name":"time",
                "entries": [{
                    "descr": "last 24h",
                    "value": "1 d",
                    "referredValues": {
                        "entry": []
                    }
                },
                    {
                        "descr": "last 48h",
                        "value": "2 d",
                        "referredValues": {
                            "entry": []
                        }
                    },
                    {
                        "descr": "last 72h",
                        "value": "3 d",
                        "referredValues": {
                            "entry": []
                        }
                    },
                    {
                        "descr": "last week",
                        "value": "7 d",
                        "referredValues": {
                            "entry": []
                        }
                    },
                    {
                        "descr": "last month",
                        "value": "31 d",
                        "referredValues": {
                            "entry": []
                        }
                    }
                ],
                "id": "time",
                "selectedEntry": {
                    "descr": "last 24h",
                    "value": "1 d",
                    "referredValues": {
                        "entry": []
                    }
                },
                "type": "List",
                "visible": "true"
            }],
            "data": manager.layerId,
            "description": layerObj.descr,
            "id": manager.layerId,
            "longDescription": 'Time window'
        }
    }

    manager.setProps(manager.layerProps);

    var items = [];
    manager.getLayerAvailability = function(){
        items = [];
        var to = moment(menuService.getDateTo()).utc().startOf('day');
        var from  = moment(to).subtract(15, 'd');

        for (var dt = moment(from); dt.isBefore(to); dt.add(1, 'days')) {
            var utc_date = dt.clone().utc();
            var item = {
                date: utc_date,
                description: utc_date.toDate().toUTCString(),
                id: utc_date.toDate().valueOf() + ";" + utc_date.toDate().valueOf()
            }
            items.push(item);
        }
    }
    manager.getLayerAvailability();
    manager.setItem(items[items.length-1]);


    manager.onDateChange = function(onFinish){
        if (manager.infoAvaialability) manager.infoAvaialability(items.length, items.length);
        update(manager.props(), items[items.length - 1], onFinish)
    };

    manager.goForward = function() {
        var iIndexLoadedLayer = _.findIndex(items, function (availableItem) {
            return availableItem.id == manager.item().id;
        });

        iIndexLoadedLayer = (iIndexLoadedLayer > -1)? (iIndexLoadedLayer + 1) : 1;

        if (manager.infoAvaialability) manager.infoAvaialability((iIndexLoadedLayer + 1), items.length);

        update(manager.props(), items[iIndexLoadedLayer], function() {
            mapService.oLayerList.updateLayer(manager)
        });
    };

    manager.goBackward = function() {
        var iIndexLoadedLayer = _.findIndex(items, function (availableItem) {
            return availableItem.id == manager.item().id;
        });

        iIndexLoadedLayer = (iIndexLoadedLayer > -1)? iIndexLoadedLayer : 1;
        if (manager.infoAvaialability) manager.infoAvaialability((iIndexLoadedLayer - 1), items.length);
        update(manager.props(), items[iIndexLoadedLayer - 1], function () {
            mapService.oLayerList.updateLayer(manager)
        });
    };

    manager.showProps = function (onFinish) {
        console.log('props');
        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function() {
                    return {
                        layer: manager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {
            console.log('prop_modal',  obj);
            update(obj.props, obj.data, onFinish)
        }, function () {
            console.log("CANCEL")
        });
    };

    manager.setCurrentLayer = function(){
        var item = manager.item();
        console.log(item);
        if(item.date_string) {
            WMSParams['time'] = item.date_string;
        }
        if(layer){
            manager.remove(layer);
        }
        layer = mapService.addSingleTileWmsLayer(layerObj.server.url, WMSParams);
        manager.setMapLayer(layer);
    };

    manager.getLayerAvailability = function() {
        return items;
    };

    manager.setVisible = function(b){
        visible = b;
        if (!visible && layer) {
            layer.setOpacity(0);
        }else{
            layer.setOpacity(1);
        }
    };

    manager.isDraggable = function(){
        return true;
    };

    manager.isVisible = function(){
        return visible;
    };

    manager.parseInfo =function(data){

        console.log(data)

        var ret = {
            layerName: layerObj.name,
            properties : []
        };

        if (data.features && data.features.length > 0) {
            data.features.forEach(function (f) {
                if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                    ret.properties.push({name: 'value', 'value': f.properties.GRAY_INDEX.toFixed(2)})
                } else {
                    for (p in f.properties) {
                        ret.properties.push({name: p, 'value': f.properties[p]})
                    }
                }
            })
        }

        ret.properties.forEach(function (item) {
            if (item.name == 'link'){
                item.html = true;
            }else item.html = false;
        })

        return ret;
    }

    manager.setCanMovie(false);

    return manager;
}


function stationClickListener(s) {

    if(layer.dataid.indexOf('sensorClass')>-1){
        showChart(s.target.feature.properties.sensorid, s.target.feature.properties.dbid);
    }else{
        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        var sensorData = s.target.feature.properties;

        serieService.getSeries(layerData, sensorData, from, to, function (data) {

            showChart(sensorData, data, from, to);

        }, function (data) {

            alert('Error loading data: ' + data.error_message);

        })
    }

}



function layerManager_dynamic_external_wmst_nasa(layerObj, mapService,
                                                     layerService, serieService,
                                                     menuService, $uibModal,
                                                     acEvent, audioService,
                                                     tagService, apiService,
                                                     _, sentinelService,
                                                     $interval, floodproofsService,
                                                     $translate, iconService, $timeout) {

    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService,
        menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,
        $interval, floodproofsService, $translate,iconService, $timeout);
    var $q = angular.injector(["ng"]).get("$q");

    var items = [];
    var visible = true;
    var layer = null;

    manager.timewindow = '24h';
    manager.date_to = moment(menuService.getDateTo()).startOf('day');

    manager.hardcodedProperties = function() {
        return true;
    };

    manager.legend = function () {
        var legend_url = layerObj.server.url;
        return {
            type: 'DYNAMIC',
            layers: layerObj.dataid,
            url: legend_url
        }
    };

    function update(newProps, newItem, onFinish, bScrambling) {
        manager.setProps(newProps);
        manager.setItem(newItem);
        if (manager.mapLayer()) {
            manager.setlayerOpacity(manager.mapLayer().options.opacity);
            mapService.removeLayer(manager.mapLayer());
        }

        if (manager.layerOpacity()) {
            manager.mapLayer().setOpacity(manager.layerOpacity())
        }

        var entry = newProps.layerProperties.attributes[0].selectedEntry;
        manager.timewindow = newProps.layerProperties.attributes[0].selectedEntry.value;
        manager.date_to = newItem.date;
        manager
            .setLayerOnMap()
            .then(onFinish);
    }

    function stationMouseOverListener(s){
        try{
            if(warningInfo){
                // warningInfo.mouseOver(layer.dataid.split(";")[1],mapLayer._leaflet_id, s.target.feature.properties, iconService.sensorClassStylist[layer.dataid.split(";")[1]].palette)
                console.log('station listener', s);
                warningInfo.mouseOver("COAU", manager.mapLayer()._leaflet_id, s.target.feature, null)
            }
        }catch(err){}
    }

    function stationMouseOutListener(s){
        try{
            if(warningInfo){
                warningInfo.mouseOut("COAU", manager.mapLayer()._leaflet_id)
            }
        }catch(err){}
    }

    var warningInfo = null;
    manager.setWarningInfo = function (wi) {
        warningInfo = wi
    };
    manager.getWarningInfo = function () {
        return warningInfo;
    };

    manager.setLayerOnMap = function(){



        var url = layerObj.server.url +
                    manager.date_to.format('YYYY/MM/DD') +  '/' +
                    manager.timewindow + '.geojson';

        return fetch(url)
            .then(function(response){
                if(response.ok) {
                    return response.json();
                }else{
                    throw('Data not found');
                }
            })
            .then(function(data){
                console.log()

                manager.setMapLayer(mapService.addGeoJsonLayerCluster(data.features, manager.layerId, {

                    pointToLayer: function(feature, latlng) {

                        var geojsonMarkerOptions = {

                            radius: 5,
                            fillColor: 'red',
                            color: "#000",
                            weight: 1,
                            opacity: 1.0,
                            fillOpacity: 0.7

                        };

                        return L.circleMarker(latlng, geojsonMarkerOptions);
                    }
                }, null, stationMouseOverListener, stationMouseOutListener
                ));
            })
            .catch(function(error){
                alert(error);
            });
    }

    manager.load = function(onFinish) {
        manager
            .setLayerOnMap()
            .then(onFinish);
    }


    manager.layerProps = {
        "layerProperties": {
            "attributes": [{
                "descr": "Time Window",
                "name":"time",
                "entries": [{
                    "descr": "last 24h",
                    "value": "24h",
                    "referredValues": {
                        "entry": []
                    }
                },
                    {
                        "descr": "last 48h",
                        "value": "48h",
                        "referredValues": {
                            "entry": []
                        }
                    },
                    {
                        "descr": "last week",
                        "value": "7d",
                        "referredValues": {
                            "entry": []
                        }
                    }
                ],
                "id": "time",
                "selectedEntry": {
                    "descr": "last 24h",
                    "value": "24h",
                    "referredValues": {
                        "entry": []
                    }
                },
                "type": "List",
                "visible": "true"
            }],
            "data": manager.layerId,
            "description": layerObj.descr,
            "id": manager.layerId,
            "longDescription": 'Time window'
        }
    }
    manager.setProps(manager.layerProps);

    manager.getLayerAvailability = function(){
        items = [];
        var to = moment(menuService.getDateTo()).utc().startOf('day');
        to.add(1, 'd');
        var from  = moment(to).subtract(15, 'd');

        for (var dt = moment(from); dt.isBefore(to); dt.add(1, 'd')) {
            var utc_date = dt.clone().utc();
            var item = {
                date: utc_date,
                description: utc_date.toDate().toUTCString(),
                id: utc_date.toDate().valueOf() + ";" + utc_date.toDate().valueOf()
            }
            items.push(item);
        }
    }
    manager.getLayerAvailability();
    manager.setItem(items[items.length-1]);


    manager.onDateChange = function(onFinish){
        if (manager.infoAvaialability) manager.infoAvaialability(items.length, items.length);
        update(manager.props(), items[items.length - 1], onFinish)
    };

    manager.goForward = function() {
        var iIndexLoadedLayer = _.findIndex(items, function (availableItem) {
            return availableItem.id == manager.item().id;
        });

        iIndexLoadedLayer = (iIndexLoadedLayer > -1)? (iIndexLoadedLayer + 1) : 1;

        if (manager.infoAvaialability) manager.infoAvaialability((iIndexLoadedLayer + 1), items.length);

        update(manager.props(), items[iIndexLoadedLayer], function() {
            mapService.oLayerList.updateLayer(manager)
        });
    };

    manager.goBackward = function() {
        var iIndexLoadedLayer = _.findIndex(items, function (availableItem) {
            return availableItem.id == manager.item().id;
        });

        iIndexLoadedLayer = (iIndexLoadedLayer > -1)? iIndexLoadedLayer : 1;
        if (manager.infoAvaialability) manager.infoAvaialability((iIndexLoadedLayer - 1), items.length);
        update(manager.props(), items[iIndexLoadedLayer - 1], function () {
            mapService.oLayerList.updateLayer(manager)
        });
    };

    manager.showProps = function (onFinish) {
        console.log('props');
        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function() {
                    return {
                        layer: manager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {
            console.log('prop_modal',  obj);
            update(obj.props, obj.data, onFinish)
        }, function () {
            console.log("CANCEL")
        });
    };

    manager.setCurrentLayer = function(){
        var item = manager.item();
        console.log(item);
        if(item.date_string) {
            WMSParams['time'] = item.date_string;
        }
        if(layer){
            manager.remove(layer);
        }
        layer = mapService.addSingleTileWmsLayer(layerObj.server.url, WMSParams);
        manager.setMapLayer(layer);
    };

    manager.getLayerAvailability = function() {
        return items;
    };

    manager.setVisible = function(b, callback){
        visible = b;
        //Mirko SPIEGAMI!
        if(manager.mapLayer().hasOwnProperty("setOpacity")){
            if (!visible ) {
                layer.setOpacity(0);
            }else{
                layer.setOpacity(1);
            }
        }else{
            if (!visible ) {
                manager.mapLayer().clearLayers()
            }else{
                manager.setLayerOnMap().then(callback)
            }
        }



    };

    manager.isDraggable = function(){
        return true;
    };

    manager.isVisible = function(){
        return visible;
    };

    return manager;
}
