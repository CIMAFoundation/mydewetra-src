  function tool_addExternalWMSLayer (ModelData,  $uibModal, onClose) {

    var layerPropModal = $uibModal.open({
        templateUrl: 'apps/dewetra2/views/add_external_layer.html',
        controller: "extWmsController",
        size: "lg",
        resolve: {
            model: function() {
                return {
                    mapService: null,
                    onClose : onClose
                }
            }
        }
    });

    layerPropModal.result.then(function (obj) {

    });

}
