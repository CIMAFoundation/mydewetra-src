/**
 * Created by Dario Rubado on 15/12/15.
 */

function layerManager_dynamic_async(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent) {

    var layer = layerObj;

    var infoAvaialability= {
        index: 0,
        length : 1,
        reverse : null// per i radar il primo layer disponibile è l'ultimo in ordine di tempo, al contrario dei modelli
    };

    var props = null;
    var item = null;
    var mapLayer = null;

    var bCanMovie = true;

    var refresh = {

        status: false,
        refreshTime : 10000,
        lastRefresh: null

    };

    var iOpacity =100;

    var downloadUrl = null;

    var wsAcquisition = null;

    // Mi registro alla coda di messaggi per l'aggiornamento dei dati
    var updateListener = function() {

        console.log("update Listener");

        acEvent.connect('logger', 'logger4dew', function () {

            console.log("Connecting to rabbit");

            wsAcquisition = acEvent.subscribe('dynamic_async', goToLast);

        },function () {
            console.log('waiting 5 seconds and then reconnect');
            setTimeout(updateListener, 5000)
        })

    };

    function update(newProps, newItem, onFinish) {

        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        layerService.republishLayer(layer, newProps, from, to, newItem, function (data) {
            props = newProps;
            item = newItem;
            if (mapLayer) iOpacity = mapLayer.options.opacity
            if (mapLayer) mapService.removeLayer(mapLayer);
            mapLayer = mapService.addWmsLayer(layer.server.url+'/wms', data.layerid);

            downloadUrl = ((data.layertype && (data.layertype.toUpperCase() == 'VECTOR'))?
                            layer.server.url + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                            layer.server.url + '/ddsData/' + data.layerid + '.tiff');

            if (iOpacity) mapLayer.setOpacity(iOpacity);
            if (onFinish) onFinish()
        })

        console.log(layer.id + " " + data.layerid + " " + status)
    }

    

    function initializeMoveOptions(){

        //setto layer props per averle pronte per la movie
        layerService.getLayerProperties(layer, function (data) {
            props =data;
        });
        //chiedo una volta la disponibilita dei layer per sapere se posso andare avanti o indietro nel tempo

        //chiedo quali layer sono diponibili nella timeline

        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        layerService.getLayerAvailability(layer, props, from, to, function (data) {

            bCanMovie = (data.length > 1);
            if (bCanMovie){
                //cerco l'index del layer caricato precedentemente
                var iIndexLoadedLayer = _.findIndex(data, function (availableItem) {
                    return availableItem.description == item.description;
                });
                //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                iIndexLoadedLayer = (iIndexLoadedLayer > -1) ? iIndexLoadedLayer : 1;

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                infoAvaialability.index = iIndexLoadedLayer;
                infoAvaialability.length = data.length ;
                infoAvaialability.reverse = (moment(data[0].date).unix() > moment(data[1].date).unix());
            }

        })
    }


    function goForward(){
        var oManager = mapService.oLayerList.getManagerByMapLayer(mapLayer);
        //controllo se ci sono gia delle proprieta caricate
        if(props) {
            //carico le date
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //chiedo quali layer sono diponibili nella timeline
            layerService.getLayerAvailability(layer, props, from, to, function (data) {

                //cerco l'index del layer caricato precedentemente
                var iIndexLoadedLayer = _.findIndex(data, function (availableItem) {
                    return availableItem.description == item.description;
                });
                //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                iIndexLoadedLayer = (iIndexLoadedLayer > -1) ? iIndexLoadedLayer : 1;

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                if (oManager.infoAvaialability) {
                    oManager.infoAvaialability(iIndexLoadedLayer + 1, data.length );
                }

                update(props, data[iIndexLoadedLayer + 1], function () {
                    mapService.oLayerList.updateLayer(oManager)
                })
            })
        }

    }

    function goBackward(){

        var oManager = mapService.oLayerList.getManagerByMapLayer(mapLayer);
        //controllo se ci sono gia delle proprieta caricate
        if(props){
            //carico le date
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //chiedo quali layer sono diponibili nella timeline
            layerService.getLayerAvailability(layer, props, from, to, function (data) {

                //cerco l'index del layer caricato precedentemente
                var iIndexLoadedLayer = _.findIndex(data, function(availableItem){
                    return availableItem.description == item.description;
                });
                //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                iIndexLoadedLayer = (iIndexLoadedLayer > -1)? iIndexLoadedLayer: 1;

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                if(oManager.infoAvaialability){
                    oManager.infoAvaialability(iIndexLoadedLayer-1, data.length);
                }

                update(props, data[iIndexLoadedLayer-1],function(){
                    mapService.oLayerList.updateLayer(oManager)
                })
            })

        }
    }

    function goToLast() {

        var oManager = mapService.oLayerList.getManagerByMapLayer(mapLayer);

        console.log("aggiorno");
        //controllo se ci sono gia delle proprieta caricate
        if (menuService.isRealTime() && props) {

            //carico le date
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //chiedo quali layer sono diponibili nella timeline
            layerService.getLayerAvailability(layer, props, from, to, function (data) {

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                if (oManager.infoAvaialability) oManager.infoAvaialability(0, data.length );
                
                update(props, data[0], function () {
                    mapService.oLayerList.updateLayer(oManager)
                })
            })
        }

    }


    return {

        layerObj: function () {
            return layer
        },

        props: function () {
            return props
        },

        item: function () {
            return item
        },

        isAsync: function () {
            return true;
        },
        
        setOpacity:function (int) {
            iOpacity = int;
        },

        getOpacity:function () {
            return iOpacity
        },
        
        wsAquisition: wsAcquisition,

        dateRun: function(){
            var aSplittedDate =  item.id.split(';');
            var dateRun= moment.utc(parseInt(aSplittedDate[0]));
            return dateRun;

        },
        dateRef: function(){
            var aSplittedDate =  item.id.split(';');
            var dateRef = moment.utc(parseInt(aSplittedDate[1]));
            return dateRef;
        },
        dateRefFormatted: function(){
            var sDateRunDateRef =  item.id;

            if(sDateRunDateRef.indexOf(";") > -1){
                //controllo se osservazione o previsione
                var bLayerType = layerObj.category == "observation";
                //se osservazione la data di run corrisponde alla dateref e ne visualizzo solo una
                if(bLayerType){
                    var aDateRunDateRef = sDateRunDateRef.split(";");
                    var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                    //var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm')

                    return sDateRun
                }else{
                    //se previsione distinguo le due date
                    var aDateRunDateRef = sDateRunDateRef.split(";");
                    var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                    var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                    return sDateRef + " "+" (Run:"+ sDateRun+")"
                }
                //se ha solo una data non mi pongo il problema
            }else{


                // Anto 20160908: Se item.id non è una data provo con item.date
                var tsRun = parseInt(sDateRunDateRef);
                if (!isNaN(tsRun)) return moment(new Date(tsRun)).utc().format('DD/MM/YYYY HH:mm');
                else return moment(Date.parse(item.date)).utc().format('DD/MM/YYYY HH:mm');

            }

        },
        dateForecast :function(){
            var aSplittedDate =  item.id.split(';');
            var diff =((parseInt(aSplittedDate[1]))-(parseInt(aSplittedDate[0])));
            if(diff > 0 ) {
                diff = diff / (1000 * 60 * 60);
                return diff;
            }else return 0;
        },

        mapLayer: function () {
            return mapLayer
        },

        load: function(onFinish) {

            if (!menuService.isRealTime() && (wsAcquisition != null)) this.removeListener();

            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            layerService.publishLayer(layer,from,to,function(data){
                props = data.properties;
                item = data.item;

                mapLayer = mapService.addWmsLayer(data.serverurl+'/wms', data.layerid);

                downloadUrl = ((data.layertype && (data.layertype.toUpperCase() == 'VECTOR'))?
                                data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                                data.serverurl + '/ddsData/' + data.layerid + '.tiff');

                //inizializzo le opzioni per la movie
                initializeMoveOptions();
                if (onFinish) onFinish()
            })


            //connetto a messaggistica il layer se non è nel passato
            if (menuService.isRealTime()) updateListener();


        },

        updateListener: updateListener,

        removeListener: function () {
            acEvent.unsubscribe(wsAcquisition);
            wsAcquisition = null;
            console.log("unsubscribe")
        },

        name: function() {
            return layer.name
        },

        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        descr: function () {
            if (!props) return layer.descr;
            return props.layerProperties.description;
        },

        draggable: function () {
            return true;
        },

        haveInfo: function () {
            return true;
        },

        typeDescr: function () {
            return "DYNAMIC"
        },

        haveAudio: function(){
            return false
        },

        canMovie: function(){
            //da cambiare
            return bCanMovie;
        },

        infoAvaialability : function(index, length){
            if(index != null && length != null){
                infoAvaialability.index = index;
                infoAvaialability.length = length
            }else return infoAvaialability
        },

        onDateChange:function(onFinish){

            //precarico anche l'opzione corrente cosi basta cliccare aggiorna per refreshare
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //chiedo layer avaiability dopodiche uso la update

            layerService.getLayerAvailability(layer, props, from, to, function (data) {
                update(props, data[0], onFinish)
            })
        },
        layerTooltip: function(){

            //dividere per osservazioni o previsioni e aggiungere le properties al tooltip


            var layerDelay = function (layerManagerObj) {


                try{
                    var oReferenceDate = layerManagerObj.dateRef().utc().toDate()
                }catch(err){
                    return layerManagerObj.descr()
                }

                // Get Now
                var oDate = new Date();

                //console.log("Now  = " + oDate);
                //console.log("Ref  = " + oReferenceDate);

                // Compute time difference
                var iDifference = oDate.getTime()-oReferenceDate.getTime();

                // How it is in minutes?
                var iMinutes = 1000*60;

                var iDeltaMinutes = Math.round(iDifference/iMinutes);

                var sTimeDelta = "";

                if (iDeltaMinutes>0){
                    if (iDeltaMinutes<60 ) {
                        // Less then 1h
                        sTimeDelta += iDeltaMinutes + " min. fa";
                    }
                    else if (iDeltaMinutes< 60*24) {
                        // Less then 1d
                        var iDeltaHours =  Math.round(iDeltaMinutes/60);
                        sTimeDelta += iDeltaHours + " ore fa";
                    }
                    else {
                        // More than 1d
                        var iDeltaDays =  Math.round(iDeltaMinutes/(60*24));
                        sTimeDelta += iDeltaDays + " giorni fa";
                    }
                }else{
                    if (iDeltaMinutes> -60 ) {
                        // Less then 1h
                        sTimeDelta += "Fra: "+Math.abs(iDeltaMinutes)+" Minuti" ;
                    }
                    else if (iDeltaMinutes > -60*24) {
                        // Less then 1d
                        var iDeltaHours =  Math.round(iDeltaMinutes/60);
                        sTimeDelta += "Fra: "+Math.abs(iDeltaHours)+" Ore" ;
                    }
                    else {
                        // More than 1d
                        var iDeltaDays =  Math.round(iDeltaMinutes/(60*24));
                        sTimeDelta += "Fra: "+Math.abs(iDeltaDays)+" Giorni";
                    }
                }


                return sTimeDelta;
            };
            var oTooltip={ "API 15": [
                {
                    label : "LAYER_NAME",
                    value : this.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : this.descr()
                },
                {
                    label : "DATE_REF",
                    value : this.dateRun().format("DD/MM/YYYY HH:mm")
                }
            ],
                MCM_CUMULATED_RAIN_DESCR : [
                    {
                        label : "LAYER_NAME",
                        value : this.name()
                    },
                    {
                        label : "LAYER_DESCRIPTION",
                        value : this.descr()
                    },
                    {
                        label : "DATE_REF",
                        value : this.dateRef().format("DD/MM/YYYY HH:mm")
                    }
                ],
                RADAR : [
                    {
                        label : "LAYER_NAME",
                        value : this.name()
                    },
                    {
                        label : "LAYER_DESCRIPTION",
                        value : this.descr()
                    },
                    //{
                    //    label : "DATE_RUN",
                    //    value : this.dateRun().format("YYYY/MM/DD HH:mm")
                    //},
                    {
                        label : "DATE_REF",
                        value : this.dateRun().format("DD/MM/YYYY HH:mm")
                    },
                    //{
                    //    label : "DATE_FORECAST",
                    //    value : this.dateForecast()
                    //},
                    //{
                    //    label : "DATE_DELAY",
                    //    value : layerDelay(this)
                    //}
                ],
                DEFAULT:[
                    {
                        label : "LAYER_NAME",
                        value : this.name()
                    },
                    {
                        label : "LAYER_DESCRIPTION",
                        value : this.descr()
                    }
                ],
                FULL : [
                    {
                        label : "LAYER_NAME",
                        value : this.name()
                    },
                    {
                        label : "LAYER_DESCRIPTION",
                        value : this.descr()
                    },
                    {
                        label : "DATE_RUN",
                        value : this.dateRun().format("DD/MM/YYYY HH:mm")
                    },
                    {
                        label : "DATE_REF",
                        value : this.dateRef().format("DD/MM/YYYY HH:mm")
                    },
                    {
                        label : "DATE_FORECAST",
                        value : this.dateForecast()
                    },
                    {
                        label : "DATE_DELAY",
                        value : layerDelay(this)
                    }]
            };
            //se un radar ritorno tooltip radar
            if((this.name().indexOf('RADAR'))> -1) return oTooltip['RADAR'];

            //altrimenti se cè un tooltip pre preparato carico quello
            if (oTooltip[layer.descr]) return oTooltip[layer.descr];
            //altrimenti tooltip di default
            return oTooltip['DEFAULT'];
        },

        refreshable : function () {
            return refresh.status;
        },

        refreshProperty: function(){
            return refresh
        },

        lastRefresh : function(){
            return refresh.lastRefresh
        },

        setLastRefresh: function(time){
            refresh.lastRefresh  = time
        },

        setRefresh: function (isRefreshable) {
            refresh.status = isRefreshable;
        },

        //refresh: function(onFinish){
        //
        //    var from = menuService.getDateFromUTCSecond();
        //    var to = menuService.getDateToUTCSecond();
        //
        //    //se è nascosto o ha opacita < 100 devo ricaricarlo cosi
        //    var iOpacity = mapLayer.options.opacity;
        //
        //    layerService.republishLayer(layer, props, from, to, item, function (data, status) {
        //
        //        if (data.layerid && data.layerid.length >0 ) {
        //            if (mapLayer) mapService.removeLayer(mapLayer);
        //            mapLayer = mapService.addWmsLayer(layer.server.url + '/wms', data.layerid);
        //            //setto l'opcita del layer prima del caricamento
        //            mapLayer.setOpacity(iOpacity);
        //            if (onFinish) onFinish(mapLayer._leaflet_id)
        //        }
        //        console.log(layer.id + " " + data.layerid + " " + status)
        //    })
        //},

        refresh:function(onFinish){

            if (menuService.isRealTime() ) {
                update(props, item, onFinish)
            }
        },

        showProps: function (onFinish) {
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties.html',
                controller: "layerPropertiesController",
                size: "lg",
                resolve: {
                    params: function() {
                        return {
                            layer: mapLayer
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj.props, obj.data, onFinish)
            }, function () {
                console.log("CANCEL")
            });
        },

        getDownloadUrl: function () {
            return downloadUrl
        },
        update: function(obj, onFinish){
            update(obj.props, obj.data, onFinish)
        },
        goForward : goForward,
        goBackward : goBackward
    }

}
