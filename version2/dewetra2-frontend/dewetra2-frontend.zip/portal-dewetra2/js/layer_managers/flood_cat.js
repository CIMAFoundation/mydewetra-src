/**
 * Created by Dario Rubado on 12/07/17.
 */
function layerManager_flood_cat(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService, floodCatService) {

    var ICON_SIZE = 14;
    var visible=true;

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;
    var indicatorsMax = {};

    var backgroundLayer = null;

    var rasorFeatureStyle = {
        weight : 1,
        opacity : 1,
        fillOpacity: 0.6
    }

    var aPalette = iconService.rasorDamagePalette;

    var lastRasorUrl;

    function getRandomColor() {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    var eventsColor=[];

    var props = {

        scenario:{
            name:"TIME_RANGE",
            descr:"TIME_RANGE_DESCR",
            date :false,
            type:"select",
            typeSelected:{
                name:"dw2_range",
                descr:"dw2_range_descr",
                value:"dw2_range"
            },
            typeAttr:[
                {
                    name:"dw2_range",
                    descr:"dw2_range_descr",
                    value:"dw2_range"
                },
                {
                    name:"last_mounth",
                    descr:"last_mounth_descr",
                    value:"30"
                },{
                    name:"last_3_mounth",
                    descr:"last_3_mounth_descr",
                    value:"90"
                },{
                    name:"last_year",
                    descr:"last_year_descr",
                    value:"365"
                }
            ]
        }

        // attributes:{
        //     name:"RASOR_DAMAGE",
        //     descr:"RASOR_DAMAGE_DESCR",
        //     date :false,
        //     type:"select",
        //     typeSelected:{
        //         name:"population_day",
        //         descr:"population_day_descr",
        //         value:["27","28","29","56"]
        //     },
        //     typeAttr:[
        //         {
        //             name:"off",
        //             descr:"off_descr",
        //             value:false
        //         },{
        //             name:"structure_damage",
        //             descr:"structure_damage_descr",
        //             value:["1"]
        //         },{
        //             name:"content_damage",
        //             descr:"content_damage_descr",
        //             value:["2"]
        //         },
        //         // {
        //         //     name:"car_damage",
        //         //     descr:"car_damage_descr",
        //         //     value:["3"]
        //         // },
        //         {
        //             name:"economic_damage_struttura",
        //             descr:"economic_damage_struttura_descr",
        //             value:["7"]
        //         },{
        //             name:"economic_damage_contenuto",
        //             descr:"economic_damage_contenuto_descr",
        //             value:["8"]
        //         },
        //         // {
        //         //     name:"economic_damage_auto",
        //         //     descr:"economic_damage_auto_descr",
        //         //     value:["9"]
        //         // },
        //         {
        //             name:"economic_damage",
        //             descr:"economic_damage_descr",
        //             value:["7","8","9"]
        //         }, {
        //             name:"population_day",
        //             descr:"population_day_descr",
        //             value:["27","28","29","56"]
        //         },{
        //             name:"population_low_day",
        //             descr:"population_low_day_descr",
        //             value:["27"]
        //         },{
        //             name:"population_medium_day",
        //             descr:"population_medium_day_descr",
        //             value:["28"]
        //         },{
        //             name:"population_high_day",
        //             descr:"population_high_day_descr",
        //             value:["29"]
        //         },{
        //             name:"population_very_high_day",
        //             descr:"population_very_high_day_descr",
        //             value:["56"]
        //         },
        //         {
        //             name:"population",
        //             descr:"population_descr",
        //             value:["58","59","60","61"]
        //         },
        //
        //         {
        //             name:"population_low_night",
        //             descr:"population_low_night_descr",
        //             value:["59"]
        //         },
        //         {
        //             name:"population_medium_night",
        //             descr:"population_medium_night_descr",
        //             value:["58"]
        //         },
        //         {
        //             name:"population_high_night",
        //             descr:"population_high_night_descr",
        //             value:["60"]
        //         },
        //         {
        //             name:"population_very_high_night",
        //             descr:"population_very_high_night_descr",
        //             value:["61"]
        //         }
        //     ]
        // },
        // backgroundLayer:{
        //
        //     name:"background_layer",
        //     descr:"background_layer_descr",
        //     date :false,
        //     type:"boolean",
        //     typeSelected:{
        //         name:"background_layer_water_depth",
        //         descr:"background_layer_water_depth_descr",
        //         value:""
        //     },
        //     typeAttr:[
        //         {
        //             name:"background_layer_off",
        //             descr:"background_layer_off_descr",
        //             value:false
        //         },{
        //             name:"background_layer_water_depth",
        //             descr:"background_layer_water_depth_descr",
        //             value:""
        //         },{
        //             name:"background_layer_hazard_zone",
        //             descr:"background_layer_hazard_zone_descr",
        //             value:"RASOR_hazard_zones_band2"
        //         }
        //     ]
        // },
        // hideFeature:{
        //
        //     name:"background_layer",
        //     descr:"background_layer_descr",
        //     date :false,
        //     type:"boolean",
        //     typeSelected:{
        //         name:"view_feature",
        //         descr:"view_feature_descr",
        //         value:true
        //     },
        //     typeAttr:[
        //         {
        //             name:"view_feature",
        //             descr:"view_feature_descr",
        //             value:true
        //         },{
        //             name:"hide_feature",
        //             descr:"hide_feature_descr",
        //             value:false
        //         }
        //     ]
        // }


    }








    function stationClickListener(s) {

        //s.target.feature.properties.floodEventCode
    //apps/floodcat/index.html?skin=3&ide=test_id
        window.open("apps/floodcat/index.html?skin=3&ide="+s.target.feature.properties.floodEventCode)



    }



    function InfoMouseOver(s) {
        if (infoPopUP){
            infoPopUP.mouseOver('FLOOD_CAT', mapLayer._leaflet_id, s.target.feature)
        }
    }

    function InfoMouseOut() {
        if (infoPopUP){
            infoPopUP.mouseOut('FLOOD_CAT', mapLayer._leaflet_id)
        }
    }


    function update(newProps, onFinish){

            // if(angular.isUndefined(props.scenario)){
            //     props.scenario = {};
            //     props.scenario.typeSelected = {};
            //     props.scenario.typeSelected.value = "";
            //
            //     newProps.scenario = {};
            //     newProps.scenario.typeSelected = {};
            //     newProps.scenario.typeSelected.value ="";
            //
            // }

            if (props.scenario.typeSelected.value != newProps.scenario.typeSelected.value){

                props = newProps;
                var manager = mapService.oLayerList.getManagerByMapLayer(mapLayer)
                manager.load(onFinish);

            }

    }


    setBackgroundLayer = function () {

        if (backgroundLayer) mapService.removeHardCodedWmsLayer(backgroundLayer);
        var styles =  null;

        //if(props.attributes.typeSelected.name == "population") styles="RASOR_hazard_zones_band2";
        switch (props.backgroundLayer.typeSelected.value){
            case false:
                break;
            case "":
                backgroundLayer = mapService.addHardCodedWmsLayer(lastRasorUrl.scenarioServer,lastRasorUrl.scenarioLayer, null,styles);
                break;
            case "RASOR_hazard_zones_band2":
                styles="RASOR_hazard_zones_band2";
                backgroundLayer = mapService.addHardCodedWmsLayer(lastRasorUrl.scenarioServer,lastRasorUrl.scenarioLayer, null,styles);
        }

        // if(props.backgroundLayer.typeSelected.value) backgroundLayer = mapService.addHardCodedWmsLayer(lastRasorUrl.scenarioServer,lastRasorUrl.scenarioLayer, null,styles);
    }



    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        setMapLayer: function (l) {
            mapLayer = l;
        },

        load: function(onFinish){

            if(props.scenario.typeSelected.value == "dw2_range"){
                var obj={
                    startDate:menuService.getDateFrom(),
                    endDate:menuService.getDateTo()
                }
            }else {
                 // = menuService.getDateFrom()
                var date = new Date(new Date().setDate(menuService.getDateFrom().getDate()-parseInt(props.scenario.typeSelected.value)))
                var obj={
                    startDate:date,
                    endDate:menuService.getDateTo()
                }
            }

            if(mapLayer) mapService.removeLayer(mapLayer);

            floodCatService.getFloodCatEvents(obj,function(data){

                theGeoJson = floodCatService.transformToGeoJson(data);

                theGeoJson.features.forEach(function (feature) {
                    if(!eventsColor[feature.properties.uniCode]) eventsColor[feature.properties.uniCode] = getRandomColor();
                })

                mapLayer = mapService.addGeoJsonLayer(theGeoJson, layer['descr'], {
                    onEachFeature:function (feature, layer) {
                        console.log(feature)
                        return L.polygon(feature)
                    },
                    style:function (geoJsonFeature) {
                        return{
                            fillColor: eventsColor[geoJsonFeature.properties.uniCode],
                            color : eventsColor[geoJsonFeature.properties.uniCode],
                            opacity : 1,
                            fillOpacity: 0.3,
                            weight: 1,

                        }
                    },
                    pointToLayer: function(feature,latlng) {
                        var geojsonMarkerOptions = {
                            radius: 5,
                            fillColor: eventsColor[feature.properties.uniCode],
                            color: eventsColor[feature.properties.uniCode],
                            weight: 5,
                            opacity: 1,
                            fillOpacity: 1
                        };

                        return L.circleMarker(latlng, geojsonMarkerOptions);

                        // /console.log("MARKER");
                        //return L.marker(latlng);

                    }
                }, stationClickListener, InfoMouseOver, InfoMouseOut);


                if (onFinish) onFinish()
            }, function (err) {
                console.log(err);
            })


        },

        disablePros:function () {
            delete props.scenario;
        },

        layerTooltip: function(){

            var manager = this;



            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : manager.name()
                },
                // {
                //     label : "VARIABLE_DESCRIPTION",
                //     value : props.attributes.typeSelected.name
                // },
                // {
                //     label : "SCENARIO_DESCRIPTION",
                //     value : props.scenario.typeSelected.name
                // }

            ];
            return tooltipObj;
        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        setOpacity : function(value){

            if (value){
                rasorFeatureStyle.opacity = value;
                rasorFeatureStyle.fillOpacity = value;
                //updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return rasorFeatureStyle.opacity
        },


        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (backgroundLayer) mapService.removeHardCodedWmsLayer(backgroundLayer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.descr
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        typeDescr: function () {
            return props.scenario.typeSelected.descr;
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi;
        },

        getWarningInfo:function () {
            return infoPopUP;
        },

        showProps : function (onFinish) {
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties_rasor_damage.html',
                controller: function ($scope, $uibModalInstance, params){

                    $scope.data = angular.copy(params.props);

                    $scope.update = function () {

                        $uibModalInstance.close($scope.data);
                    };
                    $scope.closePopup = function () {
                        $uibModalInstance.dismiss()
                    }
                },
                size: "lg",

                resolve: {
                    params: function() {
                        return {
                            layer: mapLayer,
                            props:props
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj, onFinish)

            }, function () {
                console.log("CANCEL")
            });
        },

        legend:function () {

            var styles =  "";
            if(props.backgroundLayer.typeSelected.value == "RASOR_hazard_zones_band2") {

                styles="&STYLE=RASOR_hazard_zones_band2";
            }

            var legend = {

                type:"ADVANCED",
                legend:[{
                    type:"CUSTOM",
                    title: "IMPACT_LAYER_PALETTE",
                    palette:[{
                        label:"VERY_LOW",
                        color:"#FFFFFF",
                        sign:"<",
                        value:250000,
                        mu:"€",
                        dec:0
                    },{
                        label:"LOW",
                        color:"#FFFF00",
                        sign:"<",
                        value:500000,
                        mu:"€",
                        dec:0
                    },{
                        label:"MODERATE",
                        color:"#FA8B3C",
                        sign:"<",
                        value:1000000,
                        mu:"€",
                        dec:0
                    },{
                        label:"HIGH",
                        color:"#FF0000",
                        sign:"<",
                        value:1500000,
                        mu:"€",
                        dec:0
                    },{
                        label:"VERY HIGH",
                        color:"#C13BDB",
                        sign:"<",
                        value:2000000,
                        mu:"€",
                        dec:0
                    }]
                },{
                    type:"IMAGE",
                    title: "IMPACT_LAYER_BACKGROUND_PALETTE",
                    img:lastRasorUrl.scenarioServer + "?request=GetLegendGraphic&format=image/png&WIDTH=12&HEIGHT=12&LAYER=" + lastRasorUrl.scenarioLayer + styles+"&legend_options=fontAntiAliasing:true;fontSize:10"
                }]
            };

            if(props.attributes.typeSelected.name.indexOf("population")>-1) {

                styles="&STYLE=RASOR_hazard_zones_band2";

                legend.legend[0].palette = [{
                    label:"",
                    color:"#FFFFFF",
                    value:"-",
                    mu:"0",
                    dec:0
                },{
                    label:"LOW",
                    color:"#FFFF00",
                    value:"-",
                    mu:"1-40",
                    dec:0
                },{
                    label:"MODERATE",
                    color:"#FA8B3C",
                    value:"-",
                    mu:"40-80",
                    dec:0
                },{
                    label:"HIGH",
                    color:"#FF0000",
                    value:"-",
                    mu:"80-130",
                    dec:0
                },{
                    label:"VERY HIGH",
                    color:"#C13BDB",
                    value:"-",
                    mu:"> 130",
                    dec:0
                }]
            }



            return legend;
        },

        setVisible: function (b) {
            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        }

    }

}