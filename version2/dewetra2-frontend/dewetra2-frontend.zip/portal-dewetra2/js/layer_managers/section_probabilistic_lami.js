/**
 * Created by Dario Rubado on 19/06/15.
 */

function layerManager_section_probabilistic_lami(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService) {

    var ICON_SIZE = 14;
    var visible=true;

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;

    var dateRun = null;

    let additionalLayers = [];

    var markerFloodOption = {
        radius : menuService.markerFloodOptions.radius,
        weight : menuService.markerFloodOptions.weight,
        color : menuService.markerFloodOptions.color,
        opacity : menuService.markerFloodOptions.opacity,
        fillOpacity: menuService.markerFloodOptions.fillOpacity
    };
    //add External Layer

    function AddBackgroundLayer() {
        var layerToAdd = 49;
        apiService.get("settings/layers/?id="+layerToAdd,function(obj){

            var AlreadyLoaded = false;
            var dataId =obj.objects[0].dataid;

            var o = mapService.getLayerTest();
            if (o.draggable){
                o.draggable.forEach(function (data) {
                    if (data.wmsParams.layers == dataId){
                        AlreadyLoaded = true;
                    }
                })
            }

            //
            function buildLayerManager(layer) {
                var mangerName = 'layerManager_' + layer['type'].code;
                var manager = window[mangerName](layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService);

                return manager;
            }
            if (AlreadyLoaded){
                console.log("Gia Caritcato")
            }else{
                var PlusManager = buildLayerManager(obj.objects[0]);
                PlusManager.load(function () {
                    mapService.setlayerManager(PlusManager.mapLayer(), PlusManager);
                    mapService.oLayerList.addLayer(PlusManager)
                });
            }

        });
    }

    //add External Layer End



    function stationInfoMouseOver(s){
        if(infoPopUP){
            console.log(s.target.feature.properties);
            infoPopUP.mouseOver('FloodProofsProbabilistic',mapLayer._leaflet_id, s.target.feature.properties , iconService.section_gauge_observation_Icon(s.target.feature))
        }
    }

    function stationInfoMouseOut(){
        if(infoPopUP){
            infoPopUP.mouseOut('FloodProofsProbabilistic',mapLayer._leaflet_id)
        }
    }




    function stationClickListener(s) {

        if(s.target.feature.properties.maxvalue <=-9998){
            alert($translate.instant('UNAVAILABLE_DATA'));
            return; //da scommentare dopo test
        }

        if(s.target.feature.properties.maxvalue == '-7777'||s.target.feature.properties.maxvalue == '-6666'||s.target.feature.properties.maxvalue == '-5555'){
            alert($translate.instant(s.target.feature.properties.maxvalue));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/hydrogram_chart_form.html',
            controller: 'hydrogramChartController',
            size: 'lg',
            keyboard: false,
            resolve: {
                sectionData: function () {
                    return {
                        section : s.target.feature.properties,
                        prop : layerData.prop,
                        serverId: layerObj.server.id
                    };
                }
            }
        })
    }

    function updateFeatureStyle () {

        for(var layerId in mapLayer._layers){
           mapLayer._layers[layerId].setIcon(iconService.section_gauge_observation_Icon(mapLayer._layers[layerId].feature, markerFloodOption.opacity))
        }

    }




    const oManager = {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        setMapLayer: function (l) {
          mapLayer = l;
        },

        // setProps:function (props) {
        //
        // },

        load: function(onFinish) {


            serieService.getLayerData(layer, function (ld) {

                layerData = ld;

                floodproofsService.layer(layer.server.id,layerData.layer.dataid, function (data) {

                    theGeoJson = data;


                    var dateToCheck = null;

                    if(theGeoJson.features){
                        theGeoJson.features.forEach(function (feature) {

                            if(feature.properties.run != ""){
                                dateToCheck = moment(feature.properties.run,"YYYYMMDDHHmm");

                                if(dateRun!= null){
                                    if(dateToCheck.isAfter(dateRun)){
                                        dateRun = dateToCheck;
                                    }
                                }else{
                                    dateRun = dateToCheck;
                                }
                            }
                        })
                    }


                    mapLayer = mapService.addGeoJsonLayer(theGeoJson, layer['descr'], {

                        pointToLayer: function(feature, latlng) {

                            if(layer.dataid.indexOf("dams")>-1)feature.properties.sWarningInfoMeasureUnit = "m<sup>3</sup>";

                            if(layer.dataid == "comunege.idro.probabilisticlami") return L.marker(latlng, {icon:iconService.comunege_idro(feature)});

                            return L.marker(latlng, {icon:iconService.section_gauge_observation_Icon(feature)});
                        }

                    }, stationClickListener, stationInfoMouseOver, stationInfoMouseOut);

                    // if(layer.dataid != "comunege.idro.probabilisticlami")  AddBackgroundLayer();
                    oManager.loadAdditionalLayer();

                    if (onFinish) onFinish()

                }, function(data) {

                    alert('Error loading layer: ' + data.error_message);

                })

            });

        },

        layerTooltip: function(){

            var manager = this;



            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : manager.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : manager.typeDescr()
                }

            ];
            return tooltipObj;
        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        setOpacity : function(value){

            if (value){
                markerFloodOption.opacity = value;
                markerFloodOption.fillOpacity = value;
                updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return markerFloodOption.opacity
        },


        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            oManager.removeAdditionalLayer();
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.name
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        typeDescr: function () {
            return "SECTION_LAMI_PROBABILISTIC"
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi;
        },

        getWarningInfo:function () {
          return infoPopUP;
        },

        setVisible: function (b) {
            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        },

        dateLine:function(){
            //return layerObj.descr;
            if(dateRun)return dateRun.format('DD/MM/YYYY HH:mm')
        },
        customprops : function(){

            try {
                if(layerObj.hasOwnProperty("customprops")){
                    return JSON.parse(layerObj.customprops);
                }
            }catch (e) {
                console.log(e);
            }
        },

        removeAdditionalLayer : () => {
            additionalLayers.map(mapLayer => {
                mapService.getMap().removeLayer(mapLayer);
            });
        },

        loadAdditionalLayer : () => {

            try {
                if (oManager.customprops() && oManager.customprops().hasOwnProperty('additional_layers')) {

                    oManager.customprops().additional_layers.layerlist.map((layer)=>{
                        additionalLayers.push(mapService.addWmsLayer(layer.url, layer.dataid));
                    });
                }
            }catch (e) {
                console.log(e);
            }
        },

        thirdLine:function(){
            return true


        },

        getVariable :function(){

            return ""

        },

        getAggregation :function(){

            return""


        }
    }

    return oManager;

}


function layerManager_phenological_analysis2(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope) {

    var manager = layerManager_section_probabilistic_lami(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope)

    var url = "http://130.251.104.198/geoserver/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=italy_genoa_di_flo_bui_imprex4";

    var dateNow = moment(new Date());

    var year = parseInt(dateNow.format('YYYY'))-1;

    var latest_year = 2006;

    var props = {

        analysis:{
            name:"ANALYSIS",
            descr:"ANALYSIS_DESCR",
            date :false,
            type:true,
            typeSelected:{
                name: "phenological_phase_name",
                descr:"phenological_phase_descr",
                value:"phenological_phase"
            },
            typeAttr:[
                {
                    name: "phenological_phase_name",
                    descr:"phenological_phase_descr",
                    value:"phenological_phase"
                },{
                    name: "erbacee_phase_name",
                    descr:"erbacee_phase_descr",
                    value:"erbacee_phase"
                },{
                    name:"cfr_year_name",
                    descr:"cfr_year_descr",
                    value:"cfr_year"
                }
            ]
        },

        year:{
            name:"REFERENCE_YEAR",
            descr:"REFERENCE_YEAR_DESCR",
            date :false,
            type:true,
            typeSelected:{
                name:"REFERENCE_YEAR",
                descr:"REFERENCE_YEAR_descr",
                value:year
            },
            typeAttr:[]
        }
    }

    for(var i = year;year<= latest_year; i--){
        props.year.typeAttr.push({
            name:"REFERENCE_"+year.toString()+"_YEAR",
            descr:"REFERENCE_"+year.toString()+"_YEAR_descr",
            value:year
        });
    }

    props.year.typeSelected = props.year.typeAttr[0];


    manager.typeDescr = function () {
        return props.attributes.typeSelected.descr;
    };


    function InfoMouseOver(s) {
        if (manager.getWarningInfo){
            manager.getWarningInfo().mouseOver('rasor_damage', mapLayer._leaflet_id, s.target.feature)
        }
    }

    function InfoMouseOut() {
        if (manager.getWarningInfo){
            manager.getWarningInfo().mouseOver('rasor_damage', mapLayer._leaflet_id)
        }
    }

    manager.props = props;
    manager.contourPalette = iconService.rasorDamagePalette;

    var mapLayer;

    var theGeoJson;

    var indicatorsMax = {};



    function calculateIndicatorsMax(geoJson) {

        geoJson.features.forEach(function(feature) {
            for (var name in feature.properties) {
                if (name.indexOf('indicator_') === 0) {
                    var iid = name.substring(10)
                    if (iid in indicatorsMax) {
                        indicatorsMax[iid] = Math.max(indicatorsMax[iid], feature.properties[name])
                    } else {
                        indicatorsMax[iid] = feature.properties[name]
                    }
                }
            }
        });
    }

    function build_palette(geoJson) {

        geoJson.features.forEach(function (feature) {

            feature.properties.contourColor = iconService.rasorDamagePalette[iconService.rasor_damage_Palette_Contour(feature)];

            manager.props.attributes.typeAttr.forEach(function (attr) {

                var value = 0;
                var iMax = 0;

                attr.value.forEach(function (id) {

                    if(angular.isUndefined(indicatorsMax[id]))indicatorsMax[id] = 0;

                    if(feature.properties.hasOwnProperty("indicator_"+id)){
                        //sommo i valori degli indicatori da sommare
                        value +=  feature.properties["indicator_"+id];
                        //sommo i valori degli indicatori massimi da sommare
                        iMax += indicatorsMax[id]
                    }
                })

                feature.properties[attr.name+"_value"] = value;

                var valuePercent = (value/iMax)*100;

                var fillColor ="darkgray";

                if (attr.name.indexOf('population') >= 0|| attr.name.indexOf('economic') >= 0){

                    if (valuePercent < 10) {

                        var component = 255-Math.ceil(valuePercent * 12.75)
                        fillColor = 'rgb(255, 255, ' + component + ')'

                    } else if (valuePercent < 30) {

                        var component = 255-Math.ceil(valuePercent * 8.5)
                        fillColor = 'rgb(255,' + component + ', 0)'

                    } else {

                        var component = Math.ceil(valuePercent * 2.55)
                        fillColor = 'rgb(255, 0, ' + component + ')'
                    }

                } else {

                    if (value < 10) {
                        var component = 255-Math.ceil(value * 12.75)
                        fillColor = 'rgb(255, 255, ' + component + ')'

                    } else if (value < 30) {

                        var component = 255-Math.ceil(value * 8.5)
                        fillColor = 'rgb(255,' + component + ', 0)'

                    } else {

                        var component = Math.ceil(value * 2.55)
                        fillColor = 'rgb(255, 0, ' + component + ')'
                    }

                }
                feature.properties[attr.name+"_color"] = fillColor
            })

        })
        return geoJson;

    }




    manager.load = function(onFinish){
        apiService.getExt(url,function (data) {

            var selectedIndicator = manager.props.attributes.typeSelected;

            //indicatorsMax =
            calculateIndicatorsMax(data);
            console.log(indicatorsMax);

            theGeoJson = build_palette(data);


            mapLayer = mapService.addGeoJsonLayer(theGeoJson.features, manager.typeDescr(), {

                style: function (feature) {

                    feature.fillColor = feature.properties[selectedIndicator.name+"_color"]

                    return {
                        color: feature.properties.contourColor,
                        weight: 1,
                        opacity: 1,
                        fillColor: feature.fillColor,
                        fillOpacity: 0.6
                    }
                }


            }, null, InfoMouseOver, InfoMouseOut);

            manager.setMapLayer(mapLayer);

            if (onFinish) onFinish()

        },function () {
            alert("error loading url")
        })
    }

    // function indicatorValue(feature ) {
    //     var selectedIndicator = manager.props.attributes.typeSelected;
    //
    //     var value = 0;
    //
    //     selectedIndicator.value.forEach(function (indicatorId) {
    //         if(feature.properties.hasOwnProperty("indicator_"+indicatorId)){
    //             value += feature.properties["indicator_"+indicatorId];
    //         }
    //     });
    //
    //     return value;
    // }

    function update(props, onFinish){

        if (manager.props.scenario.typeSelected.value != props.scenario.typeSelected.value){

            apiService.post("")

        }

        manager.props = props;

        var selectedIndicator = manager.props.attributes.typeSelected;

        for  (var id in mapLayer._layers){

            var layer = mapLayer._layers[id];

            layer.feature.properties.fillColor = layer.feature.properties[selectedIndicator.name+"_color"];

            layer.setStyle({
                color: layer.feature.properties.contourColor,
                "weight": 1,
                opacity: 1,
                fillColor: layer.feature.properties.fillColor,
                fillOpacity: 0.6
            })
        }
        if(onFinish)onFinish();
    }

    manager.showProps = function (onFinish) {
        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties_rasor_damage.html',
            controller: ['$scope', '$uibModalInstance', 'params' ,function ($scope, $uibModalInstance, params){

                $scope.data = params.props;

                $scope.update = function () {

                    $uibModalInstance.close($scope.data);
                };
                $scope.closePopup = function () {
                    $uibModalInstance.dismiss()
                }
            }],
            size: "lg",

            resolve: {
                params: function() {
                    return {
                        layer: mapLayer,
                        props:props
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {
            update(obj, onFinish)

        }, function () {
            console.log("CANCEL")
        });
    }

    return manager;
}
