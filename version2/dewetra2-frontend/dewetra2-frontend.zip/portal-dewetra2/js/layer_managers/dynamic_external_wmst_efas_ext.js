/**
 * Created by Anto on 20/09/16.
 */

function layerManager_dynamic_external_wmst_efas_ext(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout) {

    var dates = [];

    function wait(ms) {
        var d = new Date();
        var d2 = null;
        do { d2 = new Date(); }
        while(d2-d < ms);
    }

    function getLayerAvailability() {

        var offset = 12 * 3600000;

        var from = menuService.getDateFrom().setUTCMinutes(0,0,0) - offset;
        var to = menuService.getDateTo().setUTCMinutes(0,0,0) - offset;

        var layerURL, dt, utc_date, tmp_dates = [];

        var params = {
            service: 'WMS',
            request: 'GetMap',
            version: '1.3.0',
            layers: manager.layerId,
            styles: '',
            format: 'image/png',
            transparent: true,
            crs: 'epsg:3857',
            bbox: '-978393.962050256,4767224.580089872,3717897.055790973,5694252.859132491',
            width: '960',
            height: '190'
        };

        dates.splice(0, dates.length);

        //NEW
        //// Preparo il set di date valide
        //for (var t = from; t < to; t += 3600000) {
        //
        //    dt = new Date(t);
        //
        //    if ((dt.getUTCHours() == 0) || (dt.getUTCHours() == 12)) {
        //
        //        tmp_dates.push(moment(dt).utc());
        //
        //    }
        //
        //}
        //
        //var count = 0;
        //
        //while (count < tmp_dates.length) {
        //
        //    if (utc_date != tmp_dates[count]) {
        //
        //        utc_date = tmp_dates[count];
        //
        //        layerURL = (layerObj.server.url + '?TIME=' + utc_date.format('YYYY-MM-DDT') + utc_date.format('HH') + ':00:00');
        //
        //        layerURL = layerURL + L.Util.getParamString(params, layerURL, true);
        //
        //        apiService.getExt(layerURL, function(data) {
        //
        //                if (typeof data === 'string') {
        //
        //                    if (data.indexOf('ServiceException') < 0) {
        //                        dates.push({
        //                            "date": utc_date,
        //                            "description": dt.toUTCString(),
        //                            "id": utc_date.valueOf() + ";" + utc_date.valueOf()
        //                        });
        //                    }
        //
        //                }
        //
        //                count++;
        //
        //            },
        //            function (err) {
        //
        //                count++;
        //                console.log("Error Loading layer: " + err)
        //
        //            });
        //
        //    }
        //
        //}


        //ORG!!!
        for (var t = from; t < to; t += 3600000) {

            dt = new Date(t);

            if ((dt.getUTCHours() == 0) || (dt.getUTCHours() == 12)) {

                utc_date = moment(dt).utc();

                layerURL = (layerObj.server.url + '?TIME=' + utc_date.format('YYYY-MM-DDT') + utc_date.format('HH') + ':00:00');

                layerURL = layerURL + L.Util.getParamString(params, layerURL, true);

                apiService.getExt(layerURL, function(data) {

                        if (typeof data === 'string') {

                            if (data.indexOf('ServiceException') < 0) {

                                console.log('Adding date: ' + layerURL)

                                dates.push({
                                    "date": utc_date,
                                    "description": dt.toUTCString(),
                                    "id": utc_date.valueOf() + ";" + utc_date.valueOf()
                                });
                            }

                        }
                    },
                    function (err) {

                        console.log("Error Loading layer: " + err)

                    });


            }

            //wait(3000);

        }


    }


    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout);

    var id_split = layerObj.dataid.split('_');
    manager.layerId = (id_split.length == 1)? id_split[0] : id_split[1];

    var WMSParams = {
        service: 'WMS',
        request: 'GetMap',
        version: '1.3.0',
        layers: manager.layerId,
        styles: '',
        format: 'image/png',
        transparent: true
    };


    function update(newProps, newItem, onFinish, bScrambling) {

        manager.setProps(newProps);

        manager.setItem(newItem);

        if (manager.mapLayer()) {
            manager.setlayerOpacity(manager.mapLayer().options.opacity);
            mapService.removeLayer(manager.mapLayer());
        }

        var query = '?TIME=' + newItem.date.format('YYYY-MM-DDT') + newItem.date.format('HH') + ':00:00';
        manager.setMapLayer(mapService.addSingleTileWmsLayer(layerObj.server.url + query, WMSParams));

        if (manager.layerOpacity()) manager.mapLayer().setOpacity(manager.layerOpacity());

        if (onFinish) onFinish()

    }

    manager.hardcodedProperties = function() {
        return true;
    }

    manager.legend = function () {

        return {
            type: layerObj.type.code.toUpperCase(),
            url: "img/sumALHEUE.png",
            dynPalette: {}
            //layers:mapLayer.wmsParams.layers,
        }
    },

    manager.initializeMoveOptions = function() {

        getLayerAvailability();

        var data = dates;

        manager.setCanMovie(data.length > 1);
        if (manager.canMovie()) {
            //cerco l'index del layer caricato precedentemente
            var iIndexLoadedLayer = _.findIndex(data, function(availableItem) {
                return availableItem.description == manager.item().description;
            });
            //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
            iIndexLoadedLayer = (iIndexLoadedLayer > -1)? iIndexLoadedLayer : 1;

            //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
            manager.infoAvaialability(iIndexLoadedLayer + 1, data.length);
            manager.infoAvaialability().reverse = (moment(data[0].date).unix() > moment(data[1].date).unix());

        }

    },

    manager.layerProps = {
        "layerProperties": {
            "attributes": [
                {
                    "descr": "Variable",
                    "name":"variable",
                    "entries": [{
                        "descr": "ECMWF-ENS > 5y EFAS-RP",
                        "value": "q_ens;0",
                        "referredValues": {
                            "entry": []
                        }

                    }],
                    "id": "variable",
                    "selectedEntry": {
                        "descr": "ECMWF-ENS > 5y EFAS-RP",
                        "value": "q_ens;0",
                        "referredValues": {
                            "entry": []
                        }
                    },
                    "type": "List",
                    "visible": "true"
                }

            ],
            "data": manager.layerId,
            "description": layerObj.descr,
            "id": manager.layerId,
            "longDescription": 'Number of ECMWF-ENS based forecasts exceeding the EFAS 5-year return period threshold'
        }
    }


    manager.load = function(onFinish) {

        manager.setProps(manager.layerProps);

        var offset = 12 * 3600000;
        var to = new Date(menuService.getDateTo().getTime() - offset);

        //var to = menuService.getDateTo();
        var hours = (to.getUTCHours() >= 12)? 12 : 0;
        to.setUTCHours(hours, 0, 0, 0);

        manager.setItem({
            "date": to,
            "description": to.toUTCString(),
            "id": to.getTime() + ";" + to.getTime()
        });

        var query = '?TIME=' + moment(to).format('YYYY-MM-DDT') + ((hours > 0)? hours : '00') + ':00:00';
        manager.setMapLayer(mapService.addSingleTileWmsLayer(layerObj.server.url + query, WMSParams));

        //inizializzo le opzioni per la movie
        manager.initializeMoveOptions();

        if (onFinish) onFinish()

    }

    //costruisco chiamata a rabbit
    manager.updateListener = function() {

        console.log("Empty update Listener");
        manager.wsAcquisition = null;

    };

    manager.removeListener = function () {

    },

    manager.onDateChange = function(onFinish){

        var data = getLayerAvailability();

        //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
        if (manager.infoAvaialability) manager.infoAvaialability(data.length, data.length);

        update(manager.props(), data[data.length - 1], onFinish)

    },

    manager.goForward = function() {

        //controllo se ci sono gia delle proprieta caricate
        if (manager.props()) {

            var data = getLayerAvailability();

            //cerco l'index del layer caricato precedentemente
            var iIndexLoadedLayer = _.findIndex(data, function (availableItem) {
                return availableItem.description == manager.item().description;
            });
            //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
            iIndexLoadedLayer = (iIndexLoadedLayer > -1)? (iIndexLoadedLayer + 1) : 1;

            //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
            if (manager.infoAvaialability) manager.infoAvaialability((iIndexLoadedLayer + 1), data.length);

            update(manager.props(), data[iIndexLoadedLayer], function() {
                mapService.oLayerList.updateLayer(manager)
            })

        }

    },

    manager.goBackward = function() {

        //controllo se ci sono gia delle proprieta caricate
        if (manager.props()) {

            var data = getLayerAvailability();

            //cerco l'index del layer caricato precedentemente
            var iIndexLoadedLayer = _.findIndex(data, function (availableItem) {
                return availableItem.description == manager.item().description;
            });
            //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
            iIndexLoadedLayer = (iIndexLoadedLayer > -1)? iIndexLoadedLayer : 1;

            //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
            if (manager.infoAvaialability) manager.infoAvaialability((iIndexLoadedLayer - 1), data.length);

            update(manager.props(), data[iIndexLoadedLayer - 1], function () {
                mapService.oLayerList.updateLayer(manager)
            })

        }

    }

    manager.showProps = function (onFinish) {

        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function() {
                    return {
                        layer: manager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {
            update(obj.props, obj.data, onFinish)
        }, function () {
            console.log("CANCEL")
        });

    },

    manager.getLayerAvailability = function () {
        return dates;
    };



    //eseguo chimata rabbit
    manager.updateListener();

    return manager;

}