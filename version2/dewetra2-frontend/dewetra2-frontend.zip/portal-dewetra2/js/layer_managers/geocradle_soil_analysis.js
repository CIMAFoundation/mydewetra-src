/**
 * Created by Dario Rubado on 12/07/17.
 */
function layerManager_geocradle_soil_analysis(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService) {


    var visible = true;

    var layer = layerObj;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;
    var layerDateRef = '';


    var backgroundLayer = null;

    var featureStyle = {
        weight : 1,
        opacity : 1,
        fillOpacity: 0.6
    }

    var layer_palette = [{
        label:"NO DATA",
        color:"#505050",
        sign:"<",
        value:0,
        mu:"%",
        dec:""
    },{
        label:"",
        color:"#FFE6E6",
        sign:"<",
        value:10,
        mu:"%",
        dec:0
    },{
        label:"",
        color:"#FFC8C8",
        sign:"<",
        value:20,
        mu:"%",
        dec:0
    },{
        label:"",
        color:"#FFAFAF",
        sign:"<",
        value:30,
        mu:"%",
        dec:0
    },{
        label:"",
        color:"#FF9696",
        sign:"<",
        value:40,
        mu:"%",
        dec:0
    },{
        label:"",
        color:"#FF7D7D",
        sign:"<",
        value:50,
        mu:"%",
        dec:0
    },{
        label:"",
        color:"#FF6464",
        sign:"<",
        value:60,
        mu:"%",
        dec:0
    },{
        label:"",
        color:"#FF4B4B",
        sign:"<",
        value:70,
        mu:"%",
        dec:0
    },{
        label:"",
        color:"#FF3232",
        sign:"<",
        value:80,
        mu:"%",
        dec:0
    },{
        label:"",
        color:"#FF1E1E",
        sign:"<",
        value:90,
        mu:"%",
        dec:0
    },{
        label:"",
        color:"#FF0A0A",
        sign:"<=",
        value:100,
        mu:"%",
        dec:0
    }];

    var props = {

        areaType: {
            name: "AREA_OF_INTEREST",
            descr: "AREA_OF_INTEREST_DESCR",
            visible: true,
            date: false,
            type: true,
            typeSelected: {
                name:"COUNTRY",
                descr:"COUNTRY",
                value:"country"
            },
            typeAttr:[
                {
                    name: "REGION",
                    descr:"REGION",
                    value:"region"
                },{
                    name:"COUNTRY",
                    descr:"COUNTRY",
                    value:"country"
                }
            ]
        },
        region: {
            name: "REGION",
            descr: "REGION_DESCR",
            date: false,
            type: true,
            visible: false,
            typeSelected: {
                name: "ALL",
                descr:"ALL",
                value:"-"
            },
            typeAttr: [
                {
                    name: "ALL",
                    descr:"ALL",
                    value:"-"
                },
                {
                    name: "Balkan",
                    descr:"Balkan",
                    value:"BK"
                },{
                    name:"Middle East",
                    descr:"Middle East",
                    value:"ME"
                },{
                    name:"North Africa",
                    descr:"North Africa",
                    value:"NA"
                }
            ]
        },
        country: {
            name: "COUNTRY",
            descr: "COUNTRY_DESCR",
            date: false,
            type: true,
            visible: true,
            typeSelected: {
                name: "ALL",
                descr:"ALL",
                value:"-"
            },
            typeAttr: [
                {
                    name: "ALL",
                    descr:"ALL",
                    value:"-"
                },
                {
                    name: "Greece",
                    descr:"Greece",
                    value:"GR"
                },{
                    name:"Fyrom",
                    descr:"Fyrom",
                    value:"MK"
                },{
                    name:"Serbia",
                    descr:"Serbia",
                    value:"RS"
                },{
                    name:"Turkey",
                    descr:"Turkey",
                    value:"TR"
                },{
                    name:"Israel",
                    descr:"Israel",
                    value:"IL"
                }

            ]
        },
        depth: {
            name: "DEPTH",
            descr: "DEPTH_DESCR",
            date: false,
            type: true,
            visible: true,
            typeSelected: {
                name: "30 - 40",
                descr:"30 - 40",
                value:"30;40"
            },
            typeAttr:[
                {
                    name: "SURFACE",
                    descr:"SURFACE",
                    value:"0;10"
                },{
                    name: "10 - 20",
                    descr:"10 - 20",
                    value:"10;20"
                },{
                    name: "20 - 30",
                    descr:"20 - 30",
                    value:"20;30"
                },{
                    name: "30 - 40",
                    descr:"30 - 40",
                    value:"30;40"
                },{
                    name: "40 - 50",
                    descr:"40 - 50",
                    value:"40;50"
                },{
                    name: "50 - 60",
                    descr:"50 - 60",
                    value:"50;60"
                },{
                    name: "60 - 70",
                    descr:"60 - 70",
                    value:"60;70"
                },{
                    name: "70 - 80",
                    descr:"70 - 80",
                    value:"70;80"
                },{
                    name: "80 - 90",
                    descr:"80 - 90",
                    value:"80;90"
                },{
                    name: "90 - 100",
                    descr:"90 - 100",
                    value:"90;100"
                },{
                    name: "100 - 120",
                    descr:"100 - 120",
                    value:"100;120"
                },{
                    name: "120 - 140",
                    descr:"120 - 140",
                    value:"120;140"
                },{
                    name: "140 - 160",
                    descr:"140 - 160",
                    value:"140;160"
                },{
                    name: "160 - 180",
                    descr:"160 - 180",
                    value:"160;180"
                },{
                    name: "180 - 200",
                    descr:"180 - 200",
                    value:"180;200"
                },{
                    name: "> 200",
                    descr:"> 200",
                    value:"200;2000"
                }
            ]
        },
        soilTaxonomy: {
            name: "SOIL_CLASSIFICATION",
            descr: "SOIL_CLASSIFICATION_DESCR",
            date: false,
            type: true,
            visible: true,
            typeSelected: {
                name: "USDA",
                descr:"USDA",
                value:"usda"
            },
            typeAttr:[
                {
                    name: "USDA",
                    descr:"USDA",
                    value:"usda"
                },{
                    name:"WRB",
                    descr:"WRB",
                    value:"wrb"
                }
            ]
        },
        usda: {
            name: "USDA",
            descr: "USDA_DESCR",
            date: false,
            type: true,
            visible: true,
            typeSelected: {
                name: "ALL",
                descr:"ALL",
                value:"-"
            },
            typeAttr:[
                {
                    name: "ALL",
                    descr:"ALL",
                    value:"-"
                },
                {
                    name: "ALFISOLS",
                    descr:"ALFISOLS",
                    value:"ALFISOLS"
                },{
                    name: "ANDISOLS",
                    descr:"ANDISOLS",
                    value:"ANDISOLS"
                },{
                    name:"ARIDISOLS",
                    descr:"ARIDISOLS",
                    value:"ARIDISOLS"
                },{
                    name:"ENTISOLS",
                    descr:"ENTISOLS",
                    value:"ENTISOLS"
                },{
                    name:"GELISOLS",
                    descr:"GELISOLS",
                    value:"GELISOLS"
                },{
                    name:"HISTOSOLS",
                    descr:"HISTOSOLS",
                    value:"HISTOSOLS"
               },{
                    name:"INCEPTISOLS",
                    descr:"INCEPTISOLS",
                    value:"INCEPTISOLS"
                },{
                    name:"MOLLISOLS",
                    descr:"MOLLISOLS",
                    value:"MOLLISOLS"
                },{
                    name:"OXISOLS",
                    descr:"OXISOLS",
                    value:"OXISOLS"
                },{
                    name:"SPODOSOLS",
                    descr:"SPODOSOLS",
                    value:"SPODOSOLS"
                },{
                    name:"ULTISOLS",
                    descr:"ULTISOLS",
                    value:"ULTISOLS"
                },{
                    name:"VERTISOLS",
                    descr:"VERTISOLS",
                    value:"VERTISOLS"
                }

            ]
        },
        wrb: {
            name: "WRB",
            descr: "WRB_DESCR",
            date: false,
            type: true,
            visible: false,
            typeSelected:                 {
                name: "ALL",
                descr:"ALL",
                value:"-"
            },
            typeAttr:[
                {
                    name: "ALL",
                    descr:"ALL",
                    value:"-"
                },
                {
                    name: "Acrisols",
                    descr:"Acrisols",
                    value:"AC"
                },{
                    name: "Albeluvisols",
                    descr:"Albeluvisols",
                    value:"AB"
                },{
                    name:"Alisols",
                    descr:"Alisols",
                    value:"AL"
                },{
                    name: "Andosols",
                    descr:"Andosols",
                    value:"AN"
                },{
                    name: "Anthrosols",
                    descr:"Anthrosols",
                    value:"AT"
                },{
                    name:"Arenosols",
                    descr:"Arenosols",
                    value:"AR"
                },{
                    name:"Calcisols",
                    descr:"Calcisols",
                    value:"CL"
                },{
                    name:"Cambisols",
                    descr:"Cambisols",
                    value:"CM"
                },{
                    name:"Chernozem",
                    descr:"Chernozem",
                    value:"CH"
                },{
                    name:"Cryosols",
                    descr:"Cryosols",
                    value:"CR"
                },{
                    name:"Durisol",
                    descr:"Durisol",
                    value:"DU"
                },{
                    name:"Ferralsols",
                    descr:"Ferralsols",
                    value:"FR"
                },{
                    name:"Fluvisol",
                    descr:"Fluvisol",
                    value:"FL"
                },{
                    name:"Gleysols",
                    descr:"Gleysols",
                    value:"GL"
                },{
                    name:"Gypsisols",
                    descr:"Gypsisols",
                    value:"GY"
                },{
                    name:"Histosols",
                    descr:"Histosols",
                    value:"HS"
                },{
                    name:"Kastanozem",
                    descr:"Kastanozem",
                    value:"KS"
                },{
                    name:"Leptosols",
                    descr:"Leptosols",
                    value:"LP"
                },{
                    name:"Lixisols",
                    descr:"Lixisols",
                    value:"LX"
                },{
                    name:"Luvisols",
                    descr:"Luvisols",
                    value:"LV"
                },{
                    name:"Nitisols",
                    descr:"Nitisols",
                    value:"NT"
                },{
                    name:"Phaeozem",
                    descr:"Phaeozem",
                    value:"PH"
                },{
                    name:"Planosols",
                    descr:"Planosols",
                    value:"PL"
                },{
                    name:"Plinthosols",
                    descr:"Plinthosols",
                    value:"PT"
                },{
                    name:"Podzols",
                    descr:"Podzols",
                    value:"PZ"
                },{
                    name:"Regosols",
                    descr:"Regosols",
                    value:"RG"
                },{
                    name:"Retisols",
                    descr:"Retisols",
                    value:"RT"
                },{
                    name:"Solonchaks",
                    descr:"Solonchaks",
                    value:"SC"
                },{
                    name:"Solonetz",
                    descr:"Solonetz",
                    value:"SN"
                },{
                    name:"Technosols",
                    descr:"Technosols",
                    value:"TC"
                },{
                    name:"Umbrisols",
                    descr:"Umbrisols",
                    value:"UM"
                },{
                    name:"Vertisols",
                    descr:"Vertisols",
                    value:"VR"
                }

            ]
        },
        variable: {
            name: "VARIABLE",
            descr: "VARIABLE_DESCR",
            date: false,
            type: true,
            visible: true,
            typeSelected: {
                name: "OM",
                descr:"OM",
                value:"OM",
                uom:"[%]"
            },
            typeAttr:[
                {
                    name: "CaCO3",
                    descr:"CaCO3",
                    value:"CaCO3",
                    uom:"[%]"
                },{
                    name: "OM",
                    descr:"OM",
                    value:"OM",
                    uom:"[%]"
                },{
                    name:"sand_fraction",
                    descr:"sand_fraction",
                    value:"sand_fraction",
                    uom:"[%]"
                },{
                    name:"silt_fraction",
                    descr:"silt_fraction",
                    value:"silt_fraction",
                    uom:"[%]"
                },{
                    name:"clay_fraction",
                    descr:"clay_fraction",
                    value:"clay_fraction",
                    uom:"[%]"
                },{
                    name:"pH(H2O)",
                    descr:"pH(H2O)",
                    value:"pH(H2O)",
                    uom:""
                }
            ]
        },
        dynamicPalette: {
            min_value: 0,
            max_value: 100
        }


    }



    function getPaletteColor(val) {

        for (var j = 0; j < layer_palette.length; j++) {

            if (!isNaN(val) && (layer_palette[j].value > val)) return layer_palette[j].color;

        }

        return '#000';

    }

    function stationClickListener(s) {

        if (s.target.feature.properties.value <=-9998){
            alert($translate.instant('UNAVAILABLE_DATA'));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/geocradle_soil_analysis_chart_form.html',
            controller: 'geocradleSoilAnalysisChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sampleInfo: function () {

                    return {

                        sampleData : s.target.feature.properties,
                        seriesId : layerObj.dataid,
                        serverId: layerObj.server.id

                    };

                }

            }
        })

    }



    function InfoMouseOver(s) {

        if (infoPopUP) infoPopUP.mouseOver('geocradle_soil_analysis', mapLayer._leaflet_id, s.target.feature)

    }

    function InfoMouseOut() {

        if (infoPopUP) infoPopUP.mouseOut('geocradle_soil_analysis', mapLayer._leaflet_id)

    }

    function update(newProps, onFinish) {

        props = newProps;
        var manager = mapService.oLayerList.getManagerByMapLayer(mapLayer)
        manager.load(onFinish);

    }


    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        setMapLayer: function (l) {
            mapLayer = l;
        },

        load: function(onFinish) {

            var obj = {

                "id": layerObj.dataid,
                "from": menuService.getDateFromUTCSecond(),
                "to": menuService.getDateToUTCSecond(),
                "props": {
                    "areaType": props.areaType.typeSelected.value,
                    "area": ((props.areaType.typeSelected.value == "region")? props.region.typeSelected.value : props.country.typeSelected.value),
                    "depth": props.depth.typeSelected.value,
                    "soilTaxonomy": props.soilTaxonomy.typeSelected.value,
                    "soilType": ((props.soilTaxonomy.typeSelected.value = "usda")? props.usda.typeSelected.value : props.wrb.typeSelected.value),
                    "variable": props.variable.typeSelected.value,
                    "date": ((props.date && (props.date != 'ALL'))? props.date : '-')
                }

            };

            // Riscalo la palette in
            var step = (props.dynamicPalette.max_value - props.dynamicPalette.min_value)/10;
            layer_palette[0].mu = props.variable.typeSelected.uom;
            for (var j = 1; j < layer_palette.length; j++) {
                layer_palette[j].value = (props.dynamicPalette.min_value + j*step);
                layer_palette[j].mu = props.variable.typeSelected.uom;
            }

            apiService.post("ddsserie/"+layer.server.id+"/seriefeatures/", obj, function(data) {

                theGeoJson = data;

                layerDateRef = ((props.date && (props.date != 'ALL'))? props.date : 'ALL DATES');

                if (mapLayer) mapService.removeLayer(mapLayer);

                mapLayer = mapService.addGeoJsonLayer(theGeoJson.features, layerObj.name, {

                    pointToLayer: function(feature, latlng) {

                        feature.properties.variable = props.variable.typeSelected.name + ' ' + props.variable.typeSelected.uom
                        feature.properties.fillColor = getPaletteColor(feature.properties.value);

                        var geojsonMarkerOptions = {

                            radius : 5,
                            weight : 1,
                            color : "#000000",
                            opacity : 1,
                            fillOpacity: 0.8,
                            fillColor: feature.properties.fillColor

                       };

                        return L.circleMarker(latlng, geojsonMarkerOptions);

                    }


                }, stationClickListener, InfoMouseOver, InfoMouseOut);


                if (onFinish) onFinish()


            }, function(data, status) {
                alert(data)
            })

        },

        layerTooltip: function(){

            var manager = this;

            var tooltipObj = [

                {
                    label : "LAYER_NAME",
                    value : manager.name()
                },
                {
                    label : "DEPTH",
                    value : props.depth.typeSelected.name
                },
                {
                    label : "VARIABLE",
                    value : props.variable.typeSelected.name
                },
                {
                    label : "DATE",
                    value : layerDateRef
                }

            ];

            return tooltipObj;

        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        setOpacity : function(value){

            if (value){
                featureStyle.opacity = value;
                featureStyle.fillOpacity = value;
                //updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return featureStyle.opacity
        },

        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (backgroundLayer) mapService.removeHardCodedWmsLayer(backgroundLayer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.descr
        },

        descr: function () {
            return ''
        },

        draggable: function () {
            return false
        },

        typeDescr: function () {
            return layerDateRef;
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi;
        },

        getWarningInfo: function () {
            return infoPopUP;
        },

        showProps : function (onFinish) {

            var layerPropModal = $uibModal.open({

                templateUrl: 'apps/dewetra2/views/layer_properties_geocradle_soil_analysis.html',
                controller: function ($scope, $uibModalInstance, params) {

                    $scope.data = angular.copy(params.props);

                    $scope.availableDates = [];

                    function getAvailability() {

                        var p = {
                            "areaType": $scope.data.areaType.typeSelected.value,
                            "area": (($scope.data.areaType.typeSelected.value == "region")? $scope.data.region.typeSelected.value : $scope.data.country.typeSelected.value),
                            "depth": $scope.data.depth.typeSelected.value,
                            "soilTaxonomy": $scope.data.soilTaxonomy.typeSelected.value,
                            "soilType": (($scope.data.soilTaxonomy.typeSelected.value = "usda")? $scope.data.usda.typeSelected.value : $scope.data.wrb.typeSelected.value),
                            "variable": $scope.data.variable.typeSelected.value
                        };

                        $scope.availableDates.splice(0, $scope.availableDates.length);

                        serieService.getAvailability(layerObj.server.id, layerObj.dataid, menuService.getDateFromUTCSecond(), menuService.getDateToUTCSecond(), p,
                            function(data) {
                                var datesArray = Array.isArray(data)? data : [data];
                                if (datesArray.length > 1) $scope.availableDates.push('ALL');
                                datesArray.forEach(function (date) {
                                    $scope.availableDates.push(moment(date).format('YYYY-MM-DD'));
                                })

                            },
                            function(error) {
                                alert(error);
                            }
                        );
                    }

                    getAvailability();

                    $scope.update = function () {
                        $uibModalInstance.close($scope.data);
                    };

                    $scope.closePopup = function () {
                        $uibModalInstance.dismiss()
                    }

                    $scope.itemChanged = function(item) {

                        if (item.typeSelected.value == 'region') {
                            $scope.data['region'].visible = true;
                            $scope.data['country'].visible = false;
                        }
                        if (item.typeSelected.value == 'country') {
                            $scope.data['region'].visible = false;
                            $scope.data['country'].visible = true;
                        }
                        if (item.typeSelected.value == 'usda') {
                            $scope.data['usda'].visible = true;
                            $scope.data['wrb'].visible = false;
                        }
                        if (item.typeSelected.value == 'wrb') {
                            $scope.data['usda'].visible = false;
                            $scope.data['wrb'].visible = true;
                        }
                        if ((item.name == 'AREA_OF_INTEREST') || (item.name == 'SOIL_CLASSIFICATION')) return;

                        getAvailability();

                    };
                },
                size: "lg",

                resolve: {
                    params: function() {
                        return {
                            layer: mapLayer,
                            props: props
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj, onFinish)
            }, function () {
                console.log("CANCEL")
            });

        },

        legend: function () {

            return {
                type:"ADVANCED",
                legend:[{
                    type:"CUSTOM",
                    title: props.variable.typeSelected.name,
                    palette: layer_palette
                }]
            };

        },

        setVisible: function (b) {
            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);
        },

        isVisible:function(){
            return visible;
        }

    }

}