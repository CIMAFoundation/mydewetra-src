/**
 * Created by Dario Rubado on 14/07/16.
 */
function layerManager_flood_proofs_probabilistic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService){

    var ICON_SIZE = 14;

    var visible=true;

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;

    var markerFloodOption = {
        radius : iconService.markerFloodOptions.radius,
        weight : iconService.markerFloodOptions.weight,
        color : iconService.markerFloodOptions.color,
        opacity : iconService.markerFloodOptions.opacity,
        fillOpacity: iconService.markerFloodOptions.fillOpacity
    };
    //add External Layer
    // var layerToAdd = 49
    //
    // var AddictionalLayer = apiService.get("settings/layers/?id="+layerToAdd,function(obj){
    //
    //     var AlreadyLoaded = false;
    //     var dataId =obj.objects[0].dataid;
    //
    //     var o  = mapService.getLayerTest()
    //
    //     if (o.draggable){
    //         o.draggable.forEach(function (data) {
    //             if (data.wmsParams.layers == dataId){
    //                 AlreadyLoaded = true;
    //             }
    //         })
    //     }
    //
    //     //
    //     function buildLayerManager(layer) {
    //         var mangerName = 'layerManager_' + layer['type'].code;
    //         var manager = window[mangerName](layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService);
    //
    //         return manager;
    //     }
    //     if (AlreadyLoaded){
    //         console.log("Gia Caritcato")
    //     }else{
    //         var PlusManager = buildLayerManager(obj.objects[0]);
    //         PlusManager.load(function () {
    //             mapService.setlayerManager(PlusManager.mapLayer(), PlusManager);
    //             mapService.oLayerList.addLayer(PlusManager)
    //
    //         });
    //     }
    //
    // })

    //add External Layer End

    function stationInfoMouseOver(s){
        if(infoPopUP){
            console.log(s.target.feature.properties);
            infoPopUP.mouseOver('FloodProofs',mapLayer._leaflet_id, s.target.feature.properties  )
        }
    }

    function stationInfoMouseOut(){
        if(infoPopUP){
            infoPopUP.mouseOut('FloodProofs',mapLayer._leaflet_id)
        }
    }

    function stationClickListener(s) {

        if (!s.target.feature.properties[layerData.prop.fidField] || (s.target.feature.properties[layerData.prop.fidField].length < 1)){
            alert($translate.instant('UNAVAILABLE_DATA'));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/hydrogram_chart_form.html',
            controller: 'hydrogramChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sectionData: function () {

                    return {

                        section : s.target.feature.properties,
                        prop : layerData.prop,
                        serverId: layerObj.server.id
                    };

                }

            }
        })

    }






    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        canMovie: function(){
            return false
        },

        load: function(onFinish) {

            console.log("stop");
            serieService.getLayerData(layer, function (ld) {

                layerData = ld;
                serieService.getGeoJson(layerData, function (data) {

                    theGeoJson = data;

                    var geojsonMarkerOptions = {
                               radius: 5,
                               fillColor: '#0000FF',
                               color: '#000',
                               weight: 1,
                               opacity: 1,
                               fillOpacity: 0.8
                            };

                    mapLayer = mapService.addGeoJsonLayer(data, layer['descr'], {

                        pointToLayer: function(feature, latlng) {
                            // return L.marker(latlng, {icon:mapService.getTriangleIcon(ICON_SIZE, "blue", "black", markerFloodOption.opacity)});
                            return L.marker(latlng, {icon:iconService.section_gauge_observation_Icon(feature)});
                        }

                    }, stationClickListener,stationInfoMouseOver, stationInfoMouseOut);

                    if (onFinish) onFinish()

                }, function(data) {

                    alert('Error loading layer: ' + data.error_message);

                })

            });

        },

        layerTooltip: function(){

            // var manager = mapService.getLayerManager(mapLayer);


            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : this.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : this.typeDescr()
                }

            ];
            return tooltipObj;
        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        setOpacity : function(value){

            if (value){
                markerFloodOption.opacity = value;
                markerFloodOption.fillOpacity = value
            }
        },

        getOpacity : function(){
            return markerFloodOption.opacity
        },

        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.descr
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        typeDescr: function () {
            // return "SECTION_PROBABILISTIC"
            return "";
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi
        },

        setVisible: function (b) {

            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        }

    }

}
