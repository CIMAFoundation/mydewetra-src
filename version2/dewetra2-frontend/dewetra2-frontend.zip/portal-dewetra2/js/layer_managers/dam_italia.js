function layerManager_dam_italia_old(layerObj) {

    var isVisible = true;

    var iOpacity = 1;

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices();

    var isLoaded = false;

    var timer = null;

    var to;

    var modalInstance;

    let markers = []

    const onMouseClick = (e) => {

        oServices.damService.getObservation(e.target.feature.properties.archivio, e.target.feature.properties.sub, (data) => {
            //console.log(data.content)
            //console.log(xml2json(parseXml(data.content),""));


            if (data.hasOwnProperty('content') && data.content.indexOf('solari') > -1) {
                alert('ARCHIVIO DIGHE:' + data.content)

                return
            }


            modalInstance = oServices.$uibModal.open({
                animation: true,
                component: 'damItaly',
                size: 'lg',
                resolve: {
                    oManager: function () {
                        return oManager
                    },
                    target: function () {
                        return e.target
                    },
                    observation: function () {
                        return JSON.parse(xml2json(parseXml(data.content), ""));
                    }
                }
            });

            modalInstance.result.then(function (obj) {

                console.log('modal-component dismissed at: ' + new Date());
                modalInstance = null;

            }, function () {
                console.log('modal-component dismissed at: ' + new Date());
                modalInstance = null;
            });

        })
    }


    function update(onFinish) {

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        var geojson = {
            "name":"NewFeatureType",
            "type":"FeatureCollection",
            "features":[]
        };

        oServices.damService.getCapabilities((data) => {


            data.content.ListDams.map(dam => {
                //data.content.ListDams.filter(dam => dam.diga.toUpperCase() == 'CORBARA').map(dam => {
                //data.content.ListDams.slice(0, 100).map(dam => {

                let point = getRandomLatLng(oServices.mapService.getMap());
                let lat, lon, damProp;
                try {
                    damProp = dbDighe["qDighe"].filter((d) => {
                        return ((d.Narch == dam.archivio) && (d.Sub == dam.sub));
                    })[0];
                    lat = damProp.Lat;
                    lon = damProp.Long;
                } catch (e) {
                    lat = point.lat;
                    lon = point.lng;
                }


                let i = {
                    iconUrl: 'apps/dewetra2/fonts/icone-scenario/SVG/dams.svg',
                    iconColor: "black",
                    iconSize: [20, 20]
                }
                damProp = {...damProp, ...dam}
                let feat = {
                    "type":"Feature",
                    "geometry":{
                    "type":"Point",
                        "coordinates":[lon, lat]
                },
                    "properties":damProp
                }

                geojson.features.push( feat);

                //oServices.iconService.dam_italia_Icon(feature, latlng)

                // let marker = L.marker([lat, lon], {icon: L.icon(i)});

                // marker.bindPopup("<b>" + dam.diga + "</b><br>" + dam.archivio + " -> " + dam.sub);

                // if (dam.diga.toUpperCase() == 'CORBARA') {
                //     marker.openPopup();
                // }

                // marker.on('mouseover', function (e) {
                //     marker.openPopup();
                // });
                // marker.on('mouseout', function (e) {
                //     //console.log("out")
                //     marker.closePopup();
                // });
                // marker.on('click', function (e) {
                //     onMouseClick(e)
                // })
                //
                // marker.properties = dam;

                // markers.push(marker)
            });


            //var theLayer = L.layerGroup(markers)

            //add dams like
            // oServices.mapService.addGeoJsonLayerCluster(geojson,"DAMS ITALIA" , {
            oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(geojson,"DAMS ITALIA" , {
                pointToLayer: oServices.iconService.dam_italia_Icon
            }, onMouseClick, function (e) {

                let str;

                Object.keys(e.target.feature.properties).forEach((s)=>{
                    str +='<br><b>'+ s + '</b>:' + e.target.feature.properties[s] +  '</n>';
                });
                e.target.bindPopup(str);

                e.target.openPopup()
            }, function (e) {
                e.target.closePopup()
            }));

            //add layer classic
            //oServices.mapService.addGenericLayer(theLayer, "DAMS ITALIA")

            // /.setMapLayer(theLayer)


            if (onFinish) onFinish()

        })

    }

    oManager.update = update;

    oManager.load = function (onFinish) {

        oManager.update(onFinish)

    };

    oManager.getOpacity = function () {
        return 1
    }

    oManager.showProps = function (onFinish) {


    }

    oManager.draggable = function () {
        return false
    }

    oManager.onDateChange = function (onFinish) {
        oManager.update(onFinish)

    };

    oManager.parseInfo = function (layer, data, url) {

        // if(oManager.layerObj().hasOwnProperty("customprops")){
        //     if (oManager.customprops().hasOwnProperty("queryable")){
        //         if(oManager.customprops().queryable == false) {
        //             alert(oServices.$translate.instant('NOT_QUERYABLE') + " "  + oManager.name())
        //             return
        //         };
        //     }
        // }
        //
        //
        // //
        // //if(modalInstance != null) return
        // modalInstance = oServices.$uibModal.open({
        //     animation: true,
        //     component: 'efasReportingPointInfo',
        //     size:'lg',
        //     resolve:{
        //         oManager:function () {
        //             return oManager
        //         },
        //         dateRun: function() {
        //             return  to
        //         }
        //     }
        // });
        //
        // modalInstance.result.then(function (obj) {
        //
        //     console.log('modal-component dismissed at: ' + new Date());
        //     modalInstance = null;
        //
        // }, function () {
        //     console.log('modal-component dismissed at: ' + new Date());
        //     modalInstance = null;
        // });


    }

    oManager.thirdLine = function () {
        return true
    }


    oManager.getVariable = function () {

        let string = ''

        return string
    }

    oManager.getAggregation = function () {
        return "";
    }


    delete oManager.getDownloadUrl;


    oManager.legend = function () {

        var legend = {
            type: "ADVANCED",
            legend: [{
                type: "CUSTOM",
                title: oManager.name(),
                palette: [],
                descr: ""
            }]
        };


        if (oManager.layerObj().hasOwnProperty("customprops")) {
            if (oManager.customprops().hasOwnProperty("customLegend")) {
                legend.legend[0].palette = oManager.customprops().customLegend['default'].palette;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].img = oManager.customprops().customLegend['default'].img;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].descr = oManager.customprops().customLegend['default'].descr;//default o la variabile che definisci mi permette di gestire multi legenda

                return legend
            }
        }
    }

    return oManager
}


function layerManager_dam_italia(layerObj) {

    const oManager = layerManager_dam_italia_old(layerObj);
    let modalInstance;
    const oServices = oManager.oServices();
    let isVisible = true;

    let oTheGeoJson;

    let iOpacity = 1;

    function onMouseClick(s){

        console.log(s.target.feature.properties);

        // modalInstance = oServices.$uibModal.open({
        //
        //     templateUrl: 'apps/dewetra2/views/sensor_chart_form.html',
        //     controller: 'sensorChartController',
        //     size: 'lg',
        //     keyboard: false,
        //     resolve: {
        //
        //         sensorData: function () {
        //
        //             return s.target.feature.properties;
        //
        //         },
        //         layerObj: function () {
        //
        //             return oManager;
        //
        //         }
        //
        //     }
        // });


        var modalInstance = oServices.$uibModal.open({

            component: 'sentinelChartComponent',
            size: 'lg',
            keyboard: false,
            resolve: {

                sensorData: function () {

                    return s.target.feature.properties;

                },
                layerObj: function () {

                    return oManager;

                }

            }
        });
    }

    oManager.setTheGeoJson = (oGeoJson) => {

        oGeoJson.features.map((feature)=>{
            feature.properties.now = oServices.menuService.getDateToUTCSecond();
        })
        oTheGeoJson = oGeoJson;
    };
    oManager.getTheGeoJson = () => {
        return oTheGeoJson;
    }

    loadLayer = () =>{
        oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(oManager.getTheGeoJson(),"DAMS ITALIA" , {
            pointToLayer: oServices.iconService.dam_italia_Icon,
        }, onMouseClick, function (e) {
            let v = Object.keys(e.target.feature.properties).filter((key)=>{
                return key.startsWith('v_');
            })[0];
            let date = moment.unix(parseInt(v.split('_')[1])).utc().format('llll');
            let value = parseFloat(e.target.feature.properties[v]).toFixed(1);
            let str ='<br><b>'+ oServices.$translate.instant('STATION_NAME') + '</b>:' + e.target.feature.properties.stationname +  '</n>';
            str +='<br><b>'+ oServices.$translate.instant('LAST_DATE_UPDATE') + '</b>:' + date +  '</n>';
            str +='<br><b>'+ oServices.$translate.instant('LAST0H') + '</b>:' + value +  '</n>';
            e.target.bindPopup(str);
            e.target.openPopup()
        }, function (e) {
            e.target.closePopup()
        }));
    }

    oManager.update = function update(onFinish) {

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        oManager.oServices().sentinelService.getNationalDams((data)=>{
            oManager.setTheGeoJson(data);
            loadLayer();

            if(onFinish) onFinish();

        },(data)=>{
            console.log(data)
        });

    }

    oManager.setOpacity = function (value) {

        if (value) {
            for ( let i in oManager.mapLayer()._layers){
                iOpacity = value
                oManager.mapLayer()._layers[i].setStyle({opacity: iOpacity, fillOpacity: iOpacity});
            }
        }
    }

    oManager.getOpacity = function () {
        return iOpacity
    }

    oManager.setVisible = function (b) {

        if(!b) {
            if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());
        }else {

            loadLayer();
        }

        isVisible = b
    }

    oManager.isVisible = function () {
        return isVisible
    }

    oManager.legend = function () {

        var legend = {

            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: "",
                palette:[{
                    label:"No Value",
                    color:"#8A8787",
                    // sign:"",
                    // value:"",
                    // mu:"",
                    // dec:0
                },{
                    label:"Dati da -24h a -1h ",
                    color:"#FFFFFF",
                    // sign:"<",
                    // value:500000,
                    // mu:"€",
                    // dec:0
                },{
                    label:"Dati da -1h a 0h ",
                    color:"#00FF00",
                    // sign:"<",
                    // value:1000000,
                    // mu:"€",
                    // dec:0
                }]
            }]

        };

        return legend

    };


    delete oManager.showProps;

    return oManager;
}


