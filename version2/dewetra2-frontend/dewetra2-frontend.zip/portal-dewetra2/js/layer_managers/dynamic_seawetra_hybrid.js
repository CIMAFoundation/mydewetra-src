/**
 * Created by Dario Rubado on 27/10/20
 */




function layerManager_seawetra_hybrid_static(layerObj) {

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices()

    var isVisible = true;

    var oLegend = {}


    var iOpacity = 1;

    let oDynamicPaletteSettings = {
        haveDynamicPalette: false,
        min_value: 0,
        max_value: 0
    };

    function buildDynamicPaletteData(properties) {

        if (oDynamicPaletteSettings.haveDynamicPalette) return oDynamicPaletteSettings;


        if (properties.layerProperties.attributes.length > 0) {

            var dynamicPaletteProp = _.findWhere(properties.layerProperties.attributes, {name: "dyn_pal"})

            if (dynamicPaletteProp && dynamicPaletteProp.selectedEntry.value == "1") {
                var obj = {}
                obj.haveDynamicPalette = true;//setto opzio true
                var selectedVariable = _.findWhere(properties.layerProperties.attributes, {name: "variable"})
                var maxVal = _.findWhere(selectedVariable.selectedEntry.referredValues.entry, {key: "max_def"});
                if (maxVal) {
                    obj.max_value = parseFloat(maxVal.value);
                    obj.min_value = parseFloat((_.findWhere(selectedVariable.selectedEntry.referredValues.entry, {key: "min_def"})).value);
                    return obj
                }
            }

        }
    }

    function setDynamicPalette() {
        //return false
        var obj = buildDynamicPaletteData(oManager.props());
        if (obj) oDynamicPaletteSettings = obj
    }

    oManager.load = function (onFinish) {

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        let from = oServices.menuService.getDateFrom()
        let to = oServices.menuService.getDateTo()

        to.setUTCHours(23, 0, 0, 0);
        to.setDate(2);
        to.setMonth(0)
        from.setUTCHours(1, 0, 0, 0);
        from.setDate(1);
        from.setMonth(0)

        oServices.layerService.getLayerProperties(layerObj, function (layerProp) {

            oManager.setProps(layerProp);

            setDynamicPalette();

            oServices.layerService.publishLayer(layerObj, Math.round(from.getTime() / 1000), Math.round(to.getTime() / 1000), function (data) {

                oManager.setLayer(data.properties, data.item, data.layerid, onFinish);

            });

        });

    }

    oManager.update = function (newProps, newItem, onFinish) {

        let from = oServices.menuService.getDateFrom();
        let to = oServices.menuService.getDateTo();

        to.setUTCHours(23, 0, 0, 0);
        to.setDate(1);
        to.setMonth(0)
        from.setUTCHours(1, 0, 0, 0);
        from.setDate(1);
        from.setMonth(0);

        oServices.layerService.republishLayer(layerObj, newProps, Math.round(from.getTime() / 1000), Math.round(to.getTime() / 1000), newItem, (data) => {

            oManager.setLayer(newProps, newItem, data.layerid, onFinish);

        });


    }


    oManager.setLayer = (newProps, newItem, layerId, onFinish) => {

        oManager.setProps(newProps);

        oManager.setItem(newItem);

        oManager.setLayerId(layerId);

        if (oManager.mapLayer()) oManager.setLayerOpacity(oManager.mapLayer().options.opacity);

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        oManager.setMapLayer(oServices.mapService.addWmsLayer(layerObj.server.url + '/wms', layerId, (oDynamicPaletteSettings.haveDynamicPalette) ? "minimum:" + oDynamicPaletteSettings.min_value.toString() + ";maximum:" + oDynamicPaletteSettings.max_value.toString() : null));

        oManager.mapLayer().setOpacity(oManager.layerOpacity());

        if (onFinish) onFinish()

    }


    oManager.showProps = function (onFinish) {

        var layerPropModal = oServices.$uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesControllerSeawetra",
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        layer: oManager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {


            oManager.update(obj.props, obj.data, onFinish)
        }, function () {

        });
    },


        oManager.setOpacity = function (value) {


            iOpacity = value;
            oManager.mapLayer().setOpacity(value);

        }

    oManager.getOpacity = function () {
        return iOpacity
    }


    oManager.setVisible = function (b) {

        if (!b) {
            if (oManager.mapLayer()) oManager.setOpacity(0)
            iOpacity = 0;
        } else {
            if (oManager.mapLayer()) oManager.setOpacity(1)
            iOpacity = 1;
        }

        isVisible = b
    }

    oManager.isVisible = function () {
        return isVisible
    }

    oManager.haveDynamicPalette = (obj) => {

        if (obj) {
            oDynamicPaletteSettings = obj
            oManager.setLayer(oManager.props(), oManager.item(), oManager.getLayerId())
        }

        if (oDynamicPaletteSettings.haveDynamicPalette) {
            return oDynamicPaletteSettings
        } else return false;
    }

    oManager.buildDynamicPaletteData = buildDynamicPaletteData;

    oManager.legend = function (callback) {

        oLegend = {
            type: "STATIC",
            url: oManager.mapLayer()._url,
            layers: oManager.mapLayer().wmsParams.layers,
        }
        if (callback) callback(oLegend)

    }

    oManager.parseInfo =  function (data) {

        //layer prop
        var oProperties = oManager.props();

        //inizializzo array
        var aProperties = []

        var measureUnit = ""

        if (oProperties.layerProperties.attributes.length >= 1) {

            oProperties.layerProperties.attributes.forEach(function (prop) {
                //if(debug)console.log(prop)
                if (prop.selectedEntry.referredValues && prop.selectedEntry.referredValues.entry.length > 0) {
                    prop.selectedEntry.referredValues.entry.forEach(function (entry) {
                        if (entry.key == "mu") measureUnit = entry.value
                    })
                }

                var oProp = {
                    name: prop.descr,
                    value: prop.selectedEntry.descr
                }
                if (prop.descr != "-") aProperties.push(oProp);
            })
        }

        var ret = {
            layerName: oManager.descr(),
            layerDate: oManager.item() ? moment(oManager.item().date).utc().format('DD/MM/YYYY HH:mm') : " - ",
            properties: []
        };

        if (data.features && data.features.length > 0) {
            data.features.forEach(function (f) {
                if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                    ret.properties.push({
                        name: 'value',
                        'value': f.properties.GRAY_INDEX.toFixed(2) + " " + measureUnit
                    })
                } else {
                    for (p in f.properties) {
                        ret.properties.push({name: p, 'value': f.properties[p] + " " + measureUnit})
                    }
                }
            })
        }

        ret.properties = ret.properties.concat(aProperties);

        ret.properties.forEach(function (item) {
            if (item.name == 'link') {
                item.html = true;
            } else item.html = false;
        })

        return ret;
    }


    return oManager

}
