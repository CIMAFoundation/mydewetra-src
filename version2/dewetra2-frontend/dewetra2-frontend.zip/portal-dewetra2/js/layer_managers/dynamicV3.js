
function layerManager_dynamic_v3(layerObj) {

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices();

    var iOpacity = 1;

    var layerMovieConf;

    var infoAvaialability = {
        index: 0,
        length: 1,
        reverse: null// per i radar il primo layer disponibile è l'ultimo in ordine di tempo, al contrario dei modelli
    };

    var oDynamicPaletteSettings = {
        haveDynamicPalette: false,
        min_value: 0,
        max_value: 0
    };

    let playPromise;

    var layerId;

    var downloadUrl;

    var debug = true;

    var currentLoadedTimeline;

    var fadeEffectTime = 300;

    oManager.setCanMovie(true);

    oManager.draggable = function (){
        return true;
    }





    function initializeMoveOptions() {


        //chiedo una volta la disponibilita dei layer per sapere se posso andare avanti o indietro nel tempo

        //chiedo quali layer sono diponibili nella timeline

        const from = oServices.menuService.getDateFromUTCSecond();
        const to = oServices.menuService.getDateToUTCSecond();

        oServices.layerService.getLayerAvailability(layerObj, oManager.props(), from, to, function (dataAvailable) {



            let bCanMovie = (dataAvailable.length > 1) ? true : false;
            if (bCanMovie) {
                //cerco l'index del layer caricato precedentemente
                var iIndexLoadedLayer = _.findIndex(dataAvailable, function (availableItem) {
                    return availableItem.description == oManager.item().description;
                });
                //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                iIndexLoadedLayer = (iIndexLoadedLayer > -1) ? iIndexLoadedLayer : 1;

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                infoAvaialability.index = iIndexLoadedLayer;
                infoAvaialability.length = dataAvailable.length;
                infoAvaialability.reverse = moment(dataAvailable[0].date).unix() > moment(dataAvailable[1].date).unix() ? true : false
            }

        })
    }

    oManager.load = function (onFinish){

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());


        oServices.layerService.getLayerProperties(layerObj, function (layerProp) {
            oManager.setProps(layerProp);

            loadNoMovie(onFinish);

            if(debug) console.log('STANDARD METHOD');



        })

    };

    function loadNoMovie (onFinish){
        const from = oServices.menuService.getDateFromUTCSecond();
        const to = oServices.menuService.getDateToUTCSecond();

        oServices.layerService.publishLayer(layerObj, from, to, function (data) {
            // &env=minimum:12;maximum:20&
            //oManager.setProps( data.properties); from publish don't return
            oManager.setItem(data.item);
            oManager.setLayerId(data.layerid);

            //check after setting props
            buildDynamicPaletteData();

            oManager.setLayerId(data.layerid);
            oManager.setMapLayer( oServices.mapService.addWmsLayer(data.serverurl + '/wms', data.layerid));
            oManager.setDownloadUrl(
                ((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                    data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                    data.serverurl + '/ddsData/' + data.layerid + '.tiff')
            );

            //inizializzo le opzioni per la movie
            initializeMoveOptions();

            if (onFinish) onFinish()

            if (!oManager.isVisible()) oManager.setVisible(false);


        }, function (data) {
            alert(oServices.$translate.instant(data));
            if (debug) console.log(data);
        })
    }


    oManager.update = function (newProps, newItem, onFinish){

        oManager.setProps(newProps);
        oManager.setItem(newItem);

        updateOldMethod( onFinish)
        if(debug) console.log('updateOldMethod');


    };

    function updateOldMethod( onFinish){

        const from = oServices.menuService.getDateFromUTCSecond();
        const to = oServices.menuService.getDateToUTCSecond();

        oServices.layerService.republishLayer(layerObj, oManager.props(), from, to, oManager.item(),
            function (data, status) {

                oManager.setDownloadUrl(((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                    layerObj.server.url + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                    layerObj.server.url + '/ddsData/' + data.layerid + '.tiff'));

                setLayer( data.layerid, onFinish);
            },

             function (data) {
                alert(oServices.$translate.instant(data));
            })
    }




    function setLayerWithProp(newProps, newItem, layerId, onFinish) {


        oManager.setProps(newProps)

        oManager.setItem(newItem)

        setLayer(layerId, onFinish);


        if (debug) console.log(layerObj.id + " " + layerId)
    }

    function setLayer(layerId , onFinish){

        if (oManager.mapLayer()) iOpacity = oManager.mapLayer().options.opacity;

        const LoadedMapLayerToRemove = oManager.mapLayer();

        // if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());


        oManager.oServices().$timeout(() => {
            if(LoadedMapLayerToRemove)oManager.oServices().mapService.removeLayer(LoadedMapLayerToRemove);
        },fadeEffectTime);

        oManager.setLayerId(layerId);

        oManager.setMapLayer(
            oManager.oServices().mapService.addWmsLayer(layerObj.server.url + '/wms', layerId, (oManager.haveDynamicPalette()) ? "minimum:" + oManager.haveDynamicPalette().min_value.toString() + ";maximum:" + oManager.haveDynamicPalette().max_value.toString() : null)
        );

        if (iOpacity != null) oManager.mapLayer().setOpacity(iOpacity);

        if (debug) console.log(layerObj.id + " " + layerId)


        if (onFinish) onFinish();
    }






    oManager.haveDynamicPalette = function (obj) {

        if (obj) {
            oDynamicPaletteSettings = obj
            setLayer(layerId)
        }

        if (oDynamicPaletteSettings.haveDynamicPalette) {
            return oDynamicPaletteSettings
        } else return false;
    }

    function buildDynamicPaletteData() {

        if (oDynamicPaletteSettings.haveDynamicPalette) return oDynamicPaletteSettings;


        if (oManager.props().layerProperties.attributes.length > 0) {

            var dynamicPaletteProp = _.findWhere(oManager.props().layerProperties.attributes, {name: "dyn_pal"})

            if (dynamicPaletteProp && dynamicPaletteProp.selectedEntry.value == "1") {
                var obj = {}
                obj.haveDynamicPalette = true;//setto opzio true
                var selectedVariable = _.findWhere(oManager.props().layerProperties.attributes, {name: "variable"})
                var maxVal = _.findWhere(selectedVariable.selectedEntry.referredValues.entry, {key: "max_def"});
                if (maxVal) {
                    obj.max_value = parseFloat(maxVal.value);
                    obj.min_value = parseFloat((_.findWhere(selectedVariable.selectedEntry.referredValues.entry, {key: "min_def"})).value);
                    oDynamicPaletteSettings = obj
                    //return obj// forse inutile
                }
            }

        }
    }



    oManager.canPlay= function (){
        return (oManager.getPlayPromise() == null);
    }

    oManager.play = function (oRootScope){

        if(oManager.getPlayPromise() == null){
            oManager.setPlayPromise( oManager.oServices().$interval(function () {

                if (oRootScope.pendingRequests == 0) {

                    if (infoAvaialability.reverse) {
                        if (infoAvaialability.index != 0) {
                            oManager.goBackward();
                        } else oManager.goToLast();
                    } else {
                        if (infoAvaialability.index < infoAvaialability.length - 1) {
                            oManager.goForward();
                        } else oManager.goToFirst();
                    }

                }
            }, 2000))
        }else{
            oManager.stop();
        }


    }

    oManager.stop = function () {
        console.log('stop');
        debug
        oManager.oServices().$interval.cancel(oManager.getPlayPromise());
        playPromise = null;
        oManager.setPlayPromise(playPromise)

    }


    oManager.goToLast = function () {
        if (oServices.menuService.isRealTime() && oManager.props()) {

            //carico le date
            const from = oManager.oServices().menuService.getDateFromUTCSecond();
            const to = oManager.oServices().menuService.getDateToUTCSecond();

            //chiedo quali layer sono diponibili nella timeline
            oManager.oServices().layerService.getLayerAvailability(layerObj, oManager.props(), from, to, function (data) {

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                if (oManager.infoAvaialability) oManager.infoAvaialability(data.length - 1, data.length);

                update(oManager.props(), data[data.length - 1], function () {
                    oManager.oServices().mapService.oLayerList.updateLayer(oManager)
                })
            })
        }    }

    oManager.goToFirst = function () {
        //carico le date
        const from = oManager.oServices().menuService.getDateFromUTCSecond();
        const to = oManager.oServices().menuService.getDateToUTCSecond();

        //chiedo quali layer sono diponibili nella timeline
        oManager.oServices().layerService.getLayerAvailability(layerObj, oManager.props(), from, to, function (data) {

            //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
            if (oManager.infoAvaialability) {
                oManager.infoAvaialability(0, data.length);
            }

            update(oManager.props(), data[0], function () {
                oManager.oServices().mapService.oLayerList.updateLayer(oManager)
            })
        })
    }

    oManager.goForward= function (){


        //carico le date
        const from = oManager.oServices().menuService.getDateFromUTCSecond();
        const to = oManager.oServices().menuService.getDateToUTCSecond();

        //chiedo quali layer sono diponibili nella timeline
        oManager.oServices().layerService.getLayerAvailability(layerObj, oManager.props(), from, to, function (data) {

            //cerco l'index del layer caricato precedentemente
            let iIndexLoadedLayer = oManager.oServices()._.findIndex(data, function (availableItem) {
                return availableItem.description == oManager.item().description;
            });

            //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
            iIndexLoadedLayer = (iIndexLoadedLayer > -1) ? iIndexLoadedLayer : 1;

            //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
            if (oManager.infoAvaialability) {
                oManager.infoAvaialability(iIndexLoadedLayer + 1, data.length);
            }

            oManager.update(oManager.props(), data[iIndexLoadedLayer + 1], function () {

                oManager.oServices().mapService.oLayerList.updateLayer(oManager)
            })
        })    }

    oManager.canForward = function (){

        if(oManager.canMovie()){
            return ( oManager.canMovie() && oManager.infoAvaialability().index < oManager.infoAvaialability().length);
        }else return false;

    }

    oManager.goBackward = function (){
        //carico le date
        const from = oManager.oServices().menuService.getDateFromUTCSecond();
        const to = oManager.oServices().menuService.getDateToUTCSecond();

        //chiedo quali layer sono diponibili nella timeline
        oManager.oServices().layerService.getLayerAvailability(layerObj, oManager.props(), from, to, function (data) {

            //cerco l'index del layer caricato precedentemente
            var iIndexLoadedLayer = oManager.oServices()._.findIndex(data, function (availableItem) {
                return availableItem.description == oManager.item().description;
            });
            //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
            iIndexLoadedLayer = (iIndexLoadedLayer > -1) ? iIndexLoadedLayer : 1;

            //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
            if (oManager.infoAvaialability) {
                oManager.infoAvaialability(iIndexLoadedLayer - 1, data.length);
            }

            oManager.update(oManager.props(), data[iIndexLoadedLayer - 1], function () {
                oManager.oServices().mapService.oLayerList.updateLayer(oManager)
            })
        })
    }

    oManager.canBackward = function () {

        if(oManager.canMovie()){
            return ( oManager.canMovie() && oManager.infoAvaialability().index >= 0);
        }else return false;

    }

    oManager.layerDateRefFromManager = function (){

    }

    oManager.dateLine = function (){
        try {
            return oManager.dateRefFormatted()
        }catch (e){
            if (debug)   //console.log(e);
            return "date";
        }
    }
    oManager.dateRun = function (){
        if (oManager.item().id == null) return "";
        var aSplittedDate = oManager.item().id.split(';');
        var dateRun = moment.utc(parseInt(aSplittedDate[0]));
        return dateRun;
    }
    oManager.dateRef = function (){
        if (oManager.item().id == null) return "";
        var aSplittedDate = oManager.item().id.split(';');
        var dateRef = moment.utc(parseInt(aSplittedDate[1]));
        return dateRef;
    }

    oManager.dateForecast = function () {
        if (oManager.item().id == null) return "";
        var aSplittedDate = oManager.item().id.split(';');
        var diff = ((parseInt(aSplittedDate[1])) - (parseInt(aSplittedDate[0])));
        if (diff > 0) {
            diff = diff / (1000 * 60 * 60);
            return "+" + parseInt(diff);
        } else if (diff < 0) {
            return "-" + Math.abs(parseInt(diff)) / (1000 * 60 * 60);
        } else return 0;
    },

        oManager.dateRefFormatted = function () {
            var sDateRunDateRef = oManager.item().id;



            if (oManager.props().layerProperties.id == "WFSNOWROADS") return item.id.replace(/;/g, ' ');

            if (sDateRunDateRef  == null) return "";

            if (sDateRunDateRef.indexOf(";") > -1) {
                //controllo se osservazione o previsione
                var bLayerType = layerObj.category == "observation";
                //se osservazione la data di run corrisponde alla dateref e ne visualizzo solo una
                if (bLayerType) {
                    var aDateRunDateRef = sDateRunDateRef.split(";");
                    var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                    //var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                    return sDateRun
                } else {
                    //se previsione distinguo le due date
                    var aDateRunDateRef = sDateRunDateRef.split(";");
                    var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                    var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                    return sDateRef + " " + " (Run:" + sDateRun + ")";
                }
                //se ha solo una data non mi pongo il problema
            } else {


                // Anto 20160908: Se item.id non è una data provo con item.date
                var tsRun = parseInt(sDateRunDateRef);
                if (!isNaN(tsRun)) {
                    return moment(new Date(tsRun)).utc().format('DD/MM/YYYY HH:mm');
                }
                else {
                    return moment(Date.parse(oManager.item().date)).utc().format('DD/MM/YYYY HH:mm');
                }

            }

        };





    oManager.thirdLine = function () {
        return true
    }

    oManager.getVariable= function () {


        var str = "";
        if (Array.isArray(oManager.props().layerProperties.attributes)) {
            oManager.props().layerProperties.attributes.forEach(function (prop) {
                if (prop.name == "operation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (prop.name == "variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (prop.name == "__variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            })
            return str;
        } else {
            if (oManager.props().layerProperties.attributes.name == "operation") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            if (oManager.props().layerProperties.attributes.name == "variable") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            if (oManager.props().layerProperties.attributes.name == "__variable") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
        }

    };

    oManager.getAggregation= function () {
        var str = "";

        if (Array.isArray(oManager.props().layerProperties.attributes)) {
            oManager.props().layerProperties.attributes.forEach(function (prop) {
                if (prop.name == "aggregation") str = prop.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
                if (prop.name == "__aggregation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            })
            return str;
        } else {
            if (oManager.props().layerProperties.attributes.name == "aggregation") str = oManager.props().layerProperties.attributes.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
            if (oManager.props().layerProperties.attributes.name == "__aggregation") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
        }


    };




    // oManager.showProps= function (onFinish) {
    //
    //     var layerPropModal = oServices.$uibModal.open({
    //         templateUrl: 'apps/dewetra2/views/layer_properties.html',
    //         controller: "layerPropertiesController",
    //         size: "lg",
    //         resolve: {
    //             params: function () {
    //                 return {
    //                     layer: oManager.mapLayer()
    //                 }
    //             }
    //         }
    //     });
    //
    //     layerPropModal.result.then(function (obj) {
    //
    //         oManager.update(obj.props, obj.data, onFinish)
    //     }, function () {
    //         if (debug) console.log("CANCEL")
    //     });
    // };
    //TODO
    oManager.showProps= function (onFinish) {

        var modalInstance = oServices.$uibModal.open({
            animation: true,
            component: 'layerPropertiesDynamic',
            size:'lg',
            resolve:{
                oManager:function () {
                    return oManager
                }
            }
        });

        modalInstance.result.then(function (obj) {

            console.log('modal-component dismissed at: ' + new Date());

            oManager.update(obj.props, obj.data, onFinish)

            modalInstance = null;

        }, function () {
            console.log('modal-component dismissed at: ' + new Date());
            modalInstance = null;
        });
    };



    oManager.layerTooltip = function (){

        //dividere per osservazioni o previsioni e aggiungere le properties al tooltip


        var layerDelay = function (layerManagerObj) {


            try {
                var oReferenceDate = layerManagerObj.dateRef().utc().toDate()
            } catch (err) {
                return layerManagerObj.descr()
            }

            // Get Now
            var oDate = new Date();

            //if(debug)console.log("Now  = " + oDate);
            //if(debug)console.log("Ref  = " + oReferenceDate);

            // Compute time difference
            var iDifference = oDate.getTime() - oReferenceDate.getTime();

            // How it is in minutes?
            var iMinutes = 1000 * 60;

            var iDeltaMinutes = Math.round(iDifference / iMinutes);

            var sTimeDelta = "";

            if (iDeltaMinutes > 0) {
                if (iDeltaMinutes < 60) {
                    // Less then 1h
                    sTimeDelta += oServices.$translate.instant("pre_min_fa") + " " + iDeltaMinutes + ' ' + oServices.$translate.instant("min_fa");
                } else if (iDeltaMinutes < 60 * 24) {
                    // Less then 1d
                    var iDeltaHours = Math.round(iDeltaMinutes / 60);
                    sTimeDelta += oServices.$translate.instant("pre_ore_fa") + " " + iDeltaHours + ' ' + oServices.$translate.instant("ore_fa");
                } else {
                    // More than 1d
                    var iDeltaDays = Math.round(iDeltaMinutes / (60 * 24));
                    sTimeDelta += oServices.$translate.instant("pre_giorni_fa") + " " + iDeltaDays + ' ' + oServices.$translate.instant("giorni_fa");
                }
            } else {
                if (iDeltaMinutes > -60) {
                    // Less then 1h
                    sTimeDelta += oServices.$translate.instant("Fra") + ': ' + Math.abs(iDeltaMinutes) + ' ' + oServices.$translate.instant("Minuti");
                } else if (iDeltaMinutes > -60 * 24) {
                    // Less then 1d
                    var iDeltaHours = Math.round(iDeltaMinutes / 60);
                    sTimeDelta += oServices.$translate.instant("Fra") + ': ' + Math.abs(iDeltaHours) + ' ' + oServices.$translate.instant("Ore");
                } else {
                    // More than 1d
                    var iDeltaDays = Math.round(iDeltaMinutes / (60 * 24));
                    sTimeDelta += oServices.$translate.instant("Fra") + ': ' + Math.abs(iDeltaDays) + ' ' + oServices.$translate.instant("Giorni");
                }
            }


            return sTimeDelta;
        };

        //gestisco la from date nel tooltip.
        try {
            var oHoursOfCumulate = oManager.props().layerProperties.attributes.filter((attr) => {
                return attr.descr == "Cumulative Rainfall"
            })[0].selectedEntry

            var iHoursOfCumulate = parseInt(oHoursOfCumulate.value);

            // if(iHoursOfCumulate == '-1') {
            //     console.log("cumulata su time range")
            //     iHoursOfCumulate = Math.abs(menuService.getDateTo() - menuService.getDateFrom()) / 36e5;
            // }

        } catch (e) {
            console.log(iHoursOfCumulate);
        }


        //gestisco risoluzione spaziale pioggia

        try {
            var oSpatialResolution = oManager.props().layerProperties.attributes.filter((attr) => {
                return attr.descr == "Spatial Resolution"
            })[0].selectedEntry;


        } catch (e) {
            console.log(e)
        }


        //definisco oggetto tooltip
        var oTooltip = {
            "API 15": [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") : ""
                }
            ],
            MCM_CUMULATED_RAIN_DESCR: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") : ""
                }
            ],
            RADAR: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.getVariable()
                },
                //{
                //    label : "DATE_RUN",
                //    value : oManager.dateRun().format("YYYY/MM/DD HH:mm")
                //},
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") + ' UTC' : "",
                },
                //{
                //    label : "DATE_FORECAST",
                //    value : oManager.dateForecast()
                //},
                // {
                //     label: "DATE_DELAY",
                //     value: layerDelay(oManager)
                // }
            ],
            observation: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: (oManager.getVariable()) ? oManager.getVariable() : oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id && oManager.dateRef().isValid == true) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") : ""
                }
                // {
                //     label : "DATE_DELAY",
                //     value : layerDelay(oManager)
                // }
            ],
            forecast: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_RUN",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") : ""
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") + " (" + oManager.dateForecast() + " h)" : ""
                },
                // {
                //     label : "DATE_FORECAST",
                //     value : oManager.dateForecast()
                // },
                // {
                //     label : "DATE_DELAY",
                //     value : layerDelay(this)
                // }

            ],
            DEFAULT: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                }
            ],
            RAINFALL_FIELD: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: oManager.dateRun().format("DD/MM/YYYY HH:mm")
                },
                {
                    label: "CUMULATE_TIME",
                    value: (oHoursOfCumulate) ? oHoursOfCumulate.descr : null
                },
                {
                    label: "AGGREGATION",
                    value: (oSpatialResolution) ? oSpatialResolution.descr : null
                },
                {
                    label: "FROM_DATE",
                    value: (iHoursOfCumulate > -1) ? oManager.dateRun().subtract({hours: iHoursOfCumulate}).format("DD/MM/YYYY HH:mm") : moment.utc(oServices.menuService.getDateFrom()).format("DD/MM/YYYY HH") + ':00'
                },
                {
                    label: "TO_DATE",
                    value: oManager.dateRun().format("DD/MM/YYYY HH:mm")
                }
            ],
            WFSNOWROADS: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: oManager.item().id.replace(/;/g, ' ')
                }
            ],
            FULL: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_RUN",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") : ""
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") : ""
                },
                {
                    label: "DATE_FORECAST",
                    value: oManager.dateForecast()
                },
                {
                    label: "DATE_DELAY",
                    value: layerDelay(oManager)
                }]
        };


        //layer prop
        var oProperties = oManager.props();

        //inizializzo array
        var aProperties = []

        var aHidedProp = ["-", "dir", "Directory"];

        if (oProperties.layerProperties.attributes.length >= 1) {
            oProperties.layerProperties.attributes.forEach(function (prop) {
                if (prop.visible = "false") {
                    prop.visible = true
                    prop.hidden = true;
                }
                var oProp = {
                    label: prop.descr,
                    value: prop.selectedEntry.descr
                }

                // if(!aHidedProp.includes(prop.descr)){
                //     if(prop.hidden ){
                //         aProperties.push(oProp)
                //     }
                // }

                if ((!aHidedProp.includes(prop.descr)) && !prop.hidden) {
                    aProperties.push(oProp)
                }
                ;

            })
        }


        // radar a parte
        //se un radar ritorno tooltip radar
        if ((oManager.name().toUpperCase().indexOf('RADAR')) > -1) {
            return oTooltip['RADAR'].concat(aProperties);
        }

        if ((oManager.name().indexOf('MAPPA_PIOGGIA')) > -1) {
            return oTooltip['RAINFALL_FIELD'].concat(aProperties);
        }

        if (layerObj.category == "observation") {

            return oTooltip[layerObj.category].concat(aProperties);

        } else if (layerObj.category == "forecast") {
            if (layerObj.dataid == "WFSNOWROADS") return oTooltip[layerObj.dataid]
            return oTooltip[layerObj.category].concat(aProperties);

        }


        //altrimenti se cè un tooltip pre preparato carico quello
        if (oTooltip[layer.descr]) return oTooltip[layer.descr];

        //altrimenti tooltip di default
        return oTooltip['DEFAULT'];

    }

    oManager.parseInfo = (data, url) => {

        let propToFilter= [];

        let ret = {
            layerName: oManager.descr(),
            layerDate: oManager.item() ? moment(oManager.item().date).utc().format('DD/MM/YYYY HH:mm') : " - ",
            properties: []
        };

        if (oManager.customprops() && oManager.customprops().hasOwnProperty('parse_info')) {
            propToFilter = oManager.customprops().parse_info
        }



        //layer prop
        const oProperties = oManager.props();

        //inizializzo array
        const aProperties = []

        let measureUnit = ""

        if (oProperties.layerProperties.attributes.length >= 1) {

            oProperties.layerProperties.attributes.forEach(function (prop) {
                //if(debug)console.log(prop)
                if (prop.selectedEntry.referredValues && prop.selectedEntry.referredValues.entry.length > 0) {
                    prop.selectedEntry.referredValues.entry.forEach(function (entry) {
                        if (entry.key == "mu") measureUnit = entry.value
                    })
                }

                let oProp = {
                    name: prop.descr,
                    value: prop.selectedEntry.descr
                }
                if (prop.descr != "-" && (prop.visible == "true" || prop.visible == true) && (prop.hidden != "true" ||prop.hidden != true)) {
                    aProperties.push(oProp)
                };
            })
        }



        if (data.features && data.features.length > 0) {
            data.features.forEach(function (f) {
                if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                    ret.properties.push({
                        name: 'value',
                        'value': f.properties.GRAY_INDEX.toFixed(2) + " " + measureUnit
                    })
                } else {
                    for (let p in f.properties) {

                        if( propToFilter.indexOf(p)== -1) {
                            ret.properties.push({name: p, 'value': f.properties[p] + " " + measureUnit})
                        }
                    }
                }
            })
        }

        ret.properties = ret.properties.concat(aProperties);

        ret.properties.forEach(function (item) {
            if (item.name == 'link') {
                item.html = true;
            } else item.html = false;
        })

        return ret;
    }

    oManager.legend = function (callback) {

        //if (oLegend != null) callback(oLegend);
        //controllo se nelle properties cè l'attributo custom legend
        for (var i = 0; i < oManager.props().layerProperties.attributes.length; i++) {
            var attr = oManager.props().layerProperties.attributes[i]
            if (attr.name == 'customLegend') {

                oLegend = {
                    dynPalette: {},
                    type: "DDS_CUS  TOM_LEGEND",
                    url: attr.selectedEntry.value,
                    layers: oManager.mapLayer().wmsParams.layers,
                }

                callback(oLegend);
            }
        }

        //chiamo api per sapere se c'è una palette dinamica

        oServices.apiService.get('ddsmap/layerstyle/' + layerObj.server.id + '/' + oManager.mapLayer().options.layers, function (data) {
            // apiService.getExt('http://dds.cimafoundation.org/dewetra2/dewapi/ddsmap/layerstyle/'+ layer.server.id+'/'+mapLayer.options.layers , function (data) {
            // mapLayer.options.layers
            if (debug) console.log(data);

            if (oDynamicPaletteSettings.haveDynamicPalette) {

                var delta = (((oDynamicPaletteSettings.max_value - oDynamicPaletteSettings.min_value) / (data.length - 1))).toFixed(2);

                data.forEach(function (item, index) {
                    item.value = oDynamicPaletteSettings.min_value + (index * delta);
                })

                let oLegend = {
                    aPalette: data,
                    dynPalette: oDynamicPaletteSettings,
                    type: layerObj.type.code.toUpperCase(),
                    url: mapLayer._url,
                    layers: mapLayer.wmsParams.layers,
                }
                if (callback) callback(oLegend);

            } else {
                if (data.length > 1) {

                    var legend = {

                        type: "ADVANCED",
                        legend: [{
                            type: "CUSTOM",
                            title: layerObj.name,
                            palette: []
                        }]

                    }

                    legend.legend.palette = []
                    data.forEach(function (val) {
                        legend.legend[0].palette.push(
                            {
                                label: val.label,
                                color: val.color,
                            }
                        )
                    })

                    if (callback) callback(legend);

                }

                let oLegend = {
                    aPalette: data,
                    dynPalette: {},
                    type: layerObj.type.code.toUpperCase(),
                    url: oManager.mapLayer()._url,
                    layers: oManager.mapLayer().wmsParams.layers,
                }
                if (callback) callback(oLegend);
            }


        }, function (err, head) {
            if (debug) console.log(err);
            aPalette = null;
            oLegend = {
                type: layerObj.type.code.toUpperCase(),
                url: oManager.mapLayer()._url,
                layers: oManager.mapLayer().wmsParams.layers,
            }
            if (callback) {
                callback(oLegend)
            } else return null;


        });

    };


    oManager.getVariable= function () {

        const props = oManager.props();

        let str = "";
        if (Array.isArray(props.layerProperties.attributes)) {
            props.layerProperties.attributes.forEach(function (prop) {
                if (prop.name == "operation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (prop.name == "variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (prop.name == "__variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            })
            return str;
        } else {
            if (props.layerProperties.attributes.name == "operation") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            if (props.layerProperties.attributes.name == "variable") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            if (props.layerProperties.attributes.name == "__variable") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
        }

    }

    oManager.getAggregation= function () {
        let str = "";
        const props = oManager.props();
        if (Array.isArray(props.layerProperties.attributes)) {
            props.layerProperties.attributes.forEach(function (prop) {
                if (prop.name == "aggregation") str = prop.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
                if (prop.name == "__aggregation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            })
            return str;
        } else {
            if (props.layerProperties.attributes.name == "aggregation") str = props.layerProperties.attributes.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
            if (props.layerProperties.attributes.name == "__aggregation") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
        }


    }

    oManager.thirdLine = function () {
        return true
    }

    oManager.punctualSerie= function (lat, lon, okCallback, koCallback) {
        console.log("Punctual: ", lat, lon)
        let from = oManager.oServices().menuService.getDateFromUTCSecond() - 432000;// 5 day

        let to = oManager.oServices().menuService.getDateToUTCSecond();


        oManager.oServices().serieService.getPunctualSerie(layerObj.server.id, oManager.props().layerProperties, from, to, lon, lat, okCallback, koCallback);

    }

        oManager.punctualSerieWithVariable= function (lat, lon, selectedVariable,okCallback, koCallback) {
        console.log("Punctual: ", lat, lon)
        let from = oManager.oServices().menuService.getDateFromUTCSecond() - 432000;// 5 day

        let to = oManager.oServices().menuService.getDateToUTCSecond();

        let duplicatedProperties = Object.assign({}, oManager.props().layerProperties);

        duplicatedProperties.attributes.map(attr => {
            if(attr.descr.toUpperCase() == 'VARIABLE'){
                att.selectedEntry = selectedVariable;
            }
        })

            oManager.oServices().serieService.getPunctualSerie(layerObj.server.id, duplicatedProperties, from, to, lon, lat, okCallback, koCallback);

    }

    oManager.punctualSerieWithProperties= function (lat, lon, properties,okCallback, koCallback) {
        console.log("Punctual: ", lat, lon)
        let from = oManager.oServices().menuService.getDateFromUTCSecond() - 432000;// 5 day

        let to = oManager.oServices().menuService.getDateToUTCSecond();

        oManager.oServices().serieService.getPunctualSerie(layerObj.server.id, properties.layerProperties, from, to, lon, lat, okCallback, koCallback);

    }

    oManager.areaSerie= function (points, okCallback, koCallback) {
        console.log("Area: ", points.map(p => p));
        let from = oManager.oServices().menuService.getDateFromUTCSecond() - 432000;// 5 day

        let to = oManager.oServices().menuService.getDateToUTCSecond();


        oManager.oServices().serieService.getAreaSerie(layerObj.server.id, oManager.props().layerProperties, from, to, points, okCallback, koCallback);

    }


    return oManager;

}
