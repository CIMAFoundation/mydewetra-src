
function layerManager_serie_ais_boe_forecast(layerObj) {

    const oManager = layerManager_default(layerObj);

    const oServices = oManager.oServices();

    let additionalLayers = [];

    let isVisible = true;

    const debug = true;

    let dateRun;

    const stationClickListener = (s) => {

        // if(s.target.feature.properties.maxvalue <=-9998){
        //     alert(oServices.$translate.instant('UNAVAILABLE_DATA'));
        //     return;
        // }
        return


        var modalInstance = oServices.$uibModal.open({

            component: 'proofsChartComponent',
            size: 'lg',
            keyboard: false,
            resolve: {
                sectionData: function () {
                    return {
                        section : s.target.feature.properties,
                        prop : oManager.getLayerData().prop,
                        serverId: oManager.layerObj().server.id,
                        serieId : oManager.getLayerData().prop.id,
                        layerObj: oManager.layerObj(),
                        oManager: oManager
                    };
                }
            }
        });

    }

    const stationInfoMouseOver = (s)=>{

        const dateLabel = s.target.feature.properties.datelabel;

        const layers = oManager.mapLayer().getLayers();
        for (let id in layers){
            if (layers[id].feature && layers[id].feature.properties && layers[id].feature.properties.datelabel == dateLabel){
                for(let l in layers[id]._layers){
                    layers[id]._layers[l].setStyle({
                        radius: 6,
                        fillColor: 'red',
                        color: 'black',
                        weight: 1,
                        opacity: 1,
                        fillOpacity: 1
                    }).bringToFront();
                }

            }else{
                for(let l in layers[id]._layers){
                    layers[id]._layers[l].setStyle({
                        radius: 6,
                        fillColor: 'green',
                        color: 'black',
                        weight: 1,
                        opacity: 0.5,
                        fillOpacity: 0.5
                    }).bringToBack()
                }
            }
        }


        if(oManager.getWarningInfo()){
            oManager.getWarningInfo().mouseOver('SENSOR_FLOODPROOF_SERIES',oManager.mapLayer()._leaflet_id, s.target.feature.properties  )
        }
    }

    const stationInfoMouseOut = (s)=>{
        const layers = oManager.mapLayer().getLayers();
        for (let id in layers){
                for(let l in layers[id]._layers){
                    layers[id]._layers[l].setStyle({
                        radius: 6,
                        fillColor: 'green',
                        color: 'black',
                        weight: 1,
                        opacity: 1,
                        fillOpacity: 1
                    })
                }

        }
        if(oManager.getWarningInfo()){
            oManager.getWarningInfo().mouseOut('SENSOR_FLOODPROOF_SERIES',oManager.mapLayer()._leaflet_id)
        }
    }

    // oManager.customprops = (layer, onFinish) => {
    //     if (oManager.layerObj().hasOwnProperty("customprops")) {
    //         return JSON.parse(oManager.layerObj().customprops)
    //     }
    // }

    // oManager.customprops = function(){
    //     var _this = this;
    //     debugger
    //     if(_this.layerObj().hasOwnProperty("customprops")){
    //         return JSON.parse(_this.layerObj().customprops)
    //     }
    // };

    const serieStyle = {
        'generic' : 'serie_generic_Icon',
        'africa.floodproofs2.nwpgfsdet' : 'serie_FP_auc_Icon',
        'bolivia.droughtproofs.spistations' : 'droughtproods_SPI_Icon',
        'bolivia.droughtproofs.speistations': 'droughtproods_SPI_Icon',
        // 'nwp_gfs_gy_realtime.floodproofs.deterministic': 'droughtproods_SPI_Icon',
        // 'rf_gfs_gy_realtime.floodproofs.deterministic' : 'droughtproods_SPI_Icon',
        // 'obs_sat_gy_realtime.floodproofs.deterministic': 'droughtproods_SPI_Icon',
        // 'nwp_wrf_gy_realtime.floodproofs.deterministic': 'droughtproods_SPI_Icon',
    };

    chooseSerieStyle = (serie) => {

        try {
            if (oManager.customprops() && oManager.customprops().hasOwnProperty('serieStyle')) {
                // console.info("Style loaded by custom prop" );
                return oManager.customprops().setStyle()
            }
        }catch (e) {
            console.log(e);
        }

        if(serieStyle[serie]){
            return serieStyle[serie];
        }else{
            return serieStyle['generic'];
        }
    };

    const calculateLastNow = (data) => {
        let featWithTime = data.features.filter(f => moment(f.properties.run,'YYYYMMDDHHmm').isValid());
        if (featWithTime.length == 0) {
            console.log("no features");
            return ('-');
        };
        dateRun = featWithTime.reduce((previousValue, currentValue, currentIndex, array) => {
            let curr = (currentValue && currentValue.properties && currentValue.properties.run)?moment(currentValue.properties.run,'YYYYMMDDHHmm'):moment.invalid();
            let prev = (previousValue && previousValue.properties && previousValue.properties.run)?moment(previousValue.properties.run,'YYYYMMDDHHmm'):moment.invalid();
            if(curr.isValid() && prev.isValid()){
                if(curr.isSameOrAfter(prev)){
                    console.log(curr.format('LL'))
                    return curr;
                }else {
                    console.log(prev.format('LL'))
                    return prev;
                }
            }else return curr
        })

        //console.log(time)
    }


    oManager.load = (onFinish) => {

        oManager.loadAdditionalLayer();

        if (oManager.mapLayer())oServices.mapService.removeLayer(oManager.mapLayer());

        oServices.serieService.getLayerData(oManager.layerObj(),(layerData) => {

            oManager.setLayerData(layerData);

            oServices.floodproofsService.layer(oManager.layerObj().server.id, oManager.getLayerData().layer.dataid, (data) => {

                //data.features = data.features.filter((f, index)=>{return index <100})

                try {
                    calculateLastNow(data);
                }catch (e) {
                    console.log(e)
                }


                oManager.setTheGeoJson(data);

                oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(oManager.getTheGeoJson(), oManager.layerObj()['descr'], {

                    pointToLayer: function(feature, latlng) {

                        let geojsonMarkerOptions = {
                            radius: 6,
                            fillColor: 'green',
                            color: 'black',
                            weight: 1,
                            opacity: 1,
                            fillOpacity: 1
                        };

                        return L.circleMarker(latlng, geojsonMarkerOptions);
                    }

                }, stationClickListener,stationInfoMouseOver, stationInfoMouseOut));

                if (onFinish) onFinish()
            });
        })
    }



    oManager.setVisible = function (b) {

        if(!b) {
            if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());
            oManager.removeAdditionalLayer();
        }else {
            oManager.loadAdditionalLayer();
            oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(oManager.getTheGeoJson(), oManager.layerObj()['descr'], {

                pointToLayer: function(feature, latlng) {

                    let geojsonMarkerOptions = {
                        radius: 6,
                        fillColor: 'green',
                        color: 'black',
                        weight: 1,
                        opacity: 1,
                        fillOpacity: 1
                    };

                    return L.circleMarker(latlng, geojsonMarkerOptions);
                }

            }, stationClickListener,stationInfoMouseOver, stationInfoMouseOut));
        }

        isVisible = b
    }

    oManager.isVisible = function () {
        return isVisible
    }

    oManager.layerTooltip = function () {

        let p = [{
                label: "LAYER_NAME",
                value: oManager.name()
            },
            {
                label: "LAYER_DESCRIPTION",
                value: oManager.descr()
            }];

        if (oManager.getMetaData().length > 0){
            p.push({
                label: "LAYER_META",
                value: oManager.getMetaData()
            })
        }

        return p;
    }

    oManager.thirdLine= function () {
        return true
    }



    oManager.getVariable = function () {

        if(dateRun && dateRun.isValid()) return oServices.$translate.instant('DATE_RUN') + ' : ' + dateRun.format('YYYY/MM/DD  HH:mm');

    }


    delete oManager.showProps;


    return oManager;

}
