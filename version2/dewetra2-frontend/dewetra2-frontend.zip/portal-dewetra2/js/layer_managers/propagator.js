/**
 * Created by mirkodandrea on 05/09/17.
 */

plotty.addColorScale("propagator_colorscale", ["green", "yellow", "red", "violet"], [0, 0.25, 0.50, 0.75]);

function layerManager_static_propagator(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService) {
    const propagatorService = function(){
        const $http = angular.injector(["ng"]).get("$http");
        const $window = angular.injector(["ng"]).get("$window");
        const $timeout = angular.injector(["ng"]).get("$timeout");
        const apiService = angular.element(document.querySelector('.ng-scope')).injector().get('apiService');
        this.server = window.app.url.propagatorServerUrl;
        const server = this.server;


        const color_range = chroma
            .scale(['rgba(0,0,0,0)', 'green', 'yellow', 'red', 'violet'])
            .domain([0, 255]);

        this.getRuns = () => apiService.getPropagator(server + '/propagator_api/api/runs/?limit=0');

        this.getRun = rid => $http.get(server + '/propagator_api/api/runs/' + rid + '/')
            .then(res => res.data, err => console.log(err))
            .then(data => {
                data.outputs.map(function(o){
                    o.timeref = moment(o.timeref).format('YYYY-MM-DD HH:mm');
                });
                return data;
            });

        function sortIsochones(geojson){
            const r_features = _.sortBy(geojson.features, [f => -f.properties.time]);
            geojson.features = r_features;
            return geojson;
        }

        function createIsochroneLayer(geojson, SHOW_VALUE, warningInfo){
            const layer = L.geoJson(geojson, {
                filter: (feature, layer) => feature.properties.value == SHOW_VALUE,
                style: feature => ({
                    color: 'hsl(' + 50*(1-feature.properties.time/60/48) + ', 100%' + ', 50%)',
                    weight: 2
                }),
                onEachFeature: (feature, layer) => {
                    if (!feature.properties || !feature.properties.time || !feature.properties.time) { return; }

                    const coords = layer.getLatLngs();
                    const area = coords.reduce((a, c) => a + L.GeometryUtil.geodesicArea(c), 0);
                    const areaStr = L.GeometryUtil.readableArea(area, true);
                    const hours = feature.properties.time/60;
                    feature.properties.area = areaStr;
                    feature.properties.hours = hours;

                    layer.on('mouseover', e => {
                        layer.setStyle({weight: 5, color:'yellow'});
                        warningInfo.mouseOver('PROPAGATOR', layer._leaflet_id, feature);
                    });
                    layer.on('mouseout', e => {
                        layer.setStyle(layer.options.style(layer.feature));
                        warningInfo.mouseOut('PROPAGATOR', layer._leaflet_id);
                    });
                },
                pane: 'propagator-isochrone'
            });

            return layer;
        }

        this.getGeojsonLayer = (run, SHOW_VALUE, warningInfo) => {
            if(run.isochrones.length==0){
                return $timeout(() => null);
            }
            const geojson_file = run.isochrones[0].file;
            const geojson_url = server + geojson_file;

            return $http.get(geojson_url)
                .then(res => res.data)
                .then(geojson => sortIsochones(geojson))
                .then(geojson => createIsochroneLayer(geojson, SHOW_VALUE, warningInfo))
        };

        this.getGeotiffLayer = (run, n) => {
            const tiff_file = run.outputs[n].file;

            if(!tiff_file) return null;

            const tiff_url = server + tiff_file;

            const raster_layer = L.leafletGeotiff(
                tiff_url,
                {
                    band: 0,
                    displayMin: 1,
                    displayMax: 255,
                    //name: 'Wind speed',
                    colorScale: 'propagator_colorscale',
                    clampLow: false,
                    clampHigh: true
                }
            );
            return raster_layer;
        };


        this.getGeotiffLayerPromise = (run, n) => {
            const tiff_file = run.outputs[n].file;
            if (!tiff_file) return null;
            const tiff_url = server + tiff_file;
            return fetch(tiff_url, { responseType: "arraybuffer" })
                .then(r => r.arrayBuffer())
                .then(buffer => L.ScalarField.fromGeoTIFF(buffer))
                .then(s => L.canvasLayer.scalarField(s, {
                    color: color_range,
                    pane: 'propagator-raster'
                }));
        };


        return this;
    };

    const manager = layerManager_static(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService);
    const service = propagatorService();

    let run = null;
    let runs = null;
    let layerGroup = null;

    let rasterLayer = null;
    let isochroneLayer = null;

    let currentOutput = null;
    let showIsochrones = true;

    let visible = true;
    let infoAvaialability = {
        index: 0,
        length: 10,
        reverse: false
    };

    manager.parseInfo = data => ({
        layerName: manager.descr(),
        properties : []
    });

    const map = mapService.getMap();
    map.createPane('propagator-raster');
    const pane = map.createPane('propagator-isochrone');
    const initialZIndex = pane.style['z-index'];

    selectRun = run_id => {
        layerGroup && mapService.layersGroup.removeLayer(layerGroup);
        layerGroup = L.layerGroup([], {pane:'propagator'});

        layerGroup.bringToFront = () => {
            rasterLayer.bringToFront();
            if(isochroneLayer){
                isochroneLayer.bringToFront();
            }
            pane.style['z-index'] = 9999;
        }
        layerGroup.bringToBack = () => {
            rasterLayer.bringToBack();
            if(isochroneLayer){
                isochroneLayer.bringToBack();
            }
            pane.style['z-index'] = initialZIndex;
        }

        return service.getRun(run_id)
            .then(selected_run => {
                run = selected_run;
                infoAvaialability.length = run.outputs.length;
                return run;
            })
            .then(run => service.getGeojsonLayer(run, 0.5, warningInfo))
            .then(geojson_layer => {
                isochroneLayer = geojson_layer;
                if(isochroneLayer){
                    showIsochrones && layerGroup.addLayer(isochroneLayer);
                }

                layerGroup.options = {
                    opacity: 0.5
                };
                mapService.layersGroup.addLayer(layerGroup, { name: 'layergroup_propagator'});
                manager.setMapLayer(layerGroup);
            })
            .then(() => selectRaster(run.outputs.length-1))
            .then(() => run);

    }


    selectRaster = n => {
        currentOutput = run.outputs[n];
        infoAvaialability.index = n;
        service.getGeotiffLayerPromise(run, n)
            .then(new_raster_layer => {
                if(!new_raster_layer){ return null; }
                layerGroup.clearLayers();
                layerGroup.addLayer(new_raster_layer, true);
                layerGroup.addLayer(isochroneLayer, true);
                rasterLayer = new_raster_layer;
            });
    }


    showHideIsochrones = () => {
        if(!showIsochrones && layerGroup.hasLayer(isochroneLayer)){
            layerGroup.removeLayer(isochroneLayer);
        }else{
            if(!layerGroup.hasLayer(isochroneLayer)){
                layerGroup.addLayer(isochroneLayer);
            }
        }
    }

    manager.load = onFinish => {
        service.getRuns()
            .then( data => runs = data.objects.filter(run => run.user == $rootScope.acSession.user.id))
            .then( () => selectRun(runs[0].id))
            .then( () => onFinish && onFinish());
    };

    let opacityValue = 0.5;
    manager.setOpacity = value => {
        if (!value){ return; }
        opacityValue = value;
        layerGroup && rasterLayer && rasterLayer.setOpacity(opacityValue);
        layerGroup && isochroneLayer && isochroneLayer.setStyle({opacity:opacityValue});
    };

    manager.getOpacity = () => opacityValue;
    manager.type= () => "PROPAGATOR";
    manager.typeDescr = () => "PROPAGATOR_LAYER";
    manager.canMovie = () => true;

    const _layerObj = manager.layerObj;
    manager.layerObj = () => {
        /**
         * overrides the boundaries for the current layer
         * using the boundaries of the isochrone layer if present
         */
        if(!isochroneLayer) return _layerObj();

        const bounds = isochroneLayer.getBounds();
        return {
            lats: bounds.getSouth(),
            latn: bounds.getNorth(),
            lonw: bounds.getWest(),
            lone: bounds.getEast()
        }
    };

    let playHook = false;
    manager.play = () => {
        if(playHook){
            $interval.cancel(playHook);
            playHook = false;
        }else {
            playHook = $interval(() => manager.goForward(), 500);
        }
    };

    manager.canPlay = () => !playHook;

    manager.infoAvaialability = (index, length) => {
        if(index != null && length != null){
            infoAvaialability.index = index;
            infoAvaialability.length = length
        }
        return infoAvaialability
    };

    manager.onDateChange = onFinish => console.log('ondatechange');

    manager.goForward = () => {
        infoAvaialability.index = (infoAvaialability.index+1) % infoAvaialability.length;
        selectRaster(infoAvaialability.index);
    };

    manager.goBackward = () => {
        infoAvaialability.index = (infoAvaialability.index-1) % infoAvaialability.length;
        selectRaster(infoAvaialability.index);
    };

    manager.legend = () => ({
        type:"ADVANCED",
        legend:[{
            type:"CUSTOM",
            title: "PROPAGATOR_PALETTE",
            palette:[{
                label:"probabity",
                color:"green",
                sign:"<=",
                value:25,
                mu:"%",
                dec:0
            },{
                label:"probabity",
                color:"yellow",
                sign:"<=",
                value:50,
                mu:"%",
                dec:0
            },{
                label:"probabity",
                color:"red",
                sign:"<=",
                value:75,
                mu:"%",
                dec:0
            },{
                label:"probabity",
                color:"violet",
                sign:">",
                value:75,
                mu:"%",
                dec:0
            }]
        }]
    })

    manager.layerTooltip = () => [
        {
            label : "LAYER_NAME",
            value : manager.name()
        },
        {
            label : "PROPAGATOR_RUN",
            value : run.name
        },
        {
            label : "PROPAGATOR_TIMESTAMP",
            value : run.timestamp
        },
        {
            label : "PROPAGATOR_TIMESTEP",
            value : currentOutput.timeref
        }
    ]

    let warningInfo = null;
    manager.setWarningInfo = wi => warningInfo = wi;

    manager.setVisible = b => {
        visible = b;
        if (!b) layerGroup.clearLayers();
        else {
            rasterLayer && layerGroup.addLayer(rasterLayer);
            layerGroup && showIsochrones && layerGroup.addLayer(isochroneLayer);
        }
    };

    manager.isVisible = () => visible;

    manager.showProps = onFinish => {
        const layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties_propagator.html',
            controller: ['$scope', '$uibModalInstance', 'propagatorService',function ($scope, $uibModalInstance, propagatorService){
                $scope.sel_run_data = angular.copy(run);
                $scope.runs = runs;
                $scope.sel_time = currentOutput;
                $scope.show_isochrones = showIsochrones;

                if($scope.sel_run_data) {
                    const selectedRuns = runs.filter(r => $scope.sel_run_data.id == r.id);
                    if(selectedRuns.length>0) $scope.sel_run = selectedRuns[0];
                }

                $scope.update = () => $uibModalInstance.close($scope);

                $scope.switchRun = () => {
                    propagatorService
                        .getRun($scope.sel_run.id)
                        .then(data => $scope.sel_run_data = data);
                };
                $scope.closePopup =  () => $uibModalInstance.dismiss()
            }],
            size: "lg",
            resolve: {
                propagatorService:service
            }
        });

        layerPropModal.result
            .then(res => {
            if(run.id !== res.sel_run_data.id) {
                showIsochrones = res.show_isochrones;
                selectRun(res.sel_run_data.id)
                    .then( _run => {
                        const n = _.findIndex(_run.outputs, o => o.id == res.sel_time.id);
                        selectRaster(n);
                    });
            }else{
                if(currentOutput.id !== res.sel_time.id) {
                    var n = _.findIndex(res.sel_run_data.outputs, o => o.id == res.sel_time.id);
                    selectRaster(n);
                }
                if(showIsochrones != res.show_isochrones){
                    showIsochrones = res.show_isochrones;
                }
                showHideIsochrones();
            }

        });
    };


    return manager;
}
