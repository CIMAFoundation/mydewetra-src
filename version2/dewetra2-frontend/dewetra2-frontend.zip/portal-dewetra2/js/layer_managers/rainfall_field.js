/**
 * Created by doy on 19/06/15.
 */

function layerManager_rainfall_field(layerObj, mapService, layerService, serieService, menuService, $uibModal) {

    var layer = layerObj;

    var props = null;
    var item = null;
    var mapLayer = null;

    var refresh = {
        status: true,
        refreshTime : 10000,
        lastRefresh: null
    };

    var iOpacity = 100;

    var downloadUrl = null;


    function update(newProps, newItem, onFinish) {

        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        layerService.republishLayer(layer, newProps, from, to, newItem, function (data) {
            props = newProps;
            item = newItem;
            if(mapLayer) iOpacity = mapLayer.options.opacity
            if (mapLayer) mapService.removeLayer(mapLayer);
            mapLayer = mapService.addWmsLayer(layer.server.url+'/wms', data.layerid);
            if (iOpacity) mapLayer.setOpacity(iOpacity);
            if (onFinish) onFinish()
        })
    }

    function goForward(){}

    function goBack(){}

    return {

        layerObj: function () {
            return layer
        },

        props: function () {
            return props
        },

        item: function () {
            return item
        },
        dateRun: function(){
            var aSplittedDate =  item.id.split(';');
            var dateRun= moment.utc(parseInt(aSplittedDate[0]));
            return dateRun;

        },
        //dateRef: function(){
        //    var aSplittedDate =  item.id.split(';');
        //    var dateRef = moment.utc(parseInt(aSplittedDate[0]));
        //    return dateRef;
        //},
        dateRef: function(){
                this.descr()
            },
        dateRefFormatted: function(){
            var sDateRunDateRef =  item.id;

            if(sDateRunDateRef.indexOf(";") > -1){
                //controllo se osservazione o previsione
                var bLayerType = l.category == "observation";
                //se osservazione la data di run corrisponde alla dateref e ne visualizzo solo una
                if(bLayerType){
                    var aDateRunDateRef = sDateRunDateRef.split(";");
                    var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                    //var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm')

                    return sDateRun
                }else{
                    //se previsione distinguo le due date
                    var aDateRunDateRef = sDateRunDateRef.split(";");
                    var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                    var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                    return sDateRef + " "+" (Run:"+ sDateRun+")"
                }
                //se ha solo una data non mi pongo il problema
            }else{
                var sDateRun = moment(new Date(parseInt(sDateRunDateRef))).utc().format('DD/MM/YYYY HH:mm');
                return sDateRun
            }

        },
        dateForecast :function(){
            var aSplittedDate =  item.id.split(';');
            var diff =((parseInt(aSplittedDate[1]))-(parseInt(aSplittedDate[0])));
            if(diff > 0 ) {
                diff = diff / (1000 * 60 * 60);
                return diff;
            }else return 0;
        },

        mapLayer: function () {
            return mapLayer
        },

        load: function(onFinish) {
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            islist = function (attr) {
                return attr.type.toLowerCase() == 'list'
            };

            //precarico le proprietà
            layerService.getLayerProperties(layerObj, function (data) {

                data.layerProperties.attributes.forEach(function (attr) {
                    if (islist(attr)) {
                        for (var i = 0; i < attr.entries.length; i++) {
                            if (attr.entries[i].value == attr.selectedEntry.value) {
                                attr.selectedEntry = attr.entries[i];
                                break;
                            }
                        }
                    }
                });
                props = data;
            });
            layerService.publishLayer(layer,from,to,function(data){
                props = data.properties;
                item = data.item;
                mapLayer = mapService.addWmsLayer(data.serverurl+'/wms', data.layerid);

                // ANTO 20170619: gestisco la possibilità di scaricare shp o raster
                downloadUrl = ((data.layertype && (data.layertype.toUpperCase() == 'VECTOR'))?
                                data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                                data.serverurl + '/ddsData/' + data.layerid + '.tiff');

                //downloadUrl = data.serverurl + '/ddsData/' + data.layerid + '.tiff';          ORG!!!

                if (onFinish) onFinish()

            })
        },

        name: function() {
            return layer.name
        },



        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        descr: function () {
            if (!props) return layer.descr;
            return props.layerProperties.attributes[3].selectedEntry.descr;

        },

        draggable: function () {
            return true;
        },

        haveInfo: function () {
            return true;
        },

        legend:function () {

            return {
                type: layerObj.type.code.toUpperCase(),
                url: mapLayer._url,
                layers:mapLayer.wmsParams.layers,
            }
        },

        typeDescr: function () {
            return "RAINFALL_FIELD"
        },

        haveAudio: function(){
            return false
        },

        canMovie: function(){
            return false
        },

        onDateChange:function(onFinish){

            //precarico anche l'opzione corrente cosi basta cliccare aggiorna per refreshare
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //chiedo layer avaiability dopodiche uso la update

            layerService.getLayerAvailability(layer, props, from, to, function (data) {
                update(props, data[0], onFinish)
            })
        },
        layerTooltip: function(){

            var layerDelay = function (layerManagerObj) {


                try{
                    var oReferenceDate = layerManagerObj.dateRef().utc().toDate()
                }catch(err){
                    return layerManagerObj.descr()
                }

                // Get Now
                var oDate = new Date();

                //console.log("Now  = " + oDate);
                //console.log("Ref  = " + oReferenceDate);

                // Compute time difference
                var iDifference = oDate.getTime()-oReferenceDate.getTime();

                // How it is in minutes?
                var iMinutes = 1000*60;

                var iDeltaMinutes = Math.round(iDifference/iMinutes);

                var sTimeDelta = "";

                if (iDeltaMinutes>0){
                    if (iDeltaMinutes<60 ) {
                        // Less then 1h
                        sTimeDelta += iDeltaMinutes + " min. fa";
                    }
                    else if (iDeltaMinutes< 60*24) {
                        // Less then 1d
                        var iDeltaHours =  Math.round(iDeltaMinutes/60);
                        sTimeDelta += iDeltaHours + " ore fa";
                    }
                    else {
                        // More than 1d
                        var iDeltaDays =  Math.round(iDeltaMinutes/(60*24));
                        sTimeDelta += iDeltaDays + " giorni fa";
                    }
                }else{
                    if (iDeltaMinutes> -60 ) {
                        // Less then 1h
                        sTimeDelta += "Fra: "+Math.abs(iDeltaMinutes)+" Minuti" ;
                    }
                    else if (iDeltaMinutes > -60*24) {
                        // Less then 1d
                        var iDeltaHours =  Math.round(iDeltaMinutes/60);
                        sTimeDelta += "Fra: "+Math.abs(iDeltaHours)+" Ore" ;
                    }
                    else {
                        // More than 1d
                        var iDeltaDays =  Math.round(iDeltaMinutes/(60*24));
                        sTimeDelta += "Fra: "+Math.abs(iDeltaDays)+" Giorni";
                    }
                }


                return sTimeDelta;
            };
            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : this.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : layer.descr
                },
                {
                    label : "DATE_REF",
                    value : this.dateRun().format("DD/MM/YYYY HH:mm")
                },
                {
                    label : "CUMULATE_TIME",
                    value : props.layerProperties.attributes[3].selectedEntry.descr
                },
                {
                    label : "AGGREGATION",
                    value : props.layerProperties.attributes[5].selectedEntry.descr
                },
                {
                    label : "FROM_DATE",
                    value : this.dateRun().subtract({hours:props.layerProperties.attributes[3].selectedEntry.value}).format("DD/MM/YYYY HH:mm")
                },
                {
                    label : "TO_DATE",
                    value : this.dateRun().format("DD/MM/YYYY HH:mm")
                }

            ];
            return tooltipObj;
        },

        refreshable : function () {
            return refresh.status;
        },

        refreshProperty: function(){
            return refresh
        },

        lastRefresh : function(){
            return refresh.lastRefresh
        },

        setLastRefresh: function(time){
            refresh.lastRefresh  = time
        },

        setRefresh: function (isRefreshable) {
            refresh.status = isRefreshable;
        },

        refresh:function(onFinish){

            //controllo se ci sono gia delle proprieta caricate
            if (menuService.isRealTime() ) {
                update(props, item, onFinish)
            }
        },

        showProps: function (onFinish) {
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties.html',
                controller: "layerPropertiesController",
                size: "lg",
                resolve: {
                    params: function() {
                        return {
                            layer: mapLayer
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj.props, obj.data, onFinish)
            }, function () {
                console.log("CANCEL")
            });
        },

        getDownloadUrl: function () {
            return downloadUrl
        },
        update: function(obj, onFinish){
            update(obj.props, obj.data, onFinish)
        }
    }

}