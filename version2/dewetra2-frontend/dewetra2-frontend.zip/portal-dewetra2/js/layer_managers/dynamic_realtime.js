/**
 * Created by Dario Rubado on 12/09/16.
 */

function layerManager_dynamic_realtime(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope) {

    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout)

    manager.setRefresh(false)
    //test
    manager.refreshable = function () {
        return false;
    }

    var deregisterNewAcq = $rootScope.$on('NEWACQ', function (event, data) {
        //console.log("new data acquired: " + data)

        var props = manager.props()['layerProperties'];

        // console.log(props['id'] + "==" + data)

        if (props['id'] != data) return;

        console.log("updating " + data + "...")

        var propsCopy = JSON.parse(JSON.stringify(props))

        if (!Array.isArray(propsCopy['attributes'])) propsCopy['attributes'] = [propsCopy['attributes']]
        propsCopy['attributes'].forEach(function (attr) {
            if (!Array.isArray(attr['entries'])) attr['entries'] = [attr['entries']]
            attr['entries'].forEach(function (entry) {

                rvs = []
                if (entry.referredValues && entry.referredValues.entry) {
                    if (!Array.isArray(entry.referredValues.entry)) entry.referredValues.entry = [entry.referredValues.entry]
                    entry.referredValues.entry.forEach(function (rv) {
                        rvs.push({entry: rv})
                    })
                }
                entry.referredValues = rvs
            })

            rvs = []
            if (attr.selectedEntry.referredValues && attr.selectedEntry.referredValues.entry) {
                if (!Array.isArray(attr.selectedEntry.referredValues.entry)) attr.selectedEntry.referredValues.entry = [attr.selectedEntry.referredValues.entry]
                attr.selectedEntry.referredValues.entry.forEach(function (rv) {
                    rvs.push({entry: rv})
                })
            }
            attr.selectedEntry.referredValues = rvs
        })

        //check
        var aLayerCounter = [];
        var moreThan1 = false;

        if (mapService.oLayerList.aDraggable.length > 0){
            mapService.oLayerList.aDraggable.forEach(function (layerMan) {
                if (layerMan.hasOwnProperty("props")){
                    if (layerMan.props() && layerMan.props().hasOwnProperty('layerProperties')) {
                        var props = layerMan.props()['layerProperties'];
                        (angular.isUndefined(aLayerCounter[props['id']])) ? aLayerCounter[props['id']] = 1 : aLayerCounter[props['id']] = aLayerCounter[props['id']] + 1;
                    }
                }
            });
        }
        if (mapService.oLayerList.aUndraggable.length > 0){
            mapService.oLayerList.aUndraggable.forEach(function (layerMan) {
                if (layerMan.hasOwnProperty("props")){

                    if (layerMan.props() && layerMan.props().hasOwnProperty('layerProperties')){
                        var props = layerMan.props()['layerProperties'];
                        (angular.isUndefined(aLayerCounter[props['id']]))?aLayerCounter[props['id']] = 1:aLayerCounter[props['id']] =aLayerCounter[props['id']] + 1;
                    }

                }

            });
        }

        if (aLayerCounter[props['id']]>1) moreThan1 = true;


        if(!moreThan1){
            $rootScope.realTimeSocket.send(JSON.stringify(propsCopy));
            console.log(propsCopy);
        }else{
            var item = manager.item();
            manager.update(manager.props(), item);
        }


    })

    var deregisterNewLayer = $rootScope.$on('NEWLAYER', function (event, data) {

        var props = manager.props()['layerProperties'];

        var toks = data.split("|");

        if((toks[0].indexOf('RAINMAP_ITALY_MON') == 0) && (props['id'] == 'RAINMAP_ITALY')){
            return
        }

        if (toks[0].indexOf(props['id']) == 0 ) {
            console.log("changing layer " + props['id'] + "...")
            var item = JSON.parse(toks[1]);
            manager.setNewLayer(manager.props(), item, toks[0]);
        }


    })

    manager.removeListener = function () {
        console.log("unregistering realtime listeners")
        if (deregisterNewAcq) deregisterNewAcq()
        if (deregisterNewLayer) deregisterNewLayer()
    }

    return manager;
}
