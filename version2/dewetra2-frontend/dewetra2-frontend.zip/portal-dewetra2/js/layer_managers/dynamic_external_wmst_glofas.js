/**
 * Created by Mirko on 26/02/18.
 */

function layerManager_dynamic_external_wmst_glofas(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout) {

    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout);
    var $q = angular.injector(["ng"]).get("$q");
    var $sce = angular.injector(["ng"]).get("$sce");
    var $window = angular.injector(["ng"]).get("$window");
    var items = null;
    var visible = true;
    var layer = null;

    manager.parseInfo = function(data, url){

        // //layer prop
        // var oProperties = this.props();
        //
        // //inizializzo array
        // var aProperties = []
        //
        // var measureUnit = ""
        //
        // if(oProperties.layerProperties.attributes.length >=1){
        //
        //     oProperties.layerProperties.attributes.forEach(function (prop) {
        //         //if(debug)console.log(prop)
        //         if(prop.selectedEntry.referredValues&&prop.selectedEntry.referredValues.entry.length >0){
        //             prop.selectedEntry.referredValues.entry.forEach(function (entry) {
        //                 if (entry.key == "mu") measureUnit = entry.value
        //             })
        //         }
        //
        //         var oProp = {
        //             name : prop.descr,
        //             value : prop.selectedEntry.descr
        //         }
        //         if (prop.descr != "-") aProperties.push(oProp);
        //     })
        // }
        //
        // var ret = {
        //     layerName: this.descr(),
        //     layerDate: " - ",
        //     properties : aProperties
        // };


        //console.log(data)
        //console.log(url)


        // const a = document.createElement('a');
        // a.href = url;
        // a.target = '_blank'
        try {
            $window.open(url, 'newwindow', 'width=500,height=1000,toolbar=no,location=no,resizable=yes');
        }catch (e) {
            window.open(url, 'newwindow', 'width=500,height=1000,toolbar=no,location=no,resizable=yes');
        }

        //'width=900,height=750,toolbar=no,scrollbars=no,location=no,resizable =yes’
        //return false;"
        // document.body.appendChild(a);
        // a.click()

        // var ret = {
        //     layerName: this.descr(),
        //     layerDate: " - ",
        //     properties : [{name: '', value: url, iframe: true},{name: '', value: url, popup: true}]
        // };

        //return ret;
    }

    //layerObj.dataid = 'RPG80'


    manager.layerId = layerObj.dataid;
    var WMSParams = {
        service: 'WMS',
        request: 'GetMap',
        version: '1.3.0',
        layers: manager.layerId,
        styles: '',
        format: 'image/png',
        transparent: true,
        infoFormat: 'text/html'
    };

    function loadLayerAvailability(){
        var t = menuService.getDateTo();
        t.setUTCHours(0, 0, 0, 0);
        var date = moment(t).toDate();
        var utc_date = moment(t).utc();
        var dateYesterday = moment(t).subtract(1, 'days').toDate()
        var utc_dateYesterday = moment(t).subtract(1, 'days').utc()
        return [
            {
                date: utc_dateYesterday,
                description: dateYesterday.toUTCString(),
                date_string: utc_dateYesterday.toISOString(),
                id: '' + utc_dateYesterday.valueOf()
            },
            {
                date: utc_date,
                description: date.toUTCString(),
                date_string: utc_date.toISOString(),
                id: '' + utc_date.valueOf()
            }
        ]
    }

    function update(newProps, newItem, onFinish, bScrambling) {
        manager.setProps(newProps);
        manager.setItem(newItem);
        if (manager.mapLayer()) {
            manager.setlayerOpacity(manager.mapLayer().options.opacity);
            mapService.removeLayer(manager.mapLayer());
        }

        if (manager.layerOpacity()) {
            manager.mapLayer().setOpacity(manager.layerOpacity())
        }

        if (onFinish) onFinish();
        manager.setCurrentLayer();
    }

    manager.hardcodedProperties = function() {
        return true;
    };

    manager.legend = function () {
        var legend_url = layerObj.server.url;
        return {
            type: 'DYNAMIC',
            layers: layerObj.dataid,
            url: legend_url
        }
    };

    manager.initializeMoveOptions = function() {
        items = loadLayerAvailability()
        manager.setCanMovie(items.length > 1);
        if (manager.canMovie()) {
            //cerco l'index del layer caricato precedentemente
            var iIndexLoadedLayer = _.findIndex(items, function(item) {
                return item.id == manager.item().id;
            });
            //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
            iIndexLoadedLayer = (iIndexLoadedLayer > -1)?iIndexLoadedLayer:1;

            //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
            manager.infoAvaialability(iIndexLoadedLayer + 1, items.length);
            manager.infoAvaialability().reverse = items[0].date > items[1].date;
        }
    };

    manager.layerProps = {
        "layerProperties": {
            "attributes": [
            ],
            "data": manager.layerId,
            "description": layerObj.descr,
            "id": manager.layerId,
            "longDescription": layerObj.descr
        }
    };


    manager.load = function(onFinish) {
        items = loadLayerAvailability()
        manager.setProps(manager.layerProps);
        var item = items[items.length-1];
        manager.setItem(item);
        //inizializzo le opzioni per la movie
        manager.initializeMoveOptions();
        if (onFinish) onFinish();
        manager.setCurrentLayer();
    };


    manager.onDateChange = function(onFinish){
        items = loadLayerAvailability()
        if (manager.infoAvaialability) manager.infoAvaialability(items.length, items.length);
        update(manager.props(), items[items.length - 1], onFinish)
    };

    manager.goForward = function() {
        var iIndexLoadedLayer = _.findIndex(items, function (availableItem) {
            return availableItem.id == manager.item().id;
        });

        iIndexLoadedLayer = (iIndexLoadedLayer > -1)? (iIndexLoadedLayer + 1) : 1;

        if (manager.infoAvaialability) manager.infoAvaialability((iIndexLoadedLayer + 1), items.length);

        update(manager.props(), items[iIndexLoadedLayer], function() {
            mapService.oLayerList.updateLayer(manager)
        });
    };

    manager.goBackward = function() {
        var iIndexLoadedLayer = _.findIndex(items, function (availableItem) {
            return availableItem.id == manager.item().id;
        });

        iIndexLoadedLayer = (iIndexLoadedLayer > -1)? iIndexLoadedLayer : 1;
        if (manager.infoAvaialability) manager.infoAvaialability((iIndexLoadedLayer - 1), items.length);
        update(manager.props(), items[iIndexLoadedLayer - 1], function () {
            mapService.oLayerList.updateLayer(manager)
        });
    };

    manager.showProps = function (onFinish) {
        console.log('props');
        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function() {
                    return {
                        layer: manager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {
            update(obj.props, obj.data, onFinish)
        }, function () {
            console.log("CANCEL")
        });
    };

    manager.setCurrentLayer = function(){
        var item = manager.item();
        // console.log(item);
        if(item.date_string) {
            WMSParams['time'] = item.date_string;
        }
        if(layer){
            manager.remove(layer);
            manager.remove(manager.mapLayer())//test
        }
        layer = mapService.addSingleTileWmsLayer(layerObj.server.url, WMSParams);
        manager.setMapLayer(layer);
    };

    manager.getLayerAvailability = function() {
        items = loadLayerAvailability();
        return items;
    };

    manager.setVisible = function(b){
        visible = b;
        if (!visible && layer) {
            layer.setOpacity(0);
        }else{
            layer.setOpacity(1);
        }
    };

    manager.isDraggable = function(){
        return true;
    };

    manager.isVisible = function(){
        return visible;
    };

    manager.customprops = function(){
        if(manager.layerObj().hasOwnProperty("customprops")){
            return JSON.parse(manager.layerObj().customprops)
        }
    };

    manager.legend = function(){


        console.log(manager);
        var legend = {
            type: "ADVANCED",
            legend: [{
                type: "CUSTOM",
                title: manager.name(),
                palette: []
            }]
        };


        if(manager.layerObj().hasOwnProperty("customprops")){
            if (manager.customprops().hasOwnProperty("customLegend")){

                legend.legend[0] = manager.customprops().customLegend.default;//default o la variabile che definisci mi permette di gestire multi legenda
                console.log(legend)
                return legend
            }
        }


    };

    manager.refresh = function(onFinish){
        if (onFinish) onFinish()
    }



    console.log(manager.mapLayer);

    return manager;

}
