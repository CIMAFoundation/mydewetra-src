/**
 * Created by Dario Rubado on 12/09/16.
 */

function layerManager_dynamic_ais_boe(layerObj) {

    const oManager = layerManager_dynamic_v3(layerObj)

    const oServices = oManager.oServices();


    oManager.load = (onFinish) => {
        const from = oServices.menuService.getDateFromUTCSecond();
        const to = oServices.menuService.getDateToUTCSecond();


        oServices.layerService.publishLayer(layerObj, from, to, function (data) {
            // &env=minimum:12;maximum:20&
            oManager.setProps(data.properties);
            oManager.setItem(data.item);
            oManager.setLayerId(data.layerid);


            oManager.setLayerId(data.layerid);
            //https://dds.cimafoundation.org/dds/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=dds:AIS_BOE_AIS_BOE_244890406_1656637200000_1657886400000_points&maxFeatures=50&outputFormat=application%2Fjson
            //https://dds.cimafoundation.org/wfs?version=1.0.0&request=GetFeature&typeName=dds:AIS_BOE_AIS_BOE_244890406_1656637200000_1657886400000_points&maxFeatures=50&outputFormat=application/json

            let urlToWfsLayer = data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=" + oManager.getLayerId()+'_points,'+oManager.getLayerId()+'_lines';

            oServices.apiService.getExt(urlToWfsLayer, (data) => {
                oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(data.features, layerObj.descr), {

                    pointToLayer: function(feature, latlng){
                        debugger
                        return L.circleMarker(latlng,
                            {
                                radius: 8,
                                fillColor: 'green',
                                color: "#000",
                                weight: 1,
                                opacity: 1,
                                fillOpacity: 0.8
                            });

                    },
                    onEachFeature

                }, null, null, null, null, null);

                oManager.setDownloadUrl(
                    ((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                        data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                        data.serverurl + '/ddsData/' + data.layerid + '.tiff')
                );

                if (onFinish) onFinish()

                if (!oManager.isVisible()) oManager.setVisible(false);
            });


        })

    }

    return oManager;
}
