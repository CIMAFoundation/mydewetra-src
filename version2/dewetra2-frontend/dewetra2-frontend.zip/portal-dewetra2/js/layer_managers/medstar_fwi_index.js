/**
 * Created by Dario Rubado on 20/03/22.
 */

//portale toscana lamma
//https://geoportale.lamma.rete.toscana.it/cgi-bin/wms_rischio_prev?map=wms_YYYY/ris_prev_incendio_wms_YYYY-mm-dd.map&SERVICE=WMS&VERSION=1.3.0&REQUEST=GetCapabilities
function layerManager_medstar_fwi_index(layerObj) {

    let isVisible = true;

    let iOpacity = 1;

    const oManager = layerManager_default(layerObj);

    const oServices = oManager.oServices();

    let isLoaded = false;

    let timer = null;

    let to;

    let modalInstance;

    let XmlCapability;
    let temporalInstants, timeDimensionOfLayerSelectedFromCapabilities, layerSelectedFromCapabilities;

    const availableVariable = ['Comuni_Rfwi_Run2_', 'Comuni_Rfwi_Run1_', 'Comuni_Rfwi_Run0_'];


    var WMSParams = {
        service: 'WMS',
        request: 'GetMap',
        version: '1.3.0',
        //version: '1.1.1',
        layers: layerObj.dataid,
        styles: '',
        time: '',
        // srsName:'EPSG:3857',
        // crsName:'EPSG:3857',
        format: 'image/png',
        width: 512,
        height: 512,
        // width=256&height=256
        //tiled: true,
        transparent: true
    };


    const layerProps = {
        "layerProperties": {
            "attributes": [
                {
                    "descr": "Variable",
                    "name": "variable",
                    "entries": [{
                        "descr": "MAP_FORCAST_FWI_TODAY",
                        "value": "Comuni_Rfwi_Run0_",
                        "referredValues": {
                            "entry": []
                        }

                    }, {
                        "descr": "MAP_FORCAST_FWI_TOMORROW",
                        "value": "Comuni_Rfwi_Run1_",
                        "referredValues": {
                            "entry": []
                        }

                    }, {
                        "descr": "MAP_FORCAST_FWI_AFTER_TOMORROW",
                        "value": "Comuni_Rfwi_Run2_",
                        "referredValues": {
                            "entry": []
                        }

                    }],
                    "id": "variable",
                    "selectedEntry": {
                        "descr": "MAP_FORCAST_FWI_TODAY",
                        "value": "Comuni_Rfwi_Run0_",
                        "referredValues": {
                            "entry": []
                        }

                    },
                    "type": "List",
                    "visible": "true"
                }

            ],
            "data": oManager.layerId,
            "description": oManager.descr,
            "id": oManager.layerId,
            "longDescription": oManager.descr
        }
    }


    oManager.setProps(Object.assign({}, layerProps));

    setCapability = (data) => {
        XmlCapability = data;
    }

    parsedCapability = () => {
        return new WMSCapabilities().parse(XmlCapability);
    }

    buildProperties = () => {

        // oManager.layerProps = Object.assign({}, layerProps);
        //
        // let oDateTo = moment.utc(oServices.menuService.getDateTo());
        // let year = oDateTo.year();
        // let sDateMapFormatted = oDateTo.format('YYYY-MM-DD');
        // oManager.layerProps.layerProperties.attributes[0].selectedEntry

        const dayToLoad = 10;
        const exampleEntry = {
            "descr": "DateRef",
            "value": "tim",
            "referredValues": {
                "entry": []
            }};

        const exampleAttribute = {
            "descr": "DateRef",
            "name": "DateRef",
            "id": "Variable",
            "entries":[],
            "selectedEntry": {},
            "type": "List",
            "visible": "true",
        };

        const newProperties = Object.assign({}, layerProps);

        const oDateTo = moment.utc(oServices.menuService.getDateTo());

        const attribute = Object.assign({}, exampleAttribute);

        const entries = []

        for(let i = 1; i < dayToLoad; i++){
            let entry = Object.assign({}, exampleEntry);
            entry.value = oDateTo.clone().subtract(i, 'days').unix();
            entry.descr = oDateTo.clone().subtract(i, 'days').format('YYYY-MM-DD');
            entries.push(entry);
        }


        attribute.entries = entries
        attribute.selectedEntry = entries[0];


        newProperties.layerProperties.attributes[1] = attribute;

        oManager.setProps(newProperties);


    }

    function getCapabilities(callback) {

        //map=wms_YYYY/ris_prev_incendio_wms_YYYY-mm-dd.map
        let oDateTo = getDate();
        let year = oDateTo.year();
        let sDateMapFormatted = oDateTo.format('YYYY-MM-DD');
        //const ServerUrl = oManager.layerObj().server.url + '?map=wms_' + year + '/ris_prev_incendio_wms_' + sDateMapFormatted + '.map';

        const url = oManager.layerObj().server.url + '?map=wms_' + year + '/ris_prev_incendio_wms_' + sDateMapFormatted + '.map' + '&service=WMS&version=1.3.0&request=GetCapabilities';


        // oManager.layerObj().server.url
        // olayerObj.server.url

        //https://geoportale.lamma.rete.toscana.it/cgi-bin/wms_rischio_prev?map=wms_2022/ris_prev_incendio_wms_2022-03-18.map&service=WMS&version=1.3.0&request=GetCapabilities
        //https://geoportale.lamma.rete.toscana.it/cgi-bin/wms_rischio_prev?map=wms_YYYY/ris_prev_incendio_wms_YYYY-mm-dd.map&SERVICE=WMS&VERSION=1.3.0&REQUEST=GetCapabilities

        oServices.apiService.getExt(url
            , function (data) {

                setCapability(data);

                if (callback) callback();

            }, function (data) {
                console.log("medstar dynamic ERROR", data);
            })
    }


    function update(onFinish, properties) {

        oManager.setProps(properties);

        getCapabilities(()=>{
            setLayer(onFinish);
        })

    }

    function getDate(){
        if (oManager.props().layerProperties.attributes[1].selectedEntry.value && moment.unix(oManager.props().layerProperties.attributes[1].selectedEntry.value).isValid){
            return moment.unix(oManager.props().layerProperties.attributes[1].selectedEntry.value)
        }else {
            return moment.utc(oServices.menuService.getDateTo());
        }

    }

    setLayer = (onFinish) => {

        if (oManager.mapLayer()) {
            iOpacity = oManager.mapLayer().options.opacity;
        }

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        const oDateTo = getDate();
        const year = oDateTo.year();
        const sDateMapFormatted = oDateTo.format('YYYY-MM-DD');

        const layerId = oManager.props().layerProperties.attributes[0].selectedEntry.value + sDateMapFormatted;

        oManager.setLayerId(layerId);

        const ServerUrl = oManager.layerObj().server.url + '?map=wms_' + year + '/ris_prev_incendio_wms_' + sDateMapFormatted + '.map';

        oManager.setMapLayer(oServices.mapService.addWmsLayer(ServerUrl, layerId));

        oManager.mapLayer().setOpacity(iOpacity);

        if (onFinish) onFinish();

    }

    oManager.load = function (onFinish) {

        buildProperties();

        getCapabilities((data) => {

            if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

            oServices.$timeout(()=>{
                setLayer(onFinish);
            },1000)

        });

    };


    oManager.draggable = function () {
        return true
    }

    // manager.showProps = function (onFinish) {
    //
    //     var layerPropModal = $uibModal.open({
    //         templateUrl: 'apps/dewetra2/views/layer_properties.html',
    //         controller: "layerPropertiesController",
    //         size: "lg",
    //         resolve: {
    //             params: function() {
    //                 return {
    //                     layer: manager.mapLayer()
    //                 }
    //             }
    //         }
    //     });
    //
    //     layerPropModal.result.then(function (obj) {
    //         update(obj.props, obj.data, onFinish)
    //     }, function () {
    //         console.log("CANCEL")
    //     });
    //
    // },

    oManager.onDateChange = function (onFinish) {

        buildProperties();

        getCapabilities(()=>{
            setLayer(onFinish);
        });



    };

    oManager.showProps = function (onFinish) {

        var layerPropModal = oServices.$uibModal.open({
            template: `
                    <div class="popup">
                        <div class="head" >
                            <div class="flex-container">
                                <!--Title-->
                                <div class="brand flex-item">
                                    <i class=""fa app-static animated bounceIn delay-002" ></i>
                                    <p class="animated fadeInDown delay-001" translate>
                                        <span translate>{{layer.name}}</span> <span translate>properties</span>
                                    </p>
                                </div>
                    
                                <div class="flex-item">
                                    <a class="close" ng-click="closePopup()" href>
                                        <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    
                        <hr>
         
                        <div class="modal-body">

                            <hr>
                                
                               <div class="row" ng-repeat="attr in config.properties.layerProperties.attributes">
                <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                    <label class="hidden-xs">
                        <h4 translate>{{attr.descr}}</h4>

                    </label>
                    <label class="pull-right visible-xs">
                        <h4 translate>{{attr.descr}}</h4>

                    </label>
                </div>

                <div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
                    <select class="form-control" ng-options="opt as opt.descr | translate for opt in attr.entries"
                            ng-model="attr.selectedEntry" >
                    </select>

                </div>
            </div>
             
                    
                            <hr>
                    <div class="row">      
                                <div class="flex-item animated zoomInUp delay-003 ">
                                    <a href="" class="btn btn-warning pull-right" ng-click="update()" tooltip="reload layer" >
                                        <i class="fa fa-refresh "></i>
                                        {{ 'LAYER_REFRESH' | translate }}
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>`,
            controller: ['$scope', 'layerService', 'mapService', 'menuService', '$uibModalInstance', 'params', '$interval', '$translate', '_', function ($scope, layerService, mapService, menuService, $uibModalInstance, params, $interval, $translate, _) {

                $scope.config = {
                    selectedVariable: {},
                    properties: {},
                    selectedEntry: {}
                }

                $scope.config.properties = params.oManager.props();

                $scope.config.properties.layerProperties.attributes[0].selectedEntry = $scope.config.properties.layerProperties.attributes[0].entries.filter(entry => $scope.config.properties.layerProperties.attributes[0].selectedEntry.value == entry.value)[0];

                $scope.selectTypeAttr = function (d) {
                    console.log(d);
                }

                $scope.update = function () {
                    $uibModalInstance.close($scope.config.properties);
                };

                $scope.closePopup = function () {
                    $uibModalInstance.dismiss()
                };


            }],
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        layerObj,
                        oManager
                    }
                }
            }
        });

        layerPropModal.result.then(function (properties) {
            update(onFinish, properties)
        }, function () {
            console.log("CANCEL")
        });
    }

    oManager.thirdLine = function () {
        return true
    }


    oManager.getVariable = function () {
        let s = '';
        try {
            if (oManager.props().layerProperties.attributes[1].selectedEntry.value && moment.unix(oManager.props().layerProperties.attributes[1].selectedEntry.value).isValid){
                s += oServices.$translate.instant('DateRef') + ': '+moment.unix(oManager.props().layerProperties.attributes[1].selectedEntry.value).format('YYYY-MM-DD');
            }
            return s + ' -> ' + oManager.props().layerProperties.attributes[0].selectedEntry.descr;
        }catch (e) {

        }




    }

    oManager.getAggregation = function () {
        return '';

    }




    delete oManager.getDownloadUrl;


    oManager.legend = function () {


        let parsedCapabilities = parsedCapability();

        //parsedCapabilities.Capability.Layer.Layer[26].Style[0].LegendURL[0].OnlineResource

        let aLayerInCapabilities;

        try {
            debugger
            aLayerInCapabilities = parsedCapabilities.Capability.Layer.Layer.filter(layer => layer.Title == oManager.getLayerId())
        }catch (e) {
            console.log(e);
        }

        let legendImageUrl;
        if(aLayerInCapabilities.length > 0 ){
            //console.log(aLayerInCapabilities[0].Style[0].LegendURL[0].OnlineResource)
            legendImageUrl = aLayerInCapabilities[0].Style[0].LegendURL[0].OnlineResource;
        }



        const legend = {
            type: "ADVANCED",
            legend: [{
                type: "CUSTOM",
                title: oManager.name(),
                palette: [],
                descr: ""
            }]
        };

        legend.legend[0].palette = [];//default o la variabile che definisci mi permette di gestire multi legenda
        legend.legend[0].img = legendImageUrl;//default o la variabile che definisci mi permette di gestire multi legenda
        legend.legend[0].descr = '';//default o la variabile che definisci mi permette di gestire multi legenda

        return legend
    }

    return oManager
}



