/**
 * Created by doy on 19/06/15.
 */

function layerManager_sensor_generic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, thresholdService) {


    function showChart(s) {

        var modalInstance = $uibModal.open({

            templateUrl: window.app.config.sensorChartDirective.templateUrl,
            controller: 'sensorChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sensorData: function () {

                    var featureData = s.target.feature.properties;

                    return {
                        sensorId : (featureData.sensor)?featureData.sensor:featureData.sensorid,
                        dbId : (featureData.db)?featureData.db:featureData.dbid,
                        properties: featureData,
                        from:"sensor_generic",
                        sensorClass : (featureData.sensorclass)?featureData.sensorclass:featureData.class,
                        ddsChartSerie:layerObj.dataid,
                        ddsServerId:layerObj.server.id
                    };

                }
            }
        });

    }

    var manager = layerManager_sensor(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, thresholdService);




    function stationClickListener(s) {

        showChart(s);

    }

    /**
     * mouse listener
     * @param feature object
     * @return *
     * */
    function stationMouseOverListener(s){
        try{

            let tooltipType = '';

            switch (layerObj.dataid) {
                case 'bolivia.sensor.rainfall':
                    tooltipType = 'SENSOR_GENERIC';
                    break;
                default:
                    tooltipType = 'SENSOR_FLOODPROOF_SERIES';
            }

            if(manager.getWarningInfo){
                manager.getWarningInfo().mouseOver(tooltipType,manager.mapLayer()._leaflet_id, s.target.feature.properties)
            }
        }catch(err){
            alert("errot thresholdInfo.mouseOver")
        }
    }

    function stationMouseOutListener(s){
        try{

            let tooltipType = '';

            switch (layerObj.dataid) {
                case 'bolivia.sensor.rainfall':
                    tooltipType = 'SENSOR_GENERIC';
                    break;
                default:
                    tooltipType = 'SENSOR_FLOODPROOF_SERIES';
            }
            if(manager.getWarningInfo){
                manager.getWarningInfo().mouseOut(tooltipType,manager.mapLayer()._leaflet_id)
            }

        }catch(err){
            alert("errot thresholdInfo.mouseOver")
        }
    }

    manager.load = function(onFinish) {

        serieService.getLayerData(layerObj, function (ld) {

            manager.setLayerData(ld);

            floodproofsService.layer(ld.layer.server.id,ld.layer.dataid, function (data) {

                manager.setGeoJson(data);
                manager.setMapLayer();

                manager.setMapLayer(mapService.addGeoJsonLayer(data, layerObj['descr'], {
                            pointToLayer: function(feature, latlng) {
                                return iconService.sensor_generic_Icon(feature,latlng);
                            }
                        }, stationClickListener, stationMouseOverListener, stationMouseOutListener));

                if (onFinish) onFinish()

            }, function(data) {

                alert('Error loading layer: ' + data.error_message);

            })


        });




    }


    manager.legend = function(){


        console.log(manager);
        var legend = {
            type: "ADVANCED",
            legend: [{
                type: "CUSTOM",
                title: manager.name(),
                palette: []
            }]
        };


        if(manager.layerObj().hasOwnProperty("customprops")){
            if (manager.customprops().hasOwnProperty("customLegend")){

                legend.legend[0].palette = manager.customprops().customLegend.default;//default o la variabile che definisci mi permette di gestire multi legenda

                console.log(legend)

                return legend
            }



        }




    };

    return manager;


}
