/**
 * Created by doy on 19/06/15.
 */

function layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout) {

    var layer = layerObj;

    var visible = true;

    var infoAvaialability = {
        index: 0,
        length: 1,
        reverse: null// per i radar il primo layer disponibile è l'ultimo in ordine di tempo, al contrario dei modelli
    };

    var props = null;
    var item = null;
    var mapLayer = null;
    var layerId = null

    var ShowNearestDate = false;

    var oDynamicPaletteSettings = {
        haveDynamicPalette: false,
        min_value: 0,
        max_value: 0
    };

    var aPalette = [];

    var oLegend = null;

    var bCanMovie = true;


    var refresh = {
        status: true,
        refreshTime: 10000,
        lastRefresh: null,
        refreshAttempt: 0
    };

    var oCallBackError = {
        getLayerAvailability: 0,
        republishLayer: 0
    }

    var downloadUrl = null;

    var iOpacity = 100;

    var debug = menuService.debug;

    var sendToSit = true;

    var removed = false;


    function buildDynamicPaletteData(properties) {

        if (oDynamicPaletteSettings.haveDynamicPalette) return oDynamicPaletteSettings;


        if (properties.layerProperties.attributes.length > 0) {

            var dynamicPaletteProp = _.findWhere(properties.layerProperties.attributes, {name: "dyn_pal"})

            if (dynamicPaletteProp && dynamicPaletteProp.selectedEntry.value == "1") {
                var obj = {}
                obj.haveDynamicPalette = true;//setto opzio true
                var selectedVariable = _.findWhere(properties.layerProperties.attributes, {name: "variable"})
                var maxVal = _.findWhere(selectedVariable.selectedEntry.referredValues.entry, {key: "max_def"});
                if (maxVal) {
                    obj.max_value = parseFloat(maxVal.value);
                    obj.min_value = parseFloat((_.findWhere(selectedVariable.selectedEntry.referredValues.entry, {key: "min_def"})).value);
                    return obj
                }
            }

        }
    }

    function setDynamicPalette(properties) {
        //return false
        var obj = buildDynamicPaletteData(properties);
        if (obj) oDynamicPaletteSettings = obj
    }


    var lastUpdateReceived = null;

    function setNewLayer(newProps, newItem, layerId, onFinish) {

        // &env=minimum:12;maximum:20

        props = newProps;
        item = newItem;
        if (mapLayer) iOpacity = mapLayer.options.opacity

        if (mapLayer) mapService.removeLayer(mapLayer);

        if (removed) return
        mapLayer = mapService.addWmsLayer(layer.server.url + '/wms', layerId, (oDynamicPaletteSettings.haveDynamicPalette) ? "minimum:" + oDynamicPaletteSettings.min_value.toString() + ";maximum:" + oDynamicPaletteSettings.max_value.toString() : null);

        if (iOpacity != null) mapLayer.setOpacity(iOpacity);

        if (onFinish) onFinish()
        refresh.refreshAttempt = 0
        if (debug) console.log(layer.id + " " + layerId)
    }


    function update(newProps, newItem, onFinish, bScrambling) {

        // if((newProps === props)&&(newItem === item))setNewLayer(newProps,newItem,layerId,onFinish)

        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        var random = Math.floor(Math.random() * 5000) + 300

        if (!bScrambling) random = 0;

        if (debug) console.log("ritardo prima chiamata repubblish layer:" + random);


        $timeout(
            layerService.republishLayer(layer, newProps, from, to, newItem,
                function (data, status) {


                    refresh.refreshAttempt = 0
                    layerId = data.layerid;
                    downloadUrl = ((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                        layer.server.url + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                        layer.server.url + '/ddsData/' + data.layerid + '.tiff');
                    setNewLayer(newProps, newItem, data.layerid, onFinish);
                },
                function (data, status) {//onerror
                    var random = Math.floor(Math.random() * 5000) + 3000
                    if (debug) console.log("ritardo on error 500 repubblish layer: " + random)

                    //se da errore la republish, permetto al massimo 5 tentativi
                    refresh.refreshAttempt = refresh.refreshAttempt + 1;
                    if (debug) console.log("tentativo numero: " + refresh.refreshAttempt)

                    // se è una movie stoppo
                    stop();

                    if (status == 500 && refresh.refreshAttempt < 5) {
                        $timeout(function () {
                            update(newProps, newItem, onFinish)
                        }, random)
                    }
                }, function (data) {
                    alert($translate.instant(data));
                    if (debug) console.log(data);
                })
            , random)
    }

    function initializeMoveOptions() {

        //setto layer props per averle pronte per la movie
        layerService.getLayerProperties(layer, function (data) {
            props = data;
        });
        //chiedo una volta la disponibilita dei layer per sapere se posso andare avanti o indietro nel tempo

        //chiedo quali layer sono diponibili nella timeline

        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        layerService.getLayerAvailability(layer, props, from, to, function (dataAvailable) {

            //todo


            //non arriva ordinato dataAvailable

            bCanMovie = (dataAvailable.length > 1) ? true : false;
            if (bCanMovie) {
                //cerco l'index del layer caricato precedentemente
                var iIndexLoadedLayer = _.findIndex(dataAvailable, function (availableItem) {
                    return availableItem.description == item.description;
                });
                //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                iIndexLoadedLayer = (iIndexLoadedLayer > -1) ? iIndexLoadedLayer : 1;

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                infoAvaialability.index = iIndexLoadedLayer;
                infoAvaialability.length = dataAvailable.length;
                infoAvaialability.reverse = moment(dataAvailable[0].date).unix() > moment(dataAvailable[1].date).unix() ? true : false
            }

        })
    }


    function goForward() {

        console.log("Go Forward");

        var oManager = mapService.oLayerList.getManagerByMapLayer(mapLayer);
        //controllo se ci sono gia delle proprieta caricate

        if (props) {
            //carico le date
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //chiedo quali layer sono diponibili nella timeline
            layerService.getLayerAvailability(layer, props, from, to, function (data) {

                //cerco l'index del layer caricato precedentemente
                var iIndexLoadedLayer = _.findIndex(data, function (availableItem) {
                    return availableItem.description == item.description;
                });

                //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                iIndexLoadedLayer = (iIndexLoadedLayer > -1) ? iIndexLoadedLayer : 1;

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                if (oManager.infoAvaialability) {
                    oManager.infoAvaialability(iIndexLoadedLayer + 1, data.length);
                }

                update(props, data[iIndexLoadedLayer + 1], function () {

                    mapService.oLayerList.updateLayer(oManager)
                })
            })
        }
    }

    function goBackward() {

        console.log("Go Forward");

        var oManager = mapService.oLayerList.getManagerByMapLayer(mapLayer);
        //controllo se ci sono gia delle proprieta caricate
        if (props) {
            //carico le date
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //chiedo quali layer sono diponibili nella timeline
            layerService.getLayerAvailability(layer, props, from, to, function (data) {

                //cerco l'index del layer caricato precedentemente
                var iIndexLoadedLayer = _.findIndex(data, function (availableItem) {
                    return availableItem.description == item.description;
                });
                //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                iIndexLoadedLayer = (iIndexLoadedLayer > -1) ? iIndexLoadedLayer : 1;

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                if (oManager.infoAvaialability) {
                    oManager.infoAvaialability(iIndexLoadedLayer - 1, data.length);
                }

                update(props, data[iIndexLoadedLayer - 1], function () {
                    mapService.oLayerList.updateLayer(oManager)
                })
            })

        }
    }

    var playPromise = null;


    function playOld(ORootScope) {


        var oManager = mapService.oLayerList.getManagerByMapLayer(mapLayer);

        if (playPromise == null) {
            playPromise = $interval(function () {

                if (ORootScope.pendingRequests == 0) {

                    if (oManager.infoAvaialability().index < oManager.infoAvaialability().length - 1) {
                        oManager.goForward();
                    } else goToFirst();

                }
            }, 1000);
        } else {
            $interval.cancel(playPromise);
            playPromise = null;
        }
    }

    function play(ORootScope) {

        var oManager = mapService.oLayerList.getManagerByMapLayer(mapLayer);

        if (playPromise == null) {
            playPromise = $interval(function () {

                if (ORootScope.pendingRequests == 0) {

                    if (infoAvaialability.reverse) {
                        if (infoAvaialability.index != 0) {
                            oManager.goBackward();
                        } else goToLast();
                    } else {
                        if (infoAvaialability.index < infoAvaialability.length - 1) {
                            oManager.goForward();
                        } else goToFirst();
                    }

                }
            }, 4000);
        } else {
            $interval.cancel(playPromise);
            playPromise = null;
        }
    }

    function canPlay() {
        return (playPromise == null);
    }

    function stop() {
        $interval.cancel(playPromise);
        playPromise = null;
    }


    function goToFirst() {
        console.log("to First");
        var oManager = mapService.oLayerList.getManagerByMapLayer(mapLayer);
        //controllo se ci sono gia delle proprieta caricate
        if (props) {
            //carico le date
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //chiedo quali layer sono diponibili nella timeline
            layerService.getLayerAvailability(layer, props, from, to, function (data) {

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                if (oManager.infoAvaialability) {
                    oManager.infoAvaialability(0, data.length);
                }

                update(props, data[0], function () {
                    mapService.oLayerList.updateLayer(oManager)
                })
            })

        }
    }

    function goToLast() {
        console.log("to Last");
        var oManager = mapService.oLayerList.getManagerByMapLayer(mapLayer);

        //controllo se ci sono gia delle proprieta caricate
        if (menuService.isRealTime() && props) {

            //carico le date
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //chiedo quali layer sono diponibili nella timeline
            layerService.getLayerAvailability(layer, props, from, to, function (data) {

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                if (oManager.infoAvaialability) oManager.infoAvaialability(data.length - 1, data.length);

                update(props, data[data.length - 1], function () {
                    mapService.oLayerList.updateLayer(oManager)
                })
            })
        }

    }

    return {

        layerObj: function () {
            return layer;
        },

        setLayerObj: function (obj) {
            layer = obj;
        },

        props: function () {
            return props;
        },

        setProps: function (p) {
            props = p;
        },

        item: function () {
            return item;
        },

        setItem: function (i) {
            item = i;
        },

        getLayerId: function () {
            return layerId;
        },

        setLayerId: function (LId) {
            layerId = LId;
        },

        setDownloadUrl: function (DUrl) {
            downloadUrl = DUrl;
        },

        customprops: function () {

            if (layerObj.hasOwnProperty("customprops")) {
                return JSON.parse(layerObj.customprops)
            }
        },


        parseInfo: function (data) {

            //layer prop
            var oProperties = this.props();

            //inizializzo array
            var aProperties = []

            var measureUnit = ""

            if (oProperties.layerProperties.attributes.length >= 1) {

                oProperties.layerProperties.attributes.forEach(function (prop) {
                    //if(debug)console.log(prop)
                    if (prop.selectedEntry.referredValues && prop.selectedEntry.referredValues.entry.length > 0) {
                        prop.selectedEntry.referredValues.entry.forEach(function (entry) {
                            if (entry.key == "mu") measureUnit = entry.value
                        })
                    }

                    var oProp = {
                        name: prop.descr,
                        value: prop.selectedEntry.descr
                    }
                    if (prop.descr != "-" && (prop.visible == "true" || prop.visible == true) && (prop.hidden != "true" ||prop.hidden != true)) {
                        aProperties.push(oProp)
                    };
                })
            }

            var ret = {
                layerName: this.descr(),
                layerDate: item ? moment(item.date).utc().format('DD/MM/YYYY HH:mm') : " - ",
                properties: []
            };

            if (data.features && data.features.length > 0) {
                data.features.forEach(function (f) {
                    if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                        ret.properties.push({
                            name: 'value',
                            'value': f.properties.GRAY_INDEX.toFixed(2) + " " + measureUnit
                        })
                    } else {
                        for (p in f.properties) {
                            ret.properties.push({name: p, 'value': f.properties[p] + " " + measureUnit})
                        }
                    }
                })
            }

            ret.properties = ret.properties.concat(aProperties);

            ret.properties.forEach(function (item) {
                if (item.name == 'link') {
                    item.html = true;
                } else item.html = false;
            })

            return ret;
        },

        dateRun: function () {
            if (item.id == null) return "";
            var aSplittedDate = item.id.split(';');
            var dateRun = moment.utc(parseInt(aSplittedDate[0]));
            return dateRun;

        },
        dateRef: function () {
            if (item.id == null) return "";
            var aSplittedDate = item.id.split(';');
            var dateRef;
            if(aSplittedDate.length ==1){
                dateRef = moment.utc(parseInt(aSplittedDate[0]));
            }else{
                dateRef = moment.utc(parseInt(aSplittedDate[1]));
            }

            return dateRef;
        },
        dateRefFormatted: function () {
            var sDateRunDateRef = item.id;

            if (props.layerProperties.id == "WFSNOWROADS") return item.id.replace(/;/g, ' ');

            if (item.id == null) return "";

            if (sDateRunDateRef.indexOf(";") > -1) {
                //controllo se osservazione o previsione
                var bLayerType = layerObj.category == "observation";
                //se osservazione la data di run corrisponde alla dateref e ne visualizzo solo una
                if (bLayerType) {
                    var aDateRunDateRef = sDateRunDateRef.split(";");
                    var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                    var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                    return sDateRun
                } else {
                    //se previsione distinguo le due date
                    var aDateRunDateRef = sDateRunDateRef.split(";");
                    var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                    var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                    return sDateRef + " " + " (Run:" + sDateRun + ")";
                }
                //se ha solo una data non mi pongo il problema
            } else {


                // Anto 20160908: Se item.id non è una data provo con item.date
                var tsRun = parseInt(sDateRunDateRef);
                if (!isNaN(tsRun)) {
                    return moment(new Date(tsRun)).utc().format('DD/MM/YYYY HH:mm');
                }
                else {
                    return moment(Date.parse(item.date)).utc().format('DD/MM/YYYY HH:mm');
                }

            }

        },
        dateForecast: function () {
            if (item.id == null) return "";
            var aSplittedDate = item.id.split(';');
            var diff = ((parseInt(aSplittedDate[1])) - (parseInt(aSplittedDate[0])));
            if (diff > 0) {
                diff = diff / (1000 * 60 * 60);
                return "+" + parseInt(diff);
            } else if (diff < 0) {
                return "-" + Math.abs(parseInt(diff)) / (1000 * 60 * 60);
            } else return 0;
        },

        mapLayer: function () {
            return mapLayer
        },

        setMapLayer: function (l) {
            mapLayer = l;
        },

        loadWithProperties(onFinish, layerObj, props, item, dateFrom, dateTo, opacity) {
            let _this = this;

            let from = (dateFrom) ? dateFrom : menuService.getDateFromUTCSecond();
            let to = (dateTo) ? dateTo : menuService.getDateToUTCSecond();

            iOpacity = (opacity) ? opacity : 1;

            if (_this.mapLayer()) mapService.removeLayer(_this.mapLayer());

            layerService.republishLayer(layerObj, props, from, to, item, function (data) {
                layerId = data.layerid;
                downloadUrl = ((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                    layer.server.url + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                    layer.server.url + '/ddsData/' + data.layerid + '.tiff');
                setNewLayer(props, item, data.layerid, onFinish);
            }, x => console.log(x))
        },

        load: function (onFinish) {

            var _this = this;

            if (_this.mapLayer()) mapService.removeLayer(_this.mapLayer());

            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //chiedo proprietà per controllare che proprietà sono settate
            layerService.getLayerProperties(layer, function (layerProp) {
                props = layerProp;

                layerService.getLayerAvailability(layer, props, from, to, function (dataAvailable) {
                    //controllo che non sia settato

                    var indexToLoad = 0;

                    if (angular.isArray(props.layerProperties.attributes)) {

                        props.layerProperties.attributes.forEach(function (attribute) {
                            if (attribute.name == "show_nearest_date") {
                                //console.log(dataAvailable)
                                ShowNearestDate = true;
                                var valueOfTo = moment(to).valueOf();
                                //ppassing
                                indexToLoad = closestDataAvailable(valueOfTo, dataAvailable);
                            }
                        })
                    }


                    if (ShowNearestDate) {
                        layerService.republishLayer(layer, props, from, to, dataAvailable[indexToLoad],
                            function (data) {

                                layerId = data.layerid;
                                downloadUrl = ((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                                    layer.server.url + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                                    layer.server.url + '/ddsData/' + data.layerid + '.tiff');
                                setDynamicPalette(props);
                                //inizializzo le opzioni per la movie

                                item = dataAvailable[indexToLoad];

                                setNewLayer(props, dataAvailable[indexToLoad], data.layerid, onFinish);

                                initializeMoveOptions();

                                if (!visible) _this.setVisible(false);
                            },
                            function (data, status) {//onerror
                                alert($translate.instant(data));
                                if (debug) console.log(data);
                            })

                    } else {

                        layerService.publishLayer(layer, from, to, function (data) {
                            // &env=minimum:12;maximum:20&
                            props = data.properties;

                            //check
                            setDynamicPalette(props);
                            item = data.item;
                            layerId = data.layerid
                            mapLayer = mapService.addWmsLayer(data.serverurl + '/wms', data.layerid);

                            downloadUrl = ((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                                data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                                data.serverurl + '/ddsData/' + data.layerid + '.tiff');


                            //inizializzo le opzioni per la movie
                            initializeMoveOptions();

                            if (onFinish) onFinish()

                            if (!visible) _this.setVisible(false);


                        }, function (data) {
                            alert($translate.instant(data));
                            if (debug) console.log(data);
                        })
                    }

                })
            });

        },

        name: function () {
            return layer.name
        },

        dataid: function () {
            return layer.dataid
        },

        remove: function (layer, onFinish) {
            removed = true
            if (playPromise) {
                $interval.cancel(playPromise);
            }
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        descr: function () {
            if (!props) return layer.descr;
            return props.layerProperties.description;
        },

        draggable: function () {
            return true;
        },

        haveInfo: function () {
            return true;
        },

        typeDescr: function () {
            return "DYNAMIC"
        },

        haveAudio: function () {
            return false
        },

        legend: function (callback) {

            //if (oLegend != null) callback(oLegend);
            //controllo se nelle properties cè l'attributo custom legend
            for (var i = 0; i < props.layerProperties.attributes.length; i++) {
                var attr = props.layerProperties.attributes[i]
                if (attr.name == 'customLegend') {

                    oLegend = {
                        dynPalette: {},
                        type: "DDS_CUSTOM_LEGEND",
                        url: attr.selectedEntry.value,
                        layers: mapLayer.wmsParams.layers,
                    }

                    callback(oLegend);
                }
            }

            //chiamo api per sapere se c'è una palette dinamica

            apiService.get('ddsmap/layerstyle/' + layer.server.id + '/' + mapLayer.options.layers, function (data) {
                // apiService.getExt('http://dds.cimafoundation.org/dewetra2/dewapi/ddsmap/layerstyle/'+ layer.server.id+'/'+mapLayer.options.layers , function (data) {
                // mapLayer.options.layers
                if (debug) console.log(data);

                if (oDynamicPaletteSettings.haveDynamicPalette) {

                    var delta = (((oDynamicPaletteSettings.max_value - oDynamicPaletteSettings.min_value) / (data.length - 1))).toFixed(2);

                    data.forEach(function (item, index) {
                        item.value = oDynamicPaletteSettings.min_value + (index * delta);
                    })

                    oLegend = {
                        aPalette: data,
                        dynPalette: oDynamicPaletteSettings,
                        type: layerObj.type.code.toUpperCase(),
                        url: mapLayer._url,
                        layers: mapLayer.wmsParams.layers,
                    }
                    if (callback) callback(oLegend);

                } else {
                    if (data.length > 1) {

                        var legend = {

                            type: "ADVANCED",
                            legend: [{
                                type: "CUSTOM",
                                title: layerObj.name,
                                palette: []
                            }]

                        }

                        legend.legend.palette = []
                        data.forEach(function (val) {
                            legend.legend[0].palette.push(
                                {
                                    label: val.label,
                                    color: val.color,
                                }
                            )
                        })

                        if (callback) callback(legend);

                    }

                    oLegend = {
                        aPalette: data,
                        dynPalette: {},
                        type: layerObj.type.code.toUpperCase(),
                        url: mapLayer._url,
                        layers: mapLayer.wmsParams.layers,
                    }
                    if (callback) callback(oLegend);
                }


            }, function (err, head) {
                if (debug) console.log(err);
                aPalette = null;
                oLegend = {
                    type: layerObj.type.code.toUpperCase(),
                    url: mapLayer._url,
                    layers: mapLayer.wmsParams.layers,
                }
                if (callback) {
                    callback(oLegend)
                } else return null;


            });


            // return {
            //     type: layerObj.type.code.toUpperCase(),
            //     url: mapLayer._url,>
            //     layers:mapLayer.wmsParams.layers,
            // }
        },

        haveDynamicPalette: function (obj) {

            if (obj) {
                oDynamicPaletteSettings = obj
                setNewLayer(props, item, layerId)
            }

            if (oDynamicPaletteSettings.haveDynamicPalette) {
                return oDynamicPaletteSettings
            } else return false;
        },

        canMovie: function () {
            //da cambiare
            return bCanMovie;
        },

        setCanMovie: function (b) {
            bCanMovie = b;
        },

        layerOpacity: function () {

            return iOpacity;
        },

        setlayerOpacity: function (i) {
            iOpacity = i;
        },

        infoAvaialability: function (index, length) {

            if ((index != null) && (length != null)) {
                infoAvaialability.index = index;
                infoAvaialability.length = length
            } else return infoAvaialability

        },

        canBeSendTosit: function () {

            return sendToSit;
        },

        sendToSit: function (callback, kocallback) {
            var obj = {
                serverId: layer.server.id,
                layerId: layerId
            };

            layerService.toPermanentLayer(obj, callback, kocallback);
        },

        onDateChange: function (onFinish) {
            console.log("on Date Change");
            //precarico anche l'opzione corrente cosi basta cliccare aggiorna per refreshare
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            this.load(onFinish)
            //chiedo layer avaiability dopodiche uso la update

            // layerService.getLayerAvailability(layer, props, from, to, function (data) {
            //     update(props, data[0], onFinish)
            // })
        },
        layerTooltip: function () {

            //dividere per osservazioni o previsioni e aggiungere le properties al tooltip


            var layerDelay = function (layerManagerObj) {


                try {
                    var oReferenceDate = layerManagerObj.dateRef().utc().toDate()
                } catch (err) {
                    return layerManagerObj.descr()
                }

                // Get Now
                var oDate = new Date();

                //if(debug)console.log("Now  = " + oDate);
                //if(debug)console.log("Ref  = " + oReferenceDate);

                // Compute time difference
                var iDifference = oDate.getTime() - oReferenceDate.getTime();

                // How it is in minutes?
                var iMinutes = 1000 * 60;

                var iDeltaMinutes = Math.round(iDifference / iMinutes);

                var sTimeDelta = "";

                if (iDeltaMinutes > 0) {
                    if (iDeltaMinutes < 60) {
                        // Less then 1h
                        sTimeDelta += $translate.instant("pre_min_fa") + " " + iDeltaMinutes + ' ' + $translate.instant("min_fa");
                    } else if (iDeltaMinutes < 60 * 24) {
                        // Less then 1d
                        var iDeltaHours = Math.round(iDeltaMinutes / 60);
                        sTimeDelta += $translate.instant("pre_ore_fa") + " " + iDeltaHours + ' ' + $translate.instant("ore_fa");
                    } else {
                        // More than 1d
                        var iDeltaDays = Math.round(iDeltaMinutes / (60 * 24));
                        sTimeDelta += $translate.instant("pre_giorni_fa") + " " + iDeltaDays + ' ' + $translate.instant("giorni_fa");
                    }
                } else {
                    if (iDeltaMinutes > -60) {
                        // Less then 1h
                        sTimeDelta += $translate.instant("Fra") + ': ' + Math.abs(iDeltaMinutes) + ' ' + $translate.instant("Minuti");
                    } else if (iDeltaMinutes > -60 * 24) {
                        // Less then 1d
                        var iDeltaHours = Math.round(iDeltaMinutes / 60);
                        sTimeDelta += $translate.instant("Fra") + ': ' + Math.abs(iDeltaHours) + ' ' + $translate.instant("Ore");
                    } else {
                        // More than 1d
                        var iDeltaDays = Math.round(iDeltaMinutes / (60 * 24));
                        sTimeDelta += $translate.instant("Fra") + ': ' + Math.abs(iDeltaDays) + ' ' + $translate.instant("Giorni");
                    }
                }


                return sTimeDelta;
            };

            //gestisco la from date nel tooltip.
            try {
                var oHoursOfCumulate = props.layerProperties.attributes.filter((attr) => {
                    return attr.descr == "Cumulative Rainfall"
                })[0].selectedEntry

                var iHoursOfCumulate = parseInt(oHoursOfCumulate.value);

                // if(iHoursOfCumulate == '-1') {
                //     console.log("cumulata su time range")
                //     iHoursOfCumulate = Math.abs(menuService.getDateTo() - menuService.getDateFrom()) / 36e5;
                // }

            } catch (e) {
                console.log(iHoursOfCumulate);
            }


            //gestisco risoluzione spaziale pioggia

            try {
                var oSpatialResolution = props.layerProperties.attributes.filter((attr) => {
                    return attr.descr == "Spatial Resolution"
                })[0].selectedEntry;


            } catch (e) {
                console.log(e)
            }


            //definisco oggetto tooltip
            var oTooltip = {
                "API 15": [
                    {
                        label: "LAYER_NAME",
                        value: this.name()
                    },
                    {
                        label: "LAYER_DESCRIPTION",
                        value: this.descr()
                    },
                    {
                        label: "DATE_REF",
                        value: (item.id) ? this.dateRun().format("DD/MM/YYYY HH:mm") : ""
                    }
                ],
                MCM_CUMULATED_RAIN_DESCR: [
                    {
                        label: "LAYER_NAME",
                        value: this.name()
                    },
                    {
                        label: "LAYER_DESCRIPTION",
                        value: this.descr()
                    },
                    {
                        label: "DATE_REF",
                        value: (item.id) ? this.dateRef().format("DD/MM/YYYY HH:mm") : ""
                    }
                ],
                RADAR: [
                    {
                        label: "LAYER_NAME",
                        value: this.name()
                    },
                    {
                        label: "LAYER_DESCRIPTION",
                        value: this.getVariable()
                    },
                    //{
                    //    label : "DATE_RUN",
                    //    value : this.dateRun().format("YYYY/MM/DD HH:mm")
                    //},
                    {
                        label: "DATE_REF",
                        value: (item.id) ? this.dateRun().format("DD/MM/YYYY HH:mm") + ' UTC' : "",
                    },
                    //{
                    //    label : "DATE_FORECAST",
                    //    value : this.dateForecast()
                    //},
                    // {
                    //     label: "DATE_DELAY",
                    //     value: layerDelay(this)
                    // }
                ],
                observation: [
                    {
                        label: "LAYER_NAME",
                        value: this.name()
                    },
                    {
                        label: "LAYER_DESCRIPTION",
                        value: (this.getVariable()) ? this.getVariable() : this.descr()
                    },
                    {
                        label: "DATE_REF",
                        value: (item.id ) ? this.dateRef().format("DD/MM/YYYY HH:mm") : ""
                    }
                    // {
                    //     label : "DATE_DELAY",
                    //     value : layerDelay(this)
                    // }
                ],
                forecast: [
                    {
                        label: "LAYER_NAME",
                        value: this.name()
                    },
                    {
                        label: "LAYER_DESCRIPTION",
                        value: this.descr()
                    },
                    {
                        label: "DATE_RUN",
                        value: (item.id) ? this.dateRun().format("DD/MM/YYYY HH:mm") : ""
                    },
                    {
                        label: "DATE_REF",
                        value: (item.id) ? this.dateRef().format("DD/MM/YYYY HH:mm") + " (" + this.dateForecast() + " h)" : ""
                    },
                    // {
                    //     label : "DATE_FORECAST",
                    //     value : this.dateForecast()
                    // },
                    // {
                    //     label : "DATE_DELAY",
                    //     value : layerDelay(this)
                    // }

                ],
                DEFAULT: [
                    {
                        label: "LAYER_NAME",
                        value: this.name()
                    },
                    {
                        label: "LAYER_DESCRIPTION",
                        value: this.descr()
                    }
                ],
                RAINFALL_FIELD: [
                    {
                        label: "LAYER_NAME",
                        value: this.name()
                    },
                    {
                        label: "LAYER_DESCRIPTION",
                        value: this.descr()
                    },
                    {
                        label: "DATE_REF",
                        value: this.dateRun().format("DD/MM/YYYY HH:mm")
                    },
                    {
                        label: "CUMULATE_TIME",
                        value: (oHoursOfCumulate) ? oHoursOfCumulate.descr : null
                    },
                    {
                        label: "AGGREGATION",
                        value: (oSpatialResolution) ? oSpatialResolution.descr : null
                    },
                    {
                        label: "FROM_DATE",
                        value: (iHoursOfCumulate > -1) ? this.dateRun().subtract({hours: iHoursOfCumulate}).format("DD/MM/YYYY HH:mm") : moment.utc(menuService.getDateFrom()).format("DD/MM/YYYY HH") + ':00'
                    },
                    {
                        label: "TO_DATE",
                        value: this.dateRun().format("DD/MM/YYYY HH:mm")
                    }
                ],
                WFSNOWROADS: [
                    {
                        label: "LAYER_NAME",
                        value: this.name()
                    },
                    {
                        label: "LAYER_DESCRIPTION",
                        value: this.descr()
                    },
                    {
                        label: "DATE_REF",
                        value: item.id.replace(/;/g, ' ')
                    }
                ],
                FULL: [
                    {
                        label: "LAYER_NAME",
                        value: this.name()
                    },
                    {
                        label: "LAYER_DESCRIPTION",
                        value: this.descr()
                    },
                    {
                        label: "DATE_RUN",
                        value: (item.id) ? this.dateRun().format("DD/MM/YYYY HH:mm") : ""
                    },
                    {
                        label: "DATE_REF",
                        value: (item.id) ? this.dateRef().format("DD/MM/YYYY HH:mm") : ""
                    },
                    {
                        label: "DATE_FORECAST",
                        value: this.dateForecast()
                    },
                    {
                        label: "DATE_DELAY",
                        value: layerDelay(this)
                    }]
            };


            //layer prop
            var oProperties = this.props();

            //inizializzo array
            var aProperties = []

            var aHidedProp = ["-", "dir", "Directory"];

            if (oProperties.layerProperties.attributes.length >= 1) {
                oProperties.layerProperties.attributes.forEach(function (prop) {
                    if (prop.visible == "false") {
                        prop.visible = false
                        prop.hidden = true;
                    }
                    var oProp = {
                        label: prop.descr,
                        value: prop.selectedEntry.descr
                    }

                    // if(!aHidedProp.includes(prop.descr)){
                    //     if(prop.hidden ){
                    //         aProperties.push(oProp)
                    //     }
                    // }

                    if ((!aHidedProp.includes(prop.descr)) && !prop.hidden) {
                        aProperties.push(oProp)
                    };

                })
            }


            // radar a parte
            //se un radar ritorno tooltip radar
            if ((this.name().toUpperCase().indexOf('RADAR')) > -1) {
                return oTooltip['RADAR'].concat(aProperties);
            }

            if ((this.name().indexOf('MAPPA_PIOGGIA')) > -1) {
                return oTooltip['RAINFALL_FIELD'].concat(aProperties);
            }

            if (layerObj.category == "observation") {

                return oTooltip[layerObj.category].concat(aProperties);

            } else if (layerObj.category == "forecast") {
                if (layerObj.dataid == "WFSNOWROADS") return oTooltip[layerObj.dataid]
                return oTooltip[layerObj.category].concat(aProperties);

            }


            //altrimenti se cè un tooltip pre preparato carico quello
            if (oTooltip[layer.descr]) return oTooltip[layer.descr];

            //altrimenti tooltip di default
            return oTooltip['DEFAULT'];

        },

        refreshable: function () {
            return refresh.status;
        },

        refreshProperty: function () {
            return refresh
        },

        lastRefresh: function () {
            return refresh.lastRefresh
        },

        setLastRefresh: function (time) {
            refresh.lastRefresh = time
        },

        setRefresh: function (isRefreshable) {
            refresh.status = isRefreshable;
        },

        refresh: function (onFinish) {

            var oManager = mapService.oLayerList.getManagerByMapLayer(mapLayer);

            if (menuService.isRealTime() && oManager.infoAvaialability().index == 0) {
                goToLast();
                //update(props, item, onFinish )
            }
        },

        showProps: function (onFinish) {
            var _this = this;
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties.html',
                controller: "layerPropertiesController",
                size: "lg",
                resolve: {
                    params: function () {
                        return {
                            layer: mapLayer
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {

                var bScrambling = false;

                _this.update(obj.props, obj.data, onFinish, bScrambling)
            }, function () {
                if (debug) console.log("CANCEL")
            });
        },

        getDownloadUrl: function () {
            return downloadUrl
        },

        update: function (obj, onFinish) {
            update(obj.props, obj.data, onFinish)
        },

        initializeMoveOptions: initializeMoveOptions,

        goForward: goForward,

        goBackward: goBackward,

        play: play,

        // setVisible: function (b,callBack) {
        //
        //     var manager = this;
        //     visible = b;
        //     if (!b) oManager.mapLayer().setOpacity(0);
        //     else oManager.mapLayer().setOpacity(0);
        //
        // },
        //
        // isVisible:function(){
        //     return visible;
        // },


        availablesVariables : function () {

            if(props &&  props.hasOwnProperty('layerProperties') && props.layerProperties.hasOwnProperty('attributes')){
                return props.layerProperties.attributes.filter(attr => {
                    return attr.descr.toUpperCase() == 'VARIABLE';
                })
            }

        },

        getVariable: function () {


            let str = "";
            if (Array.isArray(props.layerProperties.attributes)) {
                props.layerProperties.attributes.forEach(function (prop) {
                    if (prop.name == "operation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                    if (prop.name == "variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                    if (prop.name == "__variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                })
                return str;
            } else {
                if (props.layerProperties.attributes.name == "operation") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (props.layerProperties.attributes.name == "variable") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (props.layerProperties.attributes.name == "__variable") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            }

        },

        getAggregation: function () {
            var str = "";

            if (Array.isArray(props.layerProperties.attributes)) {
                props.layerProperties.attributes.forEach(function (prop) {
                    if (prop.name == "aggregation") str = prop.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
                    if (prop.name == "__aggregation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                })
                return str;
            } else {
                if (props.layerProperties.attributes.name == "aggregation") str = props.layerProperties.attributes.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
                if (props.layerProperties.attributes.name == "__aggregation") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            }


        },

        thirdLine: function () {
            return true


        },

        punctualSerie: function (lat, lon, okCallback, koCallback) {
            console.log("Punctual: ", lat, lon)
            let from = menuService.getDateFromUTCSecond() - 432000;// 5 day

            let to = menuService.getDateToUTCSecond();


            serieService.getPunctualSerie(layerObj.server.id, props.layerProperties, from, to, lon, lat, okCallback, koCallback);

        },

        punctualSerieWithVariable: function (lat, lon, selectedVariable,okCallback, koCallback) {
            console.log("Punctual: ", lat, lon)
            let from = menuService.getDateFromUTCSecond() - 432000;// 5 day

            let to = menuService.getDateToUTCSecond();

            let duplicatedProperties = Object.assign({}, props.layerProperties);

            duplicatedProperties.attributes.map(attr => {
                if(attr.descr.toUpperCase() == 'VARIABLE'){
                    att.selectedEntry = selectedVariable;
                }
            })

            serieService.getPunctualSerie(layerObj.server.id, duplicatedProperties, from, to, lon, lat, okCallback, koCallback);

        },

        punctualSerieWithProperties: function (lat, lon, properties,okCallback, koCallback) {
            console.log("Punctual: ", lat, lon)
            let from = menuService.getDateFromUTCSecond() - 432000;// 5 day

            let to = menuService.getDateToUTCSecond();

            serieService.getPunctualSerie(layerObj.server.id, properties.layerProperties, from, to, lon, lat, okCallback, koCallback);

        },

        areaSerie: function (points, okCallback, koCallback) {
            console.log("Area: ", points.map(p => p));
            let from = menuService.getDateFromUTCSecond() - 432000;// 5 day

            let to = menuService.getDateToUTCSecond();


            serieService.getAreaSerie(layerObj.server.id, props.layerProperties, from, to, points, okCallback, koCallback);

        },

        canPlay: canPlay,

        goToLast: goToLast,

        update: update,

        setNewLayer: setNewLayer,

        buildDynamicPaletteData: buildDynamicPaletteData

    }

}


function layerManager_dynamic_flowtmaps(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout) {
    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout)

    manager.getAggregation = function () {
        return ""
    }
    manager.getVariable = function () {
        return ""
    }

    return manager;
}

function layerManager_dynamic_snowroads(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout) {
    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout)

    //WFSNOWDEM

    //WFSNOWROADS


    manager.layerTooltip = function () {

        var o = {
            'WFSNOWDEM': [
                {
                    label: "LAYER_NAME",
                    value: manager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: "Weather Forecast Snow Elevation"
                },
                {
                    label: "BULLETIN_DATE",
                    value: manager.item().description.split('.')[0]
                },
                {
                    label: "DATE_FORECAST",
                    value: manager.item().description.split('.')[1]
                },
            ],
            'WFSNOWROADS': [
                {
                    label: "LAYER_NAME",
                    value: manager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: "Weather Forecast Snow Roads"
                },
                {
                    label: "BULLETIN_DATE",
                    value: manager.item().description.split('.')[0]
                },
                {
                    label: "DATE_FORECAST",
                    value: manager.item().description.split('.')[1]
                },
            ]
        }


        return o[layerObj.dataid]

    }

    manager.parseInfo = function (data) {


        var o = {
            'WFSNOWDEM': [{
                name: "QUOTA",
                value: data.features[0].properties.quota,
                html: false
            },
                {
                    name: "COD_AREA",
                    value: data.features[0].properties.cod_area,
                    html: false
                },
                {
                    name: "MIN_Q_NEVE",
                    value: data.features[0].properties.min_q_neve,
                    html: false
                },
                {
                    name: "MAX_Q_NEVE",
                    value: data.features[0].properties.max_q_neve,
                    html: false
                },
                {
                    name: "NEVE",
                    value: data.features[0].properties.neve,
                    html: false
                },],
            'WFSNOWROADS': [
                {
                    name: "RDNR",
                    value: data.features[0].properties.rdnr,
                    html: false
                }, {
                    name: "GRIDCODE",
                    value: data.features[0].properties.gridcode,
                    html: false
                },
                {
                    name: "QUOTA_MAX",
                    value: data.features[0].properties.quota_max,
                    html: false
                },
                {
                    name: "TIPO_STR",
                    value: data.features[0].properties.tipo_str,
                    html: false
                },
                {
                    name: "LABEL",
                    value: data.features[0].properties.label,
                    html: false
                },
                {
                    name: "COD_AREA",
                    value: data.features[0].properties.cod_area,
                    html: false
                },
                {
                    name: "MIN_Q_NEVE",
                    value: data.features[0].properties.min_q_neve,
                    html: false
                },
                {
                    name: "MAX_Q_NEVE",
                    value: data.features[0].properties.max_q_neve,
                    html: false
                },
                {
                    name: "NEVE",
                    value: data.features[0].properties.neve,
                    html: false
                },
            ]
        }

        var ret = {
            layerName: layerObj.name,
            layerDate: "",
            properties: o[layerObj.dataid]
        };


        return ret;


    }


    manager.showProps = function (onFinish) {
        var _this = this;

        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties_snow_roads.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        layer: manager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {

            var bScrambling = false

            _this.update(obj.props, obj.data, onFinish, bScrambling)
            console.log(manager.item())
        }, function () {
            if (debug) console.log("CANCEL")
        });
    };

    manager.legend = function () {
        console.log("legendstatic" + "img/" + layerObj.dataid + ".png")
        return {
            type: layerObj.type.code.toUpperCase(),
            url: "img/" + layerObj.dataid + ".png",
            dynPalette: {haveDynamicPalette: false}

        }
    },


        manager.dateLine = function () {
            return manager.item().description.split('.')[0];
        };

    manager.getVariable = function () {
        return manager.item().description.split('.')[1];
    }

    return manager

}

function layerManager_impact_records(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout) {

    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout)


    manager.showProps = function (onFinish) {
        var _this = this;
        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties_impact_reports.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        layer: manager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {

            var bScrambling = false

            _this.update(obj.props, obj.data, onFinish, bScrambling)
        }, function () {
            console.log("CANCEL")
        });
    }

    manager.parseInfo = function (data) {


        var ret = {
            layerName: this.descr(),
            layerDate: "",
            properties: []
        };

        ret.properties.push(
            {
                name: "DATE",
                value: data.features[0].properties.date,
                html: false
            },
            {
                name: "CATEGORY",
                value: data.features[0].properties.category,
                html: false
            },
            {
                name: "DESCR",
                value: data.features[0].properties.descr,
                html: false
            },
            {
                name: "LOCATION",
                value: data.features[0].properties.location,
                html: false

            },
            {
                name: "LINK_TO_IMPACT_REPORT",
                value: data.features[0].properties.info,
                html: true
            }
        );

        return ret;


    }


    manager.legend = function () {

        return {
            type: layerObj.type.code.toUpperCase(),
            url: "img/sumALHEUE.png",
            dynPalette: {}
        }
    },


        manager.dateLine = function () {
            return "";
        }


    return manager

}


function layerManager_punctual_series(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout) {

    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout)


    manager.punctalSerie = function (lat, lon) {
        console.log("punctual")


    };

    manager.punctalSerie = function (lat, lon) {
        console.log("punctual")


    }

    return manager

}

function layerManager_burned_areas(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout) {
    const manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout)

    const oldFunction =  manager.getDownloadUrl;

    const array = [{
        ACTION: 'downloadCSV',
        LABEL: 'DOWNLOAD CVS DATA',
        ICON: 'fa fa-file-text-o',
        ENABLED: true
    }]

    manager.additionalButton = () => {
        array[0].ENABLED = (manager.props().layerProperties.attributes.filter((attr)=> attr.descr == 'Spatial Resolution')[0].selectedEntry.descr != 'Native')
        return array
    }

    manager.downloadCSV = () => {
        //province Data;            from_date;    to_date;    area_ha;    aggr_area;
        //comuni Data;            from_date;    to_date;    area_ha;    aggr_area;    PROVINCIA;    REGIONE;

        let resolution = manager.props().layerProperties.attributes.filter((attr)=> attr.descr == 'Spatial Resolution')[0].selectedEntry.descr

        let url =layerObj.server.url+'/ows?service=WFS&version=1.0.0&request=GetFeature&typeName='+manager.getLayerId()+'&maxFeatures=50&outputFormat=application/json';

        apiService.getExt(url,(data)=>{
            let csvHeader = "data:text/csv;charset=utf-8,";

            //let firstFeature = data.features[0];

            switch (resolution) {
                case 'Municipality':
                    csvHeader += 'from_date,to_date,area_ha,aggr_area,PROVINCIA,REGIONE';
                    break;
                case 'Province':
                    csvHeader += 'from_date,to_date,area_ha,aggr_area';
                    break;
                case 'Region':
                    csvHeader += 'from_date,to_date,area_ha,aggr_area';
                    break;
                default:
                    csvHeader += 'from_date,to_date,area_ha,aggr_area';
                    break
            }
            csvHeader +="\r\n";

            data.features.forEach(feature => {
                //(feature.properties.Data)?feature.properties.Data+',':''+(feature.properties.from_date)?feature.properties.from_date+',':''+(feature.properties.to_date)?feature.properties.to_date+',':''+(feature.properties.area_ha)?feature.properties.area_ha+',':''+(feature.properties.PROVINCIA)?feature.properties.PROVINVIA+',':''+(feature.properties.REGIONE)?feature.properties.REGIONE+',':'';
                let row ;

                switch (resolution) {
                    case 'Municipality':
                        row = feature.properties.from_date+','+feature.properties.to_date+','+feature.properties.area_ha +','+feature.properties.aggr_area+',' +feature.properties.PROVINCIA+','+feature.properties.REGIONE;
                        break;
                    case 'Province':

                        row = feature.properties.from_date+','+feature.properties.to_date+','+feature.properties.area_ha +','+feature.properties.aggr_area;
                        break;
                    case 'Region':
                        row = feature.properties.from_date+','+feature.properties.to_date+','+feature.properties.area_ha +','+feature.properties.aggr_area;
                        break;
                    default:
                        row = feature.properties.Data+','+feature.properties.from_date+','+feature.properties.to_date+','+feature.properties.area_ha;
                        break
                }

                csvHeader += row+ "\r\n";
            })

            let encodedUri = encodeURI(csvHeader);
            let link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", manager.name()+ "_" +resolution.toUpperCase() +".csv");
            //link.innerHTML= "Click Here to download";

            link.click();
        });

        // try {
        //     if(manager.props().layerProperties.attributes.filter((attr)=> attr.descr == 'Spatial Resolution')[0].selectedEntry.descr != 'Native'){
        //         let url ='https://dds.cimafoundation.org/dds/ows?service=WFS&version=1.0.0&request=GetFeature&typeName='+manager.getLayerId()+'&maxFeatures=50&outputFormat=application/json'
        //         apiService.getExt(url,(data)=>{
        //             console.log(data)
        //         });
        //     }else return oldFunction()
        //
        //     //manager.props().layerProperties.attributes[2].selectedEntry.descr != 'Native
        // }catch (e) {
        //
        // }
    }

    return manager;
}


