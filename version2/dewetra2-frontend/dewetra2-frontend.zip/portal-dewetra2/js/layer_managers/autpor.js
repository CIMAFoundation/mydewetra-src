/**
 * Created by Dario Rubado on 12/07/17.
 */
function layerManager_autpor(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService) {


    var visible = true;
    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;
    var backgroundLayer = null;
    var featureStyle = {
        weight : 1,
        opacity : 1,
        fillOpacity: 0.8
    }
    var markerOptions = {
        'autpor.turbidity' : ["#4BB74C", "#BCEE68", "#CD9B1D", "#CD0000"],
        'autpor.turbidity.view_all' : ["#4BB74C", "#BCEE68", "#CD9B1D", "#CD0000"],
        'autpor.turbidity_breakwater' : ["#e63fff", "#e63fff"],
        'autpor.turbidity_breakwater.view_all' : ["#e63fff", "#e63fff"],
        'autpor.dusts' : ["#7CFC00", "#E3170D"],
        'autpor.dusts.view_all' : ["#7CFC00", "#E3170D"],
        'autpor.reports' : ["#e63fff", "#e63fff"]                       // VERIFICARE IN SEGUITO!!!
    }


    function stationClickListener(s) {

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/autpor_chart_form.html',
            controller: 'autporChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sampleInfo: function () {

                    return {

                        sampleData : (layerObj.dataid == 'autpor.reports')? s.properties : s.target.feature.properties,
                        seriesId : layerObj.dataid,
                        serverId: layerObj.server.id

                    };

                }

            }
        })

    }


    function InfoMouseOver(s) {
        if (infoPopUP) infoPopUP.mouseOver('autpor', mapLayer._leaflet_id, s.target.feature)
    }

    function InfoMouseOut() {
        if (infoPopUP) infoPopUP.mouseOut('autpor', mapLayer._leaflet_id)
    }

    function update(newProps, onFinish) {
        props = newProps;
        var manager = mapService.oLayerList.getManagerByMapLayer(mapLayer)
        manager.load(onFinish);
    }

    function getPalette() {

        var palette = [];

        for (var i = 0; i < theGeoJson.features.length; i++) {
            palette.push({
                label: theGeoJson.features[i].properties.Tipologia + ' ' + theGeoJson.features[i].properties.Code,
                color: markerOptions[layerObj.dataid][i]
            })
        }

        return palette;

    }


    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        setMapLayer: function (l) {
            mapLayer = l;
        },

        load: function(onFinish) {

            serieService.getLayerData(layer, function (ld) {

                layerData = ld;

                var obj = {

                    "id": layerObj.dataid,
                    "from": menuService.getDateFromUTCSecond(),
                    "to": menuService.getDateToUTCSecond(),
                    "props": {}

                };

                apiService.post("ddsserie/" + layer.server.id + "/seriefeatures/", obj, function(data) {

                    theGeoJson = data;

                    if (layerObj.dataid == 'autpor.reports') {

                        stationClickListener(theGeoJson.features[0]);

                        if(onFinish)onFinish(false)

                    } else {

                        if (mapLayer) mapService.removeLayer(mapLayer);

                        mapLayer = mapService.addGeoJsonLayer(theGeoJson.features, layerObj.name, {

                            pointToLayer: function(feature, latlng) {

                                var ix = theGeoJson.features.indexOf(feature);

                                var geojsonMarkerOptions = {

                                    radius : 5,
                                    weight : 1,
                                    color : "#000000",
                                    opacity : 1,
                                    fillOpacity: 0.8,
                                    fillColor: markerOptions[layerObj.dataid][ix]

                                };

                                return L.circleMarker(latlng, geojsonMarkerOptions);

                            }


                        }, stationClickListener, InfoMouseOver, InfoMouseOut);

                        if (onFinish) onFinish();

                    }

                }, function(data, status) {
                    alert(data)
                })

            });






        },

        layerTooltip: function(){

            var manager = this;

            var tooltipObj = [

                {
                    label : "LAYER_NAME",
                    value : manager.name()
                }

            ];

            return tooltipObj;

        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        setOpacity : function(value){

            if (value){
                featureStyle.opacity = value;
                featureStyle.fillOpacity = value;
                //updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return featureStyle.opacity
        },

        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (backgroundLayer) mapService.removeHardCodedWmsLayer(backgroundLayer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.descr
        },

        descr: function () {
            return ''
        },

        draggable: function () {
            return false
        },

        typeDescr: function () {
            return '';
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi;
        },

        getWarningInfo: function () {
            return infoPopUP;
        },

        showProps : function (onFinish) {

            // ORG!!!
            //var layerPropModal = $uibModal.open({
            //
            //    templateUrl: 'apps/dewetra2/views/layer_properties_geocradle_soil_analysis.html',
            //    controller: function ($scope, $uibModalInstance, params) {
            //
            //        $scope.data = angular.copy(params.props);
            //
            //        $scope.availableDates = [];
            //
            //        function getAvailability() {
            //
            //            var p = {
            //                "areaType": $scope.data.areaType.typeSelected.value,
            //                "area": (($scope.data.areaType.typeSelected.value == "region")? $scope.data.region.typeSelected.value : $scope.data.country.typeSelected.value),
            //                "depth": $scope.data.depth.typeSelected.value,
            //                "soilTaxonomy": $scope.data.soilTaxonomy.typeSelected.value,
            //                "soilType": (($scope.data.soilTaxonomy.typeSelected.value = "usda")? $scope.data.usda.typeSelected.value : $scope.data.wrb.typeSelected.value),
            //                "variable": $scope.data.variable.typeSelected.value
            //            };
            //
            //            $scope.availableDates.splice(0, $scope.availableDates.length);
            //
            //            serieService.getAvailability(layerObj.server.id, layerObj.dataid, menuService.getDateFromUTCSecond(), menuService.getDateToUTCSecond(), p,
            //                function(data) {
            //                    var datesArray = Array.isArray(data)? data : [data];
            //                    if (datesArray.length > 1) $scope.availableDates.push('ALL');
            //                    datesArray.forEach(function (date) {
            //                        $scope.availableDates.push(moment(date).format('YYYY-MM-DD'));
            //                    })
            //
            //                },
            //                function(error) {
            //                    alert(error);
            //                }
            //            );
            //        }
            //
            //        getAvailability();
            //
            //        $scope.update = function () {
            //            $uibModalInstance.close($scope.data);
            //        };
            //
            //        $scope.closePopup = function () {
            //            $uibModalInstance.dismiss()
            //        }
            //
            //        $scope.itemChanged = function(item) {
            //
            //            if (item.typeSelected.value == 'region') {
            //                $scope.data['region'].visible = true;
            //                $scope.data['country'].visible = false;
            //            }
            //            if (item.typeSelected.value == 'country') {
            //                $scope.data['region'].visible = false;
            //                $scope.data['country'].visible = true;
            //            }
            //            if (item.typeSelected.value == 'usda') {
            //                $scope.data['usda'].visible = true;
            //                $scope.data['wrb'].visible = false;
            //            }
            //            if (item.typeSelected.value == 'wrb') {
            //                $scope.data['usda'].visible = false;
            //                $scope.data['wrb'].visible = true;
            //            }
            //            if ((item.name == 'AREA_OF_INTEREST') || (item.name == 'SOIL_CLASSIFICATION')) return;
            //
            //            getAvailability();
            //
            //        };
            //    },
            //    size: "lg",
            //
            //    resolve: {
            //        params: function() {
            //            return {
            //                layer: mapLayer,
            //                props: props
            //            }
            //        }
            //    }
            //});
            //
            //layerPropModal.result.then(function (obj) {
            //    update(obj, onFinish)
            //}, function () {
            //    console.log("CANCEL")
            //});

            return;

        },

        legend: function () {

            return {

                type:"ADVANCED",
                legend:[{
                    type:"CUSTOM",
                    title: "TORBIDIMETRO_PALETTE",
                    palette: getPalette()

                }]
            };

        },

        setVisible: function (b) {
            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);
        },

        isVisible:function(){
            return visible;
        }

    }

}