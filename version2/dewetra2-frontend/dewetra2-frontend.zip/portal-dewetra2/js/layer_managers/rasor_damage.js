/**
 * Created by Dario Rubado on 12/07/17.
 */
function layerManager_rasor_damage(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService) {

    var ICON_SIZE = 14;
    var visible=true;

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;
    var indicatorsMax = {};

    var backgroundLayer = null;

    var rasorFeatureStyle = {
        weight : 1,
        opacity : 1,
        fillOpacity: 0.6
    }

    var aPalette = iconService.rasorDamagePalette;

    var lastRasorUrl;


    // contourPalette['6'] ='label-contour';
    // contourPalette['7'] ='#a9a9a9';
    // contourPalette['8'] ='#ffffff';
    // contourPalette['9'] ='#ffff00';
    // contourPalette['10'] ='#ff00ff';

    //testURL
    var url = "http://130.251.104.198/geoserver/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=italy_genoa_di_flo_bui_imprex4";

    //add External Layer
    // function AddBackgroundLayer() {
    //     var layerToAdd = 49;
    //     apiService.get("settings/layers/?id="+layerToAdd,function(obj){
    //
    //         var AlreadyLoaded = false;
    //         var dataId =obj.objects[0].dataid;
    //
    //         var o = mapService.getLayerTest();
    //         if (o.draggable){
    //             o.draggable.forEach(function (data) {
    //                 if (data.wmsParams.layers == dataId){
    //                     AlreadyLoaded = true;
    //                 }
    //             })
    //         }
    //
    //         //
    //         function buildLayerManager(layer) {
    //             var mangerName = 'layerManager_' + layer['type'].code;
    //             var manager = window[mangerName](layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService);
    //
    //             return manager;
    //         }
    //         if (AlreadyLoaded){
    //             console.log("Gia Caritcato")
    //         }else{
    //             var PlusManager = buildLayerManager(obj.objects[0]);
    //             PlusManager.load(function () {
    //                 mapService.setlayerManager(PlusManager.mapLayer(), PlusManager);
    //                 mapService.oLayerList.addLayer(PlusManager)
    //             });
    //         }
    //
    //     });
    // }



    //add External Layer End


    var props = {

        scenario:{
            name:"RASOR_SCENARIO",
            descr:"RASOR_SCENARIO_DESCR",
            date :false,
            type:"select",
            typeSelected:{
                name:"pessimistic_scenario",
                descr:"pessimistic_scenario_descr",
                value:"PESSIMISTIC"
            },
            typeAttr:[
                {
                    name:"optimistic_scenario",
                    descr:"optimistic_scenario_descr",
                    value:"OPTIMISTIC"
                },{
                    name:"medium_scenario",
                    descr:"medium_scenario_descr",
                    value:"MEDIUM"
                },{
                    name:"pessimistic_scenario",
                    descr:"pessimistic_scenario_descr",
                    value:"PESSIMISTIC"
                }
            ]
        },

        attributes:{
            name:"RASOR_DAMAGE",
            descr:"RASOR_DAMAGE_DESCR",
            date :false,
            type:"select",
            typeSelected:{
                name:"population_day",
                descr:"population_day_descr",
                value:["27","28","29","56"]
            },
            typeAttr:[
                {
                    name:"off",
                    descr:"off_descr",
                    value:false
                },{
                    name:"structure_damage",
                    descr:"structure_damage_descr",
                    value:["1"]
                },{
                    name:"content_damage",
                    descr:"content_damage_descr",
                    value:["2"]
                },
                // {
                //     name:"car_damage",
                //     descr:"car_damage_descr",
                //     value:["3"]
                // },
                {
                    name:"economic_damage_struttura",
                    descr:"economic_damage_struttura_descr",
                    value:["7"]
                },{
                    name:"economic_damage_contenuto",
                    descr:"economic_damage_contenuto_descr",
                    value:["8"]
                },
                // {
                //     name:"economic_damage_auto",
                //     descr:"economic_damage_auto_descr",
                //     value:["9"]
                // },
                {
                    name:"economic_damage",
                    descr:"economic_damage_descr",
                    value:["7","8","9"]
                }, {
                    name:"population_day",
                    descr:"population_day_descr",
                    value:["27","28","29","56"]
                },{
                    name:"population_low_day",
                    descr:"population_low_day_descr",
                    value:["27"]
                },{
                    name:"population_medium_day",
                    descr:"population_medium_day_descr",
                    value:["28"]
                },{
                    name:"population_high_day",
                    descr:"population_high_day_descr",
                    value:["29"]
                },{
                    name:"population_very_high_day",
                    descr:"population_very_high_day_descr",
                    value:["56"]
                },
                {
                    name:"population",
                    descr:"population_descr",
                    value:["58","59","60","61"]
                },

                {
                    name:"population_low_night",
                    descr:"population_low_night_descr",
                    value:["59"]
                },
                {
                    name:"population_medium_night",
                    descr:"population_medium_night_descr",
                    value:["58"]
                },
                {
                    name:"population_high_night",
                    descr:"population_high_night_descr",
                    value:["60"]
                },
                {
                    name:"population_very_high_night",
                    descr:"population_very_high_night_descr",
                    value:["61"]
                }
            ]
        },
        backgroundLayer:{

            name:"background_layer",
            descr:"background_layer_descr",
            date :false,
            type:"boolean",
            typeSelected:{
                name:"background_layer_water_depth",
                descr:"background_layer_water_depth_descr",
                value:""
            },
            typeAttr:[
                {
                    name:"background_layer_off",
                    descr:"background_layer_off_descr",
                    value:false
                },{
                    name:"background_layer_water_depth",
                    descr:"background_layer_water_depth_descr",
                    value:""
                },{
                    name:"background_layer_hazard_zone",
                    descr:"background_layer_hazard_zone_descr",
                    value:"RASOR_hazard_zones_band2"
                }
            ]
        },
        // hideFeature:{
        //
        //     name:"background_layer",
        //     descr:"background_layer_descr",
        //     date :false,
        //     type:"boolean",
        //     typeSelected:{
        //         name:"view_feature",
        //         descr:"view_feature_descr",
        //         value:true
        //     },
        //     typeAttr:[
        //         {
        //             name:"view_feature",
        //             descr:"view_feature_descr",
        //             value:true
        //         },{
        //             name:"hide_feature",
        //             descr:"hide_feature_descr",
        //             value:false
        //         }
        //     ]
        // }


    }


    function calculateIndicatorsMax(geoJson) {

        geoJson.features.forEach(function(feature) {
            for (var name in feature.properties) {
                if (name.indexOf('indicator_') === 0) {
                    var iid = name.substring(10)
                    if (iid in indicatorsMax) {
                        indicatorsMax[iid] = Math.max(indicatorsMax[iid], feature.properties[name])
                    } else {
                        indicatorsMax[iid] = feature.properties[name]
                    }
                }
            }
        });
        // console.log(indicatorsMax)
    }

    function build_palette(geoJson) {

        geoJson.features.forEach(function (feature) {

            //feature.properties.contourColor = iconService.rasorDamagePalette[iconService.rasor_damage_Palette_Contour(feature)];

            props.attributes.typeAttr.forEach(function (attr) {

                var value = 0;
                var iMax = 0;

                attr.value.forEach(function (id) {

                    if(angular.isUndefined(indicatorsMax[id]))indicatorsMax[id] = 0;

                    if(feature.properties.hasOwnProperty("indicator_"+id)){
                        //sommo i valori degli indicatori da sommare
                        value +=  feature.properties["indicator_"+id];
                        //sommo i valori degli indicatori massimi da sommare
                        iMax += indicatorsMax[id]
                    }
                })

                feature.properties[attr.name+"_value"] = value;

                var valuePercent = (value/iMax)*100;

                var fillColor ="darkgray";

                if (attr.name.indexOf('population') >= 0|| attr.name.indexOf('economic') >= 0){

                    if (valuePercent < 10) {

                        var component = 255-Math.ceil(valuePercent * 12.75)
                        fillColor = 'rgb(255, 255, ' + component + ')'

                    } else if (valuePercent < 30) {

                        var component = 255-Math.ceil(valuePercent * 8.5)
                        fillColor = 'rgb(255,' + component + ', 0)'

                    } else {

                        var component = Math.ceil(valuePercent * 2.55)
                        fillColor = 'rgb(255, 0, ' + component + ')'
                    }

                } else {

                    if (value < 10) {
                        var component = 255-Math.ceil(value * 12.75)
                        fillColor = 'rgb(255, 255, ' + component + ')'

                    } else if (value < 30) {

                        var component = 255-Math.ceil(value * 8.5)
                        fillColor = 'rgb(255,' + component + ', 0)'

                    } else {

                        var component = Math.ceil(value * 2.55)
                        fillColor = 'rgb(255, 0, ' + component + ')'
                    }

                }
                feature.properties[attr.name+"_color"] = fillColor
            })

        })
        return geoJson;

    }

    function build_palette_2 (geoJson){
        geoJson.features.forEach(function (feature) {

            //feature.properties.contourColor = iconService.rasorDamagePalette[iconService.rasor_damage_Palette_Contour(feature)];



            props.attributes.typeAttr.forEach(function (attr) {

                if (attr.value != false) {

                    var value = 0;
                    var iMax = 0;

                    attr.value.forEach(function (id) {

                        if (angular.isUndefined(indicatorsMax[id])) indicatorsMax[id] = 0;

                        if (feature.properties.hasOwnProperty("indicator_" + id)) {
                            //sommo i valori degli indicatori da sommare
                            value += feature.properties["indicator_" + id];
                            //sommo i valori degli indicatori massimi da sommare
                            iMax += indicatorsMax[id]
                        }
                    })


                    feature.properties[attr.name + "_value"] = value;

                    var valuePercent = (value / iMax) * 100;

                    var fillColor = "darkgray";

                    if (attr.name.indexOf('population') >= 0) {
                        if (value > 140) fillColor = aPalette[4]
                        if (value >= 105 && value < 140) fillColor = aPalette[3]
                        if (value >= 70 && value < 105) fillColor = aPalette[2]
                        if (value >= 40 && value < 70) fillColor = aPalette[1]
                        if (value < 40 && value > 20) fillColor = aPalette[0]
                        if (value >= 1 && value < 20) fillColor = "#fff9c6"//palette alterata
                        if (value == 0) fillColor = "transparent"

                    } else if (attr.name.indexOf('economic') >= 0) {
                        if (value > 1500000) fillColor = aPalette[4]
                        if (value >= 1000000 && value < 1500000) fillColor = aPalette[3]
                        if (value >= 500000 && value < 1000000) fillColor = aPalette[2]
                        if (value >= 250000 && value < 500000) fillColor = aPalette[1]
                        if (value < 250000) fillColor = aPalette[0]
                    } else {

                        if (value < 10) {
                            var component = 255 - Math.ceil(value * 12.75)
                            fillColor = 'rgb(255, 255, ' + component + ')'

                        } else if (value < 30) {

                            var component = 255 - Math.ceil(value * 8.5)
                            fillColor = 'rgb(255,' + component + ', 0)'

                        } else {

                            var component = Math.ceil(value * 2.55)
                            fillColor = 'rgb(255, 0, ' + component + ')'
                        }

                    }
                    feature.properties[attr.name + "_color"] = fillColor
                }

            })

        })
        return geoJson;
    }


    function stationClickListener(s) {

        if(s.target.feature.properties.maxvalue <=-9998){
            alert($translate.instant('UNAVAILABLE_DATA'));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/hydrogram_chart_form.html',
            controller: 'hydrogramChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sectionData: function () {

                    return {

                        section : s.target.feature.properties,
                        prop : layerData.prop,
                        serverId: layerObj.server.id

                    };

                }

            }
        })

    }



    function InfoMouseOver(s) {
        if (infoPopUP){
            infoPopUP.mouseOver('rasor_damage', mapLayer._leaflet_id, s.target.feature)
        }
    }

    function InfoMouseOut() {
        if (infoPopUP){
            infoPopUP.mouseOut('rasor_damage', mapLayer._leaflet_id)
        }
    }

    function update2(newProps, onFinish) {
        props = newProps;
        var manager = mapService.oLayerList.getManagerByMapLayer(mapLayer)
        manager.load(onFinish);
    }

    function update(newProps, onFinish){

            if(angular.isUndefined(props.scenario)){
                props.scenario = {};
                props.scenario.typeSelected = {};
                props.scenario.typeSelected.value = "";

                newProps.scenario = {};
                newProps.scenario.typeSelected = {};
                newProps.scenario.typeSelected.value ="";

            }

            if (props.scenario.typeSelected.value != newProps.scenario.typeSelected.value){

                props = newProps;
                var manager = mapService.oLayerList.getManagerByMapLayer(mapLayer)
                manager.load(onFinish);

            }else{
                props = newProps;
                var selectedIndicator = props.attributes.typeSelected;

                for  (var id in mapLayer._layers){

                    var layer = mapLayer._layers[id];

                    layer.feature.properties.fillColor = layer.feature.properties[selectedIndicator.name+"_color"];

                    var opacity = 0.6;
                    var weight =1;

                    if (layer.feature.properties.fillColor == "transparent") opacity = 0;

                    if(props.attributes.typeSelected.value == false){
                        opacity = 0
                        weight = 0
                    }

                    layer.setStyle({
                        //color: layer.feature.properties.contourColor,
                        color:"black",
                        weight: weight,
                        opacity: opacity,
                        fillColor: layer.feature.properties.fillColor,
                        fillOpacity: opacity
                    })
                }
                setBackgroundLayer();

                if(onFinish)onFinish();
            }

    }


    setBackgroundLayer = function () {

        if (backgroundLayer) mapService.removeHardCodedWmsLayer(backgroundLayer);
        var styles =  null;

        //if(props.attributes.typeSelected.name == "population") styles="RASOR_hazard_zones_band2";
        switch (props.backgroundLayer.typeSelected.value){
            case false:
                break;
            case "":
                backgroundLayer = mapService.addHardCodedWmsLayer(lastRasorUrl.scenarioServer,lastRasorUrl.scenarioLayer, null,styles);
                break;
            case "RASOR_hazard_zones_band2":
                styles="RASOR_hazard_zones_band2";
                backgroundLayer = mapService.addHardCodedWmsLayer(lastRasorUrl.scenarioServer,lastRasorUrl.scenarioLayer, null,styles);
        }

        // if(props.backgroundLayer.typeSelected.value) backgroundLayer = mapService.addHardCodedWmsLayer(lastRasorUrl.scenarioServer,lastRasorUrl.scenarioLayer, null,styles);
    }



    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        setMapLayer: function (l) {
            mapLayer = l;
        },

        load: function(onFinish, hydrogram){




            if(hydrogram ){
                obj={
                    "id":hydrogram.id,
                    "feature":hydrogram.feature.DATI_DA,
                    "hydrogram":hydrogram.values[hydrogram.indexOfSeries]
                }
            }else {
                var obj={
                    // "id":"italy.floodproofs.wrfwsm6",
                    "id":layerObj.dataid.split(';')[0],
                    // "feature":"Bisagno,Passerella Firpo",
                    "feature":layerObj.dataid.split(';')[1],
                    "from":menuService.getDateFromUTCSecond(),
                    "to":menuService.getDateToUTCSecond(),
                    "scenario":props.scenario.typeSelected.value
                };
            }

            apiService.post("ddsserie/"+layer.server.id+"/rasorimpacturl/",obj,function (rasorUrl) {

                lastRasorUrl = rasorUrl;

                apiService.getExt(rasorUrl.impactGeoJsonURL,function (data) {

                    var selectedIndicator = props.attributes.typeSelected;


                    calculateIndicatorsMax(data);
                    console.log(indicatorsMax);

                    theGeoJson = build_palette_2(data);

                    if(mapLayer) mapService.removeLayer(mapLayer)

                    mapLayer = mapService.addGeoJsonLayer(theGeoJson.features, props.attributes.typeSelected.descr, {

                        style: function (feature) {

                            feature.fillColor = feature.properties[selectedIndicator.name+"_color"]
                            var opacity = 0.6;
                            var weight = 1;
                            if (feature.fillColor == "transparent") opacity = 0;

                            if(props.attributes.typeSelected.value == false){
                                opacity = 0;
                                weight = 0;
                            }

                            return {
                                //color: feature.properties.contourColor,
                                color: "black",
                                weight: weight,
                                opacity: opacity,
                                fillColor: feature.fillColor,
                                fillOpacity: opacity
                            }
                        }


                    }, null, InfoMouseOver, InfoMouseOut);


                    setBackgroundLayer();

                    if (onFinish) onFinish()

                },function () {
                    alert("ERROR Loading Impact Layer data settings")
                })
            },function () {
                alert("Impossible to load Impact Layer.\nPossibly no data available for this time range")
            })


        },

        disablePros:function () {
            delete props.scenario;
        },

        layerTooltip: function(){

            var manager = this;



            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : manager.name()
                },
                {
                    label : "VARIABLE_DESCRIPTION",
                    value : props.attributes.typeSelected.name
                },
                {
                    label : "SCENARIO_DESCRIPTION",
                    value : props.scenario.typeSelected.name
                }

            ];
            return tooltipObj;
        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        setOpacity : function(value){

            if (value){
                rasorFeatureStyle.opacity = value;
                rasorFeatureStyle.fillOpacity = value;
                //updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return rasorFeatureStyle.opacity
        },


        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (backgroundLayer) mapService.removeHardCodedWmsLayer(backgroundLayer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.descr
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        typeDescr: function () {
            return props.attributes.typeSelected.descr;
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi;
        },

        getWarningInfo:function () {
            return infoPopUP;
        },

        showProps : function (onFinish) {
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties_rasor_damage.html',
                controller: ['$scope', '$uibModalInstance', 'params',function ($scope, $uibModalInstance, params){

                    $scope.data = angular.copy(params.props);

                    $scope.update = function () {

                        $uibModalInstance.close($scope.data);
                    };
                    $scope.closePopup = function () {
                        $uibModalInstance.dismiss()
                    }
                }],
                size: "lg",

                resolve: {
                    params: function() {
                        return {
                            layer: mapLayer,
                            props:props
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj, onFinish)

            }, function () {
                console.log("CANCEL")
            });
        },

        legend:function () {

            var styles =  "";
            if(props.backgroundLayer.typeSelected.value == "RASOR_hazard_zones_band2") {

                styles="&STYLE=RASOR_hazard_zones_band2";
            }

            var legend = {

                type:"ADVANCED",
                legend:[{
                    type:"CUSTOM",
                    title: "IMPACT_LAYER_PALETTE",
                    palette:[{
                        label:"VERY_LOW",
                        color:"#FFFFFF",
                        sign:"<",
                        value:250000,
                        mu:"€",
                        dec:0
                    },{
                        label:"LOW",
                        color:"#FFFF00",
                        sign:"<",
                        value:500000,
                        mu:"€",
                        dec:0
                    },{
                        label:"MODERATE",
                        color:"#FA8B3C",
                        sign:"<",
                        value:1000000,
                        mu:"€",
                        dec:0
                    },{
                        label:"HIGH",
                        color:"#FF0000",
                        sign:"<",
                        value:1500000,
                        mu:"€",
                        dec:0
                    },{
                        label:"VERY HIGH",
                        color:"#C13BDB",
                        sign:"<",
                        value:2000000,
                        mu:"€",
                        dec:0
                    }]
                },{
                    type:"IMAGE",
                    title: "IMPACT_LAYER_BACKGROUND_PALETTE",
                    img:lastRasorUrl.scenarioServer + "?request=GetLegendGraphic&format=image/png&WIDTH=12&HEIGHT=12&LAYER=" + lastRasorUrl.scenarioLayer + styles+"&legend_options=fontAntiAliasing:true;fontSize:10"
                }]
            };

            if(props.attributes.typeSelected.name.indexOf("population")>-1) {

                styles="&STYLE=RASOR_hazard_zones_band2";

                legend.legend[0].palette = [{
                    label:"",
                    color:"#FFFFFF",
                    value:"-",
                    mu:"0",
                    dec:0
                },{
                    label:"LOW",
                    color:"#FFFF00",
                    value:"-",
                    mu:"1-40",
                    dec:0
                },{
                    label:"MODERATE",
                    color:"#FA8B3C",
                    value:"-",
                    mu:"40-80",
                    dec:0
                },{
                    label:"HIGH",
                    color:"#FF0000",
                    value:"-",
                    mu:"80-130",
                    dec:0
                },{
                    label:"VERY HIGH",
                    color:"#C13BDB",
                    value:"-",
                    mu:"> 130",
                    dec:0
                }]
            }



            return legend;
        },

        setVisible: function (b) {
            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        }

    }

}
