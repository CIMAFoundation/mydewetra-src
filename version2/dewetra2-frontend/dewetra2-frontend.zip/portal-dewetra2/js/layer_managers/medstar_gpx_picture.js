/**
 * Created by Dario on 19/04/21.
 *
 *
 */

function layerManager_medstar_gpx_picture(layerObj) {

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices();

    var iOpacity = 1;

    var layerId;

    var downloadUrl;

    var debug = true;

    var aLayers = [];

    var oMarker = L.marker(L.latLng(44, 8))

    var baseLayerObject = layerObj;

    var markerWarningOption = {
        radius : oServices.iconService.markerWarningOptions.radius,
        weight : oServices.iconService.markerWarningOptions.weight,
        color : oServices.iconService.markerWarningOptions.color,
        opacity : oServices.iconService.markerWarningOptions.opacity,
        fillOpacity: oServices.iconService.markerWarningOptions.fillOpacity
    };

    oManager.draggable = function () {
        return false;
    }

    oManager.type = () => {
        return "MEDSTAR_PHENOCAM";
    }
    oManager.typeDescr = () => {
        return "MEDSTAR_PHENOCAM";
    }

    oManager.haveAudio = () => {
        return false;
    }
    oManager.legend = () => {
        return {
            dynPalette: {},
            type: oManager.layerObj().type.code.toUpperCase(),
            url: oManager.mapLayer()._url,
            layers: oManager.mapLayer().wmsParams.layers,
        }
    }

    oManager.canMovie = () => {
        return false;
    }

    oManager.refreshable = () => {
        return false;
    }

    oManager.layerTooltip = () => {
        let tooltipObj = [
            {
                label: "LAYER_NAME",
                value: oManager.name()
            },
            {
                label: "LAYER_DESCRIPTION",
                value: oManager.descr()
            },
            {
                label: "LAYER_TYPE",
                value: oManager.type()
            }

        ];
        return tooltipObj;
    }

    oManager.remove = (layer, onFinish) => {
        oServices.mapService.removeLayer(layer);
        if (onFinish) onFinish()
    }

    oManager.dateLine = (layer, onFinish) => {
        return "";
    }

    oManager.delayLine = (layer, onFinish) => {
        return "";
    }

    oManager.customprops = (layer, onFinish) => {
        if (oManager.layerObj().hasOwnProperty("customprops")) {
            return JSON.parse(oManager.layerObj().customprops)
        }
    }

    oManager.parseInfo = (data) => {
        var ret = {
            layerName: oManager.layerObj().name,
            properties: []
        };

        if (data.features && data.features.length > 0) {
            data.features.forEach(function (f) {
                if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                    ret.properties.push({name: 'value', 'value': f.properties.GRAY_INDEX.toFixed(2)})
                } else {
                    for (p in f.properties) {
                        ret.properties.push({name: p, 'value': f.properties[p]})
                    }
                }
            })
        }

        ret.properties.forEach(function (item) {
            if (item.name == 'link') {
                item.html = true;
            } else item.html = false;
        })

        return ret;
    }

    oManager.loadWithProperties = (onFinish, layerObj, props, item, dateFrom, dateTo, opacity) => {
        oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));
        if (iOpacity) oManager.setOpacity(opacity);
        if (onFinish) onFinish();

    },

    stationClickListener = function (data) {
        console.log(data.target.feature.properties);
        let str = '';
        if(data.target.feature.properties.imgs.length > 0){
            let tok = data.target.feature.properties.imgs[0].split('_');
            let date = moment(tok[3]+tok[4]+tok[5]+tok[6], 'YYYYMMDDHHmmss');
            let path = 'https://psr.cimafoundation.org/api/phenocam/img/'+ data.target.feature.properties.imgs[0]+'/';
            str += '<h3>' +date.format('LLL') + '</h3><img style="width: 300px;" src="' + path + '">'
        }

        data.target.bindPopup(str);

        data.target.openPopup();



    }

    stationMouseOverListener = function (data) {
        console.log(data);
    }

    stationMouseOutListener = function (data) {
        console.log(data);
    }

    oManager.load = function (onFinish) {



        if (oManager.mapLayer()) mapService.removeLayer(oManager.mapLayer());



        oServices.$timeout(function (){
            oServices.mapService.getMap().addLayer(oMarker);
        },1000)

        // oMarker.addTo(oServices.mapService.getMap());

        oMarker.bindPopup('<h3>Image from helicopter</h3><img style="width: 300px" src="apps/dewetra2/img/mockupLandscape.png">')



        oManager.setMapLayer(oMarker);



        if (onFinish) onFinish()

        // oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));
        // if (oManager.customprops() && oManager.customprops().hasOwnProperty('static_multilayer')) {
        //     //includo il layer stesso
        //     // oManager.customprops().static_multilayer.layerlist.push(oManager.layerObj().id);
        //     // debugger
        //     oServices.layerService.getLayers('static', null, (data) => {
        //         aLayers = data.objects.filter(obj => oManager.customprops().static_multilayer.layerlist.includes(obj.id));
        //         aLayers.push(layerObj);
        //         // debugger
        //     });
        //
        // }



    };

    oManager.remove = function (layer, onFinish) {
        try {
            oServices.mapService.getMap().removeLayer(oMarker)
        }catch (e) {
            console.log(e);
        }

        try {
            if (!angular.isUndefined(additionalLayers)){
                additionalLayers.map(mapLayer =>{
                    //oServices.mapService.getMap().removeLayer(mapLayer);
                })
            }
        }catch (e) {
            console.log(e);
        }

        if (onFinish)onFinish()
    }


    oManager.update = function (newProps, newItem, onFinish) {

        let layer = aLayers.filter(layer => layer.dataid == newItem.id)[0];

        oManager.setLayerObj(layer);

        //let opacity = oManager.mapLayer().getOpacity();

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));

        //oManager.mapLayer().setOpacity(opacity)

        if (onFinish) onFinish();
    };


    oManager.layerProps = {
        "layerProperties": {
            "attributes": [
                {
                    "descr": "Variable",
                    "name": "variable",
                    "entries": [{
                        // "descr": "Landslide probability",
                        "descr": "LAYERS_VARIABLE",
                        // "value": "prob;0",
                        "value": "",
                        "referredValues": {
                            "entry": []
                        }
                    }],
                    "id": "variable",
                    "selectedEntry": {
                        // "descr": "Landslide probability",
                        "descr": "LAYERS_VARIABLE",
                        // "value": "prob;0",
                        "value": "",
                        "referredValues": {
                            "entry": []
                        }
                    },
                    "type": "List",
                    "visible": "true"
                }

            ],
            "data": oManager.layerObj().layerId,
            "description": oManager.layerObj().descr,
            "id": oManager.layerObj().layerId,
            "longDescription": oManager.layerObj().descr
        }
    }


    oManager.showProps = function (onFinish) {

        var layerPropModal = oServices.$uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        layer: oManager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {

            oManager.update(obj.props, obj.data, onFinish)
        }, function () {
            if (debug) console.log("CANCEL")
        });
    };

    oManager.customFormatDateDescription = function (data) {
        return data.description
    }

    oManager.item = function () {
        return {
            "date": "2021-02-10T12:00:00Z",
            "description": oManager.layerObj().descr,
            "id": oManager.layerObj().dataid
        }
    }

    oManager.getLayerAvailability = function () {

        return aLayers.map((obj) => {

            return {
                "date": obj.name,
                "description": obj.descr,
                "id": obj.dataid
            }
        });

    };

    return oManager;

    const gpx1= {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {},
                "geometry": {
                    "type": "LineString",
                    "coordinates": [
                        [
                            8.01727294921875,
                            43.88997537383687
                        ],
                        [
                            7.93487548828125,
                            43.971074904863265
                        ],
                        [
                            7.86346435546875,
                            44.05995928349327
                        ],
                        [
                            7.87445068359375,
                            44.13294218313968
                        ],
                        [
                            8.00079345703125,
                            44.16447445668456
                        ],
                        [
                            8.12713623046875,
                            44.15068115978094
                        ],
                        [
                            8.19305419921875,
                            44.07574700247845
                        ],
                        [
                            8.27545166015625,
                            44.12308489306967
                        ],
                        [
                            8.33587646484375,
                            44.213709909702054
                        ],
                        [
                            8.47320556640625,
                            44.3670601700202
                        ],
                        [
                            8.5308837890625,
                            44.5063000997406
                        ],
                        [
                            8.8714599609375,
                            44.42397290075389
                        ]
                    ]
                }
            }
        ]
    };

}
