/**
 * Created by Dario Rubado on 20/01/17.
 */

function layerManager_bulletin_hydro(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService, $timeout){

    var ICON_SIZE = 14;

    var visible=true;

    dateFromFormatted =  function () {
        return moment(menuService.getDateFrom()).format("YYYYMMDD");
    }
    
    dateToFormatted = function () {
        return moment(menuService.getDateTo()).format("YYYYMMDD");
    }

    dateToFormattedYestarday = function () {
        return moment(menuService.getDateTo()).subtract(1, "days").format("YYYYMMDD");
    }

    var level_name = {
        0:"Assente",
        1:"Ordinaria",
        2:"Moderata",
        3:"Elevata"
    }

    var bulletinList= [];

    var bulletin = null;

    var bulletinId = null;

    var bulType = null;
    var bulDate = null;

    var bulTodayTomorrow =null;
    
    var urlBulletinHydroByDateOk = "http://dds.cimafoundation.org/webalert2/api/bulletin/?day_string__range="+ dateFromFormatted()+","+dateToFormatted();
    var urlBulletinHydroByDate = "http://dds.cimafoundation.org/webalert2/api/bulletin/?day_string__range=20161201,20161228";
    
    // var urlBulletinHydroById = "http://dds.cimafoundation.org/webalert2/api/getYesterdayTodayWa/?bulletin__id="+bulletinId;

    function urlBulletinListByDate() {
        // return"http://dds.cimafoundation.org/webalert2/api/bulletin/?day_string__range=20161201,20161228";
        console.log(apiService.buildBulletinHydroUrl("bulletin/?day_string__range="+ dateFromFormatted()+","+dateToFormatted()));
        return apiService.buildBulletinHydroUrl("bulletin/?day_string__range="+ dateFromFormatted()+","+dateToFormatted())
        // console.log("http://dds.cimafoundation.org/webalert2/api/bulletin/?day_string__range="+ dateFromFormatted()+","+dateToFormatted());
        // return "http://www.mydewetra.org/webalert2/api/bulletin/?day_string__range=20180110,20180124";
        // return "http://www.mydewetra.org/webalert2/api/bulletin/?day_string__range="+ dateFromFormatted()+","+dateToFormatted();
    }
    function urlBulletinListByDateYesterday() {
        // return"http://dds.cimafoundation.org/webalert2/api/bulletin/?day_string__range=20161201,20161228";
        console.log(apiService.buildBulletinHydroUrl("bulletin/?day_string__range="+ dateFromFormatted()+","+dateToFormatted()));
        return apiService.buildBulletinHydroUrl("bulletin/?day_string__range="+ dateFromFormatted()+","+dateToFormatted())
        // console.log("http://dds.cimafoundation.org/webalert2/api/bulletin/?day_string__range="+ dateFromFormatted()+","+dateToFormatted());
        // return "http://www.mydewetra.org/webalert2/api/bulletin/?day_string__range=20180110,20180124";
        // return "http://www.mydewetra.org/webalert2/api/bulletin/?day_string__range="+ dateFromFormatted()+","+dateToFormatted();
    }

    function urlBulletinHydroById() {
        console.log(apiService.buildBulletinHydroUrl("getYesterdayTodayWa/?bulletin_id="+bulletinId));
        return apiService.buildBulletinHydroUrl("getYesterdayTodayWa/?bulletin_id="+bulletinId+"&map_id="+bulTodayTomorrow);
        // console.log("http://www.mydewetra.org/webalert2/api/getYesterdayTodayWa/?bulletin_id="+bulletinId);
        // return "http://www.mydewetra.org/webalert2/api/getYesterdayTodayWa/?bulletin_id="+bulletinId;
    }

    var colors = iconService.bulletin_hydro_Colors;


    var markerFloodOption = {
        radius : iconService.markerFloodOptions.radius,
        weight : iconService.markerFloodOptions.weight,
        color : iconService.markerFloodOptions.color,
        opacity : iconService.markerFloodOptions.opacity,
        fillOpacity: iconService.markerFloodOptions.fillOpacity
    };

    
    function update(newProps,newData, onFinish) {

        bulletin = newProps.bulletinId

        bulletinId = newProps.bulletinId.id;
        bulDate = newProps.bulletinId.today_day;
        bulDate = newProps.bulletinId.tomorrow_day;
        bulType = newProps.bulletinId.bull_type;
        bulTodayTomorrow = newProps.date;

        setNewLayer(onFinish);
    }

    function setNewLayer(onFinish){

        if(mapLayer)mapService.removeLayer(mapLayer);

        apiService.getExt(urlBulletinHydroById(), function (bulletin) {
            // console.log(bulletin);
            theGeoJson = bulletin.objects

            mapLayer = mapService.addGeoJsonLayer(theGeoJson, layer['descr'],{


            }, stationClickListener,stationInfoMouseOver, stationInfoMouseOut);

            mapLayer.setStyle(function(feature) {
                var nCol = iconService.bulletin_hydro_Icon(feature.properties.crit_idro,feature.properties.crit_idrogeo,feature.properties.crit_temp);
                return {color: "#000000", "weight": 1, opacity: 1, fillColor: colors[nCol], fillOpacity: 0.6};
            });

            if (onFinish) onFinish()

        });

    }

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;




    //add External Layer End

    function stationInfoMouseOver(s){
        if(infoPopUP){
            s.target.feature.properties.bulletin = bulletin;
            infoPopUP.mouseOver('BULLETIN_HYDRO',mapLayer._leaflet_id, s.target.feature.properties  )
        }
    }

    function stationInfoMouseOut(){
        if(infoPopUP){
            infoPopUP.mouseOut('BULLETIN_HYDRO',mapLayer._leaflet_id)
        }
    }

    function stationClickListener(s) {

        if(!angular.isDefined(s.target.feature.properties.id )){
            alert($translate.instant('UNAVAILABLE_DATA'));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/bulletin_hydro_click_detail.html',
            controller:['$scope', '$uibModal', '$uibModalInstance','feature', function($scope, $uibModal, $uibModalInstance,feature){

                var list = angular.copy(feature.properties)

                var level_name = {
                    0:"Assente",
                    1:"Ordinaria",
                    2:"Moderata",
                    3:"Elevata"
                }

                for(var p in list){
                    if (p.indexOf("crit")>-1){
                        list[p] = level_name[list[p]];
                    }
                }


                $scope.featureProp = list;
            }],
            size: 'lg',
            keyboard: false,
            resolve: {

                feature: function () {

                    return {

                        properties : s.target.feature.properties

                    };

                }

            }
        })

    }



    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        canMovie: function(){
            return false
        },

        load: function(onFinish) {
            
            apiService.getExt( urlBulletinListByDate(), function (data) {
                // console.log(data)


                if(data.objects.length >0){
                    bulletinList = data.objects;

                    bulletin =bulletinList[0];
                    bulletinId = bulletinList[0].id
                    bulType = bulletinList[0].bull_type;
                    bulDate= bulletinList[0].today_day;

                    // moment(, "YYYYMMDD");

                    (moment().diff(moment(bulletinList[0].day_string,"YYYYMMDD"),"days")>0)?bulTodayTomorrow = 'tomorrow':bulTodayTomorrow = 'today'

                    apiService.getExt(urlBulletinHydroById(), function (bulletin) {

                        theGeoJson = bulletin.objects;

                        mapLayer = mapService.addGeoJsonLayer(theGeoJson, layer['descr'],{
                            style: function(feature, latlng) {

                                var nCol = iconService.bulletin_hydro_Icon(feature.properties.crit_idro,feature.properties.crit_idrogeo,feature.properties.crit_temp);
                                return {color: "#000000", "weight": 1, opacity: 1, fillColor: colors[nCol], fillOpacity: 0.6};
                            }


                        }, stationClickListener,stationInfoMouseOver, stationInfoMouseOut);



                        if (onFinish) onFinish()

                    });
                }else {


                    alert("no Bulletin from:"+dateFromFormatted()+ " to :"+ dateToFormatted());
                }

                },
                function () {
                    console.log("Error Loading bulletin")
                })

        },

        layerTooltip: function(){

            // var manager = mapService.getLayerManager(mapLayer);
            var methodName = bulTodayTomorrow+"_day";

            var dict = {
                first:"Prima",
                update:"Update",
                errata_corrige:"Errata Corrige",
            }


            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : this.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : this.typeDescr()
                },
                {
                    label : "BULLETIN_DATE",
                    value : bulDate
                },
                {
                    label : "BULLETIN_TYPE",
                    value : dict[bulType]
                },
                {
                    label : "MAP_ID",
                    value : bulletin[methodName]
                }

            ];


            return tooltipObj;
        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        legend:function () {
            return {
                dynPalette:{},
                type: "DYNAMIC_EXTERNAL_WMS_IZS_EXT",
                url: "img/legend_bulletin_hydro.png"
                //layers:mapLayer.wmsParams.layers,
            }
        },

        setOpacity : function(value){

            if (value){
                markerFloodOption.opacity = value;
                markerFloodOption.fillOpacity = value
            }
        },

        getOpacity : function(){
            return markerFloodOption.opacity
        },

        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.descr
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        delayLine:function(){
            return "";
        },

        dateLine:function(){
            return bulDate;
        },

        typeDescr: function () {
            return "BULLETIN_HYDRO"
        },

        refreshable : function () {
            return true;
        },
        haveDynamicPalette:function(){
            return false;
        },

        refresh:function(onFinish){
            if (menuService.isRealTime() ) {
                update(props, props, onFinish)
            }
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi
        },

        setVisible: function (b) {

            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        },

        // update: function(obj, onFinish){
        //     update(obj.props, obj.data, onFinish)
        // },

        showProps: function(onFinish) {
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties_bulletin_hydro.html',
                controller: ['$scope', 'layerService', 'mapService', 'menuService', '$uibModalInstance', 'params', '$interval', '$translate', function ($scope, layerService, mapService, menuService, $uibModalInstance, params, $interval, $translate, _) {

                    $scope.formatMe = function (string) {
                        switch (string) {
                            case "TODAY":
                                return $scope.bulletinList[index].today_day;
                                break;
                            case "TOMORROW":
                                return $scope.bulletinList[index].tomorrow_day;
                                break;
                        }
                    }

                    $scope.bulletinList = params.bulletinList;

                    var index = _.findIndex($scope.bulletinList,function (bulletin) {
                        return (bulletin.id == bulletinId)
                    })

                    $scope.update = function () {
                        $uibModalInstance.close($scope.data);
                    };
                    $scope.closePopup = function () {
                        $uibModalInstance.dismiss();
                    };
                    $scope.data = {};
                    $scope.data.bulletinId = $scope.bulletinList[index];

                    $scope.data.date = params.bulTodayTomorrow

                    $scope.bulletinNameFormatter = function (opt) {
                        var string =  opt.today_day+" - "+opt.bull_type;
                        return string;
                    }


                    console.log("test")


                }],
                size: "lg",
                resolve: {
                    params: function() {
                        return {
                            bulletinList:bulletinList,
                            bulletinId: bulletinId,
                            bulTodayTomorrow:bulTodayTomorrow
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj, obj, onFinish)
            }, function () {
                console.log("CANCEL")
            });
        }

    }

}
