/**
 * Created by Dario Rubado on 12/09/16.
 */

function layerManager_dynamic_async_ext(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout) {

    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout)

    //spengo refresh automatico
    //manager.setRefresh(false)



    //costruisco chiamata a rabbit
    manager.updateListener = function() {

        console.log("update Listener");

        acEvent.connect('logger', 'logger4dew', function () {

            console.log("Connecting to rabbit for layer: "+ manager.dataid());

            manager.wsAcquisition = acEvent.subscribe('dynamic_async', manager.mAsyncUpdate);

        },function () {
            console.log('waiting 5 seconds and then reconnect');
            manager.promise = $timeout(manager.updateListener, 5000)
        })

    };

    manager.removeListener =  function () {
        acEvent.unsubscribe(manager.wsAcquisition);
        manager.wsAcquisition = null;
        if (manager.promise) $timeout.cancel(manager.promise)
        console.log("unsubscribe")
    },

    //eseguo chimata rabbit
    manager.updateListener();

    return manager; }