/**
 * Created by Dario Rubado on 27/10/19.
 */




function layerManager_sadc(layerObj) {

    

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices()

    var oTheGeoJson = null;

    var sKey,sHazardKey;

    var variable ='';

    var legend = {

        type: "ADVANCED",
        legend: [{
            type: "CUSTOM",
            title: "SADC",
            palette: [{
                label: oServices.$translate.instant('NOALERT'),
                color: "#00ff00",
                sign: "",
                value: 1,
                mu: "",
                dec: 0,
                minValue: 1,
                maxValue: 1,
            },{
                label: oServices.$translate.instant('ADVISORY'),
                color: "#fdff4f",
                sign: "",
                value: 2,
                mu: "",
                dec: 0,
                minValue: 2,
                maxValue: 2,
            },{
                label: oServices.$translate.instant('WATCH'),
                color: "#e1740e",
                sign: "",
                value: 3,
                mu: "",
                dec: 0,
                minValue: 3,
                maxValue: 3,
            }, {
                label: oServices.$translate.instant('WARNING'),
                color: "#ff0000",
                sign: "",
                value: 4,
                mu: "",
                dec: 0,
                minValue: 4,
                maxValue: 4,
            }]

    }]
    }

    var isVisible = true;

    var oLegend = {}


    var iOpacity = 1;

    oManager.legend = function () {
        return legend
    }

    function paletter(geoJson) {

    }

    function paletteFeature(aPalette, iFeatureValue) {


    }

    function onClick(e) {
        //console.log(alert(e.target.feature.properties.aggregations[sKey]))
    }

    function onMouseOver(e) {


        if(oManager.hasOwnProperty("getWarningInfo")){

            let geoServerPalette =""
            console.log(e)
            //e.target.feature.properties.data = {key:sKey,value:e.target.feature.properties.aggregations[sKey.toLowerCase()]}

            oManager.getWarningInfo().mouseOver('SADC',oManager.mapLayer()._leaflet_id, e.target.feature.properties, 'geoServerPalette')
        }

        console.log(e)

        //e.target.bindPopup(e.target.feature.properties.aggregations[sKey.toLowerCase()]);
        //e.target.openPopup()
    }

    function onMouseOut(e) {
        console.log(e)

        oManager.getWarningInfo().mouseOut('SADC',oManager.mapLayer()._leaflet_id)

        e.target.closePopup()
    }



    function featureStyler(feature) {

        if(feature.properties.periods.Today.params && !angular.isUndefined(feature.properties.periods.Today.params[variable])){

            var value =  parseInt(feature.properties.periods.Today.params[variable].level) ;
            // var value =  parseInt(feature.properties.periods.Today.level);

            var p = legend.legend[0].palette[value -1];

            return{
                color: "#666666",
                weight: 1,
                fillColor: p.color,
                fillOpacity: 0.6,
                opacity: iOpacity
            }

        }else if(angular.isUndefined(feature.properties.periods.Today.params[variable])) {

            //var value = feature.properties.periods.Today.level

            var p = legend.legend[0].palette[0];

            return {
                color: "#666666",
                weight: 1,
                fillColor: p.color,
                fillOpacity: 0.6,
                opacity: iOpacity
            }

        }
    }

    oManager.load = function (onFinish) {

    //39 flood  38 fires //37 drought

        switch (layerObj.dataid.split("/")[1]) {
            case  "drought":
                variable = 37;
                break;
            case "fire":
                variable = 38;
                break;
            case "flood":
                variable = 39;
                break;
        }


        var url = layerObj.server.url + layerObj.dataid;
        //var url ='http://130.251.104.12:8100/sdac-climate-early-warning/drought';

        //var url = layerObj.server.url + layerObj.dataid;
        oServices.apiService.getExt(url, function (data) {

            oManager.setMapLayer(
                oServices.mapService.addGeoJsonLayer(data.areaData, "layerObj.descr", {
                    style:featureStyler
            }, onClick, onMouseOver, onMouseOut));


            var corner1 = L.latLng(-4, -9.90),
                corner2 = L.latLng(-39.82, 61.84),
                bounds = L.latLngBounds(corner1, corner2);

            oServices.mapService.getMap().fitBounds(bounds)

            //oManager.mapLayer().setStyle(featureStyler)

            if (onFinish) onFinish()

        })


    }

    oManager.update = function () {

        let sQueryString = '';

        oManager.props().layerProperties.attributes.forEach(function (oAttr) {

            if(oAttr.hasOwnProperty("querystring")){
                if(oAttr.selectedEntry.value != "DEFAULT"){
                    if(sQueryString.indexOf("?")>-1){
                        sQueryString+= "&"+oAttr.querystring+"="+oAttr.selectedEntry.value+""
                    }else {
                        sQueryString+= "?"+oAttr.querystring+"="+oAttr.selectedEntry.value+""
                    }

                }
            }
        })



        oServices.apiService.getExt(layerObj.server.url + '/layer/' + layerObj.dataid + '/' + oManager.props().layerProperties.attributes[0].selectedEntry.value+sQueryString, function (data) {

            if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

            oTheGeoJson = data;

            sKey = oManager.props().layerProperties.attributes[1].selectedEntry.value

            paletter(data)

            oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(oTheGeoJson, layerObj.descr, {
                style: featureStyler
            }, onClick, onMouseOver, onMouseOut));


        })
    }





    oManager.setOpacity = function (value) {

        if (value) {
            for ( let i in oManager.mapLayer()._layers){
                iOpacity = value
                oManager.mapLayer()._layers[i].setStyle(featureStyler(oManager.mapLayer()._layers[i].feature))
            }
        }
    }

    oManager.getOpacity = function () {
        return iOpacity
    }


    oManager.setVisible = function (b) {

        if(!b) {
            if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());
        }else {
            oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(oTheGeoJson, layerObj.descr, {
                style: featureStyler
            }, onClick, onMouseOver, onMouseOut));
        }

        isVisible = b
    }

    oManager.isVisible = function () {
        return isVisible
    }




    return oManager

}
