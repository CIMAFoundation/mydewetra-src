/**
 * Created by Dario Rubado on 20/01/17.
 */

function layerManager_bulletin_fire(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService, $timeout){

    var ICON_SIZE = 14;

    var visible=true;

    dateFromFormatted =  function () {
        return moment(menuService.getDateFrom()).format("YYYYMMDD");
    }

    dateToFormatted = function () {
        return moment(menuService.getDateTo()).format("YYYYMMDD");
    }

    var bulletinList= [];

    var bulletinId = null;

    var bultype = null;
    var buldate

    var map_id = 'today'; //or tomorrow in today is the prevision for tomorrow and tomorrow for the day after tomorrow



    function urlBulletinListByDate() {
        return window.app.url.bulletinFireUrl+"bulletin/?day_string__range="+ dateFromFormatted()+","+dateToFormatted();
    }

    function urlBulletinHydroById() {

        return window.app.url.bulletinFireUrl+"getYesterdayTodayWa/?bulletin_id="+bulletinId;
    }



    var colors = [
        '#a1ffa7',
        'orange',
        'red',
    ];


    var markerFloodOption = {
        radius : iconService.markerFloodOptions.radius,
        weight : iconService.markerFloodOptions.weight,
        color : iconService.markerFloodOptions.color,
        opacity : iconService.markerFloodOptions.opacity,
        fillOpacity: iconService.markerFloodOptions.fillOpacity
    };

    var getColurVal = function(crit_fire) {

        return crit_fire;
    }


    function update(newProps,newData, onFinish) {

        bulletinId = newProps.bulletinId.id;

        buldate = newProps.bulletinId.buldate
        bultype = newProps.bulletinId.bull_type
        map_id = newProps.date

        setNewLayer(onFinish);
    }

    function setNewLayer(onFinish){

        if(mapLayer)mapService.removeLayer(mapLayer);

        apiService.getExt(urlBulletinHydroById(), function (bulletin) {
            // console.log(bulletin);
            theGeoJson = bulletin.objects.filter(obj => obj.properties.map_id == map_id);

            mapLayer = mapService.addGeoJsonLayer(theGeoJson, layer['descr'],{


            }, stationClickListener,stationInfoMouseOver, stationInfoMouseOut);

            mapLayer.setStyle(function(feature) {

                return {color: "#000000", "weight": 1, opacity: 1, fillColor: colors[feature.properties.crit_fire], fillOpacity: 0.6};
            });

            if (onFinish) onFinish()

        });

    }

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;




    //add External Layer End

    function stationInfoMouseOver(s){
        if(infoPopUP){
            infoPopUP.mouseOver('BULLETIN_HYDRO',mapLayer._leaflet_id, s.target.feature.properties  )
        }
    }

    function stationInfoMouseOut(){
        if(infoPopUP){
            infoPopUP.mouseOut('BULLETIN_HYDRO',mapLayer._leaflet_id)
        }
    }

    function stationClickListener(s) {

        if(!angular.isDefined(s.target.feature.properties.id )){
            alert($translate.instant('UNAVAILABLE_DATA'));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/bulletin_hydro_click_detail.html',
            controller:[ '$scope', '$uibModal', '$uibModalInstance','feature',function($scope, $uibModal, $uibModalInstance,feature){
                $scope.featureProp = feature.properties;
            }],
            size: 'lg',
            keyboard: false,
            resolve: {

                feature: function () {

                    return {

                        properties : s.target.feature.properties

                    };

                }

            }
        })

    }






    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        canMovie: function(){
            return false
        },

        load: function(onFinish) {

            apiService.getExt( urlBulletinListByDate(), function (data) {
                // console.log(data)


                if(data.objects.length >0){

                    bulletinList = data.objects;

                    bulletinId = bulletinList[bulletinList.length-1].id;

                    bultype = bulletinList[bulletinList.length-1].bull_type;
                    buldate= bulletinList[bulletinList.length-1].buldate;

                    //filtrare per map_id today  tomorrow

                    apiService.getExt(urlBulletinHydroById(), function (bulletin) {
                        //console.log(bulletin);
                        theGeoJson = bulletin.objects.filter(obj => obj.properties.map_id == map_id);

                        mapLayer = mapService.addGeoJsonLayer(theGeoJson, layer['descr'],{
                            style: function(feature, latlng) {

                                return {color: "#000000", "weight": 1, opacity: 1, fillColor: colors[feature.properties.crit_fire], fillOpacity: 0.6};
                            }

                        }, stationClickListener,stationInfoMouseOver, stationInfoMouseOut);



                        if (onFinish) onFinish()

                    });
                }else {
                    alert("no Bulletin from:"+dateFromFormatted()+ " to :"+ dateToFormatted());
                }

                },
                function () {
                    console.log("Error Loading bulletin")
                })

        },

        layerTooltip: function(){

            // var manager = mapService.getLayerManager(mapLayer);


            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : this.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : this.typeDescr()
                }

            ];
            return tooltipObj;
        },

        // onDateChange:function(onFinish){
        //
        //     if (mapLayer) mapService.removeLayer(mapLayer);
        //     this.load(onFinish)
        //
        // },

        legend:function () {

        },

        setOpacity : function(value){

            if (value){
                markerFloodOption.opacity = value;
                markerFloodOption.fillOpacity = value
            }
        },

        getOpacity : function(){
            return markerFloodOption.opacity
        },

        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.descr;
        },

        descr: function () {
            return buldate;
        },
        draggable: function () {
            return false;
        },

        typeDescr: function () {
            return "BULLETIN_FIRE";
        },

        delayLine:function(){
            return bultype;
        },

        dateLine:function(){
            return buldate;
        },

        refreshable : function () {
            return true;
        },

        refresh:function(onFinish){
            if (menuService.isRealTime() ) {
                update(props, props, onFinish)
            }
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi
        },

        setVisible: function (b) {

            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        },

        // update: function(obj, onFinish){
        //     update(obj.props, obj.data, onFinish)
        // },

        showProps: function(onFinish) {
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties_bulletin_fire.html',
                controller: ['$scope', 'layerService', 'mapService', 'menuService', '$uibModalInstance', 'params', '$interval', '$translate', '_', function($scope, layerService, mapService, menuService, $uibModalInstance, params, $interval, $translate, _) {

                    $scope.bulletinList = params.bulletinList;

                    $scope.update = function () {
                        $uibModalInstance.close($scope.data);
                    };
                    $scope.closePopup = function () {
                        $uibModalInstance.dismiss();
                    };
                    $scope.data = {};
                    $scope.data.bulletinId = {id: params.bulletinId};

                    $scope.data.date = params.date;

                    $scope.bulletinNameFormatter = function (opt) {
                        var string =  opt.buldate+" - "+opt.bull_type;
                        return string;
                    }



                }],
                size: "lg",
                resolve: {
                    params: function() {
                        return {
                            bulletinList:bulletinList,
                            date: map_id,
                            bulletinId: bulletinId

                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj, obj, onFinish)
            }, function () {
                console.log("CANCEL")
            });
        }

    }

}
