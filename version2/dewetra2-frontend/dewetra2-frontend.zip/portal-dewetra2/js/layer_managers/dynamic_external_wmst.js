/**
 * Created by Mirko on 26/02/18.
 */

var HYDS_API_KEY = 'u2bzchm9d89l5gxa0sunvo5konr9ov1e';

function encodeData(data) {
    return Object.keys(data).map(function(key) {
        return [key, data[key]].map(encodeURIComponent).join("=");
    }).join("&");
}

angular
    .module('dewetra')
    .service('WMSTService',
        function($http, $q){
        return _WMSTService($http, $q);
});

var _WMSTService = function($http, $q){
    if($http===undefined) {
        $http = angular.injector(["ng"]).get("$http");
    }
    if($q===undefined) {
        $q = angular.injector(["ng"]).get("$q");
    }
    var service = this;

    var context = new Jsonix.Context([XLink_1_0, WMS_1_3_0], {
        namespacePrefixes : {
            "http://www.opengis.net/wms" : "",
            "http://www.w3.org/1999/xlink" : "xlink"
        },
        mappingStyle : "simplified"
    });
    // Create an unmarshaller (parser)
    var unmarshaller = context.createUnmarshaller();

    this.getLayerTimeLine = function(server, layer){
        //check if wms is in url
        var base_url = server.replace('/wms', '/' + layer + '/wms');
        var params = encodeData({
           service:'WMS',
           version:'1.3.0',
           request:'GetCapabilities',
           apikey: HYDS_API_KEY
        });
        var url = base_url + '?' + params;

        var p = $q.defer();
        unmarshaller.unmarshalURL(url, function(result) {
            console.log(result);
            var layers = result.WMS_Capabilities.capability.layer.layer;
            //layers should be of length 1, take the first element
            if(!layers || layers.length==0){
                alert('Something went wrong while getting the timeline from ' + url);
            }
            var l = layers[0];
            var timeline = l.dimension?l.dimension[0].value.split(','):null;
            p.resolve(timeline);

        });

        return p.promise;
    };

    return service;
};


function layerManager_dynamic_external_wmst(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout) {
    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout);
    var $q = angular.injector(["ng"]).get("$q");

    var items = null;
    var visible = true;
    var layer = null;


    manager.layerId = layerObj.dataid;
    var WMSParams = {
        service: 'WMS',
        request: 'GetMap',
        version: '1.1.1',
        layers: manager.layerId,
        styles: '',
        format: 'image/png',
        transparent: true,
        apikey: HYDS_API_KEY
    };
    manager.wmsParams = WMSParams;

    var WMSTService = new _WMSTService();

    function loadLayerAvailability(){
        if(items!==null){
            var p = $q.defer();
            $timeout(function(){
               p.resolve(items);
            });
            return p.promise;
        }else {
            return WMSTService.getLayerTimeLine(layerObj.server.url, layerObj.dataid)
                .then(function (timeline) {
                    if(timeline) {
                        items = timeline.map(function (t) {
                            var date = moment(t).toDate();
                            var utc_date = moment(t).utc();

                            var item = {
                                date: utc_date,
                                description: date.toUTCString(),
                                date_string: t,
                                id: '' + utc_date.valueOf()
                            };
                            return item;
                        });
                    }else{
                        var date = moment().toDate();
                        var utc_date = moment(date).utc();
                        items = [
                            {
                                date: utc_date,
                                description: date.toUTCString(),
                                date_string: null,
                                id: '' + utc_date.valueOf()
                            }
                        ]
                    }

                    return items;
                });
        }
    }

    function update(newProps, newItem, onFinish, bScrambling) {
        manager.setProps(newProps);
        manager.setItem(newItem);
        if (manager.mapLayer()) {
            manager.setlayerOpacity(manager.mapLayer().options.opacity);
            mapService.removeLayer(manager.mapLayer());
        }

        if (manager.layerOpacity()) {
            manager.mapLayer().setOpacity(manager.layerOpacity())
        }

        if (onFinish) onFinish();
        manager.setCurrentLayer();
    }

    manager.hardcodedProperties = function() {
        return true;
    };

    manager.legend = function () {
        var legend_url = layerObj.server.url;


        return {
            //type: 'DYNAMIC_FORCERULE',
            type: 'DYNAMIC',
            layers: layerObj.dataid,
            url: legend_url
        }
    };

    manager.initializeMoveOptions = function() {
        loadLayerAvailability()
            .then(function(items){
                manager.setCanMovie(items.length > 1);
                if (manager.canMovie()) {
                    //cerco l'index del layer caricato precedentemente
                    var iIndexLoadedLayer = _.findIndex(items, function(item) {
                        return item.id == manager.item().id;
                    });
                    //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                    iIndexLoadedLayer = (iIndexLoadedLayer > -1)?iIndexLoadedLayer:1;

                    //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                    manager.infoAvaialability(iIndexLoadedLayer + 1, items.length);
                    manager.infoAvaialability().reverse = items[0].date > items[1].date;
                }
            });
    };

    manager.layerProps = {
        "layerProperties": {
            "attributes": [
            ],
            "data": manager.layerId,
            "description": layerObj.descr,
            "id": manager.layerId,
            "longDescription": layerObj.descr
        }
    };


    manager.load = function(onFinish) {
        loadLayerAvailability().then(function(items){
            manager.setProps(manager.layerProps);
            var item = items[items.length-1];
            manager.setItem(item);
            //inizializzo le opzioni per la movie
            manager.initializeMoveOptions();
            if (onFinish) onFinish();
            manager.setCurrentLayer();
        });
    };

    var playHook = null;
    manager.play = function(){
        if(playHook){
            $interval.cancel(playHook);
            playHook = null;
        }else {
            playHook = $interval(function () {
                manager.goForward();
            }, 2000);
        }
    };

    manager.canPlay = function(){
        return playHook==null;
    };


    manager.onDateChange = function(onFinish){
        if (manager.infoAvaialability) manager.infoAvaialability(items.length, items.length);
        update(manager.props(), items[items.length - 1], onFinish)
    };

    manager.goForward = function() {
        var idx = _.findIndex(items, function (i){
            return i.id == manager.item().id;
        });

        idx = idx ? idx : 0;
        var new_idx = (idx+1)%items.length;
        console.log('forward', idx, items.length);

        if (manager.infoAvaialability) {
            manager.infoAvaialability(new_idx+1, items.length);
        }

        update(manager.props(), items[new_idx], function() {
            mapService.oLayerList.updateLayer(manager)
        });
    };

    manager.goBackward = function() {
        var idx = _.findIndex(items, function (i) {
            return i.id == manager.item().id;
        });

        idx = idx ? idx : items.length-1;
        var new_idx = (idx-1)%items.length;
        console.log('backward', idx, items.length);

        if (manager.infoAvaialability) {
            manager.infoAvaialability(new_idx, items.length);
        }
        update(manager.props(), items[new_idx], function () {
            mapService.oLayerList.updateLayer(manager)
        });
    };

    manager.showProps = function (onFinish) {
        console.log('props');
        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function() {
                    return {
                        layer: manager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {
            update(obj.props, obj.data, onFinish)
        }, function () {
            console.log("CANCEL")
        });
    };

    manager.setCurrentLayer = function(){
        var item = manager.item();
        console.log(item);
        if(item.date_string) {
            WMSParams['time'] = item.date_string;
        }
        if(layer){
            manager.remove(layer);
        }
        layer = mapService.addSingleTileWmsLayer(layerObj.server.url, WMSParams);
        manager.setMapLayer(layer);
    };

    manager.getLayerAvailability = function() {
        return items;
    };

    manager.setVisible = function(b){
        visible = b;
        if (!visible && layer) {
            layer.setOpacity(0);
        }else{
            layer.setOpacity(1);
        }
    };

    manager.isDraggable = function(){
        return true;
    };

    manager.isVisible = function(){
        return visible;
    };

    manager.layerTooltip = function(){

        console.log(manager.item());
        return [{
            label : "LAYER_NAME",
            value : this.name()
        },
            {
                label : "LAYER_DESCRIPTION",
                value : this.descr()
            },
            {
                label : "DATE_RUN",
                value : (manager.item().id)?this.dateRun().format("DD/MM/YYYY HH:mm"):""
            }]
    };

    console.log(manager.mapLayer);

    return manager;

}