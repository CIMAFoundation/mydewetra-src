/**
 * Created by Dario Rubado on 27/10/20
 */




function layerManager_fews_po(layerObj) {

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices()

    var isVisible = true;

    var oLegend = {}

    var oLayerData = null;

    var iOpacity = 1;

    var infoPopUP = oManager.getWarningInfo();


    const stationClickListener = (s) =>{
        if(s.target.feature.properties.maxvalue <=-9998){
            alert(oServices.$translate.instant('UNAVAILABLE_DATA'));
            return; //da scommentare dopo test
        }

        if(s.target.feature.properties.maxvalue == '-7777'||s.target.feature.properties.maxvalue == '-6666'||s.target.feature.properties.maxvalue == '-5555'){
            alert(oServices.$translate.instant(s.target.feature.properties.maxvalue));
            return;
        }

        const modalInstance = oServices.$uibModal.open({

            templateUrl: 'apps/dewetra2/views/hydrogram_chart_form.html',
            controller: 'hydrogramChartController',
            size: 'lg',
            keyboard: false,
            resolve: {
                sectionData: function () {
                    return {
                        section : s.target.feature.properties,
                        prop : oLayerData.prop,
                        serverId: layerObj.server.id,
                        serie: oLayerData.layer.dataid
                    };
                }
            }
        })
    };
    const stationInfoMouseOver = (s) => {
        infoPopUP = oManager.getWarningInfo();

        if(infoPopUP){
            //console.log(s.target.feature.properties);
            infoPopUP.mouseOver('FEWS',oManager.mapLayer()._leaflet_id, s.target.feature.properties)
        }
    };
    const stationInfoMouseOut = () => {
        infoPopUP = oManager.getWarningInfo();
        if(infoPopUP){
            infoPopUP.mouseOut('FEWS',oManager.mapLayer()._leaflet_id)
        }
    };


    const AddBackgroundLayer = () => {
        const layerToAdd = 49;
        oServices.apiService.get("settings/layers/?id="+layerToAdd,function(obj){

            let AlreadyLoaded = false;
            const dataId =obj.objects[0].dataid;

            const o = oServices.mapService.getLayerTest();
            if (o.draggable){
                o.draggable.forEach(function (data) {
                    if (data.wmsParams.layers == dataId){
                        AlreadyLoaded = true;
                    }
                })
            }

            //
            function buildLayerManager(layer) {
                const mangerName = 'layerManager_' + layer['type'].code;
                const manager = window[mangerName](layerObj, oServices.mapService, oServices.layerService, oServices.serieService, oServices.menuService, oServices.$uibModal, oServices.acEvent,oServices.audioService,oServices.tagService,oServices.apiService, oServices._, oServices.sentinelService,  oServices.$interval, oServices.floodproofsService);

                return manager;
            }
            if (AlreadyLoaded){
                console.log("Gia Caritcato")
            }else{
                const PlusManager = buildLayerManager(obj.objects[0]);
                PlusManager.load(function () {
                    oServices.mapService.setlayerManager(PlusManager.mapLayer(), PlusManager);
                    oServices.mapService.oLayerList.addLayer(PlusManager)
                });
            }

        });
    }

    oManager.load = function (onFinish) {

        oServices.serieService.getLayerData(layerObj, function (ld) {


            oLayerData = ld;

            oServices.floodproofsService.layer(layerObj.server.id,oLayerData.layer.dataid, function (data) {


                oManager.setTheGeoJson( data);

                console.log(oManager.getTheGeoJson())

                oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(oManager.getTheGeoJson(), layerObj['descr'], {

                    pointToLayer: function(feature, latlng) {
                        return L.marker(latlng, {icon:oServices.iconService.section_fews_po_Icon(feature)});
                    }

                }, stationClickListener, stationInfoMouseOver, stationInfoMouseOut));

                // AddBackgroundLayer();

                if (onFinish) onFinish()

            }, function(data) {

                alert('Error loading layer: ' + data.error_message);

            })

        });

    }

    oManager.update = function (newProps, newItem, onFinish) {




    }


    oManager.showProps = function (onFinish) {

        var layerPropModal = oServices.$uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesControllerSeawetra",
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        layer: oManager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {



            oManager.update(obj.props, obj.data, onFinish)
        }, function () {

        });
    },


        oManager.setOpacity = function (value) {


            iOpacity = value;
            oManager.mapLayer().setOpacity(value);

        }

    oManager.getOpacity = function () {
        return iOpacity
    }


    oManager.setVisible = function (b) {

        if(!b) {
            if (oManager.mapLayer()) oManager.setOpacity(0)
            iOpacity = 0;
        }else {
            if (oManager.mapLayer()) oManager.setOpacity(1)
            iOpacity = 1;
        }

        isVisible = b
    }

    oManager.isVisible = function () {
        return isVisible
    }

    oManager.legend = function (callback) {

        //if (oLegend != null) callback(oLegend);
        //controllo se nelle properties cè l'attributo custom legend
        for (var i = 0; i < oManager.props().layerProperties.attributes.length; i++) {
            var attr = oManager.props().layerProperties.attributes[i]
            if (attr.name == 'customLegend') {

                oLegend = {
                    dynPalette: {},
                    type: "DDS_CUSTOM_LEGEND",
                    url: attr.selectedEntry.value,
                    layers: oManager.mapLayer().wmsParams.layers,
                }

                callback(oLegend);
            }
        }

        //chiamo api per sapere se c'è una palette dinamica

        oServices.apiService.get('ddsmap/layerstyle/' + oManager.getLayerId() + '/' + oManager.mapLayer().options.layers, function (data) {
            // apiService.getExt('http://dds.cimafoundation.org/dewetra2/dewapi/ddsmap/layerstyle/'+ layer.server.id+'/'+mapLayer.options.layers , function (data) {
            // mapLayer.options.layers


            if (data.length > 1) {

                var legend = {

                    type: "ADVANCED",
                    legend: [{
                        type: "CUSTOM",
                        title: layerObj.name,
                        palette: []
                    }]

                }

                legend.legend.palette = []
                data.forEach(function (val) {
                    legend.legend[0].palette.push(
                        {
                            label: val.label,
                            color: val.color,
                        }
                    )
                })

                if (callback) callback(legend);

                oLegend = {
                    aPalette: data,
                    dynPalette: {},
                    type: layerObj.type.code.toUpperCase(),
                    url: mapLayer._url,
                    layers: mapLayer.wmsParams.layers,
                }
                if (callback) callback(oLegend);
            }


        }, function (err, head) {
            let aPalette = null;
            oLegend = {
                type: layerObj.type.code.toUpperCase(),
                url: oManager.mapLayer()._url,
                layers: oManager.mapLayer().wmsParams.layers,
            }
            if (callback) {
                callback(oLegend)
            } else return null;


        });



    }

    // oManager.parseInfo =  function (data) {
    //
    //     //layer prop
    //     var oProperties = oManager.props();
    //
    //     //inizializzo array
    //     var aProperties = []
    //
    //     var measureUnit = ""
    //
    //     if (oProperties.layerProperties.attributes.length >= 1) {
    //
    //         oProperties.layerProperties.attributes.forEach(function (prop) {
    //             //if(debug)console.log(prop)
    //             if (prop.selectedEntry.referredValues && prop.selectedEntry.referredValues.entry.length > 0) {
    //                 prop.selectedEntry.referredValues.entry.forEach(function (entry) {
    //                     if (entry.key == "mu") measureUnit = entry.value
    //                 })
    //             }
    //
    //             var oProp = {
    //                 name: prop.descr,
    //                 value: prop.selectedEntry.descr
    //             }
    //             if (prop.descr != "-") aProperties.push(oProp);
    //         })
    //     }
    //
    //     var ret = {
    //         layerName: oManager.descr(),
    //         layerDate: oManager.item() ? moment(oManager.item().date).utc().format('DD/MM/YYYY HH:mm') : " - ",
    //         properties: []
    //     };
    //
    //     if (data.features && data.features.length > 0) {
    //         data.features.forEach(function (f) {
    //             if (!f.geometry && 'GRAY_INDEX' in f.properties) {
    //                 ret.properties.push({
    //                     name: 'value',
    //                     'value': f.properties.GRAY_INDEX.toFixed(2) + " " + measureUnit
    //                 })
    //             } else {
    //                 for (p in f.properties) {
    //                     ret.properties.push({name: p, 'value': f.properties[p] + " " + measureUnit})
    //                 }
    //             }
    //         })
    //     }
    //
    //     ret.properties = ret.properties.concat(aProperties);
    //
    //     ret.properties.forEach(function (item) {
    //         if (item.name == 'link') {
    //             item.html = true;
    //         } else item.html = false;
    //     })
    //
    //     return ret;
    // }


    return oManager

}
