/**
 * Created by doy on 19/06/15.
 */

// layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope

function layerManager_sensor_native(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService) {

    var ICON_SIZE = 14;
    var visible=true;

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;

    var markerFloodOption = {
        radius : menuService.markerFloodOptions.radius,
        weight : menuService.markerFloodOptions.weight,
        color : menuService.markerFloodOptions.color,
        opacity : menuService.markerFloodOptions.opacity,
        fillOpacity: menuService.markerFloodOptions.fillOpacity
    };
    //add External Layer
    var layerToAdd = 49;
    var AddictionalLayer = apiService.get("settings/layers/?id="+layerToAdd,function(obj){

        var AlreadyLoaded = false;
        var dataId =obj.objects[0].dataid;

        var o = mapService.getLayerTest();
        if (o.draggable){
            o.draggable.forEach(function (data) {
                if (data.wmsParams.layers == dataId){
                    AlreadyLoaded = true;
                }
            })
        }

        //
        function buildLayerManager(layer) {
            var mangerName = 'layerManager_' + layer['type'].code;
            var manager = window[mangerName](layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService);

            return manager;
        }
        if (AlreadyLoaded){
            console.log("Gia Caritcato")
        }else{
            var PlusManager = buildLayerManager(obj.objects[0]);
            PlusManager.load(function () {
                mapService.setlayerManager(PlusManager.mapLayer(), PlusManager);
                mapService.oLayerList.addLayer(PlusManager)
            });
        }

    });
    //add External Layer End

    function stationInfoMouseOver(s){
        if(infoPopUP){
            infoPopUP.mouseOver('FloodProofsProbabilistic',mapLayer._leaflet_id, s.target.feature.properties , iconService.section_gauge_observation_Icon(s.target.feature))
        }
    }

    function stationInfoMouseOut(){
        if(infoPopUP){
            infoPopUP.mouseOut('FloodProofsProbabilistic',mapLayer._leaflet_id)
        }
    }




    function stationClickListener(s) {

        if(s.target.feature.properties.maxvalue <=-9998){
            alert($translate.instant('UNAVAILABLE_DATA'));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/hydrogram_chart_form.html',
            controller: 'hydrogramChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sectionData: function () {

                    return {

                        section : s.target.feature.properties,
                        prop : layerData.prop,
                        serverId: layerObj.server.id

                    };

                }

            }
        })

    }

    function updateFeatureStyle () {

        for(var layerId in mapLayer._layers){
           mapLayer._layers[layerId].setIcon(iconService.section_gauge_observation_Icon(mapLayer._layers[layerId].feature, markerFloodOption.opacity))
        }

    }




    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        load: function(onFinish) {






            serieService.getLayerData(layer, function (ld) {

                layerData = ld;

                floodproofsService.layer(layer.server.id,layerData.layer.dataid, function (data) {

                    theGeoJson = data;

                    mapLayer = mapService.addGeoJsonLayer(theGeoJson, layer['descr'], {

                        pointToLayer: function(feature, latlng) {
                            return L.marker(latlng, {icon:iconService.section_gauge_observation_Icon(feature)});
                        }

                    }, stationClickListener, stationInfoMouseOver, stationInfoMouseOut);

                    if (onFinish) onFinish()

                }, function(data) {

                    alert('Error loading layer: ' + data.error_message);

                })

            });

        },

        layerTooltip: function(){

            var manager = this;



            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : manager.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : manager.typeDescr()
                }

            ];
            return tooltipObj;
        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        setOpacity : function(value){

            if (value){
                markerFloodOption.opacity = value;
                markerFloodOption.fillOpacity = value;
                updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return markerFloodOption.opacity
        },


        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.descr
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        typeDescr: function () {
            return "sensor_native"
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi
        },

        getWarningInfo: function () {
            return infoPopUP;
        },

        setVisible: function (b) {
            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        }

    }

}
