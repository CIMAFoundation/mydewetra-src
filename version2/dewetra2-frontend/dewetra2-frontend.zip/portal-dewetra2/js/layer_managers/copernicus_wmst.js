"use strict";

/**
 * Created by Mirko on 26/02/18.
 */
var layerManager_copernicus_wmst;

(function () {
    var proxy_url = 'https://dds.cimafoundation.org/dewetra2/dewapi/utils/proxy/';

    function encodeData(data) {
        return Object.keys(data).map(function (key) {
            return [key, data[key]].map(encodeURIComponent).join("=");
        }).join("&");
    }

    var _WMSTServiceCopernicus = function _WMSTServiceCopernicus($http, $q) {
        var service = this;
        var $http, $q, $window;
        if ($http === undefined) {
            $http = angular.injector(["ng"]).get("$http");
        }
        if ($q === undefined) {
            $q = angular.injector(["ng"]).get("$q");
        }
        if ($window === undefined) {
            $window = angular.injector(["ng"]).get("$window");
        }

        function proxy(url) {
            return $http.post(proxy_url, {
                method: "get",
                json_response: "false",
                url: url
            }).then(function (res) {
                var data = res.data;
                if (data.status !== 200) {
                    throw new Error(data.content);
                }
                return data.content;
            });
        }

        this.getLayerDimensions = function (server, layer, token) {
            //check if wms is in url

            var params = encodeData({
                service: 'WMS',
                version: '1.3.0',
                request: 'GetCapabilities',
                token: token
            });
            var url = server + '?' + params;

            var p = $q.defer();
            return proxy(url).then(function (xmlString) {
                var x2js = new X2JS();
                var result = x2js.xml_str2json(xmlString);
                var layers = result.WMS_Capabilities.Capability.Layer.Layer;

                layers = layers.filter(function (l) {
                    return l.Name == layer;
                });
                if (layers.length == 0) {
                    throw new Error('Something went wrong while getting the timeline from ' + url);
                }
                var dims = layers[0].Dimension;
                return dims;
            });
        };

        return service;
    };

    layerManager_copernicus_wmst = function layerManager_copernicus_wmst(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout) {
        var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout);
        var $q = angular.injector(["ng"]).get("$q");

        var timeline_items = null;
        var visible = false;
        var layer = null;

        var wms_layer_token = layerObj.dataid.split('/');
        var wms_service = wms_layer_token[0];

        var WMSTService = new _WMSTServiceCopernicus();

        var WMSParams = {
            service: 'WMS',
            request: 'GetMap',
            version: '1.3.0',
            layers: manager.layerId,
            styles: '',
            crs: L.CRS.EPSG4326,
            format: 'image/png',
            transparent: true,
            token: manager.token
        };

        function loadLayerAvailability() {
            if (timeline_items !== null) {
                var p = $q.defer();
                $timeout(function () {
                    p.resolve(timeline_items);
                });
                return p.promise;
            } else {
                return WMSTService.getLayerDimensions(manager.server_url, manager.layerId, manager.token).then(function (dims) {
                    var props = {
                        "layerProperties": {
                            "attributes": dims.filter(function (d) {
                                return d._name !== 'time';
                            }).map(function (d) {
                                return {
                                    "name": d._name,
                                    "descr": d._name.split('_').map(function (s) {
                                        return s.toUpperCase();
                                    }).join(' '),
                                    "type": "List",
                                    "visible": "true",
                                    "entries": d.__text.split(',').map(function (e) {
                                        return {
                                            "descr": e + " " + d._unitSymbol,
                                            "referredValues": {},
                                            "value": e
                                        };
                                    }),
                                    "selectedEntry": {
                                        "descr": d._default + " " + d._unitSymbol,
                                        "referredValues": {},
                                        "value": d._default
                                    }
                                };
                            })
                        }
                    };
                    _.extend(manager.layerProps, props);
                    console.log(manager.layerProps);
                    return dims;
                }).then(function (dims) {
                    var timeline_dims = dims.filter(function (d) {
                        return d._name == 'time';
                    });
                    var timeline = timeline_dims.length > 0 ? timeline_dims[0].__text.split(',') : [date()];

                    /*
                    timeline_items = timeline.map(t => ({
                        date: moment(t).toDate(),
                        description: moment(t).utc().toDate().toUTCString(),
                        date_string: t,
                        id: t
                    }));
                    */

                    if (timeline) {
                        timeline_items = timeline.map(function (t) {
                            var date = moment(t).toDate();
                            var utc_date = moment(t).utc();

                            var item = {
                                date: utc_date,
                                description: date.toUTCString(),
                                date_string: t,
                                id: '' + utc_date.valueOf()
                            };
                            return item;
                        });
                    } else {
                        var date = moment().toDate();
                        var utc_date = moment(date).utc();
                        timeline_items = [{
                            date: utc_date,
                            description: date.toUTCString(),
                            date_string: null,
                            id: '' + utc_date.valueOf()
                        }];
                    }

                    return timeline_items;
                });
            }
        }

        function update(newProps, newItem, onFinish, bScrambling) {
            manager.setProps(newProps);
            manager.setItem(newItem);
            if (manager.mapLayer()) {
                manager.setlayerOpacity(manager.mapLayer().options.opacity);
                mapService.removeLayer(manager.mapLayer());
            }

            if (manager.layerOpacity()) {
                manager.mapLayer().setOpacity(manager.layerOpacity());
            }

            if (onFinish) onFinish();
            manager.setCurrentLayer();
        }

        manager.isLoading = false;
        manager.server_url = layerObj.server.url + wms_service;
        manager.layerId = wms_layer_token[1];
        manager.token = wms_layer_token[2];
        manager.wmsParams = WMSParams;

        manager.layerObj = function () {
            if (manager.isLoading) {
                var loading_layer = angular.copy(layerObj);
                loading_layer.icon = (layerObj ? layerObj.icon : '') + '   faa-flash faa-slow animated';
                return loading_layer;
            } else {
                return layerObj;
            }
        };

        manager.mapLayer = function () {
            return layer ? layer : { options: { opacity: 0 } };
        };

        manager.hardcodedProperties = function () {
            return true;
        };

        manager.legend = function () {
            var legend_url = layerObj.server.url;

            return {
                //type: 'DYNAMIC_FORCERULE',
                type: 'DYNAMIC',
                layers: layerObj.dataid,
                url: legend_url
            };
        };

        manager.initializeMoveOptions = function () {
            loadLayerAvailability().then(function (timeline_items) {
                manager.setCanMovie(timeline_items.length > 1);
                if (manager.canMovie()) {
                    //cerco l'index del layer caricato precedentemente
                    var iIndexLoadedLayer = _.findIndex(timeline_items, function (item) {
                        return item.id == manager.item().id;
                    });
                    //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                    iIndexLoadedLayer = iIndexLoadedLayer > -1 ? iIndexLoadedLayer : 1;

                    //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                    manager.infoAvaialability(iIndexLoadedLayer + 1, timeline_items.length);
                    manager.infoAvaialability().reverse = timeline_items[0].date > timeline_items[1].date;
                }
            });
        };

        manager.layerProps = {
            "layerProperties": {
                "attributes": []
            },
            "data": manager.layerId,
            "description": layerObj.descr,
            "id": manager.layerId,
            "longDescription": layerObj.descr
        };

        manager.load = function (onFinish) {
            manager.isLoading = true;

            loadLayerAvailability().then(function (timeline_items) {
                manager.setProps(manager.layerProps);
                var item = timeline_items[timeline_items.length - 1];
                manager.setItem(item);

                manager.initializeMoveOptions();
                manager.setCurrentLayer();
                visible = true;
            }).catch(function (err) {
                console.error(err);
            }).finally(function () {
                manager.isLoading = false;
            });

            onFinish && onFinish();
        };

        manager.setVisible = function (b) {
            visible = b;
            if (!b) mapLayer.clearLayers();else mapLayer.addData(theGeoJson);
        };

        manager.isVisible = function () {
            return visible;
        };

        manager.onDateChange = function (onFinish) {
            if (manager.infoAvaialability) manager.infoAvaialability(timeline_items.length, timeline_items.length);
            update(manager.props(), timeline_items[timeline_items.length - 1], onFinish);
        };

        manager.goForward = function () {
            var iIndexLoadedLayer = _.findIndex(timeline_items, function (availableItem) {
                return availableItem.id == manager.item().id;
            });

            iIndexLoadedLayer = iIndexLoadedLayer > -1 ? iIndexLoadedLayer + 1 : 1;

            if (manager.infoAvaialability) manager.infoAvaialability(iIndexLoadedLayer + 1, timeline_items.length);

            update(manager.props(), timeline_items[iIndexLoadedLayer], function () {
                mapService.oLayerList.updateLayer(manager);
            });
        };

        manager.goBackward = function () {
            var iIndexLoadedLayer = _.findIndex(timeline_items, function (availableItem) {
                return availableItem.id == manager.item().id;
            });

            iIndexLoadedLayer = iIndexLoadedLayer > -1 ? iIndexLoadedLayer : 1;
            if (manager.infoAvaialability) manager.infoAvaialability(iIndexLoadedLayer - 1, timeline_items.length);
            update(manager.props(), timeline_items[iIndexLoadedLayer - 1], function () {
                mapService.oLayerList.updateLayer(manager);
            });
        };

        manager.showProps = function (onFinish) {
            console.log('props');
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties.html',
                controller: "layerPropertiesController",
                size: "lg",
                resolve: {
                    params: function params() {
                        return {
                            layer: manager.mapLayer()
                        };
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj.props, obj.data, onFinish);
            }, function () {
                console.log("CANCEL");
            });
        };

        manager.setCurrentLayer = function () {
            var item = manager.item();
            if (item.date_string) {
                WMSParams['time'] = item.date_string;
            }

            var props = manager.props();
            props.layerProperties.attributes.map(function (a) {
                WMSParams[a.name] = a.selectedEntry.value;
            });

            console.log(WMSParams);
            layer ? manager.remove(layer) : null;
            layer = mapService.addSingleTileWmsLayer(manager.server_url, WMSParams);
            manager.setMapLayer(layer);
        };

        manager.getLayerAvailability = function () {
            return timeline_items;
        };

        manager.setVisible = function (b) {
            visible = b;
            if (!visible && layer) {
                layer.setOpacity(0);
            } else {
                layer.setOpacity(1);
            }
        };

        manager.isDraggable = function () {
            return true;
        };

        manager.isVisible = function () {
            return visible;
        };

        return manager;
    };
})();
