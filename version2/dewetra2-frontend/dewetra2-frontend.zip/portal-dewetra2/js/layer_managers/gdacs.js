/**
 * Created by Dario Rubado on 12/09/16.
 */

function layerManager_gdacs_rss(layerObj) {

    var isVisible = true;

    var iOpacity = 1;

    var manager = layerManager_default(layerObj);



    var oServices = manager.oServices();

    var isLoaded = false;

    manager.draggable = function () {
        return false;
    }

    manager.setVisible = function (b, callBack) {

        isVisible = b;
        if (!b) manager.mapLayer().clearLayers();
        else this.update(null, null, function () {
            if (callBack) callBack()
        });

    };

    manager.isVisible = function () {
        return isVisible;
    }

    function infoMouseOver(s) {
        if (manager.getWarningInfo() && angular.isDefined(s)) {
            manager.getWarningInfo().mouseOver('GDACS', manager.mapLayer()._leaflet_id, s)
        }
    }

    function infoMouseOut() {
        if (manager.getWarningInfo()) {
            manager.getWarningInfo().mouseOut('GDACS', manager.mapLayer()._leaflet_id)
        }
    }

    var layerProps = {
        "layerProperties": {
            "attributes": [
                {
                    "id": "variable",
                    "descr": "Variable",
                    "name": "variable",
                    "entries": [
                        {
                            "descr": "RSS 7 days",
                            "value": "https://www.gdacs.org/xml/rss_7d.xml",
                            "referredValues": {
                                "entry": []
                            }
                        },
                        {
                            "descr": "RSS 24 hours",
                            "value": "https://www.gdacs.org/xml/rss_24h.xml",
                            "referredValues": {
                                "entry": []
                            }

                        }
                    ],
                    "selectedEntry": {
                        "descr": "RSS 24 hours",
                        "value": "https://www.gdacs.org/xml/rss_24h.xml",
                        "referredValues": {
                            "entry": []
                        }
                    },
                    "type": "List",
                    "visible": "true"
                }

            ],
            "data": manager.layerId,
            "description": layerObj.descr,
            "id": manager.layerId,
            "longDescription": ''
        }
    }


    var iconsURL = {
        "GreenEQ": "https://www.gdacs.org/images/gdacs_icons/alerts/Green/EQ.png",
        "OrangeEQ": "https://www.gdacs.org/images/gdacs_icons/alerts/Orange/EQ.png",
        "RedEQ": "https://www.gdacs.org/images/gdacs_icons/alerts/Red/EQ.png",
        "GreenFL": "https://www.gdacs.org/images/gdacs_icons/alerts/Green/FL.png",
        "OrangeFL": "https://www.gdacs.org/images/gdacs_icons/alerts/Orange/FL.png",
        "RedFL": "https://www.gdacs.org/images/gdacs_icons/Red/alerts/FL.png",
        "GreenTC": "https://www.gdacs.org/images/gdacs_icons/alerts/Green/TS.png",
        "OrangeTC": "https://www.gdacs.org/images/gdacs_icons/alerts/Orange/TS.png",
        "RedTC": "https://www.gdacs.org/images/gdacs_icons/alerts/Red/TS.png",
        "GreenDR": "https://www.gdacs.org/images/gdacs_icons/alerts/Green/DR.png",
        "OrangeDR": "https://www.gdacs.org/images/gdacs_icons/alerts/Orange/DR.png",
        "RedDR": "https://www.gdacs.org/images/gdacs_icons/alerts/Red/DR.png"
    }

    function handleRSS(url, theMap, onFinish) {

        oServices.apiService.proxyGeneric(url, function (rssdata) {

            var rssObj = xml2js(rssdata, {compact: false, spaces: 4})

            // console.log(rssObj)

            if (rssObj.elements.length > 1) {
                var items = rssObj.elements[0].elements[0].elements.filter((x) => {
                    return x.name == "item"
                });
            }

            var points = [];
            var markers = [];

            items.forEach(function (item) {


                var point = {
                    title: item.elements.filter(x => x.name == "title")[0].elements[0].text,
                    link: item.elements.filter(x => x.name == "link")[0].elements[0].text,
                    description: item.elements.filter(x => x.name == "description")[0].elements[0].text,
                    pubDate: item.elements.filter(x => x.name == "pubDate")[0].elements[0].text,
                    lat: item.elements.filter(x => x.name == "geo:Point")[0].elements[0].elements[0].text,
                    lon: item.elements.filter(x => x.name == "geo:Point")[0].elements[1].elements[0].text,
                    gdacs: {
                        resources: item.elements.filter(x => x.name == "gdacs:resources")[0].elements[0].elements,
                        gdacs: item.elements.filter((x) => {
                            return ((x.name) && (x.name.startsWith("gdacs:") && (!x.name.endsWith(":resource"))))
                        }),
                    }
                }

                points.push(point)


                // console.log(point.gdacs.gdacs.filter(x=>x.name=="gdacs:alertlevel")[0].elements[0].text)
                var icon = L.icon({
                    iconUrl: iconsURL[point.gdacs.gdacs.filter(x => x.name == "gdacs:alertlevel")[0].elements[0].text + point.gdacs.gdacs.filter(x => x.name == "gdacs:eventtype")[0].elements[0].text],
                    iconSize: [32, 32], // size of the icon
                    iconAnchor: [16, 16], // point of the icon which will correspond to marker's location
                });


                var marker = L.marker([point.lat, point.lon], {icon: icon});

                marker.on('mouseover', function (e) {
                    infoMouseOver(point);
                });
                marker.on('mouseout', function (e) {
                    infoMouseOut();
                });
                marker.on('click', function (e) {
                    window.open(point.link);
                })


                markers.push(marker)

            })

            var theLayer = L.layerGroup(markers)

            oServices.mapService.addGenericLayer(theLayer, "GDACS RSS")

            manager.setMapLayer(theLayer)


            if (onFinish) onFinish()
        })


    }

    manager.load = function (onFinish) {

        manager.setLayerId("GDACS_RSS");

        manager.setProps(layerProps);

        var to = new Date();

        manager.setItem({
            "date": to,
            "description": to.toUTCString(),
            "id": to.getTime() + ";" + to.getTime()
        });


        if (manager.mapLayer()) oServices.mapService.removeLayer(manager.mapLayer())

        handleRSS(layerProps.layerProperties.attributes[0].selectedEntry.value, oServices.mapService.getMap(), onFinish)

    }

    manager.update = function (obj) {
        if (manager.mapLayer()) oServices.mapService.removeLayer(manager.mapLayer())

        layerProps.layerProperties.attributes[0].selectedEntry =(obj)?obj:layerProps.layerProperties.attributes[0].selectedEntry;

        manager.setProps(layerProps)

        handleRSS(layerProps.layerProperties.attributes[0].selectedEntry.value, oServices.mapService.getMap(), function () {
            console.log("loaded")
        })
    }

    manager.thirdLine = function(){
        return true
    }

    manager.getVariable = function(){
        return layerProps.layerProperties.attributes[0].selectedEntry.descr
    }

    manager.getAggregation = function(){
        return ""
    }


    manager.showProps = function (onFinish) {
        var layerPropModal = oServices.$uibModal.open({
            // templateUrl: 'apps/dewetra2/views/layer_properties.html',
            template: `<div class="popup">
                        
                            <div class="head" >
                                <div class="flex-container">
                                    <!--Title-->
                                    <div class="brand flex-item">
                                        <i class=""fa app-static animated bounceIn delay-002" ></i>
                                        <p class="animated fadeInDown delay-001" >
                                            <span translate>{{layer.name}}</span> <span translate>properties</span>
                                        </p>
                                    </div>
                                    <div class="flex-item">
                                        <a class="close" ng-click="closePopup()" href>
                                            <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="modal-body">
                                <hr>
                                <div class="row">
                                    <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                                        <select ng-options="data.descr for data in availables" class="form-control"  ng-model="data.data"  >
                                        
                                            
                                           
                                        </select>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="flex-item animated zoomInUp delay-003 ">
                                        <a href="" class="btn btn-warning pull-right" ng-click="update()"  ng-show="data.data">
                                            <i class="fa fa-refresh "></i>
                                            {{ 'LAYER_REFRESH' | translate }}
                                            
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>`,
            controller: function ($scope, $uibModalInstance, params,) {


                //manager.props().layerProperties.attributes[0].entries.filter(x=>x.descr == manager.props().layerProperties.attributes[0].selectedEntry.descr)
                $scope.data = {
                    data:{},
                    props:manager.props()
                }

                console.log($scope.data.props.layerProperties.attributes[0].selectedEntry.descr )


                $scope.availables = $scope.data.props.layerProperties.attributes[0].entries;


                $scope.update = function () {
                    $uibModalInstance.close($scope.data);
                };
                $scope.closePopup = function () {
                    $uibModalInstance.dismiss()
                };


            },
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        manager: manager
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {

            manager.update(obj.data)
        }, function () {
            console.log("CANCEL")
        });
    }


    return manager;
}



