function layerManager_status_radar(layerObj) {

    // const oManager = layerManager_dynamic_v3(layerObj);
    const oManager = layerManager_default(layerObj);

    const oServices = oManager.oServices();

    var iOpacity= 1;

    var visible = true;

    const debug = oServices.menuService.debug;

    oManager.canMovie = () => {
        return false;
    }

    const overing = (s) => {

        const prop = Object.fromEntries(Object.entries(s.target.feature.properties).map(a => {
                if (a[0] =='active') {
                    a[0] = 'Stato'
                    a[1] = (a[1] == true)?'Attivo':'Disattivo'
                };
                    return [oServices.$translate.instant(a[0].trim()), a[1]]
            }
        ))

        oManager.getWarningInfo().mouseOver('GENERIC',oManager.mapLayer()._leaflet_id, prop)
    }

    const leaving = (s) => {

        // s.target.closePopup();
        oManager.getWarningInfo().mouseOut('GENERIC')
    }

    const load = (callback) => {
        var from = oServices.menuService.getDateFromUTCSecond();
        var to = oServices.menuService.getDateToUTCSecond();

        oServices.layerService.publishLayer(layerObj,from,to,(data) => {
            oManager.setLayerId(data.layerid);
            oManager.setProps(data.properties);
            oManager.setItem(data.item);
            oManager.setServerUrl(data.serverurl)

            oManager.setDownloadUrl (((data.layertype && (data.layertype.toUpperCase() == 'VECTOR'))?
                data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                data.serverurl + '/ddsData/' + data.layerid + '.tiff'));

            setLayer(callback)


        });
    }

    oManager.load = (onFinish) => {
        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        load(onFinish);

    }

    const setLayer = ( onFinish) => {

        if (oManager.mapLayer()) iOpacity = oManager.mapLayer().options.opacity;

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        let urlToWfsLayer = oManager.getServerUrl() + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=" + oManager.getLayerId();

        oServices.apiService.getExt(urlToWfsLayer, (data) => {
            if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());


            oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(data.features, layerObj.descr, {



                pointToLayer: oServices.iconService[layerObj['type'].code + '_Icon'],
                //     function(feature, latlng){
                //     let color = (feature.properties.active)?'green':'orange';
                //     return L.circleMarker(latlng,
                //         {
                //             radius: 8,
                //             fillColor: color,
                //             color: "#000",
                //             weight: 1,
                //             opacity: 1,
                //             fillOpacity: 0.8
                //         });
                //
                // }

            }, null, overing, leaving, null,null));

            if (onFinish) onFinish()
        });
    }

    oManager.update = (newProps, newItem, onFinish) => {
        if(newProps) oManager.setProps(newProps);
        if(newItem)oManager.setItem(newItem);

        var from = oServices.menuService.getDateFromUTCSecond();
        var to = oServices.menuService.getDateToUTCSecond();

        oServices.layerService.republishLayer(layerObj, oManager.props(), from, to, oManager.item(),
            function (data, status) {

                oManager.setDownloadUrl(((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                    layerObj.server.url + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                    layerObj.server.url + '/ddsData/' + data.layerid + '.tiff'));
                oManager.setLayerId(data.layerid);
                setLayer( onFinish);
            },

            function (data) {
                alert(oServices.$translate.instant(data));
            })
        if(debug) console.log('update');


    }

    oManager.showProps= function (onFinish) {

        var layerPropModal = oServices.$uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        layer: oManager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {

            oManager.update(obj.props, obj.data, onFinish)
        }, function () {
            if (debug) console.log("CANCEL")
        });
    };

    oManager.onDateChange = () => {
        oManager.load(onFinish)
    }

    oManager.setVisible = function (b,callBack) {
        visible = b;

        if (!b) oManager.mapLayer().clearLayers();

        if (b) this.update(null,null, callBack)
    }

    oManager.isVisible = function () {
        return visible
    }

    oManager.setOpacity = function(value){



        if (value){
            iOpacity = value
            debugger
            oManager.mapLayer().eachLayer((layer) => {
                debugger
                layer.setStyle({
                    radius: 8,
                    color: "#000",
                    weight: 1,
                    opacity: 1,
                    fillOpacity: iOpacity
                })
            })
        }
    }

    oManager.getOpacity = function(){
        return iOpacity
    }

    oManager.legend = function (callback) {
        var legend = {

            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: "STATUS_RADAR_PALETTE",
                palette:[{
                    label:"STATUS_RADAR_0",
                    color:"green",
                    // sign:"",
                    // value:"",
                    // mu:"",
                    // dec:0
                },{
                    label:"STATUS_RADAR_1",
                    color:"grey",
                    // sign:"<",
                    // value:500000,
                    // mu:"€",
                    // dec:0
                }]
            }]

        };

        return legend
    }

    oManager.dateLine = function (){
        try {
            return oManager.dateRefFormatted()
        }catch (e){
            if (debug)   //console.log(e);
                return "date";
        }
    }
    oManager.dateRun = function (){
        if (oManager.item().id == null) return "";
        var aSplittedDate = oManager.item().id.split(';');
        var dateRun = moment.utc(parseInt(aSplittedDate[0]));
        return dateRun;
    }
    oManager.dateRef = function (){
        if (oManager.item().id == null) return "";
        var aSplittedDate = oManager.item().id.split(';');
        var dateRef = moment.utc(parseInt(aSplittedDate[1]));
        return dateRef;
    }

    oManager.dateForecast = function () {
        if (oManager.item().id == null) return "";
        var aSplittedDate = oManager.item().id.split(';');
        var diff = ((parseInt(aSplittedDate[1])) - (parseInt(aSplittedDate[0])));
        if (diff > 0) {
            diff = diff / (1000 * 60 * 60);
            return "+" + parseInt(diff);
        } else if (diff < 0) {
            return "-" + Math.abs(parseInt(diff)) / (1000 * 60 * 60);
        } else return 0;
    },

        oManager.dateRefFormatted = function () {
            var sDateRunDateRef = oManager.item().id;



            if (oManager.props().layerProperties.id == "WFSNOWROADS") return item.id.replace(/;/g, ' ');

            if (sDateRunDateRef  == null) return "";

            if (sDateRunDateRef.indexOf(";") > -1) {
                //controllo se osservazione o previsione
                var bLayerType = layerObj.category == "observation";
                //se osservazione la data di run corrisponde alla dateref e ne visualizzo solo una
                if (bLayerType) {
                    var aDateRunDateRef = sDateRunDateRef.split(";");
                    var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                    //var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                    return sDateRun
                } else {
                    //se previsione distinguo le due date
                    var aDateRunDateRef = sDateRunDateRef.split(";");
                    var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                    var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                    return sDateRef + " " + " (Run:" + sDateRun + ")";
                }
                //se ha solo una data non mi pongo il problema
            } else {


                // Anto 20160908: Se item.id non è una data provo con item.date
                var tsRun = parseInt(sDateRunDateRef);
                if (!isNaN(tsRun)) {
                    return moment(new Date(tsRun)).utc().format('DD/MM/YYYY HH:mm');
                }
                else {
                    return moment(Date.parse(oManager.item().date)).utc().format('DD/MM/YYYY HH:mm');
                }

            }

        };





    oManager.thirdLine = function () {
        return true
    }

    oManager.getVariable= function () {


        var str = "";
        if (Array.isArray(oManager.props().layerProperties.attributes)) {
            oManager.props().layerProperties.attributes.forEach(function (prop) {
                if (prop.name == "operation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (prop.name == "variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (prop.name == "__variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            })
            return str;
        } else {
            if (oManager.props().layerProperties.attributes.name == "operation") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            if (oManager.props().layerProperties.attributes.name == "variable") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            if (oManager.props().layerProperties.attributes.name == "__variable") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
        }

    };

    oManager.getAggregation= function () {
        var str = "";

        if (Array.isArray(oManager.props().layerProperties.attributes)) {
            oManager.props().layerProperties.attributes.forEach(function (prop) {
                if (prop.name == "aggregation") str = prop.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
                if (prop.name == "__aggregation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            })
            return str;
        } else {
            if (oManager.props().layerProperties.attributes.name == "aggregation") str = oManager.props().layerProperties.attributes.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
            if (oManager.props().layerProperties.attributes.name == "__aggregation") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
        }


    };

    oManager.layerTooltip = function (){

        const layerDelay = function (layerManagerObj) {


            try {
                var oReferenceDate = layerManagerObj.dateRef().utc().toDate()
            } catch (err) {
                return layerManagerObj.descr()
            }

            // Get Now
            var oDate = new Date();

            //if(debug)console.log("Now  = " + oDate);
            //if(debug)console.log("Ref  = " + oReferenceDate);

            // Compute time difference
            var iDifference = oDate.getTime() - oReferenceDate.getTime();

            // How it is in minutes?
            var iMinutes = 1000 * 60;

            var iDeltaMinutes = Math.round(iDifference / iMinutes);

            var sTimeDelta = "";

            if (iDeltaMinutes > 0) {
                if (iDeltaMinutes < 60) {
                    // Less then 1h
                    sTimeDelta += oServices.$translate.instant("pre_min_fa") + " " + iDeltaMinutes + ' ' + oServices.$translate.instant("min_fa");
                } else if (iDeltaMinutes < 60 * 24) {
                    // Less then 1d
                    var iDeltaHours = Math.round(iDeltaMinutes / 60);
                    sTimeDelta += oServices.$translate.instant("pre_ore_fa") + " " + iDeltaHours + ' ' + oServices.$translate.instant("ore_fa");
                } else {
                    // More than 1d
                    var iDeltaDays = Math.round(iDeltaMinutes / (60 * 24));
                    sTimeDelta += oServices.$translate.instant("pre_giorni_fa") + " " + iDeltaDays + ' ' + oServices.$translate.instant("giorni_fa");
                }
            } else {
                if (iDeltaMinutes > -60) {
                    // Less then 1h
                    sTimeDelta += oServices.$translate.instant("Fra") + ': ' + Math.abs(iDeltaMinutes) + ' ' + oServices.$translate.instant("Minuti");
                } else if (iDeltaMinutes > -60 * 24) {
                    // Less then 1d
                    var iDeltaHours = Math.round(iDeltaMinutes / 60);
                    sTimeDelta += oServices.$translate.instant("Fra") + ': ' + Math.abs(iDeltaHours) + ' ' + oServices.$translate.instant("Ore");
                } else {
                    // More than 1d
                    var iDeltaDays = Math.round(iDeltaMinutes / (60 * 24));
                    sTimeDelta += oServices.$translate.instant("Fra") + ': ' + Math.abs(iDeltaDays) + ' ' + oServices.$translate.instant("Giorni");
                }
            }


            return sTimeDelta;
        };

         return [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                 {
                     label: "VARIABLE",
                     value: oManager.getVariable()
                 },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") : ""
                },
                 {
                     label: "DATE_DELAY",
                     value: layerDelay(oManager)
                 }
            ];
    }

    return oManager;

}
