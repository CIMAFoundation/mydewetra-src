/**
 * Created by Dario Rubado on 12/09/16.
 */

function layerManager_coau(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope) {

    var manager = layerManager_dynamic_realtime(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope)

    var wi;

    var debug = menuService.debug;

    manager.draggable = function () {
        return false;
    }
    var p = {}
    p.options = {};

    manager.setMapLayer(p);

    function infoMouseOver (s) {

        // console.log(s)

        if(manager.getWarningInfo() && angular.isDefined(s)){

            console.table(s.target.feature)

            s.target.feature.title = layerObj.name;

            wi.mouseOver('COAU',manager.mapLayer()._leaflet_id, s.target.feature  )
        }
    }

    function infoMouseOverCluster (s) {
        if(manager.getWarningInfo() && angular.isDefined(s)){
            var arr = recursiveCheck(s.layer)
            //wi.mouseOver('SFLOC',manager.mapLayer()._leaflet_id, s.target.feature  )
            console.log(arr)
        }
    }
    function infoMouseOut () {
        if(wi){
            wi.mouseOut('COAU',manager.mapLayer()._leaflet_id)
        }
    }


    function recursiveCheck(cluster) {

        var arr = [];
        // if(array) arr.concat(array);

        if (cluster && cluster._markers){
            if(cluster._markers.length > 0){
                cluster._markers.forEach(function (marker) {
                    arr.push(marker.feature);
                })
            }
            if(cluster.hasOwnProperty("_childClusters") && cluster._childClusters.length > 0){
                cluster._childClusters.forEach(function (child) {
                    var p = recursiveCheck(child);
                    if (p.length > 0){
                        arr = arr.concat(p)
                    }
                })
            }
        }
        // console.log(arr);
        return arr
    }




    manager.setWarningInfo=function(WaInfo){
        wi = WaInfo;
    }

    manager.getWarningInfo=function(){
        return wi
    }

    manager.load =function (onFinish) {

        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        manager.setLayerObj(layerObj);

        layerService.publishLayer(layerObj,from,to,function(data){
            // &env=minimum:12;maximum:20&

            manager.setLayerId(data.layerid);
            manager.setProps(data.properties);
            //check
            // setDynamicPalette(props);
            manager.setItem(data.item);

            //mapLayer = mapService.addWmsLayer(data.serverurl+'/wms', data.layerid);

            manager.setDownloadUrl (((data.layertype && (data.layertype.toUpperCase() == 'VECTOR'))?
                data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                data.serverurl + '/ddsData/' + data.layerid + '.tiff'));
            manager.setServerUrl(data.serverurl)

            var urlToWfsLayer = data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=" + data.layerid;

            if(manager.hasOwnProperty('getDownloadUrl'))    delete manager.getDownloadUrl;

            console.log(urlToWfsLayer)

            apiService.getExt(urlToWfsLayer,function (data) {




                if(manager.mapLayer()) mapService.removeLayer(manager.mapLayer())

                // L.marker(latlng, {icon:iconService.section_gauge_observation_Icon(feature)});

                manager.setMapLayer(mapService.addGeoJsonLayerCluster(data.features, layerObj.descr, {



                    pointToLayer: function(feature, latlng){

                        let sIconName = layerObj.type.code+'_Icon';

                        return iconService[sIconName](feature, latlng)
                    }

                }, null, infoMouseOver, infoMouseOut, null,infoMouseOverCluster));



                if (onFinish) onFinish()

            },function () {
                alert("ERROR Loading Impact Layer data settings")
            })



            //inizializzo le opzioni per la movie
            //initializeMoveOptions();

            if (onFinish) onFinish()

            // if (!visible) _.this.setVisible(false);

        }, function (data) {

            alert($translate.instant(data));

        })

    }

    var serverUrl = ""

    manager.setServerUrl = function (url) {
        serverUrl = url;
    }

    manager.getServerUrl = function () {
        return serverUrl;
    }

    manager.update = function (newProps, newItem, onFinish, bScrambling) {
        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        layerService.republishLayer(manager.layerObj(), newProps, from, to, newItem,
            function (data, status) {


                manager.setLayerId(data.layerid);

                manager.setDownloadUrl (((data.layertype && (data.layertype.toUpperCase() == 'VECTOR'))?
                    data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                    data.serverurl + '/ddsData/' + data.layerid + '.tiff'));
                var urlToWfsLayer = data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=" + data.layerid;
                //manager.setDownloadUrl(urlToWfsLayer);

                if(manager.hasOwnProperty('getDownloadUrl'))    delete manager.getDownloadUrl;

                manager.setNewLayer(newProps, newItem, data.layerid, onFinish);
            },
            function (data, status) {//onerror
                if(debug)console.log("republish error "+random)

            }, function (data) {
                alert($translate.instant(data));
                if(debug)console.log(data);
            })
    }

    manager.setNewLayer = function (newProps, newItem, layerId, onFinish) {


        manager.setProps(newProps);
        manager.setItem(newItem);
        // gestire opacita
        // if (mapLayer) iOpacity = mapLayer.options.opacity
        if (manager.mapLayer()) mapService.removeLayer(manager.mapLayer());

        var urlToWfsLayer = manager.getServerUrl() + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=" + layerId;
        //manager.setDownloadUrl(urlToWfsLayer);

        apiService.getExt(urlToWfsLayer,function (data) {


            if(manager.mapLayer()) mapService.removeLayer(manager.mapLayer())

            // L.marker(latlng, {icon:iconService.section_gauge_observation_Icon(feature)});

            manager.setMapLayer(mapService.addGeoJsonLayerCluster(data.features, layerObj.descr, {
                pointToLayer: function(feature, latlng){

                    let sIconName = layerObj.type.code+'_Icon';

                    return iconService[sIconName](feature, latlng)
                }

            }, null, infoMouseOver, infoMouseOut,null, infoMouseOverCluster));



            if (onFinish) onFinish()

        },function () {
            alert("ERROR Loading Impact Layer data settings")
        })

        if(debug)console.log("  error"  + " " + layerId)
    }

    manager.refresh = function () {

    }


    manager.legend = function () {
        var legend = {
            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: $translate.instant("COAU"),
                image:"apps/dewetra2/img/canadair.svg",
                palette: []
            }]
        };


        var palette = [{
            label:"COAU",
            color:"#fbd216",
            sign:"",
            value:"levels[i]",
            // image:"apps/dewetra2/img/canadair.svg",
            mu:'',
            dec:1

        }];

        legend.legend[0].palette = palette;




        return legend;
    };


    return manager;

}


/**
 * Created by Dario Rubado on 12/09/16.
 */

function layerManager_terna(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope) {

    var manager = layerManager_coau(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope)





    manager.legend = function () {
        var legend = {
            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: $translate.instant("TERNA"),
                image:"apps/dewetra2/fonts/icone-scenario/SVG/terna.svg",
                palette: []
            }]
        };


        var palette = [{
            label:"TERNA",
            color:"#fbd216",
            sign:"",
            value:"levels[i]",
            mu:'',
            dec:1

        }];

        legend.legend[0].palette = palette;




        return legend;
    };


    return manager;

}


function layerManager_frp(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope) {

    var manager = layerManager_coau(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope)





    manager.legend = function () {
        var legend = {
            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: $translate.instant("FRP"),
                image:"apps/dewetra2/img/flame.svg",
                palette: []
            }]
        };


        var palette = [{
            label:"FRP_ITALY",
            color:"rgba(14,13,7,0.95)",
            sign:"",
            value:"levels[i]",
            mu:'',
            dec:1

        }];

        legend.legend[0].palette = palette;




        return legend;
    };


    return manager;

}

