function layerManager_dynamic_external_wmst_ea_hazards_watch(layerObj) {

    var isVisible = true;

    var iOpacity = 1;

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices();

    var isLoaded = false;

    var timer = null;

    var to;

    var modalInstance;

    let XmlCapability;
    let temporalInstants, timeDimensionOfLayerSelectedFromCapabilities, layerSelectedFromCapabilities;


    var WMSParams = {
        service: 'WMS',
        request: 'GetMap',
        version: '1.3.0',
        //version: '1.1.1',
        layers: layerObj.dataid,
        styles: '',
        time:'',
        // srsName:'EPSG:3857',
        // crsName:'EPSG:3857',
        format: 'image/png',
        width: 512,
        height: 512,
       // width=256&height=256
        //tiled: true,
        transparent: true
    };

    setCapability = (data) => {
        XmlCapability = data;
    }

    parsedCapability = () => {
        return new WMSCapabilities().parse(XmlCapability);
    }

    function getCapabilities(callback){

        const url = oManager.layerObj().server.url+'?service=WMS&version=1.3.0&request=GetCapabilities';
        // oManager.layerObj().server.url
        // olayerObj.server.url

        oServices.apiService.getExt( url
            , function (data) {

                //data.Capability.Layer.Layer //aarray of layers



                // data.Capability.Layer.Layer[0] = {
                //     "Name": "weekly_temp_anom", // name to filter
                //     "Title": "Weekly Temperature Anomaly",
                //     "Dimension": [
                //         {
                //             "name": "time",
                //             "units": "ISO8601",
                //             "unitSymbol": null,
                //             "default": "current",
                //             "values": "2021-10-05T00:00:00.000Z,2021-10-13T00:00:00.000Z,2021-10-19T00:00:00.000Z,2021-11-02T00:00:00.000Z"
                //         }
                //     ],
                //     "queryable": true,
                //     "opaque": false,
                //     "noSubsets": false
                // };

                //data.Capability.Layer.Layer[0].Dimension[0].values//  '2021-10-05T00:00:00.000Z,2021-10-13T00:00:00.000Z,2021-10-19T00:00:00.000Z,2021-11-02T00:00:00.000Z'

                setCapability(data);

                layerSelectedFromCapabilities = parsedCapability().Capability.Layer.Layer.filter(layer => {
                    return layer.Name == oManager.layerObj().dataid;
                })[0];

                timeDimensionOfLayerSelectedFromCapabilities = layerSelectedFromCapabilities.Dimension.filter(dimension => {
                    return dimension.name == 'time';
                })[0];

                temporalInstants = timeDimensionOfLayerSelectedFromCapabilities.values.split(',');

                if (callback)callback();

            }, function (data) {
                console.log("eahazardswatch.icpac.net ERROR", data);
            })
    }



    function nearestDateTo() {

        let dateTo = moment.utc(oServices.menuService.getDateTo())

        let minDiff;
        let sDate;

        if(temporalInstants){
            temporalInstants.map((t)=> {
                let diff = moment(t).diff(dateTo)
                if (minDiff){
                    if (minDiff > diff) {
                        minDiff = diff;
                        sDate = t;
                    };
                }else{
                    minDiff = diff;
                    sDate = t;
                }
            })
        }


    }




    function update(onFinish, selectedDate){

        if (oManager.mapLayer()){
            iOpacity = oManager.mapLayer().options.opacity
        }

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        WMSParams.time = selectedDate

        oManager.setMapLayer(oServices.mapService.addSingleTileWmsLayer(layerObj.server.url , WMSParams));

        oManager.mapLayer().setOpacity(iOpacity)


        if (onFinish) onFinish()

    }

    oManager.load = function(onFinish) {

        getCapabilities((data) => {


            if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());


            //original https://eahazardswatch.icpac.net/gsky/ows?service=WMS&request=GetMap&version=1.1.1&width=256&height=256&styles=&transparent=true&srs=EPSG:3857&bbox=3757032.814272985,3757032.814272985,5009377.085697312,5009377.085697312&format=image/png&time=2021-11-16T00:00:00.000Z&layers=weekly_heavy_rainfall
            // https://eahazardswatch.icpac.net/ncwms/wms?SERVICE=WMS&REQUEST=GetMap&VERSION=1.3.0&LAYERS=daily_rainfall_forecast&STYLES=&FORMAT=image%2Fpng&TRANSPARENT=true&TIME=2021-11-15T06%3A00%3A00.000Z&WIDTH=1024&HEIGHT=1024&CRS=EPSG%3A3857&BBOX=344883.87162271526,4038321.078362432,2225846.2636643327,6640849.017416114&WIDTH=769&HEIGHT=1064
            // https://eahazardswatch.icpac.net/gsky/ows?SERVICE=WMS&REQUEST=GetMap&VERSION=1.3.0&width=256&height=256&LAYERS=daily_rainfall_forecast&STYLES=&FORMAT=image%2Fpng&TRANSPARENT=true&TIME=2021-11-15T06%3A00%3A00.000Z&WIDTH=1024&HEIGHT=1024&CRS=EPSG%3A3857&BBOX=344883.87162271526,4038321.078362432,2225846.2636643327,6640849.017416114&WIDTH=769&HEIGHT=1064

            if(temporalInstants.length == 1 || temporalInstants[0] == ""){

               alert("NO TIMELINE PRESENT");
            }


            WMSParams.time = temporalInstants[temporalInstants.length -1];

            oManager.setMapLayer(oServices.mapService.addSingleTileWmsLayer(layerObj.server.url , WMSParams));

            oManager.mapLayer().setOpacity(iOpacity)


            if (onFinish) onFinish()

        });

    };

    oManager.showProps = function(onFinish) {

        var layerPropModal = oServices.$uibModal.open({
            template: `
                    <div class="popup">
                        <div class="head" >
                            <div class="flex-container">
                                <!--Title-->
                                <div class="brand flex-item">
                                    <i class=""fa app-static animated bounceIn delay-002" ></i>
                                    <p class="animated fadeInDown delay-001" translate>
                                        <span translate>{{layer.name}}</span> <span translate>properties</span>
                                    </p>
                                </div>

                                <div class="flex-item">
                                    <a class="close" ng-click="closePopup()" href>
                                        <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <div class="modal-body">

                            <hr>


                            <div class="row" >
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <label class="hidden-xs">
                                        <h4 translate>CHOOSE_INTERVAL</h4>
                                    </label>
                                </div>

                                <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                                    <select class="form-control"  ng-model="config.selectedDate" ng-options="date as formatDate(date) for date in config.dates" ng-change="selectTypeAttr(date)">
                                    </select>
                                </div>
                            </div>
                            <hr>
                    <div class="row">
                                <div class="flex-item animated zoomInUp delay-003 ">
                                    <a href="" class="btn btn-warning pull-right" ng-click="update()" tooltip="reload layer" ng-show="config.selectedDate">
                                        <i class="fa fa-refresh "></i>
                                        {{ 'LAYER_REFRESH' | translate }}
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>`,
            controller: ['$scope', 'layerService', 'mapService', 'menuService', '$uibModalInstance', 'params', '$interval', '$translate', '_',function ($scope, layerService, mapService, menuService, $uibModalInstance, params, $interval, $translate, _) {

                $scope.config= {
                    selectedDate: {},
                    dates: []
                }
                $scope.config.dates = params.temporalInstants;

                if(params.selectedDate){
                    $scope.config.selectedDate = $scope.config.dates[$scope.config.dates.indexOf((params.selectedDate))];
;                }

                let dateFromMoment = moment.utc(oServices.menuService.getDateFrom());



                $scope.formatDate = (date) => {
                    return moment(date).format('DD/MM/YYYY HH:00')
                }


                $scope.selectTypeAttr = function(d){
                    console.log(d);
                }

                $scope.update = function () {
                    $uibModalInstance.close($scope.config.selectedDate);
                };

                $scope.closePopup = function () {
                    $uibModalInstance.dismiss()
                };



            }],
            size: "lg",
            resolve: {
                params: function() {
                    return {
                        layer: layerObj,
                        temporalInstants: temporalInstants,
                        selectedDate : WMSParams.time,
                        to: to
                    }
                }
            }
        });

        layerPropModal.result.then(function (selectedDate) {
            update(onFinish, selectedDate)
        }, function () {
            console.log("CANCEL")
        });
    }

    oManager.draggable = function(){
        return true
    }

    oManager.onDateChange = function(onFinish){
        update(onFinish)

    };

    // oManager.parseInfo = function (layer, data, url) {
    //
    //     if(oManager.layerObj().hasOwnProperty("customprops")){
    //         if (oManager.customprops().hasOwnProperty("queryable")){
    //             if(oManager.customprops().queryable == false) {
    //                 alert(oServices.$translate.instant('NOT_QUERYABLE') + " "  + oManager.name())
    //                 return
    //             };
    //         }
    //     }
    //
    //
    //     //
    //     //if(modalInstance != null) return
    //     modalInstance = oServices.$uibModal.open({
    //         animation: true,
    //         component: 'efasReportingPointInfo',
    //         size:'lg',
    //         resolve:{
    //             oManager:function () {
    //                 return oManager
    //             },
    //             dateRun: function() {
    //                 return  to
    //             }
    //         }
    //     });
    //
    //     modalInstance.result.then(function (obj) {
    //
    //         console.log('modal-component dismissed at: ' + new Date());
    //         modalInstance = null;
    //
    //     }, function () {
    //         console.log('modal-component dismissed at: ' + new Date());
    //         modalInstance = null;
    //     });
    //
    //
    //
    // }

    oManager.thirdLine= function () {
        return true
    }



    oManager.getVariable = function () {

        if(WMSParams.time) return moment(WMSParams.time).format('LLL')


    }

    oManager.getAggregation = function () {
        return "";
    }



    delete oManager.getDownloadUrl;




    oManager.legend = function () {

        var legend = {
            type: "ADVANCED",
            legend: [{
                type: "CUSTOM",
                title: oManager.name(),
                palette: [],
                descr:""
            }]
        };


        if(oManager.layerObj().hasOwnProperty("customprops")){
            if (oManager.customprops().hasOwnProperty("customLegend")){
                legend.legend[0].palette = oManager.customprops().customLegend['default'].palette;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].img = oManager.customprops().customLegend['default'].img;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].descr = oManager.customprops().customLegend['default'].descr;//default o la variabile che definisci mi permette di gestire multi legenda

                return legend
            }
        }
    }

    return oManager
}



