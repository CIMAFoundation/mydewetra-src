/**
 * Created by Dario Rubado on 19/06/15.
 */



function layerManager_section_gauge_observation(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService) {

    var ICON_SIZE = 14;

    var visible=true;

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;

    var dateRun = null;

    var markerFloodOption = {
        radius : iconService.markerFloodOptions.radius,
        weight : iconService.markerFloodOptions.weight,
        color : iconService.markerFloodOptions.color,
        opacity : iconService.markerFloodOptions.opacity,
        fillOpacity: iconService.markerFloodOptions.fillOpacity
    };
    //add External Layer
    var layerToAdd = 49;
    var AddictionalLayer = apiService.get("settings/layers/?id="+layerToAdd,function(obj){

        var AlreadyLoaded = false;
        var dataId =obj.objects[0].dataid;

        var o = mapService.getLayerTest();
        if (o.draggable){
            o.draggable.forEach(function (data) {
                if (data.wmsParams.layers == dataId){
                    AlreadyLoaded = true;
                }
            })
        }

        //
        function buildLayerManager(layer) {
            var mangerName = 'layerManager_' + layer['type'].code;
            var manager = window[mangerName](layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService);

            return manager;
        }
        if (AlreadyLoaded){
            console.log("Gia Caritcato")
        }else{
            var PlusManager = buildLayerManager(obj.objects[0]);
            PlusManager.load(function () {
                mapService.setlayerManager(PlusManager.mapLayer(), PlusManager);
                mapService.oLayerList.addLayer(PlusManager)

            });
        }

    });
    //add External Layer End

    function stationInfoMouseOver(s){
        if(infoPopUP){
            //console.log(s);
            infoPopUP.mouseOver('FloodProofsDeterministic',mapLayer._leaflet_id, s.target.feature.properties  )
        }
    }

    function stationInfoMouseOut(){
        if(infoPopUP){
            infoPopUP.mouseOut('FloodProofsDeterministic',mapLayer._leaflet_id)
        }
    }

    function stationClickListener(s) {

        // if(s.target.feature.properties.maxvalue <=-9998){
        //     alert($translate.instant('UNAVAILABLE_DATA'));
        //     return;
        // }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/hydrogram_chart_form.html',
            controller: 'hydrogramChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sectionData: function () {

                    return {

                        section : s.target.feature.properties,
                        prop : layerData.prop,
                        serverId: layerObj.server.id

                    };

                }

            }
        })


        //TODO cambiare commento

        // var modalInstance = $uibModal.open({
        //     component: 'proofsChartComponent',
        //     //component: 'share',
        //     size: 'lg',
        //     keyboard: false,
        //     resolve: {
        //         sectionData: function () {
        //             return {
        //                 section : s.target.feature.properties,
        //                 prop : layerData.prop,
        //                 serverId: layerObj.server.id,
        //                 serieId : layerData.prop.id,
        //                 layerObj: layerObj
        //             };
        //         }
        //     }
        // });


    }


    function updateFeatureStyle () {


        sectionIconUndefined = iconService.getTriangleIcon(ICON_SIZE, "grey", "black", markerFloodOption.opacity);

        sectionIconNoThresholdLow = iconService.getTriangleIcon(ICON_SIZE, "white", "black", markerFloodOption.opacity);

        sectionIconNoThresholdHigh = iconService.getTriangleIcon(ICON_SIZE, "lime", "black", markerFloodOption.opacity);

        sectionIconOrdinaria = iconService.getTriangleIcon(ICON_SIZE, "yellow", "black", markerFloodOption.opacity);

        sectionIconElevata = iconService.getTriangleIcon(ICON_SIZE, "red", "black", markerFloodOption.opacity);

        //for(var layerId in mapLayer._layers){
        //    mapLayer._layers[layerId].setIcon(getIcon(mapLayer._layers[layerId].properties.feature))
        //}

    }

    /**
    var sectionIconUndefined = iconService.getTriangleIcon(ICON_SIZE, "grey");

    var sectionIconNoThresholdLow = iconService.getTriangleIcon(ICON_SIZE, "white");

    var sectionIconNoThresholdHigh = iconService.getTriangleIcon(ICON_SIZE, "lime");

    var sectionIconOrdinaria = iconService.getTriangleIcon(ICON_SIZE, "yellow");

    //var sectionIconModerata = mapService.getTriangleIcon(ICON_SIZE, "orange");

    var sectionIconElevata = iconService.getTriangleIcon(ICON_SIZE, "red");


    function getIcon(feature){

        var value = feature.properties.maxvalue;

        if(value> 50){
            console.log("p")
        }

        //Creo array soglie
        var aThreshold = [];
        if(value != -9999){
            for(prop in feature.properties){
                if((stringStartsWith(prop, "Q_ALLARME"))||(stringStartsWith(prop, "Q_ALLERTA"))){
                    if (feature.properties[prop] != -9999 && feature.properties[prop] != 0 ){
                        var obj = {
                            prop : feature.properties[prop],
                            exceded : (value > feature.properties[prop])?true:false
                        }
                        aThreshold.push(obj)
                    }
                }
            }
        }


        var superati = _.filter(aThreshold, function(obj){
            return obj.exceded
        })

        var icon

        switch(aThreshold.length){
            case 0:
                return sectionIconUndefined;
                break
            case 1:
                (superati.length == 1)?icon =sectionIconElevata: icon = null
                if (superati.length == 0){
                    feature.properties.trend > 0?icon = sectionIconNoThresholdHigh:icon = sectionIconNoThresholdLow
                }
                break
            case 2:
                if (superati.length == 1)icon = sectionIconOrdinaria
                if (superati.length == 2)icon = sectionIconElevata
                if (superati.length == 0){
                    feature.properties.trend > 0?icon = sectionIconNoThresholdHigh:icon = sectionIconNoThresholdLow
                }
                break

        }
        return icon;


    }
     */

    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        setMapLayer: function (mapL) {
            mapLayer = mapL;
        },

        canMovie: function(){
            return false
        },

        setLayerData:function(ld){
            layerData = ld
        },
        getLayerData:function(){
            return layerData
        },



        load: function(onFinish) {

            var _this = this;


            serieService.getLayerData(layer, function (ld) {
                layerData = ld;
                floodproofsService.layer(layer.server.id,layerData.layer.dataid, function (data) {

                    theGeoJson = data;

                    var dateToCheck = null;

                    if(theGeoJson.features){
                        theGeoJson.features.forEach(function (feature) {

                            if(feature.properties.run != ""){
                                dateToCheck = moment(feature.properties.run,"YYYYMMDDHHmm");

                                if(dateRun!= null){
                                    if(dateToCheck.isAfter(dateRun)){
                                        dateRun = dateToCheck;
                                    }
                                }else{
                                    dateRun = dateToCheck;
                                }
                            }
                        })
                    }

                    mapLayer = mapService.addGeoJsonLayer(data, layer['descr'], {

                        pointToLayer: function(feature, latlng) {
                            return L.marker(latlng, {icon:iconService.section_gauge_observation_Icon(feature)});
                        }

                    }, stationClickListener,(_this.stationInfoMouseOver)?_this.stationInfoMouseOver:stationInfoMouseOver, (_this.stationInfoMouseOut)?_this.stationInfoMouseOut:stationInfoMouseOut);

                    if (onFinish) onFinish()

                }, function(data) {

                    alert('Error loading layer: ' + data.error_message);

                })

            });

        },

        layerTooltip: function(){

            var manager = mapService.getLayerManager(mapLayer);


            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : manager.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : manager.typeDescr()
                }

            ];
            return tooltipObj;
        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        setOpacity : function(value){

            if (value){
                markerFloodOption.opacity = value;
                markerFloodOption.fillOpacity = value;
                updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return markerFloodOption.opacity
        },

        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.name
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        typeDescr: function () {
            return "SECTION_DETERMINISTIC"
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi
        },

        getWarningInfo: function () {
            return infoPopUP;
        },

        setVisible: function (b) {

            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        },

        dateLine:function(){
            //return layerObj.descr;
            if(dateRun)return dateRun.format('DD/MM/YYYY HH:mm')
        },

        thirdLine:function(){
            return true


        },

        getVariable :function(){

            return ""

        },

        getAggregation :function(){

            return""


        }



    }

}

function layerManager_section_gauge_observation_level(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService) {

    var manager = layerManager_section_gauge_observation(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService);


    manager.load = function(onFinish) {

        var _this = this;


        serieService.getLayerData(layerObj, function (ld) {
            manager.setLayerData(ld);
            floodproofsService.layer(layerObj.server.id,ld.layer.dataid, function (data) {



                var mapLayer = mapService.addGeoJsonLayer(data, layerObj['descr'], {

                    pointToLayer: function(feature, latlng) {
                        return L.marker(latlng, {icon:iconService.section_gauge_observation_level_Icon(feature)});
                    }

                }, (_this.stationClickListener)?_this.stationClickListener:stationClickListener,(_this.stationInfoMouseOver)?_this.stationInfoMouseOver:stationInfoMouseOver, (_this.stationInfoMouseOut)?_this.stationInfoMouseOut:stationInfoMouseOut);

                manager.setMapLayer(mapLayer);

                if (onFinish) onFinish()

            }, function(data) {

                alert('Error loading layer: ' + data.error_message);

            })

        });

    }


    manager.stationClickListener = function(s) {

        if(s.target.feature.properties.maxvalue <=-9998){
            alert($translate.instant('UNAVAILABLE_DATA'));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/hydrogram_chart_form.html',
            controller: 'hydrogramChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sectionData: function () {

                    return {

                        section : s.target.feature.properties,
                        prop : manager.getLayerData().prop,
                        serverId: layerObj.server.id

                    };

                }

            }
        })

    };

    manager.stationInfoMouseOver = function(s){
        if(manager.getWarningInfo()){
            // console.log("FloodProofsDeterministicEfforts");
            manager.getWarningInfo().mouseOver('FloodProofsDeterministicEfforts',manager.mapLayer()._leaflet_id, s.target.feature.properties  )
        }
    };


    manager.stationInfoMouseOut = function (s) {
        if(manager.getWarningInfo()){
            // console.log("FloodProofsDeterministicEfforts");
            manager.getWarningInfo().mouseOut('FloodProofsDeterministicEfforts',manager.mapLayer()._leaflet_id, s.target.feature.properties  )
        }
    }






    return manager;
}


