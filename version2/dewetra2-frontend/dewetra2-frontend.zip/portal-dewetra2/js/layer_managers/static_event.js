/**
 * Created by Dario on 19/05/21.
 */

function layerManager_static_event(layerObj) {

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices();

    var iOpacity = 1;

    var dataid;

    var downloadUrl;

    var debug = true;

    var aLayers = [];

    var baseLayerObject = layerObj;

    let date;

    oManager.draggable = function () {
        return true;
    }

    oManager.type = () => {
        return "STATIC_EVENT";
    }
    oManager.typeDescr = () => {
        return "STATIC_EVENT";
    }

    oManager.haveAudio = () => {
        return false;
    }
    oManager.legend = () => {
        return {
            dynPalette: {},
            // FROmGEOSERVER
            type: 'STATIC',
            // type: oManager.layerObj().type.code.toUpperCase(),
            url: oManager.mapLayer()._url,
            layers: oManager.mapLayer().wmsParams.layers,
        }
    }

    oManager.canMovie = () => {
        return false;
    }

    oManager.refreshable = () => {
        return false;
    }

    oManager.layerTooltip = () => {
        let tooltipObj = [
            {
                label: "LAYER_NAME",
                value: oManager.name()
            },
            {
                label: "LAYER_DESCRIPTION",
                value: oManager.descr()
            },
            {
                label: "LAYER_TYPE",
                value: oManager.type()
            }

        ];
        return tooltipObj;
    }

    oManager.remove = (layer, onFinish) => {
        oServices.mapService.removeLayer(layer);
        if (onFinish) onFinish()
    }

    oManager.dateLine = (layer, onFinish) => {
        return oManager.layerObj().descr;
    }

    oManager.delayLine = (layer, onFinish) => {
        return "";
    }

    oManager.customprops = (layer, onFinish) => {
        if (oManager.layerObj().hasOwnProperty("customprops")) {
            return JSON.parse(oManager.layerObj().customprops)
        }
    }

    oManager.parseInfo = (data) => {
        var ret = {
            layerName: oManager.layerObj().name,
            properties: []
        };

        if (data.features && data.features.length > 0) {
            data.features.forEach(function (f) {
                if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                    ret.properties.push({name: 'value', 'value': f.properties.GRAY_INDEX.toFixed(2)})
                } else {
                    for (p in f.properties) {
                        ret.properties.push({name: p, 'value': f.properties[p]})
                    }
                }
            })
        }

        ret.properties.forEach(function (item) {
            if (item.name == 'link') {
                item.html = true;
            } else item.html = false;
        })

        return ret;
    }

    oManager.loadWithProperties = (onFinish, layerObj, props, item, dateFrom, dateTo, opacity) => {
        oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));
        dataid = oManager.layerObj().dataid;

        if (oManager.customprops() && oManager.customprops().hasOwnProperty('static_properties')) {

            aLayers = oManager.customprops().static_properties.properties

            aLayers.push({
                "descr": oManager.layerObj().descr,
                "dataid": oManager.layerObj().dataid,
                "url": oManager.layerObj().server.url
            })

        }

        if (iOpacity) oManager.setOpacity(opacity);
        if (onFinish) onFinish();

    };


    oManager.load = function (onFinish) {
        oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));

        dataid = oManager.layerObj().dataid;

        if (oManager.customprops() && oManager.customprops().hasOwnProperty('event_properties')) {

            try {
                date = moment.utc().parse(oManager.customprops().event_properties.properties.date, 'YYYYMMDDHHmm')
            }catch (e) {
                console.log(e)
            }
        }

        if (onFinish) onFinish()

    };


    oManager.update = function ( newLayer, onFinish) {

        let layer = aLayers.filter(layer => layer.dataid == newLayer.dataid)[0];

        let layerObj = oManager.layerObj()

        layerObj.descr = layer.descr;
        layerObj.server.url = layer.url;
        layerObj.dataid = layer.dataid;

        dataid = layerObj.dataid;

        oManager.setLayerObj(layerObj);

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));

        if (onFinish) onFinish();
    };


    oManager.layerProps = {}


    oManager.showProps = function (onFinish) {

        var layerPropModal = oServices.$uibModal.open({
            template: `<div class="popup">
                        <div class="head" >
                            <div class="flex-container">
                                <!--Title-->
                                <div class="brand flex-item">
                                    <i class="fa app-static animated bounceIn delay-002" ></i>
                                    <p class="animated fadeInDown delay-001" translate>
                                          <span translate>  </span> <span translate>properties</span>
                                    </p>
                                </div>
                                <div class="flex-item">
                                    <a class="close" ng-click="close()" href>
                                        <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="modal-body">
                            
                                
                            <div class="row">
                                <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                                    <label class="hidden-xs">
                                        <h4 translate>VARIABLE</h4>
                                    </label>
                                    <p></p>
                                </div>
                    
                                <div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
                                    <select class="form-control" ng-model="oConfig.selectedVariable" ng-options="layer as layer.descr | translate for layer in oConfig.params.aLayers"></select>
                                </div>
                            </div>
                                
                                           
                            <br>
                            <br>
                            <div class="row">
                                <div class="flex-item animated zoomInUp delay-003 ">
                                    <a href="" class="btn btn-warning pull-right" ng-click="update()"  ng-show="oConfig.selectedVariable.descr">
                                        <i class="fa fa-refresh "></i>
                                        {{ 'LAYER_REFRESH' | translate }}
                                        
                                    </a>
                                </div>  
                            </div>
                        </div>
                    </div>`,
            controller: ['$scope', 'params', '$uibModalInstance', function ($scope, params, $uibModalInstance) {

                $scope.oConfig = {
                    selectedVariable: params.aLayers.filter(l => params.dataid == l.dataid)[0],
                    params: params
                };

                $scope.close = () => {
                    $uibModalInstance.dismiss();
                };
                $scope.update = () => {
                    $uibModalInstance.close($scope.oConfig.selectedVariable);
                };


            }],
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        aLayers: aLayers,
                        oManager: oManager,
                        dataid: dataid
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {

            oManager.update(obj, null, onFinish)
        }, function () {
            if (debug) console.log("CANCEL")
        });
    };

    oManager.customFormatDateDescription = function (data) {
        return data.description
    }


    return oManager;

}
