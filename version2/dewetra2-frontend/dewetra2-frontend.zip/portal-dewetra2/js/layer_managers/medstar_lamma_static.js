
/**
 * Created by Dario on 19/06/21.
 */

function layerManager_medstar_lamma_static(layerObj) {

    const oManager = layerManager_static(layerObj);

    const oServices = oManager.oServices();

    oManager.load = (onFinish) => {
        const url = 'https://geoservizi1.regione.liguria.it/geoserver/M1947/wms';
        const params = {
            service: 'WMS',
            request: 'GetMap',
            //version: '1.3.0',
            version: '1.1.1',
            layers: 'L6422',
            styles: '',
            time:'',
            // srsName:'EPSG:3857',
            // crsName:'EPSG:3857',
            format: 'image/png',
            // width: 512,
            // height: 512,
            // width=256&height=256
            //tiled: true,
            transparent: true
        };
        // oManager.setMapLayer(mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));

        oManager.setMapLayer(oServices.mapService.addWmsLayerWithParameters(url, params));

        if (onFinish) onFinish()
    };

    return oManager

}
