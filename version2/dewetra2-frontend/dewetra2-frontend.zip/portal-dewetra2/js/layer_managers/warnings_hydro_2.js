/**
 * Created by Dario Rubado on 15/12/15.
 */



function layerManager_warnings_hydro(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService) {

    var layer = layerObj;
    var layerData = null;

    var warningInfo = null;

    var mapLayer = null;

    var layerProps = null;

    var props = null;

    var visible = true;

    var aggregationType = null;

    //check olddata routine
    var triggerTime = 18000;

    var timeToUndef = 7200;

    const stringSoglie = "e_";
    const stringValori = "v_";

    var wsAcquisition = null;



    //{
    //    "sensorid": -2147433942,
    //    "stationname": "pippo",
    //    "v_1449843027_3600": 6,
    //    "v_1449843027_0": 6,
    //    "v_1449843027_3600": 6,
    //    "e_1_3": -5
    //}

    var markerWarningOption = {
        radius : iconService.markerWarningOptions.radius,
        weight : iconService.markerWarningOptions.weight,
        color : iconService.markerWarningOptions.color,
        opacity : iconService.markerWarningOptions.opacity,
        fillOpacity: iconService.markerWarningOptions.fillOpacity
    };
    //palette definita in icon service
    var geoServerPalette = iconService.warningHydroPalette;


    var updateListener = function(){
        console.log("update Listener");
        acEvent.connect(window.app.acEvent.username, window.app.acEvent.password, function () {
            wsAcquisition = acEvent.subscribe(window.app.acEvent.queue+'.national_IDROMETRO', updateStation)

        },function () {
            console.log('waiting 5 seconds and then reconnect');
            setTimeout(updateListener,5000)
        })

    };

    var aggregation = [
        {
            type : "REGIONE",
            'selected': false,
            description : "AGGREGAZIONE_REGIONALE"
        },
        {
            type : "PROVINCE",
            'selected': false,
            description : "AGGREGAZIONE_PROVINCIALE"
        },
        {
            type : "COMUNI",
            'selected': false,
            description : "AGGREGAZIONE_COMUNALE"
        },
        {
            type : "BACINI",
            'selected': false,
            description : "BACINI"
        },
        {
            type : "AREEALLERTAMENTO",
            'selected': false,
            description : "WARNING_AREA"
        },
        {
            type : "STAZIONI",
            'selected': true,
            description : "AGGREGAZIONE_STAZiONI",
            dataId : "dew:Municipalities_ISTAT12010"
        },
        {
            type : "FLOOD_WAVE",
            'selected': false,
            description : "FLOOD_WAVE"
        }
    ];


    var oHydroData = {
        theGeoJsonStation: null,
        theGeoJsonRegion: null,
        theGeoJsonDistrict:null,
        theGeoJsonComuni:null,
        theGeoJsonBacini: null,
        theGeoJsonWarningArea: null,
        aAnagrafica: [],
        promise: [],
        audio: function(oldFeatureProperties, newFeatureProperties){
            //modificare audio
            if((newFeatureProperties.warning_palette == 1 || newFeatureProperties.warning_palette == 2)&&(newFeatureProperties.warning_palette > oldFeatureProperties.warning_palette)){
                audioService.playAudio({type:'zoomTo', properties: newFeatureProperties});
                console.log("testaudio")
            }else if((newFeatureProperties.warning_palette == 3 || newFeatureProperties.warning_palette == 4)&&(newFeatureProperties.warning_palette > oldFeatureProperties.warning_palette)){
                audioService.playAudio({type:'zoomTo', properties: newFeatureProperties});
                console.log("testaudio")
            }
        },
        anagrafica: function(){
            if (this.aAnagrafica.length == 0){
                for(var s in this.theGeoJsonStation.features){
                    if(!_.isUndefined(this.theGeoJsonStation.features[s].properties)) {
                        try{
                            this.aAnagrafica[this.theGeoJsonStation.features[s].properties.sensorid] = {
                                regione: this.theGeoJsonStation.features[s].properties.region,
                                provincia: this.theGeoJsonStation.features[s].properties.district,
                                comune: this.theGeoJsonStation.features[s].properties.munic,
                                bacino: this.theGeoJsonStation.features[s].properties.catchment,
                                areaAllertamento: this.theGeoJsonStation.features[s].properties.wa
                            }
                        }
                        catch(err){
                            console.log(err);
                            var p = this.theGeoJsonStation.features['move'];
                            console.log(p)
                        }
                    }
                }
            }
        },
        brintRelevantToFront: function(){
            for(var p in mapLayer._layers){
                mapLayer._layers[p].setZIndexOffset(p*mapLayer._layers[p].feature.properties.warning_palette)
            }
        },
        checkOldData: function(){
            var promise = null;
            promise = $interval(function () {
                oHydroData.checkOldData()
            }, triggerTime);
            oHydroData.promise.push(promise);
        },
        delCheckOldData: function () {
            if(oHydroData.promise){
                oHydroData.promise.forEach(function (promise) {
                    $interval.cancel(promise);
                })
            }
        },
        setGeoJsonStation: function(json) {
            json.features.forEach(function (features) { //error
                features.properties = oHydroData.validateDataByTime(features.properties);
                features.properties.warning_palette = oHydroData.palette(features.properties)
            });
            this.theGeoJsonStation= json;
            //build Dictionary anagrafica
            this.anagrafica();
        },
        setTheGeoJsonRegion : function(json){
            this.theGeoJsonRegion = json;
            this.updateTheGeoJsonRegion()
        },
        setTheGeoJsonDistrict : function(json){
            this.theGeoJsonDistrict = json;
            this.updateTheGeoJsonDistrict()
        },
        setTheGeoJsonComuni : function(json){
            this.theGeoJsonComuni = json;
            this.updateTheGeoJsonComune();
        },
        setTheGeoJsonBacini : function(json){
            this.theGeoJsonBacini = json;
            this.updateTheGeoJsonBacini();
        },
        setTheGeoJsonWarningArea : function(json){
            this.theGeoJsonWarningArea = json;
            this.updateTheGeoJsonWarningArea();
        },
        getGeoJsonStation: function () {
            return this.theGeoJsonStation;
        },
        getTheGeoJsonRegion : function(){
            return this.theGeoJsonRegion;
        },
        getTheGeoJsonDistrict : function(){
            return this.theGeoJsonDistrict;
        },
        getTheGeoJsonComuni : function(){
            return this.theGeoJsonComuni;
        },
        getTheGeoJsonBacini : function(){
            return this.theGeoJsonBacini;
        },
        getTheGeoJsonAreeAllertamento : function(){
            return this.theGeoJsonWarningArea;
        },
        updateTheGeoJsonStation : function(aProperties){

            if(aProperties.length > 0){
                //itero su array proprieta
                aProperties.forEach(function (properties) {
                    if(properties.sensorid == 41854){
                        console.log("x")
                    }

                    //per ogni proprieta la valido
                    var o = oHydroData.validateDataByTime(properties);
                    //assegno una palette
                    o.warning_palette = oHydroData.palette(o);
                    //cernco la feature da aggiornare
                    var f = _.findIndex(oHydroData.theGeoJsonStation.features, function(feature){
                        if (feature.properties.sensorid == o.sensorid) return true;
                    });
                    //console.log(f)
                    if (f > -1) {
                        //console.log("audio test")
                        oHydroData.audio(oHydroData.theGeoJsonStation.features[f].properties, o);
                        //console.log("update feature properties")
                        oHydroData.theGeoJsonStation.features[f].properties = o;
                    }
                });
                console.log("update feature style");
                //aggiorno lo stile
                oHydroData.updateFeatureStyle();
            }else {
                oHydroData.theGeoJsonStation.features.forEach(function (station) {
                    var o = oHydroData.validateDataByTime(station.properties);
                    o.warning_palette = oHydroData.palette(o);
                    station.properties = o;
                    oHydroData.updateFeatureStyle();
                })
            }

        },

        updateFeatureStyle:function(){

            switch(aggregationType) {
                case "REGIONE":
                    console.log("regione");
                    this.updateTheGeoJsonRegion();
                    this.updateRegionFeaturesStyle();
                    break;
                case "PROVINCE":
                    console.log("province");
                    this.updateTheGeoJsonDistrict();
                    this.updateDistrictFeaturesStyle();
                    break;
                case "COMUNI":
                    this.updateTheGeoJsonComune();
                    this.updateComuniFeaturesStyle();
                    console.log("comuni");
                    break;
                case "STAZIONI":
                    this.updateMarkerStyle();
                    console.log("stazioni");
                    break;
                case "BACINI":
                    this.updateTheGeoJsonBacini();
                    this.updateBaciniFeatureStyle();
                    console.log("bacini");
                    break;
                case "FLOOD_WAVE":
                    this.updateMarkerStyle()
                    console.log("floodwave");
                    break;
                case "AREEALLERTAMENTO":
                    this.updateTheGeoJsonWarningArea();
                    this.updateWarningAreaFeatureStyle();
                    console.log("aree Allertamento");
                    break;
                default:{
                    this.updateMarkerStyle()}
            }
        },

        updateMarkerStyle:function(){
            console.log("update marker style");
            this.theGeoJsonStation.features.forEach(function(station){

                var f = _.findKey(mapLayer._layers, function (marker) {
                    return (marker.feature.properties.sensorid == station.properties.sensorid)
                });
                if(f > -1){
                    //console.log("setStyle marke")

                    // mapLayer._layers[f].setStyle(
                    //     {
                    //         fillColor: geoServerPalette[station.properties.warning_palette],
                    //         opacity: markerWarningOption.opacity,
                    //         fillOpacity: markerWarningOption.fillOpacity
                    //     }
                    // );
                    mapLayer._layers[f].setIcon(getIcon(station))

                    // console.log("updated station")
                    // console.log(station)

                    if (mapLayer._layers[f].feature.properties.warning_palette ==1 ||mapLayer._layers[f].feature.properties.warning_palette ==2 || mapLayer._layers[f].feature.properties.warning_palette ==3|| mapLayer._layers[f].feature.properties.warning_palette ==4)mapLayer._layers[f].bringToFront();

                    mapLayer._layers[f].feature.properties = station.properties;
                }
            });
        },

        updateRegionFeaturesStyle:function(){

            this.theGeoJsonRegion.features.forEach(function(region){

                var f = _.findKey(mapLayer._layers, function (marker) {
                    if (marker.feature.properties.gid == region.properties.gid) return true;
                });
                if(f>-1){
                    mapLayer._layers[f].properties = region;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[region.properties.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity,
                            color : markerWarningOption.color,
                            weight: markerWarningOption.weight
                        }
                    )
                }
            });
        },

        updateDistrictFeaturesStyle:function(){

            this.theGeoJsonDistrict.features.forEach(function(province){

                var f = _.findIndex(mapLayer._layers, function (marker) {
                    if (marker.properties.district == province.gid) return true;
                });
                if(!_.isUndefined(f)){
                    if((province.warning_palette == 1 || province.warning_palette == 2)&&(province.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }else if((province.warning_palette == 3 || province.warning_palette == 4)&&(o.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }

                    mapLayer._layers[f].properties = province;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[province.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity,
                            color : markerWarningOption.color,
                            weight: markerWarningOption.weight
                        }
                    )
                }
            });
        },

        updateComuniFeaturesStyle:function(){

            this.theGeoJsonComuni.features.forEach(function(comune){

                var f = _.findIndex(mapLayer._layers, function (marker) {
                    if (marker.properties.munic == comune.gid) return true;
                });
                if(!_.isUndefined(f)){
                    if((comune.warning_palette == 1 || comune.warning_palette == 2)&&(comune.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }else if((comune.warning_palette == 3 || comune.warning_palette == 4)&&(o.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }

                    mapLayer._layers[f].properties = comune;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[comune.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity,
                            color : markerWarningOption.color,
                            weight: markerWarningOption.weight
                        }
                    )
                }
            });
        },

        updateBaciniFeatureStyle: function () {

            this.theGeoJsonBacini.features.forEach(function(catchment){

                var f = _.findIndex(mapLayer._layers, function (marker) {
                    if (marker.properties.catchment == catchment.gid) return true;
                });
                if(!_.isUndefined(f)){
                    if((catchment.warning_palette == 1 || catchment.warning_palette == 2)&&(catchment.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }else if((catchment.warning_palette == 3 || catchment.warning_palette == 4)&&(o.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }

                    mapLayer._layers[f].properties = catchment;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[catchment.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity,
                            color : markerWarningOption.color,
                            weight: markerWarningOption.weight
                        }
                    )
                }
            });
        },

        updateWarningAreaFeatureStyle: function () {
            this.theGeoJsonWarningArea.features.forEach(function(WarningArea){

                var f = _.findIndex(mapLayer._layers, function (marker) {
                    if (marker.properties.wa == WarningArea.gid) return true;
                });
                if(!_.isUndefined(f)){
                    if((WarningArea.warning_palette == 1 || WarningArea.warning_palette == 2)&&(WarningArea.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }else if((WarningArea.warning_palette == 3 || WarningArea.warning_palette == 4)&&(o.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }

                    mapLayer._layers[f].properties = WarningArea;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[WarningArea.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity,
                            color : markerWarningOption.color,
                            weight: markerWarningOption.weight
                        }
                    )
                }
            });
        },

        updateTheGeoJsonRegion: function () {

            var regionGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.region;
            });

            this.theGeoJsonRegion.features.forEach(function(feature){

                var warnIndexRegional = _.max(regionGroup[feature.properties.gid], function (station) {
                    var p = station.properties.warning_palette;
                    return p;
                });
                feature.properties.warning_palette = warnIndexRegional.properties.warning_palette;
            });
        },

        updateTheGeoJsonDistrict: function () {

            var districtGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.district;
            });


            this.theGeoJsonDistrict.features.forEach(function(feature){
                if (districtGroup[feature.properties.gid]){

                    var warnIndexDistrict = _.max(districtGroup[feature.properties.gid], function (station) {
                        return station.properties.warning_palette;
                    });
                    feature.properties.warning_palette = warnIndexDistrict.properties.warning_palette;
                }
            });
        },

        updateTheGeoJsonComune: function () {

            var municGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.munic;
            });

            this.theGeoJsonComuni.features.forEach(function(feature){
                if(municGroup[feature.properties.gid]){
                    var warnIndexMunic = _.max(municGroup[feature.properties.gid], function (station) {
                        var p = station.properties.warning_palette;
                        return p;
                    });
                    feature.properties.warning_palette = warnIndexMunic.properties.warning_palette;
                }else feature.properties.warning_palette = -2



            });
        },

        updateTheGeoJsonBacini: function () {

            var catchmentsGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.catchment;
            });
            this.theGeoJsonBacini.features.forEach(function(feature){
                if(catchmentsGroup[feature.properties.gid]){
                    var warnIndexCatchments = _.max(catchmentsGroup[feature.properties.gid], function (station) {
                        return station.properties.warning_palette;
                    });
                    feature.properties.warning_palette = warnIndexCatchments.properties.warning_palette;
                }else feature.properties.warning_palette = -2
            });
        },

        updateTheGeoJsonWarningArea: function () {

            var waGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.wa;
            });
            this.theGeoJsonWarningArea.features.forEach(function(feature){
                if(waGroup[feature.properties.gid]){
                    var warnIndexWA = _.max(waGroup[feature.properties.gid], function (station) {
                        return station.properties.warning_palette;
                    });
                    feature.properties.warning_palette = warnIndexWA.properties.warning_palette;
                }else feature.properties.warning_palette = -2
            });
        },

        validateDataByTime: function(properties){

            //se sono nel passato come ora di riferimento per validare i dati prendo quella di caricamento del layer
            var iServerTime =(menuService.isRealTime())? menuService.getUtcServerDateInSecond():menuService.getDateToUTCSecond();

            if (properties.stationname.indexOf("occelletta")> -1){
                console.log(properties)
            }

            var aValori = [];

            for (var prop in properties) {
                if (stringStartsWith(prop, stringValori)) {
                    var aValore = prop.split("_");

                    var oValore = {
                        timestamp: parseInt(aValore[1]),
                        period: parseInt(aValore[2]),
                        valore: parseFloat(properties[prop])
                    };
                    aValori.push(oValore);
                }
            }

            if (aValori.length == 0) return properties;
            var oMostRecentValue = _.max(aValori, function (valore) {
                return valore.timestamp;
            });
            if ((iServerTime - oMostRecentValue.timestamp) > timeToUndef) {
                var obj = {};
                for (var prop in properties) {
                    if (!stringStartsWith(prop, stringValori) &&(!stringStartsWith(prop, stringSoglie))) {
                        obj[prop] = properties[prop];
                    }
                }
                return obj;
            } else return properties;
        },

        palette: (oProperties) => {

            if(oProperties.seriestate == 1){
                debugger
            }

            if (oProperties.stationname.toLowerCase().indexOf("macerone")> -1){
                console.log(oProperties)
                debugger
            }

            let hasExceededMaximum = false;

            //calculate values

            const aValues = [];

            for (let prop in oProperties) {

                if (stringStartsWith(prop, stringValori)) {
                    const aValue = prop.split("_");

                    const oValue = {
                        timestamp: parseInt(aValue[1]),
                        period: parseInt(aValue[2]),
                        valore: parseFloat(oProperties[prop])
                    };
                    if (oProperties[prop] == -9999) return -2;

                    aValues.push(oValue)
                }
            }

            //calculate values END

            if(aValues.length == 0){
                return -2
            }

            if(aValues.length > 0 && oProperties.numthr == 0) {
                return -1
            }

            //calculate threshold

            const aTresholds = [];

            for (let prop in oProperties) {
                if (stringStartsWith(prop, stringSoglie)) {
                    const aThr = prop.split("_");
                    const oThr = {
                        id: aThr[1],
                        idSoglia: aThr[1],
                        severity: parseInt(aThr[2]),
                        valore: oProperties[prop]
                    };
                    aTresholds.push(oThr)

                }
            }
            //calculate threshold end



            // calculate if maximum was exceeded
            if(oProperties.hasOwnProperty('thr_names') && Object.values(oProperties.thr_names).length > 0){
                hasExceededMaximum = (Object.values(oProperties.thr_names).filter(value => value.indexOf('MAX')>-1).length > 0);
            }

            if (aValues.length > 0 && aTresholds.length == 1 && hasExceededMaximum){
                return 5
            }


            //section with threshold but none exceeded
            if(aValues.length > 0 && aTresholds.length == 0) {
                return 0
            }

            if(aValues.length > 0 && aTresholds.length > 0){
                const maxSeverity = Math.max.apply(Math, aTresholds.map(function(o) { return o.severity; }))
                return maxSeverity
            }

        }
    }
    /**
     * function that manage aggregation type and call the righ one
     * @param objprops object passed by properties layer controller
     * @param data object passed by properties layer controller
     * @param onFinish function reset layer manager passed in layerlist controller
     */
    function update(objprops, data, onFinish){


        if (data){
            //aggregationType = data.type;
            aggregationType = data.aggregation.type;
            //HighThresholdSet = data.threshold.high.id;
            //LowThresholdSet = data.threshold.low.id;
        }


        if(objprops)props = objprops;

        switch(aggregationType) {
            case "REGIONE":
                console.log("regione");
                loadRegioniJson(loadRegioniLayer);
                break;
            case "PROVINCE":
                console.log("province");
                loadProvinceJson( loadProvinceLayer);
                break;
            case "COMUNI":
                loadComuniJson(loadComuniLayer);
                console.log("comuni");
                break;
            case "STAZIONI":
                loadStazioniLayer();
                console.log("stazioni");
                break;
            case "BACINI":
                loadCatchmentJson(loadBaciniLayer);
                console.log("bacini");
                break;
            case "FLOOD_WAVE":
                //loadCatchmentJson(loadBaciniLayer);
                loadCatchmentJsonForFloodWave(loadStazioniLayer)
                console.log("bacini");
                break;
            case "AREEALLERTAMENTO":
                loadWarningAreaJson(loadWarningAreaLayer);
                console.log("Aree Allertamento");
                break;
            default:loadStazioniLayer();

        }

        if(onFinish)onFinish()

    }

    /**
     * callback that reload station layer whan aggregation is changed
     * @param onFinish function reset layer manager passed in layerlist controller
     * @returns {*}
     */

    function loadStazioniLayer(){
        mapService.removeLayer(mapLayer);

        mapLayer = mapService.addGeoJsonLayer(oHydroData.getGeoJsonStation(), layer['descr'], {

            pointToLayer: function(feature, latlng) {

                return iconStyle(feature, latlng)
            }
        }, stationClickListener,stationMouseOverListener, stationMouseOutListener);
        oHydroData.brintRelevantToFront();
    }


    /**
     * STYLE FUNCTION
     * @param feature
     * @param latlng
     * @returns {*}
     */
    function iconOldStyle(feature, latlng) {
        var geojsonMarkerOptions = {
            radius: markerWarningOption.radius,
            fillColor: geoServerPalette[feature.properties.warning_palette],
            color: "#000",
            weight: markerWarningOption.weight,
            opacity: markerWarningOption.opacity,
            fillOpacity: markerWarningOption.fillOpacity
        };

        return L.circleMarker(latlng, geojsonMarkerOptions);

    }

    function getIcon(feature) {
        return iconService.warnings_hydro_Icon(feature, markerWarningOption.opacity)
    }

    function iconNewStyle(feature, latlng) {
        return L.marker(latlng, {icon:getIcon(feature
        )});
    }



    var iconStyle = iconNewStyle;

    /**
     * callback called when the Regioni aggregation is poed
     * @param url object
     * @param okCallback function LoadProvinceLayer
     * @param onFinish function risetto layer manager
     * @returns {*}
     */

    function loadRegioniJson(loadLayerCallback){

        if(oHydroData.theGeoJsonRegion){

            if(loadLayerCallback) loadLayerCallback()

        }else {
            var oRegioniLocalStorage = menuService.oServiceStorage.m_oWarningRegionFeatureLoader(menuService.oLocalStorage, function (data) {
                oHydroData.setTheGeoJsonRegion(data);
                //oPluvioData.updateTheGeoJsonRegion()
                if (loadLayerCallback) loadLayerCallback()
            })
        }
    }

    /**
     * callback called when the province aggregation is loaded
     * @param url object
     * @param okCallback function LoadProvinceLayer
     * @paramonFinish function risetto layer manager
     * @returns {*}
     */

    function loadProvinceJson( loadLayerCallback) {

        if(oHydroData.theGeoJsonDistrict){

            if(loadLayerCallback)loadLayerCallback();
        }else{
            menuService.oServiceStorage.m_oWarningProvinceFeatureLoader(menuService.oLocalStorage, function (data) {
                oHydroData.setTheGeoJsonDistrict(data);
                //oPluvioData.updateTheGeoJsonDistrict()

                if(loadLayerCallback) loadLayerCallback()
            })
        }

    }

    /**
     * callback called when the comuni aggregation is loaded
     * @param url object
     * @param okCallback function LoadComuniLayer
     * @param onFinish function risetto layer manager
     * @param returns {*}
     */

    function loadComuniJson( loadLayerCallback) {


        if(oHydroData.theGeoJsonComuni){

            if(loadLayerCallback)loadLayerCallback();

        }else{
            menuService.oServiceStorage.m_oWarningComuniFeatureLoader(menuService.oLocalStorage, function(data){

                var municGroup = _.groupBy(oHydroData.theGeoJsonStation.features, function(sensor){
                    return sensor.properties.munic;
                });

                var aFeatures = [];
                //fitro per i sensori che hanno assegnato un comune cosi da snellire la mappa
                data.features.forEach(function (feature) {
                    if (municGroup[feature.properties.gid]) aFeatures.push(feature)
                });
                data.features = aFeatures;

                //setto i comuni
                oHydroData.setTheGeoJsonComuni(data);
                //carico il layer
                if(loadLayerCallback) loadLayerCallback()
            })
        }

    }

    /**
     * callback called when geojson of bacini is loades
     * @param onFinish
     */
    function loadCatchmentJson(loadLayerCallback){


        if(oHydroData.theGeoJsonBacini){

            if(loadLayerCallback)loadLayerCallback();
        }else{
            menuService.oServiceStorage.m_oWarningBaciniFeatureLoader(menuService.oLocalStorage, function (data) {
                oHydroData.setTheGeoJsonBacini(data);

                if(loadLayerCallback) loadLayerCallback()
            })
        }
    }

    /**
     * callback called when geojson of bacini is loades
     * @param onFinish
     */
    function loadCatchmentJsonForFloodWave(loadLayerCallback){


        if(oHydroData.theGeoJsonBacini){

            if(loadLayerCallback)loadLayerCallback();
        }else{
            menuService.oServiceStorage.m_oWarningBaciniFeatureLoader(menuService.oLocalStorage, function (data) {
                oHydroData.setTheGeoJsonBacini(data);

                if(loadLayerCallback) loadLayerCallback()
            })
        }
    }


    /**
     * callback called when geojson of bacini is loades
     * @param onFinish
     */
    function loadWarningAreaJson(loadLayerCallback){

        if(oHydroData.theGeoJsonWarningArea){
            if(loadLayerCallback)loadLayerCallback();
        }else{
            menuService.oServiceStorage.m_oWarningWAFeatureLoader(menuService.oLocalStorage, function (data) {
                oHydroData.setTheGeoJsonWarningArea(data);
                //oPluvioData.updateTheGeoJsonWarningArea()

                if(loadLayerCallback) loadLayerCallback()
            })
        }
    }

    /**
     * callback called when the geojson of the region is loaded
     * @returns {*}
     */

    function loadRegioniLayer(onFinish){


        mapService.removeLayer(mapLayer);

        mapLayer = mapService.addGeoJsonLayer(oHydroData.getTheGeoJsonRegion(), layer['descr'],{

            onEachFeature: function(feature, layer) {

                //if (feature.properties && feature.properties.NOME_REG) {
                //    layer.bindPopup(feature.properties.NOME_REG);
                //}

            }

        }, stationClickListener, stationMouseOverListener, stationMouseOutListener);
        mapLayer.setStyle(function(feature) {
           // console.log(feature);
            var colorIndex = feature.properties.warning_palette;

            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight
            }
        });

        //test 09/04
        oHydroData.updateFeatureStyle();

        if(onFinish)onFinish();

    }

    /**
     * callback called when the geojson of the province is loaded
     * @param onFinish callback re set layer manager from layer list controller
     * @returns {*}
     */
    function loadProvinceLayer(onFinish){

        mapService.removeLayer(mapLayer);

        mapLayer = mapService.addGeoJsonLayer(oHydroData.getTheGeoJsonDistrict(), layer['descr'], null, stationClickListener, stationMouseOverListener, stationMouseOutListener);
        mapLayer.setStyle(function(feature) {

            var colorIndex = feature.properties.warning_palette;
            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight
            }
        });

        //test 09/04
        oHydroData.updateFeatureStyle();

        if(onFinish)onFinish();

    }

    /**
     * callback called when the geojson of the municipality is loaded
     * @param onFinish
     */
    function loadComuniLayer(onFinish){

        mapService.removeLayer(mapLayer);

        //non funziona style da fare nel frattempo uso

        mapLayer = mapService.addGeoJsonLayer(oHydroData.getTheGeoJsonComuni(), layer['descr'], stationClickListener, stationMouseOverListener, stationMouseOutListener);
        //mapLayer.addData(geoJsonRegioni)

        mapLayer.setStyle(function(feature) {
            //console.log(feature);
            var colorIndex = feature.properties.warning_palette;


            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight
            }
        });

        //test 09/04
        oHydroData.updateFeatureStyle();

        if(onFinish)onFinish()

    }

    /**
     * callback called when the geojson of the bacini is loaded
     * @param onFinish
     */
    function loadBaciniLayer(onFinish){

        mapService.removeLayer(mapLayer);

        //non funziona style da fare nel frattempo uso

        mapLayer = mapService.addGeoJsonLayer(oHydroData.getTheGeoJsonBacini(), layer['descr'], null, stationClickListener, stationMouseOverListener, stationMouseOutListener);
        //mapLayer.addData(geoJsonRegioni)

        mapLayer.setStyle(function(feature) {
            //console.log(feature);
            var colorIndex = feature.properties.warning_palette;


            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight

            }
        });

        //test 09/04
        oHydroData.updateFeatureStyle();

        if(onFinish)onFinish()
    }

    /**
     * callback called when the geojson of the aree allertamento is loaded
     * @param onFinish
     */
    function loadWarningAreaLayer(onFinish){

        mapService.removeLayer(mapLayer);

        //non funziona style da fare nel frattempo uso

        mapLayer = mapService.addGeoJsonLayer(oHydroData.getTheGeoJsonAreeAllertamento(), layer['descr'], null, stationClickListener, stationMouseOverListener, stationMouseOutListener);
        //mapLayer.addData(geoJsonRegioni)

        mapLayer.setStyle(function(feature) {
            //console.log(feature);
            var colorIndex = feature.properties.warning_palette;


            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight

            }
        });

        //test 09/04
        oHydroData.updateFeatureStyle();

        if(onFinish)onFinish()
    }

    /**
     * Fuction for async update layer
     * @param data
     */
    function updateStation(data){

        console.log("sensor update iteration");
        var aHydroData = [];
        //se sono presenti nella anagrafica li prendo
        if(_.isArray(data)){
            aHydroData = _.filter(data, function (station) {
                if (oHydroData.aAnagrafica[station.sensorid]) return true;
            })
        }else{
            //questo nel caso sia un oggetto
            if (oHydroData.aAnagrafica[data.sensorid]) aHydroData.push(data);
        }

        console.log("warning hydro: " + aHydroData.length + " sensor to Update");
        //console.log( termoData)

        if (aHydroData.length > 0){

            //console.log(termoData);
            console.log("update the geoJson");
            oHydroData.updateTheGeoJsonStation(aHydroData);

        }

    }




    /**
     * callback called when the region features si clicked
     * @param s object
     * @returns {*}
     */
    function regionClickListener(s) {
        console.log(s.target.feature.properties.NOME_REG);
        s.target.bindPopup(s.target.feature.properties.NOME_REG).openPopup();
    }

    /**
     * callback called when the region features si clicked
     * @param s object
     * @returns {*}
     */
    function provinciaClickListener(s) {
        //console.log(s.target.feature.properties.NOME_REG)
        s.target.bindPopup(s.target.feature.properties.NOME_PRO).openPopup();
    }

    /**
     * callback called when the region features si clicked
     * @param s object
     * @returns {*}
     */
    function comuneClickListener(s) {
        console.log(s.target.feature.properties.NOME_COM);
        s.target.bindPopup(s.target.feature.properties.NOME_COM).openPopup();
    }

    /**
     * mouse listener
     * @param feature object
     * @return *
     * */
    function stationMouseOverListener(s){

        switch(aggregationType) {
            case "REGIONE":
                console.log("regione");

                break;
            case "PROVINCE":
                console.log("province");

                break;
            case "COMUNI":

                console.log("comuni");
                break;
            case "BACINI":

                console.log("bacini");
                break;
            case "AREEALLERTAMENTO":

                console.log("Aree Allertamento");
                break;
            case "FLOOD_WAVE":
                try{
                    if(warningInfo){
                        warningInfo.mouseOver('hydro',mapLayer._leaflet_id, s.target.feature.properties, geoServerPalette)
                    }
                }catch(err){
                    alert("errot thresholdInfo.mouseOver")
                }
                console.log("flood wave");
                break;
            case "STAZIONI":
                try{
                    if(warningInfo){
                        console.log(s.target.feature.properties);
                        warningInfo.mouseOver('hydro',mapLayer._leaflet_id, s.target.feature.properties, geoServerPalette)
                    }
                }catch(err){
                    alert("errot thresholdInfo.mouseOver")
                }
                console.log("stazioni");
                break;
            default:
                try{
                    if(warningInfo){
                        console.log(s.target.feature.properties);
                        warningInfo.mouseOver('hydro',mapLayer._leaflet_id, s.target.feature.properties, geoServerPalette)
                    }
                }catch(err){
                    alert("errot thresholdInfo.mouseOver")
                }

        }

    }

    function stationMouseOutListener(s){

        switch(aggregationType) {
            case "REGIONE":
                console.log("regione");

                break;
            case "PROVINCE":
                console.log("province");

                break;
            case "COMUNI":

                console.log("comuni");
                break;
            case "BACINI":

                console.log("bacini");
                break;
            case "AREEALLERTAMENTO":

                console.log("Aree Allertamento");
                break;
            case "STAZIONI":
                try{
                    if(warningInfo){
                        warningInfo.mouseOut('hydro',mapLayer._leaflet_id)}
                }catch(err){
                    alert("errot thresholdInfo.mouseOver")
                }
                console.log("stazioni");
                break;
            default:
                try{
                    if(warningInfo){
                        warningInfo.mouseOut('hydro',mapLayer._leaflet_id)}
                }catch(err){
                    alert("errot thresholdInfo.mouseOver")
                }
        }

    }


    /**
     * Manage click on station marker
     * @param s
     */
    function clickListenerStazioni(s){

        console.log(s.target.feature.properties);

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/sensor_chart_form.html',
            controller: 'sensorChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sensorData: function () {

                    var featureData = s.target.feature.properties;

                    return {
                        sensorId : featureData.sensorid,
                        dbId : featureData.dbid,
                        sensorClass : 3
                    };

                }

            }
        });
    }

    /**
     * Manage click on station marker
     * @param s
     */
    function clickListenerAggregazioni(s){
        // console.log(s);
        switch(aggregationType) {
            case "REGIONE":
                console.log("regione");
                var station = oHydroData.getGeoJsonStation();
                var aModalData = _.filter(station.features, function(sensor){
                    return (sensor.properties.region == s.target.feature.properties.gid)
                });
                break;
            case "PROVINCE":
                console.log("province");
                var station = oHydroData.getGeoJsonStation();
                var aModalData = _.filter(station.features, function(sensor){
                    return (sensor.properties.district == s.target.feature.properties.gid)
                });
                break;
            case "COMUNI":
                console.log("comuni");
                var station = oHydroData.getGeoJsonStation();
                var aModalData = _.filter(station.features, function(sensor){
                    return (sensor.properties.munic == s.target.feature.properties.gid)
                });
                break;
            case "BACINI":
                console.log("bacini");
                var station = oHydroData.getGeoJsonStation();
                var aModalData = _.filter(station.features, function(sensor){
                    return (sensor.properties.catchment == s.target.feature.properties.gid)
                });
                break;
            case "FLOOD_WAVE":
                console.log("FLOOD_WAVE");
                loadFloodWaveView(s.target);
                return
                break;
            case "AREEALLERTAMENTO":
                console.log("areeallertamento");
                var station = oHydroData.getGeoJsonStation();
                var aModalData = _.filter(station.features, function(sensor){
                    return (sensor.properties.wa == s.target.feature.properties.gid)
                });
                break;
            default:break;

        }

        if (aggregationType != "FLOOD_WAVE"){

            var modalInstance = $uibModal.open({

                templateUrl: 'apps/dewetra2/views/warning_aggregation_click_detail.html',
                controller: 'warningAggregationClickDetailController',
                size: 'lg',
                keyboard: false,
                resolve: {

                    featureData: function () {

                        var featureData = s.target.feature.properties;

                        return {
                            featureData : featureData,
                            aModalData : aModalData,
                            aggregationType: aggregationType,
                            palette: geoServerPalette,
                            type: "WARNING_HYDRO"
                        };

                    }

                }
            });
        }
    }

    let modalInstance = null;

    function loadFloodWaveView(station, callback) {
        if(modalInstance) return

        modalInstance = $uibModal.open({
            animation: true,
            size: 'lg',
            component: 'floodWaveView2',
            resolve: {
                model: function () {
                    return {
                        toolData:"obj",

                    };
                },
                onClose:function () {
                    if(callback)callback()
                }


            }
        });

        modalInstance.result.then(function (obj) {

            console.log('modal-component dismissed at: ' + new Date());

        }, function () {
            console.log('modal-component dismissed at: ' + new Date());
        });
    }

    function loadFloodWaveViewOLD(station) {

        // console.log(oHydroData.theGeoJsonBacini.features)
        //cerco a quale bacino appartiene la stazione cliccata
        var f = _.findIndex(oHydroData.theGeoJsonBacini.features, function (basin) {
            return (station.feature.properties.catchment == basin.properties.gid)
        });
        // se cè prendo il json del bacino e lo poassa alla floodView view
        if (!_.isUndefined(f)){
            var basin = oHydroData.theGeoJsonBacini.features[f]
        }
        //filtro le stazioni che appartengono a quel bacino
        // var station = _.filter(oHydroData.theGeoJsonStation.features, function (marker) {
        //     return(station.feature.properties.catchment == marker.properties.catchment)
        // })



        let modalInstance = $uibModal.open({
            animation: true,
            component: 'floodWaveViewComponent',
            size:'lg',
            keyboard: false,
            resolve:{
                params: function () {

                    return {
                        basinColor:geoServerPalette[basin.properties.warning_palette],
                        basin : basin.properties.main_basin,
                        catchment : station.feature.properties.catchment,
                        allBasin:oHydroData.theGeoJsonBacini,
                        geoJson : basin,
                        // stations:station,
                        allStations:oHydroData.theGeoJsonStation.features
                    };

                }
            }
        });

        modalInstance.result.then(function (obj) {

            console.log('modal-component dismissed at: ' + new Date());
            modalInstance = null;

        }, function () {
            console.log('modal-component dismissed at: ' + new Date());
            modalInstance = null;
        });


    }


    /**
     * function load chart
     * @param s
     */
    /**
     * function load chart
     * @param s
     */
    function stationClickListener(s) {

        switch(aggregationType) {
            case "REGIONE":
                console.log("regione");
                clickListenerAggregazioni(s);
                break;
            case "PROVINCE":
                console.log("province");
                clickListenerAggregazioni(s);
                break;
            case "COMUNI":
                clickListenerAggregazioni(s);
                console.log("comuni");
                break;
            case "BACINI":
                clickListenerAggregazioni(s);
                console.log("bacini");
                break;
            case "AREEALLERTAMENTO":
                clickListenerAggregazioni(s);
                console.log("Aree Allertamento");
                break;
            case "FLOOD_WAVE":
                clickListenerAggregazioni(s);
                console.log("FLOOD_WAVE");
                break;
            case "STAZIONI":
                clickListenerStazioni(s);
                console.log("stazioni");
                break;
            default:clickListenerStazioni(s);


        }


    }//end station click listener



    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },



        load: function(onFinish) {

            var _this = this;

            console.log("warning hydro Load");
            if (!menuService.isRealTime() && wsAcquisition != null) this.removeListener();

            sentinelService.getNationalIdro(function(data) {

                if (mapLayer) mapService.removeLayer(mapLayer);

                oHydroData.setGeoJsonStation(data);

                mapLayer = mapService.addGeoJsonLayer(oHydroData.getGeoJsonStation(), layer['descr'], {

                    pointToLayer: function(feature, latlng) {
                        // for debug
                        if(feature.properties.stationname.indexOf("occelletta")> -1){
                            console.log(feature)
                        }

                        return iconStyle(feature, latlng);

                    }

                }, stationClickListener,stationMouseOverListener, stationMouseOutListener);

                oHydroData.brintRelevantToFront();

                //for debug floodwave

                if (aggregationType == null){
                    try{
                        for(var i in aggregation){
                            if (aggregation[i].type == layerObj.dataid.toUpperCase()){
                                update(props,{aggregation:{type:layerObj.dataid.toUpperCase()}});
                                aggregationType = layerObj.dataid.toUpperCase();
                            }
                        }
                    }catch (err){
                        console.log(err)
                    }
                }


                //se è aggregata, riaggrego
                if (aggregationType != "STAZIONI") update();

                //se era un layer nascosto lo rinascondo
                if (!visible) _this.setVisible(false);


                if (onFinish) onFinish()

            }, function(data) {

                alert('Error loading layer: ' + data.error_message);

            });

            //connetto a messaggistica il layer se non è nel passato
            if (menuService.isRealTime()) updateListener()




        },

        updateListener: function(){
            console.log("update Listener");
            acEvent.connect('logger', 'logger4dew', function () {
                wsAcquisition = acEvent.subscribe('sentinel.2.national_IDROMETRO', updateStation)

            },function () {
                console.log('waiting 5 seconds and then reconnect');
                setTimeout(this.updateListener,5000)
            })

        },

        removeListener: function () {
            acEvent.unsubscribe(wsAcquisition);
            wsAcquisition = null;
            console.log("unsubscribe")
        },

        remove: function (layer, onFinish) {
            this.removeListener();
            oHydroData.delCheckOldData();
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.name
        },

        descr: function () {
            return aggregationType
        },

        onDateChange : function (callBack) {
            //ricarico il layer se è nel passato fa tutto il load
            this.load(callBack)
        },

        setVisible: function (b,callBack) {
            visible = b;
            if (!b) mapLayer.clearLayers();
            else this.update(null,null, function () {
                if(callBack)callBack()
            } );

        },

        isVisible:function(){
            return visible;
        },

        typeDescr: function () {
            return "HYDROMETRIC_ALERT_THRESHOLD"
        },

        haveAudio:function(){
            return true;
        },

        geoServerPalette: geoServerPalette,

        legend:function () {
            // return{
            //     type:layerObj.type.code.toUpperCase(),
            //     palette:geoServerPalette
            // }

            // "WARNINGS_PLUVIO_-2": "No Data",
            //     "WARNINGS_PLUVIO_-1": "No Pioggia",
            //     "WARNINGS_PLUVIO_0": "No Superamento",
            //     "WARNINGS_PLUVIO_1": "Ordinaria",
            //     "WARNINGS_PLUVIO_2": "Moderata",
            //     "WARNINGS_PLUVIO_3": "Elevata",
            //     "WARNINGS_PLUVIO_4": "Alto",

            var legend = {

                type:"ADVANCED",
                legend:[{
                    type:"CUSTOM",
                    title: "WARNING_HYDRO_PALETTE",
                    palette:[{
                        label:"WARNINGS_HYDRO_-2",
                        color:"#8A8787",
                        // sign:"",
                        // value:"",
                        // mu:"",
                        // dec:0
                    },{
                        label:"WARNINGS_HYDRO_-1",
                        color:"#FFFFFF",
                        // sign:"<",
                        // value:500000,
                        // mu:"€",
                        // dec:0
                    },{
                        label:"WARNINGS_HYDRO_0",
                        color:"#00FF00",
                        // sign:"<",
                        // value:1000000,
                        // mu:"€",
                        // dec:0
                    },{
                        label:"WARNINGS_HYDRO_1",
                        color:"#FFFF00",
                        // sign:"<",
                        // value:1500000,
                        // mu:"€",
                        // dec:0
                    },{
                        label:"WARNINGS_HYDRO_2",
                        color:"#FA8B3C",
                        // sign:"<",
                        // value:2000000,
                        // mu:"€",
                        // dec:0
                    },{
                        label:"WARNINGS_HYDRO_3",
                        color:"#FF0000",
                        // sign:"<",
                        // value:2000000,
                        // mu:"€",
                        // dec:0
                    },{
                        label:"WARNINGS_HYDRO_4",
                        color:"#C13BDB",
                        // sign:"<",
                        // value:2000000,
                        // mu:"€",
                        // dec:0
                    },{
                        label:"WARNINGS_HYDRO_5",
                        color:"#3B46DB",
                        // sign:"<",
                        // value:2000000,
                        // mu:"€",
                        // dec:0
                    }]
                }]

            };

             return legend

        },

        draggable: function () {
            return false;
        },

        setWarningInfo: function (wi) {
            warningInfo = wi
        },

        // update:update,
        update: function (props, data, onFinish) {
            if (data){
                aggregationType = data.type;
            }



            switch(aggregationType) {
                case "REGIONE":
                    console.log("regione");
                    loadRegioniJson(loadRegioniLayer);
                    break;
                case "PROVINCE":
                    console.log("province");
                    loadProvinceJson( loadProvinceLayer);
                    break;
                case "COMUNI":
                    loadComuniJson(loadComuniLayer);
                    console.log("comuni");
                    break;
                case "BACINI":
                    loadCatchmentJson(loadBaciniLayer);
                    console.log("bacini");
                    break;
                case "AREEALLERTAMENTO":
                    loadWarningAreaJson(loadWarningAreaLayer);
                    console.log("aree allertamento");
                    break;
                case "STAZIONI":
                    loadStazioniLayer();
                    console.log("stazioni");
                    break;
                case "FLOOD_WAVE":
                    loadCatchmentJsonForFloodWave(loadStazioniLayer);
                    console.log("FloodWave");
                    break;
                default:loadStazioniLayer();

            }
            if(onFinish) onFinish();
        },

        props: function (){

            var soglie = {
                low: {
                    id: 1,
                    type: "Low Threshold",
                    description: "Low Threshold",
                    list: [
                        {
                            'id': 1,
                            'selected': true,
                            'description': "+/-5 Deg. C"
                        },
                        {
                            'id': 2,
                            'selected': false,
                            'description': "+/-8 Deg. C"
                        },
                        {
                            'id': 3,
                            'selected': false,
                            'description': "+/-10 Deg. C"
                        }
                    ]
                },
                high: {
                    id: 2,
                    type: "High Threshold",
                    description: "High Threshold",
                    list: [
                        {
                            'id': 1,
                            'selected': true,
                            'description': "+/-10 Deg. C"
                        },
                        {
                            'id': 2,
                            'selected': false,
                            'description': "+/-12 Deg. C"
                        },
                        {
                            'id': 3,
                            'selected': false,
                            'description': "+/-15 Deg. C"
                        }
                    ]
                }
            };
            var props ={
                aggregation : aggregation
                //threshold : soglie
            };
            if (aggregationType){
                props.aggregation.forEach(function (a) {
                    if (aggregationType == a.type){
                        a.selected = true
                    } else a.selected = false
                })
            }

            //if (LowThresholdSet){
            //    props.threshold.low.list.forEach(function (a) {
            //        if (LowThresholdSet == a.id){
            //            a.selected = true
            //        } else a.selected = false
            //    })
            //}
            //
            //if (HighThresholdSet){
            //    props.threshold.high.list.forEach(function (a) {
            //        if (HighThresholdSet == a.id){
            //            a.selected = true
            //        } else a.selected = false
            //    })
            //}

            return props
        },

        soglie : function(){
            var setSoglie=[
                {
                    type: "",
                    description: "",
                    soglie:[
                        {
                            descr:"+/-5 Deg. C"
                        },
                        {
                            descr:"+/-8 Deg. C"
                        },
                        {
                            descr:""
                        }

                    ]

                }
            ]
        },

        layerTooltip: function(){

            var manager = this;



            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : manager.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : manager.descr()
                }

            ];
            return tooltipObj;
        },

        layerProps: layerProps,

        showProps: function (onFinish) {
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties_warning_pluvio.html',
                //templateUrl: 'apps/dewetra2/views/layer_properties.html',
                controller: "warningPluvioPropertiesController",
                //controller: "layerPropertiesController",
                size: "lg",
                resolve: {
                    params: function() {

                        return {
                            layer: mapLayer
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj.props, obj.data, onFinish)

            }, function () {
                console.log("CANCEL")
            });
        }

        ,

        thirdLine:function(){
            return ""
        },

        getVariable:function () {
            return ""
        },

        getAggregation:function () {
            return ""
        }

    }

}
