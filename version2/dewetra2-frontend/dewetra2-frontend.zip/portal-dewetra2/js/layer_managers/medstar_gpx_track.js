/**
 * Created by Dario on 19/04/21.
 *
 *
 */

function layerManager_medstar_gpx_track(layerObj) {

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices();

    var iOpacity = 1;

    var layerId;

    var downloadUrl;

    var debug = true;

    var aLayers = [];

    let visible  =true;

    let aMissions = [];
    let selectedMission = 0, selectedMissionJson;





    const GetMissionList = (okCallback, koCallback) => {
        let from = moment(oServices.menuService.getDateFrom()).format('YYYY-MM-DD');
        let to = moment(oServices.menuService.getDateTo()).format('YYYY-MM-DD');
        oServices.apiService.get('qweb/listmissions/' + from + '/' + to + '/', okCallback, koCallback)
    }

    const GetMission = (id, okCallback, koCallback) => {
        oServices.apiService.get('qweb/getmission/' + id , okCallback, koCallback)
    }

    oManager.draggable = function () {
        return false;
    }

    oManager.type = () => {
        return "MEDSTAR_PHENOCAM";
    }
    oManager.typeDescr = () => {
        return "MEDSTAR_PHENOCAM";
    }

    oManager.haveAudio = () => {
        return false;
    }
    oManager.legend = () => {
        return {
            dynPalette: {},
            type: oManager.layerObj().type.code.toUpperCase(),
            url: oManager.mapLayer()._url,
            layers: oManager.mapLayer().wmsParams.layers,
        }
    }

    oManager.canMovie = () => {
        return false;
    }

    oManager.refreshable = () => {
        return false;
    }

    oManager.layerTooltip = () => {
        let tooltipObj = [
            {
                label: "LAYER_NAME",
                value: oManager.name()
            },
            {
                label: "LAYER_DESCRIPTION",
                value: oManager.descr()
            },
            {
                label: "LAYER_TYPE",
                value: oManager.type()
            }

        ];
        return tooltipObj;
    }

    oManager.remove = (layer, onFinish) => {
        oServices.mapService.removeLayer(oManager.mapLayer());
        if (onFinish) onFinish()
    }

    oManager.dateLine = (layer, onFinish) => {
        return "";
    }

    oManager.delayLine = (layer, onFinish) => {
        return "";
    }

    oManager.customprops = (layer, onFinish) => {
        if (oManager.layerObj().hasOwnProperty("customprops")) {
            return JSON.parse(oManager.layerObj().customprops)
        }
    }





    stationClickListener = function (s) {
        debugger
        console.log(s.target.feature.properties);
        // let str = '';
        // if(data.target.feature.properties.imgs.length > 0){
        //     let tok = data.target.feature.properties.imgs[0].split('_');
        //     let date = moment(tok[3]+tok[4]+tok[5]+tok[6], 'YYYYMMDDHHmmss');
        //     let path = 'https://psr.cimafoundation.org/api/phenocam/img/'+ data.target.feature.properties.imgs[0]+'/';
        //     str += '<h3>' +date.format('LLL') + '</h3><img style="width: 300px;" src="' + path + '">'
        // }
        //
        // data.target.bindPopup(str);
        //
        // data.target.openPopup();



    }

    stationMouseOverListener = function (data) {
        console.log(data);
    }

    stationMouseOutListener = function (data) {
        console.log(data);
    }

    const SetLayer = (missionId) => {

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        if(missionId == selectedMission){

            oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(selectedMissionJson, oManager.descr()),
                {
                    style: function (geoJsonFeature) {
                        debugger
                        return {
                            color: 'red',
                            fillColor: 'red',
                            opacity : 1,
                            fillOpacity: 0.3,
                            weight: 5,
                        }
                    }
                }, stationClickListener, stationMouseOverListener, stationMouseOutListener );
        } else {
            GetMission(missionId, (missionData)=>{
                selectedMission = missionId
                selectedMissionJson = missionData;
                oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(missionData, oManager.descr()), {
                    style: function (geoJsonFeature) {
                        debugger
                        return {
                            color: 'red',
                            fillColor: 'red',
                            opacity : 1,
                            fillOpacity: 0.3,
                            weight: 5,
                        }                }
                }, stationClickListener, stationMouseOverListener, stationMouseOutListener );
            });
        }



    }



    oManager.load = function (onFinish) {

        if (oManager.mapLayer()) mapService.removeLayer(oManager.mapLayer());

        GetMissionList((missions)=>{
            aMissions = missions;

            SetLayer( Math.max(...missions));

        })

        if (onFinish) onFinish()


    };

    oManager.remove = function (layer, onFinish) {
        try {
            oServices.mapService.getMap().removeLayer(oManager.mapLayer())
        }catch (e) {
            console.log(e);
        }

        try {
            if (!angular.isUndefined(additionalLayers)){
                additionalLayers.map(mapLayer =>{
                    //oServices.mapService.getMap().removeLayer(mapLayer);
                })
            }
        }catch (e) {
            console.log(e);
        }

        if (onFinish)onFinish()
    }



    oManager.update = function (onFinish, newSelectedMission) {


        SetLayer(newSelectedMission);

        if (onFinish) onFinish();
    };



    oManager.setVisible = function (b) {

        visible = b;
        if (!b) {
            if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());
        } else SetLayer(selectedMission)

    }

    oManager.isVisible = function(){
        return visible;
    }

    oManager.thirdLine= function () {
        return true
    }

    oManager.getVariable = ()=>{
        if (selectedMission > 0) return moment.unix(selectedMission).format('YYYY-MM-DD HH:mm');

    }



    oManager.showProps = function(onFinish) {

        GetMissionList((missions)=>{
            aMissions = missions;

            //init props

            var layerPropModal = oServices.$uibModal.open({
                template: `
                    <div class="popup">
                        <div class="head" >
                            <div class="flex-container">
                                <!--Title-->
                                <div class="brand flex-item">
                                    <i class=""fa app-static animated bounceIn delay-002" ></i>
                                    <p class="animated fadeInDown delay-001" translate>
                                        <span translate>{{layer.name}}</span> <span translate>properties</span>
                                    </p>
                                </div>

                                <div class="flex-item">
                                    <a class="close" ng-click="closePopup()" href>
                                        <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <div class="modal-body">

                            <hr>


                            <div class="row" >
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <label class="hidden-xs">
                                        <h4 translate>CHOOSE_INTERVAL</h4>
                                    </label>
                                </div>

                                <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                                    <select class="form-control"  ng-model="config.selectedDate" ng-options="date as formatDate(date) for date in config.dates" ng-change="selectTypeAttr(date)">
                                    </select>
                                </div>
                            </div>
                            <hr>
                    <div class="row">
                                <div class="flex-item animated zoomInUp delay-003 ">
                                    <a href="" class="btn btn-warning pull-right" ng-click="update()" tooltip="reload layer" ng-show="config.selectedDate">
                                        <i class="fa fa-refresh "></i>
                                        {{ 'LAYER_REFRESH' | translate }}
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>`,
                controller: ['$scope', 'layerService', 'mapService', 'menuService', '$uibModalInstance', 'params', '$interval', '$translate', '_',function ($scope, layerService, mapService, menuService, $uibModalInstance, params, $interval, $translate, _) {

                    $scope.config= {
                        selectedDate: {},
                        dates: []
                    }
                    $scope.config.dates = params.temporalInstants;

                    if(params.selectedDate){
                        $scope.config.selectedDate = $scope.config.dates[$scope.config.dates.indexOf((params.selectedDate))];
                        ;                }




                    $scope.formatDate = (date) => {
                        return moment.unix(date).format('DD/MM/YYYY HH:mm')
                    }


                    $scope.selectTypeAttr = function(d){
                        console.log(d);
                    }

                    $scope.update = function () {
                        $uibModalInstance.close($scope.config.selectedDate);
                    };

                    $scope.closePopup = function () {
                        $uibModalInstance.dismiss()
                    };



                }],
                size: "lg",
                resolve: {
                    params: function() {
                        return {
                            layer: layerObj,
                            temporalInstants: aMissions,
                            selectedDate : selectedMission
                        }
                    }
                }
            });

            layerPropModal.result.then(function (selectedDate) {
                oManager.update(onFinish, selectedDate)
            }, function () {
                console.log("CANCEL")
            });

            //end init props

        })


    }

    oManager.customFormatDateDescription = function (data) {
        return data.description
    }



    return oManager;



}
