/**
 * Created by Dario Rubado on 27/02/19.
 */




function layerManager_dynamic_meteo_model(layerObj) {


    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices()

    var oLegendSubLevel = {

        type: "ADVANCED",
        legend: [{
            type: "CUSTOM",
            title: "DESINVENTAR",
            palette: []
        }]

    }


    var oLegend = {}


    var iOpacity = 1;

    var oLayers = {};

    var serverUrl;

    var sIdLayer,sDataId,sDateRun,sVariable,sLevel,sInstant;


    var playPromise, lazyLoadPromise;
    var iIndexOfInstant, iOldIndexOfInstant  = -1;

    function paletter(geoJson) {


        // oLegend = {}
        //
        // var iLengthPalette= 10;
        //
        // var iMax,iMin;
        // if(geoJson.features[0].properties.aggregations){
        //
        //
        //     for(var i in  geoJson.features[0].properties.aggregations){
        //         var iMax,iMin = 0;
        //
        //         iMax = oServices._.max(geoJson.features, function (feature) {
        //             if(feature.properties&&feature.properties.aggregations &&feature.properties.aggregations[i]){
        //                 return parseInt(feature.properties.aggregations[i])
        //             }
        //
        //         });
        //
        //         // iMin = oServices._.min(geoJson.features, function (feature) {
        //         //     return parseInt(feature.properties.aggregations[i])
        //         // });
        //
        //         var iQuotient = (iMax.properties.aggregations[i]/iLengthPalette);
        //
        //         var iColorQuotient =(255/iLengthPalette)
        //
        //         for(var j = 0; j<= iLengthPalette;j++){
        //
        //             if(!oLegend.hasOwnProperty(i)){
        //                 oLegend[i]= angular.copy(oLegendSubLevel)
        //             }
        //
        //             oLegend[i].legend[0].palette.push({
        //                 label:i ,
        //                 color:rgbToHex(255,255-(iColorQuotient*j).toFixed(0),255-(iColorQuotient*j).toFixed(0)),
        //                 sign:"",
        //                 value:(iQuotient*j),
        //                 mu:"",
        //                 dec:0,
        //                 minValue:iQuotient*j,
        //                 maxValue:iQuotient*(j+1),
        //             })
        //
        //         }
        //
        //         //console.log(oLegend[i])
        //
        //     }
        // }

    }

    function paletteFeature(aPalette, iFeatureValue) {

        var color = "#46ff15";

        // aPalette.forEach(function (item) {
        //
        //     var iValue = parseInt(iFeatureValue);
        //
        //     if(iValue>=item.minValue&&iValue<=item.maxValue){
        //         color =  item.color;
        //     }
        // });

        return color;
    }

    function onClick(e) {
        console.log(alert(e.target.feature.properties.aggregations[sKey]))
    }

    function onMouseOver(e) {
    }

    function onMouseOut(e) {
    }








    oManager.load = function (onFinish) {



        serverUrl = layerObj.server.url+'/wms';


        oServices.apiService.getExt(layerObj.server.url+'/www/'+layerObj.dataid.split('_')[0]+'.json', function (data) {

            console.log(data)

            oManager.setProps(data);

            sDataId = layerObj.dataid.split('_')[0];//model

            sDateRun = Object.keys(data)[0];//first run

            sVariable = layerObj.dataid.split('_')[1];//base variable

            sLevel = layerObj.dataid.split('_')[2];//baseLevel

            sInstant =data[sDateRun][sVariable][sLevel][0]; //first istant to visualize


            sIdLayer = layerObj.dataid.split('_')[0]+'-'+sDateRun+'-'+sVariable+'-'+sLevel+'-'+sInstant;


            oManager.setMapLayer(oServices.mapService.addWmsLayer(serverUrl, sIdLayer))

            //load each 500 ms tre image and populate an obj of wmsLayer
            oManager.preload();

            if (onFinish)onFinish(undefined, 1500)

        })




    }


    //check if already loaded
    function checkNested(obj /*, level1, level2, ... levelN*/) {
        var args = Array.prototype.slice.call(arguments, 1);

        for (var i = 0; i < args.length; i++) {
            if (!obj || !obj.hasOwnProperty(args[i])) {
                return false;
            }
            obj = obj[args[i]];
        }
        return true;
    }

    //lazy load wms
    oManager.preload = function(){
        
        lazyLoadPromise = oServices.$interval(function () {

            iIndexOfInstant = oManager.props()[sDateRun][sVariable][sLevel].indexOf(sInstant);

            if( iIndexOfInstant > iOldIndexOfInstant){

                for(var i = 1; i<4; i++){//buffer 3 immagini

                    var sInstantToPreload = oManager.props()[sDateRun][sVariable][sLevel][iIndexOfInstant+i];

                    if(!checkNested(oLayers, sDateRun,sVariable,sLevel,sInstantToPreload)){

                        if (!oLayers[sDateRun])oLayers[sDateRun] = {};
                        if (!oLayers[sDateRun][sVariable])oLayers[sDateRun][sVariable] = {};
                        if (!oLayers[sDateRun][sVariable][sLevel])oLayers[sDateRun][sVariable][sLevel] = {};

                        let sIdLayerToPreload= sDataId+'-'+sDateRun+'-'+sVariable+'-'+sLevel+'-'+sInstantToPreload

                        oLayers[sDateRun][sVariable][sLevel][sInstantToPreload] = oServices.mapService.addWmsLayer(serverUrl, sDataId+'-'+sDateRun+'-'+sVariable+'-'+sLevel+'-'+sInstantToPreload).setOpacity(0)
                        oServices.$log.info("Preload Layer:"+sIdLayerToPreload)
                    }

                }
            }{
                iOldIndexOfInstant = iIndexOfInstant;
            }


        },500);
    }

    //old update no lazy load
    oManager.updateO = function (bFade) {

        sIdLayer = sDataId+'-'+sDateRun+'-'+sVariable+'-'+sLevel+'-'+sInstant;

        oServices.$log.log(sIdLayer)




        if(bFade){

            var oldMapLayer = oManager.mapLayer();

            oServices.$timeout(function () {

                oServices.mapService.removeLayer(oldMapLayer);

            },500)

        }else{

            if(oManager.mapLayer())oServices.mapService.removeLayer(oManager.mapLayer());
        }

        oManager.setMapLayer(oServices.mapService.addWmsLayer(serverUrl, 'CIMA_WRF:'+sIdLayer))
    }

    //new update function with lazy load
    oManager.update = function (bFade) {

        sIdLayer = sDataId+'-'+sDateRun+'-'+sVariable+'-'+sLevel+'-'+sInstant;

        // oServices.$log.log(sIdLayer);
        console.log(sIdLayer)

        if(checkNested(oLayers,sDateRun,sVariable,sLevel,sInstant)){

            var oldMapLayer = oManager.mapLayer();

            iOpacity = oldMapLayer.options.opacity;

            oldMapLayer.setOpacity(0)

            oManager.setMapLayer(oLayers[sDateRun][sVariable][sLevel][sInstant])

            oManager.mapLayer().setOpacity(iOpacity)

            oServices.$log.log("opacity: "+iOpacity)

            oServices.$log.log("sInstant: "+sInstant)

            oServices.$log.log("lazyLoadMethod")

        }else{

            if(bFade){

                var oldMapLayer = oManager.mapLayer();

                oServices.$timeout(function () {

                    oServices.mapService.removeLayer(oldMapLayer);

                },500)

            }else{

                if(oManager.mapLayer())oServices.mapService.removeLayer(oManager.mapLayer());
            }

            oManager.setMapLayer(oServices.mapService.addWmsLayer(serverUrl, sIdLayer))

            oManager.mapLayer().setOpacity(iOpacity)

            oServices.$log.log(iOpacity)

            oServices.$log.log("standardMethod")
        }


    }


    oManager.dateLine = function(){

        return moment(sInstant,'YYYYMMDDHHmm').format("YYYY-MM-DD HH:mm");

        //return sInstant
    }

    oManager.showProps = function (onFinish) {


        var modalInstance = oServices.$uibModal.open({
            animation: true,
            component: 'layerProperties',
            resolve: {
                oManager: function () {
                    return oManager;
                },

            }
        });

        modalInstance.result.then(function (obj) {

            oServices.$log.log("update prop")
            console.table(obj)

            sDataId = obj.dataId.split("_")[0];
            sDateRun = obj.dateRun;
            sVariable = obj.variable;
            sLevel = obj.level;
            sInstant = obj.instant;



            oManager.update()

        }, function () {
            $log.info('modal-component dismissed at: ' + new Date());
        });


    };


    oManager.setOpacity = function (value) {
        oManager.mapLayer.setOpacity(value)
    }

    oManager.getOpacity = function () {
        return oManager.mapLayer().options.opacity
    }


    oManager.canMovie = function () {
        return true
    }

    oManager.draggable = function(){
        return true
    }

    oManager.canPlay = function () {

        if (playPromise!= null){
            return false
        }

        return (oManager.props()[Object.keys(oManager.props())[0]][sVariable][sLevel].length >1)
    }

    oManager.canForward = function () {
        return (oManager.props()[Object.keys(oManager.props())[0]][sVariable][sLevel].length >1)
    }
    oManager.goForward = function (bFade) {

        var sInstantIndex = oManager.props()[sDateRun][sVariable][sLevel].indexOf(sInstant)+1

        sInstant = oManager.props()[sDateRun][sVariable][sLevel][sInstantIndex];

        oManager.update(bFade)
    }

    oManager.canBackward = function () {
        return (oManager.props()[sDateRun][sVariable][sLevel].length >1)
    }

    oManager.goBackward = function () {

        var sInstantIndex = oManager.props()[sDateRun][sVariable][sLevel].indexOf(sInstant)-1

        sInstant = oManager.props()[sDateRun][sVariable][sLevel][sInstantIndex]

        oManager.update()
    }

    oManager.infoAvaialability=function(){
        return{
            reverse:false
        }
    }

    oManager.play = function () {

        if (playPromise == null){
            playPromise = oServices.$interval(function () {

                if(oServices.$rootScope.pendingRequests == 0){

                    oManager.goForward(true);

                }
            },1000);
        }else {
            oServices.$interval.cancel(playPromise);
            playPromise =null;
        }

    }

    oManager.stop = function () {

        oServices.$interval.cancel(playPromise)
        playPromise = null;

    }

    oManager.remove = function (layer, onFinish) {



        if(playPromise) {
            oServices.$interval.cancel(playPromise);
        }

        oServices.mapService.removeLayer(oManager.mapLayer());

        for (var layer in oLayers){
            oServices.mapService.removeLayer(oLayers[layer])
            oServices.$log.log("remove:",layer)
        }

        oServices.$interval.cancel(lazyLoadPromise)


        if (onFinish) onFinish()
    }
    oManager.legend = function () {


        var legend = {
            type: "ADVANCED",
            legend: [{
                type: "CUSTOM",
                title: oManager.name(),
                palette: []
            }]
        };


        if(oManager.layerObj().hasOwnProperty("customprops")){
            if (oManager.customprops().hasOwnProperty("customLegend")){

                legend.legend[0].palette = oManager.customprops().customLegend[sVariable];//default o la variabile che definisci mi permette di gestire multi legenda

                console.log(legend)

                return legend
            }



        }


        // return{
        //     dynPalette:{},
        //     type: layerObj.type.code.toUpperCase(),
        //     url: oManager.mapLayer()._url,
        //     layers:oManager.mapLayer().wmsParams.layers,
        // }
    }
    
    oManager.getDownloadUrl = function () {
        
    }


    return oManager

}
