/**
 * Created by Dario Rubado on 19/06/15.
 */

function layerManager_spi_spei_stations(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService) {

    var ICON_SIZE = 14;
    var visible=true;

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;

    var dateRun = null;

    let additionalLayers = [];

    var markerFloodOption = {
        radius : menuService.markerFloodOptions.radius,
        weight : menuService.markerFloodOptions.weight,
        color : menuService.markerFloodOptions.color,
        opacity : menuService.markerFloodOptions.opacity,
        fillOpacity: menuService.markerFloodOptions.fillOpacity
    };
    //add External Layer

    function AddBackgroundLayer() {
        var layerToAdd = 49;
        apiService.get("settings/layers/?id="+layerToAdd,function(obj){

            var AlreadyLoaded = false;
            var dataId =obj.objects[0].dataid;

            var o = mapService.getLayerTest();
            if (o.draggable){
                o.draggable.forEach(function (data) {
                    if (data.wmsParams.layers == dataId){
                        AlreadyLoaded = true;
                    }
                })
            }

            //
            function buildLayerManager(layer) {
                var mangerName = 'layerManager_' + layer['type'].code;
                var manager = window[mangerName](layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService);

                return manager;
            }
            if (AlreadyLoaded){
                console.log("Gia Caritcato")
            }else{
                var PlusManager = buildLayerManager(obj.objects[0]);
                PlusManager.load(function () {
                    mapService.setlayerManager(PlusManager.mapLayer(), PlusManager);
                    mapService.oLayerList.addLayer(PlusManager)
                });
            }

        });
    }

    //add External Layer End



    function stationInfoMouseOver(s){

        if(infoPopUP){
            console.log(s.target.feature.properties);
            infoPopUP.mouseOver('FloodProofsProbabilistic',mapLayer._leaflet_id, s.target.feature.properties , iconService.section_gauge_observation_Icon(s.target.feature))
        }
    }

    function stationInfoMouseOut(){
        if(infoPopUP){
            infoPopUP.mouseOut('FloodProofsProbabilistic',mapLayer._leaflet_id)
        }
    }




    function stationClickListener(s) {

        if(s.target.feature.properties.maxvalue <=-9998){
            alert($translate.instant('UNAVAILABLE_DATA'));
            return; //da scommentare dopo test
        }

        if(s.target.feature.properties.maxvalue == '-7777'||s.target.feature.properties.maxvalue == '-6666'||s.target.feature.properties.maxvalue == '-5555'){
            alert($translate.instant(s.target.feature.properties.maxvalue));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/hydrogram_chart_form.html',
            controller: 'hydrogramChartController',
            size: 'lg',
            keyboard: false,
            resolve: {
                sectionData: function () {
                    return {
                        section : s.target.feature.properties,
                        prop : layerData.prop,
                        serverId: layerObj.server.id
                    };
                }
            }
        })
    }

    function updateFeatureStyle () {

        for(var layerId in mapLayer._layers){
           mapLayer._layers[layerId].setIcon(iconService.section_gauge_observation_Icon(mapLayer._layers[layerId].feature, markerFloodOption.opacity))
        }

    }

    function getTriangleIcon(size, fillColor, borderColor, opacity, direction) {

        var icon = new L.Icon.Canvas({iconSize: new L.Point(size, size)});


        switch (direction) {
            case -1:
                icon.draw = function (ctx, w, h) {
                    ctx.globalAlpha = opacity;
                    ctx.beginPath();
                    ctx.moveTo(w / 2, h);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(0, 0);
                    ctx.fillStyle = fillColor;
                    ctx.fill();

                    ctx.beginPath();
                    ctx.moveTo(w / 2, h);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(0, 0);
                    ctx.lineTo(w / 2, h);
                    ctx.strokeStyle = (borderColor ? borderColor : "black");
                    ctx.lineWidth =(borderColor != "black")? 3 : 1;
                    ctx.stroke();
                };
                break;
            case 0:

                icon.draw = function (ctx, w, h) {
                    ctx.globalAlpha = opacity;
                    ctx.beginPath();
                    ctx.moveTo(0, 0);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.fillStyle = fillColor;
                    ctx.fill();

                    ctx.beginPath();
                    ctx.moveTo(0, 0);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.lineTo(0, 0);
                    ctx.strokeStyle = (borderColor ? borderColor : "black");
                    ctx.lineWidth =(borderColor != "black")? 3 : 1;
                    ctx.stroke();
                };
                break;
            case 1:
                icon.draw = function (ctx, w, h) {
                    ctx.globalAlpha = opacity;
                    ctx.beginPath();
                    ctx.moveTo(w / 2, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.lineTo(w / 2, 0);
                    ctx.fillStyle = fillColor;
                    ctx.fill();

                    ctx.beginPath();
                    ctx.moveTo(w / 2, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.lineTo(w / 2, 0);
                    ctx.strokeStyle = (borderColor ? borderColor : "black");
                    ctx.lineWidth =(borderColor != "black")? 3 : 1;
                    ctx.stroke();
                };
                break;
            default:
                icon.draw = function (ctx, w, h) {
                    ctx.globalAlpha = opacity;
                    ctx.beginPath();
                    ctx.moveTo(w / 2, 0);
                    ctx.lineTo(w, h);
                    ctx.lineTo(0, h);
                    ctx.moveTo(w / 2, 0);
                    ctx.fillStyle = "gray";
                    ctx.fill();

                    ctx.beginPath();
                    ctx.moveTo(w / 2, h);
                    ctx.lineTo(w, 0);
                    ctx.lineTo(0, 0);
                    ctx.lineTo(w / 2, h);
                    ctx.strokeStyle = "black";
                    ctx.lineWidth =3
                    ctx.stroke();
                };
        }



        return icon;
    }




    const oManager = {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        setMapLayer: function (l) {
          mapLayer = l;
        },

        // setProps:function (props) {
        //
        // },

        load: function(onFinish) {


            serieService.getLayerData(layer, function (ld) {

                layerData = ld;

                floodproofsService.layer(layer.server.id,layerData.layer.dataid, function (data) {

                    theGeoJson = data;


                    var dateToCheck = null;

                    if(theGeoJson.features){
                        theGeoJson.features.forEach(function (feature) {

                            if(feature.properties.run != ""){
                                dateToCheck = moment(feature.properties.run,"YYYYMMDDHHmm");

                                if(dateRun!= null){
                                    if(dateToCheck.isAfter(dateRun)){
                                        dateRun = dateToCheck;
                                    }
                                }else{
                                    dateRun = dateToCheck;
                                }
                            }
                        })
                    }


                    mapLayer = mapService.addGeoJsonLayer(theGeoJson, layer['descr'], {

                        pointToLayer: function(feature, latlng) {

                            if(layer.dataid.indexOf("dams")>-1)feature.properties.sWarningInfoMeasureUnit = "m<sup>3</sup>";


                            return L.marker(latlng, {icon:iconService.spi_spei_stations_Icon(feature)});
                        }

                    }, stationClickListener, stationInfoMouseOver, stationInfoMouseOut);

                    // if(layer.dataid != "comunege.idro.probabilisticlami")  AddBackgroundLayer();
                    oManager.loadAdditionalLayer();

                    if (onFinish) onFinish()

                }, function(data) {

                    alert('Error loading layer: ' + data.error_message);

                })

            });

        },

        layerTooltip: function(){

            var manager = this;



            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : manager.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : manager.typeDescr()
                }

            ];
            return tooltipObj;
        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        setOpacity : function(value){

            if (value){
                markerFloodOption.opacity = value;
                markerFloodOption.fillOpacity = value;
                updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return markerFloodOption.opacity
        },


        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            oManager.removeAdditionalLayer();
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.name
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        typeDescr: function () {
            return "SECTION_LAMI_PROBABILISTIC"
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi;
        },

        getWarningInfo:function () {
          return infoPopUP;
        },

        setVisible: function (b) {
            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        },

        dateLine:function(){
            //return layerObj.descr;
            if(dateRun)return dateRun.format('DD/MM/YYYY HH:mm')
        },
        customprops : function(){

            try {
                if(layerObj.hasOwnProperty("customprops")){
                    return JSON.parse(layerObj.customprops);
                }
            }catch (e) {
                console.log(e);
            }
        },

        removeAdditionalLayer : () => {
            additionalLayers.map(mapLayer => {
                mapService.getMap().removeLayer(mapLayer);
            });
        },

        loadAdditionalLayer : () => {

            try {
                if (oManager.customprops() && oManager.customprops().hasOwnProperty('additional_layers')) {

                    oManager.customprops().additional_layers.layerlist.map((layer)=>{
                        additionalLayers.push(mapService.addWmsLayer(layer.url, layer.dataid));
                    });
                }
            }catch (e) {
                console.log(e);
            }
        },

        thirdLine:function(){
            return true


        },

        getVariable :function(){

            return ""

        },

        getAggregation :function(){

            return""


        }
    }

    return oManager;

}

