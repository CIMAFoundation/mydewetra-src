function layerManager_dynamic_external_wmst_efas_generic(layerObj) {

    var isVisible = true;

    var iOpacity = 1;

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices();

    var isLoaded = false;

    var timer = null;

    var to;

    var modalInstance;


    var WMSParams = {
        service: 'WMS',
        request: 'GetMap',
        version: '1.3.0',
        //version: '1.1.1',
        layers: layerObj.dataid,
        styles: '',
        time:'',
        // srsName:'EPSG:3857',
        // crsName:'EPSG:3857',
        format: 'image/png',
        transparent: true
    };

    function nearestMid() {

        let dateTo = moment.utc(oServices.menuService.getDateTo())

        let now = moment.utc();

        let to;

        if(dateTo.diff(now,'days') < -1 ){
            to = moment.utc(oServices.menuService.getDateTo());
        }else {
            to = moment.utc(oServices.menuService.getDateTo()).subtract('hours', 8);
        }

        let iNearestH = (to.hour() > 12)?12:0;

        let nearestMid = to.hour(iNearestH).minute(0);

        return nearestMid;
    }


    function update(onFinish, selectedDate){

        if (oManager.mapLayer()){
            iOpacity = oManager.mapLayer().options.opacity
        }

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        if(moment.isMoment(selectedDate)){

            to = selectedDate
            WMSParams.time = selectedDate.utc().format('YYYY-MM-DDTHH:mm:ss');

        }else {

            to = nearestMid();

            WMSParams.time = to.utc().format('YYYY-MM-DDTHH:mm:ss');

        }



        isLoaded = false;

        if(timer) clearInterval(timer); //se timer è stato lanciato lo killo

        oManager.setMapLayer(oServices.mapService.addSingleTileWmsLayer(layerObj.server.url , WMSParams));

        timer = oManager.oServices().$timeout(function(){

            if(isLoaded == true){
                console.log("EFAS DATA LOADED");
            }else {
                alert(oManager.oServices().$translate.instant("UNAVAILABLE_DATA") + " check properties "+ oManager.name());
            }
        },8000);

        oManager.mapLayer().setOpacity(iOpacity)

        oManager.mapLayer().on('load', function () {
            isLoaded = true;
            console.log("load");
        });

        if (onFinish) onFinish()
    }

    oManager.load = function(onFinish) {

        update(onFinish)

    };

    oManager.showProps = function(onFinish) {

        var layerPropModal = oServices.$uibModal.open({
            template: `
                    <div class="popup">
                        <div class="head" >
                            <div class="flex-container">
                                <!--Title-->
                                <div class="brand flex-item">
                                    <i class=""fa app-static animated bounceIn delay-002" ></i>
                                    <p class="animated fadeInDown delay-001" translate>
                                        <span translate>{{layer.name}}</span> <span translate>properties</span>
                                    </p>
                                </div>
                    
                                <div class="flex-item">
                                    <a class="close" ng-click="closePopup()" href>
                                        <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    
                        <hr>
         
                        <div class="modal-body">

                            <hr>
                    
                    
                            <div class="row" >
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <label class="hidden-xs">
                                        <h4 translate>CHOOSE_INTERVAL</h4>
                                    </label>
                                </div>
                    
                                <div class="col-xs-8 col-sm-6 col-md-6 col-lg-6">
                                    <select class="form-control"  ng-model="config.selectedDate" ng-options="date.format('DD/MM/YYYY HH:00') for date in config.dates" ng-change="selectTypeAttr()">     
                                    </select>
                                </div>
                            </div>             
                            <hr>
                    <div class="row">      
                                <div class="flex-item animated zoomInUp delay-003 ">
                                    <a href="" class="btn btn-warning pull-right" ng-click="update()" tooltip="reload layer" ng-show="config.selectedDate">
                                        <i class="fa fa-refresh "></i>
                                        {{ 'LAYER_REFRESH' | translate }}
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>`,
            controller: ['$scope', 'layerService', 'mapService', 'menuService', '$uibModalInstance', 'params', '$interval', '$translate', '_',function ($scope, layerService, mapService, menuService, $uibModalInstance, params, $interval, $translate, _) {

                $scope.config= {
                    selectedDate: {},
                    dates: []
                }

                let nearestMid = params.nearestMid();

                let dateFromMoment = moment.utc(oServices.menuService.getDateFrom());

                $scope.config.dates.push(angular.copy(nearestMid))

                while (nearestMid.isAfter(dateFromMoment) == true){
                    nearestMid.subtract('hours',12);

                    if(nearestMid.isAfter(dateFromMoment) == true){
                        $scope.config.dates.push(angular.copy(nearestMid));
                    }

                }

                if($scope.config.dates.length == 1){
                    $scope.config.selectedDate = $scope.config.dates[0];
                }else{
                    let ind = $scope.config.dates.findIndex(function (date, index,arr){
                        return (date.format('YYYYMMDDHH') == params.to.format('YYYYMMDDHH'));

                    });

                    $scope.config.selectedDate = $scope.config.dates[ind];

                }


                console.log($scope.config.selectedDate);
                console.log($scope.config.dates);

                console.log(params.to);



                $scope.selectTypeAttr = function(d){
                    console.log(d);
                }

                $scope.update = function () {
                    $uibModalInstance.close($scope.config.selectedDate);
                };

                $scope.closePopup = function () {
                    $uibModalInstance.dismiss()
                };



            }],
            size: "lg",
            resolve: {
                params: function() {
                    return {
                    layer: layerObj,
                    nearestMid: nearestMid,
                    to: to
                    }
                }
            }
        });

        layerPropModal.result.then(function (selectedDate) {
            update(onFinish, selectedDate)
        }, function () {
            console.log("CANCEL")
        });
    }

    oManager.draggable = function(){
        return true
    }

    oManager.onDateChange = function(onFinish){
        update(onFinish)

    };

    oManager.parseInfo = function (layer, data, url) {

        if(oManager.layerObj().hasOwnProperty("customprops")){
            if (oManager.customprops().hasOwnProperty("queryable")){
                if(oManager.customprops().queryable == false) {
                    alert(oServices.$translate.instant('NOT_QUERYABLE') + " "  + oManager.name())
                    return
                };
            }
        }


        //
        //if(modalInstance != null) return
        modalInstance = oServices.$uibModal.open({
            animation: true,
            component: 'efasReportingPointInfo',
            size:'lg',
            resolve:{
                oManager:function () {
                    return oManager
                },
                dateRun: function() {
                   return  to
                }
            }
        });

        modalInstance.result.then(function (obj) {

            console.log('modal-component dismissed at: ' + new Date());
            modalInstance = null;

        }, function () {
            console.log('modal-component dismissed at: ' + new Date());
            modalInstance = null;
        });



    }

    oManager.thirdLine= function () {
        return true
    }



    oManager.getVariable = function () {

        let string = ''

        if(oManager.layerObj().hasOwnProperty("customprops")){
            if (oManager.customprops().hasOwnProperty("variableString")){
                if(oManager.customprops().variableString != '') {
                    string = oServices.$translate.instant(oManager.customprops().variableString);
                };
            }
        }

        return string + to.format(": DD/MM/YYYY HH:mm");
    }

    oManager.getAggregation = function () {
        return "";
    }



    delete oManager.getDownloadUrl;




    oManager.legend = function () {

        var legend = {
            type: "ADVANCED",
            legend: [{
                type: "CUSTOM",
                title: oManager.name(),
                palette: [],
                descr:""
            }]
        };


        if(oManager.layerObj().hasOwnProperty("customprops")){
            if (oManager.customprops().hasOwnProperty("customLegend")){
                legend.legend[0].palette = oManager.customprops().customLegend['default'].palette;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].img = oManager.customprops().customLegend['default'].img;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].descr = oManager.customprops().customLegend['default'].descr;//default o la variabile che definisci mi permette di gestire multi legenda

                return legend
            }
        }
    }

    return oManager
}



