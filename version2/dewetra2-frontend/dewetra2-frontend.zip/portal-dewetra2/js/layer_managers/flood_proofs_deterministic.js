/**
 * Created by Dario Rubado on 14/07/16.
 */
function layerManager_flood_proofs_deterministic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService) {

    var manager = layerManager_flood_proofs_probabilistic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService);

    
    return manager;
}