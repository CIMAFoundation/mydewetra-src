/**
 * Created by Dario Rubado on 27/02/19.
 */

function layerManager_default(layerObj) {

    var oLayerSettingsFromDjango = layerObj;

    var layerDataFromSerieService;

    var oProps;

    var oItems;

    var sLayerId;

    var oMapLayer;

    var sDownloadUrl;

    var sServerUrl;

    var bCanMovie= false;

    var bHaveAudio = false;

    var oWarningInfo = null;

    var iOpacity = 1;

    let oTheGeoJson = null;

    var isVisible = true;

    let playPromise;

    let additionalLayers = [];

    let infoAvaialability = {
        index: 0,
        length: 1,
        reverse: null// per i radar il primo layer disponibile è l'ultimo in ordine di tempo, al contrario dei modelli
    };




    var aServices = [
        "mapService",
        "layerService",
        "serieService",
        "menuService",
        "$uibModal",
        "acEvent",
        "audioService",
        "tagService",
        "apiService",
        "_",
        "sentinelService",
        "$interval",
        "floodproofsService",
        "$translate",
        "iconService",
        "$timeout",
        "$rootScope",
        "thresholdService",
        "floodCatService",
        "$log",
        "damService",

    ];

    var oServices = {};

    var element = document.querySelector('.ng-scope');

    aServices.forEach(function (serviceName) {
        oServices[serviceName] = angular.element(element).injector().get(serviceName);
    });

    // if (oLayerSettingsFromDjango.hasOwnProperty("customprops")) {
    //     try {
    //         oLayerSettingsFromDjango.customprops = JSON.parse(oLayerSettingsFromDjango.customprops);
    //
    //     }catch (e) {
    //         console.log(e);
    //     }
    //
    // }


    var debug =oServices.menuService.debug;


    const oManager = {

        oServices:function(){
            return oServices;
        },

        setTheGeoJson: (oGeoJson) => {
                oTheGeoJson = oGeoJson;
        },

        getTheGeoJson: () => {
            return oTheGeoJson;
        },

        layerObj:function () {
            return oLayerSettingsFromDjango;
        },
        setLayerObj: function(obj) {
            oLayerSettingsFromDjango = obj;
        },

        setLayerData :function (ld) {
            layerDataFromSerieService = ld;
        },

        getLayerData :function () {
            return layerDataFromSerieService;
        },

        setMapLayer:function(l){
            oMapLayer = l
        },

        mapLayer:function(){
            return oMapLayer
        },

        getMetaData : function () {
            return layerObj.metadata
        },

        props: function() {
            return oProps;
        },

        setProps: function(p) {
            oProps = p;
        },

        item: function() {
            return oItems;
        },

        setItem: function(i) {
            oItems = i;
        },

        getLayerId: function () {
            return sLayerId ;
        },

        setLayerId: function (LId) {
            sLayerId =  LId;
        },

        setDownloadUrl :function (DUrl) {
            sDownloadUrl = DUrl;
        },

        setServerUrl : function (url) {
            sServerUrl = url;
        },

        getServerUrl : function () {
            return sServerUrl;
        },

        /**
         * layer info parser
         */
        parseInfo: function () {
            return undefined
        },

        dateRun:function () {

        },

        dateRef:function () {

        },
        dateRefFormatted:function () {

        },
        loadWithProperties(onFinish, layerObj, props, item ,dateFrom, dateTo, opacity){

        },
        load:function (onFinish) {

            if (onFinish)onFinish()
        },
        name:function () {
            return oLayerSettingsFromDjango.name
        },
        dataid:function () {
            return oLayerSettingsFromDjango.dataid
        },
        remove:function (layer,onFinish) {
            try {
                oServices.mapService.removeLayer(layer);
            }catch (e) {
                console.log(e);
            }

            try {
                additionalLayers.map(mapLayer =>{
                    oServices.mapService.getMap().removeLayer(mapLayer);
                })
            }catch (e) {
                console.log(e);
            }

            if (onFinish)onFinish()
        },
        descr:function () {
            return oLayerSettingsFromDjango.descr
        },
        typeDescr:function () {
            return oLayerSettingsFromDjango.type.descr
        },
        draggable:function () {
            return false

        },
        haveInfo:function () {
            return false
        },
        haveAudio:function () {
            return bHaveAudio;
        },

        legend:function () {

        },
        haveDynamicPalette:function () {
            return false
        },
        canMovie:function () {
            return bCanMovie
        },
        setCanMovie:function (b) {
            bCanMovie = b;
        },
        layerOpacity:function () {
            return iOpacity;
        },
        setLayerOpacity:function (opacity) {
            iOpacity = opacity
        },

        isVisible :function () {
            return isVisible;
        },

        setIsVisible: function (boolean ) {
            isVisible = boolean;
        },



        customprops : function(){

            try {
                if(oManager.layerObj().hasOwnProperty("customprops")){
                    return JSON.parse(oManager.layerObj().customprops);
                }
            }catch (e) {
                //console.log(e);
            }
        },

        removeAdditionalLayer : () =>{
            additionalLayers.map(mapLayer => {
                oServices.mapService.getMap().removeLayer(mapLayer);
            });
        },

        loadAdditionalLayer : () => {

            try {
                if (oManager.customprops() && oManager.customprops().hasOwnProperty('additional_layers')) {

                    oManager.customprops().additional_layers.layerlist.map((layer)=>{
                        additionalLayers.push(oServices.mapService.addWmsLayer(layer.url, layer.dataid));
                    });
                }
            }catch (e) {
                console.log(e);
            }
        },

        infoAvaialability:function () {
            return infoAvaialability;
        },
        canBeSendToSit:function () {

        },
        sendToSit:function () {

        },
        onDateChange:function (callback) {
            this.load(callback)

        },
        layerTooltip:function () {

        },
        refreshable:function () {

        },
        refreshProperty:function () {

        },
        lastRefresh:function () {

        },
        setLastRefresh:function () {

        },
        setRefresh:function () {

        },
        refresh:function () {

        },

        showProps: function (onFinish) {
            var _this = this;
            var layerPropModal = oServices.$uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties.html',
                controller: "layerPropertiesController",
                size: "lg",
                resolve: {
                    params: function() {
                        return {
                            layer: _this.mapLayer()
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {

                var bScrambling = false

                _this.update(obj.props, obj.data, onFinish, bScrambling)
            }, function () {
                if(debug)console.log("CANCEL")
            });
        },
        getDownloadUrl:function () {

        },
        update:function () {

        },
        initializeMoveOptions: function () {

        },


        goForward: function () {

        },

        goBackward: function () {

        },

        play: function () {

        },

        setPlayPromise: function (promise) {
            playPromise = promise;
        },

        getPlayPromise: function () {
            return playPromise;
        },

        getVariable :function(){

        },
        getAggregation:function () {

        },
        thirdLine:function () {

        },
        canPlay:function () {

        },

        goToLast: function () {

        },

        update:function () {

        },

        setNewLayer: function () {

        },

        buildDynamicPaletteData: function () {

        },
        setWarningInfo:function (wi) {
            oWarningInfo = wi;
        },

        getWarningInfo:function () {
             return oWarningInfo;
        }

    }

    return oManager;

}
