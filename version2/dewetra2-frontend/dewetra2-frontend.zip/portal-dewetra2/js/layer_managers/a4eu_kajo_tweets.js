/**
 * Created by Mirko D'Andrea on 14/09/2017
 */

var KAJOTweetsService = function(){
    var service = this;
    var $http = angular.injector(["ng"]).get("$http");
    var $window = angular.injector(["ng"]).get("$window");
    var $httpParamSerializer = angular.injector(["ng"]).get("$httpParamSerializer");

    var server = 'http://173.249.20.52';
    var proxy_url = window.app.url.dewapiURL+'utils/proxy/';
    var API_KEY = 'efc0e944e0f37d883d79832a8d270a47e61a2718';
    var USERNAME = 'spark';

    this.appendNext = function(data, next){
        return $http
            .get(server + next, {timeout: 120*1000})
            .then(function(res){
                if(_.isEmpty(data)){
                    _.extend(data, res.data);
                } else {
                    data.features = data.features.concat(res.data.features);
                }
                if(res.data.meta.next){
                    return service.appendNext(data, res.data.meta.next);
                }else{
                    return data;
                }
            })

    }

    this.getTweets = function(from, to){
        var params = {
            'api_key': API_KEY,
            'username': USERNAME,
            'created_at':  from.toISOString() + '|' + to.toISOString(),
            'limit': 5000,
            'size': 5000,
            'flood_probability__gte': 0.9
        };
        var serPars = $httpParamSerializer(params);
        var data = {};
        var url = '/api/tweet/?' + serPars;
        return  service
            .appendNext(data, url)
            .catch(function(err){
                console.error(err);
            });;
    };

    this.getEmbed = function(tweet_id){
        return $http
        .post(
            proxy_url,
            {
                method: "get",
                url: "https://publish.twitter.com/oembed?url=https://twitter.com/cimafoundation/status/" + tweet_id
            }
        )
        .then(function(res){
            var data = res.data;
            if (data.status !== 200){
                throw new Error(data.content)
            }
            return data.content;
        });
    }

    return this;
};


function layerManager_a4eu_kajo_tweets(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService) {
    var manager = layerManager_static(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService);

    var $KAJOTweetsService = KAJOTweetsService();

    var visible=true;
    var layer = layerObj;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;

    var props = {};

    function hoverGroup(s){
        var texts = s.layer
            .getAllChildMarkers()
            .map(function(l){
                return l.feature.properties.text.substr(0, 60) + '...'
            });

        var html =
            '<div style="width:100%; max-height: 300px; overflow-y:scroll;">' +
                '<blockquote>' + texts.join('</blockquote><blockquote>') + '</blockquote>' +
            '</div>'

        L.popup({
            offset: [0, -40]
        })
        .setLatLng(s.latlng)
        .setContent(html)
        .openOn(mapService.getMap());

    }

    function tweetPopUp(s) {
        console.log('click');
        var properties = s.target.feature.properties;

        $KAJOTweetsService
        .getEmbed(properties.id)
        .then(function(tweet){
            var html =
                '<div>' +
                    tweet.html +
                    '<hr>' +
                    '<small> Probability: ' +
                        '<b>' + (100 * properties.flood_probability).toFixed(2) + '%' + '</b>' +
                    '</small>' +
                    '<small> Country: ' +
                        '<b>' + properties.country + '</b>' +
                    '</small>' +
                    '<small> Language: ' +
                        '<b>' + properties.lang + '</b>' +
                    '</small>' +
                '</div>'

            var popup = L.popup({
                    offset: [0, -40]
                })
                .setLatLng(s.latlng)
                .setContent(html)
                .openOn(mapService.getMap());
                // carica lo script per generare le preview e le immagini
                $.getScript("https://platform.twitter.com/widgets.js");
        });
    }

    function update(newProps, onFinish){
    }

    manager.isRemoved = false;
    manager.isLoading = false;
    manager.layerObj = function () {
        if(manager.isLoading){
            var loading_layer = angular.copy(layer);
            loading_layer.icon = layer.icon + '   faa-flash faa-slow animated';
            return loading_layer;
        }else{
            return layer
        }
    };

    manager.mapLayer = function () {
        if(mapLayer) {
            return mapLayer
        }else{
            // fix per fare apparire il layer disabilitato quando fa il loading
            return {
                options: {
                    opacity: 0
                }
            }
        }

    };

    manager.setMapLayer = function (l) {
        mapLayer = l;
    };

    manager.load = function(onFinish){

        var from = menuService.getDateFrom();
        var to = menuService.getDateTo();

        manager.isLoading = true;
        visible = false;
        $KAJOTweetsService
            .getTweets(from, to)
            .then(function(data){
                manager.isLoading = false;
                if(manager.isRemoved){return;}

                visible = true;
                theGeoJson = data;
                if (mapLayer) mapService.removeLayer(mapLayer);

                mapLayer = mapService
                    .addGeoJsonLayerCluster(
                        theGeoJson.features, layerObj.name, {},
                        tweetPopUp, tweetPopUp, null, null, hoverGroup);

            }).catch(function(err){
                console.error(err);
            }).finally(function(){
                manager.isLoading = false;
            });
        onFinish && onFinish();
    };

    manager.onDateChange = function(onFinish){
        if (mapLayer) mapService.removeLayer(mapLayer);
        this.load(onFinish)
    };

    manager.remove = function (layer, onFinish) {
        manager.isRemoved = true;
        mapService.removeLayer(layer);
        if (onFinish) {
            onFinish()
        }
    };

    manager.name = function() {
        return layer.descr;
    };

    manager.descr = function () {
        return $translate.instant('');
    };

    manager.draggable = function () {
        return false;
    };

    manager.typeDescr = function () {
        var s = 'tweets';
        return s;
    };

    manager.showProps = function (onFinish) {

    };

    manager.legend = function () {
        return {}
    };

    manager.setVisible = function (b) {
        visible = b;
        if (!b) mapLayer.clearLayers();
        else mapLayer.addData(theGeoJson);
    };

    manager.isVisible = function(){
        return visible;
    };


    return manager;
}
