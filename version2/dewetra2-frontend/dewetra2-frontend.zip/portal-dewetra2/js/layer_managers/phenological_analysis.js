/**
 * Created by Dario Rubado on 13/07/17.
 */

function layerManager_phenological_analysis(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope) {

    var ICON_SIZE = 14;
    var visible=true;

    var layer = layerObj;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;
    var indicatorsMax = {};

    var rasorFeatureStyle = {
        weight : 1,
        opacity : 1,
        fillOpacity: 0.6
    }

    var palette = iconService.phenologicalPalette;
    var legend = {
        fase_fenologica:{
            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: "fase_fenologica",
                palette:[{
                    label:"FASE_FENOLOGICA_1",
                    color:"#FF0000",
                },{
                    label:"FASE_FENOLOGICA_2",
                    color:"#70f5ff",
                },{
                    label:"FASE_FENOLOGICA_3",
                    color:"#00ff00",
                },{
                    label:"FASE_FENOLOGICA_4",
                    color:"#ffff00",
                },{
                    label:"FASE_FENOLOGICA_5",
                    color:"#FFaf00",
                }]
            }]
        },
        fase_igsi:{
            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: "fase_igsi",
                palette:[
                    {color: "#3f1e00", value: 0,  label: '0.00'},
                    {color: "#412404", value: 4,  label: '0.40'},
                    {color: "#422a07", value: 8,  label: '0.80'},
                    {color: "#43300a", value: 12, label: '0.12'},
                    {color: "#44360c", value: 16, label: '0.16'},
                    {color: "#453c0e", value: 20, label: '0.20'},
                    {color: "#464210", value: 24, label: '0.24'},
                    {color: "#464812", value: 28, label: '0.28'},
                    {color: "#474e14", value: 32, label: '0.32'},
                    {color: "#475317", value: 36, label: '0.36'},
                    {color: "#475919", value: 40, label: '0.40'},
                    {color: "#465f1b", value: 44, label: '0.44'},
                    {color: "#46651d", value: 48, label: '0.48'},
                    {color: "#456b1f", value: 52, label: '0.52'},
                    {color: "#437222", value: 56, label: '0.56'},
                    {color: "#427824", value: 60, label: '0.60'},
                    {color: "#407e26", value: 64, label: '0.64'},
                    {color: "#3d8429", value: 68, label: '0.68'},
                    {color: "#3a8a2b", value: 72, label: '0.72'},
                    {color: "#36902d", value: 76, label: '0.76'},
                    {color: "#319730", value: 80, label: '0.80'},
                    {color: "#2b9d32", value: 84, label: '0.84'},
                    {color: "#23a335", value: 88, label: '0.88'},
                    {color: "#18aa37", value: 92, label: '0.92'},
                    {color: "#00b03a", value: 96, label: '0.96'},
                    {color: "#00c030", value: 100, label: '1.00'}
                ]
            }]
        },
        fase_gsi:{
            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: "fase_igsi",
                palette:[
                    {color: "#3f1e00", value: 0,  label: '0.00'},
                    {color: "#412404", value: 4,  label: '0.40'},
                    {color: "#422a07", value: 8,  label: '0.80'},
                    {color: "#43300a", value: 12, label: '0.12'},
                    {color: "#44360c", value: 16, label: '0.16'},
                    {color: "#453c0e", value: 20, label: '0.20'},
                    {color: "#464210", value: 24, label: '0.24'},
                    {color: "#464812", value: 28, label: '0.28'},
                    {color: "#474e14", value: 32, label: '0.32'},
                    {color: "#475317", value: 36, label: '0.36'},
                    {color: "#475919", value: 40, label: '0.40'},
                    {color: "#465f1b", value: 44, label: '0.44'},
                    {color: "#46651d", value: 48, label: '0.48'},
                    {color: "#456b1f", value: 52, label: '0.52'},
                    {color: "#437222", value: 56, label: '0.56'},
                    {color: "#427824", value: 60, label: '0.60'},
                    {color: "#407e26", value: 64, label: '0.64'},
                    {color: "#3d8429", value: 68, label: '0.68'},
                    {color: "#3a8a2b", value: 72, label: '0.72'},
                    {color: "#36902d", value: 76, label: '0.76'},
                    {color: "#319730", value: 80, label: '0.80'},
                    {color: "#2b9d32", value: 84, label: '0.84'},
                    {color: "#23a335", value: 88, label: '0.88'},
                    {color: "#18aa37", value: 92, label: '0.92'},
                    {color: "#00b03a", value: 96, label: '0.96'},
                    {color: "#00c030", value: 100, label: '1.00'}
                ]
            }]
        },
        fase_erbacee:{
            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: "fase_erbacee",
                palette:[{
                    label:"FASE_ERBACEE_1",
                    color:"#FF0000",
                },{
                    label:"FASE_ERBACEE_2",
                    color:"#AFFCE0",
                },{
                    label:"FASE_ERBACEE_3",
                    color:"#00FF00",
                },{
                    label:"FASE_ERBACEE_4",
                    color:"#FFFF00",
                }]
            }]
        },
        "cfr_anno;fase_erbacee":{
            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: "cfr_anno",
                palette:[{
                    label:"CFR_ANNO_-1",
                    color:"#B8B8B8",
                },{
                    label:"CFR_ANNO_0",
                    color:"#00FF00",
                },{
                    label:"CFR_ANNO_1",
                    color:"#FF0000",
                },{
                    label:"CFR_ANNO_2",
                    color:"#FFFF00",
                }]
            }]
        },
        "cfr_anno;fase_fenologica":{
            type:"ADVANCED",
            legend:[{
                type:"CUSTOM",
                title: "cfr_anno",
                palette:[{
                    label:"CFR_ANNO_-1",
                    color:"#B8B8B8",
                },{
                    label:"CFR_ANNO_0",
                    color:"#00FF00",
                },{
                    label:"CFR_ANNO_1",
                    color:"#FF0000",
                },{
                    label:"CFR_ANNO_2",
                    color:"#FFFF00",
                }]
            }]
        },

    };

    // var dateNow = moment(new Date());
    var dateNow = moment(menuService.getDateTo());

    var year = parseInt(dateNow.format('YYYY'))-1;

    var latest_year = 2006;


    var props = {

        analysis: {
            name:"ANALYSIS",
            descr:"ANALYSIS_DESCR",
            date :false,
            type:true,
            typeSelected:{
                name: "fase_gsi",
                descr:"fase_gsi",
                value:"fase_gsi"
            },
            typeAttr:[
                {
                    name: "fase_igsi",
                    descr:"fase_igsi",
                    value:"fase_igsi"
                },
                {
                    name: "fase_gsi",
                    descr:"fase_gsi",
                    value:"fase_gsi"
                },
                {
                    name: "phenological_phase_name",
                    descr:"phenological_phase_descr",
                    value:"fase_fenologica"
                },{
                    name: "erbacee_phase_name",
                    descr:"erbacee_phase_descr",
                    value:"fase_erbacee"
                },{
                    name:"cfr_year_name_erbacee",
                    descr:"cfr_year_descr_erbacee",
                    value:"cfr_anno;fase_erbacee"
                },{
                    name:"cfr_year_name_phenological",
                    descr:"cfr_year_descr_phenological",
                    value:"cfr_anno;fase_fenologica"
                }
            ]
        },



        year:{
            name:"REFERENCE_YEAR",
            descr:"REFERENCE_YEAR_DESCR",
            date :false,
            type:true,
            typeSelected:{
                name:"REFERENCE_YEAR",
                descr:"REFERENCE_YEAR_descr",
                value:year
            },
            typeAttr:[]
        }
    }



    // for(var i =parseInt(latest_year);i <= year; i++){
    //
    //     props.year.typeAttr.push({
    //         name:"REFERENCE_"+i.toString()+"_YEAR",
    //         descr:i.toString(),
    //         value:i
    //     });
    // }
    //
    // props.year.typeSelected = props.year.typeAttr[props.year.typeAttr.length-1];

    
    function populateYearProp() {
        props.year.typeSelected = [];
        props.year.typeAttr = [];

        dateNow = moment(menuService.getDateTo());

        year = parseInt(dateNow.format('YYYY'))-1;

        for(var i =parseInt(latest_year);i <= year; i++){

            props.year.typeAttr.push({
                name:"REFERENCE_"+i.toString()+"_YEAR",
                descr:i.toString(),
                value:i
            });
        }

        props.year.typeSelected = props.year.typeAttr[props.year.typeAttr.length-1];

    }

    populateYearProp();


    function stationClickListener(s) {

        if (s.target.feature.properties.value <=-9998) {
            alert($translate.instant('UNAVAILABLE_DATA'));
            return;
        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/phenol_chart_form.html',
            controller: 'phenolAnalysisChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                stationInfo: function () {

                    return {

                        id_centr : s.target.feature.properties.id_centr,
                        series_id : layerObj.dataid,
                        server_id: layerObj.server.id

                    };

                }

            }
        })

    }



    function InfoMouseOver(s) {
        if (infoPopUP) {
            var type = props.analysis.typeSelected.value;
            var year = props.year.typeSelected.value;
            var val = s.target.feature.properties.value;
            var palette = legend[type].legend[0].palette;

            var feat = angular.copy(s.target.feature);
            var offset = (type == "cfr_anno;fase_fenologica" || type == "cfr_anno;fase_erbacee")?1:-1;

            feat.properties.year = (type == "cfr_anno;fase_fenologica" || type == "cfr_anno;fase_erbacee")?year:'-';
            feat.properties.analysis = $translate.instant(type);
            if ( type == 'fase_igsi' || type == 'fase_gsi'){
                feat.properties.value = val/100;
            }else{
                feat.properties.value = $translate.instant(palette[val+offset].label);
            }

            infoPopUP.mouseOver('phenological_analysis', mapLayer._leaflet_id, feat);
        }
    }

    function InfoMouseOut() {
        if (infoPopUP) {
            infoPopUP.mouseOut('phenological_analysis', mapLayer._leaflet_id)
        }
    }



    function update(newProps, onFinish){

        var update = false;

        for (var name in props){
            if (update == false)
            if (props[name].typeSelected.value != newProps[name].typeSelected.value){
                update = true;
            }
        }

        if (update){
            props = newProps;
            var manager = mapService.oLayerList.getManagerByMapLayer(mapLayer)
            manager.load(onFinish);
        }else{
            props = newProps;

            if(onFinish)onFinish();
        }
    }


    // function palettePheno(data) {
    //
    //     data.features.forEach(function (feature) {
    //
    //     });
    //
    //
    //     return data;
    // }


    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        setMapLayer: function (l) {
            mapLayer = l;
        },

        // setProps:function (props) {
        //
        // },

        load: function(onFinish) {

            var obj = {
                "id": layerObj.dataid,
                "from": menuService.getDateFromUTCSecond(),
                "to": menuService.getDateToUTCSecond(),
                "props": {
                    "analysis": props.analysis.typeSelected.value,
                    "year": props.year.typeSelected.value
                }
            };

            if(!props) props= obj.props;

            console.log(obj);

            apiService.post("ddsserie/"+layer.server.id+"/seriefeatures/",obj,function (data) {

                    theGeoJson = data;

                    if (mapLayer) mapService.removeLayer(mapLayer);

                    mapLayer = mapService.addGeoJsonLayer(theGeoJson.features, layerObj.name, {

                        pointToLayer: function(feature, latlng) {
                            const type = props.analysis.typeSelected.value;
                            const value = feature.properties.value;
                            if(type == 'fase_gsi' || type == 'fase_igsi'){
                                const _palette = palette[type];
                                let v = _palette[0];
                                for(let i=0; i<_palette.length-1; i++){
                                    if(value <= _palette[i+1].value){
                                        break
                                    }
                                    v = _palette[i+1];
                                }
                                feature.properties.fillColor = v.color;
                            }else{
                                try {
                                    feature.properties.fillColor = palette[type][value]
                                }catch (err){
                                    console.log(err)
                                }
                            }
                            return L.circleMarker(latlng, iconService.phenological_analysis_Icon(feature));
                        }
                    }, stationClickListener, InfoMouseOver, InfoMouseOut);
                    if (onFinish) onFinish()
            },function () {
                alert("error loading stations!")
            })

        },

        layerTooltip: function(){

            var manager = this;

            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : manager.name()
                }
            ];

            for(var key in props){
                tooltipObj.push({
                    label:props[key].typeSelected.descr,
                    value:props[key].typeSelected.name,
                })
            }

            return tooltipObj;
        },

        onDateChange:function(onFinish){

            if (mapLayer) mapService.removeLayer(mapLayer);
            this.load(onFinish)

        },

        setOpacity : function(value){

            if (value){
                rasorFeatureStyle.opacity = value;
                rasorFeatureStyle.fillOpacity = value;
                //updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return rasorFeatureStyle.opacity
        },


        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.descr
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        typeDescr: function () {
            return layerObj.name;
        },

        setWarningInfo: function (wi) {
            infoPopUP = wi;
        },

        getWarningInfo:function () {
            return infoPopUP;
        },

        showProps : function (onFinish) {


            populateYearProp();

            var layerPropModal = $uibModal.open({

                templateUrl: 'apps/dewetra2/views/layer_properties_rasor_damage.html',
                controller: ['$scope', '$uibModalInstance', 'params' ,function ($scope, $uibModalInstance, params){

                    $scope.data = angular.copy(params.props);

                    //remove possibility of year choosing when is no cfr_anno //TODO

                    var year = $scope.data.year;

                    $scope.$watch('data[\'analysis\'].typeSelected.name', function () {

                        if (($scope.data['analysis'].typeSelected.value != "cfr_anno;fase_erbacee")&&($scope.data['analysis'].typeSelected.value != "cfr_anno;fase_fenologica")){

                            delete $scope.data.year;
                            console.log($scope.data);

                        }else $scope.data.year = year;

                    })


                    $scope.update = function () {
                        if(!$scope.data.hasOwnProperty('year'))$scope.data.year = year
                        $uibModalInstance.close($scope.data);
                    };
                    $scope.closePopup = function () {
                        $uibModalInstance.dismiss()
                    }
                }],
                size: "lg",

                resolve: {
                    params: function() {
                        return {
                            layer: mapLayer,
                            props:props
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj, onFinish)

            }, function () {
                console.log("CANCEL")
            });
        },

        geoServerPalette: palette,

        legend:function () {
            return legend[props.analysis.typeSelected.value]
            /*
            return{
                type:layerObj.type.code.toUpperCase()+"_"+props.analysis.typeSelected.value.toUpperCase(),
                palette:palette[props.analysis.typeSelected.value]
            }
            */
        },

        setVisible: function (b) {
            visible = b;
            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

        },

        isVisible:function(){
            return visible;
        },

        dateLine:function(){
            return "";
        },

        thirdLine:function(){
            return true


        },

        getVariable :function(){

            return props.analysis.typeSelected.name.toUpperCase().trim().replace(/ /g,"_")

        },

        getAggregation :function(){

            if(props.analysis.typeSelected.name.indexOf("cfr_")>-1){
                return props.year.typeSelected.name.toUpperCase().trim().replace(/ /g,"_")
            }else return""


        },

    }

}
