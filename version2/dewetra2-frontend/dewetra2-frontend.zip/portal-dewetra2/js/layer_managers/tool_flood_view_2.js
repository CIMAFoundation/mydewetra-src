

function tool_floodWaveView2(obj, $uibModal, callback) {

    let modalInstance = null;

    loadFloodWaveViewComponentChart = function(){

        if(modalInstance) return

        modalInstance = $uibModal.open({
            animation: true,
            size: 'lg',
            component: 'floodWaveView2',
            resolve: {
                model: function () {
                    return {
                        toolData:"obj",

                    };
                },
                onClose:function () {
                    if(callback)callback()
                }


            }
        });

        modalInstance.result.then(function (obj) {

            console.log('modal-component dismissed at: ' + new Date());

        }, function () {
            console.log('modal-component dismissed at: ' + new Date());
        });
    }



    loadFloodWaveViewComponentChart()
}
