/**
 * Created by Dario on 19/05/21.
 */


/**
 * Developed for floodobservatory's layers never used because cors on loading external html
 * like Efas is a modal loaded on info layer that execute the query
 */
(function () {

    dewetraApp.component('floodobservatoryModal', {
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        template: `<div class="popup">
                        <div class="head" >
                            <div class="flex-container">
                                <!--Title-->
                                <div class="brand flex-item">
                                    <i class="fa app-static animated bounceIn delay-002" ></i>
                                    <p class="animated fadeInDown delay-001" translate>
                                          <span>title</span>
                                    </p>
                                </div>
                    
                                <div class="flex-item">
                                    <a class="close" ng-click="$ctrl.close()" href>
                                        <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    
                        <hr>
       
                        <div  class="modal-body" ng-if="$ctrl.data && $ctrl.data.features">
                            <div class="row">
                                <div class="flex-container">
                                    <div class="flex-item" ng-repeat="(key, value) in $ctrl.data.features" ng-click="$ctrl.setUrl($ctrl.data.features[key].properties.url)">{{$ctrl.data.features[key].properties.rivername}}</div>
                                </div>
                            </div>
                            
                            <div class="row" style="width: 100%; margin: auto">
                               <div ng-include="$ctrl.url" style="width: 100%;height: 100%"></div>
<!--                               //<iframe ng-src="$ctrl.url"></iframe>-->
                            </div>
                        </div>
                    </div>`,

        controller: ['$uibModal', 'acUserResource', '$rootScope', '_', '$window', 'mapService', 'apiService', 'menuService', 'damService', '$sce', function ($uibModal, acUserResource, $rootScope, _, $window, mapService, apiService, menuService, damService, $sce) {


            const $ctrl = this;

            $ctrl.setUrl = (url) => {
                $ctrl.url =$sce.trustAsResourceUrl(apiService.proxyGenericUrl(url.replace('http', 'https')));
            }


            $ctrl.buildWmsParams = function(){

                const dewetraMap = mapService.getMap();

                const layer =  $ctrl.resolve.oManager.mapLayer();

                const size = dewetraMap.getSize();

                const bbox = dewetraMap.getBounds().toBBoxString();

                var infoMarker = mapService.getInfoMarker();

                const point = dewetraMap.latLngToContainerPoint(infoMarker.getLatLng(), dewetraMap.getZoom());


                var params = {
                    request: 'GetFeatureInfo',
                    service: 'WMS',
                    srs: 'EPSG:4326',
                    styles: layer.wmsParams.styles,
                    version: layer.wmsParams.version,
                    format: layer.wmsParams.format,
                    bbox: bbox,
                    height: size.y,
                    width: size.x,
                    layers: $ctrl.resolve.oManager.layerObj().dataid,
                    query_layers: $ctrl.resolve.oManager.layerObj().dataid,
                    info_format: 'application/json',
                    feature_count: 50,
                    TOLERANCE:20
                };
                params['x'] = Math.round(point.x);
                params['y'] = Math.round(point.y);


                return params

            };


            $ctrl.buildUrl = function(){
                var params = $ctrl.buildWmsParams();
                //
                return  $ctrl.resolve.oManager.layerObj().server.url+ L.Util.getParamString(params, $ctrl.resolve.oManager.layerObj().server.url, true);
            };

            $ctrl.loadFeature = function(){
                //

                apiService.getExt($ctrl.buildUrl(),function (data) {
                    $ctrl.data =data;
                    console.log($ctrl.data);
                },function () {
                    alert("Error on request")
                })

                //$ctrl.data = [[{"tab_name": "Reporting Points", "type": "layer_tab"}, {"data": {"header": ["Station ID", "Country", "CoA Status", "Basin", "River", "Station Name", "LISFLOOD Drainage Area [km2]", "PointID", "Lat [Deg]", "Long [Deg]", "Lisflood X [Meters]", "Lisflood Y [Meters]"], "rows": [[2961, "France", "YES", "Garonne", "Truyere", "La Truyere a Sainte-Genevieve-sur-Argence [Sarrans]", "2575", "SH001350", "44.84312", "2.74635", "3742500", "2437500"]]}, "title": "Point Information", "type": "table", "id_render": "point_sec_01"}, {"data": {"header": [" ", "Forecast Date", "Probability value", "Probability tendency", "Peak forecasted in:"], "rows": [["Point Forecast", "2019-12-16 00:00", "0", "FallingArrow.gif", "2019-12-16 00:00 + 7 days"]]}, "title": "Point Forecast", "type": "table", "id_render": "forecast_sec_01"}, {"layer": "RepPoints", "title": "Discharge Hydrograph (ECMWF-ENS)", "data": {"url": "https://www.efas.eu/mapserver/images/forecasts/2019/201912/2019121600/SH001350_Dis_EUE2019121600.png", "width": 800, "height": 380}, "order": 1, "id_render": "forecast_image_01", "type": "image", "id": "SH001350"}, {"layer": "RepPoints", "title": "Return Period Hydrograph (ECMWF-ENS)", "data": {"url": "https://www.efas.eu/mapserver/images/forecasts/2019/201912/2019121600/SH001350_RP_EUE2019121600.png", "width": 800, "height": 380}, "order": 3, "id_render": "forecast_image_01", "type": "image", "id": "SH001350"}, {"layer": "RepPoints", "title": "Upstream Rainfall (ECMWF-ENS)", "data": {"url": "https://www.efas.eu/mapserver/images/forecasts/2019/201912/2019121600/SH001350_Rups_EUE2019121600.png", "width": 800, "height": 320}, "order": 5, "id_render": "forecast_image_01", "type": "image", "id": "SH001350"}, {"layer": "RepPoints", "title": "Upstream Snowmelt (ECMWF-ENS)", "data": {"url": "https://www.efas.eu/mapserver/images/forecasts/2019/201912/2019121600/SH001350_Smups_EUE2019121600.png", "width": 800, "height": 320}, "order": 7, "id_render": "forecast_image_01", "type": "image", "id": "SH001350"}, {"layer": "RepPoints", "title": "Average Temperature (ECMWF-ENS)", "data": {"url": "https://www.efas.eu/mapserver/images/forecasts/2019/201912/2019121600/SH001350_Ta_EUE2019121600.png", "width": 800, "height": 320}, "order": 9, "id_render": "forecast_image_01", "type": "image", "id": "SH001350"}, {"layer": "RepPoints", "title": "Discharge Hydrograph (COSMO-LEPS)", "data": {"url": "https://www.efas.eu/mapserver/images/forecasts/2019/201912/2019121600/SH001350_Dis_COS2019121600.png", "width": 800, "height": 380}, "order": 2, "id_render": "forecast_image_01", "type": "image", "id": "SH001350"}, {"layer": "RepPoints", "title": "Return Period Hydrograph (COSMO-LEPS)", "data": {"url": "https://www.efas.eu/mapserver/images/forecasts/2019/201912/2019121600/SH001350_RP_COS2019121600.png", "width": 800, "height": 380}, "order": 4, "id_render": "forecast_image_01", "type": "image", "id": "SH001350"}, {"layer": "RepPoints", "title": "Upstream Rainfall (COSMO-LEPS)", "data": {"url": "https://www.efas.eu/mapserver/images/forecasts/2019/201912/2019121600/SH001350_Rups_COS2019121600.png", "width": 800, "height": 320}, "order": 6, "id_render": "forecast_image_01", "type": "image", "id": "SH001350"}, {"layer": "RepPoints", "title": "Upstream Snowmelt (COSMO-LEPS)", "data": {"url": "https://www.efas.eu/mapserver/images/forecasts/2019/201912/2019121600/SH001350_Smups_COS2019121600.png", "width": 800, "height": 320}, "order": 8, "id_render": "forecast_image_01", "type": "image", "id": "SH001350"}, {"layer": "RepPoints", "title": "Average Temperature (COSMO-LEPS)", "data": {"url": "https://www.efas.eu/mapserver/images/forecasts/2019/201912/2019121600/SH001350_Ta_COS2019121600.png", "width": 800, "height": 320}, "order": 10, "id_render": "forecast_image_01", "type": "image", "id": "SH001350"}, {"data": {"header": ["Forecast Type", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"], "rows": [[{"background_color": "None", "value": "DWD-DET"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "\u2193"}, {"background_color": "ffffff", "value": "\u2193"}, {"background_color": "ffffff", "value": "\u2193"}, {"background_color": "ffffff", "value": "\u2191"}, {"background_color": "ffff00", "value": "\u2191"}, {"background_color": "ffff00", "value": "*"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "ECMWF-DET"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "\u2193"}, {"background_color": "ffffff", "value": "\u2193"}, {"background_color": "ffffff", "value": "\u2193"}, {"background_color": "ffffff", "value": "\u2191"}, {"background_color": "ffff00", "value": "\u2191"}, {"background_color": "ffff00", "value": "\u2191"}, {"background_color": "ffff00", "value": "*"}, {"background_color": "ffff00", "value": "\u2193"}, {"background_color": "33ff00", "value": "\u2193"}], [{"background_color": "None", "value": "ECMWF-ENS > 5 yr RP"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}], [{"background_color": "None", "value": "ECMWF-ENS > 20 yr RP"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}], [{"background_color": "None", "value": "COSMO-LEPS > 5 yr RP"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "ffbcbd", "value": "10"}, {"background_color": "ffbcbd", "value": "20"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "COSMO-LEPS > 20 yr RP"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}]]}, "title": "Forecasts Overview", "type": "square", "columns": 11, "id_render": "Forecasts Overview"}, {"data": {"header": ["Forecast Day", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"], "rows": [[{"background_color": "None", "value": "2019-12-13 00:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-13 12:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-16 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}]]}, "title": "DWD-DET", "type": "square", "columns": 14, "id_render": "DWD-DET"}, {"data": {"header": ["Forecast Day", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"], "rows": [[{"background_color": "None", "value": "2019-12-13 00:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-13 12:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-16 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "ffff00", "value": "None"}, {"background_color": "33ff00", "value": "None"}]]}, "title": "ECMWF-DET", "type": "square", "columns": 14, "id_render": "ECMWF-DET"}, {"data": {"header": ["Forecast Day", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"], "rows": [[{"background_color": "None", "value": "2019-12-13 00:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "2"}, {"background_color": "ffbcbd", "value": "2"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-13 12:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "4"}, {"background_color": "ffbcbd", "value": "2"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "2"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "2"}, {"background_color": "ffbcbd", "value": "2"}, {"background_color": "ffbcbd", "value": "2"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "2"}, {"background_color": "ffbcbd", "value": "2"}, {"background_color": "ffbcbd", "value": "6"}, {"background_color": "ffbcbd", "value": "2"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-16 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}]]}, "title": "ECMWF-ENS > 5 yr RP", "type": "square", "columns": 14, "id_render": "ECMWF-ENS > 5 yr RP"}, {"data": {"header": ["Forecast Day", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"], "rows": [[{"background_color": "None", "value": "2019-12-13 00:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-13 12:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-16 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}]]}, "title": "ECMWF-ENS > 20 yr RP", "type": "square", "columns": 14, "id_render": "ECMWF-ENS > 20 yr RP"}, {"data": {"header": ["Forecast Day", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"], "rows": [[{"background_color": "None", "value": "2019-12-13 00:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-13 12:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "ffbcbd", "value": "10"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-16 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffbcbd", "value": "5"}, {"background_color": "ffbcbd", "value": "10"}, {"background_color": "ffbcbd", "value": "20"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}]]}, "title": "COSMO-LEPS > 5 yr RP", "type": "square", "columns": 14, "id_render": "COSMO-LEPS > 5 yr RP"}, {"data": {"header": ["Forecast Day", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"], "rows": [[{"background_color": "None", "value": "2019-12-13 00:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-13 12:00"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-14 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-15 12:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}], [{"background_color": "None", "value": "2019-12-16 00:00"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "ffffff", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}, {"background_color": "666666", "value": "None"}]]}, "title": "COSMO-LEPS > 20 yr RP", "type": "square", "columns": 14, "id_render": "COSMO-LEPS > 20 yr RP"}, {"lss5_area": -9999, "RiverName": "Truyere", "BasinName": "Garonne", "lss1_area": -9999, "ff_t_gt20": "", "UpsRain_DW": 63.95, "INST_ID": "1,23,63,104,85", "Model_Rel": "SH001350", "notification_type": "flood", "PointType": "Static", "lss2_area": -9999, "ff_t_gt2": "", "lss4_area": -9999, "pointFileN": "SH001350_2019121600.xml", "ff_t_gt5": "", "rep_lt": 3, "MOU_Status": "YES", "alevareps": 0, "Lat": 44.84312, "ProbGT72h": 5.0, "type": "Notification", "prob": "", "RegionName": "", "alhvareps": 0, "Prob48-72h": 0.0, "Country": "France", "TotalProb": 0.0, "NoOfEPS": "0|20", "nuts1": "", "nuts0": "", "nuts3": "", "UpsRain_EU": 58.14, "ad2_name": "", "CNTR_CODE": "FR", "PointID": 1350, "UpsArea": 2575.0, "nuts2": "", "ff_mx_t": "", "lss3_area": -9999, "population": "32", "Forecast_date": "2019121600", "PeakTime": 7, "Long": 2.74635, "alecos": 0, "alhcos": 20, "nuts_id": "FR622", "HighPerc": -0.3, "Prob_24h": 0.0, "Nuts_name": "Aveyron", "Tendency": 1}]];
            };



            $ctrl.$onInit = () => {
                $ctrl.loadFeature()
            }

            $ctrl.$onChanges = () => {

            }

            $ctrl.closePopup = () => {
                $ctrl.resolve.close();
            }



        }]
    });




})();


/**
 * Developed for floodobservatory's layers never used because cors on loading external html
 * @param layerObj
 * @returns {{play: function(), getTheGeoJson: function(): null, dateRef: function(), haveDynamicPalette: function(): boolean, setNewLayer: function(), legend: function(), setDownloadUrl: function(*): void, getWarningInfo: function(): null, setServerUrl: function(*): void, typeDescr: function(): *, dateRefFormatted: function(), layerObj: function(): *, setLastRefresh: function(), item: function(): *, setIsVisible: function(*): void, setWarningInfo: function(*): void, setProps: function(*): void, infoAvaialability: function(): {length: number, index: number, reverse: null}, layerTooltip: function(), isVisible: function(): boolean, haveAudio: function(): boolean, getVariable: function(), props: function(): *, descr: function(): *, setLayerId: function(*): void, getDownloadUrl: function(), canMovie: function(): boolean, name: function(): *, parseInfo: function(): undefined, goForward: function(), getMetaData: function(): *, layerOpacity: function(): number, goToLast: function(), sendToSit: function(), buildDynamicPaletteData: function(), update: function(), showProps: function(*): void, setCanMovie: function(*): void, mapLayer: function(): *, loadWithProperties(*, *, *, *, *, *, *), remove: function(*, *): void, getAggregation: function(), canBeSendToSit: function(), load: function(*): void, draggable: function(): boolean, loadAdditionalLayer: function(): void, getLayerData: function(): *, removeAdditionalLayer: function(): void, oServices: function(): {}, initializeMoveOptions: function(), getLayerId: function(): *, setLayerData: function(*): void, setItem: function(*): void, getServerUrl: function(): *, refreshable: function(), refreshProperty: function(), thirdLine: function(), setLayerObj: function(*): void, customprops: function(): (*|undefined), lastRefresh: function(), goBackward: function(), canPlay: function(), onDateChange: function(*): void, setRefresh: function(), setTheGeoJson: function(*): void, refresh: function(), haveInfo: function(): boolean, dataid: function(): Document.pubForm.dataid|*, dateRun: function(), setMapLayer: function(*): void, setLayerOpacity: function(*): void}}
 */
function layerManager_static_properties_floodobservatory(layerObj) {
    var oManager = layerManager_static_properties(layerObj);

    const oServices = oManager.oServices();



    oManager.getFeatureInfoQueryParams = () => {

        const dewetraMap = oServices.mapService.getMap();

        const layer = oManager.mapLayer();

        //const size = dewetraMap.getSize();

        //const bbox = [ dewetraMap.getBounds().getWest(),dewetraMap.getBounds().getSouth(), dewetraMap.getBounds().getEast(), dewetraMap.getBounds().getNorth()].join(',');

        const infoMarker = oServices.mapService.getInfoMarker();

        //const point = dewetraMap.latLngToContainerPoint(infoMarker, dewetraMap.getZoom());

        //evt.latlng.getBounds().toBBoxString();

        //Lat = Y Long = X
        //const point = dewetraMap.latLngToContainerPoint(infoMarker.getLatLng(), dewetraMap.getZoom());

        //minlat minlon maxlat max lon

        // get bounds from marker
        // infoMarker.getLatLng().toBounds(5000).toBBoxString()

        //pixel dimension founded bye heart size
        //var pixDim = 40075016.686 * Math.abs(Math.cos(dewetraMap.getCenter().lat / 180 * Math.PI)) / Math.pow(2, dewetraMap.getZoom()+8);
    //pixel dimension founded bye heart size end

        //pixel dimension 2
        // Get the y,x dimensions of the map
        // var y = dewetraMap.getSize().y,
        //     x = dewetraMap.getSize().x;
// calculate the distance the one side of the map to the other using the haversine formula
//         var maxMeters = dewetraMap.containerPointToLatLng([0, y]).distanceTo( dewetraMap.containerPointToLatLng([x,y]));
// calculate how many meters each pixel represents
//         var pixDim = maxMeters/x ;

        // var ptClickLatLng = L.latLng([coordX, coordY]);
        // var ptClickLatLng = infoMarker.getLatLng();
        // var clickPoint = dewetraMap.project(ptClickLatLng, dewetraMap.mapZoom);
        // var pixHalh = pixDim / 2;
        // var latLng1 = dewetraMap.unproject(L.point([clickPoint.x - pixHalh, clickPoint.y + pixHalh]), dewetraMap.mapZoom);
        // var latLng2 = dewetraMap.unproject(L.point([clickPoint.x + pixHalh, clickPoint.y - pixHalh]),dewetraMap. mapZoom);
        // var bbox = L.latLngBounds(latLng1, latLng2);

        //pixel dimension 2 -- END

        //test
        var bbox = infoMarker.getLatLng().toBounds(1000000);
        //console.log(infoMarker);

        var params = {
            request: 'GetFeatureInfo',
            service: 'WMS',
            srs: 'EPSG:4326',
            styles: layer.wmsParams.styles,
            version: layer.wmsParams.version,
            format: layer.wmsParams.format,
            //bbox: infoMarker.getLatLng().toBBoxString(),
            bbox: bbox.toBBoxString(),
            height: 110,
            width: 110,
            layers: oManager.layerObj().dataid,
            query_layers: oManager.layerObj().dataid,
            info_format: 'application/json',
            feature_count: 50,
            x: 50,
            y: 50,
            //buffer: 5
        };

        return params

    }


    return oManager

}


/**
 * Simple static layer
 * example of custom properties on django server
 * {
 * 	"static_properties": {
 * 		"properties": [{
 * 				"descr": "name: South America",
 * 				"dataid": "dataid",
 * 				"url": "https wms server url"
 * 			},
 * 			{
 * 				"descr": "name: Europe",
 * 				"dataid": "dataid_EU:dataid_EU",
 * 				"url": "https wms server url"
 * 			},
 * 			{
 * 				"descr": "name: Asia",
 * 				"dataid": "dataid_AS",
 * 				"url": "https wms server url"
 * 			},
 * 			{
 * 				"descr": "name: Africa",
 * 				"dataid": "dataid_AF",
 * 				"url": "https wms server url"
 * 			},
 * 			{
 * 				"descr": "name: Australia",
 * 				"dataid": "dataid_AU",
 * 				"url": "https wms server url"
 * 			}
 * 		]
 * 	}
 * }
 * @param layerObj
 * @returns {{play: function(), getTheGeoJson: function(): null, dateRef: function(), haveDynamicPalette: function(): boolean, setNewLayer: function(), legend: function(), setDownloadUrl: function(*): void, getWarningInfo: function(): null, setServerUrl: function(*): void, typeDescr: function(): *, dateRefFormatted: function(), layerObj: function(): *, setLastRefresh: function(), item: function(): *, setIsVisible: function(*): void, setWarningInfo: function(*): void, setProps: function(*): void, infoAvaialability: function(): {length: number, index: number, reverse: null}, layerTooltip: function(), isVisible: function(): boolean, haveAudio: function(): boolean, getVariable: function(), props: function(): *, descr: function(): *, setLayerId: function(*): void, getDownloadUrl: function(), canMovie: function(): boolean, name: function(): *, parseInfo: function(): undefined, goForward: function(), getMetaData: function(): *, layerOpacity: function(): number, goToLast: function(), sendToSit: function(), buildDynamicPaletteData: function(), update: function(), showProps: function(*): void, setCanMovie: function(*): void, mapLayer: function(): *, loadWithProperties(*, *, *, *, *, *, *), remove: function(*, *): void, getAggregation: function(), canBeSendToSit: function(), load: function(*): void, draggable: function(): boolean, loadAdditionalLayer: function(): void, getLayerData: function(): *, removeAdditionalLayer: function(): void, oServices: function(): {}, initializeMoveOptions: function(), getLayerId: function(): *, setLayerData: function(*): void, setItem: function(*): void, getServerUrl: function(): *, refreshable: function(), refreshProperty: function(), thirdLine: function(), setLayerObj: function(*): void, customprops: function(): (*|undefined), lastRefresh: function(), goBackward: function(), canPlay: function(), onDateChange: function(*): void, setRefresh: function(), setTheGeoJson: function(*): void, refresh: function(), haveInfo: function(): boolean, dataid: function(): Document.pubForm.dataid|*, dateRun: function(), setMapLayer: function(*): void, setLayerOpacity: function(*): void}}
 */
function layerManager_static_properties(layerObj) {

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices();

    var iOpacity = 1;

    var dataid;

    var downloadUrl;

    var debug = true;

    var aLayers = [];

    var baseLayerObject = layerObj;

    oManager.draggable = function () {
        return true;
    }

    oManager.type = () => {
        return "STATIC_PROPERTIES";
    }
    oManager.typeDescr = () => {
        return "STATIC_PROPERTIES";
    }

    oManager.haveAudio = () => {
        return false;
    }
    oManager.legend = () => {
        return {
            dynPalette: {},
            // FROmGEOSERVER
            type: 'STATIC',
            // type: oManager.layerObj().type.code.toUpperCase(),
            url: oManager.mapLayer()._url,
            layers: oManager.mapLayer().wmsParams.layers,
        }
    }

    oManager.canMovie = () => {
        return false;
    }

    oManager.refreshable = () => {
        return false;
    }

    oManager.layerTooltip = () => {
        let tooltipObj = [
            {
                label: "LAYER_NAME",
                value: oManager.name()
            },
            {
                label: "LAYER_DESCRIPTION",
                value: oManager.descr()
            },
            {
                label: "LAYER_TYPE",
                value: oManager.type()
            }

        ];
        return tooltipObj;
    }

    oManager.remove = (layer, onFinish) => {
        oServices.mapService.removeLayer(layer);
        if (onFinish) onFinish()
    }

    oManager.dateLine = (layer, onFinish) => {
        return oManager.layerObj().descr;
    }

    oManager.delayLine = (layer, onFinish) => {
        return "";
    }

    oManager.customprops = (layer, onFinish) => {
        if (oManager.layerObj().hasOwnProperty("customprops")) {
            return JSON.parse(oManager.layerObj().customprops)
        }
    }

    oManager.parseInfo = (data) => {
        var ret = {
            layerName: oManager.layerObj().name,
            properties: []
        };

        if (data.features && data.features.length > 0) {
            data.features.forEach(function (f) {
                if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                    ret.properties.push({name: 'value', 'value': f.properties.GRAY_INDEX.toFixed(2)})
                } else {
                    for (p in f.properties) {
                        ret.properties.push({name: p, 'value': f.properties[p]})
                    }
                }
            })
        }

        ret.properties.forEach(function (item) {
            if (item.name == 'link') {
                item.html = true;
            }else if (item.name == 'url') {
                item.popup = true;
            } else item.html = false;
        })

        return ret;
    }

    oManager.loadWithProperties = (onFinish, layerObj, props, item, dateFrom, dateTo, opacity) => {
        oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));
        dataid = oManager.layerObj().dataid;

        oManager.mapLayer().bringToFront();

        if (oManager.customprops() && oManager.customprops().hasOwnProperty('static_properties')) {

            aLayers = oManager.customprops().static_properties.properties

            aLayers.push({
                "descr": oManager.layerObj().descr,
                "dataid": oManager.layerObj().dataid,
                "url": oManager.layerObj().server.url
            })

        }

        if (iOpacity) oManager.setOpacity(opacity);
        if (onFinish) onFinish();

    },


        oManager.load = function (onFinish) {
            oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));

            dataid = oManager.layerObj().dataid;

            oManager.mapLayer().bringToFront();

            if (oManager.customprops() && oManager.customprops().hasOwnProperty('static_properties')) {

                aLayers = oManager.customprops().static_properties.properties

                aLayers.push({
                    "descr": oManager.layerObj().descr,
                    "dataid": oManager.layerObj().dataid,
                    "url": oManager.layerObj().server.url
                })

            }

            if (onFinish) onFinish()

        };


    oManager.update = function ( newLayer, onFinish) {

        let layer = aLayers.filter(layer => layer.dataid == newLayer.dataid)[0];

        let layerObj = oManager.layerObj()

        layerObj.descr = layer.descr;
        layerObj.server.url = layer.url;
        layerObj.dataid = layer.dataid;

        dataid = layerObj.dataid;

        oManager.setLayerObj(layerObj);

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));

        if (onFinish) onFinish();
    };




    oManager.showProps = function (onFinish) {

        var layerPropModal = oServices.$uibModal.open({
            template: `<div class="popup">
                        <div class="head" >
                            <div class="flex-container">
                                <!--Title-->
                                <div class="brand flex-item">
                                    <i class="fa app-static animated bounceIn delay-002" ></i>
                                    <p class="animated fadeInDown delay-001" translate>
                                          <span translate>  </span> <span translate>properties</span>
                                    </p>
                                </div>
                                <div class="flex-item">
                                    <a class="close" ng-click="close()" href>
                                        <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="modal-body">
                            
                                
                            <div class="row">
                                <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                                    <label class="hidden-xs">
                                        <h4 translate>VARIABLE</h4>
                                    </label>
                                    <p></p>
                                </div>
                    
                                <div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
                                    <select class="form-control" ng-model="oConfig.selectedVariable" ng-options="layer as layer.descr | translate for layer in oConfig.params.aLayers"></select>
                                </div>
                            </div>
                                
                                           
                            <br>
                            <br>
                            <div class="row">
                                <div class="flex-item animated zoomInUp delay-003 ">
                                    <a href="" class="btn btn-warning pull-right" ng-click="update()"  ng-show="oConfig.selectedVariable.descr">
                                        <i class="fa fa-refresh "></i>
                                        {{ 'LAYER_REFRESH' | translate }}
                                        
                                    </a>
                                </div>  
                            </div>
                        </div>
                    </div>`,
            controller: ['$scope', 'params', '$uibModalInstance', function ($scope, params, $uibModalInstance) {

                $scope.oConfig = {
                    selectedVariable: params.aLayers.filter(l => params.dataid == l.dataid)[0],
                    params: params
                };

                $scope.close = () => {
                    $uibModalInstance.dismiss();
                };
                $scope.update = () => {
                    $uibModalInstance.close($scope.oConfig.selectedVariable);
                };


            }],
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        aLayers: aLayers,
                        oManager: oManager,
                        dataid: dataid
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {

            oManager.update(obj, null, onFinish)
        }, function () {
            if (debug) console.log("CANCEL")
        });
    };

    oManager.customFormatDateDescription = function (data) {
        return data.description
    }


    return oManager;

}
