/**
 * Created by Dario Rubado on 19/06/15.
 */



function layerManager_section_probabilistic(layerObj, mapService, layerService, serieService, menuService, $uibModal) {

    var layer = layerObj;
    var layerData = null;
    var mapLayer = null;

    var visible = true;

    var dateRun = null;

    var theGeoJson = null;



    function stationClickListener(s) {

        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        var sectionData = s.target.feature.properties;

        var t = new Date().getTime();

        serieService.getSeries(layerData, sectionData, from, to, function (data) {

            var modalInstance = $uibModal.open({

                templateUrl: 'apps/dewetra2/views/chart_form.html',
                controller: function($scope, $uibModalInstance) {

                    $scope.title = sectionData.DATI_DA;

                    //		Expected: basin;section;procedure;run_data;meteo_model_run_date
                    var title_tokens = data[0].title.split(";");
                    var values = [];

                    data.forEach(function(h) {
                        values.push(h.values)
                    });

                    var hydrogram = {

                        section : sectionData.SEZIONE,
                        basin : sectionData.NOME_BACIN,
                        thresholds : [
                                        { name : 'THR_1',
                                          value : sectionData.THR1},
                                        { name : 'THR_2',
                                          value : sectionData.THR2},
                                        { name : 'THR_3',
                                          value : sectionData.THR3}
                        ],
                        procedure : 'Flood Proofs Probabilistic LAMI',
                        scenario : '',
                        dateRef : moment.utc(title_tokens[3], "YYYYMMDDHHmm").valueOf(),
                        now : menuService.getDateToUTCSecond(),
                        timeline : data[0].timeline,
                        values : values

                    };
                    setTimeout(function() {
                        showMaximumHydrogramChart(hydrogram);
                    }, 0);

                    $scope.closePopup = function(){

                        $uibModalInstance.close()

                    }

                },
                //size: 'lg',
                keyboard: false,
                windowClass: 'app-modal-window'


            });


        }, function (data) {
            alert('Error loading data: ' + data.error_message);
        })

    }

    var sectionIcon = new L.Icon.Canvas({iconSize: new L.Point(20, 20)});
    sectionIcon.draw = function(ctx, w, h) {

        // begin custom shape
        ctx.beginPath();

        ctx.moveTo(1, 1);
        ctx.lineTo(w, 0);
        ctx.moveTo(w, 0);
        ctx.lineTo(w/2, h);
        ctx.moveTo(w/2, h);
        ctx.lineTo(0, 0);

        ctx.closePath();
        ctx.lineWidth = 2;
        ctx.strokeStyle = 'blue';
        ctx.stroke();

        ctx.font = "14px Arial bold";
        ctx.fillStyle = 'blue';
        ctx.fillText("P",6,12);

    };


    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        load: function(onFinish) {
            serieService.getLayerData(layer, function (ld) {
                layerData = ld;
                serieService.getGeoJson(layerData, function(data) {

                    theGeoJson = data;

                    var dateToCheck = null;

                    if(theGeoJson.features){
                        theGeoJson.features.forEach(function (feature) {

                            if(feature.properties.run != ""){
                                dateToCheck = moment(feature.properties.run,"YYYYMMDDHHmm");

                                if(dateRun!= null){
                                    if(dateToCheck.isAfter(dateRun)){
                                        dateRun = dateToCheck;
                                    }
                                }else{
                                    dateRun = dateToCheck;
                                }
                            }
                        })
                    }


                    mapLayer = mapService.addGeoJsonLayer(data, layer['descr'], {

                        pointToLayer: function(feature, latlng) {
                            return L.marker(latlng, {icon:sectionIcon});

                        }

                    }, stationClickListener);

                    if (onFinish) onFinish()

                }, function(data) {

                    alert('Error loading layer: ' + data.error_message);

                });

            });

        },

        remove: function (layer, onFinish) {
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.name
        },

        descr: function () {
            return layer.descr
        },
        draggable: function () {
            return false
        },

        typeDescr: function () {
            return "SECTION_PROBABILISTIC"
        },


        setVisible: function (b) {

            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(theGeoJson);

            //visible = b
            //mapLayer.eachLayer(function (layer) {   //restore feature color
            //    mapLayer.resetStyle(layer);
            //});
        },
        dateLine:function(){
            //return layerObj.descr;
            if(dateRun)return dateRun.format('DD/MM/YYYY HH:mm')
        },

        thirdLine:function(){
            return true


        },

        getVariable :function(){

            return ""

        },

        getAggregation :function(){

            return""


        }



    }

}
