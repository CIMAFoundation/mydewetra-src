/**
 * Created by doy on 19/06/15.
 */


function layerManager_sensor(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, thresholdService) {

    var layer = layerObj;
    var layerData = null;

    var mapLayer = null;

    var visible = true;

    var warningInfo = null;

    var theGeoJson = null;

    var wsAcquisition = null;

    var sensorClassStyler = null;

    var selectedDataType =  0;

    var stringSoglie = "e_";
    var stringValori = "v_";
    var timeToUndef = 14400;

    var markerWarningOption = {
        radius : iconService.markerWarningOptions.radius,
        weight : iconService.markerWarningOptions.weight,
        color : iconService.markerWarningOptions.color,
        opacity : iconService.markerWarningOptions.opacity,
        fillOpacity: iconService.markerWarningOptions.fillOpacity
    };

    var updateListener = function(){
        console.log("update Listener");
        acEvent.connect('logger', 'logger4dew', function () {
            wsAcquisition = acEvent.subscribe('sentinel.2.#', updateStation)

        },function () {
            console.log('waiting 5 seconds and then reconnect');
            setTimeout(updateListener,5000)
        })

    };

    /**
     * Fuction for async update layer
     * @param data
     */
    function updateStation(data){

        console.log("sensor update iteration");
        var sensorData = [];

        if(_.isArray(data)){
            sensorData = _.filter(data, function (station) {
                if (oSensorData.aAnagrafica[station.sensorid]) return true;
            })
        }else{
            if (oSensorData.aAnagrafica[data.sensorid]) sensorData.push(data);
        }

        if (sensorData.length > 0){
            console.log("Sensor: " + sensorData.length + " sensor to Update");

            oSensorData.updateTheGeoJsonStation(sensorData);

        }

    }


    var oSensorData = {
        theGeoJsonStation: null,
        theGeoJsonRegion: null,
        theGeoJsonDistrict:null,
        theGeoJsonComuni:null,
        aAnagrafica: [],
        promise: [],
        audio: function(oldPalette, newPalette){
            //if((newPalette.warning_palette == 1 || newPalette.warning_palette == 2)&&(newPalette.warning_palette > oldPalette.warning_palette)){
            //    audioService.playAudio()
            //    console.log("testaudio")
            //}else if((newPalette.warning_palette == 3 || newPalette.warning_palette == 4)&&(newPalette.warning_palette > oldPalette.warning_palette)){
            //    audioService.playAudio()
            //    console.log("testaudio")
            //}
        },
        anagrafica: function(){
            if (this.aAnagrafica.length == 0){
                for(var s in this.theGeoJsonStation.features){
                    if(!_.isUndefined(this.theGeoJsonStation.features[s].properties)) {
                        try{
                            this.aAnagrafica[this.theGeoJsonStation.features[s].properties.sensorid] = {
                                regione: this.theGeoJsonStation.features[s].properties.region,
                                provincia: this.theGeoJsonStation.features[s].properties.district,
                                comune: this.theGeoJsonStation.features[s].properties.munic
                            }
                        }
                        catch(err){
                            console.log(err);
                            var p = this.theGeoJsonStation.features['move'];
                            console.log(p)
                        }
                    }
                }
            }
        },
        brintRelevantToFront: function(){
            for(var p in mapLayer._layers){
                if((mapLayer._layers[p].feature.properties.warning_palette ==3)){
                    mapLayer._layers[p].bringToFront();
                }
                if((mapLayer._layers[p].feature.properties.warning_palette ==-1)){
                    mapLayer._layers[p].bringToBack();
                }
            }
        },
        checkOldData: function(){
            var promise = null;
            promise = $interval(function () {
                oSensorData.checkOldData()
            }, triggerTime);
            oSensorData.promise.push(promise);
        },
        delCheckOldData: function () {
            if(oSensorData.promise){
                oSensorData.promise.forEach(function (promise) {
                    $interval.cancel(promise);
                })
            }
            audioPromise =[]
        },
        setGeoJsonStation: function(json) {
            json.features.forEach(function (features) { //error
                // features.properties = oSensorData.validateDataByTime(features.properties);
                // features.properties.warning_palette = oSensorData.palette(features.properties)
            });
            this.theGeoJsonStation= json;
            //build Dictionary anagrafica
            this.anagrafica();
        },
        setTheGeoJsonRegion : function(json){
            this.theGeoJsonRegion = json;
            this.updateTheGeoJsonRegion()
        },
        setTheGeoJsonDistrict : function(json){
            this.theGeoJsonDistrict = json;
            this.updateTheGeoJsonDistrict()
        },
        setTheGeoJsonComuni : function(json){
            this.theGeoJsonComuni = json;
            this.updateTheGeoJsonComune();
        },
        getGeoJsonStation: function () {
            return this.theGeoJsonStation;
        },
        getTheGeoJsonRegion : function(){
            return this.theGeoJsonRegion;
        },
        getTheGeoJsonDistrict : function(){
            return this.theGeoJsonDistrict;
        },
        getTheGeoJsonComuni : function(){
            return this.theGeoJsonComuni;
        },
        updateTheGeoJsonStation : function(aProperties){

            if(aProperties ){
                aProperties.forEach(function (properties) {
                    var o = oSensorData.validateDataByTime(properties);
                    o.warning_palette = oSensorData.palette(o);
                    var f = _.findIndex(oSensorData.theGeoJsonStation.features, function(feature){
                        if (feature.properties.sensorid == o.sensorid) return true;
                    });
                    //console.log(f)
                    if (f > -1) {
                        //console.log("audio test")
                        // oHygroData.audio(oHygroData.theGeoJsonStation.features[f].properties, o);
                        //console.log("update feature properties")
                        oSensorData.theGeoJsonStation.features[f].properties = o;
                    }
                });
                console.log("update feature style");
                oSensorData.updateFeatureStyle();
            }else {
                oSensorData.theGeoJsonStation.features.forEach(function (station) {
                    var o = oSensorData.validateDataByTime(station.properties);
                    o.warning_palette = oSensorData.palette(o);
                    station.properties = o;
                });
                oSensorData.updateFeatureStyle();
            }

        },

        updateFeatureStyle:function(){

            switch(aggregationType) {
                case "REGIONE":
                    console.log("regione");
                    this.updateTheGeoJsonRegion();
                    this.updateRegionFeaturesStyle();
                    break;
                case "PROVINCE":
                    console.log("province");
                    this.updateTheGeoJsonDistrict();
                    this.updateDistrictFeaturesStyle();
                    break;
                case "COMUNI":
                    this.updateTheGeoJsonComune();
                    this.updateComuniFeaturesStyle();
                    console.log("comuni");
                    break;
                case "STAZIONI":
                    this.updateMarkerStyle();
                    console.log("stazioni");
                    break;
                default:{
                    this.updateMarkerStyle()}
            }
        },

        updateMarkerStyle:function(){
            console.log("update marker style");
            this.theGeoJsonStation.features.forEach(function(station){

                var f = _.findKey(mapLayer._layers, function (marker) {
                    return (marker.feature.properties.sensorid == station.properties.sensorid)
                });
                if(f > -1){
                    //console.log("setStyle marke")

                    var latlng = mapLayer._layers[f].getLatLng();
                    //var test = L.marker(latlng).addTo(mapLayer);


                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: iconService.sensorClassStylist[layer.dataid.split(";")[1]].palette[station.properties.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity
                        });



                    mapLayer._layers[f].feature.properties = station.properties;
                }
            });
        },

        updateRegionFeaturesStyle:function(){

            this.theGeoJsonRegion.features.forEach(function(region){

                var f = _.findKey(mapLayer._layers, function (marker) {
                    if (marker.feature.properties.gid == region.properties.gid) return true;
                });
                if(f>-1){
                    mapLayer._layers[f].properties = region;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[region.properties.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity
                        })
                }
            });
        },

        updateDistrictFeaturesStyle:function(){

            this.theGeoJsonDistrict.features.forEach(function(province){

                var f = _.findIndex(mapLayer._layers, function (marker) {
                    if (marker.properties.district == province.gid) return true;
                });
                if(!_.isUndefined(f)){
                    if((province.warning_palette == 1 || province.warning_palette == 2)&&(province.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }else if((province.warning_palette == 3 || province.warning_palette == 4)&&(o.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }

                    mapLayer._layers[f].properties = province;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[province.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity
                        })
                }
            });
        },

        updateComuniFeaturesStyle:function(){

            this.theGeoJsonComuni.features.forEach(function(comune){

                var f = _.findIndex(mapLayer._layers, function (marker) {
                    if (marker.properties.munic == comune.gid) return true;
                });
                if(!_.isUndefined(f)){
                    if((comune.warning_palette == 1 || comune.warning_palette == 2)&&(comune.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }else if((comune.warning_palette == 3 || comune.warning_palette == 4)&&(o.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }

                    mapLayer._layers[f].properties = comune;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[comune.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity
                        })
                }
            });
        },

        updateTheGeoJsonRegion: function () {

            var regionGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.region;
            });

            this.theGeoJsonRegion.features.forEach(function(feature){

                var warnIndexRegional = _.max(regionGroup[feature.properties.gid], function (station) {
                    var p = station.properties.warning_palette;
                    return p;
                });
                feature.properties.warning_palette = warnIndexRegional.properties.warning_palette;
            });
        },

        updateTheGeoJsonDistrict: function () {

            var districtGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.district;
            });

            this.theGeoJsonDistrict.features.forEach(function(feature){

                var warnIndexDistrict = _.max(districtGroup[feature.properties.gid], function (station) {
                    var p = station.properties.warning_palette;
                    return p;
                });
                feature.properties.warning_palette = warnIndexDistrict.properties.warning_palette;
            });
        },

        updateTheGeoJsonComune: function () {

            var municGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.munic;
            });

            this.theGeoJsonComuni.features.forEach(function(feature){
                if(municGroup[feature.properties.gid]){
                    var warnIndexMunic = _.max(municGroup[feature.properties.gid], function (station) {
                        var p = station.properties.warning_palette;
                        return p;
                    });
                    feature.properties.warning_palette = warnIndexMunic.properties.warning_palette;
                }else feature.properties.warning_palette = -1



            });
        },

        validateDataByTime: function(properties){

            //se sono nel passato come ora di riferimento per validare i dati prendo quella di caricamento del layer
            var iServerTime =(menuService.isRealTime())? menuService.getUtcServerDateInSecond():menuService.getDateToUTCSecond();

            if (properties.sensorid == -2147462361){
                //console.log(properties)
            }

            var aValori = [];

            for (var prop in properties) {
                if (stringStartsWith(prop, stringValori)) {
                    var aValore = prop.split("_");

                    var oValore = {
                        timestamp: parseInt(aValore[1]),
                        period: parseInt(aValore[2]),
                        valore: parseFloat(properties[prop])
                    };
                    aValori.push(oValore);
                }
            }

            if (aValori.length == 0) return properties;
            var oMostRecentValue = _.max(aValori, function (valore) {
                return valore.timestamp;
            });

            if ((iServerTime - oMostRecentValue.timestamp) > timeToUndef) {
                var obj = {};
                for (var prop in properties) {
                    if (!stringStartsWith(prop, stringValori) &&(!stringStartsWith(prop, stringSoglie))) {
                        obj[prop] = properties[prop];
                    }
                }
                return obj;
            } else return properties;
        },
        palette: function(oProperties) {

            for (var prop in oProperties) {
                if (stringEndsWith(prop, "_"+selectedDataType.toString())) {
                    return iconService.sensorClassStylist[layer.dataid.split(";")[1]].paletter(oProperties[prop]);
                }
            }
        }
    };


    function showChart(properties, sensorId, dbId, sensorClass) {



        if(layer.dataid.split(";")[1]){
            sensorClass = layer.dataid.split(";")[1]

        }

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/sensor_chart_form.html',
            controller: 'sensorChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sensorData: function () {

                    // var featureData = props;

                    return {
                        sensorId: sensorId,
                        dbId: dbId,
                        sensorClass: sensorClass,
                        properties:properties
                    };

                }

            }
        });
    }

    function stationClickListener(s) {

        if(layer.dataid.indexOf('sensorClass')>-1){
            showChart(s.target.feature.properties, s.target.feature.properties.sensorid, s.target.feature.properties.dbid);

        }else{
            showChart(s.target.feature.properties, s.target.feature.properties.sensor, s.target.feature.properties.db,s.target.feature.properties.class);

        }

    }

    /**
     * mouse listener
     * @param feature object
     * @return *
     * */
    function stationMouseOverListener(s){
        try{
            if(warningInfo){
                // warningInfo.mouseOver(layer.dataid.split(";")[1],mapLayer._leaflet_id, s.target.feature.properties, iconService.sensorClassStylist[layer.dataid.split(";")[1]].palette)

                warningInfo.mouseOver("SENSOR_GENERIC",mapLayer._leaflet_id, s.target.feature.properties, iconService.sensorClassStylist[layer.dataid.split(";")[1]].palette)
            }
        }catch(err){
            alert("errot thresholdInfo.mouseOver")
        }
    }

    function stationMouseOutListener(s){
        try{
            if(warningInfo){
                warningInfo.mouseOut("SENSOR_GENERIC",mapLayer._leaflet_id)
            }

        }catch(err){
            alert("errot thresholdInfo.mouseOver")
        }
    }



    var sensorIcon = new L.Icon({iconSize: new L.Point(16, 16)});

    return {

        sensorIcon: function() {
            return sensorIcon;
        },

        layerData: function() {
          return layerData;
        },

        setLayerData: function(l) {
            layerData = l;
        },

        layerObj: function() {
            return layer
        },

        mapLayer: function() {
            return mapLayer;
        },

        setMapLayer: function(l) {
            mapLayer = l;
        },

        setGeoJson: function(o) {
            theGeoJson = o;
        },

        load: function(onFinish) {

            if(layer.dataid.indexOf('sensorClass')>-1){

                sentinelService.getSensorGeneric(layer.dataid.split(";")[1],null,function (data) {

                    if (!menuService.isRealTime() && wsAcquisition != null) this.removeListener();

                    if(mapLayer) mapService.removeLayer(mapLayer);

                    if(iconService.sensorClassStylist[layer.dataid.split(";")[1]].hasOwnProperty("uniformData")){

                        data =iconService.sensorClassStylist[layer.dataid.split(";")[1]].uniformData(data)
                    }

                    oSensorData.setGeoJsonStation(data);

                    //iconService.sensorClassStylist[layer.dataid.split(";")[1]].Icon

                    mapLayer = mapService.addGeoJsonLayer(oSensorData.getGeoJsonStation(), layer['descr'], {

                        pointToLayer: function(feature, latlng) {

                            return iconService.sensorClassStylist[layer.dataid.split(";")[1]].Icon(feature, latlng)

                        }

                    }, stationClickListener,stationMouseOverListener, stationMouseOutListener);

                    if (onFinish) onFinish()

                    updateListener()

                },function (err) {
                    console.log("error loading sensor generic")
                })

            }else{
                serieService.getLayerData(layer, function (ld) {
                    layerData = ld;

                    serieService.getGeoJson(layerData, function(data) {

                        theGeoJson = data;


                        mapLayer = mapService.addGeoJsonLayer(data, layer['descr'], {
                            pointToLayer: function(feature, latlng) {
                                return L.circleMarker(latlng, {icon:sensorIcon});
                            }
                        }, stationClickListener);

                        if (onFinish) onFinish()

                    }, function(data) {

                        alert('Error loading layer: ' + data.error_message);

                    });

                });
            }

        },

        layerTooltip: function(){

            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : this.name()
                },
                {
                    label : "LAYER_DESCR",
                    value : this.descr()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : this.typeDescr()
                }

            ];

            return tooltipObj;

        },

        dateLine:function(){
            return layer.descr;

            //var sensor = layer.dataid.split(";")[1];
            //return "SENSOR_TYPE_DATELINE_"+sensor;
        },

        updateListener: function(){
            console.log("update Listener");
            acEvent.connect('logger', 'logger4dew', function () {
                wsAcquisition = acEvent.subscribe('sentinel.2', updateStation)

            },function () {
                console.log('waiting 5 seconds and then reconnect');
                setTimeout(this.updateListener,5000)
            })

        },

        removeListener: function () {
            acEvent.unsubscribe(wsAcquisition);
            wsAcquisition = null;
            console.log("unsubscribe")
        },


        remove: function (layer, onFinish) {
            if (wsAcquisition) this.removeListener();
            oSensorData.delCheckOldData()
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.name
        },

        descr: function () {
            return layer.descr
        },

        isVisible:function(){
            return visible
        },

        setVisible: function (b) {

            visible =b

            if (!b) mapLayer.clearLayers();
            else mapLayer.addData(oSensorData.getGeoJsonStation());

            //visible = b
            //mapLayer.eachLayer(function (layer) {   //restore feature color
            //    mapLayer.resetStyle(layer);
            //});
        },
        bounds:function(){
            var manager = this;

            var bounds = L.latLngBounds(L.latLng(manager.layerObj().lats,manager.layerObj().lonw),
                L.latLng(manager.layerObj().latn,manager.layerObj().lone));
            return bounds;
        },

        onDateChange : function (callBack) {
            //ricarico il layer se è nel passato fa tutto il load
            this.load(callBack)
        },

        typeDescr: function () {
            return "SENSOR_LAYER";
        },

        setWarningInfo: function (wi) {
            warningInfo = wi
        },

        getWarningInfo: function () {
            return warningInfo;
        },

        type: function () {
            return "SENSOR_LAYER";
        },

        draggable: function () {
            return false;
        },

        legend: function () {

            if (iconService.sensorClassStylist[layer.dataid.split(";")[1]].hasOwnProperty("palette")) {

                var sensorClass = layer.dataid.split(";")[1];

                var legend = {
                    type: "ADVANCED",
                    legend: [{
                        type: "CUSTOM",
                        title: "SENSOR_CLASS_PALETTE_" + layer.dataid.split(";")[1],
                        palette: []
                    }]
                };

                for (var i in iconService.sensorClassStylist[layer.dataid.split(";")[1]].palette) {
                    var obj = {};
                    obj.label = "SENSOR_CLASS_PALETTE_" + layer.dataid.split(";")[1] + "_" + i.toString();
                    obj.color = iconService.sensorClassStylist[layer.dataid.split(";")[1]].palette[i];
                    legend.legend[0].palette.push(obj)
                }

                return legend;

            }




        },

        thirdLine:function(){
            return ""
        },

        getVariable:function () {
            return ""
        },

        getAggregation:function () {
            return ""
        }

    }

}
