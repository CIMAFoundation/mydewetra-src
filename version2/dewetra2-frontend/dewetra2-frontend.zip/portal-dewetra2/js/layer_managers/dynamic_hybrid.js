
function layerManager_dynamic_hybrid(layerObj) {

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices();

    var iOpacity = 1;

    var layerMovieConf;

    var infoAvaialability = {
        index: 0,
        length: 1,
        reverse: null// per i radar il primo layer disponibile è l'ultimo in ordine di tempo, al contrario dei modelli
    };

    var oDynamicPaletteSettings = {
        haveDynamicPalette: false,
        min_value: 0,
        max_value: 0
    };

    var playPromise;

    var layerId;

    var downloadUrl;

    var debug = true;

    var currentLoadedTimeline;

    var fadeEffectTime = 300;

    oManager.setCanMovie(true);

    oManager.draggable = function (){
        return true;
    }

    function loadMovieOptions(){
        oServices.layerService.getSupportedMovie(layerObj.server.id,(supportedMovie)=> {

            var availableLayer = supportedMovie.datas.filter(layerConf => layerConf.dataId == layerObj.dataid)[0];

            if(availableLayer.dataId){
                oServices.layerService.createMovie(layerObj.server.id, layerObj.dataid,(data) => {

                    if (data.string == 'KO' || data.string == 'OK'){
                        oServices.layerService.getMovie(layer.server.id, layerObj.dataid,(data) =>{

                            //data.properties e data.datas
                            //da data.properties devo estrarre le selected entry di tipo list no hidden cobinare il value e in datas prendere il timelineid corretto

                            let attributes = data.properties.attributes.filter((attr) => {//filter by used attributes
                                return (attr.type == "List" && attr.visible == "true")
                            })

                            //build timelineId
                            let neededTimelineId= layerObj.dataid+'_';

                            attributes.map(( cur, idx ,src)=>{
                                let sep = (idx < (src.length-1))?'_':'';
                                if(cur.selectedEntry.value ){
                                    neededTimelineId += cur.selectedEntry.value + sep;
                                }
                            });

                            let timelineObj = data.datas.filter(obj => obj.timelineId == neededTimelineId)[0];



                            oServices.layerService.getMovieTimeline(layerObj.server.id,layerObj.dataid, timelineObj.timelineId, function(timeline){
                                console.log(timeline);

                            })


                        },(data) =>{
                            console.log(data);

                        },)
                    }

                })

            }else {
                //todo rendo compatibile con vecchia movie?
            }

        },(data)=>{console.log('error in get supported movie call')})
    }

    function evaluateAttributeForMovie(attr){
        return (attr.type == "List" && (attr.visible == "true" || typeof attr.visible === "boolean"));

    }

    function evaluateExclusion(){
        // console.log(layerMovieConf.exclusion);//attributeName entries
        // console.log(oManager.props().layerProperties.attributes); //attributes [name selectedEntry.value]

        let attributes = oManager.props().layerProperties.attributes.filter(evaluateAttributeForMovie);
        var canMovie = true;

        if(!layerMovieConf) {
            oManager.setCanMovie(false)
            return false;
        }

        attributes.map((attribute) => {

            let exclusionAttr = layerMovieConf.exclusion.filter(excl => excl.attributeName == attribute.name)[0];

            if(Array.isArray(exclusionAttr.entries) && exclusionAttr.entries.indexOf(attribute.selectedEntry.value) > -1){
                canMovie = false;
            }
        })

        if(debug) console.log('Movie Version 2');
        oManager.setCanMovie(canMovie)
        return canMovie;
    }

    function initializeMovieV2(onFinish){

        if(layerMovieConf.dataId){
            oServices.layerService.createMovie(layerObj.server.id, layerObj.dataid,(data) => {

                if (data.string == 'KO' || data.string == 'OK'){
                    oServices.layerService.getMovie(layerObj.server.id, layerObj.dataid,(data) =>{

                        //data.properties e data.datas
                        //da data.properties devo estrarre le selected entry di tipo list no hidden cobinare il value e in datas prendere il timelineid corretto

                        let attributes = oManager.props().layerProperties.attributes.filter(evaluateAttributeForMovie);

                        //build timelineId
                        let neededTimelineId= layerObj.dataid+'_';
                        attributes.map(( cur, idx ,src)=>{
                            let sep = (idx < (src.length-1))?'_':'';
                            if(cur.selectedEntry.value ){
                                neededTimelineId += cur.selectedEntry.value + sep;
                            }
                        });

                        let timelineObj = data.datas.filter(obj => obj.timelineId == neededTimelineId)[0];

                        oServices.layerService.getMovieTimeline(layerObj.server.id,layerObj.dataid, timelineObj.timelineId, function(timeline){
                            if (debug)console.log(timeline); //timelineValues.entry[key value]

                            if (debug)console.log(oManager.item());


                            setLayerFromTimeline(timeline, 0, onFinish)

                        })


                    },(data) =>{
                        console.log(data);

                    },)
                }

            })

        }
    }

    function initializeMoveOptions() {


        //chiedo una volta la disponibilita dei layer per sapere se posso andare avanti o indietro nel tempo

        //chiedo quali layer sono diponibili nella timeline

        var from = oServices.menuService.getDateFromUTCSecond();
        var to = oServices.menuService.getDateToUTCSecond();

        oServices.layerService.getLayerAvailability(layerObj, oManager.props(), from, to, function (dataAvailable) {



            let bCanMovie = (dataAvailable.length > 1) ? true : false;
            if (bCanMovie) {
                //cerco l'index del layer caricato precedentemente
                var iIndexLoadedLayer = _.findIndex(dataAvailable, function (availableItem) {
                    return availableItem.description == oManager.item().description;
                });
                //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                iIndexLoadedLayer = (iIndexLoadedLayer > -1) ? iIndexLoadedLayer : 1;

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                infoAvaialability.index = iIndexLoadedLayer;
                infoAvaialability.length = dataAvailable.length;
                infoAvaialability.reverse = moment(dataAvailable[0].date).unix() > moment(dataAvailable[1].date).unix() ? true : false
            }

        })
    }

    oManager.load = function (onFinish){

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());


        oServices.layerService.getLayerProperties(layerObj, function (layerProp) {
            oManager.setProps(layerProp);

            oServices.layerService.getSupportedMovie(layerObj.server.id,(supportedMovie)=> {
                layerMovieConf = supportedMovie.datas.filter(layerConf => layerConf.dataId == layerObj.dataid)[0];


                if(evaluateExclusion() && oManager.oServices().menuService.isRealTime()){
                    initializeMovieV2(onFinish);
                    if(debug) console.log('MOVIE METHOD');
                }else {
                    loadNoMovie(onFinish);
                    if(debug) console.log('STANDARD METHOD');
                }
            }, function (){
                loadNoMovie(onFinish);
                if(debug) console.log('STANDARD METHOD');
            });



        })

    };

    function loadNoMovie (onFinish){
        var from = oServices.menuService.getDateFromUTCSecond();
        var to = oServices.menuService.getDateToUTCSecond();

        oServices.layerService.publishLayer(layerObj, from, to, function (data) {
            // &env=minimum:12;maximum:20&
            oManager.setProps( data.properties);
            oManager.setItem(data.item);
            oManager.setLayerId(data.layerid);

            //check after setting props
            buildDynamicPaletteData();


            oManager.setLayerId(data.layerid);
            oManager.setMapLayer( oServices.mapService.addWmsLayer(data.serverurl + '/wms', data.layerid));
            oManager.setDownloadUrl(
                ((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                    data.serverurl + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                    data.serverurl + '/ddsData/' + data.layerid + '.tiff')
            );

            //inizializzo le opzioni per la movie
            initializeMoveOptions();

            if (onFinish) onFinish()

            if (!oManager.isVisible()) oManager.setVisible(false);


        }, function (data) {
            alert($translate.instant(data));
            if (debug) console.log(data);
        })
    }


    oManager.update = function (newProps, newItem, onFinish){

        oManager.setProps(newProps);
        oManager.setItem(newItem);

        if(evaluateExclusion()){
            updateNewMethod(onFinish)

            if(debug) console.log('updateNewMethod');
        }else {
            updateOldMethod( onFinish)
            if(debug) console.log('updateOldMethod');
        }


    };

    function updateOldMethod( onFinish){

        var from = oServices.menuService.getDateFromUTCSecond();
        var to = oServices.menuService.getDateToUTCSecond();

        oServices.layerService.republishLayer(layerObj, oManager.props(), from, to, oManager.item(),
            function (data, status) {


                oManager.setDownloadUrl(((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                    layerObj.server.url + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                    layerObj.server.url + '/ddsData/' + data.layerid + '.tiff'));

                setLayer( data.layerid, onFinish);
            },

            function (data) {
                alert($translate.instant(data));
            })
    }

    function updateNewMethod(onFinish){
        initializeMovieV2(onFinish);
    }


    function setLayerWithProp(newProps, newItem, layerId, onFinish) {


        oManager.setProps(newProps)

        oManager.setItem(newItem)

        setLayer(layerId, onFinish);


        if (debug) console.log(layerObj.id + " " + layerId)
    }

    function setLayer(layerId , onFinish){

        if (oManager.mapLayer()) iOpacity = oManager.mapLayer().options.opacity;

        var LoadedMapLayerToRemove = oManager.mapLayer();

        // if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());


        oServices.$timeout(() => {
            if(LoadedMapLayerToRemove)oServices.mapService.removeLayer(LoadedMapLayerToRemove);
        },fadeEffectTime);

        oManager.setLayerId(layerId);

        oManager.setMapLayer(
            oServices.mapService.addWmsLayer(layerObj.server.url + '/wms', layerId, (oManager.haveDynamicPalette()) ? "minimum:" + oManager.haveDynamicPalette().min_value.toString() + ";maximum:" + oManager.haveDynamicPalette().max_value.toString() : null)
        );

        if (iOpacity != null) oManager.mapLayer().setOpacity(iOpacity);

        if (debug) console.log(layerObj.id + " " + layerId)


        if (onFinish) onFinish();
    }

    function setLayerFromTimeline(timeline, index, onFinish){

        //let item = {
        //"date": "2021-02-11T01:00:00Z",
        //"description": "Run: 2021-02-09 1200. Progr. + 37 h",
        //"id": "1612872000000;1613005200000"
        //};

        currentLoadedTimeline = timeline;

        //COSMO_I2_COSMO_I2_1_Native_tp_-_1612915200000_1612983600000
        let splittedValue = currentLoadedTimeline.timelineValues.entry[index].value.split('_');
        let sDateRef = splittedValue[splittedValue.length-1];
        let sDateRun = splittedValue[splittedValue.length-2];
        let diff = moment(sDateRun).diff(sDateRef, 'hours');

        let item = {
            "date": moment.unix(currentLoadedTimeline.timelineValues.entry[index].key).format(),
            "description": moment.unix(sDateRun).format("Run: YYYY-MM-DD HHmm. Progr. +") + diff + " h",
            "id" : sDateRun+';'+sDateRef,

        };

        oManager.setItem(item)



        oManager.infoAvaialability().index = index;

        oManager.infoAvaialability().length = timeline.timelineValues.entry.length;

        setLayer(currentLoadedTimeline.timelineValues.entry[index].value, onFinish);
    }

    function setLayerFromLastLoadedTimeline(newIndex, onFinish){

        if(newIndex){
            oManager.infoAvaialability().index = newIndex;
        }

        setLayer(currentLoadedTimeline.timelineValues.entry[oManager.infoAvaialability().index].value, onFinish)

        //oManager.infoAvaialability().length = timeline.timelineValues.entry.length
    }


    oManager.haveDynamicPalette = function (obj) {

        if (obj) {
            oDynamicPaletteSettings = obj
            setLayer(layerId)
        }

        if (oDynamicPaletteSettings.haveDynamicPalette) {
            return oDynamicPaletteSettings
        } else return false;
    }

    function buildDynamicPaletteData() {

        if (oDynamicPaletteSettings.haveDynamicPalette) return oDynamicPaletteSettings;


        if (oManager.props().layerProperties.attributes.length > 0) {

            var dynamicPaletteProp = _.findWhere(oManager.props().layerProperties.attributes, {name: "dyn_pal"})

            if (dynamicPaletteProp && dynamicPaletteProp.selectedEntry.value == "1") {
                var obj = {}
                obj.haveDynamicPalette = true;//setto opzio true
                var selectedVariable = _.findWhere(oManager.props().layerProperties.attributes, {name: "variable"})
                var maxVal = _.findWhere(selectedVariable.selectedEntry.referredValues.entry, {key: "max_def"});
                if (maxVal) {
                    obj.max_value = parseFloat(maxVal.value);
                    obj.min_value = parseFloat((_.findWhere(selectedVariable.selectedEntry.referredValues.entry, {key: "min_def"})).value);
                    oDynamicPaletteSettings = obj
                    //return obj// forse inutile
                }
            }

        }
    }



    oManager.canPlay= function (){
        return (playPromise == null);
    }

    oManager.play = function (oRootScope){

        playPromise = oServices.$interval(function () {

            if (oRootScope.pendingRequests == 0) {

                if (infoAvaialability.reverse) {
                    if (infoAvaialability.index != 0) {
                        oManager.goBackward();
                    } else oManager.goToLast();
                } else {
                    if (infoAvaialability.index < infoAvaialability.length - 1) {
                        oManager.goForward();
                    } else oManager.goToFirst();
                }

            }
        }, 2000);
    }

    oManager.stop = function () {
        oServices.$interval.cancel(playPromise);
        playPromise = null;
    }


    oManager.goToLast = function () {
        setLayerFromLastLoadedTimeline(infoAvaialability.length - 1)
    }

    oManager.goToFirst = function () {
        setLayerFromLastLoadedTimeline(0)
    }

    oManager.goForward= function (){
        if(evaluateExclusion()){
            setLayerFromLastLoadedTimeline(oManager.infoAvaialability().index + 1 )
        }
    }

    oManager.canForward = function (){

        if(oManager.canMovie()){
            return ( oManager.canMovie() && oManager.infoAvaialability().index < oManager.infoAvaialability().length);
        }else return false;

    }

    oManager.goBackward = function (){
        if(evaluateExclusion()){
            setLayerFromLastLoadedTimeline(oManager.infoAvaialability().index - 1 )
        }
    }

    oManager.canBackward = function () {

        if(oManager.canMovie()){
            return ( oManager.canMovie() && oManager.infoAvaialability().index >= 0);
        }else return false;

    }

    oManager.layerDateRefFromManager = function (){

    }

    oManager.dateLine = function (){
        try {
            return oManager.dateRefFormatted()
        }catch (e){
            if (debug)   //console.log(e);
                return "date";
        }
    }

    oManager.dateRefFormatted = function () {
        var sDateRunDateRef = oManager.item().id;

        if (oManager.props().layerProperties.id == "WFSNOWROADS") return item.id.replace(/;/g, ' ');

        if (sDateRunDateRef  == null) return "";

        if (sDateRunDateRef.indexOf(";") > -1) {
            //controllo se osservazione o previsione
            var bLayerType = layerObj.category == "observation";
            //se osservazione la data di run corrisponde alla dateref e ne visualizzo solo una
            if (bLayerType) {
                var aDateRunDateRef = sDateRunDateRef.split(";");
                var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                //var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                return sDateRun
            } else {
                //se previsione distinguo le due date
                var aDateRunDateRef = sDateRunDateRef.split(";");
                var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                return sDateRef + " " + " (Run:" + sDateRun + ")";
            }
            //se ha solo una data non mi pongo il problema
        } else {


            // Anto 20160908: Se item.id non è una data provo con item.date
            var tsRun = parseInt(sDateRunDateRef);
            if (!isNaN(tsRun)) {
                return moment(new Date(tsRun)).utc().format('DD/MM/YYYY HH:mm');
            }
            else {
                return moment(Date.parse(oManager.item().date)).utc().format('DD/MM/YYYY HH:mm');
            }

        }

    };



    oManager.thirdLine = function () {
        return true
    }

    oManager.getVariable= function () {


        var str = "";
        if (Array.isArray(oManager.props().layerProperties.attributes)) {
            oManager.props().layerProperties.attributes.forEach(function (prop) {
                if (prop.name == "operation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (prop.name == "variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (prop.name == "__variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            })
            return str;
        } else {
            if (oManager.props().layerProperties.attributes.name == "operation") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            if (oManager.props().layerProperties.attributes.name == "variable") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            if (oManager.props().layerProperties.attributes.name == "__variable") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
        }

    };

    oManager.getAggregation= function () {
        var str = "";

        if (Array.isArray(oManager.props().layerProperties.attributes)) {
            oManager.props().layerProperties.attributes.forEach(function (prop) {
                if (prop.name == "aggregation") str = prop.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
                if (prop.name == "__aggregation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            })
            return str;
        } else {
            if (oManager.props().layerProperties.attributes.name == "aggregation") str = oManager.props().layerProperties.attributes.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
            if (oManager.props().layerProperties.attributes.name == "__aggregation") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
        }


    };

    oManager.dateRun = function (){

    }


    oManager.showProps= function (onFinish) {

        var layerPropModal = oServices.$uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        layer: oManager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {

            oManager.update(obj.props, obj.data, onFinish)
        }, function () {
            if (debug) console.log("CANCEL")
        });
    };

    oManager.onDateChange= function (onFinish) {
        console.log("on Date Change");
        //precarico anche l'opzione corrente cosi basta cliccare aggiorna per refreshare



        oManager.load(onFinish)
        //chiedo layer avaiability dopodiche uso la update

        // layerService.getLayerAvailability(layer, props, from, to, function (data) {
        //     update(props, data[0], onFinish)
        // })
    },

    oManager.showProps= function (onFinish) {

        var modalInstance = oServices.$uibModal.open({
            animation: true,
            component: 'layerPropertiesDynamic',
            size:'lg',
            resolve:{
                oManager:function () {
                    return oManager
                }
            }
        });

        modalInstance.result.then(function (obj) {

            console.log('modal-component dismissed at: ' + new Date());

            oManager.update(obj.props, obj.data, onFinish)

            modalInstance = null;

        }, function () {
            console.log('modal-component dismissed at: ' + new Date());
            modalInstance = null;
        });
    };

    oManager.layerTooltip = function (){

        //dividere per osservazioni o previsioni e aggiungere le properties al tooltip


        var layerDelay = function (layerManagerObj) {


            try {
                var oReferenceDate = layerManagerObj.dateRef().utc().toDate()
            } catch (err) {
                return layerManagerObj.descr()
            }

            // Get Now
            var oDate = new Date();

            //if(debug)console.log("Now  = " + oDate);
            //if(debug)console.log("Ref  = " + oReferenceDate);

            // Compute time difference
            var iDifference = oDate.getTime() - oReferenceDate.getTime();

            // How it is in minutes?
            var iMinutes = 1000 * 60;

            var iDeltaMinutes = Math.round(iDifference / iMinutes);

            var sTimeDelta = "";

            if (iDeltaMinutes > 0) {
                if (iDeltaMinutes < 60) {
                    // Less then 1h
                    sTimeDelta += $translate.instant("pre_min_fa") + " " + iDeltaMinutes + ' ' + $translate.instant("min_fa");
                } else if (iDeltaMinutes < 60 * 24) {
                    // Less then 1d
                    var iDeltaHours = Math.round(iDeltaMinutes / 60);
                    sTimeDelta += $translate.instant("pre_ore_fa") + " " + iDeltaHours + ' ' + $translate.instant("ore_fa");
                } else {
                    // More than 1d
                    var iDeltaDays = Math.round(iDeltaMinutes / (60 * 24));
                    sTimeDelta += $translate.instant("pre_giorni_fa") + " " + iDeltaDays + ' ' + $translate.instant("giorni_fa");
                }
            } else {
                if (iDeltaMinutes > -60) {
                    // Less then 1h
                    sTimeDelta += $translate.instant("Fra") + ': ' + Math.abs(iDeltaMinutes) + ' ' + $translate.instant("Minuti");
                } else if (iDeltaMinutes > -60 * 24) {
                    // Less then 1d
                    var iDeltaHours = Math.round(iDeltaMinutes / 60);
                    sTimeDelta += $translate.instant("Fra") + ': ' + Math.abs(iDeltaHours) + ' ' + $translate.instant("Ore");
                } else {
                    // More than 1d
                    var iDeltaDays = Math.round(iDeltaMinutes / (60 * 24));
                    sTimeDelta += $translate.instant("Fra") + ': ' + Math.abs(iDeltaDays) + ' ' + $translate.instant("Giorni");
                }
            }


            return sTimeDelta;
        };

        //gestisco la from date nel tooltip.
        try {
            var oHoursOfCumulate = oManager.props().layerProperties.attributes.filter((attr) => {
                return attr.descr == "Cumulative Rainfall"
            })[0].selectedEntry

            var iHoursOfCumulate = parseInt(oHoursOfCumulate.value);

            // if(iHoursOfCumulate == '-1') {
            //     console.log("cumulata su time range")
            //     iHoursOfCumulate = Math.abs(menuService.getDateTo() - menuService.getDateFrom()) / 36e5;
            // }

        } catch (e) {
            console.log(iHoursOfCumulate);
        }


        //gestisco risoluzione spaziale pioggia

        try {
            var oSpatialResolution = oManager.props().layerProperties.attributes.filter((attr) => {
                return attr.descr == "Spatial Resolution"
            })[0].selectedEntry;


        } catch (e) {
            console.log(e)
        }


        //definisco oggetto tooltip
        var oTooltip = {
            "API 15": [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") : ""
                }
            ],
            MCM_CUMULATED_RAIN_DESCR: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") : ""
                }
            ],
            RADAR: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.getVariable()
                },
                //{
                //    label : "DATE_RUN",
                //    value : oManager.dateRun().format("YYYY/MM/DD HH:mm")
                //},
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") + ' UTC' : "",
                },
                //{
                //    label : "DATE_FORECAST",
                //    value : oManager.dateForecast()
                //},
                // {
                //     label: "DATE_DELAY",
                //     value: layerDelay(oManager)
                // }
            ],
            observation: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: (oManager.getVariable()) ? oManager.getVariable() : oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id && oManager.dateRef().isValid == true) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") : ""
                }
                // {
                //     label : "DATE_DELAY",
                //     value : layerDelay(oManager)
                // }
            ],
            forecast: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_RUN",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") : ""
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") + " (" + oManager.dateForecast() + " h)" : ""
                },
                // {
                //     label : "DATE_FORECAST",
                //     value : oManager.dateForecast()
                // },
                // {
                //     label : "DATE_DELAY",
                //     value : layerDelay(this)
                // }

            ],
            DEFAULT: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                }
            ],
            RAINFALL_FIELD: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: oManager.dateRun().format("DD/MM/YYYY HH:mm")
                },
                {
                    label: "CUMULATE_TIME",
                    value: (oHoursOfCumulate) ? oHoursOfCumulate.descr : null
                },
                {
                    label: "AGGREGATION",
                    value: (oSpatialResolution) ? oSpatialResolution.descr : null
                },
                {
                    label: "FROM_DATE",
                    value: (iHoursOfCumulate > -1) ? oManager.dateRun().subtract({hours: iHoursOfCumulate}).format("DD/MM/YYYY HH:mm") : moment.utc(menuService.getDateFrom()).format("DD/MM/YYYY HH") + ':00'
                },
                {
                    label: "TO_DATE",
                    value: oManager.dateRun().format("DD/MM/YYYY HH:mm")
                }
            ],
            WFSNOWROADS: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: oManager.item().id.replace(/;/g, ' ')
                }
            ],
            FULL: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_RUN",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") : ""
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") : ""
                },
                {
                    label: "DATE_FORECAST",
                    value: oManager.dateForecast()
                },
                {
                    label: "DATE_DELAY",
                    value: layerDelay(oManager)
                }]
        };


        //layer prop
        var oProperties = oManager.props();

        //inizializzo array
        var aProperties = []

        var aHidedProp = ["-", "dir", "Directory"];

        if (oProperties.layerProperties.attributes.length >= 1) {
            oProperties.layerProperties.attributes.forEach(function (prop) {
                if (prop.visible = "false") {
                    prop.visible = true
                    prop.hidden = true;
                }
                var oProp = {
                    label: prop.descr,
                    value: prop.selectedEntry.descr
                }

                // if(!aHidedProp.includes(prop.descr)){
                //     if(prop.hidden ){
                //         aProperties.push(oProp)
                //     }
                // }

                if ((!aHidedProp.includes(prop.descr)) && !prop.hidden) {
                    aProperties.push(oProp)
                }
                ;

            })
        }


        // radar a parte
        //se un radar ritorno tooltip radar
        if ((oManager.name().toUpperCase().indexOf('RADAR')) > -1) {
            return oTooltip['RADAR'].concat(aProperties);
        }

        if ((oManager.name().indexOf('MAPPA_PIOGGIA')) > -1) {
            return oTooltip['RAINFALL_FIELD'].concat(aProperties);
        }

        if (layerObj.category == "observation") {

            return oTooltip[layerObj.category].concat(aProperties);

        } else if (layerObj.category == "forecast") {
            if (layerObj.dataid == "WFSNOWROADS") return oTooltip[layerObj.dataid]
            return oTooltip[layerObj.category].concat(aProperties);

        }


        //altrimenti se cè un tooltip pre preparato carico quello
        if (oTooltip[layer.descr]) return oTooltip[layer.descr];

        //altrimenti tooltip di default
        return oTooltip['DEFAULT'];

    }

    oManager.legend = function (callback) {

        //if (oLegend != null) callback(oLegend);
        //controllo se nelle properties cè l'attributo custom legend
        for (var i = 0; i < oManager.props().layerProperties.attributes.length; i++) {
            var attr = oManager.props().layerProperties.attributes[i]
            if (attr.name == 'customLegend') {

                oLegend = {
                    dynPalette: {},
                    type: "DDS_CUSTOM_LEGEND",
                    url: attr.selectedEntry.value,
                    layers: oManager.mapLayer().wmsParams.layers,
                }

                callback(oLegend);
            }
        }

        //chiamo api per sapere se c'è una palette dinamica

        oServices.apiService.get('ddsmap/layerstyle/' + layerObj.server.id + '/' + oManager.mapLayer().options.layers, function (data) {
            // apiService.getExt('http://dds.cimafoundation.org/dewetra2/dewapi/ddsmap/layerstyle/'+ layer.server.id+'/'+mapLayer.options.layers , function (data) {
            // mapLayer.options.layers
            if (debug) console.log(data);

            if (oDynamicPaletteSettings.haveDynamicPalette) {

                var delta = (((oDynamicPaletteSettings.max_value - oDynamicPaletteSettings.min_value) / (data.length - 1))).toFixed(2);

                data.forEach(function (item, index) {
                    item.value = oDynamicPaletteSettings.min_value + (index * delta);
                })

                let oLegend = {
                    aPalette: data,
                    dynPalette: oDynamicPaletteSettings,
                    type: layerObj.type.code.toUpperCase(),
                    url: mapLayer._url,
                    layers: mapLayer.wmsParams.layers,
                }
                if (callback) callback(oLegend);

            } else {
                if (data.length > 1) {

                    var legend = {

                        type: "ADVANCED",
                        legend: [{
                            type: "CUSTOM",
                            title: layerObj.name,
                            palette: []
                        }]

                    }

                    legend.legend.palette = []
                    data.forEach(function (val) {
                        legend.legend[0].palette.push(
                            {
                                label: val.label,
                                color: val.color,
                            }
                        )
                    })

                    if (callback) callback(legend);

                }

                let oLegend = {
                    aPalette: data,
                    dynPalette: {},
                    type: layerObj.type.code.toUpperCase(),
                    url: oManager.mapLayer()._url,
                    layers: oManager.mapLayer().wmsParams.layers,
                }
                if (callback) callback(oLegend);
            }


        }, function (err, head) {
            if (debug) console.log(err);
            aPalette = null;
            oLegend = {
                type: layerObj.type.code.toUpperCase(),
                url: oManager.mapLayer()._url,
                layers: oManager.mapLayer().wmsParams.layers,
            }
            if (callback) {
                callback(oLegend)
            } else return null;


        });

    };

    return oManager;

}
