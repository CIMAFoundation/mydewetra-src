/**
 * Created by Dario Rubado on 15/12/15.
 */

function layerManager_wind(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService) {

    var layer = layerObj;
    var layerData = null;

    var warningInfo = null;

    var mapLayer = null;

    var layerProps = null;

    var props = null;

    var visible = true;

    var theGeoJsonStation = null;

    var arrayAnagrafica = [];

    var loadedJson = null;
    var aggregationType = null;

    var selectedDataType =  0;

    var LowThresholdSet = 1;
    var HighThresholdSet = 1;

    var triggerTime = 18000;

    var timeToUndef = 7200;

    var stringSoglie = "e_";
    var stringValori = "v_";
    var audioCounter = null;

    var urlRegioniMap = "http://dds.cimafoundation.org/sentinel/sentinelapi/aggr/layer/regions_it/";
    var urlProvinceMap = "http://dds.cimafoundation.org/sentinel/sentinelapi/aggr/layer/districts_it/";
    var urlComuniMap = "http://dds.cimafoundation.org/sentinel/sentinelapi/aggr/layer/municipalities_it/";

    var geoJsonRegioni = null;
    var geoJsonProvince = null;
    var geoJsonComuni = null;

    var wsAcquisition = null;

    var upIcon = L.icon({iconUrl: 'apps/dewetra2/img/wind/wind.svg',
        iconSize:     [20, 20]
        // popupAnchor:  [-3, -76]
    })

    var markerWarningOption = {
        radius : iconService.markerWarningOptions.radius,
        weight : iconService.markerWarningOptions.weight,
        color : iconService.markerWarningOptions.color,
        opacity : iconService.markerWarningOptions.opacity,
        fillOpacity: iconService.markerWarningOptions.fillOpacity
    };
    //http://130.251.104.19:15672/#/exchanges/acroweb/amq.topic
    //dario dario4rabbit

    //{
    //    "sensorid": -2147433942,
    //    "stationname": "pippo",
    //    "v_1449843027_3600": 6,
    //    "v_1449843027_0": 6,
    //    "v_1449843027_3600": 6,
    //    "e_1_3": -5
    //}

    var geoServerPalette = iconService.anemometerPalette;

    function palette_wind(data) {

        if (data <= -9998) {
            return 0;
        }else if ((data<=2)) {
            return 1;
        }else if ((data<=6)&&(data>=2)) {
            return 2;
        }else if ((data<=11)&&(data>6)) {
            return 3;
        }else if ((data<=18)&&(data>11)) {
            return 4;
        }else if ((data<=30)&&(data>18)) {
            return 5;
        }else if ((data<=39)&&(data>30)) {
            return 6;
        }else if ((data<=50)&&(data>39)) {
            return 7;
        }else if ((data<=61)&&(data>50)) {
            return 8;
        }else if ((data<=74)&&(data>61)) {
            return 9;
        }else if ((data<=87)&&(data>74)) {
            return 10;
        }else if ((data<=102)&&(data>87)) {
            return 11;
        }else if(data>102) return 12;
    }


    var updateListener = function(){
        console.log("update Listener");
        acEvent.connect('logger', 'logger4dew', function () {
            console.log("Listener connected");
            wsAcquisition = acEvent.subscribe('sentinel.2.#', updateStation)

        },function () {
            console.log('waiting 5 seconds and then reconnect');
            setTimeout(updateListener,5000)
        })

    };

    var oWindData = {
        theGeoJsonStation: null,
        theGeoJsonRegion: null,
        theGeoJsonDistrict:null,
        theGeoJsonComuni:null,
        aAnagrafica: [],
        promise: [],
        audio: function(oldPalette, newPalette){
            //if((newPalette.warning_palette == 1 || newPalette.warning_palette == 2)&&(newPalette.warning_palette > oldPalette.warning_palette)){
            //    audioService.playAudio()
            //    console.log("testaudio")
            //}else if((newPalette.warning_palette == 3 || newPalette.warning_palette == 4)&&(newPalette.warning_palette > oldPalette.warning_palette)){
            //    audioService.playAudio()
            //    console.log("testaudio")
            //}
        },
        anagrafica: function(){
            if (this.aAnagrafica.length == 0){
                for(var s in this.theGeoJsonStation.features){
                    if(!_.isUndefined(this.theGeoJsonStation.features[s].properties)) {
                        try{
                            this.aAnagrafica[this.theGeoJsonStation.features[s].properties.sensorid] = {
                                regione: this.theGeoJsonStation.features[s].properties.region,
                                comune: this.theGeoJsonStation.features[s].properties.munic
                            }
                            this.aAnagrafica[this.theGeoJsonStation.features[s].properties.speed.sensorid] = {
                                regione: this.theGeoJsonStation.features[s].properties.region,
                                comune: this.theGeoJsonStation.features[s].properties.munic
                            }
                        }
                        catch(err){
                            console.log(err);
                            var p = this.theGeoJsonStation.features['move'];
                            // console.log(p)
                        }
                    }
                }
            }
        },
        brintRelevantToFront: function(){

            for(var p in mapLayer._layers){
                if((!angular.isDefined(palette_wind((mapLayer._layers[p].feature.properties.speed)?mapLayer._layers[p].feature.properties.value:1)))){
                    if(mapLayer._layers[p].bringToBack)mapLayer._layers[p].bringToBack();
                }

            }
        },
        checkOldData: function(){
            var promise = null;
            promise = $interval(function () {
                oWindData.checkOldData()
            }, triggerTime);
            oWindData.promise.push(promise);
        },
        delCheckOldData: function () {
            if(oWindData.promise){
                oWindData.promise.forEach(function (promise) {
                    $interval.cancel(promise);
                })
            }
            audioPromise =[]
        },
        setGeoJsonStation: function(json) {
            json.features.forEach(function (features) { //error
                features.properties = oWindData.validateDataByTime(features.properties);
                features.properties = oWindData.palette(features.properties)
            });
            this.theGeoJsonStation= json;
            //build Dictionary anagrafica
            this.anagrafica();
        },
        setTheGeoJsonRegion : function(json){
            this.theGeoJsonRegion = json;
            this.updateTheGeoJsonRegion()
        },
        setTheGeoJsonDistrict : function(json){
            this.theGeoJsonDistrict = json;
            this.updateTheGeoJsonDistrict()
        },
        setTheGeoJsonComuni : function(json){
            this.theGeoJsonComuni = json;
            this.updateTheGeoJsonComune();
        },
        getGeoJsonStation: function () {
            return this.theGeoJsonStation;
        },
        getTheGeoJsonRegion : function(){
            return this.theGeoJsonRegion;
        },
        getTheGeoJsonDistrict : function(){
            return this.theGeoJsonDistrict;
        },
        getTheGeoJsonComuni : function(){
            return this.theGeoJsonComuni;
        },
        updateTheGeoJsonStation : function(aProperties){

            if(aProperties ){
                aProperties.forEach(function (properties) {
                    var o = oWindData.validateDataByTime(properties);

                    o = oWindData.palette(o);


                    var f = _.findIndex(oWindData.theGeoJsonStation.features, function(feature){
                        if (feature.properties.sensorid == o.sensorid ) return true;
                    });

                    if (f > -1) {//se rotation
                        o.updated = true;
                        o.speed = oWindData.theGeoJsonStation.features[f].properties.speed;
                        oWindData.theGeoJsonStation.features[f].properties = o;

                    }else{//se velocita
                        f = _.findIndex(oWindData.theGeoJsonStation.features, function(feature){
                            if (feature.properties.speed.sensorid == o.sensorid) return true;
                        });
                        if (f >-1) {
                            oWindData.theGeoJsonStation.features[f].properties.updated = true
                            oWindData.theGeoJsonStation.features[f].properties.speed = o;
                        }
                    }
                });
                console.log("update feature style");

                oWindData.updateFeatureStyle();
            }else {
                oWindData.theGeoJsonStation.features.forEach(function (station) {
                    var o = oWindData.validateDataByTime(station.properties);
                    o = oWindData.palette(o);
                    station.properties = o;
                });
                oWindData.updateFeatureStyle();
            }

        },

        updateFeatureStyle:function(){

            switch(aggregationType) {
                case "REGIONE":
                    console.log("regione");
                    this.updateTheGeoJsonRegion();
                    this.updateRegionFeaturesStyle();
                    break;
                case "PROVINCE":
                    console.log("province");
                    this.updateTheGeoJsonDistrict();
                    this.updateDistrictFeaturesStyle();
                    break;
                case "COMUNI":
                    this.updateTheGeoJsonComune();
                    this.updateComuniFeaturesStyle();
                    console.log("comuni");
                    break;
                case "STAZIONI":
                    this.updateMarkerStyle();
                    console.log("stazioni");
                    break;
                default:{
                    this.updateMarkerStyle()}
            }
        },

        updateMarkerStyle:function(){
            console.log("update marker style");
            this.theGeoJsonStation.features.forEach(function(station){

                if(!station.properties.updated) return;

                station.properties.updated =  false;

                var indexOfmarker = _.findKey(mapLayer._layers, function (marker) {
                    return (marker.feature.properties.sensorid == station.properties.sensorid||marker.feature.properties.speed.sensorid == station.properties.sensorid)
                });

                if(indexOfmarker > -1){

                    var indexOfGeoJsonStation = _.findIndex(oWindData.theGeoJsonStation.features, function(feature){
                        if (feature.properties.sensorid == station.properties.sensorid || feature.properties.speed.sensorid == station.properties.sensorid ) return true;
                    });

                    // console.log("indexOfGeoJsonStation: "+indexOfGeoJsonStation);

                    if(indexOfGeoJsonStation > -1){
                        // console.log(oWindData.theGeoJsonStation.features[indexOfGeoJsonStation].properties.stationname);
                        var val = palette_wind((oWindData.theGeoJsonStation.features[indexOfGeoJsonStation].properties.speed)?oWindData.theGeoJsonStation.features[indexOfGeoJsonStation].properties.speed.value:1)

                        if(!angular.isDefined(val)) val = 0;

                        var icon = L.icon({
                                iconUrl: 'http://mydewetratest.cimafoundation.org/apps/dewetra2/img/wind/wind_'+val+'.png',
                                iconSize:  [30, 30]
                            })

                        mapLayer._layers[indexOfmarker].setIcon(icon);

                        mapLayer._layers[indexOfmarker].setRotationAngle(oWindData.theGeoJsonStation.features[indexOfGeoJsonStation].properties.value)

                        mapLayer._layers[indexOfmarker].feature.properties = oWindData.theGeoJsonStation.features[indexOfGeoJsonStation].properties;

                        // var latlng = mapLayer._layers[indexOfmarker].getLatLng();

                        // console.log("MARKER ");

                        // var test = L.marker(latlng).addTo(mapLayer);

                        var promise =

                        // console.log(test);

                        // var icon = L.icon({
                        //     iconUrl: 'apps/dewetra2/img/wind/wind_'+val+'.png',
                        //     iconSize:     [30, 30]
                        // })
                        //
                        // var latlng = mapLayer._layers[indexOfmarker].getLatLng();
                        // var feature = mapLayer._layers[indexOfmarker].feature;
                        // feature.properties = station.properties;
                        //
                        // mapLayer.removeLayer(mapLayer._layers[indexOfmarker]);
                        //
                        // var marker = L.marker(latlng, {icon: L.icon({
                        //     iconUrl: 'apps/dewetra2/img/wind/wind_'+val+'.png',
                        //     iconSize:     [30, 30]
                        // }),rotationAngle : oWindData.theGeoJsonStation.features[indexOfGeoJsonStation].properties.value}).addTo(mapLayer);
                        // marker.feature = feature;
                        //
                        // marker.feature.properties.updated = false;
                        // marker.addTo(mapLayer);

                        console.log("added marker:"+ mapLayer._layers[indexOfmarker].feature.properties.stationname);

                    }else  {
                        console.log("error");
                    }




                }
            });
        },

        updateRegionFeaturesStyle:function(){

            this.theGeoJsonRegion.features.forEach(function(region){

                var f = _.findKey(mapLayer._layers, function (marker) {
                    if (marker.feature.properties.gid == region.properties.gid) return true;
                });
                if(f>-1){
                    mapLayer._layers[f].properties = region;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[region.properties.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity
                        })
                }
            });
        },

        updateDistrictFeaturesStyle:function(){

            this.theGeoJsonDistrict.features.forEach(function(province){

                var f = _.findIndex(mapLayer._layers, function (marker) {
                    if (marker.properties.district == province.gid) return true;
                });
                if(!_.isUndefined(f)){
                    if((province.warning_palette == 1 || province.warning_palette == 2)&&(province.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }else if((province.warning_palette == 3 || province.warning_palette == 4)&&(o.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }

                    mapLayer._layers[f].properties = province;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[province.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity
                        })
                }
            });
        },

        updateComuniFeaturesStyle:function(){

            this.theGeoJsonComuni.features.forEach(function(comune){

                var f = _.findIndex(mapLayer._layers, function (marker) {
                    if (marker.properties.munic == comune.gid) return true;
                });
                if(!_.isUndefined(f)){
                    if((comune.warning_palette == 1 || comune.warning_palette == 2)&&(comune.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }else if((comune.warning_palette == 3 || comune.warning_palette == 4)&&(o.warning_palette > mapLayer._layers[f].properties.warning_palette)){
                        audioService.playAudio()
                    }

                    mapLayer._layers[f].properties = comune;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[comune.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity
                        })
                }
            });
        },

        updateTheGeoJsonRegion: function () {

            var regionGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.region;
            });

            this.theGeoJsonRegion.features.forEach(function(feature){

                var warnIndexRegional = _.max(regionGroup[feature.properties.gid], function (station) {
                    var p = station.properties.warning_palette;
                    return p;
                });
                feature.properties.warning_palette = warnIndexRegional.properties.warning_palette;
            });
        },

        updateTheGeoJsonDistrict: function () {

            var districtGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.district;
            });

            this.theGeoJsonDistrict.features.forEach(function(feature){

                var warnIndexDistrict = _.max(districtGroup[feature.properties.gid], function (station) {
                    var p = station.properties.warning_palette;
                    return p;
                });
                feature.properties.warning_palette = warnIndexDistrict.properties.warning_palette;
            });
        },

        updateTheGeoJsonComune: function () {

            var municGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.munic;
            });

            this.theGeoJsonComuni.features.forEach(function(feature){
                if(municGroup[feature.properties.gid]){
                    var warnIndexMunic = _.max(municGroup[feature.properties.gid], function (station) {
                        var p = station.properties.warning_palette;
                        return p;
                    });
                    feature.properties.warning_palette = warnIndexMunic.properties.warning_palette;
                }else feature.properties.warning_palette = -1



            });
        },

        validateDataByTime: function(properties){
            return properties

            //se sono nel passato come ora di riferimento per validare i dati prendo quella di caricamento del layer
            var iServerTime =(menuService.isRealTime())? menuService.getUtcServerDateInSecond():menuService.getDateToUTCSecond();

            if (properties.sensorid == -2147462361){
                //console.log(properties)
            }

            var aValori = [];

            for (var prop in properties) {
                if (stringStartsWith(prop, stringValori)) {
                    var aValore = prop.split("_");

                    var oValore = {
                        timestamp: parseInt(aValore[1]),
                        period: parseInt(aValore[2]),
                        valore: parseFloat(properties[prop])
                    };
                    aValori.push(oValore);
                }
            }

            if (aValori.length == 0) return properties;
            var oMostRecentValue = _.max(aValori, function (valore) {
                return valore.timestamp;
            });
            if ((iServerTime - oMostRecentValue.timestamp) > timeToUndef) {
                var obj = {};
                for (var prop in properties) {
                    if (!stringStartsWith(prop, stringValori) &&(!stringStartsWith(prop, stringSoglie))) {
                        obj[prop] = properties[prop];
                    }
                }
                return obj;
            } else return properties;
        },
        palette: function(oProperties) {


            for (var prop in oProperties) {
                if (stringEndsWith(prop, "_"+selectedDataType.toString())) {
                    oProperties.value = oProperties[prop];
                }
            }

            for (var prop in oProperties.speed) {
                if (stringEndsWith(prop, "_"+selectedDataType.toString())) {
                    oProperties.speed.value = oProperties.speed[prop];
                }
            }

            return oProperties;
        }
    };


    var geoServerPalette = iconService.anemometerPalette;
    /**
     * function that manage aggregation type and call the righ one
     * @param objprops object passed by properties layer controller
     * @param data object passed by properties layer controller
     * @param onFinish function reset layer manager passed in layerlist controller
     */
    function update(objprops, data, onFinish){


        if(selectedDataType != data.raingaugeDataType.value){
            selectedDataType = data.raingaugeDataType.value;
            oWindData.updateTheGeoJsonStation()
        }

        //if (data){
        //    //aggregationType = data.type;
        //    //aggregationType = data.aggregation.type;
        //    selectedDataType = data.raingaugeDataType.value;
        //    //HighThresholdSet = data.threshold.high.id;
        //    //LowThresholdSet = data.threshold.low.id;
        //}



        props = objprops;
        //switch(aggregationType) {
        //    case "REGIONE":
        //        console.log("regione");
        //        loadRegioniJson(props,loadRegioniLayer, onFinish);
        //        break;
        //    case "PROVINCE":
        //        console.log("province");
        //        loadProvinceJson(props, loadProvinceLayer, onFinish);
        //        break;
        //    case "COMUNI":
        //        loadComuniJson(props, loadComuniLayer, onFinish)
        //        console.log("comuni");
        //        break;
        //    case "STAZIONI":
        //        loadStazioniJson(loadStazioniLayer, onFinish)
        //        console.log("stazioni");
        //        break;
        //    default:loadStazioniJson(loadStazioniLayer, onFinish);
        //
        //}

    }

    /**
     * callback that reload station layer whan aggregation is changed
     * @param onFinish function reset layer manager passed in layerlist controller
     * @returns {*}
     */

    function loadStazioniLayer(onFinish){
        mapService.removeLayer(mapLayer);

        mapLayer = mapService.addGeoJsonLayer(oWindData.getGeoJsonStation(), layer['descr'], {

            pointToLayer: function(feature, latlng) {

                var geojsonMarkerOptions = {
                    radius: markerWarningOption.radius,
                    fillColor: geoServerPalette[feature.properties.warning_palette],
                    color: "#000",
                    weight: markerWarningOption.weight,
                    opacity: markerWarningOption.opacity,
                    fillOpacity: markerWarningOption.fillOpacity
                };

                return L.circleMarker(latlng, geojsonMarkerOptions);

            }

        }, stationClickListener,stationMouseOverListener, stationMouseOutListener);



        if(onFinish) onFinish()

    }

    /**
     * callback called when the Regioni aggregation is poed
     * @param url object
     * @param okCallback function LoadProvinceLayer
     * @param onFinish function risetto layer manager
     * @returns {*}
     */

    function loadRegioniJson(props, okCallback, onFinish){

        if(oWindData.theGeoJsonRegion){

            if(okCallback) okCallback(onFinish)

        }else
        {
            apiService.getExt(urlRegioniMap, function (data) {


                oWindData.setTheGeoJsonRegion(data);
                oWindData.updateTheGeoJsonRegion();
                //geoJsonRegioni = data;

                if(okCallback) okCallback(onFinish)
            })
        }


    }

    /**
     * callback called when the province aggregation is loaded
     * @param url object
     * @param okCallback function LoadProvinceLayer
     * @paramonFinish function risetto layer manager
     * @returns {*}
     */

    function loadProvinceJson(url, okCallback, onFinish) {


        if(oWindData.theGeoJsonDistrict){

            if(okCallback)okCallback(onFinish);
        }else{
            apiService.getExt(urlProvinceMap, function (data) {

                oWindData.setTheGeoJsonDistrict(data);
                oWindData.updateTheGeoJsonDistrict();
                if(okCallback) okCallback(onFinish)

            })
        }

    }

    /**
     * callback called when the comuni aggregation is loaded
     * @param url object
     * @param okCallback function LoadComuniLayer
     * @param onFinish function risetto layer manager
     * @param returns {*}
     */

    function loadComuniJson(url, okCallback, onFinish) {

        if(geoJsonComuni){

            if(okCallback)okCallback(onFinish);
        }else{
            apiService.getExt(urlComuniMap, function (data) {


                //geoJsonComuni = data;
                oWindData.setTheGeoJsonComuni(data);
                oWindData.updateTheGeoJsonComune();
                if(okCallback) okCallback(onFinish)

            })
        }
    }

    /**
     * callback called when the geojson of the region is loaded
     * @returns {*}
     */

    function loadRegioniLayer(onFinish){


        mapService.removeLayer(mapLayer);

        mapLayer = mapService.addGeoJsonLayer(oWindData.getTheGeoJsonRegion(), layer['descr'],{

            onEachFeature: function(feature, layer) {

                //if (feature.properties && feature.properties.NOME_REG) {
                //    layer.bindPopup(feature.properties.NOME_REG);
                //}

            }

        }, regionClickListener, stationMouseOverListener, stationMouseOutListener);
        mapLayer.setStyle(function(feature) {
            // console.log(feature);
            var colorIndex = feature.properties.warning_palette;

            return {
                fillColor: geoServerPalette[colorIndex],
                color : geoServerPalette[colorIndex],
                opacity : 0.8,
                fillOpacity: 0.8

            }
        });
        if(onFinish)onFinish();

    }

    /**
     * callback called when the geojson of the province is loaded
     * @param onFinish callback re set layer manager from layer list controller
     * @returns {*}
     */
    function loadProvinceLayer(onFinish){

        mapService.removeLayer(mapLayer);

        mapLayer = mapService.addGeoJsonLayer(oWindData.getTheGeoJsonDistrict(), layer['descr'], null, provinciaClickListener, stationMouseOverListener, stationMouseOutListener);
        mapLayer.setStyle(function(feature) {

            var colorIndex = feature.properties.warning_palette;
            return {
                fillColor: geoServerPalette[colorIndex],
                color : geoServerPalette[colorIndex],
                opacity : 0.8,
                fillOpacity: 0.8

            }
        });
        if(onFinish)onFinish()
    }

    /**
     * callback called when the geojson of the municipality is loaded
     * @param onFinish
     */
    function loadComuniLayer(onFinish){

        mapService.removeLayer(mapLayer);

        //non funziona style da fare nel frattempo uso

        mapLayer = mapService.addGeoJsonLayer(oWindData.getTheGeoJsonComuni(), layer['descr'], comuneClickListener, stationMouseOverListener, stationMouseOutListener);
        //mapLayer.addData(geoJsonRegioni)

        mapLayer.setStyle(function(feature) {
            //console.log(feature);
            var colorIndex = feature.properties.warning_palette;


            return {
                fillColor: warningsPalette[colorIndex],
                color : warningsPalette[colorIndex],
                opacity : 0.8,
                fillOpacity: 0.8

            }
        });
        if(onFinish)onFinish()
    }


    /**
     * callback called when the geojson of the station layer is called
     * @param onFinish callback re set layer manager from layer list controller
     * @returns {*}
     */
    function loadStazioniJson(okCallback, onFinish){

        if(okCallback) okCallback(onFinish)
    }





    /**
     * Fuction for async update layer
     * @param data
     */
    function updateStation(data){



        // console.log("sensor update iteration");
        var windData = [];
        //console.log(data);


        if(_.isArray(data)){
            windData = _.filter(data, function (station) {
                if (oWindData.aAnagrafica[station.sensorid]) return true;
            })
        }else{
            if (oWindData.aAnagrafica[data.sensorid]) windData.push(data);
        }




        //console.log( termoData)

        if (windData.length > 0){
            console.log("WIND SENSOR: " + windData.length + " sensor to Update");
            //console.log(termoData);
            // console.log("update the geoJson");
            oWindData.updateTheGeoJsonStation(windData);

        }

    }


    /**
     * Get Region by station id
     * @param feature int id
     * @return string Regione
     * */
    function getRegionByStationId(stationId){
        return arrayAnagrafica[stationId].regione;
    }

    /**
     * Get Region by station id
     * @param feature int id
     * @return string Provincia
     * */
    function getProvinciaByStationId(stationId){
        return arrayAnagrafica[stationId].provincia;
    }

    /**
     * Get Comune by station id
     * @param feature int id
     * @return string Comune
     * */
    function getComuneByStationId(stationId){
        return arrayAnagrafica[stationId].comune;
    }



    /**
     * callback called when the region features si clicked
     * @param s object
     * @returns {*}
     */
    function regionClickListener(s) {
        console.log(s.target.feature.properties.NOME_REG);
        s.target.bindPopup(s.target.feature.properties.NOME_REG).openPopup();
    }

    /**
     * callback called when the region features si clicked
     * @param s object
     * @returns {*}
     */
    function provinciaClickListener(s) {
        //console.log(s.target.feature.properties.NOME_REG)
        s.target.bindPopup(s.target.feature.properties.NOME_PRO).openPopup();
    }

    /**
     * callback called when the region features si clicked
     * @param s object
     * @returns {*}
     */
    function comuneClickListener(s) {
        console.log(s.target.feature.properties.NOME_COM);
        s.target.bindPopup(s.target.feature.properties.NOME_COM).openPopup();
    }

    /**
     * mouse listener
     * @param feature object
     * @return *
     * */
    function stationMouseOverListener(s){

        try{
            if(warningInfo){
                warningInfo.mouseOver('WIND',mapLayer._leaflet_id, s.target.feature.properties, geoServerPalette)
            }
        }catch(err){
            alert("errot thresholdInfo.mouseOver")
        }
    }

    function stationMouseOutListener(s){
        try{
            if(warningInfo){
                warningInfo.mouseOut('WIND',mapLayer._leaflet_id)
            }

        }catch(err){
            alert("errot thresholdInfo.mouseOver")
        }
    }

    /**
     * build html popup
     * @param markerProperties
     * @returns {*}
     */
    function buildPopUp(markerProperties){
        var aStringheSoglie = [];
        for(var prop in markerProperties){
            if (stringStartsWith(prop, stringSoglie)){
                var aSoglia = prop.split("_");
                var sRiga = "N Soglia:"+aSoglia[1]+" - valore:"+markerProperties[prop]+" Livello attenzione: " +aSoglia[2];
                console.log(sRiga);
                aStringheSoglie.push(sRiga);
            }
        }
        var popUpHtml = '';
        aStringheSoglie.forEach(function(soglia){
            var p = '<p>' + soglia + '</p>';
            popUpHtml.concat(p);
        });
        return popUpHtml
    }

    function showChart(sensorId, dbId,speedSensorId, speedDbId) {
        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/sensor_chart_form.html',
            controller: 'sensorChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sensorData: function () {

                    var featureData = props;

                    return {
                        sensorId: sensorId,
                        dbId: dbId,
                        sensorClass: 10,
                        speed:{
                            sensorId: speedSensorId,
                            dbId: speedDbId,
                            sensorClass: 11,
                        }
                    };

                }

            }
        });
    }

    /**
     * function load chart
     * @param s
     */
    function stationClickListener(s) {
        showChart(s.target.feature.properties.sensorid, s.target.feature.properties.dbid,s.target.feature.properties.speed.sensorid, s.target.feature.properties.speed.dbid);
    }



    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },


        load: function(onFinish) {

            console.log("WIND Punctual");
            if (!menuService.isRealTime() && wsAcquisition != null) this.removeListener();
            var data;
            sentinelService.getNationalWindSpeed(function(speedData) {

                sentinelService.getNationalWindDirection(function (directionData) {
                    //console.log(directionData);

                    directionData.features.forEach(function (directionStation) {

                        var index = _.findKey(speedData.features, function (speedFeature) {
                            return (speedFeature.properties.stationid == directionStation.properties.stationid)
                        })
                        if (index > -1 && !directionStation.properties.direction) {
                            directionStation.properties.speed = speedData.features[index].properties;
                        };
                    })

                    data = directionData;

                    if (mapLayer) mapService.removeLayer(mapLayer);

                    oWindData.setGeoJsonStation(data);

                    mapLayer = mapService.addGeoJsonLayer(oWindData.getGeoJsonStation(), layer['descr'], {

                        pointToLayer: function(feature, latlng) {

                            return iconService.wind_Icon(feature, latlng)

                        }

                    }, stationClickListener,stationMouseOverListener, stationMouseOutListener);

                    oWindData.brintRelevantToFront();
                    if (onFinish) onFinish()

                    // //connetto a messaggistica il layer
                    updateListener()
                })
            })


        },

        updateListener: function(){
            console.log("update Listener");
            acEvent.connect('logger', 'logger4dew', function () {
                wsAcquisition = acEvent.subscribe('sentinel.2', updateStation)

            },function () {
                console.log('waiting 5 seconds and then reconnect');
                setTimeout(this.updateListener,5000)
            })

        },

        removeListener: function () {
            acEvent.unsubscribe(wsAcquisition);
            wsAcquisition = null;
            console.log("unsubscribe")
        },

        remove: function (layer, onFinish) {
            this.removeListener();
            oWindData.delCheckOldData();
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.name
        },

        descr: function () {
            return layer.descr
        },

        dateLine:function () {
            return "ANEMOMETER";
        },

        onDateChange : function (callBack) {
            //ricarico il layer se è nel passato fa tutto il load
            this.load(callBack)
        },

        setVisible: function (b,callBack) {

            var manager = this;
            visible = b;
            if (!b) mapLayer.clearLayers();
            else this.update(null,null, function () {
                if(manager){mapService.oLayerList.updateLayer(manager,null);}
                if(callBack)callBack()
            } );

        },

        isVisible:function(){
            return visible;
        },

        typeDescr: function () {
            return "RAINGAUGE_LAYER_" + this.descriptionCumulata();
        },

        haveAudio: function(){
            return false
        },

        geoServerPalette: geoServerPalette,

        legend:function () {

            return{
                type:layerObj.type.code.toUpperCase(),
                palette:geoServerPalette
            }
        },

        descriptionCumulata: function(){
            var s = selectedDataType/3600;
            s = "CUM" + s.toString() + "H";
            return s
        },

        draggable: function () {
            return false;
        },

        setWarningInfo: function (wi) {
            warningInfo = wi
        },

        update: function (props, data, onFinish) {
            if (data){
                aggregationType = data.type;
            }

            switch(aggregationType) {
                case "REGIONE":
                    console.log("regione");
                    loadRegioniJson(urlRegioniMap,loadRegioniLayer);
                    break;
                case "PROVINCE":
                    console.log("province");
                    loadProvinceJson(urlProvinceMap, loadProvinceLayer);
                    break;
                case "COMUNI":
                    loadComuniJson(urlComuniMap, loadComuniLayer);
                    console.log("comuni");
                    break;
                case "STAZIONI":
                    loadStazioniJson(loadStazioniLayer);
                    console.log("stazioni");
                    break;
                default:loadStazioniJson(loadStazioniLayer);

            }
            if(onFinish) onFinish();
        },

        props: function (){
            var aggregation = [
                {
                    type : "REGIONE",
                    'selected': false,
                    description : "AGGREGAZIONE_REGIONALE",
                    dataId : "dew:Regions_ISTAT2010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms",
                    completeUrl:"http://geoserver.cimafoundation.org/geoserver/dew/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=dew:Regioni_ISTAT2008&maxFeatures=50&outputFormat=json"
                },
                {
                    type : "PROVINCE",
                    'selected': false,
                    description : "AGGREGAZIONE_PROVINCIALE",
                    dataId : "dew:Districts_ISTAT2010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms"
                },
                {
                    type : "COMUNI",
                    'selected': false,
                    description : "AGGREGAZIONE_COMUNALE",
                    dataId : "dew:Municipalities_ISTAT12010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms"
                },
                {
                    type : "STAZIONI",
                    'selected': true,
                    description : "AGGREGAZIONE_STAZiONI",
                    dataId : "dew:Municipalities_ISTAT12010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms"
                }
            ];
            var soglie = {
                low: {
                    id: 1,
                    type: "Low Threshold",
                    description: "Low Threshold",
                    list: [
                        {
                            'id': 1,
                            'selected': true,
                            'description': "+/-5 Deg. C"
                        },
                        {
                            'id': 2,
                            'selected': false,
                            'description': "+/-8 Deg. C"
                        },
                        {
                            'id': 3,
                            'selected': false,
                            'description': "+/-10 Deg. C"
                        }
                    ]
                },
                high: {
                    id: 2,
                    type: "High Threshold",
                    description: "High Threshold",
                    list: [
                        {
                            'id': 1,
                            'selected': true,
                            'description': "+/-10 Deg. C"
                        },
                        {
                            'id': 2,
                            'selected': false,
                            'description': "+/-12 Deg. C"
                        },
                        {
                            'id': 3,
                            'selected': false,
                            'description': "+/-15 Deg. C"
                        }
                    ]
                }
            };
            var dataType = [
                {
                    id:1,
                    type: "lasth",
                    value : 0,
                    description:"CUMULATA_LAST_H",
                    selected: true
                },
                {
                    id:1,
                    type: "cum1h",
                    value : 3600,
                    description:"CUMULATA_1_H",
                    selected: false
                },
                {
                    id:2,
                    type: "cum3h",
                    value : 10800,
                    description:"CUMULATA_3_H",
                    selected: false
                },
                {
                    id:3,
                    type: "cum6h",
                    value : 21600,
                    description:"CUMULATA_6_H",
                    selected: false
                },
                {
                    id:4,
                    type: "cum12h",
                    value : 43200,
                    description:"CUMULATA_12_H",
                    selected: false
                },
                {
                    id:5,
                    type: "cum24h",
                    value : 86400,
                    description:"CUMULATA_24_H",
                    selected: false
                }
            ];
            var props ={
                //aggregation : aggregation
                //threshold : soglie
                raingaugeDataType : dataType
            };
            if (aggregationType){
                props.aggregation.forEach(function (a) {
                    if (aggregationType == a.type){
                        a.selected = true
                    } else a.selected = false
                })
            }

            if (selectedDataType){
                props.raingaugeDataType.forEach(function (a) {
                    if (selectedDataType == a.value){
                        a.selected = true
                    } else a.selected = false
                })
            }



            return props
        },

        getCum : function(){
            return aggregationType;
            //return second in number cumulated
        },

        soglie : function(){
            var setSoglie=[
                {
                    type: "",
                    description: "",
                    soglie:[
                        {
                            descr:"+/-5 Deg. C"
                        },
                        {
                            descr:"+/-8 Deg. C"
                        },
                        {
                            descr:""
                        }

                    ]

                }
            ]
        },

        layerProps: layerProps,

        layerTooltip: function(){

            var manager = this;
            var layerDelay = function (layerManagerObj) {



                try{
                    var oReferenceDate = layerManagerObj.dateRef().utc().toDate()
                }catch(err){
                    return layerManagerObj.descr()
                }

                // Get Now
                var oDate = new Date();

                //console.log("Now  = " + oDate);
                //console.log("Ref  = " + oReferenceDate);

                // Compute time difference
                var iDifference = oDate.getTime()-oReferenceDate.getTime();

                // How it is in minutes?
                var iMinutes = 1000*60;

                var iDeltaMinutes = Math.round(iDifference/iMinutes);

                var sTimeDelta = "";

                if (iDeltaMinutes<60) {
                    // Less then 1h
                    sTimeDelta += iDeltaMinutes + " min. fa";
                }
                else if (iDeltaMinutes< 60*24) {
                    // Less then 1d
                    var iDeltaHours =  Math.round(iDeltaMinutes/60);
                    sTimeDelta += iDeltaHours + " ore fa";
                }
                else {
                    // More than 1d
                    var iDeltaDays =  Math.round(iDeltaMinutes/(60*24));
                    sTimeDelta += iDeltaDays + " giorni fa";
                }

                return sTimeDelta;
            };
            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : manager.name()
                },
                // {
                //     label : "LAYER_DESCRIPTION",
                //     value : manager.descr()
                // },
                // {
                //     label : "CUMULATA_H",
                //     value : manager.descriptionCumulata()
                // }

            ];
            return tooltipObj;
        },

        setOpacity : function(value){

            if (value){
                markerWarningOption.opacity = value;
                markerWarningOption.fillOpacity = value;
                oWindData.updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return markerWarningOption.opacity
        },

        showProps: function (onFinish) {
            return;
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties_warning_pluvio.html',
                //templateUrl: 'apps/dewetra2/views/layer_properties.html',
                controller: "warningPluvioPropertiesController",
                //controller: "layerPropertiesController",
                size: "lg",
                resolve: {
                    params: function() {
                        return {
                            layer: mapLayer
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj.props, obj.data, onFinish)

            }, function () {
                console.log("CANCEL")
            });
        },

        // resizeOnZoomEnd:function (zoom) {
        //
        //     var value = {
        //         2:10,
        //         3:10,
        //         4:10,
        //         5:10,
        //         6:20,
        //         7:20,
        //         8:20,
        //         9:20,
        //         10:30,
        //         11:30,
        //         12:30,
        //         13:40,
        //         14:40
        //     }
        //
        //     var radiusValue = (angular.isDefined(value[zoom]))?value[zoom]:30;
        //
        //     for(var f in mapLayer._layers){
        //
        //         var val = iconService.windPalette((mapLayer._layers[f].feature.properties.speed)?mapLayer._layers[f].feature.properties.speed.value:1);
        //
        //         if(angular.isUndefined(val)) val=0;
        //
        //         var icon = L.icon({
        //             iconUrl: 'http://mydewetratest.cimafoundation.org/apps/dewetra2/img/wind/wind_'+val+'.png',
        //             iconSize:  [radiusValue, radiusValue]
        //         })
        //
        //         mapLayer._layers[f].setIcon(icon);
        //
        //         mapLayer._layers[f].setRotationAngle(mapLayer._layers[f].feature.properties.value);
        //
        //     }
        //
        // },

        showChart: showChart,

        thirdLine:function(){
            return ""
        },

        getVariable:function () {
            return ""
        },

        getAggregation:function () {
            return ""
        }

    }

}
