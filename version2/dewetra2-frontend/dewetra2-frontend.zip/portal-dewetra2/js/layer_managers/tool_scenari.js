/**
 * Created by Dario Rubado on 29/08/18.
 */
function tool_scenari(ModelData,  $uibModal, onClose) {

    console.log(ModelData.manager);

    var modalInstance = $uibModal.open({

        templateUrl: 'apps/dewetra2/views/scenari_docked.html',
        controller: 'scenariControllerDocked',
        size: 'lg',
        keyboard: false,
        windowClass:"scenario_general "+ModelData.manager,
        windowTopClass:"scenario_general "+ModelData.manager,
        backdrop:false,
        resolve: {

            model: function () {

                return {
                    toolData:ModelData,
                    onClose : onClose
                };

            }
        }
    });

    return{
        modalIstance : modalInstance
    }
}


function tool_scenari_erra_docked(ModelData,  $uibModal, onClose) {

    console.log(ModelData.manager);

    var modalInstance = $uibModal.open({

         templateUrl: 'apps/dewetra2/views/scenari_docked_erra.html',
        //templateUrl: 'apps/dewetra2/views/scenari_docked_world.html',
        controller: 'scenariControllerDockedErra',
        size: 'lg',
        keyboard: false,
        windowClass:"scenario_general scenari_anywhere "+ModelData.manager,
        windowTopClass:"scenario_general scenari_anywhere "+ModelData.manager,
        backdrop:false,
        resolve: {

            model: function () {

                return {
                    toolData:ModelData,
                    onClose : onClose
                };

            }
        }
    });

    return{
        modalIstance : modalInstance
    }
}

// function tool_scenari_erra_docked(ModelData,  $uibModal, onClose) {
//
//     console.log(ModelData.manager);
//
//     var modalInstance = $uibModal.open({
//
//         // templateUrl: 'apps/dewetra2/views/scenari_docked_erra.html',
//         templateUrl: 'apps/dewetra2/views/scenari_docked_world.html',
//         controller: 'scenariControllerDockedErra',
//         size: 'lg',
//         keyboard: false,
//         windowClass:"scenario_general scenari_anywhere "+ModelData.manager,
//         windowTopClass:"scenario_general scenari_anywhere "+ModelData.manager,
//         backdrop:false,
//         resolve: {
//
//             model: function () {
//
//                 return {
//                     toolData:ModelData,
//                     onClose : onClose
//                 };
//
//             }
//         }
//     });
//
//     return{
//         modalIstance : modalInstance
//     }
// }


// width: 400px;
// right: 0;
// left: inherit;


function tool_scenari_anywhere(ModelData, $uibModal, onClose) {
    var manager = tool_scenari(ModelData, $uibModal, onClose);
    return manager;
}

function tool_scenari_scenari(ModelData, $uibModal, onClose) {
    var manager = tool_scenari(ModelData, $uibModal, onClose);
    return manager;
}

function tool_scenari_erra(ModelData, $uibModal, onClose) {
    var manager = tool_scenari_erra_docked(ModelData, $uibModal, onClose);
    return manager;
}

function tool_scenari_world(ModelData, $uibModal, onClose) {
    var manager = tool_scenari_world_docked(ModelData, $uibModal, onClose);
    return manager;
}

/**
 * Created by Dario Rubado on 18/12/15.
 */

dewetraApp.controller('scenariController',[ '$scope','$window','$location','$anchorScroll', '$uibModal', '$uibModalInstance','model', '$translate',  'menuService', 'serieService', 'sentinelService', 'thresholdService','_', '$timeout', '$rootScope', '$sce', 'iconService', 'apiService','toolsService', '$location', 'mapService' ,'$anchorScroll','acLogbook', 'printService',function($scope,$window,$location,$anchorScroll, $uibModal, $uibModalInstance,model, $translate,  menuService, serieService, sentinelService, thresholdService,_, $timeout, $rootScope, $sce, iconService, apiService,toolsService, $location ,$anchorScroll,acLogbook, printService) {

    acLogbook.logActivity('Dewetra2-Scenario', 'Loaded Scenario');

    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    });

    var oMap, oFeatureLayer, oPolygon, oPost;

    $scope.bLayerList = true;


    /**
     * Init Map
     */
    var initMap = function () {


        oFeatureLayer = L.featureGroup();

        var osmBasic = L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 18
        });
        oMap = L.map('scenari',
            {
                //zoomControl:false,
                // scrollWheelZoom:false,
                //tap:false,
                boxZoom:false
            });
            // }).setView([44, 8], 13);

        osmBasic.addTo(oMap);

        oFeatureLayer.addTo(oMap);

        //Draw
        var editableLayers = new L.FeatureGroup();

        oMap.addLayer(editableLayers);


        var options = {
            position: 'topright',
            draw: {
                polygon: {
                    allowIntersection: false, // Restricts shapes to simple polygons
                    drawError: {
                        color: '#e1111b', // Color the shape will turn when intersects
                        message: '<strong>Oh snap!<strong> you can\'t draw that!' // Message that will show when intersect
                    },
                    shapeOptions: {
                        color: '#2c38f3'
                    }
                },
                polyline:false,
                circle:false,
                rectangle:false,
                marker:false,
            },
            edit: {
                featureGroup: editableLayers, //REQUIRED!!
                remove: true
            }
        };

        var optionsOnlyEdit = {
            position: 'topright',
            draw: false,
            edit: {
                featureGroup: editableLayers, //REQUIRED!!
                remove: true
            }
        };

        var drawControl = new L.Control.Draw(options);
        var drawControlOnlyEdit = new L.Control.Draw(optionsOnlyEdit);

        oMap.on('draw:created', function(e) {
            var type = e.layerType,
                layer = e.layer;

            editableLayers.addLayer(layer);
            oPolygon = layer;
            //
            // drawControl.removeFrom(oMap);
            // drawControlOnlyEdit.addTo(oMap)
            //
            // $scope.loadFilteredFeatures()
        });

        // oMap.on("draw:edited", function(e ){
        //     oPolygon = e.layer;
        //
        //     oFeatureLayer.clearLayers()
        //
        //     $scope.loadFilteredFeatures()
        // });

        // oMap.on("draw:deleted", function(e ){
        //     drawControlOnlyEdit.removeFrom(oMap);
        //     drawControl.addTo(oMap);
        //
        //     oFeatureLayer.clearLayers();
        //     oPolygon = null;
        // });



        oMap.addControl(drawControl);

        //draw end

        toolsService.getToolById(model.toolData.toolId, function (data) {

            var southWest = L.latLng($rootScope.acSession.hat.domain.lats, $rootScope.acSession.hat.domain.lonw),
                northEast = L.latLng($rootScope.acSession.hat.domain.latn, $rootScope.acSession.hat.domain.lone),
                bounds = L.latLngBounds(southWest, northEast);
            oMap.fitBounds(bounds);

            data.config.layers.forEach(function (o) {
                o.checked = false;
            });
            $scope.aoLayers = data.config.layers;

        })


        // var data = [{name: "Moroni", age: 50} ,{name: "pippo", age: 50},{name: "Moroni", age: 50},{name: "pluti", age: 50}];
        // $scope.tableParams = new NgTableParams({
        //     // initial filter
        //     // filter: { country: "Ecuador" }
        //     count:4
        // }, {
        //     data: data
        // });
        // console.log($scope.tableParams)

    };



    $scope.toggleLayer = function(oLayer){

        oLayer.checked = !oLayer.checked;

        if (oLayer.checked){
            oLayer.oMapLayer = L.tileLayer.wms(oLayer.wmsServer, {
                layers: oLayer.wmsId,
                format: 'image/png',
                transparent: true,
                maxZoom: 24,
            }).addTo(oMap).bringToFront();

        }else {
            oMap.removeLayer(oLayer.oMapLayer);
        }

        try {
            if (oPolygon.hasOwnProperty("_latlngs")){
                $scope.loadFilteredFeatures();
            }
        }catch (e) {
            console.log(e)
        }

    };

    $scope.isUpdateActive = function(){
        try {
            if (oPolygon.hasOwnProperty("_latlngs")){
                var hasLayer = false;
                $scope.aoLayers.forEach(function (layer) {
                    if(layer.checked){
                        hasLayer = true;
                    }
                });
                return hasLayer;
            } return false
        }catch (e) {
            console.log(e);
            return false
        }

    };

    $scope.buildFeaturesTable = function(){

        $scope.aoFeatureLayers = oFeatureLayer.getLayers();


    };

    $scope.buildArrayForNgTable = function(aoLayers){
        for(var key in aoLayers){
            aoLayers[key].feature.properties
        }
    };




    $scope.selectedLayerInTable = function(oLayerSelected){



        $scope.aoFeatureLayers.forEach(function(oLayer){
            oLayer.active = false;
        });
        oLayerSelected.active = true;

        $scope.oFeaturesInTable = oLayerSelected._layers;

        console.log($scope.oFeaturesInTable);

        // $scope.aoNgTable = [];
        //
        // for(var o in oLayerSelected._layers){
        //     $scope.aoNgTable.push(oLayerSelected._layers[o].feature.properties)
        // }




        $scope.oFeaturesHeadInTable =$scope.oFeaturesInTable[Object.keys($scope.oFeaturesInTable)[0]].feature.properties;

        $scope.trackingProp = Object.keys($scope.oFeaturesHeadInTable)[0];

        oMap.fitBounds(oPolygon.getBounds().pad(0.5))

    };

    $scope.loadFilteredFeatures = function(){



        if(oFeatureLayer)oFeatureLayer.clearLayers();

        var oPost={
            layers :[],
            polygonFilter:[]
        };
        // collect active layer
        $scope.aoLayers.forEach(function (layer) {
            if(layer.checked){
                var l = angular.copy(layer);
                delete l.oMapLayer;
                delete l.checked;
                oPost.layers.push(l);
            }
        });

        // oPolygon._latlngs.forEach(function (p) {
        //     oPost.polygonFilter.push({lat:parseFloat(p.lat.toFixed(2)),lng:parseFloat(p.lng.toFixed(2))})
        // });

        //ufficiale
        oPost.polygonFilter = oPolygon._latlngs[0];

        // oPost.polygonFilter.push(oPolygon._latlngs[0]);
        oPost.polygonFilter.push(oPolygon._latlngs[0][0]);

        //TEST
        // oPost.polygonFilter = [
        //     {lng: 17.56, lat : 41.18},
        //     {lng: 17.18, lat : 39.49},
        //     {lng: 20.24, lat : 39.55},
        //     {lng: 17.56, lat : 41.18},
        // ];

        var geojsonMarkerOptions = {
            radius: 8,
            fillColor: "#ff7800",
            color: "#000",
            weight: 1,
            opacity: 1,
            fillOpacity: 0.8
        };


        toolsService.getWFSFilteredFeatures(oPost,function (aoLayers) {

            $scope.state = 2;


            if (aoLayers.length> 0){
                aoLayers.forEach(function (layer, index) {

                    var numberOfFeatures = 0;
                    // if(layer.features.length){
                    //     layer.features.forEach(function (feat) {
                    //         feat.geometry.coordinates.
                    //     })
                    // }

                    var oLayer =L.geoJson(layer, {
                        style: function (feature) {
                            return oPost.layers[index].style;
                        },
                        onEachFeature:function (oFeature, layer) {
                            // console.log(oFeature);
                            numberOfFeatures++;
                        },
                        pointToLayer:function(geoJsonPoint, latlng) {
                            var oM =L.circleMarker(latlng, oPost.layers[index].style);
                            oM.on('mouseover',function (ev) {
                                $scope.swichPageAndHighlight(ev.target._leaflet_id);
                            });
                            return oM;
                        },
                        coordsToLatLng: function (coords) {
                            //                    latitude , longitude, altitude
                            //return new L.LatLng(coords[1], coords[0], coords[2]); //Normal behavior
                            return new L.LatLng(coords[0], coords[1], coords[2]);
                        }

                    });
                    oLayer.name = oPost.layers[index].name;
                    oLayer.style = oPost.layers[index].style;
                    oLayer.active = false;
                    oLayer.numberOfFeatures = numberOfFeatures;
                    oFeatureLayer.addLayer(oLayer).bringToFront();
                });

                $scope.buildFeaturesTable();
            }


        },function (err) {
            console.log(err)
        });
    };

    $scope.aFilter =[];

    // $scope.$watch('filterObj',function () {
    //     ($scope.filterObj
    // });

    $scope.mouseOverFeatureInTable = function(feature){
        feature.bindPopup("You are here").openPopup();
    };

    $scope.mouseLeaveFeatureInTable = function(feature){
        feature.closePopup();
    };

    $scope.mouseClickFeatureInTable = function(feature){
        var latLngs = [ feature.getLatLng() ];
        var markerBounds = L.latLngBounds(latLngs);
        oMap.fitBounds(markerBounds).setZoom(13);

    };

    $scope.swichPageAndHighlight = function(id){
        $scope.paginatorConfig.eachPage = 1000;
        $location.hash(id+"_Anchor");
        $scope.featureHighlighted = id+"_Anchor";
        $anchorScroll();
    };

    $scope.filterObj = {};
    $scope.FilterByText = function(oFeatureInTable){

        oFeatureInTable = $scope.paginator(oFeatureInTable);

        var oFiltered={};
        if(Object.keys($scope.filterObj).length>0){

            for(var layer in oFeatureInTable){//per ogni layer
                for(var prop in oFeatureInTable[layer].feature.properties){ //per ogni prop del layer
                    if ($scope.filterObj[prop] == ""){
                        //se è stato cancellato non deve più filtrare
                        delete $scope.filterObj[prop];
                        break;
                    }
                    if($scope.filterObj[prop] ){//se esiste un filtro per quella prop
                        if(oFeatureInTable[layer].feature.properties[prop].toLowerCase().indexOf($scope.filterObj[prop].toLowerCase())> -1){//se prop in feature ha parte di prop in filter pusho
                            oFiltered[layer] = oFeatureInTable[layer];
                            // oFeatureInTable[layer].inTable = true ;
                        }
                    }else {

                    }

                }
            }

        } else return oFeatureInTable;
        return oFiltered;
    };

    $scope.paginatorConfig={
        page:0,
        pages:[0],
        eachPage:10000
    };

    $scope.paginator=function(oFeatureInTable){
        if (typeof oFeatureInTable != 'object')return oFeatureInTable;
        var oFiltered = {};

        var count = Object.keys(oFeatureInTable).length;
        if ($scope.paginatorConfig.eachPage< count){
            var quotient = Math.floor(count/$scope.paginatorConfig.eachPage);
            var remainder = count % $scope.paginatorConfig.eachPage;
            $scope.paginatorConfig.pages = [];
            for(var i = 0; i<= quotient; i++){
                $scope.paginatorConfig.pages.push(i);
            }
            // if (remainder>0)$scope.paginatorConfig.pages.push($scope.paginatorConfig.pages[$scope.paginatorConfig.pages.length-1]+1);

            var iFeatureCount = 0;
            var start = $scope.paginatorConfig.page *$scope.paginatorConfig.eachPage;
            var end = start +$scope.paginatorConfig.eachPage;
            for(var feat in oFeatureInTable){
                if (iFeatureCount>= start && iFeatureCount<= end){
                    oFiltered[feat] = oFeatureInTable[feat];
                }
                iFeatureCount++;
            }
            return oFiltered;
        }else {
            $scope.paginatorConfig.pages = [0];
            return oFeatureInTable;
        }

    };

    $scope.filterBuilder = function(key, value){
        console.log(key);
        return value;
    };

    $scope.fromObjToArray = function(obj){

        var result = Object.keys(obj).map(function(key) {
            return [key, obj[key]];
        });
        return result;
    };

    $scope.downloadData = function(){

        if(!$scope.aoFeatureLayers) return;

        var objToPost={
            data:[],
            creator:"Dewetra2",
            title:"DW2 report to excel"
        };

        if($scope.aoFeatureLayers.length >0){
            $scope.aoFeatureLayers.forEach(function (layer) {


            var eachLayerObj = {
                title :layer.name,
                numberOfFeatures :layer.numberOfFeatures,
                data:[]
            };

            var isIndexBuilded = false;

            for (var feat in layer._layers){

                var aFeatProp= [];//featureProp
                var aFeatKey = [];

                for(var key in layer._layers[feat].feature.properties){
                    if (!isIndexBuilded){
                        aFeatKey.push(key)
                    }
                    aFeatProp.push(layer._layers[feat].feature.properties[key])
                }

                if(!isIndexBuilded)eachLayerObj.data.push(aFeatKey);

                eachLayerObj.data.push(aFeatProp);
                isIndexBuilded = true;

            }

            objToPost.data.push(eachLayerObj);

        })
        }
        printService.getDataToFile('xlsx', objToPost,function (data) {
            var a = document.createElement('a');
            a.href = data.url;
            document.body.appendChild(a);
            a.click()
        });

    };


    $scope.loadLayerInDW2 = function(){

        var oFakeLayer= {
            icon :null,
            descr:"scenario",
            latn:44.45,
            lats:44.35,
            lone:9,
            lonw:8.9,
            server:{id:1},
            type:{
                code:"SCENARIO"
            }
        };



    };


    $scope.reset = function () {

        oMap.remove();


        initMap()
    };

    $scope.closePopup = function() {

        $uibModalInstance.close();

    };


    $timeout(initMap, 1000)

}]);


/**
 * Scenari controller bis
 */

dewetraApp.controller('scenariControllerDocked',['$scope','$window','$location','$anchorScroll', '$uibModal', '$uibModalInstance','model', '$translate',  'menuService', 'serieService', 'sentinelService', 'thresholdService','_', '$timeout', '$rootScope', '$sce', 'iconService', 'apiService','toolsService', '$location', 'mapService' ,'$anchorScroll','acLogbook', 'printService', function($scope,$window,$location,$anchorScroll, $uibModal, $uibModalInstance,model, $translate,  menuService, serieService, sentinelService, thresholdService,_, $timeout, $rootScope, $sce, iconService, apiService,toolsService, $location, mapService ,$anchorScroll,acLogbook, printService) {

    acLogbook.logActivity('Dewetra2-Scenario', 'Loaded Scenario');

    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    });

    var oMap, oFeatureLayer, oWMSLayer,oPolygon,oPost,editableLayers,drawControl,drawControlOnlyEdit;

    $scope.bLayerList = true;

    $scope.state = 0;

    $scope.config= {
        oHazardMap : {}
    };


    /**
     * Init Map
     */
    var initMap = function () {


        oFeatureLayer = L.featureGroup();

        oWMSLayer = L.featureGroup();

        var osmBasic = L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 18
        });
        // oMap = L.map('scenari',
        //     {
        //         //zoomControl:false,
        //         // scrollWheelZoom:false,
        //         //tap:false,
        //         boxZoom:false
        //     }).setView([44, 8], 13);

        oMap =  mapService.getMap();

        // console.log(oMap);

        // osmBasic.addTo(oMap);

        oFeatureLayer.addTo(oMap);

        oWMSLayer.addTo(oMap);

        //Draw
        editableLayers = new L.FeatureGroup();

        editableLayers.addTo(oMap);
        // oFeatureLayer.addLayer(editableLayers);


        var options = {
            position: 'bottomleft',
            draw: {
                polygon: {
                    allowIntersection: false, // Restricts shapes to simple polygons
                    drawError: {
                        color: '#e1111b', // Color the shape will turn when intersects
                        message: '<strong>Oh snap!<strong> you can\'t draw that!' // Message that will show when intersect
                    },
                    shapeOptions: {
                        color: '#2c38f3'
                    }
                },
                polyline:false,
                circle:false,
                rectangle:false,
                marker:false,
            },
            edit: {
                featureGroup: editableLayers, //REQUIRED!!
                remove: true
            }
        };

        var optionsOnlyEdit = {
            position: 'bottomleft',
            draw: false,
            edit: {
                featureGroup: editableLayers, //REQUIRED!!
                remove: true
            }
        };

        // drawControl = new L.Control.Draw(options);
        // drawControlOnlyEdit = new L.Control.Draw(optionsOnlyEdit);

        // drawControl.getContainer().className +" scenarioDrawControl";
        // drawControlOnlyEdit.getContainer().className +" scenarioDrawControl";



        // oMap.addControl(drawControl);

        // addSpecificClassToDrawControl(drawControl);


        //draw end

        function addSpecificClassToDrawControl (oDrawControl){
            if(oDrawControl.getContainer().className.indexOf("scenarioDrawControl" )>-1){

            }else{
                oDrawControl.getContainer().className +=" scenarioDrawControl";
            }
        }

        var editToolBar= new L.EditToolbar.Edit(oMap, {
            featureGroup: editableLayers,
            selectedPathOptions: optionsOnlyEdit.edit
        });
        var drawToolbar = new L.Draw.Polygon(oMap, options.draw.polygon);

        $scope.drawPolygon = function(){

            $scope.sFilterType = 'DRAW';

            drawToolbar.enable();

        };

        $scope.editPolygon = function(){

            // editToolBar.enable()
        };




        $scope.stopEdit = function(){
            // editToolBar.disable();
        };

        $scope.deletePolygon = function(){
            editableLayers.clearLayers();
            oPolygon = null;
        };


        oMap.on('draw:created', function(e) {
            var type = e.layerType,
                layer = e.layer;

            editableLayers.addLayer(e.layer);

            oPolygon = e.layer;


            drawToolbar.disable();


            // try {
            //     drawControlOnlyEdit.addTo(oMap);
            // }catch (e) {
            //     console.log(e)
            // }
            //
            // addSpecificClassToDrawControl(drawControlOnlyEdit);

            // $scope.loadFilteredFeatures()
        });

        // oMap.on("draw:edited", function(e ){
        //     oPolygon = e.layer;
        //
        //     // oFeatureLayer.clearLayers()
        //
        //     // $scope.loadFilteredFeatures()
        // });

        // oMap.on("draw:deleted", function(e ){
            // drawControlOnlyEdit.removeFrom(oMap);
            // drawControl.addTo(oMap);
            // addSpecificClassToDrawControl(drawControl);
            // oFeatureLayer.clearLayers();
            // oPolygon = null;

        // });


        $scope.isObjPolygon= function(){
            return (oPolygon == null)?false:true;
        };


        //UPLOAD



        $scope.setFile = function(file){

        };

        //END UPLOAD


        toolsService.getToolById(model.toolData.toolId, function (data) {

            var southWest = L.latLng($rootScope.acSession.hat.domain.lats, $rootScope.acSession.hat.domain.lonw),
                northEast = L.latLng($rootScope.acSession.hat.domain.latn, $rootScope.acSession.hat.domain.lone),
                bounds = L.latLngBounds(southWest, northEast);
            oMap.fitBounds(bounds);

            data.config.layers.forEach(function (o) {
                o.checked = false;
            });
            $scope.aoLayers = data.config.layers;

        })


    };//END INIT






    $scope.toggleLayer = function(oLayer){

        oLayer.checked = !oLayer.checked;

        if (oLayer.checked){
            oLayer.oMapLayer = L.tileLayer.wms(oLayer.wmsServer, {
                layers: oLayer.wmsId,
                format: 'image/png',
                transparent: true,
                maxZoom: 24,
            }).addTo(oWMSLayer).bringToFront();

        }else {
            oWMSLayer.removeLayer(oLayer.oMapLayer);
        }

        // try {
        //     if (oPolygon.hasOwnProperty("_latlngs")){
        //         $scope.loadFilteredFeatures();
        //     }
        // }catch (e) {
        //     console.log(e)
        // }

    };

    $scope.isUpdateActive = function(){
        try {
            if (oPolygon.hasOwnProperty("_latlngs")){
                var hasLayer = false;
                $scope.aoLayers.forEach(function (layer) {
                    if(layer.checked){
                        hasLayer = true;
                    }
                });
                return hasLayer;
            } return false
        }catch (e) {
            console.log(e);
            return false
        }

    };

    $scope.changeState = function(state){
        $scope.state = state;
    };

    $scope.buildFeaturesTable = function(){

        $scope.aoFeatureLayers = oFeatureLayer.getLayers();

        $scope.selectedLayerInTable($scope.aoFeatureLayers[0])

    };

    $scope.buildArrayForNgTable = function(aoLayers){
        for(var key in aoLayers){
            aoLayers[key].feature.properties
        }
    };


    $scope.counterObj = {};




    $scope.selectedLayerInTable = function(oLayerSelected){

        $scope.bDisableCountEFilter = false;

        if(_.keys(oLayerSelected._layers).length <2){
            $scope.bDisableCountEFilter = true;
        }

        $scope.aoFeatureLayers.forEach(function(oLayer){
            oLayer.active = false;
        });

        oLayerSelected.active = true;

        $scope.oFeaturesInTable = oLayerSelected._layers;

        console.log($scope.oFeaturesInTable);

        $scope.oFeaturesHeadInTable =$scope.oFeaturesInTable[Object.keys($scope.oFeaturesInTable)[0]].feature.properties;

        $scope.counterObj = Object.keys($scope.oFeaturesHeadInTable);

        console.log($scope.counterObj);

        for(var i in $scope.counterObj ){
            $scope.counterObj[i]=0
        }

        console.log($scope.counterObj);

        $scope.trackingProp = Object.keys($scope.oFeaturesHeadInTable)[0];

        oMap.fitBounds(oPolygon.getBounds().pad(0.5));

    };

    $scope.countNumberByFeatures = function(key){

        var count = 0;

        for(var i in $scope.oFeaturesInTable){

            if ($scope.oFeaturesInTable[i].feature.properties[key]){
                if (!isNaN(parseFloat($scope.oFeaturesInTable[i].feature.properties[key]))){
                    count += parseFloat($scope.oFeaturesInTable[i].feature.properties[key]);
                }
            }
        }

        // $scope.oFeaturesInTable.feature.forEach(function (feature) {
        //     if (feature.properties[key]){
        //         if (!isNaN(parseFloat(feature.properties[key]))){
        //             count += parseFloat(feature.properties[key]);
        //         }
        //     }
        // })
        $scope.counterObj[key] = count;

        console.log($scope.counterObj[key]);
        console.log(count)

    };

    $scope.loadFilteredFeatures = function(){

        if(oFeatureLayer)oFeatureLayer.clearLayers();

        var oPost={
            layers :[],
            polygonFilter:[]
        };
        // collect active layer
        $scope.aoLayers.forEach(function (layer) {
            if(layer.checked){
                var l = angular.copy(layer);
                delete l.oMapLayer;
                delete l.checked;
                oPost.layers.push(l);
            }
        });

        // oPolygon._latlngs.forEach(function (p) {
        //     oPost.polygonFilter.push({lat:parseFloat(p.lat.toFixed(2)),lng:parseFloat(p.lng.toFixed(2))})
        // });

        //ufficiale
        oPost.polygonFilter = oPolygon._latlngs[0];

        oPost.polygonFilter.push(oPolygon._latlngs[0][0]);


        //TEST
        // oPost.polygonFilter = [
        //     {lng: 17.56, lat : 41.18},
        //     {lng: 17.18, lat : 39.49},
        //     {lng: 20.24, lat : 39.55},
        //     {lng: 17.56, lat : 41.18},
        // ];

        var geojsonMarkerOptions = {
            radius: 8,
            fillColor: "#ff7800",
            color: "#000",
            weight: 1,
            opacity: 1,
            fillOpacity: 0.8
        };


        toolsService.getWFSFilteredFeatures(oPost,function (aoLayers) {

            $scope.state = 2;

            var oPolygon = L.polygon(oPost.polygonFilter);

            var jsonFeatureFromPolygon = oPolygon.toGeoJSON();

            if (aoLayers.length> 0){

                aoLayers.forEach(function (layer, index) {

                    var oLayerToAnalyze = layer;

                    if(oPost.layers[index].isRaster){
                        oPost.layers[index].style = {
                            opacity:1,
                            fillColor:"#fff"
                        };
                        jsonFeatureFromPolygon.properties =layer.features[0].properties;
                        oLayerToAnalyze = angular.copy(jsonFeatureFromPolygon);

                        oLayerToAnalyze.isRaster = oPost.layers[index].isRaster;
                    }

                    var numberOfFeatures = 0;

                    var oLayer =L.geoJson(oLayerToAnalyze, {
                        style: function (feature) {
                            return oPost.layers[index].style;
                        },
                        onEachFeature:function (oFeature, layer) {
                            // console.log(oFeature);
                            numberOfFeatures++;
                        },
                        pointToLayer:function(geoJsonPoint, latlng) {
                            var oM =L.circleMarker(latlng, oPost.layers[index].style);
                            oM.on('mouseover',function (ev) {
                                $scope.swichPageAndHighlight(ev.target._leaflet_id);
                            });
                            return oM;
                        },
                        coordsToLatLng: function (coords) {
                            //                    latitude , longitude, altitude

                            if(oLayerToAnalyze.isRaster){
                                return new L.LatLng(coords[1], coords[0], coords[2]);
                            }else{
                                return new L.LatLng(coords[0], coords[1], coords[2]);
                            }

                            //return new L.LatLng(coords[1], coords[0], coords[2]); //Normal behavior
                            // return new L.LatLng(coords[0], coords[1], coords[2]);
                        }

                    });
                    oLayer.name = oPost.layers[index].name;
                    oLayer.style = oPost.layers[index].style;
                    oLayer.active = false;
                    oLayer.numberOfFeatures = numberOfFeatures;

                    oFeatureLayer.addLayer(oLayer).bringToFront();
                });

                $scope.buildFeaturesTable();
            }


        },function (err) {
            console.log(err)
        });
    };

    $scope.aFilter =[];


    $scope.mouseOverFeatureInTable = function(feature){

        feature.bindPopup("You are here").openPopup();

    };

    $scope.mouseLeaveFeatureInTable = function(feature){
        feature.closePopup();
    };

    $scope.mouseClickFeatureInTable = function(feature){
        var latLngs = [ feature.getLatLng() ];
        var markerBounds = L.latLngBounds(latLngs);
        oMap.fitBounds(markerBounds).setZoom(13);

    };

    $scope.swichPageAndHighlight = function(id){
        $scope.paginatorConfig.eachPage = 1000;
        $location.hash(id+"_Anchor");
        $scope.featureHighlighted = id+"_Anchor";
        $anchorScroll();
    };

    $scope.filterObj = {};

    $scope.FilterByText = function(oFeatureInTable){

        oFeatureInTable = $scope.paginator(oFeatureInTable);

        var oFiltered={};
        if(Object.keys($scope.filterObj).length>0){

            for(var layer in oFeatureInTable){//per ogni layer
                for(var prop in oFeatureInTable[layer].feature.properties){ //per ogni prop del layer
                    if ($scope.filterObj[prop] == ""){
                        //se è stato cancellato non deve più filtrare
                        delete $scope.filterObj[prop];
                        break;
                    }
                    if($scope.filterObj[prop] ){//se esiste un filtro per quella prop
                        if(oFeatureInTable[layer].feature.properties[prop].toLowerCase().indexOf($scope.filterObj[prop].toLowerCase())> -1){//se prop in feature ha parte di prop in filter pusho
                            oFiltered[layer] = oFeatureInTable[layer];
                            // oFeatureInTable[layer].inTable = true ;
                        }
                    }else {

                    }

                }
            }

        } else return oFeatureInTable;
        return oFiltered;
    };


    $scope.paginatorConfig={
        page:0,
        pages:[0],
        eachPage:10000
    };

    $scope.paginator=function(oFeatureInTable){
        if (typeof oFeatureInTable != 'object')return oFeatureInTable;
        var oFiltered = {};

        var count = Object.keys(oFeatureInTable).length;
        if ($scope.paginatorConfig.eachPage< count){
            var quotient = Math.floor(count/$scope.paginatorConfig.eachPage);
            var remainder = count % $scope.paginatorConfig.eachPage;
            $scope.paginatorConfig.pages = [];
            for(var i = 0; i<= quotient; i++){
                $scope.paginatorConfig.pages.push(i);
            }
            // if (remainder>0)$scope.paginatorConfig.pages.push($scope.paginatorConfig.pages[$scope.paginatorConfig.pages.length-1]+1);

            var iFeatureCount = 0;
            var start = $scope.paginatorConfig.page *$scope.paginatorConfig.eachPage;
            var end = start +$scope.paginatorConfig.eachPage;
            for(var feat in oFeatureInTable){
                if (iFeatureCount>= start && iFeatureCount<= end){
                    oFiltered[feat] = oFeatureInTable[feat];
                }
                iFeatureCount++;
            }
            return oFiltered;
        }else {
            $scope.paginatorConfig.pages = [0];
            return oFeatureInTable;
        }

    };

    $scope.filterBuilder = function(key, value){
        console.log(key);
        return value;
    };

    $scope.fromObjToArray = function(obj){

        var result = Object.keys(obj).map(function(key) {
            return [key, obj[key]];
        });
        return result;
    };

    $scope.downloadData = function(){

        if(!$scope.aoFeatureLayers) return;

        var objToPost={
            data:[],
            creator:"Dewetra2",
            title:"DW2 report to excel"
        };

        if($scope.aoFeatureLayers.length >0){
            $scope.aoFeatureLayers.forEach(function (layer) {
                var eachLayerObj = {
                    title :layer.name,
                    numberOfFeatures :layer.numberOfFeatures,
                    data:[]
                };

                var isIndexBuilded = false;

                for (var feat in layer._layers){

                    var aFeatProp= [];//featureProp
                    var aFeatKey = [];

                    for(var key in layer._layers[feat].feature.properties){
                        if (!isIndexBuilded){
                            aFeatKey.push(key)
                        }
                        aFeatProp.push(layer._layers[feat].feature.properties[key])
                    }

                    if(!isIndexBuilded)eachLayerObj.data.push(aFeatKey);

                    eachLayerObj.data.push(aFeatProp);
                    isIndexBuilded = true;

                }

                objToPost.data.push(eachLayerObj);

            });
        }

        // apiService.postPrintServer('datatofile/xlsx/',objToPost,function (data) {
        //     console.log(data)
        //
        //     var a = document.createElement('a');
        //     a.href = data.url;
        //     document.body.appendChild(a);
        //     // a.download = true;
        //     // ritardo lo scaricamento senno me lo restituisce non printo
        //     $timeout(function () {
        //         a.click()
        //     },3000)
        // });

        printService.getDataToFile('xlsx', objToPost,function (data) {
            var a = document.createElement('a');
            a.href = data.url;
            document.body.appendChild(a);
            a.click()
        });

    };


    $scope.loadLayerInDW2 = function(){

        var oFakeLayer= {
            icon :null,
            descr:"scenario",
            latn:44.45,
            lats:44.35,
            lone:9,
            lonw:8.9,
            server:{id:1},
            type:{
                code:"SCENARIO"
            }
        };



    };


    $scope.reset = function () {

        oMap.remove();


        initMap()
    };

    $scope.closePopup = function() {

        var r = confirm($translate.instant("LEAVE_IMPACT_SCENARIO"));

        if (r == true) {
            $uibModalInstance.close();
            if(model.onClose)model.onClose();

            oFeatureLayer.clearLayers();

            editableLayers.clearLayers();

            oWMSLayer.clearLayers();

            oMap.removeLayer(oFeatureLayer);

            oMap.removeLayer(editableLayers);

            oMap.removeLayer(oWMSLayer);


            try {
                oMap.removeControl(drawControl);
            }catch (e) {
                console.log(e)
            }
            try {
                oMap.removeControl(drawControlOnlyEdit)
            }catch (e) {
                console.log(e)
            }


        }



    };


    $timeout(initMap, 1000)

}]);



//ERRA SCENARIO

dewetraApp.controller('scenariControllerDockedErra',[ '$scope','$window','$location','$anchorScroll', '$uibModal', '$uibModalInstance','model', '$translate',  'menuService', 'serieService', 'sentinelService', 'thresholdService','_', '$timeout', '$rootScope', '$sce', 'iconService', 'apiService','toolsService', '$location', 'mapService' ,'$anchorScroll','acLogbook', 'printService',function($scope,$window,$location,$anchorScroll, $uibModal, $uibModalInstance,model, $translate,  menuService, serieService, sentinelService, thresholdService,_, $timeout, $rootScope, $sce, iconService, apiService,toolsService, $location, mapService ,$anchorScroll,acLogbook, printService) {

    acLogbook.logActivity('Dewetra2-Scenario', 'Loaded Scenario');

    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    });

    var oMap, oFeatureLayer, oWMSLayer,oPolygon, oPost,editableLayers,drawControl,drawControlOnlyEdit;

    $scope.bLayerList = true;

    $scope.state = 0;


    $scope.oConfig = {
        availableInputChoice :['draw'],//['draw','upload', 'select'],
        oHazardMap:null,
        iHazardMap : 9999,
        sumLayers:[],
        impacts_layers:[],
        disabledKeys:{}
    };


    /**
     * Init Map
     */
    var initMap = function () {


        oFeatureLayer = L.featureGroup();

        oWMSLayer = L.featureGroup();

        var osmBasic = L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution:
                '&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors',
            maxZoom: 24
        });
        // oMap = L.map('scenari',
        //     {
        //         //zoomControl:false,
        //         // scrollWheelZoom:false,
        //         //tap:false,
        //         boxZoom:false
        //     }).setView([44, 8], 13);


        //mapService.setBaseLayer(osmBasic)

        oMap =  mapService.getMap();

        // console.log(oMap);

        // osmBasic.addTo(oMap);

        oFeatureLayer.addTo(oMap);

        oWMSLayer.addTo(oMap);

        //Draw
        editableLayers = new L.FeatureGroup();

        editableLayers.addTo(oMap);
        // oFeatureLayer.addLayer(editableLayers);


        var options = {
            position: 'bottomleft',
            draw: {
                polygon: {
                    allowIntersection: false, // Restricts shapes to simple polygons
                    drawError: {
                        color: '#e1e058', // Color the shape will turn when intersects
                        message: '<strong>Oh snap!<strong> you can\'t draw that!' // Message that will show when intersect
                    },
                    shapeOptions: {
                        color: '#f32727'
                    }
                },
                polyline:false,
                circle:false,
                rectangle:false,
                marker:false,
            },
            edit: {
                featureGroup: editableLayers, //REQUIRED!!
                remove: true
            }
        };

        var optionsOnlyEdit = {
            position: 'bottomleft',
            draw: false,
            edit: {
                featureGroup: editableLayers, //REQUIRED!!
                remove: true
            }
        };

        // drawControl = new L.Control.Draw(options);
        // drawControlOnlyEdit = new L.Control.Draw(optionsOnlyEdit);

        // drawControl.getContainer().className +" scenarioDrawControl";
        // drawControlOnlyEdit.getContainer().className +" scenarioDrawControl";



        // oMap.addControl(drawControl);

        // addSpecificClassToDrawControl(drawControl);


        //draw end

        function addSpecificClassToDrawControl (oDrawControl){
            if(oDrawControl.getContainer().className.indexOf("scenarioDrawControl" )>-1){

            }else{
                oDrawControl.getContainer().className +=" scenarioDrawControl";
            }
        }

        var editToolBar= new L.EditToolbar.Edit(oMap, {
            featureGroup: editableLayers,
            selectedPathOptions: optionsOnlyEdit.edit
        });
        var drawToolbar = new L.Draw.Polygon(oMap, options.draw.polygon);

        $scope.drawPolygon = function(){

            drawToolbar.enable();

        };

        $scope.editPolygon = function(){

            // editToolBar.enable()
        };

        $scope.stopEdit = function(){
            // editToolBar.disable();
        };

        $scope.deletePolygon = function(){
            editableLayers.clearLayers();
            oPolygon = null;
        };

        $scope.setFileEventListener = function(element){

            var fd = new FormData();

            fd.append('file', element.files[0]);

            var headers = {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}
            };

            apiService.postWithHeaders("tools/shapefiletopoly/",fd,headers,function (data) {

                oPolygon = L.polygon(data.polygonFilter, {color: "#f32727",opacity:0.7});
                editableLayers.addLayer(oPolygon);

                document.getElementById("inputShapeZip").value = "";

            },function (err) {
                console.log(err)
            })

        };


        $scope.savePolygonToShp = function(){
            let oPol ={"polygon" :  oPolygon._latlngs[0]};

            oPol.polygon.push(oPolygon._latlngs[0][0]);

            apiService.post("tools/polytoshapefile/",oPol,function (data) {

                var saving = document.createElement('a');
                saving.setAttribute('href', 'data:application/zip;base64,' + data);
                saving.setAttribute('download', "AOI_shape.zip");

                // Append anchor to body.
                document.body.appendChild(saving);
                saving.click();

                // Remove anchor from body
                document.body.removeChild(saving);
            })
        };

        oMap.on('draw:created', function(e) {
            var type = e.layerType,
                layer = e.layer;

            editableLayers.addLayer(e.layer);

            oPolygon = e.layer;


            drawToolbar.disable();


            // try {
            //     drawControlOnlyEdit.addTo(oMap);
            // }catch (e) {
            //     console.log(e)
            // }
            //
            // addSpecificClassToDrawControl(drawControlOnlyEdit);

            // $scope.loadFilteredFeatures()
        });

        // oMap.on("draw:edited", function(e ){
        //     oPolygon = e.layer;
        //
        //     // oFeatureLayer.clearLayers()
        //
        //     // $scope.loadFilteredFeatures()
        // });

        // oMap.on("draw:deleted", function(e ){
        // drawControlOnlyEdit.removeFrom(oMap);
        // drawControl.addTo(oMap);
        // addSpecificClassToDrawControl(drawControl);
        // oFeatureLayer.clearLayers();
        // oPolygon = null;

        // });


        $scope.isObjPolygon= function(){
            return (oPolygon == null)?false:true;
        };


        var printer = L.easyPrint({
            tileLayer: osmBasic,
            // sizeModes: ['Current', 'A4Landscape', 'A4Portrait'],
            sizeModes: ['Current'],
            filename: 'scenario',
            tileWait:1000,
            exportOnly: true,
            hideControlContainer: true,
            hidden: true,

        }).addTo(oMap);

        $scope.manualPrint = function () {
            printer.printMap('CurrentSize', 'RiskScenario')


            //
            // domtoimage.toJpeg(document.getElementById('map'), { quality: 0.95 })
            //     .then(function (dataUrl) {
            //         let link = document.createElement('a');
            //         link.download = 'RISK_SCENARIO';
            //         link.href = dataUrl;
            //         link.click();
            //     })
            //     .catch(function (err) {
            //         console.log(err)
            //     })

        };




        $scope.sFilterType = '';


        toolsService.getToolById(model.toolData.toolId, function (data) {

            var southWest = L.latLng($rootScope.acSession.hat.domain.lats, $rootScope.acSession.hat.domain.lonw),
                northEast = L.latLng($rootScope.acSession.hat.domain.latn, $rootScope.acSession.hat.domain.lone),
                bounds = L.latLngBounds(southWest, northEast);

            //oMap.fitBounds(bounds);//non muove la visuale della mappa quando apri tool


            data.config.layers.forEach(function (o) {
                o.checked = false;
                o.opacity = 0;
            });
            $scope.aoLayers = data.config.layers;
            $scope.aoHazard = data.config.hazard_zones;

            //metto preselezionato l'opzione di nessun hazard preselezionato
            $scope.aoHazard.push({
                id:9999,
                descr:"NO_HAZARD_SELECTED"
            });

            $scope.oConfig.oHazardMap = $scope.aoHazard[$scope.aoHazard.length - 1]

        })


    };// END INIT MAP ERRA


    $scope.hazardFilteredByBBOX = function(id){
        // console.table($scope.aoLayers)

        if (id){
            return $scope.aoHazard.filter((oHazard) => {return oHazard.id == id})
        }else {
            return $scope.aoHazard;
        }


    };


    // todo: INSERITO DEDA ...da sistemare :)
    // show hide button
    $scope.showFunc = function(){
        $scope.show = !$scope.show;
    };


    $scope.toggleLayer = function(oLayer){

        oLayer.checked = !oLayer.checked;

        if (oLayer.checked){

            oLayer.oMapLayer = L.tileLayer.wms(oLayer.wmsServer, {
                layers: oLayer.wmsId,
                format: 'image/png',
                transparent: true,
                maxZoom: 24,
            }).addTo(oWMSLayer).bringToFront();

            oLayer.opacity = 100;

        }else {
            oWMSLayer.removeLayer(oLayer.oMapLayer);
            oLayer.opacity= 0;
        }

        // try {
        //     if (oPolygon.hasOwnProperty("_latlngs")){
        //         $scope.loadFilteredFeatures();
        //     }
        // }catch (e) {
        //     console.log(e)
        // }

    };


    $scope.changeLayerOpacity = function(opacity , layer){
        if( layer.checked == false) $scope.toggleLayer(layer);


        try {
            layer.oMapLayer.setOpacity( opacity)
        }catch (e) {
            console.log(e)
        }

    };

    $scope.isUpdateActive = function(){
        try {
            if (oPolygon.hasOwnProperty("_latlngs")){
                var hasLayer = false;
                $scope.aoLayers.forEach(function (layer) {
                    if(layer.checked){
                        hasLayer = true;
                    }
                });
                return hasLayer;
            } return false
        }catch (e) {
            console.log(e);
            return false
        }

    };

    $scope.changeState = function(state){
        $scope.state = state;
    };

    $scope.buildFeaturesTable = function(){


        //serve solo per precaricare un layer al click

        let layersOutput = oFeatureLayer.getLayers().concat($scope.oConfig.sumLayers);

        $scope.aoFeatureLayers = layersOutput;


        $scope.selectedLayerInTable($scope.aoFeatureLayers[0])

    };

    $scope.buildArrayForNgTable = function(aoLayers){
        for(var key in aoLayers){
            aoLayers[key].feature.properties
        }
    };


    $scope.counterObj = {};
    $scope.meanObj = {};


    $scope.selectedLayerInTable = function(oLayerSelected){



        $scope.outputType = oLayerSelected.outputType;


        if(oLayerSelected.outputType == "impacts_map"){

            if(_.keys(oLayerSelected._layers).length <1){
                $scope.oFeaturesInTable = {};
                $scope.oFeaturesHeadInTable = {};
                return
            }

            console.table(oLayerSelected);

            $scope.bDisableCountEFilter = false;

            if(_.keys(oLayerSelected._layers).length <2){
                $scope.bDisableCountEFilter = true;
            }

            $scope.aoFeatureLayers.forEach(function(oLayer){
                oLayer.active = false;
            });

            oLayerSelected.active = true;


            $scope.oLayerSelected = oLayerSelected;

            if(!$scope.oConfig.disabledKeys.hasOwnProperty($scope.oLayerSelected.name)){
                $scope.oConfig.disabledKeys[$scope.oLayerSelected.name] = {};
            }


            $scope.oFeaturesInTable = oLayerSelected._layers;

            console.log($scope.oFeaturesInTable);


            $scope.oFeaturesHeadInTable =$scope.oFeaturesInTable[Object.keys($scope.oFeaturesInTable)[0]].feature.properties;


            $scope.counterObj = Object.keys($scope.oFeaturesHeadInTable);

            console.log($scope.counterObj);

            for(var i in $scope.counterObj ){
                $scope.counterObj[i]=0
            }

            //console.log($scope.counterObj)

            $scope.trackingProp = Object.keys($scope.oFeaturesHeadInTable)[0];



            //oMap.fitBounds(oPolygon.getBounds().pad(0.5));
            oMap.setView(getPolygonEastestPoint(),oMap.getBoundsZoom(oPolygon.getBounds()))


        }else if(oLayerSelected.outputType == "impacts_sum"){

            $scope.oImpactsSumInTable = oLayerSelected.data;

            $scope.oFeaturesHeadInTableSum =$scope.oImpactsSumInTable[Object.keys($scope.oImpactsSumInTable)[0]];

            $scope.aoFeatureLayers.forEach(function(oLayer){
                oLayer.active = false;
            });

            oLayerSelected.active = true;

        }

    };

    getPolygonEastestPoint = function(){
        if(oPolygon){
            var listOfLatLngs =oPolygon.getLatLngs();
            var listOfLngs =[];
            var listOfLats =[];

            for(let i in listOfLatLngs){
                if(Array.isArray(listOfLatLngs[i])){
                    listOfLatLngs[i].forEach(function (x) {
                        listOfLngs.push(x.lng);
                        listOfLats.push(x.lat)
                    })
                }
            }

            var latAvg =  listOfLats.reduce((a,b) => a + b, 0) / listOfLats.length;
            var lngMax= _.max(listOfLngs);

            return L.latLng(latAvg,lngMax)
        }
    };

    $scope.toggleColumnFromTable = function(keys){
        console.log($scope.oFeaturesInTable);

        //recupero layer attivo


        if($scope.oConfig.disabledKeys[$scope.oLayerSelected.name].hasOwnProperty(keys)){
            $scope.oConfig.disabledKeys[$scope.oLayerSelected.name][keys] = !$scope.oConfig.disabledKeys[$scope.oLayerSelected.name][keys]
        }else{
            $scope.oConfig.disabledKeys[$scope.oLayerSelected.name][keys] = false
        }

    };

    $scope.filterKeys = function(key){

        if(($scope.oConfig.disabledKeys[$scope.oLayerSelected.name].hasOwnProperty(key))) {
            return $scope.oConfig.disabledKeys[$scope.oLayerSelected.name][key]
        }else {
            return true
        }

        // return $scope.oConfig.disabledKeys[$scope.oLayerSelected.name][key]

    };

    $scope.$watch("oConfig.keyToAdd", (value) => {console.log(value)})
    $scope.countNumberByFeatures = function(key){

        var count = 0;

        for(var i in $scope.oFeaturesInTable){

            if ($scope.oFeaturesInTable[i].feature.properties[key]){
                if (!isNaN(parseFloat($scope.oFeaturesInTable[i].feature.properties[key]))){
                    count += parseFloat($scope.oFeaturesInTable[i].feature.properties[key]);
                }
            }
        }

        // $scope.oFeaturesInTable.feature.forEach(function (feature) {
        //     if (feature.properties[key]){
        //         if (!isNaN(parseFloat(feature.properties[key]))){
        //             count += parseFloat(feature.properties[key]);
        //         }
        //     }
        // })
        $scope.counterObj[key] = count;

        console.log($scope.counterObj[key]);
        console.log(count)

    };



    $scope.meanNumberByFeatures = function(key){

        var count = 0;

        for(var i in $scope.oFeaturesInTable){

            if ($scope.oFeaturesInTable[i].feature.properties[key]){
                if (!isNaN(parseFloat($scope.oFeaturesInTable[i].feature.properties[key]))){
                    count += parseFloat($scope.oFeaturesInTable[i].feature.properties[key]);
                }
            }
        }

        $scope.meanObj[key] = (count/Object.keys($scope.oFeaturesInTable).length);

        // console.log($scope.meanObj[key])
        // console.log(count)

    };


    $scope.loadFilteredFeatures = function(){

        if(oFeatureLayer)oFeatureLayer.clearLayers();

        var oPost={
            layers :[],
            polygonFilter:[]
        };

        $scope.oConfig.sumLayers = [];

        // collect active layer
        $scope.aoLayers.forEach(function (layer) {
            if(layer.checked){
                var l = angular.copy(layer);
                delete l.oMapLayer;
                delete l.checked;
                oPost.layers.push(l);
            }
        });

        // oPolygon._latlngs.forEach(function (p) {
        //     oPost.polygonFilter.push({lat:parseFloat(p.lat.toFixed(2)),lng:parseFloat(p.lng.toFixed(2))})
        // });

        //ufficiale
        oPost.polygonFilter = oPolygon._latlngs[0];

        oPost.polygonFilter.push(oPolygon._latlngs[0][0]);

        oPost.hazard_zones =[];

        if ($scope.oConfig.oHazardMap.id != 9999){

            oPost.hazard_zones = $scope.hazardFilteredByBBOX($scope.oConfig.oHazardMap.id)
        }

        //TEST
        // oPost.polygonFilter = [
        //     {lng: 17.56, lat : 41.18},
        //     {lng: 17.18, lat : 39.49},
        //     {lng: 20.24, lat : 39.55},
        //     {lng: 17.56, lat : 41.18},
        // ];

        var geojsonMarkerOptions = {
            radius: 8,
            fillColor: "#ff7800",
            color: "#000",
            weight: 1,
            opacity: 1,
            fillOpacity: 0.8
        };

        var iconMarkerSVG = {};


        toolsService.getScenario(oPost,function (aoLayers) {


            $scope.state = 3;

            var oPolygon = L.polygon(oPost.polygonFilter);

            var jsonFeatureFromPolygon = oPolygon.toGeoJSON();

            if (aoLayers.length> 0){

                aoLayers.forEach(function (layer) {

                    var oLayerToAnalyze = layer;
                    console.log(layer);


                    var index = oPost.layers.findIndex(function (x) {
                        return oLayerToAnalyze.layer_id == x.wmsId
                    });

                    // if result is impacts map
                    if(layer.output == 'impacts_map'){
                        var numberOfFeatures = 0;

                        var oLayer =L.geoJson(oLayerToAnalyze.data, {
                            style: function (feature) {
                                return oPost.layers[index].style;
                            },
                            onEachFeature:function (oFeature, layer) {
                                // console.log(oFeature);
                                numberOfFeatures++;
                            },
                            pointToLayer:function(geoJsonPoint, latlng) {

                                if(oPost.layers[index].icon != ""){

                                    var oM =iconService.scenario_Icon(latlng, oPost.layers[index].icon)

                                }else if(oPost.layers[index].style && oPost.layers[index].icon == ""){

                                    var oM =L.circleMarker(latlng, oPost.layers[index].style);
                                }


                                oM.on('mouseover',function (ev) {
                                    $scope.swichPageAndHighlight(ev.target._leaflet_id);
                                });

                                return oM;
                            },
                            // coordsToLatLng: function (coords) {
                            //     //                    latitude , longitude, altitude
                            //
                            //     // return new L.LatLng(coords[1], coords[0], coords[2]);
                            //
                            //     // if(oLayerToAnalyze.isRaster){
                            //     //     return new L.LatLng(coords[1], coords[0], coords[2]);
                            //     // }else{
                            //     //     return new L.LatLng(coords[0], coords[1], coords[2]);
                            //     // }
                            //
                            //     //return new L.LatLng(coords[1], coords[0], coords[2]); //Normal behavior
                            //     // return new L.LatLng(coords[0], coords[1], coords[2]);
                            // }

                        });

                        oLayer.outputType = layer.output;

                        oLayer.name = oPost.layers[index].name;
                        oLayer.icon = oPost.layers[index].icon;
                        oLayer.style = oPost.layers[index].style;
                        oLayer.active = false;
                        oLayer.numberOfFeatures = numberOfFeatures;

                        oFeatureLayer.addLayer(oLayer).bringToFront();


                    }else if (layer.output == 'impacts_sum'){

                        var oLayer ={};

                        oLayer.name= oPost.layers[index].name;
                        oLayer.outputType= layer.output;
                        oLayer.data = layer.data;
                        oLayer.layer_id = layer.layer_id;
                        oLayer.style = oPost.layers[index].style;
                        oLayer.icon = oPost.layers[index].icon;
                        oLayer.active = false;

                        $scope.oConfig.sumLayers.push(oLayer);

                        // console.log(layer)
                    }


                });


                $scope.buildFeaturesTable();
            }


        },function (err) {
            console.log(err)
        });
    };

    $scope.aFilter =[];


    $scope.mouseOverFeatureInTable = function(feature){

        feature.bindPopup("You are here").openPopup();

    };

    $scope.mouseLeaveFeatureInTable = function(feature){
        feature.closePopup();
    };

    $scope.mouseClickFeatureInTable = function(feature){
        var latLngs = [ feature.getLatLng() ];
        var markerBounds = L.latLngBounds(latLngs);
        oMap.fitBounds(markerBounds).setZoom(13);

    };

    $scope.swichPageAndHighlight = function(id){
        $scope.paginatorConfig.eachPage = 1000;
        $location.hash(id+"_Anchor");
        $scope.featureHighlighted = id+"_Anchor";
        $anchorScroll();
    };

    $scope.filterObj = {};

    $scope.FilterByText = function(oFeatureInTable){

        oFeatureInTable = $scope.paginator(oFeatureInTable);

        var oFiltered={};
        if(Object.keys($scope.filterObj).length>0){

            for(var layer in oFeatureInTable){//per ogni layer
                for(var prop in oFeatureInTable[layer].feature.properties){ //per ogni prop del layer
                    if ($scope.filterObj[prop] == ""){
                        //se è stato cancellato non deve più filtrare
                        delete $scope.filterObj[prop];
                        break;
                    }
                    if($scope.filterObj[prop] && oFeatureInTable[layer].feature.properties[prop]){//se esiste un filtro per quella prop e se esiste la prop
                        if(oFeatureInTable[layer].feature.properties[prop].toString().toLowerCase().indexOf($scope.filterObj[prop].toLowerCase())> -1){//se prop in feature ha parte di prop in filter pusho
                            oFiltered[layer] = oFeatureInTable[layer];
                            // oFeatureInTable[layer].inTable = true ;
                        }
                    }else {

                    }

                }
            }

        } else return oFeatureInTable;
        return oFiltered;
    };



        $scope.paginatorConfig={
            page:0,
            pages:[0],
            eachPage:10000
        };

        $scope.paginator=function(oFeatureInTable){
            if (typeof oFeatureInTable != 'object')return oFeatureInTable;
            var oFiltered = {};

            var count = Object.keys(oFeatureInTable).length;
            if ($scope.paginatorConfig.eachPage< count){
                var quotient = Math.floor(count/$scope.paginatorConfig.eachPage);
                var remainder = count % $scope.paginatorConfig.eachPage;
                $scope.paginatorConfig.pages = [];
                for(var i = 0; i<= quotient; i++){
                    $scope.paginatorConfig.pages.push(i);
                }
                // if (remainder>0)$scope.paginatorConfig.pages.push($scope.paginatorConfig.pages[$scope.paginatorConfig.pages.length-1]+1);

                var iFeatureCount = 0;
                var start = $scope.paginatorConfig.page *$scope.paginatorConfig.eachPage;
                var end = start +$scope.paginatorConfig.eachPage;
                for(var feat in oFeatureInTable){
                    if (iFeatureCount>= start && iFeatureCount<= end){
                        oFiltered[feat] = oFeatureInTable[feat];
                    }
                    iFeatureCount++;
                }
                return oFiltered;
            }else {
                $scope.paginatorConfig.pages = [0];
                return oFeatureInTable;
            }

        };

        $scope.filterBuilder = function(key, value){
            console.log(key);
            return value;
        };

        $scope.fromObjToArray = function(obj){

            var result = Object.keys(obj).map(function(key) {
                return [key, obj[key]];
            });
            return result;
        };

        $scope.downloadData = function(){

            if(!$scope.aoFeatureLayers) return;

            var objToPost={
                data:[],
                creator:"Dewetra2",
                title:"DW2 report to excel"
            };

            if($scope.aoFeatureLayers.length >0){
                $scope.aoFeatureLayers.forEach(function (layer) {

                    if(layer.outputType == 'impacts_map'){
                        var eachLayerObj = {
                            title :layer.name,
                            numberOfFeatures :layer.numberOfFeatures,
                            data:[]
                        };

                        var isIndexBuilded = false;

                        for (var feat in layer._layers){

                            var aFeatProp= [];//featureProp
                            var aFeatKey = [];

                            for(var key in layer._layers[feat].feature.properties){
                                if (!isIndexBuilded){
                                    aFeatKey.push(key)
                                }
                                aFeatProp.push(layer._layers[feat].feature.properties[key])
                            }

                            if(!isIndexBuilded)eachLayerObj.data.push(aFeatKey);

                            eachLayerObj.data.push(aFeatProp);
                            isIndexBuilded = true;

                        }

                        objToPost.data.push(eachLayerObj);

                    }else if(layer.outputType == 'impacts_sum'){

                        var eachLayerObj = {
                            title :layer.name,
                            data:[]
                        };


                        var isIndexBuilded = false;


                        if (layer.data.length > 0){
                            layer.data.forEach(function(item){
                                var p = angular.copy(item);
                                if(p.hasOwnProperty("$$hashKey")) delete p.$$hashKey;

                                eachLayerObj.data.push(Object.values(p));
                                delete p;
                            })
                        }


                        objToPost.data.push(eachLayerObj);

                    }



                });
            }

            // apiService.postPrintServer('datatofile/xlsx/',objToPost,function (data) {
            //     console.log(data)
            //
            //     var a = document.createElement('a');
            //     a.href = data.url;
            //     document.body.appendChild(a);
            //     // a.download = true;
            //     // ritardo lo scaricamento senno me lo restituisce non printo
            //     $timeout(function () {
            //         a.click()
            //     },3000)
            // });

            printService.getDataToFile('xlsx', objToPost,function (data) {
                var a = document.createElement('a');
                a.href = data.url;
                document.body.appendChild(a);
                a.click()
            });

        };


        $scope.loadLayerInDW2 = function(){

            var oFakeLayer= {
                icon :null,
                descr:"scenario",
                latn:44.45,
                lats:44.35,
                lone:9,
                lonw:8.9,
                server:{id:1},
                type:{
                    code:"SCENARIO"
                }
            };



        };


        $scope.reset = function () {

            oMap.remove();


            initMap()
        };

        $scope.closePopup = function() {

            var r = confirm($translate.instant("LEAVE_IMPACT_SCENARIO"));

            if (r == true) {
                $uibModalInstance.close();
                if(model.onClose)model.onClose();

                oFeatureLayer.clearLayers();

                editableLayers.clearLayers();

                oWMSLayer.clearLayers();

                oMap.removeLayer(oFeatureLayer);

                oMap.removeLayer(editableLayers);

                oMap.removeLayer(oWMSLayer);


                try {
                    oMap.removeControl(drawControl);
                }catch (e) {
                    console.log(e)
                }
                try {
                    oMap.removeControl(drawControlOnlyEdit)
                }catch (e) {
                    console.log(e)
                }


            }



        };


        $timeout(initMap, 1000)

    }]);



