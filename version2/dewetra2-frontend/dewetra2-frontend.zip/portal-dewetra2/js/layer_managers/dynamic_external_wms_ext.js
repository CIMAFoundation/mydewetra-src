/**
 * Created by Anto on 20/09/16.
 */

function layerManager_dynamic_external_wms_ext(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout) {


    function getLayerAvailability() {

        var from = menuService.getDateFrom().setUTCMinutes(0,0,0);
        var to = menuService.getDateTo().setUTCMinutes(0,0,0);

        var dt, utc_date, data = [];
        for (var t = from; t < to; t += 3600000) {
            dt = new Date(t);
            if ((dt.getUTCHours() == 0) || (dt.getUTCHours() == 12)) {
                utc_date = moment(dt).utc();
                data.push({
                    "date": utc_date,
                    "description": dt.toUTCString(),
                    "id": utc_date.valueOf() + ";" + utc_date.valueOf()
                });
            }
        }

        return data;

    }


    var manager = layerManager_dynamic(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout);


    function update(newProps, newItem, onFinish, bScrambling) {

        manager.setProps(newProps);

        manager.setItem(newItem);

        if (manager.mapLayer()) {
            manager.setlayerOpacity(manager.mapLayer().options.opacity);
            mapService.removeLayer(manager.mapLayer());
        }

        var query = "?date=" + newItem.date.format('YYYYMMDD') + "&hour=" + newItem.date.format('HH');
        manager.setMapLayer(mapService.addWmsLayer(layerObj.server.url + query, manager.layerId));

        if (manager.layerOpacity()) manager.mapLayer().setOpacity(manager.layerOpacity());

        if (onFinish) onFinish()

    }

    manager.hardcodedProperties = function() {
        return true;
    }

    manager.legend = function () {

        return {
            type: layerObj.type.code.toUpperCase(),
            url: "img/legend_lpf.jpg"
            //layers:mapLayer.wmsParams.layers,
        }
    },
        
    manager.initializeMoveOptions = function() {

        var data = getLayerAvailability();

        manager.setCanMovie(data.length > 1);
        if (manager.canMovie()) {
            //cerco l'index del layer caricato precedentemente
            var iIndexLoadedLayer = _.findIndex(data, function(availableItem) {
                return availableItem.description == manager.item().description;
            });
            //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
            iIndexLoadedLayer = (iIndexLoadedLayer > -1) ? iIndexLoadedLayer : 1;

            //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
            manager.infoAvaialability(iIndexLoadedLayer + 1, data.length);
            manager.infoAvaialability().reverse = (moment(data[0].date).unix() > moment(data[1].date).unix());

        }

    }

    manager.layerProps = {
        "layerProperties": {
            "attributes": [
                {
                    "descr": "Variable",
                    "name":"variable",
                    "entries": [{
                        "descr": "Landslide probability",
                        "value": "prob;0",
                        "referredValues": {
                            "entry": []
                        }

                    }],
                    "id": "variable",
                    "selectedEntry": {
                        "descr": "Landslide probability",
                        "value": "prob;0",
                        "referredValues": {
                            "entry": []
                        }
                    },
                    "type": "List",
                    "visible": "true"
                }

            ],
            "data": manager.layerId,
            "description": layerObj.descr,
            "id": manager.layerId,
            "longDescription": layerObj.descr
        }
    }


    manager.load = function(onFinish) {

        var id_split = layerObj.dataid.split('_');
        manager.layerId = (id_split.length == 1)? id_split[0] : id_split[1];

        manager.setProps(manager.layerProps);

        var to = menuService.getDateTo();

        var hours = (to.getUTCHours() >= 12)? 12 : 0;
        to.setUTCHours(hours, 0, 0, 0);

        manager.setItem({
            "date": to,
            "description": to.toUTCString(),
            "id": to.getTime() + ";" + to.getTime()
        });

        var query = "?date=" + moment(to).format('YYYYMMDD') + "&hour=" + hours;
        manager.setMapLayer(mapService.addWmsLayer(layerObj.server.url + query, manager.layerId));

        // ORG!!
        //downloadUrl = data.serverurl + '/ddsData/' + data.layerid + '.tiff';

        //inizializzo le opzioni per la movie
        manager.initializeMoveOptions();

        if (onFinish) onFinish()

    }

    //costruisco chiamata a rabbit
    manager.updateListener = function() {

        console.log("Empty update Listener");
        manager.wsAcquisition = null;

    };

    manager.removeListener = function () {

    },

    manager.onDateChange = function(onFinish){

        var data = getLayerAvailability();

        //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
        if (manager.infoAvaialability) manager.infoAvaialability(1, data.length);

        update(manager.props(), data[0], onFinish)

    },

    manager.goForward = function() {

        //controllo se ci sono gia delle proprieta caricate
        if (manager.props()) {

            var data = getLayerAvailability();

            //cerco l'index del layer caricato precedentemente
            var iIndexLoadedLayer = _.findIndex(data, function (availableItem) {
                return availableItem.description == manager.item().description;
            });
            //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
            iIndexLoadedLayer = (iIndexLoadedLayer > -1)? iIndexLoadedLayer : 1;

            //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
            if (manager.infoAvaialability) manager.infoAvaialability(iIndexLoadedLayer + 1, data.length);

            update(manager.props(), data[iIndexLoadedLayer + 1], function() {
                mapService.oLayerList.updateLayer(manager)
            })

        }

    }

    manager.goBackward = function() {

        //controllo se ci sono gia delle proprieta caricate
        if (manager.props()) {

            var data = getLayerAvailability();

            //cerco l'index del layer caricato precedentemente
            var iIndexLoadedLayer = _.findIndex(data, function (availableItem) {
                return availableItem.description == manager.item().description;
            });
            //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
            iIndexLoadedLayer = (iIndexLoadedLayer > -1)? iIndexLoadedLayer: 1;

            //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
            if (manager.infoAvaialability) manager.infoAvaialability(iIndexLoadedLayer - 1, data.length );

            update(manager.props(), data[iIndexLoadedLayer - 1], function () {
                mapService.oLayerList.updateLayer(manager)
            })

        }

    }

    manager.showProps = function (onFinish) {

        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties.html',
            controller: "layerPropertiesController",
            size: "lg",
            resolve: {
                params: function() {
                    return {
                        layer: manager.mapLayer()
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {
            update(obj.props, obj.data, onFinish)
        }, function () {
            console.log("CANCEL")
        });

    },

    manager.getLayerAvailability = getLayerAvailability;

    //eseguo chimata rabbit
    manager.updateListener();

    return manager;

}