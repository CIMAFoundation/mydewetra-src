/**
 * Created by doy on 19/06/15.
 */

function layerManager_static(layerObj) {


    const oManager = layerManager_default(layerObj);

    const oServices = oManager.oServices();

    const layer = layerObj;

    let mapLayer = null;

    const downloadUrl = null

    oManager.setLayerObj(layerObj);


    oManager.loadWithProperties = function (onFinish, layerObj, props, item, dateFrom, dateTo, opacity) {
        oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));
        if (opacity) oManager.mapLayer().setOpacity(opacity);
        if (onFinish) onFinish();

    }
    // layerObj:function(){},
    oManager.load = function (onFinish) {
        oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));

        if (onFinish) onFinish()
    }

    // getDownloadUrl: function () {
    //     return downloadUrl
    // },
    oManager.draggable = () => true;

    oManager.type = () => 'STATIC_LAYER';

    oManager.typeDescr = () => 'STATIC';

    oManager.legend = () => {

        try {
            if (oManager && oManager.hasOwnProperty('layerObj') && oManager.layerObj().hasOwnProperty("customprops") && oManager.customprops() != null && oManager.customprops().hasOwnProperty("customLegend")) {


                let legend = {
                    type: "ADVANCED",
                    legend: [{
                        type: "CUSTOM",
                        title: oManager.name(),
                        palette: [],
                        descr: ""
                    }]
                };

                legend.legend[0].palette = oManager.customprops().customLegend['default'].palette;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].img = oManager.customprops().customLegend['default'].img;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].descr = oManager.customprops().customLegend['default'].descr;//default o la variabile che definisci mi permette di gestire multi legenda

                return legend


            } else {
                return {
                    dynPalette: {},
                    type: oManager.layerObj().type.code.toUpperCase(),
                    url: oManager.mapLayer()._url,
                    layers: oManager.mapLayer().wmsParams.layers,
                }
            }
        }catch (e) {
           console.log(e);
        }


    }

    oManager.canMovie = () => false;

    oManager.refreshable = () => false;


    oManager.layerTooltip = function () {


        const tooltipObj = [
            {
                label: "LAYER_NAME",
            },
            {
                label: "LAYER_DESCRIPTION",
                value: oManager.descr()
            },
            {
                label: "LAYER_TYPE",
                value: oManager.type()
            }

        ];
        return tooltipObj;
    },
        oManager.remove = (layer, onFinish) => {
            oServices.mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        oManager.dateLine = () => {
            return "";
        },

        oManager.delayLine = () => {
            return "";
        },

        oManager.customprops = () => {

            let response = {};

            if (oManager.layerObj().hasOwnProperty("customprops")) {
                try {
                    response = JSON.parse(oManager.layerObj().customprops)
                } catch (e) {
                    //console.log(e);
                    response = {};
                }
                return response;
            }
        },

        oManager.parseInfo = (data) => {

            var ret = {
                layerName: oManager.name(),
                properties: []
            };

            if (data.features && data.features.length > 0) {
                data.features.forEach(function (f) {
                    if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                        ret.properties.push({name: 'value', 'value': f.properties.GRAY_INDEX.toFixed(2)})
                    } else {
                        for (p in f.properties) {
                            ret.properties.push({name: p, 'value': f.properties[p]})
                        }
                    }
                })
            }

            ret.properties.forEach(function (item) {
                if (item.name == 'link') {
                    item.html = true;
                } else item.html = false;
            })

            return ret;
        }

    return oManager;


}


function layerManager_static_rasor(layerObj, mapService, layerService, serieService) {

    var manager = layerManager_static(layerObj, mapService, layerService, serieService);

    manager.parseInfo = function (data) {
        var ret = {
            layerName: manager.descr(),
            properties: []
        };

        if (data.features && data.features.length > 0) {
            data.features.forEach(function (f) {
                if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                    ret.properties.push({name: 'value', 'value': f.properties.GRAY_INDEX.toFixed(2)})
                } else {
                    for (p in f.properties) {
                        //se la stringa contiene indicator la tengo senno la taglio
                        if ((p.indexOf('indicator') > -1) && (f.properties[p] != null)) {
                            ret.properties.push({name: p, 'value': f.properties[p]})
                        }
                    }
                }
            })
        }

        return ret;
    };
    return manager;
}


function layerManager_static_gzs(layerObj, mapService, layerService, serieService) {

    var manager = layerManager_static(layerObj, mapService, layerService, serieService);

    var id_split = layerObj.dataid.split('_');
    var layerId = (id_split.length == 1) ? id_split[0] : id_split[1];

    manager.load = function (onFinish) {

        manager.setMapLayer(mapService.addWmsLayer(layerObj.server.url + '?map=/ms4w/apps/Masprem/GeoZS/mapfile_LSMCroatia.map', layerId));
        if (onFinish) onFinish()

    }

    return manager;

}


function layerManager_static_seekms(layerObj, mapService, layerService, serieService) {

    var manager = layerManager_static(layerObj, mapService, layerService, serieService);


    manager.dateLine = function () {
        return "seekms_url"

    }


    manager.showProps = function () {

        let element = document.querySelector('.ng-scope');
        let $window = angular.element(element).injector().get("$window");

        if (manager.hasOwnProperty('customprops') && manager.customprops()["seekms_url"]) {

            $window.open(manager.customprops()["seekms_url"]);
        } else {
            return "";
        }

    }


    return manager;

}


function manageLayer_static(layer, $scope, $uibModal, mapService, layerService, serieService) {

    mapService.addStaticLayer(layer);
    $scope.layerList = mapService.layersGroup.getLayers();

    return {
        model: layer,
        nameBuilder: function (layer) {
            return layer.descr
        }

    }


}

function layerManager_CUSTOM_LEGEND_STATIC(layerObj, mapService, layerService, serieService) {

    var manager = layerManager_static(layerObj, mapService, layerService, serieService);

    console.log(layerObj)

    layerObj.customprops = JSON.parse(layerObj.customprops)

    manager.legend = function () {
        if (layerObj.hasOwnProperty("customprops")) {


            var legend = {
                type: "ADVANCED",
                legend: [{
                    type: "CUSTOM",
                    title: layerObj.name,
                    palette: []
                }]
            };


            if (layerObj.customprops.hasOwnProperty("customLegend")) {

                legend.legend[0].palette = layerObj.customprops.customLegend.default;//default o la variabile che definisci mi permette di gestire multi legenda

                console.log(legend)

                return legend
            }


        }
    }

    return manager


}


function layerManager_STATIC_DESCR_LINE(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout, $rootScope, thresholdService) {

    var manager = layerManager_static(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService, tagService, apiService, _, sentinelService, $interval, floodproofsService, $translate, iconService, $timeout, $rootScope, thresholdService);

    manager.thirdLine = function () {
        return true
    }

    manager.getVariable = function () {
        return layerObj.descr;
    }

    return manager


}





