/**
 * Created by Mirko D'Andrea on 14/09/2017
 */

var RISICOLiveService = function(){
    var $http = angular.injector(["ng"]).get("$http");
    var $window = angular.injector(["ng"]).get("$window");
    const acAuthSrv = angular.element(document.querySelector('.ng-scope')).injector().get('acAuthSrv');
    this.server = 'https://dds.cimafoundation.org/risico_live/';
    //this.server = 'http://localhost:8085/risico_live/';
    var server = this.server;

    this.getStationGroup = function () {
        let token =(acAuthSrv.hasOwnProperty('getToken'))?encodeURIComponent(acAuthSrv.getToken()):undefined;

        if(angular.isUndefined(token)) token = encodeURIComponent($window.localStorage.token)


        return $http
            .get(window.app.url.dewapiURL + 'settings/settings/'+'?acroweb_token='+token, {timeout: 120*1000})
            .then(function(res){
                return res.data.objects[0];
            });
    }



    this.getStations = function(settings){
        return $http
            .get(server + 'stations/', {timeout: 120*1000})
            .then(function(res){
                return res.data;
            });
    };

    this.getStationsWithValues = function(date_from, date_to, settings){

        var date_from_str = moment(date_from).toISOString();
        var date_to_str = moment(date_to).toISOString();

        let query= '';

        if(settings && settings.hasOwnProperty('stationgroup')){
            query += '&groupid='+settings.stationgroup;
        }

        return $http
            .get(
                server + 'timeseries/?from=' + date_from_str + '&to=' + date_to_str + query,
                {timeout: 120*1000}
            )
            .then(function(res){
                return res.data;
            });

    };

    this.getStationTimeseries = function(station_id, date_from, date_to){
        var date_from_str = moment(date_from).toISOString();
        var date_to_str = moment(date_to).toISOString();

        return $http
            .get(
                server + 'timeseries/' + station_id + '/?from=' + date_from_str + '&to=' + date_to_str,
                {timeout: 120*1000}
            )
            .then(function(res){
                return res.data;
            });
    };


    return this;
};

var variables = {
    "moisture": {
        "group": "output",
        //"levels": [ 0, 5, 10, 12, 15, 17, 20, 25, 30, 35, 50, 1000],
        //"colors": [ "#c109b5", "#FF0000","#FF6400","#FF8500","#FFA600","#FFC800","#A6A6FF","#8585FF","#6464FF","#3232FF","#0000FF"],
        //"labels": [ "<5%", "5%-10%", "10%-20%", "20%-30%", "30%-40%", ">40%"],
        "levels": [ 0, 5, 12, 1000],
        "colors": [ "#FF0000", "#FFFF00", "#00FF00", "#FF40FF"],
        "labels": [ " molto secco", " secco", " umido"],

        "units": "%",
        "min_max_y": [0, 50],
        "chart_type": "line"
    },
    "ros": {
        "group": "output",
        "levels": [ 0, 120, 210, 1000000],
        "colors": [ "#00FF00", "#FFFF00", "#FF0000", "#FF40FF"],
        "labels": [ " lenta", " media", " veloce", "-"],
        "units": "m/h",
        "min_max_y": [0, 300],
        "chart_type": "line"
    },/*
    "intensity": {
        "group": "output",
        "levels": [0,86,345,1724,2000,3500,4000,10000],
        "colors": ["#0000FF", "#0000FF", "#00FF00", "#ADFF2F", "#FFFF00", "#FF8000", "#FF0000", "#FF40FF"],
        "unity": "kW/m",
        "labels": [ "<5%", "5%-10%", "10%-20%", "20%-30%", "30%-40%", ">40%"],
        "min_max_y": [0, 4500],
        "chart_type": "line"
    },*/
    "wind_effect": {
        "group": "output",
        "levels": [1, 1.1, 1.5, 3 ],
        "colors": ["#00FF00", "#FFFF00", "#FF0000", "#FFFF00", "#FF9600", "#FF0000", "#FF64FF", "#FF00FF", "#000000"],
        "labels": [ " assenza di vento", " vento debole", "vento forte","-"],
        "unity": "adim",
        "min_max_y": [1, 3],
        "chart_type": "line"
    },
    // "wind_effect": {
    //     "group": "output",
    //     "levels": [1, 1.1, 1.5, 1.8, 2, 2.2, 2.5, 2.7, 3],
    //     "colors": ["#00FFFF", "#00FF00", "#00FF96", "#FFFF00", "#FF9600", "#FF0000", "#FF64FF", "#FF00FF", "#000000"],
    //     "labels": [ "<5%", "5%-10%", "10%-20%", "20%-30%", "30%-40%", ">40%"],
    //     "unity": "adim",
    //     "min_max_y": [1, 3],
    //     "chart_type": "line"
    // },
    "p": {
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "mm",
        "min_max_y": [0, 100],
        "chart_type": "bar"
    },
    "t": {
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "°C",
        "chart_type": "line"
    },
    "ws": {
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "m/s",
        "chart_type": "line"
    },

    "wind": {
        /* handled in a special case */
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "m/s",
    },

    "wd": {
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "°",
        "chart_type": "windbarb"
    },
    "h": {
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "%",
        "min_max_y": [0, 100],
        "chart_type": "line"
    },
    "gsi": {
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "-",
        "min_max_y": [0, 1],
        "chart_type": "line"
    },
    "igsi": {
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "-",
        "min_max_y": [0, 1],
        "chart_type": "line"
    },
    "sm": {
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "%",
        "min_max_y": [0, 1],
        "chart_type": "line"
    },
    "pheno_phase": {
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "-",
        "min_max_y": [0, 6],
        "chart_type": "line"
    },
    "grass_phase": {
        "group": "input",
        "levels": [],
        "colors": [],
        "labels": [],
        "units": "-",
        "min_max_y": [0, 6],
        "chart_type": "line"
    }
};


function hexToRgb(hex, alpha) {
    hex   = hex.replace('#', '');
    var r = parseInt(hex.length == 3 ? hex.slice(0, 1).repeat(2) : hex.slice(0, 2), 16);
    var g = parseInt(hex.length == 3 ? hex.slice(1, 2).repeat(2) : hex.slice(2, 4), 16);
    var b = parseInt(hex.length == 3 ? hex.slice(2, 3).repeat(2) : hex.slice(4, 6), 16);
    if ( alpha ) {
        return 'rgba(' + r + ', ' + g + ', ' + b + ', ' + alpha + ')';
    }
    else {
        return 'rgb(' + r + ', ' + g + ', ' + b + ')';
    }
}

function addPlotBands(variables) {
    for (var k in variables) {
        var v = variables[k];
        if (v.levels && v.colors) {
            v.plotBands = [];
            for (var i = 0; i < v.levels.length - 1; i++) {
                v.plotBands.push({
                    from: v.levels[i],
                    to: v.levels[i + 1],
                    color: hexToRgb(v.colors[i], 0.3)
                });
            }
        }
    }
}

addPlotBands(variables);


function getPalette(variable, value) {
    if (value == null){
        return {
            color: "darkgray",
            label: "NO_DATA"
        }
    }


    var levels = variables[variable].levels;
    var colors = variables[variable].colors;
    var labels = variables[variable].labels;
    var i = 0;
    for(; i<levels.length-1; i++){
        if(value>=levels[i] && value<levels[i+1]){
            break;
        }
    }

    return {
        color: colors[i],
        label: labels[i]
    }

}


function layerManager_risico_live(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService) {
    var manager = layerManager_static(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService);

    var service = RISICOLiveService();

    var ICON_SIZE = 14;
    var visible=true;

    var layer = layerObj;
    var mapLayer = null;
    var theGeoJson = null;
    var infoPopUP = null;

    var RISICOLiveFeatureStyle = {
        weight : 1,
        opacity : 1,
        fillOpacity: 0.6
    };

    var props = {

        variable:{
            name:"VARIABLE",
            descr:"VARIABLE_DESCR",
            date :false,
            type:false,
            typeSelected:{
                name: "moisture",
                descr:"moisture_descr",
                value:"moisture"
            },
            typeAttr:[{
                name: "moisture",
                descr:"moisture_descr",
                value:"moisture"
            },/*
            {
                name: "intensity",
                descr:"intensity_descr",
                value:"intensity"
            },*/
            {
                name: "ros",
                descr:"ros_descr",
                value:"ros"
            },{
                name: "wind_effect",
                descr:"wind_effect_descr",
                value:"wind_effect"
            }]
        },
        aggr_fun:{
            name:"AGGR_FUNCTION",
            descr:"AGGR_FUNCTION_DESCR",
            date :false,
            type:false,
            typeSelected:{
                name: "mean",
                descr:"mean_descr",
                value:"mean"
            },
            typeAttr:[{
                name: "min",
                descr:"min_descr",
                value:"min"
            },{
                name: "max",
                descr:"max_descr",
                value:"max"
            },{
                name: "mean",
                descr:"mean_descr",
                value:"mean"
            }]
        },
        time_interval:{
            name:"TIME_INTERVAL",
            descr:"TIME_INTERVAL_DESCR",
            date :false,
            type:true,
            typeSelected:{
                name: "LAST_12H",
                descr:"LAST_12H_descr",
                value:"12h"
            },
            typeAttr:[{
                name: "SYSTEM",
                descr:"SYSTEM_TIME_INTERVAL_desc",
                value:"system"
            },{
                name: "LAST_1H",
                descr:"LAST_1H_descr",
                value:"1h"
            },{
                name: "LAST_3H",
                descr:"LAST_3H_descr",
                value:"3h"
            },{
                name: "LAST_6H",
                descr:"LAST_6H_descr",
                value:"6h"
            },{
                name: "LAST_12H",
                descr:"LAST_12H_descr",
                value:"12h"
            },{
                name: "LAST_24H",
                descr:"LAST_24H_descr",
                value:"24h"
            }]
        }
    };



    function stationClickListener(s) {

        if (s.target.feature.properties.value <=-9998) {
            alert($translate.instant('UNAVAILABLE_DATA'));
            return;
        }

        var modalInstance = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/risico_live_chart_form.html',
            controller: 'RISICOLiveChartController',
            size: 'lg',
            keyboard: false,
            resolve: {
                stationInfo: function () {
                    return {
                        id_centr : s.target.feature.properties.id,
                        name : s.target.feature.properties.name,
                        RISICOLiveService : service,
                        variables: variables,
                        props: props,
                        from: menuService.getDateFrom(),
                        to: menuService.getDateTo()
                    };

                }

            }
        })

    }



    function InfoMouseOver(s) {
        if (infoPopUP) {
            // costruisce la vista per il controller delle info
            var properties = s.target.feature.properties;
            var time_interval = props.time_interval.typeSelected.value;
            var start_str = time_interval + '_';

            var exp_prop = {};
            exp_prop.meta = {};
            exp_prop.meta.name = properties.name;
            exp_prop.meta[props.time_interval.descr] = props.time_interval.typeSelected.descr;
            exp_prop.meta[props.aggr_fun.descr] = props.aggr_fun.typeSelected.descr;
            exp_prop.meta[props.variable.descr] = props.variable.typeSelected.descr;

            exp_prop.values =
                Object.keys(properties)
                .filter(function(k){
                    return k.startsWith(start_str)
                })
                .filter(function(k){
                    var time_aggr_and_name = k.split('_');
                    return (time_aggr_and_name[2] in variables);
                })
                .reduce(function(d, k){
                    var nk = k.replace(start_str, '');
                    d[nk] = properties[k];
                    return d;
                }, {});


            infoPopUP.mouseOver('risico_live', mapLayer._leaflet_id, exp_prop);
        }
    }

    function InfoMouseOut() {
        if (infoPopUP) {
            infoPopUP.mouseOut('risico_live', mapLayer._leaflet_id)
        }
    }

    function update(newProps, onFinish){
        var update = false;

        for (var name in props){
            if (update == false)
                if (props[name].typeSelected.value != newProps[name].typeSelected.value){
                    update = true;
                }
        }

        if (update){
            props = newProps;
            manager.load(onFinish);
        }else{
            props = newProps;
            console.log(props);
            if(onFinish)onFinish();
        }
    }

    manager.isRemoved = false;
    manager.isLoading = false;
    manager.layerObj = function () {
        if(manager.isLoading){
            var loading_layer = angular.copy(layer);
            loading_layer.icon = layer.icon + '   faa-flash faa-slow animated';
            return loading_layer;
        }else{
            return layer
        }
    };

    manager.mapLayer = function () {
        if(mapLayer) {
            return mapLayer
        }else{
            // fix per fare apparire il layer disabilitato quando fa il loading
            return {
                options: {
                    opacity: 0
                }
            }
        }
    };

    manager.setMapLayer = function (l) {
        mapLayer = l;
    };

    manager.load = function(onFinish){
        var obj = {
            id:layerObj.dataid,
            from: menuService.getDateFrom(),
            to: menuService.getDateTo(),
            props: {
                variable: props.variable.typeSelected.value,
                aggr_fun:props.aggr_fun.typeSelected.value,
                time_interval:props.time_interval.typeSelected.value
            }
        };


        manager.isLoading = true;
        visible = false;
        service
        .getStationGroup()
            .then(function (settings) {
                service.getStationsWithValues(obj.from, obj.to, settings)
                    .then(function(data){
                        manager.isLoading = false;
                        if(manager.isRemoved){return;}

                        visible = true;
                        theGeoJson = data;
                        if (mapLayer) mapService.removeLayer(mapLayer);

                        var key = obj.props.time_interval + '_' + obj.props.aggr_fun + '_' + obj.props.variable;
                        console.log(key);

                        mapLayer = mapService.addGeoJsonLayer(theGeoJson.features, layerObj.name, {
                            pointToLayer: function(feature, latlng) {
                                var p = feature.properties;
                                feature.properties.fillColor = getPalette(obj.props.variable, p[key]).color;
                                return L.circleMarker(latlng, iconService.phenological_analysis_Icon(feature));
                            }


                        }, stationClickListener, InfoMouseOver, InfoMouseOut);
                    }).catch(function(error){
                    manager.isLoading = false;
                });
                onFinish && onFinish();
            })



    };

    manager.layerTooltip = function(){
        var tooltipObj=[
            {
                label : "LAYER_NAME",
                value : manager.name()
            }
        ];

        for(var key in props){
            tooltipObj.push({
                label:props[key].descr,
                value:props[key].typeSelected.descr,
            })
        }

        return tooltipObj;
    };

    manager.onDateChange = function(onFinish){
        if (mapLayer) mapService.removeLayer(mapLayer);
        this.load(onFinish)
    };

    manager.setOpacity = function(value){
        if (value){
            RISICOLiveFeatureStyle.opacity = value;
            RISICOLiveFeatureStyle.fillOpacity = value;
            //updateFeatureStyle()
        }
    };

    manager.getOpacity = function(){
        return RISICOLiveFeatureStyle.opacity
    };

    manager.remove = function (layer, onFinish) {
        manager.isRemoved = true;
        mapService.removeLayer(layer);
        if (onFinish) {
            onFinish()
        }
    };

    manager.name = function() {
        return layer.descr;
    };

    manager.descr = function () {
        return props.variable.typeSelected.descr
        //return $translate.instant(props.time_interval.typeSelected.descr);
    };

    manager.draggable = function () {
        return false;
    };

    manager.typeDescr = function () {
        // var s =
        //     $translate.instant(props.aggr_fun.typeSelected.descr) + ' ' +
        //     $translate.instant(props.variable.typeSelected.descr) + ' ' +
        //     $translate.instant('_ON_');
        // return s;
        return props.variable.typeSelected.descr
    };

    manager.dateLine = function(){
        return props.variable.typeSelected.descr
    }

    manager.setWarningInfo = function (wi) {
        infoPopUP = wi;
    };

    manager.getWarningInfo = function () {
        return infoPopUP;
    };

    manager.showProps = function (onFinish) {
        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties_rasor_damage.html',
            controller:['$scope', '$uibModalInstance', 'params', function ($scope, $uibModalInstance, params){
                $scope.data = angular.copy(params.props);

                $scope.update = function () {
                    $uibModalInstance.close($scope.data);
                };
                $scope.closePopup = function () {
                    $uibModalInstance.dismiss()
                }
            }],
            size: "lg",

            resolve: {
                params: function() {
                    return {
                        layer: mapLayer,
                        props:props
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {
            update(obj, onFinish)

        }, function () {
            console.log("CANCEL")
        });
    };

    //manager.geoServerPalette: palette,

    manager.legend = function () {
        return{
            type:layerObj.type.code.toUpperCase(),
            palette:palette[props.analysis.typeSelected.value]
        }
    };

    manager.setVisible = function (b) {
        visible = b;
        if (!b) mapLayer.clearLayers();
        else mapLayer.addData(theGeoJson);
    };

    manager.isVisible = function(){
        return visible;
    };

    manager.legend = function () {
        var legend = {
            type:"ADVANCED",
            // title:"RISICO_LIVE_LEGEND_TITLE",
            legend:[{
                type:"CUSTOM",
                title: $translate.instant(props.variable.typeSelected.descr),
                palette: []
            }]
        };

        var sel_var = props.variable.typeSelected.value;
        var sel_var_descr = props.variable.typeSelected.descr;
        var levels = variables[sel_var].levels;
        var colors = variables[sel_var].colors;
        var units = variables[sel_var].units;
        var labels = variables[sel_var].labels;

        var palette = [];
        legend.legend[0].palette = palette;
        for(var i=0; i<levels.length-1; i++){
            palette.push({
                label:labels[i],
                color:colors[i],
                sign:"",
                value:levels[i],
                mu:units,
                dec:1

            });
        }
        console.log(legend);

        return legend;
    };

    manager.thirdLine =function(){
        return ""
    },

    manager.getVariable=function () {
        return props.aggr_fun.typeSelected.descr
    },

    manager.getAggregation=function () {
        return props.time_interval.typeSelected.descr
    }


    return manager;
}
