function layerManager_dynamic_external_wmst_ea_hazards_watch_time_parameters(layerObj) {

    var isVisible = true;

    var iOpacity = 1;

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices();

    var isLoaded = false;

    var timer = null;

    var to;

    var modalInstance;

    //https://droughtwatch.icpac.net/mapserver/mukau/php/gis/mswms.php?map=mukau_w_mf&LAYERS=cdi&FORMAT=image/png&TRANSPARENT=TRUE&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&SELECTED_YEAR=2021&SELECTED_MONTH=08&SELECTED_TENDAYS=21&SRS=EPSG:900913&BBOX=2504688.542848654,0,3757032.814272985,1252344.271424327&WIDTH=256&HEIGHT=256

    const decades = [
        {
            value: '01',
            descr: 'first decades 01->10'
        },
        {
            value: '11',
            descr: 'second decades 11->20'
        },
        {
            value: '21',
            descr: 'third decades 21->31'
        },
    ];

    let selectedDecade = 0;

    var WMSParams = {
        service: 'WMS',
        request: 'GetMap',
        map: 'mukau_w_mf',
        // version: '1.3.0',
        version: '1.1.1',
        layers: layerObj.dataid,
        // styles: '',
        // time:'',
        // SELECTED_YEAR:
        // srsName:'EPSG:3857',
        // crsName:'EPSG:3857',
        format: 'image/png',
        width: 512,
        height: 512,
       // width=256&height=256
        //tiled: true,
        transparent: true
    };


    function update(onFinish, selectedDate){

        if (oManager.mapLayer()){
            iOpacity = oManager.mapLayer().options.opacity
        }

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        WMSParams.SELECTED_YEAR = moment.utc(oServices.menuService.getDateTo()).year();

        WMSParams.SELECTED_MONTH = moment.utc(oServices.menuService.getDateTo()).month() + 1;

        let first_decade = moment.utc(oServices.menuService.getDateTo()).set('date',1);
        let second_decade = moment.utc(oServices.menuService.getDateTo()).set('date',11) ;
        let third_decade = moment.utc(oServices.menuService.getDateTo()).set('date',21);

        //Choose which decades

        if(first_decade.isSameOrBefore(oServices.menuService.getDateTo())){
            selectedDecade = 0
        }
        if(second_decade.isSameOrBefore(oServices.menuService.getDateTo())){
            selectedDecade = 1
        }
        if(third_decade.isSameOrBefore(oServices.menuService.getDateTo())){
            selectedDecade = 2
        }

        WMSParams.SELECTED_TENDAYS = decades[selectedDecade].value;

        oManager.setMapLayer(oServices.mapService.addSingleTileWmsLayer(layerObj.server.url , WMSParams));

        oManager.mapLayer().setOpacity(iOpacity)

        if (onFinish) onFinish()

    }

    oManager.load = function(onFinish) {

        update(onFinish);

    };

    delete oManager.showProps

    oManager.draggable = function(){
        return true
    }

    oManager.onDateChange = function(onFinish){
        update(onFinish)

    };

    // oManager.parseInfo = function (layer, data, url) {
    //
    //     if(oManager.layerObj().hasOwnProperty("customprops")){
    //         if (oManager.customprops().hasOwnProperty("queryable")){
    //             if(oManager.customprops().queryable == false) {
    //                 alert(oServices.$translate.instant('NOT_QUERYABLE') + " "  + oManager.name())
    //                 return
    //             };
    //         }
    //     }
    //
    //
    //     //
    //     //if(modalInstance != null) return
    //     modalInstance = oServices.$uibModal.open({
    //         animation: true,
    //         component: 'efasReportingPointInfo',
    //         size:'lg',
    //         resolve:{
    //             oManager:function () {
    //                 return oManager
    //             },
    //             dateRun: function() {
    //                 return  to
    //             }
    //         }
    //     });
    //
    //     modalInstance.result.then(function (obj) {
    //
    //         console.log('modal-component dismissed at: ' + new Date());
    //         modalInstance = null;
    //
    //     }, function () {
    //         console.log('modal-component dismissed at: ' + new Date());
    //         modalInstance = null;
    //     });
    //
    //
    //
    // }

    oManager.thirdLine= function () {
        return true
    }



    oManager.getVariable = function () {
        if(WMSParams && WMSParams.SELECTED_YEAR && WMSParams.SELECTED_MONTH && WMSParams.SELECTED_TENDAYS) {
            return WMSParams.SELECTED_YEAR + "/" + WMSParams.SELECTED_MONTH + "/ " + decades[selectedDecade].descr
        }
    }

    oManager.getAggregation = function () {
        return "";
    }



    delete oManager.getDownloadUrl;




    oManager.legend = function () {

        var legend = {
            type: "ADVANCED",
            legend: [{
                type: "CUSTOM",
                title: oManager.name(),
                palette: [],
                descr:""
            }]
        };


        if(oManager.layerObj().hasOwnProperty("customprops")){
            if (oManager.customprops().hasOwnProperty("customLegend")){
                legend.legend[0].palette = oManager.customprops().customLegend['default'].palette;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].img = oManager.customprops().customLegend['default'].img;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].descr = oManager.customprops().customLegend['default'].descr;//default o la variabile che definisci mi permette di gestire multi legenda

                return legend
            }
        }
    }

    return oManager
}



