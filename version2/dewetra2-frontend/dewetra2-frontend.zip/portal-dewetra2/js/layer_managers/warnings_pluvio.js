/**
 * Created by Dario Rubado on 19/06/15.
 */



function layerManager_warnings_pluvio(layerObj, mapService, layerService, serieService, menuService, $uibModal, acEvent, audioService,tagService ,apiService, _, sentinelService, $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService) {

    var layer = layerObj;
    var layerData = null;

    var warningInfo = null;

    var mapLayer = null;

    var layerProps = null;

    var props = null;

    var visible = true;

    var theGeoJsonStation = null;

    var arrayAnagrafica = [];

    var loadedJson = null;
    var aggregationType = null;
    var LowThresholdSet = 1;
    var HighThresholdSet = 1;

    var triggerTime = 18000;

    var timeToUndef = 7200;

    var lastUpdate = null;

    var stringSoglie = "e_";
    var stringValori = "v_";
    //Setto se sono nel passato
    var bPast = !menuService.isRealTime();

    var audioCounter = null;

    var bOnOverShowThreshold = true;
    var urlRegioniMap = "http://dds.cimafoundation.org/sentinel/sentinelapi/aggr/layer/regions_it/";
    var urlProvinceMap = "http://dds.cimafoundation.org/sentinel/sentinelapi/aggr/layer/districts_it/";
    var urlComuniMap = "http://dds.cimafoundation.org/sentinel/sentinelapi/aggr/layer/municipalities_it/";
    var urlBaciniMap = "http://dds.cimafoundation.org/sentinel/sentinelapi/aggr/layer/catchments_it/";
    var urlAreeAllertamentoMap = "http://dds.cimafoundation.org/sentinel/sentinelapi/aggr/layer/warningareas_it/";


    var sRegioniInLocalStorage  = "LocalStorage_Warning_Regioni";
    var sProvinceInLocalStorage  = "LocalStorage_Warning_Province";
    var sComuniInLocalStorage  = "LocalStorage_Warning_Comuni";
    var sBaciniMapInLocalStorage = "LocalStorage_Warning_Bacini";
    var sAreeAllertamentoMapInLocalStorage = "LocalStorage_Warning_AreeAllertamento";
    var geoJsonRegioni = null;
    var geoJsonProvince = null;
    var geoJsonComuni = null;
    var geoJsonBacini = null;
    var geoJsonAreeAllertamento = null;

    var wsAcquisition = null;

    var bWidget = false;

    var debug = menuService.debug;

    var markerWarningOption = {
        radius : iconService.markerWarningOptions.radius,
        weight : iconService.markerWarningOptions.weight,
        color : iconService.markerWarningOptions.color,
        opacity : iconService.markerWarningOptions.opacity,
        fillOpacity: iconService.markerWarningOptions.fillOpacity
    };
    //palette definita in icon service
    var geoServerPalette = iconService.warningPluvioPalette;

    var updateListener = function(){

        if(wsAcquisition) removeListener();
        if(debug)console.log("update Listener");
        acEvent.connect(window.app.acEvent.username, window.app.acEvent.password, function () {
            wsAcquisition = acEvent.subscribe(window.app.acEvent.queue+'.national_PLUVIOMETRO', updateStation)
            // wsAcquisition = acEvent.subscribe('TEST_KEY', updateStation)

        },function () {
            if(debug)console.log('waiting 5 seconds and then reconnect');
            setTimeout(updateListener,5000)
        })

    };

    var oPluvioData = {
        theGeoJsonStation: null,
        theGeoJsonRegion: null,
        theGeoJsonDistrict:null,
        theGeoJsonComuni:null,
        theGeoJsonBacini: null,
        theGeoJsonWarningArea: null,
        theGeoJsonTopoieti: null,
        aAnagrafica: [],
        promise: [],
        exportCvs:function () {
            var array =[];
            this.getGeoJsonStation().features.forEach(function(station){
                array.push(station.properties);
            })
            return array;
        },
        audio: function(oldFeatureProperties, newFeatureProperties){

            if((newFeatureProperties.warning_palette == 3)||(newFeatureProperties.warning_palette == 2)&&(newFeatureProperties.warning_palette > oldFeatureProperties.warning_palette)){
                if (audioService)audioService.playAudio({type:'zoomTo', properties: newFeatureProperties});
                if(debug)console.log("testaudio");

            }
        },
        anagrafica: function(){
            if (this.aAnagrafica.length == 0){
                for(var s in this.theGeoJsonStation.features){
                    if(!_.isUndefined(this.theGeoJsonStation.features[s].properties)) {
                        try{
                            this.aAnagrafica[this.theGeoJsonStation.features[s].properties.sensorid] = {
                                regione: this.theGeoJsonStation.features[s].properties.region,
                                provincia: this.theGeoJsonStation.features[s].properties.district,
                                comune: this.theGeoJsonStation.features[s].properties.munic,
                                bacino: this.theGeoJsonStation.features[s].properties.catchment,
                                areaAllertamento: this.theGeoJsonStation.features[s].properties.wa
                            }
                        }
                        catch(err){
                            if(debug)console.log(err);
                            var p = this.theGeoJsonStation.features['move'];
                            if(debug)console.log(p)
                        }
                    }
                }
            }
        },
        brintRelevantToFront: function(){
            for(var p in mapLayer._layers){
                if((mapLayer._layers[p].feature.properties.warning_palette ==3)){
                    mapLayer._layers[p].bringToFront();
                }
                if((mapLayer._layers[p].feature.properties.warning_palette ==-1)){
                    mapLayer._layers[p].bringToBack();
                }
            }
        },
        putUndefinedBack:function(){

            for(var p in mapLayer._layers){
                if((mapLayer._layers[p].feature.properties.warning_palette ==-2)){
                    mapLayer._layers[p].bringToBack();
                }
            }

            for(var p in mapLayer._layers){
                if((mapLayer._layers[p].feature.properties.warning_palette ==3)){
                    mapLayer._layers[p].bringToFront();
                }
            }

        },
        checkOldData: function(){
            var promise = null;
            promise = $interval(function () {
                oPluvioData.checkOldData()
            }, triggerTime);
            oPluvioData.promise.push(promise);
        },
        delCheckOldData: function () {
            if(oPluvioData.promise){
                oPluvioData.promise.forEach(function (promise) {
                    $interval.cancel(promise);
                })
            }
            audioPromise =[]
        },
        setGeoJsonStation: function(json) {
            json.features.forEach(function (features) { //error
                features.properties = oPluvioData.validateDataByTime(features.properties);
                features.properties.warning_palette = oPluvioData.palette(features.properties)
            });
            this.theGeoJsonStation= json;
            //build Dictionary anagrafica
            this.anagrafica();
        },
        setTheGeoJsonRegion : function(json){
            this.theGeoJsonRegion = json;
            this.updateTheGeoJsonRegion()
        },
        setTheGeoJsonDistrict : function(json){
            this.theGeoJsonDistrict = json;
            this.updateTheGeoJsonDistrict()
        },
        setTheGeoJsonComuni : function(json){
            this.theGeoJsonComuni = json;
            this.updateTheGeoJsonComune();
        },
        setTheGeoJsonBacini : function(json){
            this.theGeoJsonBacini = json;
            this.updateTheGeoJsonBacini();
        },
        setTheGeoJsonWarningArea : function(json){
            this.theGeoJsonWarningArea = json;
            this.updateTheGeoJsonWarningArea();
        },
        setTheGeoJsonTopoieti : function(json){
            this.theGeoJsonTopoieti = json;
            this.updateTheGeoJsonTopoieti();
        },
        getGeoJsonStation: function () {
            return this.theGeoJsonStation;
        },
        getTheGeoJsonRegion : function(){
            return this.theGeoJsonRegion;
        },
        getTheGeoJsonDistrict : function(){
            return this.theGeoJsonDistrict;
        },
        getTheGeoJsonComuni : function(){
            return this.theGeoJsonComuni;
        },
        getTheGeoJsonBacini : function(){
            return this.theGeoJsonBacini;
        },
        getTheGeoJsonAreeAllertamento : function(){
            return this.theGeoJsonWarningArea;
        },
        getTheGeoJsonTopoieti : function(){
            return this.theGeoJsonTopoieti;
        },
        updateTheGeoJsonStation : function(aProperties){

            if(aProperties.length > 0){
                aProperties.forEach(function (properties) {

                    var o = oPluvioData.validateDataByTime(properties);
                    o.warning_palette = oPluvioData.palette(o);
                    var f = _.findIndex(oPluvioData.theGeoJsonStation.features, function(feature){
                        if (feature.properties.sensorid == o.sensorid) return true;
                    });
                    //if(debug)console.log(f)
                    if (f > -1) {
                        //controllo se deve suonare
                        oPluvioData.audio(oPluvioData.theGeoJsonStation.features[f].properties, o);
                        //if(debug)console.log("update feature properties")
                        oPluvioData.theGeoJsonStation.features[f].properties = o;
                    }
                });
                if(debug)console.log("update feature style");
                oPluvioData.updateFeatureStyle();
            }else {
                oPluvioData.theGeoJsonStation.features.forEach(function (station) {
                    var o = oPluvioData.validateDataByTime(station.properties);
                    o.warning_palette = oPluvioData.palette(o);
                    station.properties = o;
                });
                oPluvioData.updateFeatureStyle();
            }

        },

        updateFeatureStyle:function(){

            //test
            // if(!menuService.isRealTime())this.resetAggregation();



            switch(aggregationType) {
                case "REGIONE":
                    if(debug)console.log("regione");
                    this.updateTheGeoJsonRegion();
                    this.updateRegionFeaturesStyle();
                    break;
                case "PROVINCE":
                    if(debug)console.log("province");
                    this.updateTheGeoJsonDistrict();
                    this.updateDistrictFeaturesStyle();
                    break;
                case "COMUNI":
                    this.updateTheGeoJsonComune();
                    this.updateComuniFeaturesStyle();
                    if(debug)console.log("comuni");
                    break;
                case "STAZIONI":
                    this.updateMarkerStyle();
                    if(debug)console.log("stazioni");
                    break;
                case "BACINI":
                    this.updateTheGeoJsonBacini();
                    this.updateBaciniFeatureStyle();
                    if(debug)console.log("bacini");
                    break;
                case "AREEALLERTAMENTO":
                    this.updateTheGeoJsonWarningArea();
                    this.updateWarningAreaFeatureStyle();
                    if(debug)console.log("aree Allertamento");
                    break;
                default:{
                    this.updateMarkerStyle()
                }
            }
        },

        updateMarkerStyle:function(){
            if(debug)console.log("update marker style");
            this.theGeoJsonStation.features.forEach(function(station){

                var f = _.findKey(mapLayer._layers, function (marker) {
                    return (marker.feature.properties.sensorid == station.properties.sensorid)
                });
                if(f > -1){
                    //if(debug)console.log("setStyle marke")

                    mapLayer._layers[f].setStyle(
                            {
                                fillColor: geoServerPalette[station.properties.warning_palette],
                                opacity: markerWarningOption.opacity,
                                fillOpacity: markerWarningOption.fillOpacity,
                                color : markerWarningOption.color,
                                weight: markerWarningOption.weight
                            }
                    );
                    if (mapLayer._layers[f].feature.properties.warning_palette ==1 ||mapLayer._layers[f].feature.properties.warning_palette ==2 || mapLayer._layers[f].feature.properties.warning_palette ==3|| mapLayer._layers[f].feature.properties.warning_palette ==4)mapLayer._layers[f].bringToFront();

                    mapLayer._layers[f].feature.properties = station.properties;
                }
            });
        },

        updateRegionFeaturesStyle:function(){

            this.theGeoJsonRegion.features.forEach(function(region){

                var f = _.findKey(mapLayer._layers, function (marker) {
                    return (marker.feature.properties.gid == region.properties.gid);
                });

                if(!_.isUndefined(f)){

                    mapLayer._layers[f].feature.properties = region.properties;

                    mapLayer._layers[f].setStyle(
                            {
                                fillColor: geoServerPalette[region.properties.warning_palette],
                                opacity: markerWarningOption.opacity,
                                fillOpacity: markerWarningOption.fillOpacity,
                                color : markerWarningOption.color,
                                weight: markerWarningOption.weight
                            }
                    )
                    mapLayer._layers[f].bringToFront();
                }
            });
        },

        updateDistrictFeaturesStyle:function(){

            this.theGeoJsonDistrict.features.forEach(function(province){

                var f = _.findKey(mapLayer._layers, function (layerProvincia) {
                    return (layerProvincia.feature.properties.gid==province.properties.gid);
                });

                if(!_.isUndefined(f)){

                    mapLayer._layers[f].properties = province.properties;

                    mapLayer._layers[f].setStyle(
                            {
                                fillColor: geoServerPalette[province.properties.warning_palette],
                                opacity: markerWarningOption.opacity,
                                fillOpacity: markerWarningOption.fillOpacity,
                                color : markerWarningOption.color,
                                weight: markerWarningOption.weight
                            }
                    )
                    mapLayer._layers[f].bringToFront();
                }
            });
        },

        updateComuniFeaturesStyle:function(){

            this.theGeoJsonComuni.features.forEach(function(comune){

                var f = _.findKey(mapLayer._layers, function (layerComune) {
                    return (layerComune.feature.properties.gid == comune.properties.gid);
                });

                if(!_.isUndefined(f)){

                    mapLayer._layers[f].feature.properties = comune.properties;
                    mapLayer._layers[f].setStyle(
                            {
                                fillColor: geoServerPalette[comune.properties.warning_palette],
                                opacity: markerWarningOption.opacity,
                                fillOpacity: markerWarningOption.fillOpacity,
                                color : markerWarningOption.color,
                                weight: markerWarningOption.weight
                            }
                    );
                    mapLayer._layers[f].bringToFront();
                }
            });
        },

        updateBaciniFeatureStyle: function () {

            this.theGeoJsonBacini.features.forEach(function(catchment){

                var f = _.findKey(mapLayer._layers, function (marker) {
                    return (marker.feature.properties.gid == catchment.properties.gid)
                });
                if(!_.isUndefined(f)){

                    if (catchment.properties.warning_palette ==3){
                        if(debug)console.log("stop");
                    }

                    mapLayer._layers[f].feature.properties = catchment.properties;
                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[catchment.properties.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity,
                            color : markerWarningOption.color,
                            weight: markerWarningOption.weight
                        }
                    )
                    mapLayer._layers[f].bringToFront();
                }
            });
        },

        updateWarningAreaFeatureStyle: function () {

            this.theGeoJsonWarningArea.features.forEach(function(WarningArea){

                var f = _.findKey(mapLayer._layers, function (waLayer) {
                    return (waLayer.feature.properties.gid == WarningArea.properties.gid) ;
                });

                if(!_.isUndefined(f)){

                    if (WarningArea.properties.warning_palette ==3){
                        if(debug)console.log("stop");
                    }

                    mapLayer._layers[f].feature.properties = WarningArea.properties;

                    mapLayer._layers[f].setStyle(
                        {
                            fillColor: geoServerPalette[WarningArea.properties.warning_palette],
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity,
                            color : markerWarningOption.color,
                            weight: markerWarningOption.weight
                        }
                    )
                    mapLayer._layers[f].bringToFront();
                }
            });
        },

        updateTheGeoJsonRegion: function () {
            if(debug)console.log("updateTheGeoJsonRegion");

            var regionGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.region;
            });

            this.theGeoJsonRegion.features.forEach(function(feature){

                var warnIndexRegional = _.max(regionGroup[feature.properties.gid], function (station) {

                    return  station.properties.warning_palette;

                });
                feature.properties.warning_palette = warnIndexRegional.properties.warning_palette;
            });
        },

        updateTheGeoJsonDistrict: function () {

            var districtGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.district;
            });

            this.theGeoJsonDistrict.features.forEach(function(feature){

                var warnIndexDistrict = _.max(districtGroup[feature.properties.gid], function (station) {
                    return station.properties.warning_palette;

                });
                feature.properties.warning_palette = warnIndexDistrict.properties.warning_palette;
            });

            var test = _.find(this.theGeoJsonDistrict.features, function (item) {
                return(item.properties.sigla == "SV")
            })
            if (test.properties.sigla =="SV"){
                if(debug)console.log(test);
            }


        },

        updateTheGeoJsonComune: function () {

            //2017-01-10 ai comuni che non hanno pluviometri è stato assegnato il pluviometro piu influente

            // //inizializzo variabile statione
            var aGeoJsonFeature = this.theGeoJsonStation.features;

            //raggruppo le centraline per comune
            var municGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.munic;
            });

            //per ogni feature comunale
            this.theGeoJsonComuni.features.forEach(function(feature){

                //se esiste un gruppo di sensori per quel comune
                if(municGroup[feature.properties.gid]){
                    var warnIndexMunic = _.max(municGroup[feature.properties.gid], function (station) {
                        return station.properties.warning_palette;
                    });
                    feature.properties.warning_palette = warnIndexMunic.properties.warning_palette;
                //ALTRIMENTI CERCO IL PLUVIOMETRO PIU INFLUENTE
                }else if((!municGroup[feature.properties.gid])&&feature.properties.station){
                    //errore in feature.properties.station c'è il sensorid non lo station id
                    var key  = _.findIndex(aGeoJsonFeature,function (station) {
                        return ( station.properties.sensorid == feature.properties.station)
                    })
                    if (key >-1) {
                        feature.properties.warning_palette = aGeoJsonFeature[key].properties.warning_palette;
                    }else{
                        feature.properties.warning_palette = -3;//blue color
                    }

                }else if(debug)console.log(feature);

            });


        },

        updateTheGeoJsonBacini: function () {

            var catchmentsGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.catchment;
            });
            this.theGeoJsonBacini.features.forEach(function(feature){
                if(catchmentsGroup[feature.properties.gid]){
                    var warnIndexCatchments = _.max(catchmentsGroup[feature.properties.gid], function (station) {
                        return station.properties.warning_palette;
                    });
                    feature.properties.warning_palette = warnIndexCatchments.properties.warning_palette;
                }else feature.properties.warning_palette = -2
            });
        },

        updateTheGeoJsonWarningArea: function () {

            var waGroup = _.groupBy(this.theGeoJsonStation.features, function(sensor){
                return sensor.properties.wa;
            });
            this.theGeoJsonWarningArea.features.forEach(function(feature){
                if(waGroup[feature.properties.gid]){
                    var warnIndexWA = _.max(waGroup[feature.properties.gid], function (station) {
                        return station.properties.warning_palette;
                    });
                    feature.properties.warning_palette = warnIndexWA.properties.warning_palette;
                    if (warnIndexWA.properties.warning_palette == 3){
                        if(debug)console.log("stop");
                    }
                }else feature.properties.warning_palette = -2
            });
        },
        updateTheGeoJsonTopoieti: function () {

            let theGeoJsonStation = this.getGeoJsonStation();

            this.theGeoJsonTopoieti.features.forEach(function(feature){

                let tpGroup = theGeoJsonStation.features.filter(sensor => sensor.properties.topoyeti_munic.indexOf(feature.properties.gid) > -1);
                if(tpGroup.length > 0) {
                    let warnIndexTI = _.max(tpGroup, function (station) {
                        return station.properties.warning_palette;
                    });
                    feature.properties.warning_palette = warnIndexTI.properties.warning_palette;
                }else feature.properties.warning_palette = -2;
            });


        },
        //
        resetAggregation:function () {
            this.theGeoJsonRegion=null;
            this.theGeoJsonDistrict =null;
            this.theGeoJsonComuni=null;
            this.theGeoJsonBacini= null;
            this.theGeoJsonWarningArea= null;
            this.theGeoJsonTopoieti= null;
        },

        validateDataByTime: function(properties){

            //se sono nel passato come ora di riferimento per validare i dati prendo quella di caricamento del layer
            var iServerTime =(menuService.isRealTime())? menuService.getUtcServerDateInSecond():menuService.getDateToUTCSecond();
            //var iServerTime = parseInt(menuService.getUtcServerDateInSecond());

            //if (properties.sensorid == -2147462361){
            //    if(debug)console.log(properties)
            //}

            var aValori = [];

            for (var prop in properties) {
                if (stringStartsWith(prop, stringValori)) {
                    var aValore = prop.split("_");

                    var oValore = {
                        timestamp: parseInt(aValore[1]),
                        period: parseInt(aValore[2]),
                        valore: parseFloat(properties[prop])
                    };
                    aValori.push(oValore);
                }
            }

            if (aValori.length == 0) return properties;

            var oMostRecentValue = _.max(aValori, function (valore) {
                return valore.timestamp;
            });
            //se il valore piu recente è piu vecchio del time to Undef non passo ne soglie ne valori ma solo i dati della stazione
            if ((iServerTime - oMostRecentValue.timestamp) > timeToUndef) {
                var obj = {};
                for (var prop in properties) {
                    if (!stringStartsWith(prop, stringValori) &&(!stringStartsWith(prop, stringSoglie))) {
                        obj[prop] = properties[prop];
                    }
                }
                return obj;
            } else return properties;
        },
        palette: function(oProperties) {

            //if (oProperties.sensorid == -1610577468){
            //    if(debug)console.log("p")
            //}
            var aValori = [];
            //costruisco array di oggetti per i valori
            for (var prop in oProperties) {
                if (stringStartsWith(prop, stringValori)) {
                    var aValore = prop.split("_");

                    var oValore = {
                        timestamp: parseInt(aValore[1]),
                        period: parseInt(aValore[2]),
                        valore: parseFloat(oProperties[prop])
                    };
                    if (oProperties[prop] == -9999) {
                        return -2;
                    }

                    aValori.push(oValore)
                }
            }



            //prendo il valore piu recente
            var oMostRecentValue = _.max(aValori, function (valore) {
                return valore.timestamp;
            });
            var aTreshold = [];
            //cerco le soglie e construisco array per valutarle
            var sHighTreshold = stringSoglie;
            for (var prop in oProperties){
                if (stringStartsWith(prop, sHighTreshold)) {
                    var aSoglia = prop.split("_");
                    var oSoglia = {
                        id: aSoglia[1],
                        idSoglia: aSoglia[1],
                        warn_index: parseInt(aSoglia[2]),
                        valore: oProperties[prop]
                    };
                    aTreshold.push(oSoglia)
                }
            }
            //se ci sono soglie cerco la soglia massima
            var oHightestThreshold = _.max(aTreshold, function (valore) {
                return valore.warn_index;
            });
            //se array soglie esiste ritorno la soglia maggiore
            if(aTreshold.length > 0){
                return oHightestThreshold.warn_index;
            }else if(aValori.length > 0){//se non ci sono soglie valuto i valori
                //costruisco array con valori uguali a 0
                var values= _.filter(aValori, function (value) {
                    return value.valore == 0
                });
                return ((values.length == aValori.length)? -1:0);//se i valori a 0 sono tanti come tutti i valori allora il marker è bianco altrimenti è verde

            } else return -2;


             //se non ci sono valori validi torno grigio
        }
    };
    /**
     * function that manage aggregation type and call the righ one
     * @param objprops object passed by properties layer controller
     * @param data object passed by properties layer controller
     * @param onFinish function reset layer manager passed in layerlist controller
     */
    function update(objprops, data){


        if (data){
            //aggregationType = data.type;
            aggregationType = data.aggregation.type;
            //HighThresholdSet = data.threshold.high.id;
            //LowThresholdSet = data.threshold.low.id;
        }


        if(objprops)props = objprops;

        switch(aggregationType) {
            case "REGIONE":
                if(debug)console.log("regione");
                loadRegioniJson(loadRegioniLayer);
                break;
            case "PROVINCE":
                if(debug)console.log("province");
                loadProvinceJson( loadProvinceLayer);
                break;
            case "COMUNI":
                loadComuniJson(loadComuniLayer);
                if(debug)console.log("comuni");
                break;
            case "STAZIONI":
                loadStazioniLayer();
                if(debug)console.log("stazioni");
                break;
            case "BACINI":
                loadCatchmentJson(loadBaciniLayer);
                if(debug)console.log("bacini");
                break;
            case "AREEALLERTAMENTO":
                loadWarningAreaJson(loadWarningAreaLayer);
                if(debug)console.log("Aree Allertamento");
                break;
            case "TOPOIETI":
                loadTopoietiJson(loadTopoietiLayer);
                if(debug)console.log("Aree Topoieti");
                break;
            default:loadStazioniLayer();

        }

    }

    /**
     * callback that reload station layer whan aggregation is changed
     * @param onFinish function reset layer manager passed in layerlist controller
     * @returns {*}
     */

    function loadStazioniLayer(onFinish){

        mapService.removeLayer(mapLayer);

        var _this = this;

        mapLayer = mapService.addGeoJsonLayer(oPluvioData.getGeoJsonStation(), layer['descr'], {

            pointToLayer: function(feature, latlng) {

                var geojsonMarkerOptions = {
                    radius: markerWarningOption.radius,
                    fillColor: geoServerPalette[feature.properties.warning_palette],
                    color: markerWarningOption.color,
                    weight: markerWarningOption.weight,
                    opacity: markerWarningOption.opacity,
                    fillOpacity: markerWarningOption.fillOpacity
                };

                return L.circleMarker(latlng, geojsonMarkerOptions);

            }

        }, stationClickListener,stationMouseOverListener, stationMouseOutListener);

        //se era un layer nascosto lo rinascondo
        if (!visible) _this.setVisible(false);

        oPluvioData.putUndefinedBack();

        if(onFinish) onFinish()

    }

    /**
     * callback called when the Regioni aggregation is poed
     * @param url object
     * @param loadLayerCallback function LoadProvinceLayer
     * @param onFinish function risetto layer manager
     * @returns {*}
     */

    function loadRegioniJson(loadLayerCallback){

        if(oPluvioData.theGeoJsonRegion){
            if(loadLayerCallback) loadLayerCallback()

        }else{
            var oRegioniLocalStorage = menuService.oServiceStorage.m_oWarningRegionFeatureLoader(menuService.oLocalStorage, function (data) {
                oPluvioData.setTheGeoJsonRegion(data);
                //oPluvioData.updateTheGeoJsonRegion()
                if(loadLayerCallback) loadLayerCallback()
            })
        }
    }

    /**
     * callback called when the province aggregation is loaded
     * @param url object
     * @param loadLayerCallback function LoadProvinceLayer
     * @paramonFinish function risetto layer manager
     * @returns {*}
     */

    function loadProvinceJson( loadLayerCallback) {


        if(oPluvioData.theGeoJsonDistrict){

            if(loadLayerCallback)loadLayerCallback();

        }else{
            menuService.oServiceStorage.m_oWarningProvinceFeatureLoader(menuService.oLocalStorage, function (data) {
                oPluvioData.setTheGeoJsonDistrict(data);
                //oPluvioData.updateTheGeoJsonDistrict()

                if(loadLayerCallback) loadLayerCallback()
            })
        }

    }

    /**
     * callback called when the comuni aggregation is loaded
     * @param url object
     * @param loadLayerCallback function LoadComuniLayer
     * @param onFinish function risetto layer manager
     * @param returns {*}
     */

    function loadComuniJson( loadLayerCallback) {
        if(oPluvioData.theGeoJsonComuni){

            if(loadLayerCallback)loadLayerCallback();

        }else{
            menuService.oServiceStorage.m_oWarningComuniFeatureLoader(menuService.oLocalStorage, function(data){

                var municGroup = _.groupBy(oPluvioData.theGeoJsonStation.features, function(sensor){
                    return sensor.properties.munic;
                });

                var aFeatures = [];

                //fitro per i sensori che hanno assegnato un comune cosi da snellire la mappa
                data.features.forEach(function (feature) {
                    if (municGroup[feature.properties.gid]) aFeatures.push(feature)
                    // includo anche i comuni che non hanno pluviomentri, ma che hanno una centralina assegnata al campo station
                    if (feature.properties.station) {
                        aFeatures.push(feature)
                    }
                    // if (feature.properties.nome_com == 'Suisio') {
                    //     if(debug)console.log(feature);
                    //     aFeatureIsoiete.push(feature)
                    // }
                });

                data.features = aFeatures;
                //setto i comuni
                oPluvioData.setTheGeoJsonComuni(data);
                //carico il layer
                if(loadLayerCallback) loadLayerCallback()
            })
        }
    }


    /**
     * callback called when geojson of bacini is loades
     * @param onFinish
     */
    function loadCatchmentJson(loadLayerCallback){


        if(oPluvioData.theGeoJsonBacini){
            //oPluvioData.updateTheGeoJsonBacini()
            if(loadLayerCallback)loadLayerCallback();
        }else{
            menuService.oServiceStorage.m_oWarningBaciniFeatureLoader(menuService.oLocalStorage, function (data) {
                oPluvioData.setTheGeoJsonBacini(data);

                if(loadLayerCallback) loadLayerCallback()
            })
        }
    }


    /**
     * callback called when geojson of bacini is loades
     * @param onFinish
     */
    function loadWarningAreaJson(loadLayerCallback){

        if(oPluvioData.theGeoJsonWarningArea){
            if(loadLayerCallback)loadLayerCallback();
        }else{
            menuService.oServiceStorage.m_oWarningWAFeatureLoader(menuService.oLocalStorage, function (data) {
                oPluvioData.setTheGeoJsonWarningArea(data);
                //oPluvioData.updateTheGeoJsonWarningArea()

                if(loadLayerCallback) loadLayerCallback()
            })
        }
    }

    /**
     * callback called when geojson of bacini is loades
     * @param onFinish
     */
    function loadTopoietiJson(loadLayerCallback){

        if(oPluvioData.theGeoJsonTopoieti){
            if(loadLayerCallback)loadLayerCallback();
        }else{
            menuService.oServiceStorage.m_oWarningTopoietiFeatureLoader(menuService.oLocalStorage, function (data) {
                oPluvioData.setTheGeoJsonTopoieti(data);

                if(loadLayerCallback) loadLayerCallback()
            })
        }
    }


    /**
     * callback called when the geojson of the region is loaded
     * @returns {*}
     */

    function loadRegioniLayer(onFinish){


        mapService.removeLayer(mapLayer);

        mapLayer = mapService.addGeoJsonLayer(oPluvioData.getTheGeoJsonRegion(), layer['descr'],{

            onEachFeature: function(feature, layer) {

                //if (feature.properties && feature.properties.NOME_REG) {
                //    layer.bindPopup(feature.properties.NOME_REG);
                //}

            }

        }, stationClickListener, stationMouseOverListener, stationMouseOutListener);
        mapLayer.setStyle(function(feature) {
           // if(debug)console.log(feature);
            var colorIndex = feature.properties.warning_palette;

            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight
            }
        });
        //test 09/04
        oPluvioData.updateFeatureStyle();

        if(onFinish)onFinish();

    }

    /**
     * callback called when the geojson of the province is loaded
     * @param onFinish callback re set layer manager from layer list controller
     * @returns {*}
     */
    function loadProvinceLayer(onFinish){

        mapService.removeLayer(mapLayer);

        mapLayer = mapService.addGeoJsonLayer(oPluvioData.getTheGeoJsonDistrict(), layer['descr'], null, stationClickListener, stationMouseOverListener, stationMouseOutListener);

        mapLayer.setStyle(function(feature) {

            var colorIndex = feature.properties.warning_palette;
            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight
            }
        });
        //test 09/04
        oPluvioData.updateFeatureStyle();

        if(onFinish)onFinish()
    }

    /**
     * callback called when the geojson of the municipality is loaded
     * @param onFinish
     */
    function loadComuniLayer(onFinish){

        mapService.removeLayer(mapLayer);

        //non funziona style da fare nel frattempo uso

        mapLayer = mapService.addGeoJsonLayer(oPluvioData.getTheGeoJsonComuni(), layer['descr'], null, stationClickListener, stationMouseOverListener, stationMouseOutListener);
        //mapLayer.addData(geoJsonRegioni)

        mapLayer.setStyle(function(feature) {
            //if(debug)console.log(feature);
            var colorIndex = feature.properties.warning_palette;


            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight

            }
        });

        //test 09/04
        oPluvioData.updateFeatureStyle();

        if(onFinish)onFinish()
    }

    /**
     * callback called when the geojson of the bacini is loaded
     * @param onFinish
     */
    function loadBaciniLayer(onFinish){

        mapService.removeLayer(mapLayer);

        //non funziona style da fare nel frattempo uso

        mapLayer = mapService.addGeoJsonLayer(oPluvioData.getTheGeoJsonBacini(), layer['descr'], null, stationClickListener, stationMouseOverListener, stationMouseOutListener);
        //mapLayer.addData(geoJsonRegioni)

        mapLayer.setStyle(function(feature) {
            //if(debug)console.log(feature);
            var colorIndex = feature.properties.warning_palette;


            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight

            }
        });

        //test 09/04
        oPluvioData.updateFeatureStyle();

        if(onFinish)onFinish()
    }

    /**
     * callback called when the geojson of the aree allertamento is loaded
     * @param onFinish
     */
    function loadWarningAreaLayer(onFinish){

        mapService.removeLayer(mapLayer);

        //non funziona style da fare nel frattempo uso

        mapLayer = mapService.addGeoJsonLayer(oPluvioData.getTheGeoJsonAreeAllertamento(), layer['descr'], null, stationClickListener, stationMouseOverListener, stationMouseOutListener);
        //mapLayer.addData(geoJsonRegioni)

        mapLayer.setStyle(function(feature) {
            //if(debug)console.log(feature);
            var colorIndex = feature.properties.warning_palette;


            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight

            }
        });

        //test 09/04
        oPluvioData.updateFeatureStyle();

        if(onFinish)onFinish()
    }

    /**
     * callback called when the geojson of the topoeti is loaded
     * @param onFinish
     */
    function loadTopoietiLayer(onFinish){

        mapService.removeLayer(mapLayer);

        //non funziona style da fare nel frattempo uso

        mapLayer = mapService.addGeoJsonLayer(oPluvioData.getTheGeoJsonTopoieti(), layer['descr'], null, stationClickListener, stationMouseOverListener, stationMouseOutListener);
        //mapLayer.addData(geoJsonRegioni)

        mapLayer.setStyle(function(feature) {
            //if(debug)console.log(feature);
            var colorIndex = feature.properties.warning_palette;


            return {
                fillColor: geoServerPalette[colorIndex],
                color : markerWarningOption.color,
                opacity : markerWarningOption.opacity,
                fillOpacity: markerWarningOption.fillOpacity,
                weight: markerWarningOption.weight

            }
        });

        //test 09/04
        oPluvioData.updateFeatureStyle();

        if(onFinish)onFinish()
    }


    /**
     *Check last station updated
     * @param data
     */
    function getLastUpdateDate(data){

        var aStation = []

        if(_.isArray(data)){
            data.forEach(function (station) {
                for (var prop in station) {
                    if (stringStartsWith(prop, stringValori)) {
                        var aValore = prop.split("_");

                        var oValore = {
                            timestamp: parseInt(aValore[1]),
                            station: station.stationname
                            // period: parseInt(aValore[2]),
                            // valore: parseFloat(oProperties[prop])
                        };

                        aStation.push(oValore);
                    }
                }
            })
        }else{
            for (var prop in data) {
                if (stringStartsWith(prop, stringValori)) {
                    var aValore = prop.split("_");

                    var oValore = {
                        timestamp: parseInt(aValore[1])
                        // period: parseInt(aValore[2]),
                        // valore: parseFloat(oProperties[prop])
                    };

                    aStation.push(oValore);
                }
            }
        }

        return _.max(aStation, function (value) {
            return value.timestamp
        })

    }

    // {
    //     "catchment": "45",
    //     "dbid": "2",
    //     "district": "9",
    //     "munic": "1534",
    //     "region": "7",
    //     "sensorid": "-2097483367",
    //     "sensormu": "mm",
    //     "stationid": "200043176",
    //     "stationname": "Albenga - Molino Branca",
    //     "v_1495466100_3600": "1",
    //     "e_1495466100_3600": "3"
    // }


    /**
     * Fuction for async update layer
     * @param data
     */
    function updateStation(data){
        //looking for last update date
        lastUpdate = getLastUpdateDate(data);

        if(debug)console.log("sensor update iteration");
        var pluvioData = [];
        //if(debug)console.log(data);


        if(_.isArray(data)){
            pluvioData = _.filter(data, function (station) {
                if (oPluvioData.aAnagrafica[station.sensorid]) return true;
            })

            //if(debug)console.log(data);

        }else{
            if (oPluvioData.aAnagrafica[data.sensorid]) pluvioData.push(data);
        }



        if(debug)console.log("warning pluvio: " + pluvioData.length + " sensor to Update");
        //if(debug)console.log( termoData)

        if (pluvioData.length > 0){

            //if(debug)console.log(termoData);
            if(debug)console.log("update the geoJson");
            oPluvioData.updateTheGeoJsonStation(pluvioData);

        }

    }




    /**
     * mouse listener
     * @param feature object
     * @return *
     * */
    var lastStationMouseOver = null

    function stationMouseOverListener(s){

        switch(aggregationType) {
            case "REGIONE":
                if(debug)console.log("regione");

                break;
            case "PROVINCE":
                if(debug)console.log("province");

                break;
            case "COMUNI":
                if(debug)console.log(s.target.feature.properties);
                if(debug)console.log("comuni");
                break;
            case "BACINI":

                if(debug)console.log("bacini");
                break;
            case "AREEALLERTAMENTO":

                if(debug)console.log("Aree Allertamento");
                break;
            case "STAZIONI":
                if(debug)console.log(s.target.feature.properties);
                try{
                    if(warningInfo){
                        if(debug)console.log("SensorId: "+s.target.feature.properties.sensorid);
                        warningInfo.mouseOver('pluvio',mapLayer._leaflet_id, s.target.feature.properties, geoServerPalette)
                    }
                }catch(err){
                    alert("errot thresholdInfo.mouseOver")
                }
                if(debug)console.log("stazioni");
                break;
            default:
                if(debug)console.log(s.target.feature.properties);
                try{
                    if(warningInfo){
                        if(debug)console.log("SensorId: "+s.target.feature.properties.sensorid);
                        warningInfo.mouseOver('pluvio',mapLayer._leaflet_id, s.target.feature.properties, geoServerPalette)
                    }
                }catch(err){
                    alert("errot thresholdInfo.mouseOver")
                }

        }

    }

    function stationMouseOutListener(s){

        switch(aggregationType) {
            case "REGIONE":
                if(debug)console.log("regione");

                break;
            case "PROVINCE":
                if(debug)console.log("province");

                break;
            case "COMUNI":

                if(debug)console.log("comuni");
                break;
            case "BACINI":

                if(debug)console.log("bacini");
                break;
            case "AREEALLERTAMENTO":

                if(debug)console.log("Aree Allertamento");
                break;
            case "STAZIONI":
                try{
                    if(warningInfo){
                        warningInfo.mouseOut('pluvio',mapLayer._leaflet_id)
                    }
                }catch(err){
                    alert("errot thresholdInfo.mouseOver")
                }
                if(debug)console.log("stazioni");
                break;
            default:
                try{
                    if(warningInfo){
                        warningInfo.mouseOut('pluvio',mapLayer._leaflet_id)
                    }
                }catch(err){
                    alert("errot thresholdInfo.mouseOver")
                }
        }
    }





    /**
     * function load chart
     * @param s
     */
    function stationClickListener(s) {

        switch(aggregationType) {
            case "REGIONE":
                if(debug)console.log("regione");
                clickListenerAggregazioni(s);
                break;
            case "PROVINCE":
                if(debug)console.log("province");
                clickListenerAggregazioni(s);
                break;
            case "COMUNI":
                clickListenerAggregazioni(s);
                if(debug)console.log("comuni");
                break;
            case "BACINI":
                clickListenerAggregazioni(s);
                if(debug)console.log("bacini");
                break;
            case "AREEALLERTAMENTO":
                clickListenerAggregazioni(s);
                if(debug)console.log("Aree Allertamento");
                break;
            case "STAZIONI":
                clickListenerStazioni(s);
                if(debug)console.log("stazioni");
                break;
            case "TOPOIETI":
                clickListenerAggregazioni(s);
                if(debug)console.log("stazioni");
                break;
            default:clickListenerStazioni(s);

        }


    }//end station click listener

    /**
     * Manage click on station marker
     * @param s
     */
    function clickListenerStazioni(s){

        if(debug)console.log("SensorId: "+s.target.feature.properties.sensorid);
        //if(debug)console.log(s.target.feature.properties);


        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/sensor_chart_form.html',
            controller: 'sensorChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sensorData: function () {

                    var featureData = angular.copy(s.target.feature.properties);

                    return {
                        sensorId : featureData.sensorid,
                        dbId : featureData.dbid,
                        properties: featureData,
                        from:"warning_pluvio",
                        sensorClass : 2
                    };

                }

            }
        });
    }



    /**
     * Manage click on station marker
     * @param s
     */
    function clickListenerAggregazioni(s){
        var aModalData = [];

        if(debug)console.log(s);
        switch(aggregationType) {
            case "REGIONE":
                if(debug)console.log("regione");
                var station = oPluvioData.getGeoJsonStation();
                var aModalData = _.filter(station.features, function(sensor){
                    return (sensor.properties.region == s.target.feature.properties.gid)
                });
                break;
            case "PROVINCE":
                if(debug)console.log("province");
                var station = oPluvioData.getGeoJsonStation();
                var aModalData = _.filter(station.features, function(sensor){
                    return (sensor.properties.district == s.target.feature.properties.gid)
                });
                break;
            case "COMUNI":
                if(debug)console.log("comuni");
                var station = oPluvioData.getGeoJsonStation();
                var aModalData = _.filter(station.features, function(sensor){
                    return (sensor.properties.munic == s.target.feature.properties.gid)
                });
                //se non ci sono pluviometri in quel comune prendo il pluviomentro piu influente
                if (aModalData.length == 0 && s.target.feature.properties.station){
                    var index = _.findIndex(station.features,function (station) {
                        if (station.properties.sensorid == s.target.feature.properties.station){
                            return true;
                        }
                    } )
                    aModalData.push(station.features[index]);
                }
                break;
            case "TOPOIETI":
                if(debug)console.log("topoieti");
                let stations = oPluvioData.getGeoJsonStation();
                let gidComune =s.target.feature.properties.gid

                // var aModalData = _.filter(station.features, function(sensor){
                //     return (sensor.properties.munic == s.target.feature.properties.gid)
                // });

                var aModalData = stations.features.filter(sensor => sensor.properties.topoyeti_munic.indexOf(gidComune) > -1);
                //se non ci sono pluviometri in quel comune prendo il pluviomentro piu influente

                break;
            case "BACINI":
                if(debug)console.log("bacini");
                var station = oPluvioData.getGeoJsonStation();
                var aModalData = _.filter(station.features, function(sensor){
                    return (sensor.properties.catchment == s.target.feature.properties.gid)
                });
                break;
            case "AREEALLERTAMENTO":
                if(debug)console.log("areeallertamento");
                var station = oPluvioData.getGeoJsonStation();
                var aModalData = _.filter(station.features, function(sensor){
                    return (sensor.properties.wa == s.target.feature.properties.gid)
                });
                break;
            default:break;

        }

        thresholdService.getNationalThresholdArrayBySensorClass(2,function (data) {

            var modalInstance = $uibModal.open({

                templateUrl: 'apps/dewetra2/views/warning_aggregation_click_detail.html',
                controller: 'warningAggregationClickDetailController',
                size: 'lg',
                keyboard: false,
                resolve: {

                    featureData: function () {

                        var featureData = s.target.feature.properties;

                        return {
                            featureData : featureData,
                            aModalData : aModalData,
                            aggregationType: aggregationType,
                            palette: geoServerPalette,
                            type: "WARNING_PLUVIO",
                            threshold:data
                        };


                    }

                }
            });

        });



    }



    return {

        layerObj: function () {
            return layer
        },

        mapLayer: function () {
            return mapLayer
        },

        load: function(onFinish) {

            var _this = this;

            if(debug)console.log("Warning Pluvio");
            if (!menuService.isRealTime() && wsAcquisition != null) this.removeListener();

            sentinelService.getNationalPluvio(function(data) {

                if (mapLayer) mapService.removeLayer(mapLayer);

                //routine di prova su stazione mulino branca albenga
                data.features.forEach(function (station) {

                    if(station.properties.stationname.indexOf("minore") > -1){
                        if(debug)console.log(station);
                    }

                    if(station.properties.sensorid == -2097483367){
                        if(debug)console.log(station);
                        var station2 = angular.copy(station);
                        // station2.properties.warning_palette = 3;
                        // station.properties.warning_palette = 1;
                        // oPluvioData.audio(station.properties, station2.properties);
                        if(debug)console.log(station);
                    }
                })



                oPluvioData.setGeoJsonStation(data);

                mapLayer = mapService.addGeoJsonLayer(oPluvioData.getGeoJsonStation(), layer['descr'], {

                    pointToLayer: function(feature, latlng) {
                        if(feature.properties.stationname.indexOf("arquata")> -1){
                            if(debug)console.log(feature)
                        }
                        if(feature.properties.sensorid == 210326352){
                            if(debug)console.log(feature)
                        }
                        //var sFillColor = palette(feature.properties)
                        var sFillColor = feature.properties.warning_palette;
                        var geojsonMarkerOptions = {
                            radius: markerWarningOption.radius,
                            fillColor: geoServerPalette[sFillColor],
                            color: markerWarningOption.color,
                            weight: markerWarningOption.weight,
                            opacity: markerWarningOption.opacity,
                            fillOpacity: markerWarningOption.fillOpacity
                        };

                        return L.circleMarker(latlng, geojsonMarkerOptions);

                    }

                }, stationClickListener,stationMouseOverListener, stationMouseOutListener);

                mapLayer.bringToFront();

                //se è aggregata, riaggrego
                if (aggregationType != "STAZIONI") update();

                //se era un layer nascosto lo rinascondo
                if (!visible) _this.setVisible(false);

                oPluvioData.putUndefinedBack();



                if (onFinish) onFinish()

            }, function(data) {

                alert('Error loading layer: ' + data.error_message);

            });//se sono nel passato passo true altrimenti false

            //connetto a messaggistica il layer se non è nel passato
            if (menuService.isRealTime()) updateListener()


        },




        updateListener: updateListener,

        removeListener: function () {
            acEvent.unsubscribe(wsAcquisition);
            wsAcquisition = null;
            if(debug)console.log("unsubscribe")
        },

        remove: function (layer, onFinish) {
            this.removeListener();
            oPluvioData.delCheckOldData();
            mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        name: function() {
            return layer.name
        },

        descr: function () {
            return layer.descr
        },


        onDateChange : function (callBack) {
            //ricarico il layer se è nel passato fa tutto il load

            this.load(callBack)
        },

        setVisible: function (b,callBack) {


            visible = b;
            if (!b) mapLayer.clearLayers();
            else this.update(null,null, function () {
                if(callBack)callBack()
            } );

        },

        isVisible:function(){
            return visible;
        },

        typeDescr: function () {
            return "PLUVIOMETRIC_ALERT_THRESHOLD"
        },

        legendType: function () {
            return "WARNING"
        },

        draggable: function () {
            return false;
        },

        setWarningInfo: function (wi) {
            warningInfo = wi
        },


        update: function (props, data, onFinish) {
            if (data){
                aggregationType = data.type;
            }

            switch(aggregationType) {
                case "REGIONE":
                    if(debug)console.log("regione");
                    loadRegioniJson(loadRegioniLayer);
                    break;
                case "PROVINCE":
                    if(debug)console.log("province");
                    loadProvinceJson( loadProvinceLayer);
                    break;
                case "COMUNI":
                    loadComuniJson(loadComuniLayer);
                    if(debug)console.log("comuni");
                    break;
                case "BACINI":
                    loadCatchmentJson(loadBaciniLayer);
                    if(debug)console.log("bacini");
                    break;
                case "AREEALLERTAMENTO":
                    loadWarningAreaJson(loadWarningAreaLayer);
                    if(debug)console.log("aree allertamento");
                    break;
                case "STAZIONI":
                    loadStazioniLayer();
                    if(debug)console.log("stazioni");
                    break;
                default:loadStazioniLayer();

            }
            if(onFinish) onFinish();
        },

        props: function (){
            var aggregation = [
                {
                    type : "REGIONE",
                    'selected': false,
                    description : "AGGREGAZIONE_REGIONALE",
                    dataId : "dew:Regions_ISTAT2010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms",
                    completeUrl:"http://geoserver.cimafoundation.org/geoserver/dew/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=dew:Regioni_ISTAT2008&maxFeatures=50&outputFormat=json"
                },
                {
                    type : "PROVINCE",
                    'selected': false,
                    description : "AGGREGAZIONE_PROVINCIALE",
                    dataId : "dew:Districts_ISTAT2010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms"
                },
                {
                    type : "COMUNI",
                    'selected': false,
                    description : "AGGREGAZIONE_COMUNALE",
                    dataId : "dew:Municipalities_ISTAT12010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms"
                },
                {
                    type : "BACINI",
                    'selected': false,
                    description : "BACINI",
                    dataId : "dew:Municipalities_ISTAT12010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms"
                },
                {
                    type : "AREEALLERTAMENTO",
                    'selected': false,
                    description : "WARNING_AREA",
                    dataId : "dew:Municipalities_ISTAT12010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms"
                },
                {
                    type : "STAZIONI",
                    'selected': true,
                    description : "AGGREGAZIONE_STAZiONI",
                    dataId : "dew:Municipalities_ISTAT12010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms"
                },
                {
                    type : "TOPOIETI",
                    'selected': false,
                    description : "AGGREGAZIONE_COMUNALE_TOPOIETI",
                    dataId : "dew:Municipalities_ISTAT12010",
                    url: "http://geoserver.cimafoundation.org/geoserver/wms"
                }
            ];

            var soglie = {
                low: {
                    id: 1,
                    type: "Low Threshold",
                    description: "Low Threshold",
                    list: [
                        {
                            'id': 1,
                            'selected': true,
                            'description': "+/-5 Deg. C"
                        },
                        {
                            'id': 2,
                            'selected': false,
                            'description': "+/-8 Deg. C"
                        },
                        {
                            'id': 3,
                            'selected': false,
                            'description': "+/-10 Deg. C"
                        }
                    ]
                },
                high: {
                    id: 2,
                    type: "High Threshold",
                    description: "High Threshold",
                    list: [
                        {
                            'id': 1,
                            'selected': true,
                            'description': "+/-10 Deg. C"
                        },
                        {
                            'id': 2,
                            'selected': false,
                            'description': "+/-12 Deg. C"
                        },
                        {
                            'id': 3,
                            'selected': false,
                            'description': "+/-15 Deg. C"
                        }
                    ]
                }
            };
            var props ={
                aggregation : aggregation
                //threshold : soglie
            };
            if (aggregationType){
                props.aggregation.forEach(function (a) {
                    if (aggregationType == a.type){
                        a.selected = true
                    } else a.selected = false
                })
            }


            return props
        },

        soglie : function(){
            var setSoglie=[
                {
                    type: "",
                    description: "",
                    soglie:[
                        {
                            descr:"+/-5 Deg. C"
                        },
                        {
                            descr:"+/-8 Deg. C"
                        },
                        {
                            descr:""
                        }

                    ]

                }
            ]
        },

        layerTooltip: function(){





            var tooltipObj=[
                {
                    label : "LAYER_NAME",
                    value : this.name()
                },
                {
                    label : "LAYER_DESCRIPTION",
                    value : this.descr()
                },
                {
                    label : "ASYNC_LAYER",
                    value : "ASYNC_LAYER"
                }


            ];

            if(lastUpdate != null && menuService.isRealTime()){
                tooltipObj.push(
                    {
                        label:"LAST_STATION_UPDATED",
                        value:lastUpdate.station
                    }
                    ,{
                        label:"LAST_UPDATE",
                        value:moment.utc(lastUpdate.timestamp).format('LLLL')
                    }
                 )
            }

            return tooltipObj;
        },

        layerProps: layerProps,

        haveAudio: function(){
            return true
        },
        geoServerPalette: geoServerPalette,

        legend:function () {

            // return{
            //     type:layerObj.type.code.toUpperCase(),
            //     palette:geoServerPalette
            // }

            var legend = {

                type:"ADVANCED",
                legend:[{
                    type:"CUSTOM",
                    title: "WARNING_PLUVIO_PALETTE",
                    palette:[{
                        label:"WARNINGS_PLUVIO_-2",
                        color:"#8A8787",
                        // sign:"",
                        // value:"",
                        // mu:"",
                        // dec:0
                    },{
                        label:"WARNINGS_PLUVIO_-1",
                        color:"#FFFFFF",
                        // sign:"<",
                        // value:500000,
                        // mu:"€",
                        // dec:0
                    },{
                        label:"WARNINGS_PLUVIO_0",
                        color:"#00FF00",
                        // sign:"<",
                        // value:1000000,
                        // mu:"€",
                        // dec:0
                    },{
                        label:"WARNINGS_PLUVIO_1",
                        color:"#FFFF00",
                        // sign:"<",
                        // value:1500000,
                        // mu:"€",
                        // dec:0
                    },{
                        label:"WARNINGS_PLUVIO_2",
                        color:"#FA8B3C",
                        // sign:"<",
                        // value:2000000,
                        // mu:"€",
                        // dec:0
                    },{
                        label:"WARNINGS_PLUVIO_3",
                        color:"#FF0000",
                        // sign:"<",
                        // value:2000000,
                        // mu:"€",
                        // dec:0
                    }]
                }]

            };

            return legend

        },

        setOpacity : function(value){

            if (value){
                markerWarningOption.opacity = value;
                markerWarningOption.fillOpacity = value;
                oPluvioData.updateFeatureStyle()
            }
        },

        getOpacity : function(){
            return markerWarningOption.opacity
        },

        showProps: function (onFinish) {
            var layerPropModal = $uibModal.open({
                templateUrl: 'apps/dewetra2/views/layer_properties_warning_pluvio.html',
                //templateUrl: 'apps/dewetra2/views/layer_properties.html',
                controller: "warningPluvioPropertiesController",
                //controller: "layerPropertiesController",
                size: "lg",
                resolve: {
                    params: function() {
                        return {
                            layer: mapLayer
                        }
                    }
                }
            });

            layerPropModal.result.then(function (obj) {
                update(obj.props, obj.data, onFinish)

            }, function () {
                if(debug)console.log("CANCEL")
            });
        },



        isWidget: function(bValue){

        },

        export:function () {
            apiService.exportCsv(oPluvioData.exportCvs());
        },

        thirdLine:function(){
            return ""
        },

        getVariable:function () {
            return ""
        },

        getAggregation:function () {
            return ""
        }

    }

}


