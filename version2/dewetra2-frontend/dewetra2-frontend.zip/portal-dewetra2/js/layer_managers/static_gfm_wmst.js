
function layerManager_static_wmst_gfm(layerObj) {


    const oManager = layerManager_default(layerObj);

    const oServices = oManager.oServices();

    const layer = layerObj;

    let mapLayer = null;

    const downloadUrl = null

    oManager.setLayerObj(layerObj);


    // oManager.loadWithProperties = function (onFinish, layerObj, props, item, dateFrom, dateTo, opacity) {
    //     oManager.setMapLayer(oServices.mapService.addWmsLayer(oManager.layerObj().server.url, oManager.layerObj().dataid));
    //     if (opacity) oManager.mapLayer().setOpacity(opacity);
    //     if (onFinish) onFinish();
    //
    // }
    // layerObj:function(){},
    oManager.load = function (onFinish) {

        if(oManager.mapLayer())oServices.mapService.removeLayer(oManager.mapLayer());

        oManager.setMapLayer(oServices.mapService.addWmsLayerWithParameters(oManager.layerObj().server.url, {
            layers: oManager.layerObj().dataid,
            format: 'image/png',
            transparent: true,
            time: moment(oManager.oServices().menuService.getDateTo()).format('YYYY-MM-DD')+'T00:00:00.000Z',
            // time: moment(oManager.oServices().menuService.getDateTo()).toISOString(),
            maxZoom: 24,
        }));

        if (onFinish) onFinish()
    }

    // getDownloadUrl: function () {
    //     return downloadUrl
    // },
    oManager.draggable = () => true;

    oManager.type = () => 'STATIC_LAYER_WMST_GFM';

    oManager.typeDescr = () => 'STATIC_LAYER_WMST_GFM';

    oManager.legend = () => {

        try {
            if (oManager && oManager.hasOwnProperty('layerObj') && oManager.layerObj().hasOwnProperty("customprops") && oManager.customprops() != null && oManager.customprops().hasOwnProperty("customLegend")) {


                let legend = {
                    type: "ADVANCED",
                    legend: [{
                        type: "CUSTOM",
                        title: oManager.name(),
                        palette: [],
                        descr: ""
                    }]
                };

                legend.legend[0].palette = oManager.customprops().customLegend['default'].palette;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].img = oManager.customprops().customLegend['default'].img;//default o la variabile che definisci mi permette di gestire multi legenda
                legend.legend[0].descr = oManager.customprops().customLegend['default'].descr;//default o la variabile che definisci mi permette di gestire multi legenda

                return legend


            } else {
                return {
                    dynPalette: {},
                    type: oManager.layerObj().type.code.toUpperCase(),
                    url: oManager.mapLayer()._url,
                    layers: oManager.mapLayer().wmsParams.layers,
                }
            }
        }catch (e) {
            console.log(e);
        }


    }

    oManager.canMovie = () => false;

    oManager.refreshable = () => false;


    oManager.layerTooltip = function () {


        const tooltipObj = [
            {
                label: "LAYER_NAME",
            },
            {
                label: "LAYER_DESCRIPTION",
                value: oManager.descr()
            },
            {
                label: "LAYER_TYPE",
                value: oManager.type()
            }

        ];
        return tooltipObj;
    },
        oManager.remove = (layer, onFinish) => {
            oServices.mapService.removeLayer(layer);
            if (onFinish) onFinish()
        },

        oManager.dateLine = () => {
            return moment.utc(oManager.oServices().menuService.getDateTo()).format('YYYY-MM-DD');
        },

        oManager.delayLine = () => {
            return "";
        },

        oManager.customprops = () => {

            let response = {};

            if (oManager.layerObj().hasOwnProperty("customprops")) {
                try {
                    response = JSON.parse(oManager.layerObj().customprops)
                } catch (e) {
                    //console.log(e);
                    response = {};
                }
                return response;
            }
        },

        oManager.parseInfo = (data) => {

            var ret = {
                layerName: oManager.name(),
                properties: []
            };

            if (data.features && data.features.length > 0) {
                data.features.forEach(function (f) {
                    if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                        ret.properties.push({name: 'value', 'value': f.properties.GRAY_INDEX.toFixed(2)})
                    } else {
                        for (p in f.properties) {
                            ret.properties.push({name: p, 'value': f.properties[p]})
                        }
                    }
                })
            }

            ret.properties.forEach(function (item) {
                if (item.name == 'link') {
                    item.html = true;
                } else item.html = false;
            })

            return ret;
        }



    oManager.onDateChange = function(onFinish){

        oManager.load(onFinish)




    };

    return oManager;


}
