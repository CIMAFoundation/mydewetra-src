
function layerManager_dynamic_movie(layerObj) {

    var oManager = layerManager_default(layerObj);
    var oServices = oManager.oServices();
    var iOpacity = 1;

    var layerMovieConf;

    var infoAvaialability = {
        index: 0,
        length: 1,
        reverse: null// per i radar il primo layer disponibile è l'ultimo in ordine di tempo, al contrario dei modelli
    };

    var oDynamicPaletteSettings = {
        haveDynamicPalette: false,
        min_value: 0,
        max_value: 0
    };

    var playPromise;

    var layerId;

    var downloadUrl;

    var debug = true;

    var currentLoadedTimeline;

    var fadeEffectTime = 500;

    oManager.setCanMovie(true);

    oManager.draggable = function (){
        return true;
    }

    /**
     * not used builded for hybrid mode
     */
    function loadMovieOptions(){
        oServices.layerService.getSupportedMovie(layerObj.server.id,(supportedMovie)=> {

            var availableLayer = supportedMovie.datas.filter(layerConf => layerConf.dataId == layerObj.dataid)[0];

            if(availableLayer.dataId){
                oServices.layerService.createMovie(layerObj.server.id, layerObj.dataid,(data) => {

                    if (data.string == 'KO' || data.string == 'OK'){
                        oServices.layerService.getMovie(layer.server.id, layerObj.dataid,(data) =>{

                            //data.properties e data.datas
                            //da data.properties devo estrarre le selected entry di tipo list no hidden cobinare il value e in datas prendere il timelineid corretto

                            let attributes = data.properties.attributes.filter((attr) => {//filter by used attributes
                                return (attr.type == "List" && attr.visible == "true")
                            })

                            //build timelineId
                            let neededTimelineId= layerObj.dataid+'_';

                            attributes.map(( cur, idx ,src)=>{
                                let sep = (idx < (src.length-1))?'_':'';
                                if(cur.selectedEntry.value ){
                                    neededTimelineId += cur.selectedEntry.value + sep;
                                }
                            });

                            let timelineObj = data.datas.filter(obj => obj.timelineId == neededTimelineId)[0];



                            oServices.layerService.getMovieTimeline(layerObj.server.id,layerObj.dataid, timelineObj.timelineId, function(timeline){
                                console.log(timeline);

                            })


                        },(data) =>{
                            console.log(data);

                        },)
                    }

                })

            }else {
                //todo rendo compatibile con vecchia movie?
            }

        },(data)=>{console.log('error in get supported movie call')})
    }

    /**
     * evaluate if an attribute il of the type of movie
     * @param attr
     * @returns {boolean}
     */
    function evaluateAttributeForMovie(attr){
        return (attr.type == "List" && (attr.visible == "true" || typeof attr.visible === "boolean"));

    }

    /**
     * filter layer prop by exlcusion in configuration
     */
    function filterPropertiesByExclusion(){

        if(!layerMovieConf || !layerMovieConf.exclusion) return

        oManager.props().layerProperties.attributes = oManager.props().layerProperties.attributes.map((attribute) => {
            let exclusionAttr = layerMovieConf.exclusion.filter(excl => excl.attributeName == attribute.name)[0];

            if(exclusionAttr && Array.isArray(exclusionAttr.entries) && Array.isArray(attribute.entries)){
                attribute.entries =attribute.entries.filter(attr =>{
                    return (exclusionAttr.entries.indexOf(attr.value) == -1)
                })
                //console.log(attribute.entries);
                //console.log(exclusionAttr.entries);
                return attribute
            }else return attribute;
        })

        //console.log(oManager.props().layerProperties.attributes)

        if(debug) console.log('Movie Version 2');

    }

    /**
     * not used che id the attribute is valid for the movie
     * @returns {boolean}
     */
    function evaluateExclusion(){
        // console.log(layerMovieConf.exclusion);//attributeName entries
        // console.log(oManager.props().layerProperties.attributes); //attributes [name selectedEntry.value]

        //let attributes = oManager.props().layerProperties.attributes.filter(evaluateAttributeForMovie);
        var canMovie = true;

        if(!layerMovieConf) {
            oManager.setCanMovie(false)
            return false;
        }

        if(layerMovieConf && layerMovieConf.exclusion) {
            oManager.props().layerProperties.attributes = oManager.props().layerProperties.attributes.map((attribute) => {
                let exclusionAttr = layerMovieConf.exclusion.filter(excl => excl.attributeName == attribute.name)[0];

                if(exclusionAttr && Array.isArray(exclusionAttr.entries) && Array.isArray(attribute.entries)){
                    attribute.entries =attribute.entries.filter(attr =>{
                        return (exclusionAttr.entries.indexOf(attr.value) == -1)
                    })
                    //console.log(attribute.entries);
                    //console.log(exclusionAttr.entries);
                    return attribute
                }else return attribute;
            })
        }


        if(debug) console.log('Movie Version 2');

        return canMovie;
    }

    /**
     * select the correct timeline id and load the first one
     * @param onFinish
     */
    function initializeMovieV2(onFinish, index){

            if(layerMovieConf.dataId){
                oServices.layerService.createMovie(layerObj.server.id, layerObj.dataid,(data) => {

                    if (data.string == 'KO' || data.string == 'OK'){
                        oServices.layerService.getMovie(layerObj.server.id, layerObj.dataid,(data) =>{

                            //data.properties e data.datas
                            //da data.properties devo estrarre le selected entry di tipo list no hidden cobinare il value e in datas prendere il timelineid corretto

                            let attributes = oManager.props().layerProperties.attributes.filter(evaluateAttributeForMovie);

                            //build timelineId
                            let neededTimelineId= layerObj.dataid+'_';
                            attributes.map(( cur, idx ,src)=>{
                                let sep = (idx < (src.length-1))?'_':'';
                                if(cur.selectedEntry.value ){
                                    neededTimelineId += cur.selectedEntry.value + sep;
                                }
                            });

                            let timelineObj = data.datas.filter(obj => obj.timelineId == neededTimelineId)[0];

                            oServices.layerService.getMovieTimeline(layerObj.server.id,layerObj.dataid, timelineObj.timelineId, function(timeline){
                                if (debug)console.log(timeline); //timelineValues.entry[key value]

                                if (debug)console.log(oManager.item());


                                setLayerFromTimeline(timeline, 0, onFinish)

                            })


                        },(data) =>{
                            console.log(data);

                        },)
                    }

                })

            }
    }

    function updateMovieV2(onFinish){

        if(layerMovieConf.dataId){



                    oServices.layerService.getMovie(layerObj.server.id, layerObj.dataid,(data) =>{

                        //data.properties e data.datas
                        //da data.properties devo estrarre le selected entry di tipo list no hidden cobinare il value e in datas prendere il timelineid corretto

                        let attributes = oManager.props().layerProperties.attributes.filter(evaluateAttributeForMovie);

                        //build timelineId
                        let neededTimelineId= layerObj.dataid+'_';
                        attributes.map(( cur, idx ,src)=>{
                            let sep = (idx < (src.length-1))?'_':'';
                            if(cur.selectedEntry.value ){
                                neededTimelineId += cur.selectedEntry.value + sep;
                            }
                        });

                        let timelineObj = data.datas.filter(obj => obj.timelineId == neededTimelineId)[0];

                        oServices.layerService.getMovieTimeline(layerObj.server.id,layerObj.dataid, timelineObj.timelineId, function(timeline){
                            if (debug)console.log(timeline); //timelineValues.entry[key value]

                            if (debug)console.log(oManager.item());

                            let index = 0;

                            if(oManager.item().hasOwnProperty('key')){

                                index = timeline.timelineValues.entry.findIndex(function(currentValue, index, arr){
                                    return (currentValue.key == oManager.item().key)
                                });

                            }


                            setLayerFromTimeline(timeline, index, onFinish)

                        })


                    },(data) =>{
                        console.log(data);

                    },)




        }
    }



    oManager.load = function (onFinish){

        if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());


        oServices.layerService.getLayerProperties(layerObj, function (layerProp) {
            oManager.setProps(layerProp);

            oServices.layerService.getSupportedMovie(layerObj.server.id,(supportedMovie)=> {
                layerMovieConf = supportedMovie.datas.filter(layerConf => layerConf.dataId == layerObj.dataid)[0];

                filterPropertiesByExclusion();//filter layer props by exclusion configuration

                initializeMovieV2(onFinish);
                if(debug) console.log('MOVIE METHOD');

            }, function (){

                if(debug) console.log('ERROR');
            });



        })

    };




    oManager.update = function (newProps, newItem, onFinish){

        oManager.setProps(newProps);
        oManager.setItem(newItem);

        updateMovieV2(onFinish)


    };

    /**
     * writtengor hybrid mode currently not used
     * @param onFinish
     */
    function updateOldMethod( onFinish){

        var from = oServices.menuService.getDateFromUTCSecond();
        var to = oServices.menuService.getDateToUTCSecond();

        oServices.layerService.republishLayer(layerObj, oManager.props(), from, to, oManager.item(),
            function (data, status) {


                oManager.setDownloadUrl(((data.layertype && (data.layertype.toUpperCase() == 'VECTOR')) ?
                    layerObj.server.url + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=shape-zip&typeName=" + data.layerid :
                    layerObj.server.url + '/ddsData/' + data.layerid + '.tiff'));

                setLayer( data.layerid, onFinish);
            },

             function (data) {
                alert($translate.instant(data));
            })
    }

    function updateNewMethod(onFinish){


        initializeMovieV2(onFinish);
    }


    /**
     * set layer setting item and props
     * @param newProps
     * @param newItem
     * @param layerId
     * @param onFinish
     */
    function setLayerWithProp(newProps, newItem, layerId, onFinish) {


        oManager.setProps(newProps)

        oManager.setItem(newItem)

        setLayer(layerId, onFinish);


        if (debug) console.log(layerObj.id + " " + layerId)
    }

    /**
     * set layer without set prop and item
     * @param layerId
     * @param onFinish
     */
    function setLayer(layerId , onFinish){

        if (oManager.mapLayer()) iOpacity = oManager.mapLayer().options.opacity;

        var LoadedMapLayerToRemove = oManager.mapLayer();

        // if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

        oManager.setMapLayer(
            oServices.mapService.addWmsLayer(layerObj.server.url + '/wms', layerId, (oManager.haveDynamicPalette()) ? "minimum:" + oManager.haveDynamicPalette().min_value.toString() + ";maximum:" + oManager.haveDynamicPalette().max_value.toString() : null).setOpacity(0)
        );



        oServices.$timeout(() => {
            if(LoadedMapLayerToRemove)LoadedMapLayerToRemove.setOpacity(iOpacity/2)
            oManager.mapLayer().setOpacity(iOpacity/5)
        },fadeEffectTime/2);

        oServices.$timeout(() => {
            if(LoadedMapLayerToRemove)LoadedMapLayerToRemove.setOpacity(iOpacity/5)
            oManager.mapLayer().setOpacity(iOpacity/2)

        },fadeEffectTime/5);

        oServices.$timeout(() => {
            if(LoadedMapLayerToRemove)oServices.mapService.removeLayer(LoadedMapLayerToRemove);
            if (iOpacity != null) oManager.mapLayer().setOpacity(iOpacity);

        },fadeEffectTime);

        oManager.setLayerId(layerId);



        if (iOpacity != null) oManager.mapLayer().setOpacity(iOpacity);

        if (debug) console.log(layerObj.id + " " + layerId)


        if (onFinish) onFinish();
    }

    function setLayerFromTimeline(timeline, index, onFinish){

        //let item = {
                //"date": "2021-02-11T01:00:00Z",
                //"description": "Run: 2021-02-09 1200. Progr. + 37 h",
                //"id": "1612872000000;1613005200000"
            //};

        currentLoadedTimeline = timeline;

        //COSMO_I2_COSMO_I2_1_Native_tp_-_1612915200000_1612983600000
        let splittedValue = currentLoadedTimeline.timelineValues.entry[index].value.split('_');
        let sDateRef = splittedValue[splittedValue.length-1];
        let sDateRun = splittedValue[splittedValue.length-2];
        let diff = moment(sDateRun).diff(sDateRef, 'hours');

        let item = {
            "date": moment.unix(currentLoadedTimeline.timelineValues.entry[index].key).format(),
            "description": moment.unix(sDateRun).format("Run: YYYY-MM-DD HHmm. Progr. +") + diff + " h",
            "id" : sDateRun+';'+sDateRef,

        };

        oManager.setItem(item)



        oManager.infoAvaialability().index = index;

        oManager.infoAvaialability().length = timeline.timelineValues.entry.length;

        setLayer(currentLoadedTimeline.timelineValues.entry[index].value, onFinish);
    }



    function setLayerFromLastLoadedTimeline(newIndex, onFinish){




        if(newIndex){
            oManager.infoAvaialability().index = newIndex;
        }

        let splittedValue = currentLoadedTimeline.timelineValues.entry[oManager.infoAvaialability().index].value.split('_');
        let sDateRef = splittedValue[splittedValue.length-1];
        let sDateRun = splittedValue[splittedValue.length-2];
        let diff = moment(sDateRun).diff(sDateRef, 'hours');

        let item = {
            "date": moment.unix(currentLoadedTimeline.timelineValues.entry[oManager.infoAvaialability().index].key).format(),
            "description": moment.unix(sDateRun).format("Run: YYYY-MM-DD HHmm. Progr. +") + diff + " h",
            "id" : sDateRun+';'+sDateRef,

        };

        oManager.setItem(item)

        setLayer(currentLoadedTimeline.timelineValues.entry[oManager.infoAvaialability().index].value, onFinish)

        //oManager.infoAvaialability().length = timeline.timelineValues.entry.length
    }


    oManager.haveDynamicPalette = function (obj) {

        if (obj) {
            oDynamicPaletteSettings = obj
            setLayer(layerId)
        }

        if (oDynamicPaletteSettings.haveDynamicPalette) {
            return oDynamicPaletteSettings
        } else return false;
    }

    function buildDynamicPaletteData() {

        if (oDynamicPaletteSettings.haveDynamicPalette) return oDynamicPaletteSettings;


        if (oManager.props().layerProperties.attributes.length > 0) {

            var dynamicPaletteProp = _.findWhere(oManager.props().layerProperties.attributes, {name: "dyn_pal"})

            if (dynamicPaletteProp && dynamicPaletteProp.selectedEntry.value == "1") {
                var obj = {}
                obj.haveDynamicPalette = true;//setto opzio true
                var selectedVariable = _.findWhere(oManager.props().layerProperties.attributes, {name: "variable"})
                var maxVal = _.findWhere(selectedVariable.selectedEntry.referredValues.entry, {key: "max_def"});
                if (maxVal) {
                    obj.max_value = parseFloat(maxVal.value);
                    obj.min_value = parseFloat((_.findWhere(selectedVariable.selectedEntry.referredValues.entry, {key: "min_def"})).value);
                    oDynamicPaletteSettings = obj
                    //return obj// forse inutile
                }
            }

        }
    }



    oManager.canPlay= function (){
        return (playPromise == null);
    }

    oManager.play = function (oRootScope){

        if(playPromise != null){
            oManager.stop();
            return
        }

        playPromise = oServices.$interval(function () {

            if (oRootScope.pendingRequests == 0) {

                if (oManager.infoAvaialability().reverse) {
                    if (oManager.infoAvaialability().index != 0) {
                        oManager.goBackward();
                    } else oManager.goToLast();
                } else {
                    if (oManager.infoAvaialability().index < oManager.infoAvaialability().length - 1) {
                        oManager.goForward();
                    } else oManager.goToFirst();
                }

            }
        }, 2000);
    }

    oManager.stop = function () {
        oServices.$interval.cancel(playPromise);
        playPromise = null;
    }


    oManager.goToLast = function () {
        setLayerFromLastLoadedTimeline(infoAvaialability.length - 1)
    }

    oManager.goToFirst = function () {
        setLayerFromLastLoadedTimeline(0)
    }

    oManager.goForward= function (){
        setLayerFromLastLoadedTimeline(oManager.infoAvaialability().index + 1 )
    }

    oManager.canForward = function (){

        if(oManager.canMovie()){
            return ( oManager.infoAvaialability().index < oManager.infoAvaialability().length);
        }else return false;

    }

    oManager.goBackward = function (){
        setLayerFromLastLoadedTimeline(oManager.infoAvaialability().index - 1 )
    }

    oManager.canBackward = function () {

        if(oManager.canMovie()){
            return ( oManager.canMovie() && oManager.infoAvaialability().index >= 0);
        }else return false;

    }

    oManager.layerDateRefFromManager = function (){

    }

    oManager.dateLine = function (){
        try {
            return oManager.dateRefFormatted()
        }catch (e){
            if (debug)   //console.log(e);
            return "date";
        }
    }

    oManager.dateRun = function (){
        if (oManager.item().id == null) return "";
        var aSplittedDate = oManager.item().id.split(';');
        var dateRun = moment.utc(parseInt(aSplittedDate[0]));
        return dateRun;
    }
    oManager.dateRef = function (){
        if (oManager.item().id == null) return "";
        var aSplittedDate = oManager.item().id.split(';');
        var dateRef = moment.utc(parseInt(aSplittedDate[1]));
        return dateRef;
    }

    oManager.dateForecast = function () {
        if (oManager.item().id == null) return "";
        var aSplittedDate = oManager.item().id.split(';');
        var diff = ((parseInt(aSplittedDate[1])) - (parseInt(aSplittedDate[0])));
        if (diff > 0) {
            diff = diff / (1000 * 60 * 60);
            return "+" + parseInt(diff);
        } else if (diff < 0) {
            return "-" + Math.abs(parseInt(diff)) / (1000 * 60 * 60);
        } else return 0;
    },

    oManager.dateRefFormatted = function () {
        var sDateRunDateRef = oManager.item().id;



        if (oManager.props().layerProperties.id == "WFSNOWROADS") return item.id.replace(/;/g, ' ');

        if (sDateRunDateRef  == null) return "";

        if (sDateRunDateRef.indexOf(";") > -1) {
            //controllo se osservazione o previsione
            var bLayerType = layerObj.category == "observation";
            //se osservazione la data di run corrisponde alla dateref e ne visualizzo solo una
            if (bLayerType) {
                var aDateRunDateRef = sDateRunDateRef.split(";");
                var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                //var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                return sDateRun
            } else {
                //se previsione distinguo le due date
                var aDateRunDateRef = sDateRunDateRef.split(";");
                var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');
                return sDateRef + " " + " (Run:" + sDateRun + ")";
            }
            //se ha solo una data non mi pongo il problema
        } else {


            // Anto 20160908: Se item.id non è una data provo con item.date
            var tsRun = parseInt(sDateRunDateRef);
            if (!isNaN(tsRun)) {
                return moment(new Date(tsRun)).utc().format('DD/MM/YYYY HH:mm');
            }
            else {
                return moment(Date.parse(oManager.item().date)).utc().format('DD/MM/YYYY HH:mm');
            }

        }

    };



    oManager.thirdLine = function () {
        return true
    }

    oManager.getVariable= function () {


        var str = "";
        if (Array.isArray(oManager.props().layerProperties.attributes)) {
            oManager.props().layerProperties.attributes.forEach(function (prop) {
                if (prop.name == "operation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (prop.name == "variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                if (prop.name == "__variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            })
            return str;
        } else {
            if (oManager.props().layerProperties.attributes.name == "operation") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            if (oManager.props().layerProperties.attributes.name == "variable") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            if (oManager.props().layerProperties.attributes.name == "__variable") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
        }

    };

    oManager.getAggregation= function () {
        var str = "";

        if (Array.isArray(oManager.props().layerProperties.attributes)) {
            oManager.props().layerProperties.attributes.forEach(function (prop) {
                if (prop.name == "aggregation") str = prop.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
                if (prop.name == "__aggregation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
            })
            return str;
        } else {
            if (oManager.props().layerProperties.attributes.name == "aggregation") str = oManager.props().layerProperties.attributes.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
            if (oManager.props().layerProperties.attributes.name == "__aggregation") str = oManager.props().layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
        }


    };



    oManager.remove = function (layer,onFinish){
        try{
            oManager.stop();
        }catch (e){
            console.log("not playing");
        }
        oServices.mapService.removeLayer(layer);
        if (onFinish)onFinish()
    }


    oManager.onDateChange= function (onFinish) {
        console.log("on Date Change");

        //TODO on date change load layer no movie
        let new_manager = layerManager_dynamic_v3(layerObj)

        new_manager.load(function (oninish){
            oServices.mapService.oLayerList.addLayer(new_manager);
            oServices.mapService.oLayerList.removeLayer(oManager);
            if(onFinish) onFinish()
        });

        oManager = new_manager;

        //oManager.remove(oManager.mapLayer())



        //oManager.load(onFinish)

    },

    oManager.showProps= function (onFinish) {

        var modalInstance = oServices.$uibModal.open({
            animation: true,
            component: 'layerPropertiesMovie',
            size:'lg',
            resolve:{
                oManager:function () {
                    return oManager
                }

            }
        });

        modalInstance.result.then(function (obj) {

            console.log('modal-component dismissed at: ' + new Date());

            oManager.update(obj.props, obj.data, onFinish)

            modalInstance = null;

        }, function () {
            console.log('modal-component dismissed at: ' + new Date());
            modalInstance = null;
        });
    };

    oManager.layerTooltip = function (){

        //dividere per osservazioni o previsioni e aggiungere le properties al tooltip


        var layerDelay = function (layerManagerObj) {


            try {
                var oReferenceDate = layerManagerObj.dateRef().utc().toDate()
            } catch (err) {
                return layerManagerObj.descr()
            }

            // Get Now
            var oDate = new Date();

            //if(debug)console.log("Now  = " + oDate);
            //if(debug)console.log("Ref  = " + oReferenceDate);

            // Compute time difference
            var iDifference = oDate.getTime() - oReferenceDate.getTime();

            // How it is in minutes?
            var iMinutes = 1000 * 60;

            var iDeltaMinutes = Math.round(iDifference / iMinutes);

            var sTimeDelta = "";

            if (iDeltaMinutes > 0) {
                if (iDeltaMinutes < 60) {
                    // Less then 1h
                    sTimeDelta += oServices.$translate.instant("pre_min_fa") + " " + iDeltaMinutes + ' ' + oServices.$translate.instant("min_fa");
                } else if (iDeltaMinutes < 60 * 24) {
                    // Less then 1d
                    var iDeltaHours = Math.round(iDeltaMinutes / 60);
                    sTimeDelta += oServices.$translate.instant("pre_ore_fa") + " " + iDeltaHours + ' ' + oServices.$translate.instant("ore_fa");
                } else {
                    // More than 1d
                    var iDeltaDays = Math.round(iDeltaMinutes / (60 * 24));
                    sTimeDelta += oServices.$translate.instant("pre_giorni_fa") + " " + iDeltaDays + ' ' + oServices.$translate.instant("giorni_fa");
                }
            } else {
                if (iDeltaMinutes > -60) {
                    // Less then 1h
                    sTimeDelta += oServices.$translate.instant("Fra") + ': ' + Math.abs(iDeltaMinutes) + ' ' + oServices.$translate.instant("Minuti");
                } else if (iDeltaMinutes > -60 * 24) {
                    // Less then 1d
                    var iDeltaHours = Math.round(iDeltaMinutes / 60);
                    sTimeDelta += oServices.$translate.instant("Fra") + ': ' + Math.abs(iDeltaHours) + ' ' + oServices.$translate.instant("Ore");
                } else {
                    // More than 1d
                    var iDeltaDays = Math.round(iDeltaMinutes / (60 * 24));
                    sTimeDelta += oServices.$translate.instant("Fra") + ': ' + Math.abs(iDeltaDays) + ' ' + oServices.$translate.instant("Giorni");
                }
            }


            return sTimeDelta;
        };

        //gestisco la from date nel tooltip.
        try {
            var oHoursOfCumulate = oManager.props().layerProperties.attributes.filter((attr) => {
                return attr.descr == "Cumulative Rainfall"
            })[0].selectedEntry

            var iHoursOfCumulate = parseInt(oHoursOfCumulate.value);

            // if(iHoursOfCumulate == '-1') {
            //     console.log("cumulata su time range")
            //     iHoursOfCumulate = Math.abs(menuService.getDateTo() - menuService.getDateFrom()) / 36e5;
            // }

        } catch (e) {
            console.log(iHoursOfCumulate);
        }


        //gestisco risoluzione spaziale pioggia

        try {
            var oSpatialResolution = oManager.props().layerProperties.attributes.filter((attr) => {
                return attr.descr == "Spatial Resolution"
            })[0].selectedEntry;


        } catch (e) {
            console.log(e)
        }


        //definisco oggetto tooltip
        var oTooltip = {
            "API 15": [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") : ""
                }
            ],
            MCM_CUMULATED_RAIN_DESCR: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") : ""
                }
            ],
            RADAR: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.getVariable()
                },
                //{
                //    label : "DATE_RUN",
                //    value : oManager.dateRun().format("YYYY/MM/DD HH:mm")
                //},
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") + ' UTC' : "",
                },
                //{
                //    label : "DATE_FORECAST",
                //    value : oManager.dateForecast()
                //},
                // {
                //     label: "DATE_DELAY",
                //     value: layerDelay(oManager)
                // }
            ],
            observation: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: (oManager.getVariable()) ? oManager.getVariable() : oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id && oManager.dateRef().isValid == true) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") : ""
                }
                // {
                //     label : "DATE_DELAY",
                //     value : layerDelay(oManager)
                // }
            ],
            forecast: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_RUN",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") : ""
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") + " (" + oManager.dateForecast() + " h)" : ""
                },
                // {
                //     label : "DATE_FORECAST",
                //     value : oManager.dateForecast()
                // },
                // {
                //     label : "DATE_DELAY",
                //     value : layerDelay(this)
                // }

            ],
            DEFAULT: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                }
            ],
            RAINFALL_FIELD: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: oManager.dateRun().format("DD/MM/YYYY HH:mm")
                },
                {
                    label: "CUMULATE_TIME",
                    value: (oHoursOfCumulate) ? oHoursOfCumulate.descr : null
                },
                {
                    label: "AGGREGATION",
                    value: (oSpatialResolution) ? oSpatialResolution.descr : null
                },
                {
                    label: "FROM_DATE",
                },
                {
                    label: "TO_DATE",
                    value: oManager.dateRun().format("DD/MM/YYYY HH:mm")
                }
            ],
            WFSNOWROADS: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_REF",
                    value: oManager.item().id.replace(/;/g, ' ')
                }
            ],
            FULL: [
                {
                    label: "LAYER_NAME",
                    value: oManager.name()
                },
                {
                    label: "LAYER_DESCRIPTION",
                    value: oManager.descr()
                },
                {
                    label: "DATE_RUN",
                    value: (oManager.item().id) ? oManager.dateRun().format("DD/MM/YYYY HH:mm") : ""
                },
                {
                    label: "DATE_REF",
                    value: (oManager.item().id) ? oManager.dateRef().format("DD/MM/YYYY HH:mm") : ""
                },
                {
                    label: "DATE_FORECAST",
                    value: oManager.dateForecast()
                },
                {
                    label: "DATE_DELAY",
                    value: layerDelay(oManager)
                }]
        };


        //layer prop
        var oProperties = oManager.props();

        //inizializzo array
        var aProperties = []

        var aHidedProp = ["-", "dir", "Directory"];

        if (oProperties.layerProperties.attributes.length >= 1) {
            oProperties.layerProperties.attributes.forEach(function (prop) {
                if (prop.visible = "false") {
                    prop.visible = true
                    prop.hidden = true;
                }
                var oProp = {
                    label: prop.descr,
                    value: prop.selectedEntry.descr
                }

                // if(!aHidedProp.includes(prop.descr)){
                //     if(prop.hidden ){
                //         aProperties.push(oProp)
                //     }
                // }

                if ((!aHidedProp.includes(prop.descr)) && !prop.hidden) {
                    aProperties.push(oProp)
                }
                ;

            })
        }


        // radar a parte
        //se un radar ritorno tooltip radar
        if ((oManager.name().toUpperCase().indexOf('RADAR')) > -1) {
            return oTooltip['RADAR'].concat(aProperties);
        }

        if ((oManager.name().indexOf('MAPPA_PIOGGIA')) > -1) {
            return oTooltip['RAINFALL_FIELD'].concat(aProperties);
        }

        if (layerObj.category == "observation") {

            return oTooltip[layerObj.category].concat(aProperties);

        } else if (layerObj.category == "forecast") {
            if (layerObj.dataid == "WFSNOWROADS") return oTooltip[layerObj.dataid]
            return oTooltip[layerObj.category].concat(aProperties);

        }


        //altrimenti se cè un tooltip pre preparato carico quello
        if (oTooltip[layer.descr]) return oTooltip[layer.descr];

        //altrimenti tooltip di default
        return oTooltip['DEFAULT'];

    }

    oManager.legend = function (callback) {

        //if (oLegend != null) callback(oLegend);
        //controllo se nelle properties cè l'attributo custom legend
        for (var i = 0; i < oManager.props().layerProperties.attributes.length; i++) {
            var attr = oManager.props().layerProperties.attributes[i]
            if (attr.name == 'customLegend') {

                oLegend = {
                    dynPalette: {},
                    type: "DDS_CUSTOM_LEGEND",
                    url: attr.selectedEntry.value,
                    layers: oManager.mapLayer().wmsParams.layers,
                }

                callback(oLegend);
            }
        }

        //chiamo api per sapere se c'è una palette dinamica

        oServices.apiService.get('ddsmap/layerstyle/' + layerObj.server.id + '/' + oManager.mapLayer().options.layers, function (data) {
            // apiService.getExt('http://dds.cimafoundation.org/dewetra2/dewapi/ddsmap/layerstyle/'+ layer.server.id+'/'+mapLayer.options.layers , function (data) {
            // mapLayer.options.layers
            if (debug) console.log(data);

            if (oDynamicPaletteSettings.haveDynamicPalette) {

                var delta = (((oDynamicPaletteSettings.max_value - oDynamicPaletteSettings.min_value) / (data.length - 1))).toFixed(2);

                data.forEach(function (item, index) {
                    item.value = oDynamicPaletteSettings.min_value + (index * delta);
                })

                let oLegend = {
                    aPalette: data,
                    dynPalette: oDynamicPaletteSettings,
                    type: layerObj.type.code.toUpperCase(),
                    url: mapLayer._url,
                    layers: mapLayer.wmsParams.layers,
                }
                if (callback) callback(oLegend);

            } else {
                if (data.length > 1) {

                    var legend = {

                        type: "ADVANCED",
                        legend: [{
                            type: "CUSTOM",
                            title: layerObj.name,
                            palette: []
                        }]

                    }

                    legend.legend.palette = []
                    data.forEach(function (val) {
                        legend.legend[0].palette.push(
                            {
                                label: val.label,
                                color: val.color,
                            }
                        )
                    })

                    if (callback) callback(legend);

                }

                let oLegend = {
                    aPalette: data,
                    dynPalette: {},
                    type: layerObj.type.code.toUpperCase(),
                    url: oManager.mapLayer()._url,
                    layers: oManager.mapLayer().wmsParams.layers,
                }
                if (callback) callback(oLegend);
            }


        }, function (err, head) {
            if (debug) console.log(err);
            aPalette = null;
            oLegend = {
                type: layerObj.type.code.toUpperCase(),
                url: oManager.mapLayer()._url,
                layers: oManager.mapLayer().wmsParams.layers,
            }
            if (callback) {
                callback(oLegend)
            } else return null;


        });

    };

    return oManager;

}
