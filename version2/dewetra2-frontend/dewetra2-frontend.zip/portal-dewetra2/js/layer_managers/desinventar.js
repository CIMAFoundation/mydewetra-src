/**
 * Created by Dario Rubado on 27/02/19.
 */




function layerManager_desinventar(layerObj) {

    var oManager = layerManager_default(layerObj);

    var oServices = oManager.oServices()

    var oTheGeoJson = null;

    var sKey,sHazardKey;

    var oLegendSubLevel = {

        type: "ADVANCED",
        legend: [{
            type: "CUSTOM",
            title: "DESINVENTAR",
            palette: []
        }]

    }

    var isVisible = true;

    var oLegend = {}


    var iOpacity = 1;

    oManager.legend = function () {
        return oLegend[sKey.toLowerCase()]
    }

    function paletter(geoJson) {

        oLegend = {}

        var iLengthPalette = 10;

        var iMax, iMin;

        let filteredGeoJson =geoJson.features.filter(feature=>{
            if(feature.properties && feature.properties.aggregations) return feature
        });

        if (filteredGeoJson.length > 0) {


            for (var i in  filteredGeoJson[0].properties.aggregations) {
                var iMax =0, iMin = 0;

                iMax = oServices._.max(filteredGeoJson, function (feature) {
                    if (feature.properties && feature.properties.aggregations && feature.properties.aggregations[i]) {
                        return parseInt(feature.properties.aggregations[i])
                    }

                });

                try {
                    iMax.properties.aggregations[i] = (iMax.properties && iMax.properties.aggregations && iMax.properties.aggregations[i] == 0)?10:iMax.properties.aggregations[i];

                    var iQuotient = (iMax.properties.aggregations[i] / iLengthPalette);

                    var iColorQuotient = (255 / iLengthPalette)

                    for (var j = 0; j <= iLengthPalette; j++) {

                        if (!oLegend.hasOwnProperty(i)) {
                            oLegend[i] = angular.copy(oLegendSubLevel)
                        }

                        oLegend[i].legend[0].palette.push({
                            label: oServices.$translate.instant(i.toUpperCase()),
                            color: rgbToHex(255, 255 - (iColorQuotient * j).toFixed(0), 255 - (iColorQuotient * j).toFixed(0)),
                            sign: "",
                            value: (iQuotient * j),
                            mu: "",
                            dec: 0,
                            minValue: iQuotient * j,
                            maxValue: iQuotient * (j + 1),
                        })

                    }

                    console.log(oLegend[i])
                }catch (e) {
                    console.log(e)
                    break
                }




            }
        }

    }

    function paletteFeature(aPalette, iFeatureValue) {

        var color = "#46ff15";

        aPalette.forEach(function (item) {

            var iValue = parseInt(iFeatureValue);

            if (iValue >= item.minValue && iValue <= item.maxValue) {
                color = item.color;
            }
        });

        return color;
    }

    function onClick(e) {
        //console.log(alert(e.target.feature.properties.aggregations[sKey]))
    }

    function onMouseOver(e) {


        if(oManager.hasOwnProperty("getWarningInfo")){

            let geoServerPalette =""

            e.target.feature.properties.data = {key:sKey,value:e.target.feature.properties.aggregations[sKey.toLowerCase()]}

            oManager.getWarningInfo().mouseOver('DESINVENTAR',oManager.mapLayer()._leaflet_id, e.target.feature.properties, geoServerPalette)
        }

        console.log(e)

        //e.target.bindPopup(e.target.feature.properties.aggregations[sKey.toLowerCase()]);
        //e.target.openPopup()
    }

    function onMouseOut(e) {
        console.log(e)

        oManager.getWarningInfo().mouseOut('DESINVENTAR',oManager.mapLayer()._leaflet_id)

        e.target.closePopup()
    }

    function featureStyler(feature) {

        if (feature.properties && feature.properties.aggregations) {

            var color = paletteFeature(oLegend[sKey.toLowerCase()].legend[0].palette, feature.properties.aggregations[sKey.toLowerCase()]);

            return {
                color: "#000",
                weight: 1,
                fillColor: color,
                fillOpacity: iOpacity,
                opacity: iOpacity
            }
        }else {
            return {
                color: "#000",
                weight: 1,
                fillColor: "#bbb",
                fillOpacity: iOpacity,
                opacity: iOpacity
            }
        }

    }

    oManager.load = function (onFinish) {

        var sIconFunctionName = layerObj.layerType + "_Icon";

        var sPrintFunctionName = layerObj.layerType + "_Print";


        oServices.apiService.getExt(layerObj.server.url + '/config/' + layerObj.dataid, function (data) {

            oManager.setProps(data);

            oServices.apiService.getExt(layerObj.server.url + '/layer/' + layerObj.dataid + '/' + oManager.props().layerProperties.attributes[0].selectedEntry.value, function (data) {

                // console.log(oLegend);

                oTheGeoJson = data;

                paletter(data)

                sKey = oManager.props().layerProperties.attributes[1].selectedEntry.value
                sHazardKey = oManager.props().layerProperties.attributes[2].selectedEntry.value

                oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(oTheGeoJson, layerObj.descr, {
                    style: featureStyler
                }, onClick, onMouseOver, onMouseOut));

                if (onFinish) onFinish()
            })

        })


    }

    oManager.update = function () {

        let sQueryString = '';

        oManager.props().layerProperties.attributes.forEach(function (oAttr) {

            if(oAttr.hasOwnProperty("querystring")){
                if(oAttr.selectedEntry.value != "DEFAULT"){
                    if(sQueryString.indexOf("?")>-1){
                        sQueryString+= "&"+oAttr.querystring+"="+oAttr.selectedEntry.value+""
                    }else {
                        sQueryString+= "?"+oAttr.querystring+"="+oAttr.selectedEntry.value+""
                    }

                }
            }
        })



        oServices.apiService.getExt(layerObj.server.url + '/layer/' + layerObj.dataid + '/' + oManager.props().layerProperties.attributes[0].selectedEntry.value+sQueryString, function (data) {

            if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());

            oTheGeoJson = data;

            sKey = oManager.props().layerProperties.attributes[1].selectedEntry.value

            paletter(data)

            oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(oTheGeoJson, layerObj.descr, {
                style: featureStyler
            }, onClick, onMouseOver, onMouseOut));


        })
    }


    oManager.showProps = function (onFinish) {

        var _this = this;
        var layerPropModal = oServices.$uibModal.open({
            templateUrl: 'apps/dewetra2/views/layer_properties_desinventar.html',

            controller: ['$scope', 'layerService', 'mapService', 'menuService', '$uibModalInstance', 'params', '$interval', '$translate', '_',function ($scope, layerService, mapService, menuService, $uibModalInstance, params, $interval, $translate, _) {

                $scope.isVisible = function (visibleAttr) {
                    if (visibleAttr == true || visibleAttr == "true") return true
                    return false;
                }

                $scope.islist = function (attr) {
                    return attr.type.toLowerCase() == 'list'
                };

                $scope.istime = function (attr) {
                    return attr.type.toLowerCase() == 'time'
                };

                $scope.dateOptions = {
                    dateDisabled: false,
                    formatYear: 'yy',
                    maxDate: new Date(),
                    minDate: new Date(1900, 5, 22),
                    startingDay: 1
                };

                $scope.popup1 = {
                    opened: false
                };

                $scope.popup2 = {
                    opened: false
                };

                $scope.open1 = function() {
                    $scope.popup1.opened = true;
                };

                $scope.open2 = function() {
                    $scope.popup2.opened = true;
                };

                $scope.update = function () {

                    if((moment($scope.dateFrom).isValid()&&moment($scope.dateTo).isValid()) && moment($scope.dateTo).valueOf()>=moment($scope.dateTo).valueOf()){

                        console.log("cambiate e settate");

                        var propDateTo = {
                            "descr":"DATE_TO",
                            "name":"DATE_TO",
                            "selectedEntry":{
                                "value":moment($scope.dateTo).format("YYYY-MM-DD")
                            },
                            "type":"date",
                            "data": "DATA_PROP",
                            "description": "DATA_PROP",
                            "id": "DATA_PROP",
                            "longDescription": "DATA_PROP",
                            "visible": "true",
                            "querystring": "dateto"
                        }

                        var propDateFrom = {
                            "descr":"DATE_FROM",
                            "name":"DATE_FROM",
                            "selectedEntry":{
                                "value":moment($scope.dateFrom).format("YYYY-MM-DD")
                            },
                            "type":"date",
                            "data": "DATA_PROP",
                            "description": "DATA_PROP",
                            "id": "DATA_PROP",
                            "longDescription": "DATA_PROP",
                            "visible": "true",
                            "querystring": "datefrom"
                        }

                        $scope.data.props.layerProperties.attributes = $scope.data.props.layerProperties.attributes.filter(function (data) {
                            return data.type != "date"
                        })

                        $scope.data.props.layerProperties.attributes.push(propDateFrom,propDateTo)

                    }


                    oManager.setProps($scope.data.props);

                    oManager.update()
                    $uibModalInstance.close($scope.data);
                };

                $scope.data = {
                    props: null,
                    data: null,

                };



                $scope.$watch('dateFrom',function () {
                    moment($scope.dateFrom).isValid()
                })

                $scope.$watch('dateTo',function () {
                    moment($scope.dateTo).isValid()
                });


                $scope.closePopup = function(){
                    $uibModalInstance.close();
                }

                $scope.checkAttributes = function () {
                    $scope.data.props.layerProperties.attributes.map((x)=>{

                        if(x.descr == "DES_AGGREGATION_DESCR"){
                            $scope.indicatorDescription = $translate.instant(x.selectedEntry.value+"_DESCR")
                        }

                    });
                } ;

                //INIT
                if (oManager.props()) {

                    $scope.data.props = angular.copy(oManager.props());

                    console.log($scope.data.props);


                    $scope.dateFrom = new Date("1990-01-01");
                    $scope.dateTo = new Date();

                    $scope.data.props.layerProperties.attributes.map((x)=>{
                       if(x.descr == "DATE_TO"){
                           $scope.dateTo = new Date(x.selectedEntry.value)
                       }

                        if(x.descr == "DATE_FROM"){
                            $scope.dateFrom = new Date(x.selectedEntry.value)
                        }

                        if(x.descr == "DES_AGGREGATION_DESCR"){
                            $scope.indicatorDescription = $translate.instant(x.selectedEntry.value+"_DESCR")
                        }

                    });


                    //preseleziono nel menu a tendina il valore caricato

                    for (var j in $scope.data.props.layerProperties.attributes) {

                        for (var i in $scope.data.props.layerProperties.attributes[j].entries) {

                            if ($scope.data.props.layerProperties.attributes[j].entries[i].value == $scope.data.props.layerProperties.attributes[j].selectedEntry.value) {
                                $scope.data.props.layerProperties.attributes[j].selectedEntry = $scope.data.props.layerProperties.attributes[j].entries[i]
                            }

                        }
                    }

                }
            }],
            size: "lg",
            resolve: {
                params: function () {
                    return {
                        oManager: oManager
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {


            oManager.update(obj.props, obj.data, onFinish)
        }, function () {

        });
    };


    oManager.setOpacity = function (value) {

        if (value) {
            for ( let i in oManager.mapLayer()._layers){
                iOpacity = value
                oManager.mapLayer()._layers[i].setStyle(featureStyler(oManager.mapLayer()._layers[i].feature))
            }
        }
    }

    oManager.getOpacity = function () {
        return iOpacity
    }


    oManager.setVisible = function (b) {

        if(!b) {
            if (oManager.mapLayer()) oServices.mapService.removeLayer(oManager.mapLayer());
        }else {
            oManager.setMapLayer(oServices.mapService.addGeoJsonLayer(oTheGeoJson, layerObj.descr, {
                style: featureStyler
            }, onClick, onMouseOver, onMouseOut));
        }

        isVisible = b
    }

    oManager.isVisible = function () {
        return isVisible
    }


    return oManager

}
