/**
 * Created by Dario on 12/12/22.
 */

function layerManager_static_custom_geojson(layerObj) {
    const oManager = layerManager_static(layerObj)

    let stationClickListener;

    const stationInfoMouseOver = (target)=>{
        console.log(target)
    }

    const stationInfoMouseOut = (target)=>{
        console.log(target)
    }

    const multiLineString = {
        fillColor: "red",
        color : "black",
        opacity : 1,
        fillOpacity: 0.3,
        weight: 1,

    }

    const multiPolygon = {
        fillColor: "red",
        color : "red",
        opacity : 1,
        fillOpacity: 0.3,
        weight: 1,

    }

    var geojsonMarkerOptions = {
        radius: 5,
        fillColor: "blue",
        color: "red",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.5
    };

    oManager.load = function (onFinish) {

        try {
            if (oManager && oManager.hasOwnProperty('layerObj') && oManager.layerObj().hasOwnProperty("customprops") && oManager.customprops() != null && oManager.customprops().hasOwnProperty("geoJson")) {

                const mapLayer =oManager.oServices().mapService.addGeoJsonLayer(
                    oManager.customprops()['geoJson'], oManager.layerObj()['descr'], {
                        onEachFeature: function (f, l) {
                            l.bindPopup('<pre>'+JSON.stringify(f.properties,null,' ').replace(/[\{\}"]/g,'')+'</pre>');
                        },
                        style:function (geoJsonFeature) {
                            if(geoJsonFeature && geoJsonFeature.geometry &&geoJsonFeature.geometry.type){
                                switch (geoJsonFeature.geometry.type) {
                                    case "MultiLineString":
                                        return multiLineString
                                        break;
                                    case "MultiPolygon":
                                        return multiPolygon
                                        break;
                                }
                            }
                        },
                        pointToLayer: function(feature,latlng) {
                            return L.circleMarker(latlng, geojsonMarkerOptions);
                        }

                    }, stationClickListener,stationInfoMouseOver, stationInfoMouseOut)

                mapLayer.eachLayer((layer)=>{
                    if(layer.feature.geometry.type != "MultiPolygon"){
                        layer.bringToFront()
                    }else{
                        layer.bringToBack()
                    }
                })
                oManager.setMapLayer(mapLayer)
            }
        }catch (e) {
            console.log(e);
        }

        if (onFinish) onFinish()

    }

    return oManager
}
