/**
 * Created by Dario Rubado on 29/06/15.
 */


dewetraApp.controller("liveIndicatorController",['$scope','$rootScope', '$filter','$interval', 'acEvent','$timeout', 'settingsService', function ($scope,$rootScope, $filter,$interval, acEvent,$timeout, settingsService) {


    $scope.isLiveDirectiveEnabled= window.app.config.liveIndicatorDirective.enabled;

    var wsAcquisition = null;
    var aPromises = [];
    var oPromise = null;

    $scope.mouseOn = false;

    $scope.newMessage = false;

    $scope.sensorUpdated = {
        sensorReceivedCounter :0,
        lastDateUpdate : moment.utc(),
        delayTime:-2
    }

    $scope.log = false;

    $scope.mouseEnter= function () {

        $timeout(function () {
            //set blinking for 5 seconds
            $scope.blink = true;
            if($scope.log)console.log("blink rotella")
        })


    }

    $scope.mouseLeave = function () {

        oPromise = $interval(function () {
            if($scope.blink == true){
                $timeout(function () {
                    $scope.blink = false
                });
                $scope.blink = false;
                if($scope.log)console.log(" stop blink rotella");

            }else{
                aPromises.forEach(function (promise) {
                    $interval.cancel(promise);
                })
            }

        }, 5000);

        aPromises.push(oPromise);
    }

    function init() {


        $scope.blink = false;
        $scope.messages = [];

        if (window.app.url.rabbitURL != undefined){
            //check for new sensor
            acEvent.connect('logger', 'logger4dew',
                function () {
                    wsAcquisition = acEvent.subscribe('sentinel.2.#', onNewDataAquired);
                    $scope.bStompStatus = true
                },
                function () {
                    console.log('waiting 5 seconds and then reconnect');
                    $scope.bStompStatus = false;
                    setTimeout(init, 5000)
                }
            )
        }{
            $scope.bStompStatus = true
        }


        
        
        //check for new layer
        $rootScope.$on('NEWACQ', function (event, data) {
            var message = {
                // msg: $filter('translate')(event.name, data.split("|")[0]),
                msg: event.name +":"+ data.split("|")[0].split("_")[0]+" "+data.split("|")[0].split("_")[1]+" "+data.split("|")[0].split("_")[2],
                dt: moment().utc().format('HH:mm:ss'),
                data: data
            };
            if(message.msg.indexOf("undefined")> -1) message.msg.replace(/undefined/g,'');

            publishMessage(message)
            if($scope.log)console.log("write message sensor updated");
        })


    }


    function onNewDataAquired(data) {


        $scope.sensorUpdated.sensorReceivedCounter += Object.keys(data).length;

        if ($scope.sensorUpdated.lastDateUpdate.diff(moment.utc(),'minutes') < $scope.sensorUpdated.delayTime){


            var message = {
                msg: $filter('translate')('SENSORS_ACQUIRED', {num: $scope.sensorUpdated.sensorReceivedCounter}),
                dt: $scope.sensorUpdated.lastDateUpdate.format('HH:mm:ss'),
                data: data
            };
            publishMessage(message);

            $scope.sensorUpdated.lastDateUpdate = moment.utc();
            $scope.sensorUpdated.sensorReceivedCounter = 0;
        }


    }



    function publishMessage(message) {


        $timeout(function () {
            //set blinking for 5 seconds
            $scope.blink = true;
            $scope.newMessage = true;
            if($scope.log)console.log("blink rotella")
        })

        oPromise = $interval(function () {
            if($scope.blink == true){
                $timeout(function () {
                    $scope.blink = false
                    $scope.newMessage = false;
                });
                $scope.blink = false;
                $scope.newMessage = false;
                if($scope.log)console.log(" stop blink rotella")

            }else{
                aPromises.forEach(function (promise) {
                    $interval.cancel(promise);
                })
            }

        }, 5000);

        aPromises.push(oPromise);

        //console.log(message)
        //add the message as first element
        var l = $scope.messages.unshift(message);
        //keep only the last messages
        if (l >= 5) $scope.messages = $scope.messages.slice(0, 5);
        // console.log('message: ' + message.msg + ' (queue: ' + $scope.messages.length + ')')
    }

    init()

}]);
