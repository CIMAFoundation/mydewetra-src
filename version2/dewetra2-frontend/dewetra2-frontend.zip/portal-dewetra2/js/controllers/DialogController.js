/**
 * Created by Dario Rubado on 26/05/15.
 */

dewetraApp.controller("dialogController", ['$scope', 'iconService', '$window', 'apiService',function ($scope, iconService, $window, apiService) {



    var aSensorLegend = ["WARNINGS_PLUVIO","WARNINGS_THERMO","WARNINGS_HYDRO","RAINGAUGE","THERMOMETER","HYGROMETER","WIND","FIRE_INDEX","PHENOLOGICAL_ANALYSIS","RASOR_DAMAGE","SNOWDEPTH","PHENOLOGICAL_ANALYSIS_CFR_ANNO","PHENOLOGICAL_ANALYSIS_FASE_ERBACEE","PHENOLOGICAL_ANALYSIS_FASE_FENOLOGICA"];

    var aUrlLegend = ["RAINFALL_FIELD","DYNAMIC","STATIC","STATIC_RASOR", "DYNAMIC_REALTIME","DYNAMIC_METEO_MODEL"];

    var staticLegend=["DYNAMIC_EXTERNAL_WMS_IZS_EXT","DYNAMIC_EXTERNAL_WMS_EXT","DYNAMIC_EXTERNAL_WMST_EFAS_EXT","DYNAMIC_SNOWROADS"];

    var oLayerManager = $scope.model.manager;

    var oLegend = $scope.model.legend;

    console.log(oLegend);


    var Height = 300;
    var Width = 300;

    $scope.zoomIn = function(){
        Height  *=1.1;
        Width *=1.1;
    };
    $scope.zoomOut = function(){
        Height  /=1.1;
        Width /=1.1;
    };
    $scope.isLoadingVisibile = function(){
        return false;
    };


    // apiService.get('ddsmap/layerstyle/'+$scope.model.layerObj().server.id+'/'+$scope.model.mapLayer().options.layers, function (data) {
    //     console.log(data);
    //
    // },function (err, head) {
    //     console.log(err);
    //
    // });


    if(aSensorLegend.indexOf(oLegend.type)>-1 ){

        $scope.legendType = 'SENSOR';
        $scope.legendUrl=oLegend.palette

    }else if(oLegend.type == "ADVANCED"){
        $scope.legendType = 'ADVANCED';
        $scope.oLegend = oLegend;

    }else if ( aUrlLegend.indexOf(oLegend.type) >-1 ){
        $scope.legendType = 'FROMGEOSERVER';
        if(oLegend.hasOwnProperty('customUrl')){
            $scope.legendUrl = oLegend.customUrl;
        }else{
            $scope.legendUrl = oLegend.url + "?request=GetLegendGraphic&format=image/png&WIDTH=12&HEIGHT=12&LAYER=" + oLegend.layers + "&legend_options=fontAntiAliasing:true;fontSize:10&LEGEND_OPTIONS=forceRule:True";
        }

    }else if ( staticLegend.indexOf(oLegend.type) >-1 && oLegend.dynPalette && oLegend.dynPalette.haveDynamicPalette!= true) {

        $scope.legendType = 'FROMGEOSERVER';
        $scope.legendUrl = $window.location.origin+"/apps/dewetra2/"+oLegend.url;

        console.log($scope.legendUrl)

    }else if (oLegend.type == "DDS_CUSTOM_LEGEND") {

        $scope.legendType = 'FROMGEOSERVER';
        $scope.legendUrl = oLegend.url;

        console.log($scope.legendUrl)

    }else if(oLegend.dynPalette.haveDynamicPalette == true){
        // palette dinamica colori sicuramente restituiti dal server
        $scope.legendType = 'DYNAMIC_PALETTE';
        $scope.oLegend = oLegend;

    }else if(oLegend.dynPalette.haveDynamicPalette != true && oLegend.aPalette.length > 0){
        //colori restituiti dal server e no palette dinamica
        $scope.legendType = 'DYNAMIC_LEGEND';
        $scope.oLegend = oLegend;
    }else alert("legend not defined");

    try{
        if(oLayerManager.hasOwnProperty("layerTooltip")){
            $scope.layerInfo = oLayerManager.layerTooltip();
        }
    }catch (err){
        console.log(err);
    }

    //console.log($scope.legendType);

    $scope.labelFilter= function (item) {
        console.log(item);

        return true;
    }

    $scope.getWidth = function(){
        return Width.toString() + "px";
    };
    $scope.getHeight = function(){
        return Height.toString() + "px";
    };
    $scope.getMinWidth = function(){
        var minWidth = Width/3;
        return minWidth.toString() + "px";
    };


    //if (!angular.isDefined($scope.opacity)) {
    //    $scope.opacity = $scope.model.options.opacity * 100;
    //
    //}

    //$scope.$watch('opacity', function (item) {
    //    item /=100;
    //    $scope.model.setOpacity(item)
    //})
    //;

}]);


dewetraApp.controller("drawDialogController", ['$scope', 'iconService', '$window', 'apiService',function ($scope, iconService, $window, apiService) {
    var targetLayer = $scope.model.layer;
    var layer = targetLayer;
    $scope.layerColor="#ff0000";
    $scope.extColor="#ff0000";
    $scope.opacity = 0.1;

    $scope.changeColor = function () {
      layer.setStyle({
          fillColor:$scope.layerColor,
          color:$scope.extColor,
          opacity:$scope.opacity,
          fillOpacity:$scope.opacity
      })
    };

}]);
