/**
 * Created by doy on 24/06/15.
 */



dewetraApp.controller("mapToolsController", ['$scope', '$rootScope', 'mapService', '$uibModal', 'reportService', '$sce', 'dialogService', '$window',function ($scope, $rootScope, mapService, $uibModal, reportService, $sce, dialogService, $window) {


    function init() {
        $scope.currentDewetra2ActiveTool = null;
        $rootScope.dewetra2LayersInfo = null


    }

    $rootScope.$watch("disableInfoTool",function () {
       if ($rootScope.disableInfoTool) $scope.setCurrentTool('info');
        $rootScope.disableInfoTool = false;
    });

    $rootScope.trustSrc = function(src) {
        var trustAsResourceUrl = $sce.trustAsResourceUrl(src);
        return trustAsResourceUrl;
    }


    function parseInfo(layer, data) {

        var ret = {
            layerName: (layer)?layer.name:"Background Layer",
            properties : []
        };

        if (data.features && data.features.length > 0) {
            data.features.forEach(function (f) {
                if (!f.geometry && 'GRAY_INDEX' in f.properties) {
                    ret.properties.push({name: 'value', 'value': f.properties.GRAY_INDEX.toFixed(2)})
                } else {
                    for (p in f.properties) {
                        ret.properties.push({name: p, 'value': f.properties[p]})
                    }
                }
            })
        }

        return ret;
    }



    function onLayerInfo(layer, data, url) {

        var manager = mapService.oLayerList.getManagerByMapLayer(layer);

        if (manager && manager.mapLayer().options.opacity > 0){
            var parsedData = (manager.parseInfo) ? manager.parseInfo(data, url) : parseInfo(manager.layerObj(), data);
        }else{
            // var parsedData = parseInfo(null, data)
        }

        //add the parsed datas to global info dataset
        if (parsedData) {
            if (!$rootScope.dewetra2LayersInfo) $rootScope.dewetra2LayersInfo = [];
            $rootScope.dewetra2LayersInfo.push(parsedData)
        }
    }

    $scope.isTimeSeriesEnabled = function() {
        if(mapService.oLayerList.aDraggable.length < 1) return false

        let filtered = mapService.oLayerList.aDraggable.filter(oManager => {
            return oManager.hasOwnProperty('punctualSerie')
        })

        return (filtered.length > 0)

    }

    $scope.isAreaSeriesEnabled = function() {
        if(mapService.oLayerList.aDraggable.length < 1) return false

        let filtered = mapService.oLayerList.aDraggable.filter(oManager => {
            return (oManager.hasOwnProperty('areaSerie') )
            // return (oManager.hasOwnProperty('areaSerie') && oManager.layerObj().dataid.indexOf('RISICO') >-1)
        })

        return (filtered.length > 0)

    }

    function computeDistance() {
        //TODO
        console.log(lastMeasure);
        console.log("compute distance")
    }

    function computeArea() {
        //TODO
        console.log("compute area")
    }

    function buildScenario() {
        //TODO
        console.log("compute scenario")
    }

    $scope.setCurrentTool = function(tool) {
        $rootScope.dewetra2LayersInfo = null;
        $scope.currentDewetra2ActiveTool = $scope.currentDewetra2ActiveTool == tool ? null : tool;

        mapService.setInfo($scope.currentDewetra2ActiveTool == 'info', onLayerInfo);
        //mapService.setLineDrawer($scope.currentDewetra2ActiveTool == 'distance', computeDistance);
        //mapService.setPolygonDrawer($scope.currentDewetra2ActiveTool == 'area', computeArea);
        //mapService.setPolygonDrawer($scope.currentDewetra2ActiveTool == 'scenario', buildScenario);
    }


    $scope.openToExternalPopUp = function(link){
        console.log(link);
        $window.open(link, '_blank', 'location=no,height=800,width=600,scrollbars=yes,status=no,menubar=no')
    };

    $scope.print = function () {


        // html2canvas(document.querySelector('#map'),{
        //     imageTimeout:300000,
        // }).then(function(canvas) {
        //     console.log(canvas)
        //     saveAs(canvas.toDataURL(), "print.png")
        // });
        //
        // return

        var layerPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/map_print.html',
            controller: "mapPrintController",
            size: "lg",
            resolve: {
                params: function() {
                    return {
                        mapService: null
                    }
                }
            }
        });

        layerPropModal.result.then(function (obj) {

        }, function () {
            console.log("CANCEL")
        });

    };



    //REPORT

    $scope.reportEnabled = true;

    $scope.createNewReport = function () {
        reportService.initializeReport(function (data) {
            console.log("New report created : "+data);
        });
    }

    $scope.sendToReport = function () {
        reportService.sendToReport(function (data) {
            console.log("New map added to report : "+data); //id of image on server
            //do input a server di contruire le immagini per dare sensazione di immediatezza quando scarico pptx o docx
            reportService.buildReport(function (data) {
                // report service send array of id image
                console.log("building image for Report");
                console.log(data);//obj.png=[url_image1,url_image2]
            })
        })

    }
    $scope.openReportModal = function () {

        var reportPropModal = $uibModal.open({
            templateUrl: 'apps/dewetra2/views/reportView.html',
            controller: "reportPrintController",
            size: "lg",
            resolve: {
                params: function() {
                    return {
                        mapService: null
                    }
                }
            }
        });

        reportPropModal.result.then(function (obj) {

        }, function () {
            console.log("CANCEL")
        });
    }
    // REPORT END

    $scope.shareSelected = function () {

    };
    $scope.addDrawControl = function () {

        $scope.editableLayers = mapService.addDrawControl();

        var map =mapService.getMap();


        map.on(L.Draw.Event.CREATED, function (e) {
            console.log(e)
            $scope.editableLayers.addLayer(e.layer);

            // e.layer.bindPopup("SELECT color insert text").openPopup()
            dialogService.open(e.layer._leaflet_id, 'drawDialog.html', {legend:{},manager:{}});

        });

        // map.on(L.Draw.Event.CREATED, function (e) {
        //     // var type = e.layerType,
        //     //     layer = e.layer;
        //     //
        //     // if (type === 'marker') {
        //     //     layer.bindPopup('A popup!');
        //     // }
        //     //
        //     // $scope.editableLayers.addLayer(layer);
        // });
    };

    $scope.removeDrawControl = function () {
        mapService.removeDrawControl();
        $scope.editableLayers.clearLayers()
    };


    init();

}]);
