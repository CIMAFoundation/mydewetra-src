/**
 * Created by Anto on 01/08/17.
 */

dewetraApp.controller('geocradleSoilAnalysisChartController',['$scope', '$uibModal', '$uibModalInstance', '$translate', 'sampleInfo', 'menuService', 'serieService','_', '$timeout', '$rootScope', function($scope, $uibModal, $uibModalInstance, $translate, sampleInfo, menuService, serieService,_, $timeout, $rootScope) {


    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    })

    var chartManager = {
        'soilSpectraChart' : showSoilSpectraChart,
        'chemicalAnalysisChart' : null          // showChemicalAnalysisChart    ORG!!!
    };

    addDownloadChartOption();

    addClassToDirective = function () {

        //aggiungo questa classe per customizzare solo i grafici sensori
        //console.log("test")
        var result = document.getElementsByClassName("modal-dialog");
        var wrappedResult = angular.element(result);
        //console.log(wrappedResult)
        wrappedResult.addClass("customModal2")

    }



    $scope.unit_of_measure = {
        N:"%",
        NO3:"ppm",
        OM:"%",
        OC:"%",
        CEC:"%",
        CaCO3:"%",
        soil_moisture:"%",
        silt_fraction:"%",
        clay_fraction:"%",
        sand_fraction:"%",
        EC:"μ/S"
    }

    $scope.chart = null;

    $scope.chartType = null;

    $scope.samplesData = {};

    loadSoilSamplesData(sampleInfo);

    $scope.reloadButton = {

        enabled : false,
        reload : function() {

            //for (var i = 0; i < $scope.samplesData.length; i++) {
            //
            //    if ($scope.samplesData[i].active) {
            //
            //        showChart($scope.samplesData[i]);
            //        return;
            //
            //    }
            //
            //}

        }

    };

    $scope.sampleDataChanged = function(samplesData) {

        toggleData(samplesData.type);

        showChart(samplesData);

    };

    $scope.closePopup = function() {

        $uibModalInstance.close();

    };

    $scope.formatValue = function(v) {

        return ((v < 0)? 'NA' : parseFloat(v).toFixed(2));

    };


    function loadSoilSamplesData(info) {

        //aggiungo classe per estendere i modal a schermo pieno
        $timeout(addClassToDirective, 100);

        serieService.getSeriesDirect(info.serverId, info.seriesId, info.sampleData.s_id, menuService.getDateFromUTCSecond(), menuService.getDateToUTCSecond(),

            function(data) {

                if (data.length == 0) {
                    alert($translate.instant('UNAVAILABLE_DATA'));
                    return;
                }

                var sd;

                data.forEach(function(s) {

                    sd = $scope.samplesData[s.type];
                    if (!sd) {
                        sd = {
                              's_id': info.sampleData.s_id,
                              'date': info.sampleData.date,
                              'type' : s.type,
                              'data' : s
                        };
                        $scope.samplesData[s.type] = sd;
                    }

                });

                var type = data[1].type;

                var sampleData = $scope.samplesData[type];

                toggleData(type);

                $scope.chartTitle = '"'+ sampleData.data.title + '": ' + info.sampleData.s_id;

                showChart(sampleData);

            },
            function(data) {

                alert($translate.instant('ERROR_LOADING_DATA') + ': ' + data.error_message);

            });

    }

    function showChart(sampleData) {

        if (!chartManager.hasOwnProperty(sampleData.type)) {

            alert($translate.instant('CHART_NOT_AVAILABLE'));
            return;

        }

        if (chartManager[sampleData.type] == null) return;

        $scope.chartSubTitle = $translate.instant('DATE') + ': ' + sampleInfo.sampleData.date;

        setTimeout(function() {

            $scope.chart = chartManager[sampleData.type](sampleData, menuService.oChartSize.m_iFloodProofsChartHeight(), $translate, null);

        }, 0);

    }

    function toggleData(type) {

        $scope.chartType = type;

        for (var key in $scope.samplesData) {

            // skip loop if the property is from prototype
            if (!$scope.samplesData.hasOwnProperty(key)) continue;

            $scope.samplesData[key].active = ($scope.samplesData[key].type === type);

        }

    }

    $scope.chartTitleFormatter = function(descr) {
        return descr.toUpperCase().trim().replace(/ /g,"_");
    }

    $scope.downloadChemData = function(data) {

        var csv = $translate.instant('CHEMICAL_PARAM') + ';' + $translate.instant('PARAM_VALUE') + '\n';

        for (var i = 0; i < data.data.categories.length; i++) {
            csv +=  (data.data.categories[i] + ';' + data.data.values[i] + '\n');
        }

        if (csv.length > 0) {

            var saving = document.createElement('a');
            saving.setAttribute('href', 'data:attachment/csv,' + encodeURIComponent(csv));
            saving.setAttribute('download', data.s_id + '-' + sampleInfo.sampleData.date + '.csv');

            // Append anchor to body.
            document.body.appendChild(saving);
            saving.click();

            // Remove anchor from body
            document.body.removeChild(saving);

        }

    }


}]);


