/**
 * Created by doy on 24/06/15.
 */

dewetraApp.controller("eventChooserController",['$scope', '$uibModal', 'mapService', 'layerService', 'serieService', 'menuService', 'tagService', function ($scope, $uibModal, mapService, layerService, serieService, menuService, tagService) {



    $scope.oConfig = {
        bDockedStyle:false,
        bGeoFilter:true
    }


    $scope.viewModeButton = function() {
        $scope.viewMode = !$scope.viewMode;
        tagService.setView($scope.viewMode);
    };
    function viewMode(){

        $scope.viewMode = tagService.getView()
    }

    function isLayerAccepted(layer) {
        for (var i=0; i<layer.tags.length; i++) {
            for (var j=0; j<$scope.tags.length; j++) {
                if (layer.tags[i].id == $scope.tags[j].id && $scope.tags[j].active) {
                    return true
                }
            }
        }
        return false
    }



    function buildFilteredLayers() {
        $scope.filteredLayers = [];

        $scope.layers.forEach(function (l) {
            if (isLayerAccepted(l)) $scope.filteredLayers.push(l)
        })

    }

    $scope.toggleDock = function(){
        console.log("dock: "+ $scope.oConfig.bDockedStyle);
        $scope.oConfig.bDockedStyle = !$scope.oConfig.bDockedStyle
        $scope.onDock($scope.oConfig.bDockedStyle)
    };

    function buildFolderView(layers){

        $scope.FolderView = {
            id: 'root', name: 'Layers', descr: 'Layers', choices: []
        };
        function filler(data, layer, group){
            //splitto nei punti
            var path = group.split('.');

            var choice = null;

            //costruisco i rami principali 1°livello
            for(var i=0; i<data.choices.length; i++) {
                if (data.choices[i].id == path[0]) {
                    choice = data.choices[i]
                }
            }
            //
            if (choice == null) {
                choice = {
                    id: path[0], name: path[0], descr: path[0], choices:[]
                };
                data.choices.push(choice)
            }

            if (path.length < 2) {
                choice.choices.push({
                    id: '__LAYER__', name:layer.name, descr: layer.descr, layer: layer
                })
            } else {
                filler(choice, layer, path.slice(1).join('.'))
            }
        }

        layers.forEach(function (l) {
            if (l.hierarchy) {
                filler($scope.FolderView, l, l.hierarchy)
            }
        })


    }




    function changeViewMode(){
        if ($scope.viewMode) {
            $scope.choices = $scope.FolderView.choices;
            $scope.path = [];
            $scope.path.push($scope.FolderView);
            $scope.getItemClass = $scope.getItemClass || function(choice) {return "";};
        }
    }

    $scope.$watch('viewMode', changeViewMode);

    $scope.choiceSelected = function(choice) {
        //se non ci sono dei layer in choices lo uso come path
        if (!$scope.hasLayer(choice)) {
            $scope.choices = choice.choices;
            //if is a new choice add to the path otherwise slice the path
            var i = 0;
            for(i=0; i<$scope.path.length; i++) {
                if ($scope.path[i].id == choice.id) {
                    break;
                }
            }
            if (i<$scope.path.length) {
                $scope.path = $scope.path.slice(0,i+1);
            } else {
                $scope.path.push(choice);
            }

        } else {
            //se ci sono dei layer in choices popolo la seconda vista
            $scope.oChoiceConfig.choosedLayers = choice.choices;
        }
    };




    $scope.loadLayer = function(choice){
        $scope.onLayerSelected(choice.layer, $scope.tags);
        console.log('SELEZIONATO LAYER ' + choice.layer.name)

    }

    $scope.hasChoices = function(choice) {
        return !(choice.layer && choice.layer != null);
    };

    $scope.hasLayer= function (choice) {
        return ((choice.choices[0].layer!=null && choice.choices[0].layer));
    }


    function init() {

        var oBound = null;
        if($scope.oConfig.bGeoFilter){
            oBound = mapService.getBounds()
        }
        //struttura per layer
        $scope.oChoiceConfig= {
            choosedLayers :[]
        };

        $scope.filteredLayers = [];
        if ($scope.menu.loadLayers) {
            $scope.menu.loadLayers(oBound, function (data) {

                $scope.tags = tagService.checkTags(data.tags);
                $scope.layers = data.objects;
                buildFilteredLayers();
                //folderView
                buildFolderView(data.objects);
                // console($scope.FolderView)
                //update folder view when menu change
                changeViewMode();
                //modalita folder attiva?
                viewMode();
                //$scope.pagination.totalPages = Math.floor($scope.layers.length/ $scope.pagination.limit)+1;
            })
        }

        $scope.filterLayerString = '';

    }


    $scope.folderViewLayerFilter = function (choice) {
        if (choice.layer) return false
        return true;
    }

    $scope.folderViewFolderFilter = function (choice) {
        if (choice.layer) return true
        return false;
    }

    $scope.close = function () {
        $scope.oConfig.bDockedStyle = false
        $scope.onDock($scope.oConfig.bDockedStyle)
        $scope.onClose()
    };

    lastSelectionOfTags = function(aOldTags, aTags){

    };
    
    
    $scope.layerIcon = function (obj) {
        // console.log(obj)
        if(obj.layer.icon && obj.layer.icon.length >0){
            return "i-"+obj.layer.icon;
        }else{
            return "i-default i-"+obj.layer.icon;
        }
        // "i-default i-{{obj}}"
    };
    
    $scope.folderIcon = function(choice){
        if($scope.hasChoices(choice)){
            return 'fa-folder-open'
        }else return 'i-default i-'+choice.layer.id

    };
    $scope.isCimaLayer = function(layer){
        //console.log(layer)
        var isCima = "";
        var n = layer.server.url.indexOf("cima");
        n > -1 && layer.type.code == "static" ? isCima = "cimaSticker" : isCima = "";
        return isCima
    };
    $scope.toggleTags = function(tag){

        if (!tag.active) tag.active = true;
        else tag.active = false;

        tagService.toggleTag(tag);
        buildFilteredLayers()
    };


    $scope.$watch('oConfig.bGeoFilter',function () {
        if (count>0){
            init()
        }else{
            count++
        }

    });


    var count  = 0;


    $scope.$watch('menu', init)



}]);
