/**
 * Created by Dario Rubado on 24/06/15.
 */


dewetraApp.controller("layerListController",['$scope', '$rootScope', '$uibModal', 'mapService', 'layerService', 'serieService', 'dialogService', '$translate', '$interval', '_','$window', 'menuService', '$timeout','printService', function ($scope, $rootScope, $uibModal, mapService, layerService, serieService, dialogService, $translate, $interval, _,$window, menuService, $timeout,printService) {


    $scope.config = {
        haveDownloadDisabled: false
    }

    function init() {
        if($scope.debug)console.log("layerlist init");
        //mi registro alla callback menuservice onDateToChange
        menuService.setLayerUpdateOnDateChanged(onDateChanged);
        $scope.start = 0;

        $scope.debug = menuService.debug;


    }

    function checkPropertiesInUserResource(prop) {
        //Dw2CfgCanDownloadLayer
        if($rootScope && $rootScope.userResources){
            if(Array.isArray($rootScope.userResources)){
                let downloadResource = $rootScope.userResources.filter(r => r.resource == prop);
                $scope.config.haveDownloadDisabled = (downloadResource.length == 1 && downloadResource[0].value && downloadResource[0].value == 'false');
            }
        }
    }



    function onDateChanged(){
        if ($scope.aLayerList.aDraggable){
            if ($scope.aLayerList.aDraggable.length > 0){
                $scope.aLayerList.aDraggable.forEach(function (oManager, index, array) {
                    if (oManager.onDateChange) {
                        var p = $timeout(function () {
                            oManager.onDateChange(function(){
                                $scope.aLayerList.updateDraggableLayer(oManager, index)
                            })
                        }, 300* index)
                    }
                })
            }
        }
        if ($scope.aLayerList.aUndraggable){
            if ($scope.aLayerList.aUndraggable.length > 0){
                $scope.aLayerList.aUndraggable.forEach(function (oManager,  index, array) {
                    if (oManager.onDateChange) {
                        var p = $timeout(function () {
                            oManager.onDateChange(function(){
                                $scope.aLayerList.updateUndraggableLayer(oManager, index)
                            })
                        }, 300 * index)
                    }
                })
            }
        }
    }

    //se cambio hat
    $rootScope.$on(acSessionChangedEvent, function(event, session) {

        $scope.aLayerList.init()

    });

    var modalInstance= null;

    $scope.loadCaptionDataLog = (oManager) => {

        modalInstance = $uibModal.open({
            animation: true,
            component: 'datalogcaption',
            //component: 'thresholdsEditor',
            size: 'sm',
            backdrop:'static',
            // size: 'lg',
            resolve: {
                oManager: function () {
                    return oManager
                }
            }
        });

        modalInstance.result.then(function (obj) {

            console.log('modal-component dismissed at: ' + new Date());
            modalInstance = null;

        }, function () {
            console.log('modal-component dismissed at: ' + new Date());
            modalInstance = null;
        });

    }



    $scope.dragControlListeners = {
        accept: function (sourceItemHandleScope, destSortableScope) {return true;},
            itemMoved: function (event) {
                if($scope.debug)console.log("itemMoved"+event);
            },
            orderChanged: function (event) {
                $scope.aLayerList.orderByDrag()
            },
        containment: '#list',//optional param.
        clone: false //optional param for clone feature.
    };

    $scope.reorderLayerListPromise = null;

    $scope.reorderLayerListPromise = $interval(function () {
        if($scope.aLayerList.aDraggable.length > 1){
            $scope.aLayerList.orderByDrag()
        }

    },5000);



    $scope.layerClass = function (oManager) {

        try {
            if(oManager.mapLayer().options.opacity != null){
                if(oManager.mapLayer().options.opacity == 0 ) {
                    return "trasparente";
                }
            }else if (oManager.isVisible){
                try{
                    if (!oManager.isVisible()){
                        return "trasparente";
                    }
                }catch(err){
                    if($scope.debug)console.log(err)
                }
            }
        }catch (e) {
            //console.log(e)
        }



    };

    $scope.refreshLayer = function (oManager) {
        if(oManager.mapLayer().options.opacity == 0 ) {
            //if($scope.debug)console.log("trasparente");
            return "trasparente";
        }
    };

    /**
     * get a string indicating the information of the layer
     * @param layer
     * @returns {string}
     */
    $scope.layerDateRef = function(oManager){

        try{
            oManager.item()
        }catch(err){
            return oManager.typeDescr()
        }
        var item = oManager.item();
        var aSplittedDate =  item.id.split(';');
        if (aSplittedDate.length >0){
            var dateRun = oManager.dateRun();
            var formattedDateRun = dateRun.format("YYYY/MM/DD HH:mm");
            var dateForecast = oManager.dateForecast();
            if(dateForecast > 0 ){
                var string = formattedDateRun + " prog+ " + dateForecast + " H";
                return string
            }

            var string = formattedDateRun;
            return string;
        }else {
            return "date Error"
        }
        var formattedDate = dateRef.format("YYYY/MM/DD HH:mm");
        return formattedDate

    };
    /**
     * getFirstLine comment line directly from manager
     * @param oManager
     */
    $scope.layerDateRefFromManager = function(oManager){

        try{
            return oManager.dateLine();
        }catch (err){
            try{
                //oManager.item();
                return oManager.dateRefFormatted();

            }catch(err){
                return oManager.typeDescr();

            }
        }


    };
    /**
     * Gets a string indicating the delay from oReferenceDate vs Now
     * @param layer
     * @returns {string}
     */

    $scope.layerDelay = function (oManager) {

        if (oManager.hasOwnProperty("thirdLine")){
            return oManager.thirdLine();
        }

        var layerManagerObj = oManager;
        try{
            var oReferenceDate = layerManagerObj.dateRef().utc().toDate()
        }catch(err){
            try{
                 return layerManagerObj.delayLine();
            }catch(err){
                return layerManagerObj.descr()
            }


        }

        // Get Now
        var oDate = new Date();

        //if($scope.debug)console.log("Now  = " + oDate);
        //if($scope.debug)console.log("Ref  = " + oReferenceDate);

        // Compute time difference
        var iDifference = oDate.getTime()-oReferenceDate.getTime();

        // How it is in minutes?
        var iMinutes = 1000*60;

        var iDeltaMinutes = Math.round(iDifference/iMinutes);

        var sTimeDelta = "";

        if (isNaN(iDeltaMinutes)){
            return layerManagerObj.descr()
        }

        if (iDeltaMinutes>0){
            if (iDeltaMinutes<60 ) {
                // Less then 1h
                sTimeDelta +=$translate.instant("pre_min_fa")+ " " + iDeltaMinutes +' '+ $translate.instant("min_fa");
            }
            else if (iDeltaMinutes< 60*24) {
                // Less then 1d
                var iDeltaHours =  Math.round(iDeltaMinutes/60);
                sTimeDelta +=$translate.instant("pre_ore_fa")+ " " + iDeltaHours +' '+ $translate.instant("ore_fa");
            }
            else {
                // More than 1d
                var iDeltaDays =  Math.round(iDeltaMinutes/(60*24));
                sTimeDelta +=$translate.instant("pre_giorni_fa")+ " " + iDeltaDays +' '+ $translate.instant("giorni_fa");
            }
        }else{
            if (iDeltaMinutes> -60 ) {
                // Less then 1h
                sTimeDelta += $translate.instant("Fra")+': '+Math.abs(iDeltaMinutes)+' '+ $translate.instant("Minuti");
            }
            else if (iDeltaMinutes > -60*24) {
                // Less then 1d
                var iDeltaHours =  Math.round(iDeltaMinutes/60);
                sTimeDelta += $translate.instant("Fra")+': '+Math.abs(iDeltaHours)+' '+ $translate.instant("Ore");
            }
            else {
                // More than 1d
                var iDeltaDays =  Math.round(iDeltaMinutes/(60*24));
                sTimeDelta += $translate.instant("Fra")+': '+Math.abs(iDeltaDays)+' '+ $translate.instant("Giorni");
            }
        }


        return sTimeDelta;
    };
    $scope.layerMeta= function(oManager){
        var manager = oManager;
        if(manager.layerObj().metadataurl.length > 0){
            $window.open(manager.layerObj().metadataurl, "");
        }else if($scope.debug)console.log("No Metadata")

    };

    $scope.haveLayerMeta = function (oManager) {
        return (oManager.layerObj().metadataurl.length > 0)
    }

    //layer action start
    $scope.removeLayer= function(oManager){
        //tolgo layer
        var leafletid = oManager.mapLayer()._leaflet_id;
        //se esiste chiudo legenda
        $scope.aLayerList.removeLayer(oManager);
        try{
            dialogService.close(leafletid);
        } catch(err) {
            if($scope.debug)console.log(err);
        }
        //info Layer se è piu di uno rifaccio l'info layer altrimenti chiudo il pannello

        if($scope.aLayerList.aDraggable.length >0){
            if ($rootScope.disableInfoTool)mapService.renewLayerInfo();
        }else{
            $rootScope.disableInfoTool = false;
        }

    };

    $scope.zoomToLayer= function(oManager){
        mapService.zoomToLayer(oManager.mapLayer());
    };

    $scope.downloadLayer= function(oManager){

        var isDrought = false;

        if(oManager.layerObj){
            oManager.layerObj().tags.forEach(function(tag){
                if(tag.id == 63 && tag.descr.toUpperCase() == 'DROUGHT') isDrought = true;
            })
        }

        if (isDrought){
            var a = document.createElement('a');
            a.target = '_blank';
            // a.download = "dewetra_layer";
            // a.title = "dewetra_layer";
            a.href = 'http://bolivia.mydewetra.cimafoundation.org/sequia/productos/';
            a.click()
        }else {

            if (oManager.getDownloadUrl) {

                var extension =oManager.getDownloadUrl().split('.').pop();
                if (angular.isUndefined(extension)|| oManager.getDownloadUrl().indexOf('zip')>-1){
                    extension = 'zip';
                }
                var filename = oManager.name().toUpperCase().split(' ').join('_')+'.'+extension;


                printService.renameFileDownload({
                    filename:filename,
                    url:oManager.getDownloadUrl()
                },function (data) {

                    // var url = oManager.getDownloadUrl();
                    // if (url != null) {
                    // console.log(url);
                    var a = document.createElement('a');
                    //a.target = '_blank';
                    // a.download = "dewetra_layer";
                    // a.title = "dewetra_layer";
                    a.href = data.url;
                    console.log(a.href)
                    a.click()
                    // }
                })

            }
        }



    };


    $scope.haveDownloadIcon = function(oManager){

        checkPropertiesInUserResource("Dw2CfgCanDownloadLayer");

        return (!$scope.config.haveDownloadDisabled && oManager.getDownloadUrl)? true:false;
    };

    $scope.bringToFront = function (layer) {
        let index = $scope.aLayerList.indexOf(layer);
        if (index >=1){
            $scope.aLayerList.move(index, index-1)
        }
        mapService.orderByDrag($scope.aLayerList)

    };

    $scope.canMovie = function (oManager) {
        if(oManager.canMovie){
            return oManager.canMovie()
        }else return false;
    };
    $scope.canBackward = function (oManager) {
        if(oManager.canMovie()) {

            if(oManager.hasOwnProperty('canBackward')) {
                return oManager.canBackward()
            }else {

                if (oManager.infoAvaialability().reverse) {//se è un array di tempi contrario
                    if (oManager.infoAvaialability().index < oManager.infoAvaialability().length) {
                        return true//se index è minore della lunghezza posso andare indietro nel tempo ( avanti nell'array)
                    } else
                        return false//se index è uguale della lenght posso solo andare avanti nel tempo ( indietro nell'array)
                } else {//se è un array di tempi corretto
                    if (oManager.infoAvaialability().index > 0) {
                        return true
                    } else {
                        return false
                    }
                }
            }
        } else return false
    };
    $scope.canForward = function (oManager) {
        if(oManager.canMovie()) {

            if(oManager.hasOwnProperty('canForward')) {
                return oManager.canForward()
            }else {

                if (oManager.infoAvaialability().reverse) {//se è un array di tempi contrario
                    if (oManager.infoAvaialability().index > 0) {
                        //se maggiore di zeo posso andare avanti (avanti nella linea temporale indietro nell'array)
                        return true
                    } else return false//se è = 0 posso solo tornare indietro nella linea temporale (avanti nell'array)
                } else {//se è un array di tempi corretto
                    if (oManager.infoAvaialability().index < oManager.infoAvaialability().length) {
                        return true
                    } else {
                        return false
                    }
                }
            }
        } else return false
    };
    $scope.islist = function (attr) {
        return attr.type.toLowerCase() == 'list'
    };



    $scope.goForward = function (oManager, bValue) {
        if(bValue){
            if(oManager.infoAvaialability().reverse) {
                oManager.goBackward()
            }else{
                oManager.goForward()
            }
        }
    };
    $scope.goBackward = function (oManager, bValue) {
        if(bValue){
            if(oManager.infoAvaialability().reverse) {
                oManager.goForward()
            }else{
                oManager.goBackward()
            }
        }
    };

    $scope.play = function(oManager){
        oManager.play($rootScope);
    }


    $scope.layerIcon = function (oManager) {

        if(oManager.layerObj().icon && oManager.layerObj().icon.length){
            return "i-"+oManager.layerObj().icon;
        }else{
            return "i-default i-"+oManager.layerObj().id;
        }

    };

    $scope.isCimaLayer = function (oManager) {
        if (oManager.layerObj().type&&oManager.layerObj().type.code == "static"){
            var n = oManager.mapLayer()._url.indexOf("cima");
            var isCima = (n > -1)? "cimaSticker" : "";
        }
        return isCima;
    };

    $scope.layerNameForLayerList = function (oManager) {
        if (oManager && oManager.name) return oManager.name();
        return 'unknown layer'
    };

    $scope.layerTooltipForLayerList = function (oManager) {
        if (oManager && oManager.item) return oManager.item().description;
        return ''
    };

    $scope.isSendToSitEnabledForTheHat = () => {

        try {
            if (window.app.config.sendToCloud && (window.app.config.sendToCloud.authHat.indexOf($rootScope.acSession.hat.descr)>-1)) {
                return true;
            }else {
                return false
            };
        }catch (e) {
            return false
        }

    }

    $scope.sendToSit = function (oManager) {
        oManager.sendToSit(function (data) {
            if($scope.debug)console.log(data);
            alert("Data saved in Geoserver workspace permanent Layer Id:"+data);

        })
    }

    $scope.additionalButtonAction = function (oManager, sAction) {
        oManager[sAction]();
    }

    $scope.arrayOfLegend = [];

    $scope.dialogLengend = function(oManager){

        var legend = oManager.legend(function (data) {
            dialogService.open(oManager.mapLayer()._leaflet_id, 'dialog2.html', {legend:data,manager:oManager});
        });

        if(legend)dialogService.open(oManager.mapLayer()._leaflet_id, 'dialog2.html', {legend:legend,manager:oManager});

    };

    $scope.showProperties = function(oManager){
        if (oManager && oManager.showProps) oManager.showProps(function () {
            mapService.oLayerList.updateLayer(oManager, null);
            //mapService.setlayerManager(oManager.mapLayer(), oManager);
        })
    };

    $scope.draggable= function(oManager){

        try{
            return oManager.draggable();
        }catch(err){
            if($scope.debug)console.log(err)
        }
    };
    $scope.fixed= function(oManager) {

        try{
            return oManager.draggable();
        }catch(err){
            if($scope.debug)console.log(err)
        }
    };
    //$scope.onLayerMouseOverOutTooltip.mouseOver()
    $scope.mouseEnter = function(oManager){
        $scope.onLayerMouseOverOutTooltip.mouseOver('layer', oManager)
    };
    $scope.mouseLeave = function(oManager){
        $scope.onLayerMouseOverOutTooltip.mouseOut('layer', oManager)
    };
    //REFRESH

    $scope.canRefresh = function (oManager) {

        if (oManager.refreshable && oManager.refreshable()) {
            return true
        }else return false
    };
    $scope.refreshLayer = function (oManager) {

        if (oManager.refreshable()) {
            oManager.refresh(function(){
                mapService.oLayerList.updateLayer(oManager);
            })
        }
    };
    var aPromise = [];



    //REFRESH END
    refresh = function(){
        if ($scope.aLayerList.aDraggable){
            if ($scope.aLayerList.aDraggable.length > 0){
                $scope.aLayerList.aDraggable.forEach(function (oManager, index, array) {
                    if (oManager.refreshable()) {
                        oManager.refresh(function(){
                            $scope.aLayerList.updateDraggableLayer(oManager, index)
                        })
                    }
                })
            }
        }
        if ($scope.aLayerList.aUndraggable){
            if ($scope.aLayerList.aUndraggable.length > 0){
                $scope.aLayerList.aUndraggable.forEach(function (oManager, index , array) {
                    if (oManager.refresh) {
                        oManager.refresh(function(){
                            $scope.aLayerList.updateUndraggableLayer(oManager, index)
                        })
                    }
                })
            }
        }
    };
    var aPromise2 = $interval(refresh, 600000);
    init()

}]);

dewetraApp.controller("listItemController",['$scope', '$uibModal', 'mapService', 'layerService', 'serieService', 'dialogService', function ($scope, $uibModal, mapService, layerService, serieService, dialogService) {
    function init(){
        if($scope.debug)console.log("init listItemController")

        //initialiaze value
        try {
            if ($scope.$parent.oManager.mapLayer().options.opacity) $scope.opacity =$scope.$parent.oManager.mapLayer().options.opacity;
            if ($scope.$parent.oManager.hasOwnProperty("getOpacity")) $scope.opacity =$scope.$parent.oManager.getOpacity();
        }catch (e) {
            console.log(e)
        }



        $scope.setOpacity = function () {
            if($scope.debug)console.log($scope.opacity);

            try{

                $scope.$parent.oManager.mapLayer().setOpacity($scope.opacity)
            }
            catch(err){

                if ($scope.$parent.oManager.setOpacity && $scope.$parent.oManager.getOpacity() != $scope.opacity){
                    try {
                        $scope.$parent.oManager.setOpacity($scope.opacity)
                    }
                    catch(err){
                        if($scope.debug)console.log(err)
                    }
                }
            }
        }
    }

    $scope.showFunc = function(){
        $scope.show = !$scope.show;
    };

    $scope.hideLayerToggle =function(oManager){

        $scope.opacity = mapService.hideLayerToggle(oManager);
        $scope.opacity = $scope.$parent.oManager.mapLayer().options.opacity;

    };

    init();
}]);
