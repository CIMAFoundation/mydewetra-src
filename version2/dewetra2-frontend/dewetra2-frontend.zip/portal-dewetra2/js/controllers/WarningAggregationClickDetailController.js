/**
 * Created by Dario Rubado on 29/12/15.
 */

dewetraApp.controller('warningAggregationClickDetailController', ['$scope', '$uibModal', '$uibModalInstance', 'featureData', 'menuService', 'serieService', 'sentinelService', 'thresholdService',function($scope, $uibModal, $uibModalInstance, featureData, menuService, serieService, sentinelService, thresholdService) {

    console.log(featureData);
    $scope.oConfig={
        sType : featureData.type,//WARNING_PLUVIO etc..
        sOrder : null,
        bReverseOrder : false,
        sAggregationType :featureData.aggregationType, //REGIONE etc..
        threshold: (featureData.threshold)?featureData.threshold:null
    };



    $scope.oDataBuilder={
        WARNING_PLUVIO:{
            buildData: function(properties){

                //definisco la stringa da cercare
                var stringValori = "v_";
                var stringSoglie = "e_";
                //definisco array
                var aValori = [];
                var aThresholds = [];
                //presettio tutti i valori
                properties[0] = -9999;
                properties[3600] = -9999;
                properties[10800] = -9999;
                properties[21600] = -9999;
                properties[43200] = -9999;
                properties[64800] = -9999;
                properties[86400] = -9999;
                properties[129600] = -9999;
                //tolgo gli spazi e metto lower case
                properties.stationname = properties.stationname.trim().toLowerCase();

                //cerco le soglie
                for(var prop in properties){
                    if (stringStartsWith(prop, stringSoglie)) {
                        var aThreshold = prop.split("_");

                        var oThreshold = $scope.oConfig.threshold[aThreshold[1]];
                        oThreshold.level = parseInt(aThreshold[2]);
                        if(angular.isUndefined(aThresholds[oThreshold.period])) aThresholds[oThreshold.period] = [];
                        aThresholds[oThreshold.period].push(oThreshold);
                    }
                }

                //cerco i valori nella proprietà
                for (var prop in properties) {
                    if (stringStartsWith(prop, stringValori)) {
                        var aValore = prop.split("_");
                        var value =properties[prop];
                        var ValueRounded = Math.round(properties[prop] * 10) / 10;

                        var oValore = {
                            timestamp: parseInt(aValore[1]),
                            period: parseInt(aValore[2]),
                            valore: ValueRounded,
                            color:(parseInt(value) == 0)?featureData.palette[-1]:featureData.palette[0],
                            threshold :aThresholds[parseInt(aValore[2])]
                        };

                        //setto una proprieta nella feature dove period è la cumulata
                        properties[oValore.period] = ValueRounded;

                        //se soglie
                        if(oValore.threshold && oValore.threshold.length > 0){
                            properties[oValore.period+"_color"] = featureData.palette[_.max(oValore.threshold, function (thr) {
                                return thr.level;
                            }).level];
                            //oggetto soglia superata max
                            properties[oValore.period+"_threshold"] = _.max(oValore.threshold, function (thr) {
                                return thr.level;
                            });
                            //tooltip thr_12 : valore
                            properties[oValore.period+'_tooltip']=properties[oValore.period+'_threshold'].name+ ' : '+properties[oValore.period+'_threshold'].value;

                        }else{
                            //senza soglie
                            properties[oValore.period+"_color"] = (parseFloat(value) > 0)?featureData.palette[0]:featureData.palette[-1];
                            properties[oValore.period+'_tooltip']="";
                        }



                        aValori.push(oValore);
                    }

                }



                //se non ci sono valori non metto l'ultimo tempo di aggiornamento
                if (aValori.length == 0 ){
                    properties["lastUpdateTime"] = "-"
                }else if (aValori.length > 0){
                    //se ci sono valori prendo come riferimento il tempo piu recente
                    var oMostRecentValue = _.max(aValori, function (valore) {
                        return valore.timestamp;
                    });
                    //setto il tempo
                    properties["lastUpdateTime"] = moment.unix(oMostRecentValue.timestamp).utc().format("DD/MM/YYYY HH:mm");

                    var difference = moment.duration(moment(menuService.getDateToUTCSecond()*1000).diff(moment.unix(oMostRecentValue.timestamp)));
                    // properties["delayTime"] = moment(menuService.getUtcServerDateInMillisecond()).diff(moment.unix(oMostRecentValue.timestamp))
                    properties["delayTime"] = parseInt(difference.asMinutes()).toString()+ " minuti ritardo";
                }
                //setto il colore della riga
                // properties["color"] = featureData.palette[properties.warning_palette];

                return properties
            }
        },
        WARNING_THERMO : {
            buildData : function (properties) {
                //definisco la stringa da cercare
                var stringValori = "v_";
                //definisco array
                var aValori = [];
                //presettio tutti i valori
                properties[0] = -9999;
                properties[3600] = -9999;
                properties[10800] = -9999;
                properties[21600] = -9999;
                properties[43200] = -9999;
                properties[86400] = -9999;
                //tolgo gli spazi e metto lower case
                properties.stationname = properties.stationname.trim().toLowerCase();

                //cerco i valori nella proprietà
                for (var prop in properties) {
                    if (stringStartsWith(prop, stringValori)) {
                        var aValore = prop.split("_");

                        var value = Math.round(properties[prop] * 10) / 10;
                        var oValore = {
                            timestamp: parseInt(aValore[1]),
                            period: parseInt(aValore[2]),
                            valore: value
                        };
                        aValori.push(oValore);
                        //setto una proprieta nella feature dove period è la cumulata
                        properties[oValore.period] = value
                    }
                }

                //se non ci sono valori non metto l'ultimo tempo di aggiornamento
                if (aValori.length == 0 ){
                    properties["lastUpdateTime"] = "-"
                }else{
                    //se ci sono valori prendo come riferimento il tempo piu recente
                    var oMostRecentValue = _.max(aValori, function (valore) {
                        return valore.timestamp;
                    });
                    //setto il tempo
                    properties["lastUpdateTime"] = moment.unix(oMostRecentValue.timestamp).utc().format("DD/MM/YYYY HH:mm");

                }
                //setto il colore della riga
                properties["color"] = featureData.palette[properties.warning_palette];
                return properties
            }
        },
        WARNING_HYDRO : {
            buildData : function (properties) {
                //definisco la stringa da cercare
                var stringValori = "v_";
                //definisco array
                var aValori = [];
                //presettio tutti i valori
                properties[0] = -9999;
                properties[3600] = -9999;
                properties[10800] = -9999;
                properties[21600] = -9999;
                properties[43200] = -9999;
                properties[86400] = -9999;
                //tolgo gli spazi e metto lower case
                properties.stationname = properties.stationname.trim().toLowerCase();

                //cerco i valori nella proprietà
                for (var prop in properties) {
                    if (stringStartsWith(prop, stringValori)) {
                        var aValore = prop.split("_");

                        var value = Math.round(properties[prop] * 10) / 10;
                        var oValore = {
                            timestamp: parseInt(aValore[1]),
                            period: parseInt(aValore[2]),
                            valore: value
                        };
                        aValori.push(oValore);
                        //setto una proprieta nella feature dove period è la cumulata
                        properties[oValore.period] = value
                    }
                }

                //se non ci sono valori non metto l'ultimo tempo di aggiornamento
                if (aValori.length == 0 ){
                    properties["lastUpdateTime"] = "-"
                }else{
                    //se ci sono valori prendo come riferimento il tempo piu recente
                    var oMostRecentValue = _.max(aValori, function (valore) {
                        return valore.timestamp;
                    });
                    //setto il tempo
                    properties["lastUpdateTime"] = moment.unix(oMostRecentValue.timestamp).utc().format("DD/MM/YYYY HH:mm");
                }
                //setto il colore della riga
                properties["color"] = featureData.palette[properties.warning_palette];
                return properties
            }
        }

    };
// WARNING PLUVIO function
    //ho dato nome specifico alla funzione in realta funziona per tutti i warning type
    function WARNING_PLUVIO_showRegion(){


        featureData.aModalData.forEach(function(obj){
            //obj.properties = buildData(obj.properties);
            obj.properties = $scope.oDataBuilder[$scope.oConfig.sType].buildData(obj.properties);
        });
        $scope.title = featureData.featureData.nome_reg;
        $scope.featureData = featureData.aModalData

    }

    function WARNING_PLUVIO_showDistrict(){


        featureData.aModalData.forEach(function(obj){
            obj.properties = $scope.oDataBuilder[$scope.oConfig.sType].buildData(obj.properties);
        });
        $scope.title = featureData.featureData.nome_pro;
        $scope.featureData = featureData.aModalData

    }

    function WARNING_PLUVIO_showMunic(){


        featureData.aModalData.forEach(function(obj){
            obj.properties = $scope.oDataBuilder[$scope.oConfig.sType].buildData(obj.properties);
        });
        $scope.title = featureData.featureData.nome_com;
        $scope.featureData = featureData.aModalData

    }



    function WARNING_PLUVIO_showAllertArea(){
        featureData.aModalData.forEach(function(obj){
            obj.properties = $scope.oDataBuilder[$scope.oConfig.sType].buildData(obj.properties);
        });
        $scope.title = featureData.featureData.nome_com;
        $scope.featureData = featureData.aModalData
    }

    function WARNING_PLUVIO_showBacini(){


        featureData.aModalData.forEach(function(obj){
            obj.properties = $scope.oDataBuilder[$scope.oConfig.sType].buildData(obj.properties);
        });
        $scope.title = featureData.featureData.nome_com;
        $scope.featureData = featureData.aModalData;
    }

// WARNING PLUVIO function END



    $scope.orderBy = function (data) {

};
    var oDictionary = {
        WARNING_PLUVIO: {
            REGIONE : WARNING_PLUVIO_showRegion,
            PROVINCE: WARNING_PLUVIO_showDistrict,
            COMUNI: WARNING_PLUVIO_showMunic,
            BACINI: WARNING_PLUVIO_showBacini,
            TOPOIETI : WARNING_PLUVIO_showMunic,
            AREEALLERTAMENTO: WARNING_PLUVIO_showAllertArea
        },
        WARNING_THERMO:{
            REGIONE : WARNING_PLUVIO_showRegion,
            PROVINCE: WARNING_PLUVIO_showDistrict,
            COMUNI: WARNING_PLUVIO_showMunic,
            BACINI: WARNING_PLUVIO_showBacini,
            AREEALLERTAMENTO: WARNING_PLUVIO_showAllertArea
        },
        WARNING_HYDRO:{
            REGIONE : WARNING_PLUVIO_showRegion,
            PROVINCE: WARNING_PLUVIO_showDistrict,
            COMUNI: WARNING_PLUVIO_showMunic,
            BACINI: WARNING_PLUVIO_showBacini,
            AREEALLERTAMENTO: WARNING_PLUVIO_showAllertArea
        }
    };
    //eseguo la funzione secondo la configurazione passata;
    if($scope.oConfig.sType && $scope.oConfig.sAggregationType){
        oDictionary[$scope.oConfig.sType][$scope.oConfig.sAggregationType]();
    } else console.log("Configuration settings error");
    $scope.closePopup = function() {

        $uibModalInstance.close();

    }
}]);
