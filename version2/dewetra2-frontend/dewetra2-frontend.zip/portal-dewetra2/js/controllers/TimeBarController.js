/**
 * Created by Dario Rubado on 29/06/15.
 */



dewetraApp.controller("TimeBarController",[ '$scope','$rootScope', '$uibModal', 'mapService', 'layerService', 'serieService', 'dialogService', 'menuService', 'audioService', '$timeout',function ($scope,$rootScope, $uibModal, mapService, layerService, serieService, dialogService, menuService, audioService, $timeout) {



    function init() {
        //console.log("time bar init");
        //se ci sono richieste fa girare i puntini di caricamento
        $rootScope.$watch('pendingRequests', function(){
            $scope.pendingRequests = $rootScope.pendingRequests
        })
    }

    $scope.isRealTime = function(){
        $scope.bIsRealTime = menuService.isRealTime();
    };


    $scope.bellClass = function () {
        var audio = audioService.isPlaying();
        if (audio){
            return 'faa-ring animated';
        }else {
            return ''
        }
    };

    $scope.isBell = function () {
        return audioService.isPlaying();
    };
    $scope.stopSound = function () {
        audioService.stopAudio()
    };

    menuService.setOnDateChanged(function () {

        $scope.dateFrom = menuService.getUTCDateFrom();
        $scope.dateTo = menuService.getUTCDateTo();

        $scope.isRealTime();
    });

    $scope.onDateFromSet = function (newDate, oldDate) {

        menuService.setDateFrom(newDate);

        $scope.dateFrom = menuService.getUTCDateFrom();//if date from is greater then date to this control re set the date

        $scope.isRealTime();
    };

    $scope.onDateToSet = function (oNewDate, oOldDate) {
        menuService.setDateTo(oNewDate);

        $scope.dateTo = menuService.getUTCDateTo();

        $scope.isRealTime();
    };
    $scope.onDateToSetToServer = function () {

        menuService.setNow();

        $scope.isRealTime();
    };

    $scope.DateTimeConfig = window.app.config.timeBarConfig;

    init()

}]);
