/**
 * Created by Dario Rubado on 18/12/15.
 */

dewetraApp.controller('sensorChartController',['$scope', '$uibModal', '$uibModalInstance', '$translate', 'sensorData', 'menuService', 'serieService', 'sentinelService', 'thresholdService','_', '$timeout', '$rootScope', function($scope, $uibModal, $uibModalInstance, $translate, sensorData, menuService, serieService, sentinelService, thresholdService,_, $timeout, $rootScope) {


    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    });

    console.log("init sensorChartController");

    var chartManager = {
        2 : showRaingaugeChart,
        3 : showHydrometerChart,
        // 30 : showHydrometerQViewChart,// in dw2 dpc ask for index
        30 : showHydrometerVolumeChart,
        4 : showSnowDepthChart,
        5 : showThermometerChart,
        9 : showHygromometerChart,
        10 : showAnemometerChart,
        12 : showBarometerChart,
        13 : showRadiometerChart,
        60 : showHygromometerChart,
        90 : showHygromometerChart,
        98 : showFuelMoistureChart
        // 1002 : showTurbinateChart

    };
    var chartSeries = {
        2 : 'all.sensor.rainfall',
        3 : 'all.sensor.hydrometers',
        // 30 : 'all.sensor.hydrometers',
        30 : 'italy.sensor.hydrometers.flow',
        4 : 'all.sensor.snow',
        5 : 'all.sensor.thermometers',
        9 : 'all.sensor.hygrometers',
        10 : 'all.sensor.winddirection',
        11 : 'all.sensor.windspeed',
        12 : 'all.sensor.barometer',
        13 : 'all.sensor.radiometer',
        // 30 : 'all.sensor.hydrometers',
        60 : 'all.sensor.soilthermometers',
        90 : 'all.sensor.soilmosture',
        98 : 'all.sensor.fuel_moisture',
        1002 : 'all.sensor.turbinate'
    };

    if(sensorData.hasOwnProperty('ddsChartSerie')){
        chartSeries[sensorData.sensorClass] = sensorData.ddsChartSerie;
    }
    var ddsServerId = 1;
    if(sensorData.hasOwnProperty('ddsServerId')){
        ddsServerId = sensorData.ddsServerId;
    }

    $scope.configObj = {
        station: {},
    }

    try {
        if(window.app.config.hasOwnProperty('chart') && window.app.config.chart.hasOwnProperty('csvDownloadOptions') && window.app.config.chart.csvDownloadOptions == false ){
            console.log(" Csv exporting disabled from config");
        }else {
            addDownloadChartOption();
            console.log(" Csv exporting enabled from config");
        }
    } catch (e) {
        console.log(e);
    }


    // all.sensor.winddirection e all.sensor.windspeed
    $scope.currentChart = null;

    addClassToDirective = function () {
        //aggiungo questa classe per customizzare solo i grafici sensori
        // console.log("test")
        var result = document.getElementsByClassName("modal-dialog");
        var wrappedResult = angular.element(result);
        // console.log(wrappedResult)
        wrappedResult.addClass("customModal2")
    };

    $scope.date= new Date();

    $scope.warningAnalisys = {
        enabled : false
    };

    $scope.lineeSegnalatrici = {
        enabled : false
    };

    $scope.hourlyAccumulate = false;


    function genericYaxisExstreme (sensorInfo) {

        if ($scope.yAxisGenericExtremesPopover.edited){
            return{
                min: $scope.yAxisGenericExtremesPopover.min,
                max: $scope.yAxisGenericExtremesPopover.max,
                tickInterval: 5
            }
        }

        var max = 100;
        var min = 0;
        return{
            min: min,
            max: max,
        }
    }

    var yAxisExtremes ={

        2:function (sensorInfo) {

            //calcolo max e sum

            var max = getMax(sensorInfo.obs, 50);
            var sum = (sensorInfo.obs? sensorInfo.obs.reduce(function(pv, cv) {
                var total =  ((typeof pv == 'number'  )? pv : parseFloat(pv));
                if (cv != -9999 && cv != "-9999"){// prima non si teneva conto dei -9999
                    return total+ ((typeof cv == 'number')? cv : parseFloat(cv))
                }else return total;

            }, 0) : 0);

            sum = getMax([sum, max], 100);

            var cumh = ($scope.currentChart != null && $scope.currentChart.hasOwnProperty("maxCumHYAxis"))?$scope.currentChart.maxCumHYAxis():max;

            $scope.yAxisGaugeExtremesPopover.sum = sum;
            $scope.yAxisGaugeExtremesPopover.max = max;
            $scope.yAxisGaugeExtremesPopover.cumh = cumh;

            //se sho modificato gli assi passo quelli modificati, chiedere come vuole "autorange massimo"
            if ($scope.yAxisGaugeExtremesPopover.edited){
                return{
                    max:$scope.yAxisGaugeExtremesPopover.max,
                    sum:$scope.yAxisGaugeExtremesPopover.sum,
                    cumh:$scope.yAxisGaugeExtremesPopover.cumh
                }

            }
            //else
            return {
                sum: sum,
                max: max,
                cumh:cumh
            }
        },
        3:function () {

            if ($scope.yAxisHydroExtremesPopover.edited){
                return{
                    min: $scope.yAxisHydroExtremesPopover.min,
                    max: $scope.yAxisHydroExtremesPopover.max,
                    tickInterval: 0.5
                }
            }

            return {
                min: 0,
                max: 5,
                tickInterval: 0.5
            }
        },
        4:function (sensorInfo) {

            if ($scope.yAxisSnowExtremesPopover.edited){
                return{
                    min: $scope.yAxisSnowExtremesPopover.min,
                    max: $scope.yAxisSnowExtremesPopover.max,
                    tickInterval: 5
                }
            }

            var max = getMax(sensorInfo.obs, 40);
            var min = getMin(sensorInfo.obs, 0);
            return{
                min: min,
                max: max,
                tickInterval: 5
            }
        },
        5:function (sensorInfo) {

            if ($scope.yAxisThermoExtremesPopover.edited){
                return{
                    min: $scope.yAxisThermoExtremesPopover.min,
                    max: $scope.yAxisThermoExtremesPopover.max,
                    tickInterval: 5
                }
            }

            var max = getMax(sensorInfo.obs, 40);
            var min = getMin(sensorInfo.obs, -10);
            return{
                min: min,
                max: max,
                tickInterval: 5
            }
        },
        9:genericYaxisExstreme,

        10:function (sensorInfo) {

            if ($scope.yAxisWindExtremesPopover.edited){
                return{
                    min: $scope.yAxisWindExtremesPopover.min,
                    max: $scope.yAxisWindExtremesPopover.max,
                    tickInterval: 5
                }
            }

            var max = 100;
            var min = 0;
            return{
                min: min,
                max: max,
            }
        },
        12:genericYaxisExstreme,
        13:genericYaxisExstreme,
        30:function () {

            if ($scope.yAxisHydroExtremesPopover.edited){
                return{
                    min: $scope.yAxisHydroExtremesPopover.min,
                    max: $scope.yAxisHydroExtremesPopover.max,
                    tickInterval: 0.5
                }
            }

            return {
                min: 0,
                max: 5,
                tickInterval: 0.5
            }
        },
        60:genericYaxisExstreme,
        90:genericYaxisExstreme,
        98:genericYaxisExstreme,
        1002:function (sensorInfo) {

            if ($scope.yAxisWindExtremesPopover.edited){
                return{
                    min: $scope.yAxisWindExtremesPopover.min,
                    max: $scope.yAxisWindExtremesPopover.max,
                    tickInterval: 5
                }
            }

            var max = 100;
            var min = 0;
            return{
                min: min,
                max: max,
            }
        },
        30:function () {

            if ($scope.yAxisHydroExtremesPopover.edited){
                return{
                    min: $scope.yAxisHydroExtremesPopover.min,
                    max: $scope.yAxisHydroExtremesPopover.max,
                    tickInterval: 0.5
                }
            }

            return {
                min: 0,
                max: 5,
                tickInterval: 0.5
            }
        }
    };

    var allowedSensors = [
        2,3,4,5,9,10,12,13,30,60,90,98,1002//, 10001 30 hydrometer flow
    ];


    $scope.dynamicPopoverDateFrom = {
        date: new Date(menuService.getDateFrom()),
        isOpen: false,
        templateUrl:"dateFromTemplate.html",
        title:$translate.instant('DATE_FROM'),
        content : "content",
        enabled: true,
        data: "data",
        onDateSet:function(newDate, oldDate){

            var tzOffset = newDate.getTimezoneOffset();
            var newDate = new Date(newDate.getTime() - tzOffset * 60000);

            $scope.dynamicPopoverDateFrom.date = newDate;

            $scope.reloadButton.enabled = true;
            $scope.dynamicPopoverDateFrom.close();


            //se setto date from avvicino date to a date from
            if(!moment($scope.dynamicPopoverDateTo.date).isBetween(moment($scope.dynamicPopoverDateFrom.date).subtract(10,'days'),moment($scope.dynamicPopoverDateFrom.date).add(10,'days'),null,'[]')){
                $scope.dynamicPopoverDateTo.date = moment($scope.dynamicPopoverDateFrom.date).add(1,"days").toDate();
            }

        },
        getDateUTCSecond:function(){
            return moment.utc($scope.dynamicPopoverDateFrom.date).valueOf()/1000;

        },
        close:function(){
            $scope.dynamicPopoverDateFrom.isOpen = false
        }
    };
    $scope.dynamicPopoverDateTo = {
        date: new Date(menuService.getDateTo()),
        isOpen: false,
        templateUrl:"dateToTemplate.html",
        title:$translate.instant('DATE_TO'),
        content : "content",
        enabled: true,
        data: "data",
        onDateSet:function(newDate, oldDate){

            var tzOffset = newDate.getTimezoneOffset();
            var newDate = new Date(newDate.getTime() - tzOffset * 60000);

            $scope.dynamicPopoverDateTo.date = newDate;

            $scope.reloadButton.enabled = true;
            $scope.dynamicPopoverDateTo.close();

            if(!moment($scope.dynamicPopoverDateFrom.date).isBetween(moment($scope.dynamicPopoverDateTo.date).subtract(10,'days'),moment($scope.dynamicPopoverDateTo.date).add(10,'days'),null,'[]')){
                $scope.dynamicPopoverDateFrom.date = moment($scope.dynamicPopoverDateTo.date).subtract(1,"days").toDate();
            }

        },
        getDateUTCSecond:function(){
            return moment.utc($scope.dynamicPopoverDateTo.date).valueOf()/1000;
        },
        close:function(){
            $scope.dynamicPopoverDateTo.isOpen = false
        }
    };

    $scope.yAxisGaugeExtremesPopover = {
        isOpen: false,
        templateUrl:"yAxisGaugeExtremesPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        sum: 100,
        max: 50,
        cumh: 50,
        reset:function(){
            $scope.yAxisGaugeExtremesPopover.edited = false
        },
        set:function(){

            if($scope.currentChart.yAxisUpdate){
                $scope.currentChart.yAxisUpdate(this.max, this.sum, this.cumh);

                $scope.yAxisGaugeExtremesPopover.edited = true;
                $scope.yAxisGaugeExtremesPopover.isOpen = false;
            }

        },
        close:function(){
            $scope.yAxisGaugeExtremesPopover.isOpen = false
        }
    };

    $scope.yAxisSnowExtremesPopover = {
        isOpen: false,
        templateUrl:"yAxisSnowExtremesPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min:-10,
        max:40,
        set:function(){
            $scope.yAxisSnowExtremesPopover.isOpen = false;
            $scope.yAxisSnowExtremesPopover.edited = true
        },
        close:function(){
            $scope.yAxisSnowExtremesPopover.isOpen = false
        }
    };

    $scope.yAxisThermoExtremesPopover = {
        isOpen: false,
        templateUrl:"yAxisThermoExtremesPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min:-10,
        max:40,
        set:function(){
            $scope.yAxisThermoExtremesPopover.isOpen = false;
            $scope.yAxisThermoExtremesPopover.edited = true
        },
        close:function(){
            $scope.yAxisThermoExtremesPopover.isOpen = false
        }
    };

    $scope.yAxisHygroExtremesPopover = {
        isOpen: false,
        templateUrl:"yAxisThermoExtremesPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min:0,
        max:100,
        set:function(){
            $scope.yAxisHygroExtremesPopover.isOpen = false;
            $scope.yAxisHygroExtremesPopover.edited = true
        },
        close:function(){
            $scope.yAxisHygroExtremesPopover.isOpen = false
        }
    };

    $scope.yAxisGenericExtremesPopover = {
        isOpen: false,
        templateUrl:"yAxisThermoExtremesPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min:0,
        max:100,
        set:function(){
            $scope.yAxisGenericExtremesPopover.isOpen = false;
            $scope.yAxisGenericExtremesPopover.edited = true
        },
        close:function(){
            $scope.yAxisGenericExtremesPopover.isOpen = false
        }
    };



    $scope.yAxisHydroExtremesPopover = {
        isOpen: false,
        templateUrl:"yAxisHydroExtremesPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min: 0,
        max: 5,
        set:function(){

            if($scope.currentChart.yAxisUpdate){
                $scope.currentChart.yAxisUpdate(this.max, this.min);

                $scope.yAxisHydroExtremesPopover.edited = true;
                $scope.yAxisHydroExtremesPopover.isOpen = false;
            }


        },
        close:function(){
            $scope.yAxisHydroExtremesPopover.isOpen = false
        }

    };

    $scope.yAxisWindExtremesPopover = {
        isOpen: false,
        templateUrl:"yAxisThermoExtremesPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min: 0,
        max: 5,
        set:function(){
            $scope.yAxisWindExtremesPopover.isOpen = false;
            $scope.yAxisWindExtremesPopover.edited = true
        },
        close:function(){
            $scope.yAxisWindExtremesPopover.isOpen = false
        }

    };

    $scope.reloadButton = {
        enabled : false,
        reload : function () {
            $scope.sensorChanged($scope.sensor);
            $scope.reloadButton.enabled = false;
        }
    };

    $scope.allowSensor = function(sensor){

        if ((_.indexOf(allowedSensors,sensor.class ))>-1){
            return true;
        } else return false;
    };


    loadInfo(sensorData);

    $scope.sensorChanged = function(sensor) {

        $scope.warningAnalisys.enabled= false;

        toggleSensor(sensor);

        showChart(sensor);

    };
    $scope.closePopup = function() {

        $uibModalInstance.close();

    };

    loadAddictionalSerie = function(){

    };

    function loadInfo(s) {

        //aggiungo classe per estendere i modal a schermo pieno
        $timeout(addClassToDirective,100);



        if (window.app.url.sentinelURL != undefined){
            console.log("check for sentinel");
            sentinelService.getSensorInfo(s.sensorId, s.dbId, function (info) {

                //gestisco catchment nel titolo grafico
                var catchment = (info.station.aggr_descr.catchment && info.sensor.class == 3)? info.station.aggr_descr.catchment + ' a ' : '';
                var munic = info.station.aggr_descr.munic? (' (' + info.station.aggr_descr.munic + ')') : '';

                $scope.chartTitle = '"'+ catchment + info.station.name + '"' + munic;

                $scope.station = info.station;

                $scope.configObj.station = info.station;

                $scope.station.sensors = _.filter($scope.station.sensors, function (item, key, a) {
                    return (angular.isDefined(item.nativeid));
                });
                $scope.station.sensor = _.filter($scope.station.sensors, function (item, key, a) {
                    return (angular.isDefined(item.nativeid));
                });



                info.sensor.dbid = s.dbId;
                info.sensor.nativeid = s.sensorId;
                info.sensor.sensorid = s.sensorId;


                if(info.sensor.class == 10){
                    if(s.speed.sensorId){
                        info.sensor.speed = {};
                        info.sensor.speed.dbid = s.speed.dbId;
                        info.sensor.speed.nativeid = s.speed.sensorId;
                        info.sensor.speed.sensorid = s.speed.sensorId;

                    } else console.log("anemometer speed error")
                }

                toggleSensor(info.sensor);

                showChart(info.sensor);



            }, function (data) {

                alert($translate.instant('ERROR_LOADING_DATA') + ': ' + data.error_message);

            });
        }else {

            console.log("load chart without sentinel");

            $scope.chartTitle =  s.properties.stationname;
            //s.properties.class = s.properties.sensorclass;
            s.properties.nativeid = s.properties.sensor;
            s.properties.name = s.properties.stationname;
            s.properties.dbid = s.properties.db

            if(angular.isUndefined(s.properties.class)){
                s.properties.class = s.sensorClass;
            }

            if(angular.isUndefined(s.properties.dbid)){
                s.properties.dbid = s.dbId;
            }

            if(angular.isUndefined(s.properties.nativeid)){
                s.properties.nativeid = s.sensorId;
            }

            if(angular.isUndefined(s.class)){
                s.sensorclass = s.properties.class;
            }

            $scope.station = s.properties;



            showChart(s.properties);

        }

    }

    //rainfall warning ANALISYS start

    // Implementare Rainfall Warning Analisys come era in Dewetra 1
    /**
     * ritorna sogle e valori warning analisys
     * @param featureProperties
     */
    function load_Rainfall_Warning_Analisys(featureProperties){
        //prendo le soglie
        thresholdService.getNationalThreshold(featureProperties, function (aSensorThreshold) {
            //carico i massimi
            console.log(aSensorThreshold);

            sentinelService.getPluvioLsppPunctual($scope.station.lat,$scope.station.lon, function (aLinee) {
                //se arriva dai pluvio ho già i valori altrimenti li carico
                $scope.warningAnalisysData = buildWarningAnalisysData($scope.currentChart.rainDepth(), aSensorThreshold, aLinee);

            },function (err) {
                console.log("ERROR LOADING LSPP");
                alert("Error Loading Linee Segnalatrici Possibilità Pluviometriche");
                console.log(err);
            })
        },function (err) {
            console.log("ERROR LOADING NATIONAL THRESHOLD");
            alert("Error Loading National Threshold");
            console.log(err);
        })

    }



    function loadSupeMobileWindowAccumulate(timeline, period) {
        //se periodo è zero,
        if (period ==0)return ;
        //transform date in millisecond to moment object
        timeline.forEach(function (array) {
            array[0]= moment.utc(array[0]);
        });


        var hour = period/3600;

        var Accumulate = [];

        for (var i = timeline.length-1;i > -1; i--){

            var refTime = timeline[i][0];

            var untilTime = moment.utc(refTime.toDate()).subtract(hour, 'hours');



            var Acc = 0;
            for(var i2 = i;i2 > -1; i2--){
                if(timeline[i2][0].isAfter(untilTime)){
                    //sommo i valori
                    Acc = Acc+ parseFloat(timeline[i2][1]);
                }else break;

            }

            //creo array delle cumulate
            Accumulate.push({
                value: Acc,
                from:untilTime,
                to :refTime,
                diff:refTime.diff(untilTime, 'hours')
            });
        }
        //cerco la cumulata massima
        if (Accumulate.length> 0){
            var max=_.max(Accumulate, function (val) {return val.value;});
            return max
        }
        return null;
    }


    /**
     * abilita disabilita warning analisys
     * @returns {boolean}
     */
    $scope.isWarningAnalisys = function () {
        try{
            return ($scope.currentChart.rainDepth);
        }catch (err){
            return false;
        }

    };

    /**
     * calcola superamento soglie
     * @param thrArray
     * @param mm
     * @returns {*}
     */
    function calculateThr(thrArray, mm) {
        //scorro le soglie
        var thr = null;
        if (angular.isUndefined(thrArray)) return null;

        thrArray.forEach(function (currentValue, index, arr) {
            if (parseFloat(mm) > parseFloat(currentValue.value) ){
                thr = currentValue;
            }
        });
        //e ritorno la maggiore superata
        return thr;
    }

    /**
     * costruisce struttura per html
     * @param pluviometerData
     */
    function buildWarningAnalisysData(depthTimeline, aSensorThreshold, aLinee) {

        var thresholdView = [];

        var aValue = [];

        //filtro le soglie per gruppo
        var thresholdbyDb = _.filter(aSensorThreshold, function (Threshold) {
            return (Threshold.group == 'national_PLUVIOMETRO')?true:false;
        });

        //filtro le soglie per periodo
        var thresholdByPeriod = _.groupBy(thresholdbyDb, 'period' );

        var period = [3600,10800,21600,43200, 64800,86400, 129600];

        period.forEach(function (period) {
            var maxAccObj = loadSupeMobileWindowAccumulate(depthTimeline, period);
            var exceed = (thresholdByPeriod.hasOwnProperty(period))?calculateThr(thresholdByPeriod[period], maxAccObj.value):null
            var oValue = {
                period: period,
                hour:period / 3600,
                value:maxAccObj,
                lspp:calculateLsp(aLinee,maxAccObj.value, period / 3600),
                exceed:exceed
            };

            aValue.push(oValue);
        });

        // for (var prop in thresholdByPeriod) {
        //
        //     if (prop== 172800) break;
        //     var maxAccObj = loadSupeMobileWindowAccumulate(depthTimeline, prop);
        //
        //     var oValue = {
        //         period: prop,
        //         hour:prop / 3600,
        //         value:maxAccObj,
        //         lspp:calculateLsp(aLinee,maxAccObj.value, prop / 3600),
        //         exceed:calculateThr(thresholdByPeriod[prop], maxAccObj.value)
        //     };
        //
        //     aValue.push(oValue);
        //
        //
        // }

        return aValue;
    }



    /**
     * gestisce click su warning analisys
     */
    $scope.loadWarningAnalisys= function () {
        $scope.warningAnalisys.enabled = true;

        var data ={
            sensorid :sensorData.sensorId,
            dbid : sensorData.dbId
        };

        load_Rainfall_Warning_Analisys(data);
    };

    //rainfall warning ANALISYS END


    //LINEE SEGNALATRICI START


    /**
     * calcolo superamente
     * @param aLinee
     * @param value
     * @param hour
     * @returns {*}
     */
    calculateLsp = function(aLinee,value, hour){

        var tReturn;
        // var lineeexample={
        //     10:{
        //         1:1,
        //         3:112,
        //         6:1333,
        //         12:13334,
        //         24:133356,
        //     },
        //     50:{
        //        1: "etc"
        //     }
        // };

        var aString = {
            0:"T<10",
            10:"10<T<50",
            50:"50<T<100",
            100:"100<T<200",
            200:"200<T<500",
            500:"T>500"
        };

        if(aLinee && value && hour){
            for(var prop in aLinee){

                if (value > aLinee[prop][hour]) {
                    tReturn =aString[prop];
                }
            }
            return tReturn;

        }else {
            return "N/D"
        };

    };

    //LINEE SEGNALATRICI END

    function showChart(sensor) {

        if (!chartManager[sensor.class]) {

            alert($translate.instant('CHART_NOT_AVAILABLE'));
            return;

        }

        $scope.sensor = sensor;

        var fid = sensor.nativeid + ';' + sensor.dbid;
        //var fid = sensor.id + ';' + sensor.dbid;
        // var from1 = menuService.getDateFromUTCSecond();
        var from = $scope.dynamicPopoverDateFrom.getDateUTCSecond();
        // var to1 = menuService.getDateToUTCSecond();
        var to = $scope.dynamicPopoverDateTo.getDateUTCSecond();

        $scope.chartSubTitle = $translate.instant('SENS_DESCR_' + sensor.class) + ' ' + $translate.instant('FROM') + ' ' + moment.utc(from, 'X').format('DD/MM/YYYY HH:mm')
                                                                                + ' ' + $translate.instant('TO') + ' ' + moment.utc(to, 'X').format('DD/MM/YYYY HH:mm');
        serieService.getSeriesDirect(ddsServerId, chartSeries[sensor.class], fid, from, to, function (data) {

            let sensorInfo= {};

            if (Array.isArray(data)){

                // TODO scale di deflusso
                console.log("esiste piu di una serie per questo sensore")
                if(menuService.debug)console.log(data);

                if (sensor.class == 3){// se è un idrometro aggiungo un
                    //$scope.oScalaDeflusso = true;
                    let portate = Object.assign({}, sensor);
                    $scope.scalaDiDeflusso = portate;
                    portate.class = 30;
                    portate.descr = 'hydrometer_Q';
                    $scope.station.sensors.push(portate);


                }
                sensorInfo = {
                    station: $scope.station,
                    sensor : sensor,
                    timeline : data[0].timeline,
                    obs : data[0].values,
                    undef: getUndefSeries(data[0].timeline, data[0].values, from, to),
                    series:  data.map((x)=>{
                        console.log(x);
                        return {
                            timeline:x.timeline,
                            obs: x.values,
                            title: x.title,
                            type: x.type,
                            undef: getUndefSeries(x.timeline, x.values, from, to)
                        }
                    })
                };

            }else{//modalità compatibile con le vecchie api
                sensorInfo = {
                    station: $scope.station,
                    sensor : sensor,
                    timeline : data.timeline,
                    obs : data.values,
                    undef: getUndefSeries(data.timeline, data.values, from, to)
                };
            }



            // console.log($scope.station.sensors);
            //nel caso del layer anemometri questo viene fatto a monte.. in un layer pluvio ad esempio, va assemblato qui
            if(sensor.class == 10){
                sensorInfo.sensor.speed = _.filter($scope.station.sensors,function (item) {
                    return item.class ==11;
                })[0];
            }


            setTimeout(function() {

                 $scope.currentChart = chartManager[sensor.class](sensorInfo, from, to, menuService.oChartSize.m_iSensorChartHeight(), thresholdService, $translate, yAxisExtremes[sensor.class](sensorInfo), serieService)
                // if($scope.currentChart.hasOwnProperty("reportThis"))$scope.currentChart.reportThis();
            }, 0);

        }, function (data) {
            alert($translate.instant('UNAVAILABLE_DATA'));
        });

        //se anomometro

    }

    $scope.formatSensorTitle = (sensor) => {
        switch (sensor.class) {
            case 98:

                return $translate.instant(('SENS_DESCR_' + sensor.class + '_' + sensor.descr.split(' ').join('_').toLowerCase()));
                break;
            default:
                return $translate.instant(('SENS_DESCR_' + sensor.class));
        }

    };

    function toggleSensor(s) {

        if ($scope.station) {
            if($scope.station.hasOwnProperty('sensors')) {
                $scope.station.sensors.forEach(function (sensor) {
                    sensor.active = (sensor.nativeid === s.nativeid);
                });
            }else {
                console.log("same sensors")
            }

        }

    }

    function popOverYAxis(){

    }

}]);


