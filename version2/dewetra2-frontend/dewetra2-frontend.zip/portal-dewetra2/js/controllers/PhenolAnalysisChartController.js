/**
 * Created by Anto on 01/08/17.
 */

dewetraApp.controller('phenolAnalysisChartController',['$scope', '$uibModal', '$uibModalInstance', '$translate', 'stationInfo', 'menuService', 'serieService','_', '$timeout', '$rootScope', function($scope, $uibModal, $uibModalInstance, $translate, stationInfo, menuService, serieService,_, $timeout, $rootScope) {


    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    })

    var chartManager = {
        'PhenolPhaseCfrChart' : showPhenolPhaseCfrChart,
        'SeasonPhenolPhaseChart' : showSeasonPhenolPhaseChart,
        'TempCfrChart' : showTempCfrChart,
        'SeasonAccumulatedChart' : showSeasonAccumulatedChart,
        'MontlyAccumulatedChart': showMontlyAccumulatedChart,
        'GSIChart': showGSIChart
    };

    //var chartDataManager = {
    //    'PhenolPhaseCfrChart' : getPhenolPhaseCfrChartData,
    //    'SeasonPhenolPhaseChart' : getSeasonPhenolPhaseChartData,
    //    'TempCfrChart' : getShowTempCfrChartData,
    //    'SeasonAccumulatedChart' : getSeasonAccumulatedChartData
    //};

    addDownloadChartOption();

    //change Axys
    $scope.yAxisExtremesQPopover = {

        isOpen: false,
        templateUrl:"yAxisExtremesQPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min: 0,
        max: null,
        set:function(){

            $scope.yAxisExtremesQPopover.isOpen = false
            $scope.yAxisExtremesQPopover.edited = true

            for (var i = 0; i < $scope.hydrograms.length; i++) {

                if ($scope.hydrograms[i].active) {

                    showChart($scope.hydrograms[i]);

                    return;

                }

            }

        },
        close:function(){
            $scope.yAxisExtremesQPopover.isOpen = false
        }

    };

    $scope.yAxisExtremesVPopover = {
        isOpen: false,
        templateUrl:"yAxisExtremesVPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min: 0,
        max: null,
        set:function(){

            $scope.yAxisExtremesVPopover.isOpen = false
            $scope.yAxisExtremesVPopover.edited = true

            for (var i = 0; i < $scope.hydrograms.length; i++) {

                if ($scope.hydrograms[i].active) {

                    showChart($scope.hydrograms[i]);

                    return;

                }

            }

        },
        close:function(){
            $scope.yAxisExtremesVPopover.isOpen = false
        }

    };

    $scope.XYRulerVPopover = {
        isOpen: false,
        templateUrl:"XYRulerVPopover.html",
        title:"SET_Y_RULER",
        enabled: true,
        data: "data",
        edited: false,
        xLine: null,
        yLine: null,
        set:function(){

            $scope.XYRulerVPopover.isOpen = false
            $scope.XYRulerVPopover.edited = true

            if((typeof $scope.chart)=== 'object'){

                if($scope.XYRulerVPopover.edited)$scope.chart.chart.yAxis[0].removePlotLine('yRuler');

                $scope.chart.chart.yAxis[0].addPlotLine(
                    {
                        id : 'yRuler',
                        value : parseFloat($scope.XYRulerVPopover.yLine),
                        color : 'grey',
                        width : 2,
                        zIndex: 5,
                        label : {
                            text : "Ruler",
                            color : 'grey'
                        }
                    });

            }

        },
        close:function(){
            $scope.XYRulerVPopover.isOpen = false
        }

    };

    addClassToDirective = function () {
        //aggiungo questa classe per customizzare solo i grafici sensori
        //console.log("test")
        var result = document.getElementsByClassName("modal-dialog");
        var wrappedResult = angular.element(result);
        //console.log(wrappedResult)
        wrappedResult.addClass("customModal2")


    }

    var yAxisExtremes = {

        'DeterministicHydrogramChart' : $scope.yAxisExtremesQPopover,
        'DeterministicVolumeHydrogramChart' : $scope.yAxisExtremesVPopover,
        'DeterministicLevelVolumeHydrogramChart' : $scope.yAxisExtremesVPopover,
        'MaximumHydrogramChart' : $scope.yAxisExtremesQPopover,
        'MaximumVolumeHydrogramChart' : $scope.yAxisExtremesVPopover,
        'MaximumLevelVolumeHydrogramChart' : $scope.yAxisExtremesVPopover

    };

    $scope.chart = null;

    $scope.stationData = {};

    loadPhenolData(stationInfo);

    $scope.reloadButton = {

        enabled : true,
        reload : function () {

            for (var i = 0; i < $scope.stationData.length; i++) {

                if ($scope.stationData[i].active) {

                    showChart($scope.stationData[i]);
                    return;

                }

            }

        }

    };

    $scope.stationDataChanged = function(stationData) {

        toggleData(stationData.type);

        showChart(stationData);

    };

    $scope.closePopup = function() {

        $uibModalInstance.close();

    };


    $scope.getStationDataFiltered = function () {

    }

    function loadPhenolData(s) {

        //aggiungo classe per estendere i modal a schermo pieno
        $timeout(addClassToDirective, 100);

        serieService.getSeriesDirect(s.server_id, s.series_id, s.id_centr, menuService.getDateFromUTCSecond(), menuService.getDateToUTCSecond(),

            function(data) {

            console.log(data)
                
                
                let unavailable = ["SeasonAccumulatedChart"]
                
                data = data.filter(function (d) {
                    return ( unavailable.indexOf(d.type )== -1)
                })

                if (data.length == 0) {
                    alert($translate.instant('UNAVAILABLE_DATA'));
                    return;
                }

                var sd;


                data.forEach(function(s) {

                    console.log(s)

                    sd = $scope.stationData[s.type];

                    if (!sd) {
                        sd = {
                              'active' : false,
                              'type' : s.type,
                              'data' : getChartData(s.type, data) // chartDataManager[s.type](data)
                        };
                        $scope.stationData[s.type] = sd;
                    }

                });

                var type = data[0].type;

                toggleData(type);

                $scope.chartTitle = '"'+ data[0].title + '"';

                showChart($scope.stationData[type]);

            },
            function(data) {

                alert($translate.instant('ERROR_LOADING_DATA') + ': ' + data.error_message);

            });

    }

    function getChartData(chartType, data) {

        if (chartType == 'PhenolPhaseCfrChart') {
            return [data[0], data[1]];
        } else {
            var ret = [];
            var dataType = (chartType == 'SeasonPhenolPhaseChart'? 'PhenolPhaseCfrChart' : chartType);
            for (var i = 2; i < data.length; i++) {
                if (data[i].type == dataType) ret.push(data[i]);
            }
            return ret;
        }

    }

    function getChartSubtitle(type, data) {

        var min_year = 2004, max_year = moment.utc().year();
        if ((type == 'PhenolPhaseCfrChart') || (type == 'SeasonAccumulatedChart')) {

            var dtMin = moment.utc().valueOf(), dtMax = 0;

            data.forEach(function(d) {

                dtMin = Math.min(dtMin, moment.utc(d.timeline[0]).valueOf());
                dtMax = Math.max(dtMax, moment.utc(d.timeline[d.timeline.length - 1]).valueOf());

            });

            min_year = moment.utc(dtMin/1000, 'X').format('YYYY');
            max_year = moment.utc(dtMax/1000, 'X').format('YYYY');

        } else {

            min_year = data[0].title;
            max_year = data[data.length - 2].title;

        }


        return $translate.instant('FROM').toUpperCase() + ' ' + min_year + ' ' +
               $translate.instant('TO').toUpperCase() + ' ' + max_year;

    }

    function showChart(phenolData) {

        if (!chartManager[phenolData.type]) {

            alert($translate.instant('CHART_NOT_AVAILABLE'));
            return;

        }

        $scope.chartSubTitle = getChartSubtitle(phenolData.type, phenolData.data);


        setTimeout(function() {

            $scope.chart = chartManager[phenolData.type](phenolData, menuService.oChartSize.m_iFloodProofsChartHeight(), $translate, null);

        }, 0);

    }

    function toggleData(type) {

        for (var key in $scope.stationData) {
            // skip loop if the property is from prototype
            if (!$scope.stationData.hasOwnProperty(key)) continue;

            $scope.stationData[key].active = ($scope.stationData[key].type === type);

        }

    }

    $scope.chartTitleFormatter = function (descr) {
        return descr.toUpperCase().trim().replace(/ /g,"_");
    }



}]);


