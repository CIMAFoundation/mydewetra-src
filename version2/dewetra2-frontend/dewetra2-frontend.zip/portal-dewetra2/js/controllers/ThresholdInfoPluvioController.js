/**
 * Created by Dario Rubado on 26/11/15.
 */

dewetraApp.controller("thresholdInfoPluvioController",['$scope','$rootScope','thresholdService', '_', '$timeout' , function ($scope,$rootScope,thresholdService, _, $timeout) {

    function showThreshold(data) {
        //constuisco proprieta threshold dell threshold object
        for(var prop in $scope.thresholdObject.sensorData){
            if (stringStartsWith(name, "e_")){
                var aSoglia = name.split("_");
                var oSoglia = {
                    id: aSoglia[1],
                    warn_index : aSoglia[2],
                    valore: $scope.thresholdObject.sensorData[prop],
                    thresholdValue : []
                };
                $scope.thresholdObject.threshold.push(oSoglia)
            }
        }
        if($scope.thresholdObject.threshold.length > 0){
            $scope.thresholdObject.threshold.forEach(function (soglia) {
                thresholdService.getNationalThreshold(soglia.id, function (data) {
                    soglia.thresholdValue = _where(data,{severity: soglia.warn_index})
                }, function (err) {
                    console.log("errore ricezione soglie");
                })
            })
        }
    }






    $scope.thresholdObjectPluvio ={
        sensorData : {},
        oldSensor :{},
        active : false,
        dataView : [],
        thresholdAlert:[],
        threshold:[],
        mouseOver: function(data){
            console.log("mouseOver");
            this.active = true;
            this.sensorData = data;
            this.buildThreshold(data);
            this.buildSensorDataView(data)
        },
        mouseOut: function(){
            console.log("mouseOut");
            this.threshold = [];
            this.thresholdAlert = [];

            this.active = false;
            this.sensorData = {};
        },
        buildSensorDataView : function (data) {

            var start = false;

            $scope.thresholdObject.dataView = [];
            for(var prop in data){
                if (stringStartsWith(prop, "v_")){
                    start = true
                }
            }
            if(start){
                for(var prop in data){
                    if (stringStartsWith(prop, "v_")){
                        var aValue = prop.split("_");
                        var sTimeStamp = moment.unix(aValue[1]);
                        var sPeriod = parseInt(aValue[2])/60;
                        var nValue =data[prop];

                        var oValue = {
                            timeStamp: sTimeStamp,
                            period : sPeriod,
                            valore: nValue
                        };
                        $scope.thresholdObject.dataView.push(oValue)
                    }
                }
                $scope.thresholdObject.dataView = _.sortBy($scope.thresholdObject.dataView, 'sTimeStamp')
            }
        },
        buildThreshold: function (data) {

            var start = false;

            $scope.thresholdObject.thresholdAlert = [];
            for(var prop in data){
                if (stringStartsWith(prop, "e_")){
                    start = true
                }
            }

            if (start){
                thresholdService.getNationalThreshold(data.sensorid, function (aSensorThreshold) {
                    //constuisco proprieta threshold dell threshold object
                    for(var prop in data){
                        if (stringStartsWith(prop, "e_")){
                            var aSoglia = prop.split("_");
                            var aSoglie = _.where(aSensorThreshold, {severity: parseInt(aSoglia[2])});
                            var oSoglia = {
                                id: aSoglia[1],
                                warn_index : parseInt(aSoglia[2]),
                                valore: data[prop],
                                thresholdValueMin : _.where(aSoglie,{type: "diff-"}),
                                thresholdValueMax : _.where(aSoglie,{type: "diff+"})
                            };
                            $scope.thresholdObject.thresholdAlert.push(oSoglia)
                        }
                    }
                    //test prendo solo la soglia maggiore
                    $scope.thresholdObject.thresholdAlert = _.max($scope.thresholdObject.thresholdAlert, function (obj) {
                        return obj.warn_index;
                    });
                    //console.log($scope.thresholdObject.thresholdAlert)
                })
            }

        }
    };
    //$scope.$watch('thresholdObject.sensorData', init)
}]);
