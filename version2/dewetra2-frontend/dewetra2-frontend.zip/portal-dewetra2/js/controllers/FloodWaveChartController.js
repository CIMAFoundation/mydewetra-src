/**
 * Created by Dario Rubado on 18/12/15.
 */

dewetraApp.controller('floodWaveChartController', ['$scope','$window','$location','$anchorScroll', '$uibModal', '$uibModalInstance', '$translate', 'params', 'menuService', 'serieService', 'sentinelService', 'thresholdService','_', '$timeout', '$rootScope', '$sce', 'iconService', 'apiService',function($scope,$window,$location,$anchorScroll, $uibModal, $uibModalInstance, $translate, params, menuService, serieService, sentinelService, thresholdService,_, $timeout, $rootScope, $sce, iconService, apiService) {

    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    });

    $scope.layers = [];

    var debug = menuService.debug;

    $scope.aRiverSpeed =[1,1.5,2,2.5,3];

    // $scope.riverSpeed ;
    $scope.config= {
        riverSpeed:1.5
    }

    var listOfinformationMarker= null;



    sentinelService.getFloodWave(params.basin,function (data) {
        $scope.nodes = data.nodes;

        if(debug) console.log(data.nodes)
        $scope.stationOfSelectedBasin = _.filter(params.allStations,function (station) {
            return(params.catchment == station.properties.catchment)
        })

        var allStationOfMainBasin = _.filter(params.allStations,function (station) {
            return(params.catchment == station.properties.catchment)
        })
        $scope.basin= params.geoJson.properties;



        if(data.layers.length >0){
            data.layers.forEach(function (layer) {
                //inizializzo mappa
                $scope.initMap();
                //aggiungo fiume
                $scope.addWmsRiverLayer(layer.server, layer.layerid);
                //aggiungo markers
                $scope.addMarkerEachChart(data.nodes);
                //aggiungo Html chart e grafico
                $timeout(function () {
                    $scope.addCharts(data.nodes);
                },500)


            })
        }else {
            alert("No Layer to add");
            $uibModalInstance.close();
        }

    },function (err) {
        if(debug) console.log(err)
        alert("Error Loading Flood Wave")
    })


    function speedMarkerMaker(km) {

        var time = (parseFloat(km) / (parseFloat($scope.config.riverSpeed)*3.6));


        // var myLabel = L.divIcon({
        //     iconAnchor: [10,10],
        //     className: 'floodwave',
        //     html:
        //     '<div id ="station" class="floodwaveLabel" >' +
        //     '<div id="" style="line-height: 1;" class= "text-center ">'+feature.properties.Length_km+' km</div>' +
        //     '</div>'
        //
        // });

        if (time > 1){
            var minutesInHour = (time %1).toFixed(2);
            minutesInHour= parseInt(minutesInHour*60);
            var hour = Math.floor(time);

            var myLabel = L.divIcon({
                iconAnchor: [10,10],
                className: 'floodwave',
                html:
                '<div id ="station" class="floodwaveLabel" >' +
                '<div id="" style="line-height: 1;" class= "text-center ">'+hour+'h </div>' +
                '<div id="" style="line-height: 1;" class= "text-center ">'+minutesInHour+'\'</div>' +
                '</div>'

            });

        } else {
            var minutesInHour = (time %1).toFixed(2);
            minutesInHour= parseInt(minutesInHour*60);

            var myLabel = L.divIcon({
                iconAnchor: [10,10],
                className: 'floodwave',
                html:
                '<div id ="station" class="floodwaveLabel" >' +
                '<div id="" style="line-height: 1;" class= "text-center ">'+minutesInHour+' \'</div>' +
                '</div>'

            });
        }

        return myLabel

    }


    $scope.changeSpeedInformationMarker = function() {

        for(var i in $scope.speedInformationMarkersGroup._layers ){

            var label = speedMarkerMaker($scope.speedInformationMarkersGroup._layers[i].properties.Length_km);

            $scope.speedInformationMarkersGroup._layers[i].setIcon(label);
        }
    }


    /**
     * add river layer
     * @param server
     * @param id
     */
    $scope.addWmsRiverLayer = function (server, id) {

        var basin = params.geoJson;

        var b = L.geoJson(basin,{
            style:function (feature) {

                var color= params.basinColor;

                return {
                    fillColor: color,
                    color : color,
                    opacity : 1,
                    fillOpacity: 0.6,
                    weight: 1

                }
            }
        }).addTo($scope.floodWaveMap).bringToBack();

        //addcatchment contour for test
        // var allBasin = L.geoJson(params.allBasin,{
        //     style:function (feature) {
        //         return {
        //             opacity : 1,
        //             weight: 1
        //         }
        //     }
        // }).addTo($scope.floodWaveMap).bringToBack();



        // WMS add layer
        // var l = L.tileLayer.wms(server, {
        //     layers: id,
        //     format: 'image/png',
        //     transparent: true,
        //     maxZoom: 24,
        //     // styles:(styles)?styles:"",
        //     // env :(env)?env:''
        // }).addTo($scope.floodWaveMap).bringToFront();

        var wfsUrl =  server.slice(0, -3)+"wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=";
        //http://dds.cimafoundation.org/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=COAU_FIRES_7dd58c20-0cce-42ab-94b6-4a99ab124381
        console.log("WFS URL");
        console.log(server.slice(0, -3)+"rest/layergroups/"+id);
        apiService.getExt(server.slice(0, -3)+"rest/layergroups/"+id,function (data) {


            if(data.hasOwnProperty("layerGroup")){
                if(data.layerGroup.hasOwnProperty("publishables")){

                    if(data.layerGroup.publishables.published.length == 2){

                        // //dividere layer di punti da layer multiLine
                        //  _.filter(data.layerGroup.publishables.published, function () {
                        //
                        //  });

                        var oPointLayer, oRiverLayer;

                        oPointLayer=_.filter(data.layerGroup.publishables.published, function (layer) {
                            return (layer.name.toLowerCase().indexOf("nodi")>-1);
                        });
                        oRiverLayer=_.filter(data.layerGroup.publishables.published, function (layer) {
                            return ((layer.name.toLowerCase().indexOf("archi")>-1));
                        });

                        // if(debug) console.log(oRiverLayer)
                        apiService.getExt(wfsUrl+oRiverLayer[0].name, function (data) {

                            listOfinformationMarker = L.geoJson(data,{

                                // filter:function (geoJsonFeature) {
                                //     return true;
                                // },
                                style:function (feature) {
                                    // if(debug) console.log(feature)
                                    if(feature.geometry.type == "MultiLineString"){

                                        if(feature.properties.hasOwnProperty("Branch")&&feature.properties.hasOwnProperty("Length_km")){

                                            var intermediate = parseInt(feature.geometry.coordinates[0].length/2);

                                            var myLabel = speedMarkerMaker(feature.properties.Length_km);

                                            var marker = L.marker([feature.geometry.coordinates[0][intermediate][1],feature.geometry.coordinates[0][intermediate][0]],{icon:myLabel});
                                            marker.properties = feature.properties;
                                            marker.addTo($scope.speedInformationMarkersGroup);
                                        }

                                        return {
                                            fillColor: "black",
                                            color : "black",
                                            opacity : 1,
                                            weight: 2

                                        }
                                    }
                                }

                            }).addTo($scope.floodWaveMap).bringToFront();
                        })


                    }//if 2 layers
                }//if has publishables
                else{
                    console.log("PUBLISHABLE ERROR");
                }
            }//if has layergroup properties
            else{
                console.log("WFS ERROR");
            }
        })

        $scope.floodWaveMap.fitBounds(b.getBounds());
    }




    /**
     * add marker off hydrometer
     * @param nodes
     */
    //dict of markers
    $scope.markersList = [];

    $scope.addMarkerEachChart = function (nodes) {

        if(debug) console.log("number of marker: "+ nodes.length)

        if(nodes && nodes.length > 0){

            nodes.forEach(function (node) {

                // var stationFromLayer = _.find($scope.stationOfSelectedBasin, function (station) {
                //     return (station.properties.sensorid == node.sensor_id)
                /* })*/var stationFromLayer = _.find(params.allStations, function (station) {
                    return (station.properties.sensorid == node.sensor_id)
                })

                if (stationFromLayer){
                    var marker = L.marker([node.lat, node.lon], {icon:iconService.warnings_hydro_Icon(stationFromLayer, 1)}).addTo($scope.floodWaveMap);
                    var string= "main_basin:"+node.main_basin+"</br>sensor_id:"+node.sensor_id+"</br>name:"+node.name+"</br>id_basin:"+node.id_basin;
                    marker.bindPopup(string)
                }else{

                    //quando metto il marker spaziale "tipo google" vuol dire che nell'anagrafica dei nodi differisce da quella dei sensori
                    //è da riallineare lato server
                    var marker = L.marker([node.lat, node.lon]).addTo($scope.floodWaveMap);
                    var string= "main_basin:"+node.main_basin+"</br>sensor_id:"+node.sensor_id+"</br>name:"+node.name+"</br>id_basin:"+node.id_basin;
                    marker.bindPopup(string)
                }

                // var marker = L.marker([node.lat, node.lon]).addTo($scope.floodWaveMap);
                marker.options.properties = node;
                //marker mause over

                marker.on('mouseover',function (s) {
                    $location.hash(s.target.options.properties.sensor_id+"_Anchor");
                    $anchorScroll();
                    // var element = $document.getEle
                })


                //dict of markers
                $scope.markersList[node.sensor_id] = marker;
            })
        }
    }

    /**
     * Init Map
     */
    $scope.initMap = function () {

        $scope.speedInformationMarkersGroup = L.featureGroup();

        var osmBasic = L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 18
        });
        $scope.floodWaveMap = L.map('floodWaveMap',
            {
                //zoomControl:false,
                // scrollWheelZoom:false,
                //tap:false,
                boxZoom:false
            }).setView([44, 8], 13);

        osmBasic.addTo($scope.floodWaveMap);

        $scope.speedInformationMarkersGroup.addTo($scope.floodWaveMap);

    }



    $scope.mouseOverChart = function (chartId) {
        // $scope.markersList[chartId].bindPopup("THIS HYDROMETER").openPopup();
        $scope.markersList[chartId].openPopup();
    };

    $scope.mouseOutChart = function (chartId) {
        // $scope.markersList[chartId].bindPopup("THIS HYDROMETER").openPopup();
        $scope.markersList[chartId].closePopup();
    };

    /**
     * adding single chart
     * @param node
     */
    $scope.addChart = function (node) {
        var width = document.getElementById("floodWaveCharts").clientWidth * 0.95;
        var height = 600;

        var to = menuService.getDateToUTCSecond();
        var from = menuService.getDateFromUTCSecond();

        $scope.singleChart ={};

        // node.chart = node.sensor_id.toString();

        node.sensor = {
            mu:"m",
            sensorid:node.sensor_id,
            dbid:2,

        }
        node.station = {
            name:"name"
        }

        if (node.serie.timeline.length > 0 && node.serie.values.length > 0){
            //formatto le date come mi servono nel grafico
            for (var i in node.serie.timeline){
                // node.serie.timeline[i] = new Date(node.serie.timeline[i]*1000).toISOString();
                node.serie.timeline[i] = moment(new Date(node.serie.timeline[i]*1000)).toISOString();
            }
            node.timeline= node.serie.timeline;
            node.obs= node.serie.values;
            node.undef = getUndefSeries(node.timeline, node.obs, from, to)
            node.mouseOverChart = $scope.mouseOverChart;
            node.mouseOutChart = $scope.mouseOutChart;

            // $timeout(function () {

            $scope.singleChart ={
                visibility :true,
                title: node.name,
                sensor_id:node.sensor_id
            }

            if(node.hasOwnProperty('timeline')) $scope.singleChart.chart = showHydrometerChart(node, from, to, height, thresholdService, $translate, {min:getMin(node.serie.values, 0), max:getMax(node.serie.values, 40), tickInterval:5}, serieService)

            if($scope.singleChart.chart.hasOwnProperty("setSize")) $scope.singleChart.chart.setSize(width, height);


        }else{
            if(debug) console.log(node)
        }

    }

    /**
     * addl all list of chart
     * @param nodes
     */
    $scope.addCharts = function (nodes) {
        var width = document.getElementById("floodWaveCharts").clientWidth * 0.95;
        var height = 600;
        // var Html = "";
        //
        //
        // $scope.chartsHtml = $sce.trustAsHtml(Html);

        $scope.currentChart = [];

        if(debug) console.log("number of charts: "+ nodes.length)

        nodes.forEach(function (node) {
            var to = menuService.getDateToUTCSecond();
            var from = menuService.getDateFromUTCSecond();

            node.chart = node.sensor_id.toString();

            node.sensor = {
                mu:"m",
                sensorid:node.sensor_id,
                dbid:2,

            }
            node.station = {
                name:"name"
            }

            if (node.serie.timeline.length > 0 && node.serie.values.length > 0){
                //formatto le date come mi servono nel grafico
                for (var i in node.serie.timeline){
                    // node.serie.timeline[i] = new Date(node.serie.timeline[i]*1000).toISOString();
                    node.serie.timeline[i] = moment(new Date(node.serie.timeline[i]*1000)).toISOString();
                }
                node.timeline= node.serie.timeline;
                node.obs= node.serie.values;
                node.undef = getUndefSeries(node.timeline, node.obs, from, to)
                node.mouseOverChart = $scope.mouseOverChart;
                node.mouseOutChart = $scope.mouseOutChart;

                $scope.currentChart[node.sensor_id] ={
                    visibility :true,
                    title: node.name
                }

                sentinelService.getSensorInfo(node.sensor.sensorid,node.sensor.dbid,function (data) {
                    node.sensorInfo= data ;
                    updatePopUpAfterInfoReceived(node.sensor.sensorid, data);
                    if(debug) console.log(node)

                });

                if(node.hasOwnProperty('timeline')) $scope.currentChart[node.sensor_id].chart = showHydrometerChart(node, from, to, height, thresholdService, $translate, {min:getMin(node.serie.values, 0), max:getMax(node.serie.values, 40), tickInterval:5}, serieService)

                if($scope.currentChart[node.sensor_id].chart.hasOwnProperty("setSize")) $scope.currentChart[node.sensor_id].chart.setSize(width, height);

            }else{
                if(debug) console.log(node)
            }

        })

    }

    function updatePopUpAfterInfoReceived ( sensorId, data) {
        console.log(data);
        console.log($scope.markersList);
        var string= "Catchment:"+data.station.aggr_descr.catchment+"</br>Nome:"+data.station.name+"</br>Comune:"+data.station.aggr_descr.munic+"</br>wa:"+data.station.aggr_descr.wa;
        $scope.markersList[sensorId].bindPopup(string);
    }


    $scope.closePopup = function() {

        $uibModalInstance.close();

    };

    $scope.hideChart = function (chartId) {
        $scope.currentChart[chartId].visibility = !$scope.currentChart[chartId].visibility
    }

    // $scope.loadOnClickEventonX = function (nodes) {
    //
    //     $timeout(function () {
    //         nodes.forEach(function (node) {
    //             var string = "close_"+node.sensor_id;
    //             var element = angular.element( document.querySelector(string) );
    //             if(debug) console.log(element)
    //              function onclick(e) {
    //                 var chart = angular.element( document.querySelector(node.sensor_id) );
    //                 chart.style.display = "none";
    //                 if(debug) console.log("pp")
    //             }
    //
    //             element.setAttribute("onclick", onclick)
    //
    //             // element.onclick = onclick;
    //
    //             if(debug) console.log(element)
    //
    //
    //         })
    //     }, 2000);
    //
    // }

}]);


