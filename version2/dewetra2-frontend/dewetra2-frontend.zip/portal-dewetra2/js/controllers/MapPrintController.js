dewetraApp.controller("mapPrintController", ['$scope', '$uibModalInstance','params', 'mapService',  '$http', 'printService','$interval', '$window', 'apiService' , 'menuService',function ($scope, $uibModalInstance,params, mapService,  $http, printService,$interval, $window, apiService , menuService) {

    $scope.oConfig = {
        bLoader : true,
        sImgWidth : $window.innerWidth*0.8,
        sImgEight : $window.innerHeight*0.8,
        bDownloadReady: false
    };

    var aPromises = [];

    var oPromise = $interval(function () {
        if($scope.oConfig.bLoader == true){
            $scope.oConfig.bLoader = false
        }else{
            aPromises.forEach(function (promise) {
                $interval.cancel(promise);
            })
        }
    }, 5000);

    aPromises.push(oPromise);

    $scope.init = function () {

        var params = printService.getMapsSettings(mapService, mapService.oLayerList.aDraggable, mapService.oLayerList.aUndraggable);

        params.dateTo= menuService.getDateTo()
        params.dateFrom = menuService.getDateFrom()
        // params.legendUrl =
        apiService.postPrintServer('savemap', params,function (data) {
            if(data.printId != null){
                // apiService.buildPrintApiURL('paintmap/'+data.printId)
                // var mapUrl = apiService.buildPrintApiURL('webshot/'+data.printId)


                $scope.src = apiService.buildPrintApiURL('print/'+data.printId);
                
                $scope.oConfig.bDownloadReady = true;
            }
        })
        
    };

    $scope.downloadImage = function () {

        //automate download pptx
        var a = document.createElement('a');
        a.href = $scope.src;
        document.body.appendChild(a);
        a.click();
    }

    $scope.update = function () {
        $uibModalInstance.close();
    };

    $scope.closePopup = function () {
        $uibModalInstance.dismiss()
    };

    $scope.init()

}]);
