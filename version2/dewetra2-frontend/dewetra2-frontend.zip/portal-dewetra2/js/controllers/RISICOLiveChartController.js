/**
 * Created by Mirko on 14/09/17.
 */

function getWindDirection(dir) {
    if ((dir >= 11.25) && (dir < 33.75)) return 'NNE';
    else if ((dir >= 33.75) && (dir < 56.25)) return 'NE';
    else if ((dir >= 56.25) && (dir < 78.75)) return 'ENE';
    else if ((dir >= 78.75) && (dir < 101.25)) return 'E';
    else if ((dir >= 101.25) && (dir < 123.75)) return 'ESE';
    else if ((dir >= 123.75) && (dir < 146.25)) return 'SE';
    else if ((dir >= 146.25) && (dir < 168.75)) return 'SSE';
    else if ((dir >= 168.75) && (dir < 191.25)) return 'S';
    else if ((dir >= 191.25) && (dir < 213.75)) return 'SSW';
    else if ((dir >= 213.75) && (dir < 236.25)) return 'SW';
    else if ((dir >= 236.25) && (dir < 258.75)) return 'WSW';
    else if ((dir >= 258.75) && (dir < 281.25)) return 'W';
    else if ((dir >= 281.25) && (dir < 303.75)) return 'WNW';
    else if ((dir >= 303.75) && (dir < 326.25)) return 'NW';
    else if ((dir >= 326.25) && (dir < 348.75)) return 'NNW';
    else return 'N';

}

function showRISICOLiveChart(sensorInfo, dtFrom, dtTo, iChartHeight, thresholdService, translate, objExtremes) {
    //var hourRange = 24;
    var chart = null;
    var rangeSelected = 2;

    var translate = {};
    translate.instant = function(v){return v;};

    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.StockChart({

            chart:{
                renderTo: 'chart',
                //marginTop: 25,
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },

            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' +
                            translate.instant('ORE') + ' ' + moment.utc(this.x/1000, 'X').format('HH:mm') +
                            '</div><br>';

                    this.points.forEach(function(item){
                        s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: #FF0000">' +
                            $('<div>' + sensorInfo.type + ' = ' + item.y.toFixed(2) + ' [' + sensorInfo.units + ']</div>').html() + '</div><br>';
                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: sensorInfo.type!=='wind'?[
                {
                    name: '',
                    type: 'line',
                    color: 'black',
                    threshold: null,
                    data: [],
                    showInLegend: true
                }
            ]:[
                {
                    name: 'speed',
                    type: 'line',
                    color: 'black',
                    data: [],
                    showInLegend: true
                },
                {
                    name: 'direction',
                    type:  'scatter',
                    color: 'transparent',
                    data: [],
                    showInLegend: false
                }
            ],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                }

            },
            navigator: {
                series: {
                    type: 'area',
                    fillOpacity: 0.3
                },
                enabled : true

            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                ordinal: false,
                type: 'datetime',
                range:  24 * 3600 * 1000,                                    // one day
                minRange: 1 * 3600 * 1000,                                   // one hour
                tickPixelInterval: 50,
                minorTickInterval: 'auto',
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    },
                    formatter: function () {
                        var oDate = new Date(this.value);
                        if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                            return '<b>' + Highcharts.dateFormat('%d %b', this.value) + '</b>';
                        else
                            return Highcharts.dateFormat('%H:%M', this.value);
                    }

                },
                plotLines: [
                    {
                        color: 'rgba(69, 163, 202, 1)', // Color value
                        dashStyle: 'Solid',             // Style of the plot line. Default to solid
                        value: new Date().getTime(),    // Value of where the line will appear
                        width: '2',                     // Width of the line
                        zIndex: 4
                    }
                ],
                events: {

                    setExtremes: function(e) {

                        if (e.rangeSelectorButton) {

                            var c = e.rangeSelectorButton.count;

                            if (c == 3) {
                                rangeSelected = 0;
                            } else if (c == 12) {
                                rangeSelected = 1;
                            } else {
                                rangeSelected = 2;
                            }
                        }
                    }
                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: false,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                scatter: {
                    marker: {
                        enabled: true,
                        radius: 1
                    },
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {

                buttonTheme: { // styles for the buttons
                    width: 50,
                    fill: 'none',
                    stroke: 'none',
                    'stroke-width': 0,
                    r: 3,
                    style: {
                        fontWeight: 'bold',
                        fontSize: '12px',
                        fontFamily: 'Open Sans',
                    },
                    states: {
                        hover: {},
                        select: {
                            fill: '#525052',
                            style: {
                                color: 'white'
                            }
                        }
                    }
                },

                buttons: [{
                    type: 'hour',
                    count: 3,
                    text: 'Last 3h'
                }, {
                    type: 'hour',
                    count: 12,
                    text: 'Last 12h'
                },{
                    type: 'hour',
                    count: 24,
                    text: 'Last 24h'
                },{
                    type: 'all',
                    text: 'All'
                }],

                inputEnabled: false,
                enabled: true
            },
            yAxis: {
                title: {
                    text: sensorInfo.type + ' (' + sensorInfo.units + ')'
                },
                plotBands: sensorInfo.plotBands
            },

            loading: true
        });

        var orgHighchartsRangeSelectorPrototypeRender = Highcharts.RangeSelector.prototype.render;
        Highcharts.RangeSelector.prototype.render = function (min, max) {
            orgHighchartsRangeSelectorPrototypeRender.apply(this, [min, max]);

            var leftPosition = this.chart.plotLeft,
                topPosition = this.chart.plotTop - 50,
                space = 5;

            this.zoomText.attr({
                text: ''
            });

            for (var i = 0; i < this.buttons.length; i++) {
                this.buttons[i].attr({
                    x: leftPosition,
                    y: topPosition
                });
                leftPosition += this.buttons[i].width + space;
            }

        };

    };

    if (!sensorInfo) return;
    initChart();
    //setto i due oggetti per modificare i dati e le label
    var seriesArray = chart.series;

    var items = [];
    if(sensorInfo.type === 'wind') {
        var wdir_items = [];
    }

    if (sensorInfo.timeline) {
        for (var i = 0; i < sensorInfo.timeline.length; i++) {
            var date = moment.utc(sensorInfo.timeline[i]).valueOf();
            var v = sensorInfo.values[i];
            if(sensorInfo.type === 'wind') {
                if (
                    !isNaN(v[0]) && (v[0] > -9998) &&
                    !isNaN(v[1])
                ) {
                    items.push([date, v[0]]);
                    wdir_items.push({
                        x:date, y:-1, rotate: v[1],
                        marker:{
                            symbol:
                                'url(portals/commons/img/variabili/windir_'+ getWindDirection(v[1])+'.svg)',
                            width:15,
                            height : 15
                        }
                    });
                }
            }else{
                if (!isNaN(v) && (v > -9998)) {
                    items.push([date, v]);
                }
            }
        }
    }

    var dtMin = moment.utc(sensorInfo.timeline[0]).valueOf();
    var dtMax = moment.utc(sensorInfo.timeline[sensorInfo.timeline.length - 1]).valueOf();

    if (sensorInfo.type === 'wind'){
        seriesArray[0].id = 'wind';
        seriesArray[0].setData(items);
        seriesArray[0].update({
            title: {
                rotation: 270,
                margin: 0,
                offset: 45,
                useHTML:true,
                text: '<p style="color:black">' + translate.instant(sensorInfo.type) + ' [' + sensorInfo.units + ']</p>',
                style: {
                    fontWeight : 'bold',
                    fontFamily: 'Open Sans'
                }
            },
            name: translate.instant(sensorInfo.type) + ' [' + sensorInfo.units + ']',
            type: 'line'
        }, false);

        seriesArray[1].id = 'direction';
        seriesArray[1].setData(wdir_items);
        seriesArray[1].update({
            title: {
                rotation: 270,
                margin: 0,
                offset: 45,
                useHTML:true,
                style: {
                    fontWeight : 'bold',
                    fontFamily: 'Open Sans'
                }
            }
        }, false);

        chart.yAxis[0].setExtremes(-2);

    }else{
        seriesArray[0].id = sensorInfo.type;
        seriesArray[0].setData(items);
        seriesArray[0].update({
            title: {
                rotation: 270,
                margin: 0,
                offset: 45,
                useHTML:true,
                text: '<p style="color:black">' + translate.instant(sensorInfo.type) + ' [' + sensorInfo.units + ']</p>',
                style: {
                    fontWeight : 'bold',
                    fontFamily: 'Open Sans'
                }
            },
            name: translate.instant(sensorInfo.type) + ' [' + sensorInfo.units + ']',
            type: sensorInfo.chart_type
        }, false);

        chart.xAxis[0].setExtremes(dtMin, dtMax);
        if(sensorInfo.min_max_y) {
            chart.yAxis[0].setExtremes(sensorInfo.min_max_y[0], sensorInfo.min_max_y[1]);
        }
    }

    chart.hideLoading();

    return {
        chart : chart
    }

}



dewetraApp.controller('RISICOLiveChartController', ['$scope', '$uibModal', '$uibModalInstance', '$translate', 'stationInfo', 'menuService', 'serieService','_', '$timeout', '$rootScope',function($scope, $uibModal, $uibModalInstance, $translate, stationInfo, menuService, serieService,_, $timeout, $rootScope) {
    console.log('risico chart controller.');
    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    });

    addDownloadChartOption();

    $scope.chart = null;

    $scope.stationData = {};

    var service = stationInfo.RISICOLiveService;
    getRISICOLiveData(stationInfo);

    $scope.reloadButton = {
        enabled : true,
        reload : function () {
            for (var i = 0; i < $scope.stationData.length; i++) {
                if ($scope.stationData[i].active) {
                    showChart($scope.stationData[i]);
                    return;
                }
            }
        }
    };

    $scope.stationDataChanged = function(stationData) {
        toggleData(stationData.type);
        showChart(stationData);
    };

    $scope.loadCurrent = function(){
      updateData(stationInfo.id_centr, stationInfo.from, stationInfo.to);
    };

    $scope.closePopup = function() {
        $uibModalInstance.close();
    };

    function updateData(id_centr, from, to){
        $scope.isLoading = true;
        service
            .getStationTimeseries(id_centr, from, to)
            .then(function (data) {
                if (data.length == 0) {
                    alert($translate.instant('UNAVAILABLE_DATA'));
                    return;
                }

                var sd;
                for(var type in data){
                    if(!(type in stationInfo.variables)){
                        continue;
                    }
                    if(type!=='date'){
                        if (type==='ws' || type==='wd'){
                            type = 'wind';
                        }

                        var values;

                        if (type==='wind'){
                            var wd = data['wd'];
                            var ws = data['ws'];
                            values = [];
                            for(var i=0; i<ws.length; i++){
                                values.push([ws[i], wd[i]])
                            }
                        }else {
                            values = data[type];
                        }

                        var active = $scope.stationData[type] ? $scope.stationData[type].active:false;
                        var sd = {
                            active: active,
                            type: type,
                            values: values,
                            timeline: data['date'],
                            min_max_y: stationInfo.variables[type].min_max_y,
                            plotBands: stationInfo.variables[type].plotBands,
                            units: stationInfo.variables[type].units,
                            chart_type: stationInfo.variables[type].chart_type,
                            group: stationInfo.variables[type].group||'output',
                        };
                        $scope.stationData[type] = sd;
                    }
                }
            }).then(function(){
                var type;
                if (!$scope.currentType) {
                    type = stationInfo.props.variable.typeSelected.value;
                }else{
                    type = $scope.currentType;
                }
                toggleData(type);
                showChart($scope.stationData[type]);
                $scope.chartTitle = $translate.instant(stationInfo.name);

        }).catch(function(err) {
            alert($translate.instant('ERROR_LOADING_DATA') + ': ' + err.error_message);
        }).then(function(){
            $scope.isLoading = false;
        })
    }

    function getRISICOLiveData(s) {
        updateData(s.id_centr, s.from, s.to)
    }

    function showChart(data) {
        setTimeout(function() {
            $scope.chart =
                showRISICOLiveChart(data,
                    menuService.oChartSize.m_iFloodProofsChartHeight(),
                    $translate, null
                );
        }, 0);

    }

    function toggleData(type) {
        $scope.currentType = type;
        for (var key in $scope.stationData) {
            // skip loop if the property is from prototype
            if (!$scope.stationData.hasOwnProperty(key)) continue;
            $scope.stationData[key].active = ($scope.stationData[key].type === type);
        }
    }

    $scope.chartTitleFormatter = function (descr) {
        return descr.toUpperCase().trim().replace(/ /g,"_");
    };

    $timeout(function(){
        $('#daterange').daterangepicker({
            showDropdowns: true,
            startDate: stationInfo.dateFrom,
            endDate: stationInfo.dateTo,
            timePicker24Hour: true,
            timePicker: true,
            opens: "center",
            drops: "up",
            locale: {
                format: 'DD/MM/YYYY hh:mm'
            }
        }, function(start, end) {
            updateData(stationInfo.id_centr, start, end);
        });

    }, 500);


}]);


