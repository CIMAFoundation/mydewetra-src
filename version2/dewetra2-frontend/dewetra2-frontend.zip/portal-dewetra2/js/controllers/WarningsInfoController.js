/**
 * Created by Dario Rubado on 26/11/15.
 */

dewetraApp.controller("WarningsInfoController", ['$scope','$rootScope','thresholdService', '_', '$timeout', 'sentinelService', '$uibModal', '$translate', 'menuService',function ($scope,$rootScope,thresholdService, _, $timeout, sentinelService, $uibModal, $translate, menuService) {
    $scope.isString = angular.isString;

    var debug = menuService.debug;

    $scope.oWarningData = {
        pluvio : [],
        raingauge : [],
        thermo : [],
        hydro : [],
        others : [],
        FloodProofsDeterministic:[],
        FloodProofsDeterministicEfforts:[],
        FloodProofsProbabilistic:[],
        FloodProofs:[],
        FLOODIS:[],
        FEWS:[],
        CAPS2:[],
        BULLETIN_HYDRO:[],
        HYGROMETER:[],
        WIND:[],
        rasor_damage:[],
        phenological_analysis:[],
        geocradle_soil_analysis:[],
        autpor:[],
        SFLOC:[],
        GDACS:[],
        COAU:[],
        FLOOD_CAT:[],
        SENSOR_GENERIC:[],
        NIVOMETER:[],
        DESINVENTAR:[],
        SENSOR_FLOODPROOF_SERIES:[],
        9:[],
        GENERIC:[],

    };

    $scope.mouseOver= false;

    $scope.setMouseOverFalse = function () {
        $scope.mouseOver = false

        $scope.oWarningData[$scope.warningType]= []
    };

    $scope.showChart = function () {

        var modalInstance = $uibModal.open({

            templateUrl: 'apps/dewetra2/views/sensor_chart_form.html',
            controller: 'sensorChartController',
            size: 'lg',
            keyboard: false,
            resolve: {

                sensorData: function () {

                    var featureData = $scope.featureProperties;

                    return {
                        sensorId : featureData.sensorid,
                        dbId : featureData.dbid,
                        properties: featureData,
                        from:"warning_pluvio",
                        sensorClass : 2
                    };

                }

            }
        });
    },

    $scope.oWarningInfo = {
        active: function(){
            // if ($scope.oWarningData.thermo.length>0||$scope.oWarningData.pluvio.length>0||$scope.oWarningData.others.length>0||$scope.oWarningData.hydro.length>0){
            //     return true;
            // }else return false
        },
        mouseOver: function (warningType, layerId, featureProperties, oDictPalette) {

            console.log(warningType)

            //manager popup
            var obj= null;

            $scope.warningType = warningType;

            $scope.featureProperties = featureProperties;

            for(var prop in $scope.oWarningData[warningType]){
                if (prop.id == layerId){
                    obj = prop;
                    break;
                }
            }
            if(obj != null){
                obj.properties = featureProperties
            }else{
                $scope.oWarningData[warningType] ={
                    id: layerId,
                    properties : featureProperties
                }
            }
            $scope.warningType = warningType;

            //build popup data
            if ($scope.fBuildDataAndThreshold[warningType].buildSensorData) $scope.fBuildDataAndThreshold[warningType].buildSensorData(featureProperties);
            //build popup Trheshold
            if($scope.fBuildDataAndThreshold[warningType].buildSensorThreshold)$scope.fBuildDataAndThreshold[warningType].buildSensorThreshold(featureProperties, oDictPalette)



        },
        mouseOut: function (warningType, layerId) {

            if($scope.mouseOver) return

            $scope.oWarningData[warningType]= []

        }
    };
    $scope.fBuildDataAndThreshold={
        9:{
            buildSensorData:function (data) {
                if (debug)console.table(data);
            },
            buildSensorThreshold:function () {

            }
        },
        pluvio:{
            buildSensorData : function (data, callBack) {
                if (debug)console.table(data);
                var start = false;
                var aData = [];

                for(var prop in data){
                    if (stringStartsWith(prop, "v_")){
                        start = true
                    }
                }
                if(start){
                    for(var prop in data){
                        if (stringStartsWith(prop, "v_")){
                            var aValue = prop.split("_");
                            var sTimeStamp = moment.unix(aValue[1]);
                            var sPeriod = parseInt(aValue[2])/3600;//transform in hour
                            var nValue =data[prop];

                            var oValue = {
                                timeStamp: sTimeStamp,
                                period : sPeriod,
                                valore: nValue,
                                color: (parseFloat(nValue) > 0)?'#00FF00':'#FFFFFF'
                            };
                            aData.push(oValue)
                        }
                    }
                    aData = _.sortBy(aData, 'timeStamp');
                    //arrai valori costruito per visualizzazione
                    $scope.oWarningData[$scope.warningType].dataView = aData;
                }


                //comune provincia regione
                sentinelService.getSensorInfo(data.sensorid, data.dbid,
                    function(sensorInfo){
                        //informazioni sensore  comune etc
                        $scope.oWarningData[$scope.warningType].sensorInfo = sensorInfo
                    },
                    function(err){
                        console.log("error Sentinel service")
                    })

            },
            buildSensorThreshold : function (featureProperties,  oDictPalette, callback) {
                var start = false;

                var thresholdView = [];
                for(var prop in featureProperties){
                    if (stringStartsWith(prop, "e_")){
                        start = true
                    }
                }

                if (start){
                    thresholdService.getNationalThreshold(featureProperties, function (aSensorThreshold) {
                        //constuisco proprieta threshold dell threshold object
                        for(var prop in featureProperties){
                            if (stringStartsWith(prop, "e_")){
                                var aSoglia = prop.split("_");
                                if (debug)console.table(aSensorThreshold)
                                var aSoglie = _.where(aSensorThreshold, {id: parseInt(aSoglia[1])});
                                if (debug)console.table(aSoglie[0])
                                var oSoglia = {
                                    id: aSoglia[1],
                                    warn_index : parseInt(aSoglia[2]),
                                    valore: parseInt(featureProperties[prop]),
                                    period:aSoglie[0].period/3600,
                                    thresholdValueMin : _.where(aSoglie,{type: "diff-"}),
                                    thresholdValueMax : _.where(aSoglie,{type: "diff+"})
                                };
                                thresholdView.push(oSoglia)
                            }
                        }

                        //filtro le soglie per period cosi le confronto con i valori e vedo cosa è stato superato
                        var threshold = _.groupBy(thresholdView, function (thr) {
                            return thr.period
                        });
                        //coloro i valori a seconda delle soglie superate
                        $scope.oWarningData[$scope.warningType].dataView.forEach(function(oData){
                            if(threshold[oData.period]){
                                oData["color"] = oDictPalette[threshold[oData.period].length]
                            }else {
                                oData["color"] = oDictPalette[(oData.valore == 0)?-1:0];
                            }
                        });

                        //array Soglie superate
                        $scope.oWarningData[$scope.warningType].thresholdView = thresholdView
                    })
                }
            }
        },
        raingauge:{
            buildSensorData : function (data, callBack) {
                // if (debug)console.table(data);
                var start = false;
                var aData = [];

                for(var prop in data){
                    if (stringStartsWith(prop, "v_")){
                        start = true
                    }
                }
                if(start){
                    for(var prop in data){
                        if (stringStartsWith(prop, "v_")){
                            var aValue = prop.split("_");
                            var sTimeStamp = moment.unix(aValue[1]);
                            var sPeriod = parseInt(aValue[2])/3600;//transform in hour
                            var nValue =data[prop];

                            var oValue = {
                                timeStamp: sTimeStamp,
                                period : sPeriod,
                                valore: nValue
                            };
                            aData.push(oValue)
                        }
                    }
                    aData = _.sortBy(aData, 'timeStamp');
                    //arrai valori costruito per visualizzazione
                    $scope.oWarningData[$scope.warningType].dataView = aData;
                }


                //comune provincia regione
                sentinelService.getSensorInfo(data.sensorid, data.dbid,
                    function(sensorInfo){
                        //informazioni sensore  comune etc
                        $scope.oWarningData[$scope.warningType].sensorInfo = sensorInfo
                    },
                    function(err){
                        console.log("error Sentinel service")
                    })

            },
            // buildSensorThreshold : function (featureProperties,  oDictPalette, callback) {
            //     var start = false;
            //
            //     var thresholdView = [];
            //     for(var prop in featureProperties){
            //         if (stringStartsWith(prop, "e_")){
            //             start = true
            //         }
            //     }
            //
            //     if (start){
            //         thresholdService.getNationalThreshold(featureProperties, function (aSensorThreshold) {
            //             //constuisco proprieta threshold dell threshold object
            //             for(var prop in featureProperties){
            //                 if (stringStartsWith(prop, "e_")){
            //                     var aSoglia = prop.split("_");
            //                     var aSoglie = _.where(aSensorThreshold, {id: parseInt(aSoglia[1])});
            //                     var oSoglia = {
            //                         id: aSoglia[1],
            //                         warn_index : parseInt(aSoglia[2]),
            //                         valore: parseInt(featureProperties[prop]),
            //                         period:aSoglie[0].period/3600,
            //                         thresholdValueMin : _.where(aSoglie,{type: "diff-"}),
            //                         thresholdValueMax : _.where(aSoglie,{type: "diff+"})
            //                     };
            //                     thresholdView.push(oSoglia)
            //                 }
            //             }
            //
            //             //filtro le soglie per period cosi le confronto con i valori e vedo cosa è stato superato
            //             var threshold = _.groupBy(thresholdView, function (thr) {
            //                 return thr.period
            //             });
            //             //coloro i valori a seconda delle soglie superate
            //             $scope.oWarningData[$scope.warningType].dataView.forEach(function(oData){
            //                 if(threshold[oData.period]){
            //                     oData["color"] = oDictPalette[threshold[oData.period].length]
            //                 }else oData["color"] = oDictPalette["-1"]
            //             });
            //
            //             //array Soglie superate
            //             $scope.oWarningData[$scope.warningType].thresholdView = thresholdView
            //         })
            //     }
            // }
        },
        thermo:{
            buildSensorData : function (data, callBack) {
                var start = false;
                var aData = [];

                for(var prop in data){
                    if (stringStartsWith(prop, "v_")){
                        start = true
                    }
                }
                if(start){
                    for(var prop in data){
                        if (stringStartsWith(prop, "v_")){
                            var aValue = prop.split("_");
                            var sTimeStamp = moment.unix(aValue[1]);
                            var sPeriod = parseInt(aValue[2])/3600;
                            var nValue =data[prop];

                            var label =(sPeriod == 0)?'LAST'+ sPeriod.toString()+"H":'MEAN'+ sPeriod.toString()+"H";

                            var oValue = {
                                timeStamp: sTimeStamp,
                                period : sPeriod,
                                label : label,
                                valore: nValue
                            };
                            aData.push(oValue)
                        }
                    }
                    //ordino per data
                    aData = _.sortBy(aData, 'timeStamp').reverse();
                    //arrai valori costruito per visualizzazione
                    $scope.oWarningData[$scope.warningType].dataView = aData;
                }
                //comune provincia regione
                sentinelService.getSensorInfo(data.sensorid, data.dbid,
                    function(sensorInfo){
                        //aData.push(sensorInfo);
                        //if(callBack) callBack(aData, sensorInfo);

                        $scope.oWarningData[$scope.warningType].sensorInfo = sensorInfo
                    },
                    function(err){
                        console.log("error Sentinel service")
                    })

            },
            buildSensorThreshold : function (featureProperties, oDictPalette) {
                var start = false;

                var thresholdView = [];
                for(var prop in featureProperties){
                    if (stringStartsWith(prop, "ei_")){
                        start = true
                    }
                }
                start = false;
                if (start){
                    thresholdService.getNationalThreshold(featureProperties, function (aSensorThreshold) {
                        //constuisco proprieta threshold dell threshold object
                        for(var prop in featureProperties){
                            if (stringStartsWith(prop, "ei_")){
                                var aSoglia = prop.split("_");
                                var aSoglie = _.where(aSensorThreshold, {id: parseInt(aSoglia[1])});
                                var oSoglia = {
                                    id: aSoglia[1],
                                    warn_index : parseInt(aSoglia[2]),
                                    valore: parseInt(featureProperties[prop]),
                                    period:aSoglie[0].period/3600,
                                    color : oDictPalette[featureProperties.warning_palette]
                                };
                                thresholdView.push(oSoglia)
                            }
                        }

                        //var threshold= _.groupBy(thresholdView, function (thr) {return thr.period})
                        //coloro le soglie

                        //$scope.oWarningData[$scope.warningType].dataView.forEach(function(oData){
                        //    if(threshold[oData.period]){
                        //        oData["color"] = oDictPalette[threshold[oData.period].length]
                        //    }else oData["color"] = oDictPalette["-1"]
                        //});

                        $scope.oWarningData[$scope.warningType].thresholdView = thresholdView
                    })
                }

            }
        },
        hydro:{
            buildSensorData : function (data, callBack) {
                var start = false;
                var aData = [];

                for(var prop in data){
                    if (stringStartsWith(prop, "v_")){
                        start = true;
                        break;
                    }
                }
                if(start){
                    for(var prop in data){
                        if (stringStartsWith(prop, "v_")){
                            var aValue = prop.split("_");
                            var sTimeStamp = moment.unix(aValue[1]);
                            var sPeriod = parseInt(aValue[2])/3600;
                            var nValue =data[prop];

                            var oValue = {
                                timeStamp: sTimeStamp,
                                period : sPeriod,
                                valore: nValue,
                                sensormu:data['sensormu']
                            };
                            aData.push(oValue)
                        }
                    }
                    aData = _.sortBy(aData, 'period');
                    //arrai valori costruito per visualizzazione

                    $scope.oWarningData[$scope.warningType].dataView = aData;
                }
                //return aData;

                //comune provincia regione
                sentinelService.getSensorInfo(data.sensorid, data.dbid,
                    function(sensorInfo){
                        $scope.oWarningData[$scope.warningType].sensorInfo = sensorInfo
                    },
                    function(err){
                        console.log("error Sentinel service")
                    })

            },
            buildSensorThreshold : function (featureProperties, oDictPalette) {
                var start = false;

                var thresholdView = [];
                //for(var prop in featureProperties){
                //    if (stringStartsWith(prop, "e_")){
                //        start = true
                //    }
                //}



                start = true;
                if (start){
                    thresholdService.getNationalThreshold(featureProperties, function (aSensorThreshold) {
                        //console.log("stop")

                        for(var prop in featureProperties){
                            if (stringStartsWith(prop, "e_")){
                                var aSoglia = prop.split("_");
                                var aSoglie = _.where(aSensorThreshold, {severity: parseInt(aSoglia[2])});

                                if (parseInt(aSoglia[2]) == 0){
                                    aSoglie[0].color = oDictPalette[5];
                                }else{
                                    aSoglie[0].color = oDictPalette[parseInt(aSoglia[2])];
                                }
                            }
                        }

                        if(aSensorThreshold.length >0 && featureProperties.sensormu=="cm"){
                            aSensorThreshold.forEach(function (obj) {
                                obj.value = parseInt(obj.value*100);
                            })
                        }

                        $scope.oWarningData[$scope.warningType].thresholdView = aSensorThreshold;

                        //constuisco proprieta threshold dell threshold object
                        //for(var prop in featureProperties){
                        //    if (stringStartsWith(prop, "e_")){
                        //        var aSoglia = prop.split("_");
                        //        var aSoglie = _.where(aSensorThreshold,{severity: parseInt(aSoglia[2])})
                        //        var oSoglia = {
                        //            id: aSoglia[1],
                        //            warn_index : parseInt(aSoglia[2]),
                        //            valore: parseInt(featureProperties[prop]),
                        //            color: oDictPalette[parseInt(aSoglia[2])],
                        //            thresholdValue : _.findWhere(aSensorThreshold,{severity: parseInt(aSoglia[2])})
                        //        }
                        //        thresholdView.push(oSoglia)
                        //    }
                        //}
                        //per la soglia azzurra
                        //if (thresholdView.length == 1 && thresholdView[0].warn_index == 0)thresholdView[0].color = oDictPalette[5]
                        //popolo la vista
                        //$scope.oWarningData[$scope.warningType].thresholdView = thresholdView
                    })
                }
            }
        },
        FloodProofsDeterministic:{
            buildSensorData : function (feature, oDictPalette, callBack) {

                var value = feature.maxvalue;

                //Creo array soglie
                var aThreshold = [];
                for(prop in feature){
                    if((stringStartsWith(prop, "Q_ALLARME"))||(stringStartsWith(prop, "Q_ALLERTA"))){
                        if (feature[prop] != -9999 && feature[prop] != 0 ){
                            var obj = {
                                thresholdValue : parseFloat(feature[prop]),
                                name: prop,
                                exceded : (value > feature[prop])?true:false
                            };
                            aThreshold.push(obj)
                        }
                    }
                }

                var superati = _.filter(aThreshold, function(obj){
                    return obj.exceded
                });
                var color;
                switch(aThreshold.length){
                    case 0:
                        color= "grey";
                    case 1:
                        (superati.length == 1) ? color = "red" : color = null;
                        if (superati.length == 0){
                            feature.trend > 0?color = "green":color = "white"
                        }
                    case 2:
                        if (superati.length == 1)color = "yellow";
                        if (superati.length == 2)color = "red";
                        if (superati.length == 0){
                            feature.trend > 0?color = "green":color = "white"
                        }
                }
                var obj = {
                    feature: feature,
                    aThreshold: aThreshold,
                    aSuperamenti : superati,
                    color: color
                };
                console.log(obj);
                //if (callBack)callBack(obj);
                $scope.oWarningData[$scope.warningType].dataView = obj;

            }
        },
        FloodProofsDeterministicEfforts:{
            buildSensorData : function (feature, oDictPalette, callBack) {

                var value = feature.maxvalue;
                var asTrhresholds = ["THR1","THR2","THR3","THR4"];
                //Creo array soglie
                var aThreshold = [];
                for(var prop in feature){
                    if(asTrhresholds.indexOf(prop)>-1){
                        if (feature[prop] != -9999 && feature[prop] != 0 ){
                            var obj = {
                                thresholdValue : feature[prop],
                                name: prop,
                                exceded : (value > feature[prop])?true:false
                            };
                            aThreshold.push(obj)
                        }
                    }
                }

                var superati = _.filter(aThreshold, function(obj){
                    return obj.exceded
                });
                var color;
                switch(aThreshold.length){
                    case 0:
                        color= "grey";
                    case 1:
                        (superati.length == 1) ? color = "red" : color = null;
                        if (superati.length == 0){
                            feature.trend > 0?color = "green":color = "white"
                        }
                    case 2:
                        if (superati.length == 1)color = "yellow";
                        if (superati.length == 2)color = "red";
                        if (superati.length == 0){
                            feature.trend > 0?color = "green":color = "white"
                        }
                }
                var obj = {
                    feature: feature,
                    aThreshold: aThreshold,
                    aSuperamenti : superati,
                    color: color
                };
                //if (callBack)callBack(obj);
                $scope.oWarningData[$scope.warningType].dataView = obj;

            }
        },
        FloodProofsProbabilistic:{
            buildSensorData : function (feature, oDictPalette, callBack) {

                if (debug)console.table(feature)

                var value = feature.maxvalue;

                //Creo array soglie
                var aThreshold = [];
                for(prop in feature){
                    if((stringStartsWith(prop, "Q_ALLARME"))||(stringStartsWith(prop, "Q_ALLERTA"))){
                        if (feature[prop] != -9999 && feature[prop] != 0 ){
                            var obj = {
                                thresholdValue : parseFloat(feature[prop]),
                                name: prop,
                                exceded : (value > feature[prop])?true:false
                            };
                            aThreshold.push(obj)
                        }
                    }
                }


                if(feature.maxvalue == '-7777'||feature.maxvalue == '-6666'||feature.maxvalue == '-5555'){
                    feature.showInfoMessage =$translate.instant(feature.maxvalue);
                }

                var superati = _.filter(aThreshold, function(obj){
                    return obj.exceded
                });
                var color;
                switch(aThreshold.length){
                    case 0:
                        color= "grey";
                    case 1:
                        (superati.length == 1) ? color = "red" : color = null;
                        if (superati.length == 0){
                            feature.trend > 0?color = "green":color = "white"
                        }
                    case 2:
                        if (superati.length == 1)color = "yellow";
                        if (superati.length == 2)color = "red";
                        if (superati.length == 0){
                            feature.trend > 0?color = "green":color = "white"
                        }
                }
                var obj = {
                    feature: feature,
                    aThreshold: aThreshold,
                    aSuperamenti : superati,
                    color: color
                };
                // if (debug)console.table(obj)
                $scope.oWarningData[$scope.warningType].dataView = obj;
                //if (callBack)callBack(obj);

            }
        },
        FloodProofs:{
            buildSensorData :function (feature, oDictPalette, callBack){

                //Creo array soglie
                var aThreshold = [];
                for(prop in feature){
                    if((stringStartsWith(prop, "Q_ALLARME"))||(stringStartsWith(prop, "Q_ALLERTA"))){
                        if (feature[prop] != -9999 && feature[prop] != 0 ){
                            var obj = {
                                thresholdValue : parseFloat(feature[prop]),
                                name: prop
                            };
                            aThreshold.push(obj)
                        }
                    }
                }

                var obj = {
                    feature: feature,
                    aThreshold: aThreshold,
                };

                $scope.oWarningData[$scope.warningType].dataView = obj;

            }
        },
        FLOODIS:{

          buildSensorData:function (feature) {
              console.log(feature.thumbURL)
              //https://floodis.blob.core.windows.net/file-storage/201610180741389022.png

              $scope.oWarningData[$scope.warningType].dataView = feature;
          }
        },
        FEWS: {

            buildSensorData:function (feature) {

                $scope.oWarningData[$scope.warningType].dataView = feature;

            }
        },
        CAPS2: {

            buildSensorData:function (feature) {

                $scope.oWarningData[$scope.warningType].dataView = feature;

            }
        },

        BULLETIN_HYDRO: {

            buildSensorData:function (feature) {

                var list = angular.copy(feature)

                var level_name = {
                    0:"Assente",
                    1:"Ordinaria",
                    2:"Moderata",
                    3:"Elevata"
                }

                for(var p in list){
                    if (p.indexOf("crit")>-1){
                        list[p] = level_name[list[p]];
                    }
                }
                var methodName = list.map_id+"_day";
                list.date_map =list.bulletin[methodName];


                $scope.oWarningData[$scope.warningType].dataView = list;

            }
        },

        HYGROMETER: {

            buildSensorData:function (feature) {

                $scope.oWarningData[$scope.warningType].dataView = feature;

            }
        },

        WIND: {
            buildSensorData : function (data, callBack) {
                var start = false;
                var aData = [];

                for(var prop in data){
                    if (stringStartsWith(prop, "v_")){
                        start = true
                    }
                }
                if(start){
                    for(var prop in data){
                        if (stringStartsWith(prop, "v_")){
                            var aValue = prop.split("_");
                            var sTimeStamp = moment.unix(aValue[1]);
                            var sPeriod = parseInt(aValue[2])/3600;//transform in hour
                            var nValue =data[prop];

                            var oValue = {
                                timeStamp: sTimeStamp,
                                period : sPeriod,
                                valore: nValue,
                                sensormu : data.sensormu
                            };
                            aData.push(oValue)
                        }
                    }
                    for(var prop in data.speed){
                        if (stringStartsWith(prop, "v_")){
                            var aValue = prop.split("_");
                            var sTimeStamp = moment.unix(aValue[1]);
                            var sPeriod = parseInt(aValue[2])/3600;//transform in hour
                            var nValue =data.speed[prop];

                            var oValue = {
                                timeStamp: sTimeStamp,
                                period : sPeriod,
                                valore: nValue,
                                sensormu : data.speed.sensormu
                            };
                            aData.push(oValue)
                        }
                    }

                    aData = _.sortBy(aData, 'timeStamp');
                    //arrai valori costruito per visualizzazione
                    $scope.oWarningData[$scope.warningType].dataView = aData;
                }


                //comune provincia regione
                sentinelService.getSensorInfo(data.sensorid, data.dbid,
                    function(sensorInfo){
                        //informazioni sensore  comune etc
                        $scope.oWarningData[$scope.warningType].sensorInfo = sensorInfo
                    },
                    function(err){
                        console.log("error Sentinel service")
                    })

            },
            buildSensorThreshold : function (featureProperties,  oDictPalette, callback) {
            //     var start = false;
            //
            //     var thresholdView = [];
            //     for(var prop in featureProperties){
            //         if (stringStartsWith(prop, "e_")){
            //             start = true
            //         }
            //     }
            //
            //     if (start){
            //         thresholdService.getNationalThreshold(featureProperties, function (aSensorThreshold) {
            //             //constuisco proprieta threshold dell threshold object
            //             for(var prop in featureProperties){
            //                 if (stringStartsWith(prop, "e_")){
            //                     var aSoglia = prop.split("_");
            //                     var aSoglie = _.where(aSensorThreshold, {id: parseInt(aSoglia[1])});
            //                     var oSoglia = {
            //                         id: aSoglia[1],
            //                         warn_index : parseInt(aSoglia[2]),
            //                         valore: parseInt(featureProperties[prop]),
            //                         period:aSoglie[0].period/3600,
            //                         thresholdValueMin : _.where(aSoglie,{type: "diff-"}),
            //                         thresholdValueMax : _.where(aSoglie,{type: "diff+"})
            //                     };
            //                     thresholdView.push(oSoglia)
            //                 }
            //             }
            //
            //             //filtro le soglie per period cosi le confronto con i valori e vedo cosa è stato superato
            //             var threshold = _.groupBy(thresholdView, function (thr) {
            //                 return thr.period
            //             });
            //             //coloro i valori a seconda delle soglie superate
            //             $scope.oWarningData[$scope.warningType].dataView.forEach(function(oData){
            //                 if(threshold[oData.period]){
            //                     oData["color"] = oDictPalette[threshold[oData.period].length]
            //                 }else oData["color"] = oDictPalette["-1"]
            //             });
            //
            //             //array Soglie superate
            //             $scope.oWarningData[$scope.warningType].thresholdView = thresholdView
            //         })
            //     }
             }
        },

        rasor_damage:{
            buildSensorData:function (feature) {
                var dataToShow= [];

                for( var p in feature.properties){
                    if(p.indexOf("_value")>-1){
                        dataToShow.push({
                            value : parseInt(feature.properties[p]),
                            label : p
                        })
                    }
                }


                $scope.oWarningData[$scope.warningType].feature = feature;
                $scope.oWarningData[$scope.warningType].dataView = dataToShow;

            }
        },
        COAU:{
            buildSensorData:function (feature) {
                var dataToShow= [];

                if (debug)console.table(feature)

                for( var p in feature.properties){

                    dataToShow.push({
                        value : feature.properties[p],
                        label : p
                    })

                }


                $scope.oWarningData[$scope.warningType].feature = feature;
                $scope.oWarningData[$scope.warningType].dataView = dataToShow;

            }
        },

        geocradle_soil_analysis: {
            buildSensorData:function (feature) {

                var props = _.clone(feature.properties);
                props.value = ((props.value < 0)? 'NA' : parseFloat(props.value).toFixed(2))
                $scope.oWarningData[$scope.warningType].dataView = props;

            }
        },

        autpor: {
            buildSensorData:function (feature) {

                $scope.oWarningData[$scope.warningType].dataView = feature.properties;

            }
        },

        phenological_analysis:{
            buildSensorData:function (feature) {

                $scope.oWarningData[$scope.warningType].dataView = feature.properties;

            }
        },

        risico_live:{
            buildSensorData:function (properties) {
                $scope.oWarningData[$scope.warningType].dataView = properties;
            }
        },

        PROPAGATOR:{
            buildSensorData:function (feature) {
                $scope.oWarningData[$scope.warningType].dataView = feature.properties;
            }
        },

        SFLOC:{
            buildSensorData:function (feature) {
                $scope.oWarningData[$scope.warningType].dataView = feature.properties;
            }
        },

        GDACS:{
            buildSensorData:function (feature) {
                $scope.oWarningData[$scope.warningType].dataView = feature;
            }
        },

        FLOOD_CAT:{
            buildSensorData:function (feature) {

                feature.properties.date = moment(new Date(feature.properties.date)).format("MMMM Do YYYY, h:mm:ss a")

                $scope.oWarningData[$scope.warningType].dataView = feature.properties;


            }
        },

        NIVOMETER:{
            buildSensorData:function (feature) {

                var start = false;
                var aData = [];

                var data = feature;

                for(var prop in data){
                    if (stringStartsWith(prop, "v_")){
                        start = true
                    }
                }
                if(start){
                    for(var prop in data){
                        if (stringStartsWith(prop, "v_")){
                            var aValue = prop.split("_");
                            var sTimeStamp = moment.unix(aValue[1]);
                            var sPeriod = parseInt(aValue[2])/3600;
                            var nValue =data[prop];

                            var label =(sPeriod == 0)?'NIVO-LAST'+ sPeriod.toString()+"H":'NIVO-MEAN'+ sPeriod.toString()+"H";

                            var oValue = {
                                timeStamp: sTimeStamp,
                                period : sPeriod,
                                label : label,
                                valore: nValue
                            };
                            aData.push(oValue)
                        }
                    }
                    //ordino per data
                    aData = _.sortBy(aData, 'timeStamp').reverse();
                    //arrai valori costruito per visualizzazione
                    $scope.oWarningData[$scope.warningType].dataView = aData;
                }
                //comune provincia regione
                sentinelService.getSensorInfo(data.sensorid, data.dbid,
                    function(sensorInfo){
                        //aData.push(sensorInfo);
                        //if(callBack) callBack(aData, sensorInfo);

                        $scope.oWarningData[$scope.warningType].sensorInfo = sensorInfo
                    },
                    function(err){
                        console.log("error Sentinel service")
                    })

                // $scope.oWarningData[$scope.warningType].dataView = feature.properties;


            }
        },

        SENSOR_GENERIC:{
            buildSensorData:function (feature) {
                var start = false;
                var aData = [];

                var data = feature;

                $scope.oWarningData[$scope.warningType].dataView = feature;

                for(var prop in data){
                    if (stringStartsWith(prop, "v_")){
                        start = true
                    }
                }
                if(start){

                    for(var prop in data){
                        if (stringStartsWith(prop, "v_")){
                            var aValue = prop.split("_");
                            var sTimeStamp = moment.unix(aValue[1]);
                            var sPeriod = parseInt(aValue[2])/3600;
                            var nValue =data[prop];

                            var label =(sPeriod == 0)?'LAST'+ sPeriod.toString()+"H":'MEAN'+ sPeriod.toString()+"H";

                            var oValue = {
                                timeStamp: sTimeStamp,
                                period : sPeriod,
                                label : label,
                                valore: nValue
                            };
                            aData.push(oValue)
                        }
                    }

                    //ordino per data
                    aData = _.sortBy(aData, 'timeStamp').reverse();
                    //arrai valori costruito per visualizzazione
                    $scope.oWarningData[$scope.warningType].dataView.data = aData;

                    sentinelService.getSensorInfo(feature.sensorid, feature.dbid,
                        function(sensorInfo){

                            $scope.oWarningData[$scope.warningType].sensorInfo = sensorInfo
                        },
                        function(err){
                            console.log("error Sentinel service")
                        });

                }

                if(feature.dtref != -1) {
                    feature.dtref= moment.utc(feature.dtref);
                }



            }
        },
        SENSOR_FLOODPROOF_SERIES:{
            buildSensorData:function (feature) {

                $scope.oWarningData[$scope.warningType].dataView = feature;


            }
        },
        GENERIC:{
            buildSensorData:function (feature) {

                $scope.oWarningData[$scope.warningType].dataView = feature;


            }
        },
        DESINVENTAR:{
            buildSensorData:function (feature) {


                $scope.oWarningData[$scope.warningType].dataView = feature;

                console.table($scope.oWarningData[$scope.warningType].dataView)

            }
        },
        SADC:{
            buildSensorData:function (feature) {

                if(feature.periods.Today && Object.keys(feature.periods.Today.params).length > 0){
                    feature.periods.Today.info = feature.periods.Today.params[Object.keys(feature.periods.Today.params)[0]];
                    delete feature.periods.Today.info.level
                    delete feature.periods.Today.info.levelName
                    delete feature.periods.Today.info.id
                }

                $scope.oWarningData[$scope.warningType].dataView = feature.periods.Today;
                console.log($scope.oWarningData[$scope.warningType].dataView)

            }
        },


        others:{

        }

    };

}]);
