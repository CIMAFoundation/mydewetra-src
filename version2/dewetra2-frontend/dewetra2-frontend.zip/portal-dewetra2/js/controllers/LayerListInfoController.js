/**
 * Created by Dario Rubado on 26/11/15.
 */

dewetraApp.controller("LayerListInfoController",['$scope','$rootScope','mapService', '_', '$timeout', function ($scope,$rootScope,mapService, _, $timeout) {


    $scope.oData = {
        layer : null
    };
    $scope.oInfo = {
        active: function(){
            if ($scope.oData.layer.length>0){
                return true;
            }else return false
        },
        mouseOver: function (infoType, layerObj, featureProperties) {
            //manager popup
            var obj= null;

            var manager = layerObj;
            //build popup data

            $scope.oData[infoType] = manager.layerTooltip();



        },
        mouseOut: function (infoType, layerId) {

            $scope.oData[infoType] = null;

        }
    }


}]);
