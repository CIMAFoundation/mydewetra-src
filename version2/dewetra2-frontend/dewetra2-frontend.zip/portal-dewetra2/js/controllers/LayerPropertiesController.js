dewetraApp.controller("layerPropertiesController",[ '$scope', 'layerService', 'mapService', 'menuService', '$uibModalInstance', 'params', '$interval', '$translate', '_',
    function ($scope, layerService, mapService, menuService, $uibModalInstance, params, $interval, $translate, _) {

    //var layerManager = mapService.getLayerManager(params.layer);
    var layerManager = mapService.oLayerList.getManagerByMapLayer(params.layer);
    $scope.data = {
        props: null,
        data: null,
        dynamicPalette:{
            haveDynamicPalette:false,
            min_value: 0,
            max_value:0
        }


    };


    // Aggiunto per adrion perche non si nascondevano i parametri hidden
    $scope.isVisible = function(visibleAttr){
        if (visibleAttr == true || visibleAttr == "true") return true
        return false;
    }

    function init(){

        if (layerManager.layerProps) {
            $scope.data.props = angular.copy(layerManager.layerProps);
            $scope.data.props.layerProperties.attributes.forEach(function (attr) {
                if ($scope.islist(attr)) {
                    for (var i=0; i<attr.entries.length; i++) {
                        if (attr.entries[i].value == attr.selectedEntry.value) {
                            attr.selectedEntry = attr.entries[i];
                            break;
                        }
                    }
                }
            });
            ////msgir2.8 non restituisce un array ma un oggetto quindi faccio questo accrocchio
            //if(!_.isArray($scope.data.props.layerProperties.attributes)){
            //    var obj = $scope.data.props.layerProperties.attributes
            //    $scope.data.props.layerProperties.attributes =[]
            //    $scope.data.props.layerProperties.attributes.push(obj)
            //}else $scope.data.props = data;

            //accroccrio per vedere se le entries degli attributi sono un array o un oggetto altrimenti nell'ngoptions viene undefined
            $scope.data.props.layerProperties.attributes.forEach(function(entry){
                if(!_.isArray(entry.entries)){
                    var obj = entry.entries;
                    entry.entries = [];
                    entry.entries.push(obj);
                }
            });
            //precarico anche l'opzione corrente cosi basta cliccare aggiorna per refreshare
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();

            //prendo valori layer caricato precedentemente
            if(layerManager.item){
                var oLayerItem = layerManager.item();
            }

            //chiedo quali layer sono diponibili nella timeline
            if (layerManager.getLayerAvailability) {

                var data = layerManager.getLayerAvailability();

                $scope.availables = data;
                //cerco l'index del layer caricato precedentemente
                var iIndexLoadedLayer = _.findIndex($scope.availables, function(availableItem){
                    return availableItem.description == oLayerItem.description;
                });
                //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                iIndexLoadedLayer = (iIndexLoadedLayer > -1)? iIndexLoadedLayer: 1;

                //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro

                if(layerManager.infoAvaialability){
                    layerManager.infoAvaialability(iIndexLoadedLayer+1, $scope.availables.length-1);
                }


                //layer preselezionato nella select
                $scope.data.data= $scope.availables[iIndexLoadedLayer]

            } else {

                layerService.getLayerAvailability(layerManager.layerObj(), $scope.data.props, from, to, function (data) {

                    //lista layer disponibili nella select
                    $scope.availables = data;
                    //cerco l'index del layer caricato precedentemente
                    var iIndexLoadedLayer = _.findIndex($scope.availables, function(availableItem){
                        return availableItem.description == oLayerItem.description;
                    });
                    //controllo che abbia trovato qualcosa altrimenti imposto il primo della lista
                    iIndexLoadedLayer = (iIndexLoadedLayer > -1)? iIndexLoadedLayer: 1;

                    //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro

                    if(layerManager.infoAvaialability){
                        layerManager.infoAvaialability(iIndexLoadedLayer+1, $scope.availables.length-1);
                    }


                    //layer preselezionato nella select
                    $scope.data.data= $scope.availables[iIndexLoadedLayer]
                })

            }


        } else {

            layerService.getLayerProperties(layerManager.layerObj(), function (data) {
					console.log(data);
                //msgir2.8 non restituisce un array ma un oggetto quindi faccio questo accrocchio
                if(!_.isArray(data.layerProperties.attributes)){
                    var obj = data.layerProperties.attributes;
                    data.layerProperties.attributes = [];
                    data.layerProperties.attributes.push(obj);
                    $scope.data.props = data;
                }else $scope.data.props = data;

                //accroccrio per vedere se le entries degli attributi sono un array o un oggetto altrimenti nell'ngoptions viene undefined
                $scope.data.props.layerProperties.attributes.forEach(function(entry){
                    if(!_.isArray(entry.entries)){
                        var obj = entry.entries;
                        entry.entries = [];
                        entry.entries.push(obj);
                    }
                });
                $scope.data.props.layerProperties.attributes.forEach(function (attr) {
                    if ($scope.islist(attr)) {
                        for (var i=0; i<attr.entries.length; i++) {
                            if (attr.entries[i].value == attr.selectedEntry.value) {
                                attr.selectedEntry = attr.entries[i];
                                break;
                            }
                        }
                    }
                });

                //load palette dynamic default values

                //end load palette dynamic default values

                //precarico anche l'opzione corrente cosi basta cliccare aggiorna per refreshare
                var from = menuService.getDateFromUTCSecond();
                var to = menuService.getDateToUTCSecond();

                layerService.getLayerAvailability(layerManager.layerObj(), $scope.data.props, from, to, function (data) {
                    $scope.availables = data;
                    //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                    if(layerManager.infoAvaialability){
                        layerManager.infoAvaialability(1, $scope.availables.length-1);
                    }

                    //layer preselezionato nella select
                    //aggiungo maggiore di uno per la mappa di pioggia
                    if ($scope.availables.length > 0) $scope.data.data= $scope.availables[0];

                })
            });

        }
    }



    //refresh

    if (layerManager.refreshable){
        $scope.isRefreshable = true;
        $scope.data.RefreshEnabled = layerManager.refreshable();
    }


    if(layerManager.haveDynamicPalette && layerManager.haveDynamicPalette()){

        $scope.data.dynamicPalette = layerManager.haveDynamicPalette();
    }


    $scope.$watch('data.RefreshEnabled', function () {
        layerManager.setRefresh($scope.data.RefreshEnabled)
    });
    //refresh end

    $scope.title = function () {
        return layerManager.descr()
    };

    $scope.islist = function (attr) {
        return attr.type.toLowerCase() == 'list'
    };

    $scope.isdate = function (attr) {
        return attr.type.toLowerCase() == 'date'
    };

    $scope.setPalette= function () {
        $scope.data.dynamicPalette.palette_setted = true;
        layerManager.haveDynamicPalette($scope.data.dynamicPalette)
    }

    $scope.setPalette1 = function(){
        // ng-change="expression"
        layerManager.haveDynamicPalette($scope.data.dynamicPalette)
    }

    $scope.update = function () {
        layerManager.layerProps = $scope.data.props;
        $uibModalInstance.close($scope.data);
    };
    $scope.closePopup = function () {
        $uibModalInstance.dismiss()
    };
    $scope.loadAvailables = function () {

        if (layerManager.hardcodedProperties) return;

        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        var timeAccumulate = false;

        $scope.data.props.layerProperties.attributes.forEach(function (prop) {
            console.log(prop);
            if(prop.descr == "Variable"){
                if(prop.selectedEntry.referredValues.entry.length > 0){

                    prop.selectedEntry.referredValues.entry.forEach(function (entry) {
                        if(entry["key"] == "cumulate"&& entry["value"] == "1"){
                            timeAccumulate = true;
                        }
                    })
                }
            }

            if(prop.descr == "Cumulative Range" ){
                if (timeAccumulate == true){
                    prop.visible= true
                }else {
                    prop.selectedEntry = prop.entries[0]
                    prop.visible= false
                }

            }


        })


        layerService.getLayerAvailability(layerManager.layerObj(), $scope.data.props, from, to, function (data) {
            $scope.data.dynamicPalette = layerManager.buildDynamicPaletteData($scope.data.props)
            $scope.availables = data;


            var index = _.findIndex($scope.availables,function (layer) {
                return (layer.description == $scope.data.data.description)
            })

            if (index > -1){
                $scope.data.data = $scope.availables[index];
            }else{
                $scope.data.data= $scope.availables[0]
            }


        })
    };

    /**
     * Evoluzione di load available sul cambio variabile
     */
    $scope.variableChange = function () {

        if (layerManager.hardcodedProperties) return;

        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        //data.layerProperties.attributes
        //if ("Cumulative Range") descr
        layerService.getLayerAvailability(layerManager.layerObj(), $scope.data.props, from, to, function (data) {
            $scope.data.dynamicPalette = layerManager.buildDynamicPaletteData($scope.data.props)
            $scope.availables = data;
            $scope.data.data= $scope.availables[0]
        })



    }

    /**
     * Format Date in select
     * @param sDateRunDateRef
     * @returns {*}
     */
    $scope.formatDateDescription = function(data){

        //var sDateRefDesc = $translate.instant('DATE_REF');
        //var sDateRunDesc = $translate.instant('DATE_RUN');

        if (layerManager.customFormatDateDescription) return layerManager.customFormatDateDescription(data);

        var sDateRunDateRef = data.id

        if(sDateRunDateRef.indexOf(";") > -1){
            //controllo se osservazione o previsione
            var l = layerManager.layerObj();
            var bLayerType = l.category == "observation";
            //se osservazione la data di run corrisponde alla dateref e ne visualizzo solo una
            if(bLayerType){
                var aDateRunDateRef = sDateRunDateRef.split(";");
                if(aDateRunDateRef.length >1 ){
                    if ((parseInt(aDateRunDateRef[0])) ==(parseInt(aDateRunDateRef[1]))){
                        return moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm')
                    }else return moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm')
                }else return moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                // var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                //var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm')

                //return sDateRun
            }else{
                //se previsione distinguo le due date

                var aDateRunDateRef = sDateRunDateRef.split(";");

                var diffDate=((parseInt(aDateRunDateRef[1]))-(parseInt(aDateRunDateRef[0])));

                if(diffDate> 0 ) {
                    diffDate = diffDate/ (1000 * 60 * 60);
                    diffDate= "(+"+parseInt(diffDate)+"h)";
                }else if(diffDate < 0){
                    diffDate= "(-"+Math.abs(diffDate) / (1000 * 60 * 60)+"h)";
                }else diffDate= "";



                var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');

                var returnString = sDateRef + " "+" (Run:"+ sDateRun+")"+ diffDate;

                return returnString
            }
            //se ha solo una data non mi pongo il problema
        }else{

            // Anto 20160908: Se item.id non è una data provo con item.date

            //var sDateRun = moment(new Date(parseInt(sDateRunDateRef))).utc().format('DD/MM/YYYY HH:mm');
            //return sDateRun

            var tsRun = parseInt(sDateRunDateRef);
            if (!isNaN(tsRun)) return moment(new Date(tsRun)).utc().format('DD/MM/YYYY HH:mm');
            else return moment(Date.parse(data.date)).utc().format('DD/MM/YYYY HH:mm');

        }
    };


    $scope.formatDateDescriptionSnowRoads = function(data){
        // console.log(data)

        return data.description

    };

    $scope.filterSnowRoads = function(data){

        if(data.date){
            var oFrom  = menuService.getDateFrom();
            var oTo = menuService.getDateTo();
            var oDate = new Date(data.date);

            if (oFrom.getTime()< oDate.getTime()<= oTo.getTime()) return true
        }


    };


    //order Layer
    $scope.orderLayers = function (item) {
        //console.log(item)

        // ORG!!!
        //if(item.date && moment(new Date(item.date)).isValid())return moment(new Date(item.date)).utc().unix()

        // Anto 20161010
        if(item.date && moment(new Date(item.date)).isValid()) return item.id;      //moment(new Date(item.date)).utc().unix();
    }


    //-Math.abs(num)
    $scope.reverse = true

    init();


}]);


dewetraApp.controller("desinventarLayerPropertiesController",['$scope', 'layerService', 'mapService', 'menuService', '$uibModalInstance', 'params', '$interval', '$translate', '_',function ($scope, layerService, mapService, menuService, $uibModalInstance, params, $interval, $translate, _) {
    var layerManager = mapService.oLayerList.getManagerByMapLayer(params.layer);
    $scope.data = {
        props: null,
        data: null,
        dynamicPalette:{
            haveDynamicPalette:false,
            min_value: 0,
            max_value:0
        }


    };
}]);


