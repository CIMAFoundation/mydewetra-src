/**
 * Created by Dario Rubado on 21/09/16.
 */
dewetraApp.controller("extWmsController",['$scope', '$rootScope', '$uibModalInstance','model', 'mapService',  '$http', 'printService','$interval', '$window' ,'layerService' ,function ($scope, $rootScope, $uibModalInstance,model, mapService,  $http, printService,$interval, $window ,layerService) {

    $scope.extGeoServerUrl = ""
    $scope.extDataId = ""

    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    })

    $scope.data = {
        bAlreadyLoadedWMS:true,
        servers:[],
        extGeoServerUrl: "",
        selectedServer:{},
        listOfAvailableLayers:[],
        selectedLayer:""
    }
    
    $scope.init = function () {
        //$scope.loadDewetraGeoServers();
        $scope.data.bAlreadyLoadedWMS = false;
    };

    $scope.reset= function(){
        $scope.data.listOfAvailableLayers = []
    }

   $scope.$watch('data.bAlreadyLoadedWMS', $scope.reset)

    $scope.loadDewetraGeoServers = function () {
        layerService.getGeoServers(function (data) {

            $scope.data.servers = data.objects;
            $scope.data.selectedServer= data.objects[0];
        }, function (err) {
            console.log(err);
            $scope.reset();
        })
    }

    //carico i layer disponibili da un serve gia settato su dds
    $scope.loadWmsCapabilitiesFromDewetraServer = function () {
        layerService.getWmsLayers($scope.data.selectedServer,function (data) {
            $scope.data.listOfAvailableLayers = data
            $scope.data.selectedLayer= data[0];
        },
            function (err) {
                console.log(err);
            })
    }

    //caricoLayer da server Esterno
    $scope.loadWmsCapabilitiesFromExtWMSServer = function () {

        var obj= {
            url: $scope.data.extGeoServerUrl
        }

        $scope.data.selectedServer.url =  $scope.data.extGeoServerUrl

        layerService.getWmsLayers(obj,function (data) {
            $scope.data.listOfAvailableLayers = data
                $scope.data.selectedLayer=data[0]
        },
        function (err) {
            console.log(err);
        })
    }
    
    $scope.buildLayerManager = function () {
       /* var obj = {

            url :$scope.data.selectedServer.url,
            layerId:$scope.data.selectedLayer
        }*/
        var obj = {
            server : {
                url: $scope.data.selectedServer.url
            },
            layerId : $scope.data.selectedLayer
        };

        layerService.getWmsLayerDetail(obj,function (data) {
            //console.log(data);
            var managerName= 'layerManager_static';

            var layer = {
                server: $scope.data.selectedServer,
                dataid:$scope.data.selectedLayer,
                type: {
                    code:'static'
                },
                name : data.title,
                descr: data.title,
                metadataurl:"",
                lats:data.bbox[1],
                lonw:data.bbox[0],
                latn:data.bbox[3],
                lone:data.bbox[2],
                icon:"external"
            }
            var manager = window[managerName](layer, mapService)

            manager.load(function () {
                mapService.oLayerList.addLayer(manager)
            })

        },
        function (err) {
            console.log(err)
        })
    }

    $scope.update = function () {
        $uibModalInstance.close();
    };

    $scope.closePopup = function () {
        $uibModalInstance.dismiss()
    };

    $scope.init();

}]);
