
/**
 * Created by doy on 24/06/15.
 */

dewetraApp.controller("magicSearchController", ['$scope', '$http', '$timeout', 'mapService', 'serieService', 'layerService',function ($scope, $http, $timeout, mapService, serieService, layerService) {


    function init() {
        $scope.theText='';
        setTimeout(function () {
            $("#the-text").focus()
        }, 0);



        $("#the-text").focusout(function(){
            //timeout senno no mi fa scegliere
            setTimeout($scope.onFocusOut, 500);
        });
        layerService.getLayersListAndDescription(function (data) {
            $scope.layers = data.objects
        });

        serieService.getAllMyFeatures(function (data) {
            $scope.puntualInfos = data
        })

    }

    $scope.layerSelected = function(layer) {
        layerService.getLayer(layer.id, function (data) {
            if (data.objects.length > 0) {
                $scope.onLayerSelected(data.objects[0]);
                //$scope.showInput = false;
                $scope.selectedLayer=''
            }
        })
    };

    $scope.nonEmptyTextFilter = function (o) {
        return $scope.theText.length>0
    };

    $scope.$watch('theText', function () {
        getGeoLocations($scope.theText)
    });

    var geocoderPromise = null;
    function getGeoLocations(val) {
        $scope.geoLocations = [];

        if (geocoderPromise) $timeout.cancel(geocoderPromise);
        geocoderPromise = $timeout(function () {

            console.log('query geocoder: ' + val);

            geocoder = new google.maps.Geocoder();
            geocoder.geocode( { 'address': val}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK)  {
                    results.forEach(function(loc) {

                        console.log(loc)
                        if (loc.geometry) {
                            if (loc.geometry.location) {
                                $scope.geoLocations.push({
                                    lat: loc.geometry.location.lat(),
                                    lon: loc.geometry.location.lng(),
                                    addr: loc.formatted_address
                                })
                            } else if (loc.geometry.bounds) {
                                $scope.geoLocations.push({
                                    lat: loc.geometry.bounds.getNorthEast().lat(),
                                    lon: loc.geometry.bounds.getNorthEast().lng(),
                                    addr: loc.formatted_address
                                })
                            }
                        }

                        // if (loc.geometry && loc.geometry.bounds) {
                        //     $scope.geoLocations.push({
                        //         lat: loc.geometry.bounds.getNorthEast().lat(),
                        //         lon: loc.geometry.bounds.getNorthEast().lng(),
                        //         addr: loc.formatted_address
                        //     })
                        // }

                    })
                }
            });

        }, 500)

    }

    $scope.geoLocationSelected = function (loc) {
        $scope.onAddressSelected(loc);
    };


    $scope.puntualInfoSelected = function (pi) {
        $scope.onFeatureSelected(pi)
    };

    init();

}]);
