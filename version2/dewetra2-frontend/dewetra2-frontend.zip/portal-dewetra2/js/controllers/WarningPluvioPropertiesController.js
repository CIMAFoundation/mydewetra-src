/**
 * Created by Dario Rubado on 13/10/15.
 */
dewetraApp.controller("warningPluvioPropertiesController", ['$scope', 'layerService', 'mapService', 'menuService', '$uibModalInstance', 'params', '$translate', 'audioService' ,function ($scope, layerService, mapService, menuService, $uibModalInstance, params, $translate, audioService) {

    var layerManager = mapService.oLayerList.getManagerByMapLayer(params.layer);


    $scope.haveAudio = layerManager.haveAudio();
    $scope.data = {
        //properties: layerManager.props(),
        props: layerManager.props(),
        data: {
            threshold: null,
            aggregation: null,
            raingaugeDataType: null,
            floodWave:false
        },
        layer: null,
        AudioEnabled: audioService.getAudioStatus(),
        params: params
    };

    if ($scope.data.props.threshold != null){
        $scope.lowThresholdInit = _.findIndex($scope.data.props.threshold.low.list, {'selected': true});
        $scope.highThresholdInit = _.findIndex($scope.data.props.threshold.high.list,{'selected': true})
    }

    if ($scope.data.props.aggregation != null) {
        $scope.aggregationInit = _.findIndex($scope.data.props.aggregation,{'selected': true})
    }

    if ($scope.data.props.raingaugeDataType != null) $scope.raingaugeDataTypeInit = _.findIndex($scope.data.props.raingaugeDataType,{'selected': true});




    $scope.$watch('data.AudioEnabled', function () {
        audioService.setAudio($scope.data.AudioEnabled);
        if ($scope.data.AudioEnabled == false){
            audioService.stopAudio();
        }
    });
    //$scope.data.layer = mapService.getLayerManager(params.layer);
    //console.log($scope.data.layer)

    $scope.update = function () {
        layerManager.layerProps = $scope.data.props;
        $uibModalInstance.close($scope.data);
    };
    $scope.closePopup = function () {
        $uibModalInstance.dismiss()
    }

}]);
