/**
 * Created by Dario Rubado on 02/10/15.
 */

dewetraApp.controller("toolsChooserController", ['$scope', '$uibModal', 'mapService', 'layerService', 'serieService', 'menuService', 'tagService',function ($scope, $uibModal, mapService, layerService, serieService, menuService, tagService) {


    $scope.choiceSelected = function(choice) {

    };
    function init() {
        console.log("init tools")

        menuService.getToolsMenuLinks(function (tools) {
            $scope.tools = tools;
        });
    }


    $scope.close = function () {
        $scope.onClose()
    };



    $scope.$watch('menu', init)

}]);




dewetraApp.component("layersButton",{
    templateUrl:'apps/dewetra2/views/layer_button.html',
    bindings:{
        oConfig:'<',
        aLayers:'<',
        onLayerSelected:'&'
    },
    controller:['$translate',function ($translate) {


        var ctrl = this

        ctrl.geoScaleFilter = function(obj){

            if(Array.isArray(ctrl.oConfig.geoScale)){//erra style
                if(ctrl.oConfig.geoScale.length==0) return true

                if(obj.hasOwnProperty("layer")){
                    if(obj.layer.hasOwnProperty("geoscale")&&obj.layer.geoscale!= null){

                        let i = ctrl.oConfig.geoScale.findIndex((v)=>{
                            return v.name == obj.layer.geoscale.name
                        })
                        return (i>-1)
                    }

                    return false
                }else{
                    if(obj.hasOwnProperty("geoscale")&&obj.geoscale!= null){

                        let i = ctrl.oConfig.geoScale.findIndex((v)=>{
                            return v.name == obj.geoscale.name
                        })
                        return (i>-1)
                    }

                    return false
                }



            }else{ //mydewetra style
                if(ctrl.oConfig.geoScale == "ALL") return true

                if(obj.hasOwnProperty("geoscale")&&obj.geoscale!= null){
                    if(obj.geoscale.name == ctrl.oConfig.geoScale){
                        return true
                    }else return false
                }

                return false
            }







        }
        ctrl.geoScaleFilterOld = function(obj){
            if(ctrl.oConfig.geoScale == "ALL") return true

            if(obj.hasOwnProperty("geoscale")&&obj.geoscale!= null){
                if(obj.geoscale.name == ctrl.oConfig.geoScale){
                    return true
                }else return false
            }

            return false

        }

        ctrl.drrFilter = function(obj){
            if(ctrl.oConfig.drr == "ALL") return true

            if(obj.hasOwnProperty("hierarchydrr")&&obj.hierarchydrr!= null){

                if(obj.hierarchydrr.split('.')[1] == ctrl.oConfig.drr){
                    return true
                }else return false
            }

            return false

        }

        ctrl.selectLayer = function(layer){

            try {

                if (layer.hasOwnProperty("layer")){
                    ctrl.onLayerSelected.apply(this)(layer.layer)
                }else {
                    ctrl.onLayerSelected.apply(this)(layer)
                }


            }catch (e) {
                console.log(e)
            }

        }

        ctrl.layerName = function(obj){

            if(obj && obj.icon) return obj.icon

            if(obj && obj.layer && obj.layer.icon) return obj.layer.icon

            return "default"

            // return (obj && obj.icon)?obj.icon:(obj.layer.icon);
        }

        ctrl.filterByName = function(layer){

            if(ctrl.oConfig.filterLayerString!=""){

                var string = $translate.instant(layer.name);

                if(string.toLowerCase().indexOf(ctrl.oConfig.filterLayerString.toLowerCase())>-1) {
                    return true

                }else {
                    return false
                }
            }else return true

        }

        ctrl.provenienza = function(layer){
            if(layer.source){
                return layer.source
            }else return ''
        }

        ctrl.$onChanges = function(value){

            // console.log(value.aLayers.currentValue)
            // console.log(value.aLayers.previousValue)
        }



    }]
});
