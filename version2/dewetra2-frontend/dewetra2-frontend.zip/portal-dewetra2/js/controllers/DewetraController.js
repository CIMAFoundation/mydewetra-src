/**
 * Created by Dario Rubado on 01/02/15.
 */
dewetraApp.controller("DewetraController",
    ['$uibModal', '$scope', '$rootScope', '$timeout', '$http', '$window', 'menuService', '$translate', 'mapService','tagService', 'layerService', 'serieService', 'acEvent', 'audioService', 'apiService', 'acLogbook', '_', 'sentinelService', '$interval', 'floodproofsService', '$location', 'iconService', 'thresholdService','acUserResource','rasorService', 'floodCatService', 'toolsService',
        'acAuthSrv', 'printService',function ($uibModal, $scope, $rootScope, $timeout, $http, $window, menuService, $translate, mapService,tagService, layerService, serieService, acEvent, audioService, apiService, acLogbook, _, sentinelService, $interval, floodproofsService, $location, iconService, thresholdService,acUserResource,rasorService, floodCatService, toolsService, acAuthSrv,printService) {


        let mapState;
    function init() {

        $rootScope.appDefaultLangId = window.app.lang;

        //carico i menu hard coded
        $scope.PrimaryMenu = menuService.getPrimaryMenuLinks();

        //inizialiuzzo la direttiva della lista layer
        $scope.oLayerList = mapService.oLayerList;

        let param = {};

        $scope.debug = menuService.debug;

        let baseURL = $location.absUrl();

        if(baseURL.indexOf('mapstate') > -1 ){
            mapState = printService.getMapStateDecodedUrl();


            //console.log(mapState);
            // layerId: "CIMA:com01012018_g"
            // server: "https://geodata.cimafoundation.org/geoserver/wms"
            // transparent: true
            // attribution: null
            // format: "image/png"
            // type: "STATIC"
            // name: "Confini Comunali"
            // legend: {url: "https://geodata.cimafoundation.org/geoserver/wms", name: "Confini Comunali_legend", layers: "CIMA:com01012018_g"}
            // opacity: 1
            // layerObj: {category: "static", customprops: null, dataid: "CIMA:com01012018_g", descr: "Confini Comunali Gennaio 2018", geoscale: null, …}
            // props:
            // items
            // if(mapState.dateFrom) menuService.setDateFrom(moment.utc(mapState.dateFrom).toDate())
            // if(mapState.dateTo) menuService.setDateTo(moment.utc(mapState.dateTo).toDate())



            if(mapState.wmsLayers.length >0){

                mapState.wmsLayers.map((l, index,array) => {

                    $timeout(function () {
                        let m = buildLayerManager(l.layerObj);

                        if(m.hasOwnProperty('loadWithProperties')){
                            if(l.props && l.item && l.layerObj){
                                m.loadWithProperties(function () {
                                    $scope.oLayerList.addLayer(m);

                                },l.layerObj,l.props,l.item,menuService.getDateFromUTCSecond(),menuService.getDateToUTCSecond(), l.opacity)
                            }
                        }else {
                            m = $scope.loadLayer(l.layerObj);
                            if(l.props && m.hasOwnProperty('setProps')){
                                m.setProps(l.props)
                            }
                            if(l.item && m.hasOwnProperty('setItem')){
                                m.setItem(l.item)
                            }
                            if(l.item && l.props && m.hasOwnProperty("update")){
                                m.update(l.props,l.item)
                            }
                        }

                    },index+1 * 1000);
                })
            }
            if(mapState.jsonLayers.length >0){
                mapState.jsonLayers.map(l => {
                    $timeout(function () {
                        let m = $scope.loadLayer(l.layerObj);
                        if(l.props && m.hasOwnProperty('setProps')){
                            m.setProps(l.props)
                        }
                        if(l.item && m.hasOwnProperty('setItem')){
                            m.setProps(l.props)
                        }

                    },2000);
                })
            }


        }else if(baseURL.indexOf('model')>-1){

            layerService.getLayersListAndDescription(function (data) {

                param.model = getQueryVariable("model");
                param.variable = getQueryVariable('variable');

                if (param.model){

                    if (param.model.indexOf('-')){
                        param.model.split('-').forEach(function (layerId) {

                            let layer = data.objects.filter(layerObj => layerObj.dataid == layerId)[0];

                            if (layer){
                                layerService.getLayer(layer.id, function (data) {
                                    if($scope.debug)console.log(data.objects[0]);
                                    $timeout(function () {
                                        $scope.loadLayer(data.objects[0]);
                                    },2000);
                                })
                            }else alert("No layer Found");
                        })

                    }else{

                        let layer = data.objects.filter(layerObj => layerObj.dataid == param.model)[0];

                        if (layer){
                            layerService.getLayer(layer.id, function (data) {
                                if($scope.debug)console.log(data.objects[0]);
                                $timeout(function () {
                                    $scope.loadLayer(data.objects[0]);
                                },2000);
                            })
                        }else alert("No layer Found");
                    }
                }
            });
        }


        //TODO DEV OPTION PRELOAD LAYER
        $timeout(()=>{
            //bolivia.droughtproofs.lfistations, bolivia.droughtproofs.qlowstations, bolivia.droughtproofs.speistations e bolivia.droughtproofs.spistations

            // const from = new Date(2022, 5, 8, 1);
            // const to = new Date(2022, 5, 10, 10)
            // $timeout(function () {
            //    menuService.timeModeNew(from, to);
            //    //$scope.loadLayer(fakeLayer('serie_ais_boe_forecast', 'ais.boe.forecast', 1) );
            // },1000)


            const p = {
                "category": "forecast",
                "customprops": "",
                "dataid": "COSMO_I5",
                "descr": "COSMO-5M",
                "geoscale": {
                "descr": "Italia",
                    "id": 1,
                    "name": "Italia"
            },
                "hierarchy": "meteorological models",
                "hierarchydrr": "meteorological models",
                "icon": "meteo_models",
                "id": 331,
                "latn": 50,
                "lats": 30,
                "lone": 18,
                "lonw": 6,
                "metadata": "",
                "metadataurl": "",
                "name": "COSMO-5M",
                "server": {
                "descr": "Dewetra Data Server at Cima Foundation",
                    "id": 1,
                    "name": "ddscima",
                    "url": "https://staging.mydewetra.org/dds"
            },
                "source": "ARPA-SIMC",
                "tags": [
                {
                    "descr": "Modelli Meteo",
                    "icon": null,
                    "id": 13,
                    "name": "Modelli Meteo"
                }
            ],
                "thumb": "",
                "type": {
                "code": "dynamic_v3",
                    "id": 1,
                    "name": "dynamic_v3"
            },
                "translatedName": "COSMO-5M",
                "$$hashKey": "object:967"
            }

            // $scope.loadLayer(fakeLayer('spi_spei_stations', 'bolivia.droughtproofs.spistations', 15));
            // $scope.loadLayer(fakeLayer('medstar_phenocam', 'bolivia.droughtproofs.spistations', 15));
            // $scope.loadLayer(fakeLayer('section_probabilistic_lami', 'africa.floodproofs2.nwpgfsdet'));
            // $scope.loadLayer(fakeLayer('serie_generic', 'africa.floodproofs2.nwpgfsdet'));
            // $scope.loadLayer(fakeLayer('serie_generic', 'rf_wrf_realtime.floodproofs.probabilistic', 38));
            //$scope.loadLayer(fakeLayer('dynamic_external_wmst_ea_hazards_watch', 'daily_rainfall_forecast', 39, 'https://eahazardswatch.icpac.net/gsky/ows')); //weekly_exceptional_rainfall //daily_rainfall_forecast //weekly_total_rainfall
            // $scope.loadLayer(fakeLayer('dynamic_external_wmst_ea_hazards_watch_time_parameters', 'cdi', 39, 'https://droughtwatch.icpac.net/mapserver/mukau/php/gis/mswms.php'));
            //$scope.loadLayer(fakeLayer('medstar_fwi_index', 'Comuni_Rfwi_Run0_2022-03-12', 1, 'https://geoportale.lamma.rete.toscana.it/cgi-bin/wms_rischio_prev') );
            //$scope.loadLayer(fakeLayer('medstar_wmst_haines_index', 'haines_index', 1, 'https://geoportale.lamma.rete.toscana.it/geoserver_ds/incendi/wms') );
            //$scope.loadLayer(fakeLayer('medstar_pano_phenocam', 'haines_index', 1) );
            //$scope.loadLayer(fakeLayer('serie_ais_boe_forecast', 'ais.boe.forecast', 1) );
            //$scope.loadLayer(fakeLayer('dynamic_external_wmst_global_drought_observatory', 'RDrI-Agri', 1, 'https://edo.jrc.ec.europa.eu/gdo/php/wms.php'));
            //$scope.loadLayer(fakeLayer('dynamic_external_wmst_global_drought_observatory', 'spi', 1, 'https://edo.jrc.ec.europa.eu/gdo/php/wms.php'));
            //$scope.loadLayer(fakeLayer('dynamic_external_wmst_global_drought_observatory', 'fapar_anom', 1, 'https://edo.jrc.ec.europa.eu/gdo/php/wms.php'));
            //$scope.loadLayer(fakeLayer('sensor', 'sensorClass;98', 1, 'https://edo.jrc.ec.europa.eu/gdo/php/wms.php'));
            //$scope.loadLayer(fakeLayer('burned_areas', 'SENTINEL2_BURNED_20M_CUMUL', 1, 'https://staging.mydewetra.org/dds'));
            //$scope.loadLayer(p)//TODO to remove

            // $scope.loadTools({
            //     classIcon: "floodWaveView2",
            //     title: "FLOOD_WAVE_VIEW_2",
            //     tag: "add",
            //     beta:true,
            //     selected: false,
            //     description: "FLOOD_WAVE_VIEW_2",
            //     manager: "floodWaveView2",
            //     loadLayers: "floodWaveView2"
            // })



        },1000)


        //load user resource by application

        acUserResource.getResources('dewetra2',
            (data) => {
                if(data && $rootScope && angular.isUndefined($rootScope.userResources)){
                    if(!Array.isArray(data)){
                        $rootScope.userResources = [data];
                    }else if (Array.isArray(data)) {
                        $rootScope.userResources = data;
                    }
                }
            },
            () => {
                console.log('error loading resource');
            }
        );


    }

    // $scope.popUpRisico = function (name) {
    //
    //     var serverTime = moment.utc($rootScope.getServerTime());
    //     var until = moment('2018-31-08','YYYY-DD-MM');
    //
    //     if (name.indexOf('risico')&&$rootScope.AdvPopup && serverTime.isBefore(until)){
    //
    //         var modalInstance = $uibModal.open({
    //
    //             templateUrl: 'apps/dewetra2/views/AdvMessage.html',
    //             controller: function($scope, $uibModal, $uibModalInstance, $translate,AdvMessage, _, $rootScope) {
    //                 $scope.AdvMessage = AdvMessage;
    //                 console.log(AdvMessage)
    //                 $scope.closePopup = function () {
    //                     $uibModalInstance.close();
    //                     $rootScope.AdvPopup = false;
    //                 }
    //             },
    //             size: 'lg',
    //             keyboard: false,
    //             resolve: {
    //
    //                 AdvMessage: function () {
    //
    //                     return {
    //                         title: "Manuale di RISICO",
    //                         subtitle: "Nuova pubblicazione manuale di RISICO",
    //                         messaggio : "E' disponibile il nuovo manuale di Risico presso questo link",
    //                         link: "#",
    //                         from:"Comunicazione"
    //                     };
    //
    //                 }
    //             }
    //         });
    //     }
    //
    // };


    function initMap() {


        if ($rootScope.acSession && $rootScope.acSession.hat.domain) {

            var basemap = null;


            try {
                let userOsmMap = window.app.config.userOsmMap;
                if(userOsmMap.indexOf($rootScope.acSession.user.id)> -1){
                    basemap = 'OSM - Standard'
                }
            }catch (e) {
                console.log(e)
            }


            try {
                let userSatelliteMap = window.app.config.userSatelliteMap;
                if(userSatelliteMap.indexOf($rootScope.acSession.user.id)> -1){
                    basemap = 'Google Satellite'
                }
            }catch (e) {
                console.log(e)
            }


            var southWest = L.latLng($rootScope.acSession.hat.domain.lats, $rootScope.acSession.hat.domain.lonw),
                northEast = L.latLng($rootScope.acSession.hat.domain.latn, $rootScope.acSession.hat.domain.lone),
                bounds = L.latLngBounds(southWest, northEast);

            if(mapState && mapState.hasOwnProperty('bounds')) {
                bounds =L.latLngBounds(mapState.bounds._southWest, mapState.bounds._northEast);
            };

            $timeout(function(){

                mapService.initMap(bounds, basemap);

                mapService.setZoomEndCallback()


                // var d = new Date(2015,08,14,02,00);
                // menuService.timeMode(d);



                //LOAD comPONENT FOR TEST



                // loadImpactComponentChart = function(){
                //
                //     var modalInstance = $uibModal.open({
                //         animation: true,
                //         component: 'thresholdsEditor',
                //         resolve: {
                //             model: function () {
                //                 return {
                //                     toolData:"obj",
                //
                //                 };
                //             },
                //             onClose:function () {
                //                 $scope.toolEnabled = false;
                //             }
                //
                //
                //         }
                //     });
                //
                //     modalInstance.result.then(function (obj) {
                //
                //         console.log('modal-component dismissed at: ' + new Date());
                //
                //     }, function () {
                //         console.log('modal-component dismissed at: ' + new Date());
                //     });
                // }



                // loadImpactComponentChart()






            },1000)

        }
    }

    init();

    $scope.$on('$locationChangeStart', function(event) {
        //boh
    });

    $scope.oConfig= {
        bIsDocked : false
    };

    $rootScope.$on(acAutheticationEvent, function(event, session) {

        init();

    });

    //quando cambio hat
    $rootScope.$on(acSessionChangedEvent, function(event, session) {
        //if($scope.debug)console.log(acSessionChangedEvent)
        //su cambio hat centro la mappa sul bounds prestabilito

        console.log('DewetraController acSessionChangedEvent: ' + $rootScope.acSession.authenticated)

        if (mapService.dewetraMap == null) initMap()

        mapService.fitMap();
    });

    function connectToWebSocket() {
        if ($rootScope.realTimeSocket) $rootScope.realTimeSocket.close()
        $rootScope.realTimeSocket = new WebSocket(window.app.url.realTimeWebSocketURL);
        $rootScope.realTimeSocket.onopen = function (event) {
            // var token = acAuthSrv.getToken()
            var token =(acAuthSrv.hasOwnProperty('getToken'))?acAuthSrv.getToken():undefined;


            if (acAuthSrv.isOIDC()) {
                var authData = {
                    server: 'OIDC@' + window.app.url.oidcIssuer,
                    token: token
                }
            } else {
                var authData = {
                    server: window.app.url.apiServerURL + "api/auth", //modificato da "/api/auth"
                    token: token
                }
            }
            $rootScope.realTimeSocket.send("AUTH" + JSON.stringify(authData))
            if($scope.debug)console.log('connected to websocket' + new Date());
            $rootScope.realTimeSocket.onmessage = function (event) {
                if($scope.debug)console.log('received data from websocket: ' + event.data + ' ' + new Date());
                var toks = event.data.split(";")
                //attivo solo se in tempo reale
                if(menuService.isRealTime())$rootScope.$broadcast(toks[0], event.data.substring(toks[0].length + 1));
            }
        }
        $rootScope.realTimeSocket.onclose = function (event) {
            if($scope.debug)console.log("websocket closed!!! " + new Date() +  " ...try to reconnect in 10 seconds")
            $timeout(connectToWebSocket, 10000)
        }
    }

    $rootScope.$watch('acSession.authenticated', function () {

        console.log('DewetraController AUTH WATCH: ' + $rootScope.acSession.authenticated)

        if ($rootScope.acSession.authenticated == true){

            //init the map
            if (mapService.dewetraMap == null) initMap()


            //connect to the websocket for realtime data
            try {
                if (window.app.url.realTimeWebSocketURL) {
                    connectToWebSocket();
                }
            }catch (e) {
                console.log(e)
            }


        } else {
            if ($rootScope.realTimeSocket) {
                if($scope.debug)console.log("closing websocket")
                $rootScope.realTimeSocket.close()
            }
        }
    });

    $scope.primaryMenuEnabler = function(obj){
        return obj.enabled
    };


    //Top Menu Loader layer
        //usata perchiudere il menu se ricliccato
    var lastMenuSelected = null;
    $scope.menuSelected = function (menu) {



        if (menu.enabled != false){
            if (menu.tag == "events"){


                if(window.app.config.hasOwnProperty('eventsTimeline')){
                    if(window.app.config.eventsTimeline ==  true){
                        loadEventComponent();
                    }else{
                        $scope.selectedEventMenu = menu;
                    }
                }else {
                    $scope.selectedEventMenu = menu;
                }

                $scope.layerChooserClosed();
                $scope.toolsChooserClosed();

            }else if( menu.tag == "tools"){

                $scope.selectedToolsMenu = menu;
                $scope.layerChooserClosed();
                $scope.eventChooserClosed();

            }else{
                $scope.selectedLayerMenu = menu;
                $scope.toolsChooserClosed();
                $scope.eventChooserClosed();
            }
        }
        //usata perchiudere il menu se ricliccato
        (lastMenuSelected=== menu)?$scope.escPress():lastMenuSelected=menu;
    };


    $scope.layerChooserClosed = function () {
        $scope.selectedLayerMenu = null;
    };

    //top menu loader tools

    $scope.toolsChooserClosed = function () {

        $scope.selectedToolsMenu = null;
    };

    $scope.eventChooserClosed = function () {
        $scope.selectedEventMenu = null;
    };

    $scope.escPress = function () {
        $scope.layerChooserClosed();
        $scope.toolsChooserClosed();
        $scope.eventChooserClosed();
        $scope.onFocusOut();
        lastMenuSelected = null;
    };

    let EventModalInstance = null;

    loadEventComponent = () => {

        if( EventModalInstance != null) return;

        EventModalInstance = $uibModal.open({
            animation: true,
            component: 'eventTimeLineModalComponent',
            size: 'lg',
            windowClass: 'modal-event',
            backdrop: false,
            resolve: {
               loadLayer: function (){
                   return $scope.loadLayer
               }
            }
        });

        EventModalInstance.result.then(function (obj) {

            console.log('modal-component dismissed at: ' + new Date());
            EventModalInstance = null;

        }, function () {
            console.log('modal-component dismissed at: ' + new Date());
            EventModalInstance = null;
        });
    };

    $scope.debugCounter =0;

    $scope.activateDebug = function () {

        $scope.debugCounter++;

        if ($scope.debugCounter > 10){
            menuService.debug = true;
            $scope.debug = true;
            if($scope.debug)console.log("debug activated");
        }else {
            if(!$scope.debug)console.log(10 - $scope.debugCounter + 'more' );
        }
    };

    $scope.deactivateDebug = function () {
        $scope.debugCounter = 0
    };

    function buildLayerManager(layer) {

        var mangerName = 'layerManager_' + layer['type'].code;

        // mangerName = 'layerManager_fews_po';

        console.log("Manager:"+mangerName);
        console.log("Id Layer:"+layer.dataid)

        var manager = window[mangerName](layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService, floodCatService);
        //passo l'oggetto dell direttiva WarningInfoDirective in modo da avere il popup dei warning
        //rasor layer loader
        if (rasorService.hasWarningInfo())rasorService.setWarningInfo($scope.oWarningInfo);
        if (manager.hasOwnProperty('setWarningInfo')) manager.setWarningInfo($scope.oWarningInfo);
        return manager;
    }



    $scope.onClickDockMenu = function(bIsDocked){
        console.log("dock: "+ bIsDocked);
        $scope.oConfig.bIsDocked = bIsDocked

    };

    $scope.loadLayer = function(layer, aoTags){

        $scope.layerChoosed = layer;

        const manager = buildLayerManager(layer);

        /**
         * boolean ricordo utilita se false non aggiunge layer alla layer list
         * delay rallenta di delay l'arrivo del layer nella layer list
         */
        manager.load(function (boolean, delay) {

            //passo la lista layer
            try{
                if(angular.isDefined(boolean)){
                    if(boolean)$scope.oLayerList.addLayer(manager);
                }else{
                    if(delay){
                        $timeout(function () {
                            $scope.oLayerList.addLayer(manager);
                        },delay)
                    }else {
                        $scope.oLayerList.addLayer(manager);
                    }

                }

            }catch (err){
                console.log(err)
            }

            // $scope.layerChooserClosed();
            if($scope.oConfig.bIsDocked){

            }else {
                $scope.escPress();
            }

            // add logbook activity
            setTimeout(function () {
                acLogbook.logActivity('dewetra2', 'layer added: ' + layer.name + ' (id: ' + layer.id + ')')
            }, 0)

        });


        //updateTagsStatistics
        if(aoTags)tagService.updateTagStatistics(aoTags);
        //updateTagsStatisticsEnd

        $scope.showMagicSearch = false;

        return manager;
    };

    $scope.toolEnabled = false;

    $scope.loadToolsOld = function (obj) {

        if(obj.loadLayers) $scope[obj.loadLayers]();


        if(obj.manager&&obj.manager.indexOf("scenari")>-1){

            console.log(obj.manager)

            if(angular.isUndefined(window["tool_"+obj.manager])){
                window["tool_scenari"](obj, $uibModal, function () {
                    $scope.toolEnabled = false;
                });
                $scope.toolEnabled = true;
            }else{
                window["tool_"+obj.manager](obj,  $uibModal, function () {
                    $scope.toolEnabled = false;
                });
                $scope.toolEnabled = true;
            }
        }

        $scope.escPress();
    };

    $scope.loadTools = function (obj) {

        if(obj.manager){

            console.log(obj.manager)

            if(!angular.isUndefined(window["tool_"+obj.manager])){

                window["tool_"+obj.manager](obj,  $uibModal, function () {
                    $scope.toolEnabled = false;
                    $scope.oConfig.bIsDocked = false
                });
                $scope.toolEnabled = true;
            }
        }

        $scope.escPress();
    };

    // $scope.addExternalWMSLayer = function () {
    //
    //     var layerPropModal = $uibModal.open({
    //         templateUrl: 'apps/dewetra2/views/add_external_layer.html',
    //         controller: "extWmsController",
    //         size: "lg",
    //         resolve: {
    //             params: function() {
    //                 return {
    //                     mapService: null
    //                 }
    //             }
    //         }
    //     });
    //
    //     layerPropModal.result.then(function (obj) {
    //
    //     }, function () {
    //         if($scope.debug)console.log("CANCEL")
    //         $scope.toolsChooserClosed()
    //     });
    //
    // };

    $scope.toggleMagicSearch = function () {
        $scope.showMagicSearch = !$scope.showMagicSearch
    };
    $scope.onFocusOut = function () {
        $scope.showMagicSearch = false;
    };
    $scope.serieFeatureSelected = function (obj) {
        var manager = buildLayerManager({type: {code: obj.code}});
        if (manager.showChart) {
            var from = menuService.getDateFromUTCSecond();
            var to = menuService.getDateToUTCSecond();
            serieService.getSeriesDirect(obj.server, obj.serie, obj.fid, from, to, function (data) {
                sensorId = parseInt(obj.fid.split(';')[0]);
                dbId = parseInt(obj.fid.split(';')[1]);
                manager.showChart(sensorId, dbId);
                $scope.showMagicSearch = false;
            })
        }
        addStationMarker(obj);
    };

    //GEOSEARCH

    $scope.geoLocationSelected = function (loc) {

        mapService.getMap().flyTo(new L.LatLng(loc.lat, loc.lon),11);

        mapService.addMarker(new L.LatLng(loc.lat, loc.lon));


        $scope.showMagicSearch = false;
    };

    //GEOSEARCH END

    //addMarker on Station Selected
    addStationMarker = function (station) {

        sentinelService.getSensorInfo(station.fid.split(";")[0],station.fid.split(";")[1], function (data) {
            //if($scope.debug)console.log(data)
            var oIconOption = L.icon({
                iconUrl: 'apps/dewetra2/img/stazioni.svg',
                iconSize:     [38, 95],
                //iconAnchor:   [39, 95]
                popupAnchor:  [0, -20]
            });
            mapService.addMarker(new L.LatLng(data.station.lat, data.station.lon), null, data.station.name)
        },x=>console.log(x))
    };
    //addMarker on Station Selected End

    //openlinkToExternal START

    $scope.openToExternalPopUp = function(link){
        console.log(link);
        $window.open(link, '_blank', 'location=no,height=800,width=600,scrollbars=yes,status=no,menubar=no')
    };

    //openlinkToExternal END
    //}
}]);
