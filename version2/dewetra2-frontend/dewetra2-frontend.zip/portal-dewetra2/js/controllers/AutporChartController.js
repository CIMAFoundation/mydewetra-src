/**
 * Created by Anto on 01/08/17.
 */

dewetraApp.controller('autporChartController',['$scope', '$uibModal', '$uibModalInstance', '$translate', 'sampleInfo', 'menuService', 'serieService','_', '$timeout', '$rootScope', '$window' ,function($scope, $uibModal, $uibModalInstance, $translate, sampleInfo, menuService, serieService,_, $timeout, $rootScope, $window) {


    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    })

    var chartManager = {
        'autpor.turbidity': showTurbidityChart,
        'autpor.turbidity.view_all': showTurbidityChart,
        'autpor.turbidity_breakwater': showTurbidityChart,
        'autpor.turbidity_breakwater.view_all': showTurbidityChart,
        'autpor.dusts': showDustsChart,
        'autpor.dusts.view_all': showDustsChart,
        'autpor.reports': null
    };

    var chartTitle = {
        'autpor.turbidity': 'Torbidità piattaforma',
        'autpor.turbidity.view_all': 'Torbidità piattaforma',
        'autpor.turbidity_breakwater': 'Torbidità  diga',
        'autpor.turbidity_breakwater.view_all': 'Torbidità  diga',
        'autpor.dusts': 'Polveri',
        'autpor.dusts.view_all': 'Polveri',
        'autpor.reports': 'Reports'
    };

    var thresholds = {
        'autpor.turbidity':[{ name: 'delta c', color: '#1BE0E0' }, { name: 'delta s', color: '#0000FF' }],
        'autpor.turbidity.view_all':[{ name: 'delta c', color: '#1BE0E0' }, { name: 'delta s', color: '#0000FF' }],
        'autpor.turbidity_breakwater': [{ name: 'delta c1', color: '#1BE0E0' }, { name: 'delta s1', color: '#0000FF' }, { name: 'delta c2', color: '#FCB900' }, { name: 'delta s2', color: '#FC3700' }],
        'autpor.turbidity_breakwater.view_all': [{ name: 'delta c1', color: '#1BE0E0' }, { name: 'delta s1', color: '#0000FF' }, { name: 'delta c2', color: '#FCB900' }, { name: 'delta s2', color: '#FC3700' }],
        'autpor.dusts': [{ name: 'CPI', color: '#1BE0E0' }, { name: 'CPII', color: '#0000FF' }],
        'autpor.dusts.view_all': [{ name: 'CPI', color: '#1BE0E0' }, { name: 'CPII', color: '#0000FF' }],
        'autpor.reports': []
    };

    addDownloadChartOption();

    addClassToDirective = function () {

        var result = document.getElementsByClassName("modal-dialog");
        var wrappedResult = angular.element(result);
        wrappedResult.addClass("customModal2")

    }

    $scope.isAdmin = ($rootScope.acSession.hat.descr == 'AP Admin');

    $scope.isMaster = ($rootScope.acSession.hat.descr == 'AP Master');

    $scope.isUser = !($scope.isAdmin || $scope.isMaster);


    $scope.chart = null;

    $scope.chartType = null;

    $scope.samplesData = {};

    loadSamplesData(sampleInfo);

    $scope.reloadButton = {

        enabled : false,
        reload : function() {

            //for (var i = 0; i < $scope.samplesData.length; i++) {
            //
            //    if ($scope.samplesData[i].active) {
            //
            //        showChart($scope.samplesData[i]);
            //        return;
            //
            //    }
            //
            //}

        }

    };

    $scope.dataChanged = function(d) {

        toggleData(d.type);

        showChart(d);

    };

    $scope.closePopup = function() {

        $uibModalInstance.close();

    };

    $scope.getReportName = function(f) {

        var split = f.split('/');
        return split[split.length - 1];

    };

    $scope.getReportURL = function(f) {
        return f;
    };

    $scope.validate = function(f) {



    };


    function loadSamplesData(info) {

        //aggiungo classe per estendere i modal a schermo pieno
        $timeout(addClassToDirective, 100);

        serieService.getSeriesDirect(info.serverId, info.seriesId, info.sampleData.Code, menuService.getDateFromUTCSecond(), menuService.getDateToUTCSecond(),

            function(data) {

                if (info.seriesId == 'autpor.reports') {

                    if (!data) {
                        alert($translate.instant('UNAVAILABLE_DATA'));
                        return;
                    }

                    $scope.samplesData[sampleInfo.seriesId] = {
                        'type' : sampleInfo.seriesId,
                        'name' : chartTitle[sampleInfo.seriesId],
                        'data' : [data],
                        'isUser' : $scope.isUser,
                        'isMaster' : $scope.isMaster,
                        'isAdmin' : $scope.isAdmin
                    };

                } else {

                    if (data.length == 0) {
                        alert($translate.instant('UNAVAILABLE_DATA'));
                        return;
                    }

                    $scope.samplesData[sampleInfo.seriesId] = {
                        'type' : sampleInfo.seriesId,
                        'name' : chartTitle[sampleInfo.seriesId],
                        'data' : data,
                        'isUser' : $scope.isUser,
                        'isMaster' : $scope.isMaster,
                        'isAdmin' : $scope.isAdmin
                    };

                    if (info.seriesId != 'autpor.reports') {
                        $scope.samplesData['autpor.reports'] = {
                            'type' : 'autpor.reports',
                            'name' : 'Reports',
                            'data' : [data[data.length - 1]],
                            'isUser' : $scope.isUser,
                            'isMaster' : $scope.isMaster,
                            'isAdmin' : $scope.isAdmin
                        };
                    }

                }

                toggleData(sampleInfo.seriesId);

                $scope.chartTitle = chartTitle[sampleInfo.seriesId];

                showChart($scope.samplesData[sampleInfo.seriesId]);

            },
            function(data) {

                alert($translate.instant('ERROR_LOADING_DATA') + ': ' + data.error_message);

            });

    }

    function showChart(sampleData) {


        if (!chartManager.hasOwnProperty(sampleData.type)) {

            alert($translate.instant('CHART_NOT_AVAILABLE'));
            return;

        }

        if (chartManager[sampleData.type] == null) return;

        $scope.chartSubTitle = $translate.instant('DATE') + ': ' + moment(menuService.getDateFrom()).format('DD/MM/YYYY') + ' - ' + moment(menuService.getDateTo()).format('DD/MM/YYYY');

        setTimeout(function() {

            var settings = {
                date_start: menuService.getDateFrom().getTime(),
                date_end: menuService.getDateTo().getTime(),
                thrs: thresholds[sampleInfo.seriesId]
            }
            $scope.chart = chartManager[sampleInfo.seriesId](sampleData, menuService.oChartSize.m_iFloodProofsChartHeight(), $translate, settings);

        }, 0);

    }

    function toggleData(type) {

        $scope.chartType = type;

        for (var key in $scope.samplesData) {

            // skip loop if the property is from prototype
            if (!$scope.samplesData.hasOwnProperty(key)) continue;

            $scope.samplesData[key].active = ($scope.samplesData[key].type === type);

        }

    }

    $scope.chartTitleFormatter = function (descr) {
        return descr.toUpperCase().trim().replace(/ /g,"_");
    }



}]);


