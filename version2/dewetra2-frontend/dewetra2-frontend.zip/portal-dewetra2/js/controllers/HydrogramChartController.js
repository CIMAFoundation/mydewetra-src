

dewetraApp.controller('hydrogramChartController', ['$sce', '$scope', '$uibModal', '$uibModalInstance', '$translate', 'sectionData', 'menuService', 'serieService', 'floodproofsService', '$timeout', '$rootScope', 'rasorService', '_',function($sce, $scope, $uibModal, $uibModalInstance, $translate, sectionData, menuService, serieService, floodproofsService, $timeout, $rootScope, rasorService, _) {


    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    })
    $scope.HydrogramSelected = {};

    var chartManager = {

        'DeterministicHydrogramChart' : showDeterministicHydrogramsChart,
        'MultiDeterministicHydrogramChart' : showMultiDeterministicHydrogramsChart,
        'DeterministicHydrogramLevelChart' : showDeterministicHydrogramsLevelChart,
        'DeterministicLevelHydrogramChart' : showDeterministicLevelHydrogramsChart,// cf lazio
        'DeterministicVolumeHydrogramChart' : showDeterministicHydrogramsChart,
        'DeterministicLevelVolumeHydrogramChart' : showDeterministicLevelVolumeHydrogramChart,
        'MaximumHydrogramChart' : showMaximumHydrogramChart,
        'MaximumLevelHydrogramChart' : showMaximumLevelHydrogramChart,
        'MaximumFewsHydrogramChart' : showMaximumFewsHydrogramChart, //FEWS
        'MaximumLevelFewsHydrogramChart' : showMaximumLevelFewsHydrogramChart, //FEWS
        'DeterministicHydrogramFewsChart':showDeterministicHydrogramFewsChart, //FEWS
        'DeterministicLevelHydrogramFewsChart': showDeterministicLevelHydrogramFews, //FEWS
        'MaximumVolumeHydrogramChart' : showMaximumHydrogramChart,
        'MaximumLevelVolumeHydrogramChart' : showMaximumLevelVolumeHydrogramChart,
        'ProbabilisticHydrogramChart' : showProbabilisticHydrogramChart,
        'ProbabilisticLevelHydrogramChart' :showProbabilisticLevelHydrogramChart,
        'ProbabilisticVolumeHydrogramChart' : showProbabilisticHydrogramChart,
        'TimeSeriesDroughtProofsChart' : showTimeSeriesDroughtProofsChart

    };

    $scope.chart = {};

    var chartSettings = {

        'DeterministicHydrogramChart' : {
            mod_series_name:"Q(mod)",
            mod_fut_series_name:"Q(mod future)",
            obs_series_name:"Q(obs)",
            qmod_forecast_lami:"Q(mod Forecast Lami)",

            // in deterministic
            mod_det_fut_series_name:"Q(mod Forecast Lami)",
            qmod_det_forecast_lami:"Q(mod Forecast Lami -24h)",
            yAxis_labels_x: 30,
            yAxis_tickInterval: 100,
            yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
            unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>'
        },
        'DeterministicHydrogramFewsChart':{
            mod_series_name:"Q(mod)",
            mod_fut_series_name:"Q(mod future)",
            obs_series_name:"Q(obs)",
            qmod_forecast_lami:"Q(mod Forecast Lami)",

            // in deterministic
            mod_det_fut_series_name:"Q(mod Forecast Lami)",
            qmod_det_forecast_lami:"Q(mod Forecast Lami -24h)",
            yAxis_labels_x: 30,
            yAxis_tickInterval: 100,
            yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
            unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>'
        },
        'DeterministicLevelHydrogramFewsChart':{
            mod_series_name:"L(mod)",
            obs_fut_series_name:"L(mod assim)",
            obs_series_name:"L(obs)",
            qmod_forecast_lami:"L(mod Forecast Lami)",

            // in deterministic
            mod_det_fut_series_name:"Q(mod Forecast Lami)",
            qmod_det_forecast_lami:"Q(mod Forecast Lami -24h)",
            yAxis_labels_x: 30,
            yAxis_tickInterval: 100,
            yAxis_title:'<p style="color: blue">Levels [m]</p>',
            unit_of_measure:'m'
        },
        'MultiDeterministicHydrogramChart' : {
            mod_series_name:"Q(mod)",
            mod_fut_series_name:"Q(mod future)",
            obs_series_name:"Q(obs)",
            qmod_forecast_lami:"Q(mod Forecast Lami)",

            // in deterministic
            mod_det_fut_series_name:"Q(mod Forecast Lami)",
            qmod_det_forecast_lami:"Q(mod Forecast Lami -24h)",
            yAxis_labels_x: 30,
            yAxis_tickInterval: 100,
            yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
            unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>'
        },
        'TimeSeriesDroughtProofsChart':{
            mod_series_name:"Q(mod)",
            mod_fut_series_name:"Q(mod future)",
            obs_series_name:"Q(obs)",
            qmod_forecast_lami:"Q(mod Forecast Lami)",

            // in deterministic
            mod_det_fut_series_name:"Q(mod Forecast Lami)",
            qmod_det_forecast_lami:"Q(mod Forecast Lami -24h)",
            yAxis_labels_x: 30,
            yAxis_tickInterval: 100,
            yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
            unit_of_measure:'SPI - SPEI - LFI'
        },
        'DeterministicHydrogramLevelChart' : { // FP LEVEL
            mod_series_name:"L(mod)",
            obs_fut_series_name:"L(mod assim)",
            obs_series_name:"L(obs)",
            qmod_forecast_lami:"L(mod Forecast Lami)",
            // in deterministic
            mod_det_fut_series_name:"Q(mod Forecast Lami)",
            qmod_det_forecast_lami:"Q(mod Forecast Lami -24h)",
            yAxis_labels_x: 30,
            yAxis_tickInterval: 100,
            yAxis_title:'<p style="color: blue">Levels [m]</p>',
            unit_of_measure:'m'
        },
        'DeterministicLevelHydrogramChart' : { // cf LAZIO
            mod_series_name:"L(mod)",
            obs_fut_series_name:"L(mod assim)",
            obs_series_name:"L(obs)",
            qmod_forecast_lami:"L(mod Forecast Lami)",

            // in deterministic
            mod_det_fut_series_name:"Q(mod Forecast Lami)",
            qmod_det_forecast_lami:"Q(mod Forecast Lami -24h)",
            yAxis_labels_x: 30,
            yAxis_tickInterval: 100,
            yAxis_title:'<p style="color: blue">Levels [m]</p>',
            unit_of_measure:'m'
        },
        'DeterministicVolumeHydrogramChart' : {
            isVolume:true,
            mod_series_name:"V(mod)",
            obs_series_name:"V(obs)",
            yAxis_labels_x: 40,
            yAxis_title:'<p style="color: blue">V x 10<sup>6</sup> [m<sup>3</sup>]</p>',
            unit_of_measure:'m<sup>3</sup>'
        },
        'DeterministicLevelVolumeHydrogramChart' : {
            isVolume:true,
            mod_series_name:"V(mod)",
            obs_series_name:"V(obs)",
            mod_fut_series_name:"V(mod future)",
            mod_forecast_series_name:"V(mod Forecast Lami)",
            //det
            mod_det_fut_series_name:"V(mod forecast Lami)",
            mod_det_forecast_series_name:"V(mod Forecast Lami -24h)",
            y0Axis_labels_x: -5,
            y1Axis_labels_x: 40,
            y0Axis_title:'<p style="color: blue">L [m]</p>',
            y1Axis_title:'<p style="color: blue">V x 10<sup>6</sup> [m<sup>3</sup>]</p>',
            y0unit_of_measure:'m',
            y1unit_of_measure:'m<sup>3</sup>'
        },
        'MaximumHydrogramChart' : {
            envelop_series_name:"Q(env c.i. 100%)",
            max_series_name:"Q(max)",
            obs_series_name:"Q(obs)",
            envelop80_series_name:"Q(env c.i. 80%)",
            envelop50_series_name:"Q(env c.i. 50%)",
            envelopMean_series_name:"Q(Median)",
            yAxis_labels_x: 30,
            yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
            unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>'
        },
        'MaximumLevelHydrogramChart' : {
            envelop_series_name:"H(env c.i. 100%)",
            max_series_name:"H(max)",
            obs_series_name:"H(obs)",
            envelop80_series_name:"H(env c.i. 80%)",
            envelop50_series_name:"H(env c.i. 50%)",
            envelopMean_series_name:"H(Median)",
            yAxis_labels_x: 30,
            yAxis_title:'<p style="color: blue">H [m]</p>',
            unit_of_measure:'m'
        },
        'MaximumFewsHydrogramChart' : {
            envelop_series_name:"Q(env c.i. 100%)",
            max_series_name:"Q(max)",
            obs_series_name:"Q(obs)",
            envelop80_series_name:"Q(env c.i. 80%)",
            envelop50_series_name:"Q(env c.i. 50%)",
            envelopMean_series_name:"Q(Median)",
            yAxis_labels_x: 30,
            yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
            unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>'
        },
        'MaximumLevelFewsHydrogramChart' : {
            envelop_series_name:"H(env c.i. 100%)",
            max_series_name:"H(max)",
            obs_series_name:"H(obs)",
            envelop80_series_name:"H(env c.i. 80%)",
            envelop50_series_name:"H(env c.i. 50%)",
            envelopMean_series_name:"H(Median)",
            yAxis_labels_x: 30,
            yAxis_title:'<p style="color: blue">H [m]</p>',
            unit_of_measure:'m'
        },
        'MaximumVolumeHydrogramChart' : {
            isVolume:true,
            envelop_series_name:"V(env c.i. 100%)",
            max_series_name:"V(max)",
            obs_series_name:"V(obs)",
            envelop80_series_name:"V(env c.i. 80%)",
            envelop50_series_name:"V(env c.i. 50%)",
            envelopMean_series_name:"V(Median)",
            yAxis_labels_x: 40,
            yAxis_title:'<p style="color: blue">V x 10<sup>6</sup> [m<sup>3</sup>]</p>',
            unit_of_measure:'m<sup>3</sup>'
        },
        'MaximumLevelVolumeHydrogramChart' : {
            isVolume:true,
            envelop_series_name:"V(env c.i. 100%)",
            max_series_name:"V(max)",
            obs_series_name:"V(obs)",
            envelop80_series_name:"V(env c.i. 80%)",
            envelop50_series_name:"V(env c.i. 50%)",
            envelopMean_series_name:"V(Median)",
            y0Axis_labels_x: -5,
            y1Axis_labels_x: 40,
            y0Axis_title:'<p style="color: blue">L [m]</p>',
            y1Axis_title:'<p style="color: blue">V x 10<sup>6</sup> [m<sup>3</sup>]</p>',
            y0unit_of_measure:'m',
            y1unit_of_measure:'m<sup>3</sup>'
        },
        'ProbabilisticHydrogramChart' : {
            max_series_name:"(Q, P[Qmax > Q])",
            yAxis_labels_x: 5,
            yAxis_tickInterval: 0.1,
            yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
            unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>'
        },
        'ProbabilisticLevelHydrogramChart' : {
            max_series_name:"(H, P[Hmax > H])",
            yAxis_labels_x: 5,
            yAxis_tickInterval: 0.1,
            yAxis_title:'<p style="color: blue">H [m]</p>',
            unit_of_measure:'m'
        },
        'ProbabilisticVolumeHydrogramChart' : {
            isVolume:true,
            max_series_name:"(V, P[Vmax > V])",
            yAxis_labels_x: 5,
            yAxis_tickInterval: 0.1,
            yAxis_title:'<p style="color: blue">V x 10<sup>6</sup> [m<sup>3</sup>]</p>',
            unit_of_measure:'m<sup>3</sup>'
        }

    };

    var orderChartChooser = [
        "Gauge",
        "Deterministic",
        "Probabilistic",
        "Radar",
        "Expert",
        "Qlow",
        "LFI"
    ];

    addDownloadChartOption();

    //change Axys
    $scope.yAxisExtremesQPopover = {
        isOpen: false,
        templateUrl:"yAxisExtremesQPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min: 0,
        max: null,
        set:function(){

            $scope.yAxisExtremesQPopover.isOpen = false
            $scope.yAxisExtremesQPopover.edited = true

            for (var i = 0; i < $scope.hydrograms.length; i++) {

                if ($scope.hydrograms[i].active) {

                    showChart($scope.hydrograms[i]);

                    return;

                }

            }

        },
        close:function(){
            $scope.yAxisExtremesQPopover.isOpen = false
        }

    };

    $scope.yAxisExtremesLPopover = {
        isOpen: false,
        templateUrl:"yAxisExtremesQPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min: null,
        max: null,
        set:function(){

            $scope.yAxisExtremesQPopover.isOpen = false
            $scope.yAxisExtremesQPopover.edited = true

            for (var i = 0; i < $scope.hydrograms.length; i++) {

                if ($scope.hydrograms[i].active) {

                    showChart($scope.hydrograms[i]);

                    return;

                }

            }

        },
        close:function(){
            $scope.yAxisExtremesQPopover.isOpen = false
        }

    };

    $scope.yAxisExtremesVPopover = {
        isOpen: false,
        templateUrl:"yAxisExtremesVPopover.html",
        title:"SET_Y_AXIS",
        enabled: true,
        data: "data",
        edited: false,
        min: 0,
        max: null,
        set:function(){

            $scope.yAxisExtremesVPopover.isOpen = false
            $scope.yAxisExtremesVPopover.edited = true

            for (var i = 0; i < $scope.hydrograms.length; i++) {

                if ($scope.hydrograms[i].active) {

                    showChart($scope.hydrograms[i]);

                    return;

                }

            }

        },
        close:function(){
            $scope.yAxisExtremesVPopover.isOpen = false
        }

    };

    $scope.XYRulerVPopover = {
        isOpen: false,
        templateUrl:"XYRulerVPopover.html",
        title:"SET_Y_RULER",
        enabled: true,
        data: "data",
        edited: false,
        xLine: null,
        yLine: null,
        set:function(){

            $scope.XYRulerVPopover.isOpen = false
            $scope.XYRulerVPopover.edited = true

            if((typeof $scope.chart)=== 'object'){

                if($scope.XYRulerVPopover.edited)$scope.chart.chart.yAxis[0].removePlotLine('yRuler');

                $scope.chart.chart.yAxis[0].addPlotLine(
                    {
                        id : 'yRuler',
                        value : parseFloat($scope.XYRulerVPopover.yLine),
                        color : 'grey',
                        width : 2,
                        zIndex: 5,
                        label : {
                            text : "Ruler",
                            color : 'grey'
                        }
                    });

            }

        },
        close:function(){
            $scope.XYRulerVPopover.isOpen = false
        }

    };

    addClassToDirective = function () {
        //aggiungo questa classe per customizzare solo i grafici sensori
        //console.log("test")
        var result = document.getElementsByClassName("modal-dialog");
        var wrappedResult = angular.element(result);
        //console.log(wrappedResult)
        wrappedResult.addClass("customModal2")


    }

    var yAxisExtremes = {

        'DeterministicHydrogramChart' : $scope.yAxisExtremesQPopover,
        'DeterministicHydrogramLevelChart': $scope.yAxisExtremesLPopover,
        'MultiDeterministicHydrogramChart' : $scope.yAxisExtremesQPopover,
        'DeterministicLevelHydrogramChart' : $scope.yAxisExtremesQPopover,
        'DeterministicVolumeHydrogramChart' : $scope.yAxisExtremesVPopover,
        'DeterministicLevelVolumeHydrogramChart' : $scope.yAxisExtremesVPopover,
        'MaximumHydrogramChart' : $scope.yAxisExtremesQPopover,
        'MaximumLevelHydrogramChart' : $scope.yAxisExtremesLPopover,
        'MaximumFewsHydrogramChart' : $scope.yAxisExtremesQPopover,
        'MaximumLevelFewsHydrogramChart' : $scope.yAxisExtremesQPopover,
        'DeterministicHydrogramFewsChart':$scope.yAxisExtremesQPopover, //FEWS
        'DeterministicLevelHydrogramFewsChart': $scope.yAxisExtremesVPopover,//FEWS
        'MaximumVolumeHydrogramChart' : $scope.yAxisExtremesVPopover,
        'MaximumLevelVolumeHydrogramChart' : $scope.yAxisExtremesVPopover,
        'TimeSeriesDroughtProofsChart' : $scope.yAxisExtremesQPopover

        // VERIFICARE!!
        //'ProbabilisticHydrogramChart' : $scope.yAxisExtremesQPopover,
        //'ProbabilisticVolumeHydrogramChart' : $scope.yAxisExtremesVPopover

    };

    //change Axys End

    //var chartVariable = {
    //    'obs' : 'F.P. Gauge Obs.',
    //    'det' : 'F.P. Deterministic',
    //    'max' : 'F.P. Max. Analisys',
    //    'prob' : 'F.P. Exc. Prob.'
    //}

    $scope.chart= null

    $scope.hydrograms = [];

    sectionData.prop.type = sectionData.prop.type.split(';')[0];

    //bind current data to scope
    $scope.sectionData = sectionData;

    loadHydrograms(sectionData.prop.id);

    $scope.reloadButton = {

        enabled : true,
        reload : function () {

            for (var i = 0; i < $scope.hydrograms.length; i++) {

                if ($scope.hydrograms[i].active) {

                    showChart($scope.hydrograms[i]);
                    return;

                }

            }

        }

    };

    $scope.hydrogramChanged = function(hydrogram) {

        if (hydrogram.disabled == true) return
        //Se cambio tipo di grafico resetto l'oggetto per impostare gli assi
        var curHydrogram = null

        for (var i = 0; i < $scope.hydrograms.length; i++) {

            if ($scope.hydrograms[i].active) {
                curHydrogram = $scope.hydrograms[i]
                break;
            }
        }

        if (curHydrogram) {
            if (curHydrogram.type != hydrogram.type ){
                if(yAxisExtremes[curHydrogram.type]&&yAxisExtremes[curHydrogram.type].min)yAxisExtremes[curHydrogram.type].min = null;
                if(yAxisExtremes[curHydrogram.type]&&yAxisExtremes[curHydrogram.type].max)yAxisExtremes[curHydrogram.type].max = null;
            }
        }

        toggleHydrogram(hydrogram);

        showChart(hydrogram);

    };
    $scope.closePopup = function() {

        $uibModalInstance.close();

    };
    function loadHydrograms(seriesId) {

        //aggiungo classe per estendere i modal a schermo pieno
        $timeout(addClassToDirective,100)

        floodproofsService.compatibles(sectionData.serverId, seriesId, function (data) {

            if(!_.isArray(data)){
                data =[data];
            }

            data.forEach(function(h) {
                // per ogni idrogramma controllo chart type
                var h_copy, chartTypes = h.type.split(';');
                chartTypes.forEach(function(c) {
                    //se è configurato il manager per quella tipologia popola hydrogams e li segna disabled false
                    if (chartManager.hasOwnProperty(c)) {

                        h_copy = _.clone(h);
                        h_copy.type = c;
                        h_copy.disabled = false;
                        h_copy.title = h_copy.id.toUpperCase()+"_"+c.toUpperCase();
                        // h_copy.title_translated = h_copy.id.toUpperCase()+"_"+c.toUpperCase();
                        $scope.hydrograms.push(h_copy);

                    }

                });



            });


            //per sapere se disponibili le serie chimata asincrona..
            //conto gli idrogrammi e le chiamate perche sia asincrona ..

            var iHydroResponse = 0
            var iWorkingHydrogram = 0

            $scope.hydrograms.forEach(function(h) {

                //if (h.id == seriesId) {

                    serieService.getSeriesDirect(sectionData.serverId, h.id, sectionData.section[h.fidField], menuService.getDateFromUTCSecond(), menuService.getDateToUTCSecond(),
                        function (data) {

                        h.disabled = false;
                        iHydroResponse = iHydroResponse + 1
                        iWorkingHydrogram = iWorkingHydrogram + 1

                        if(data && data.hasOwnProperty('measure') && data.measure.indexOf('ERR_') ) {
                            data.disabled = true;//TEST
                        }

                        console.log("enabled - ", h.id ,iHydroResponse+' '+ $scope.hydrograms.length);
                        if(iHydroResponse == $scope.hydrograms.length)showChart(sectionData.prop);



                    }, function (data) {

                        h.disabled = true;

                        iHydroResponse = iHydroResponse + 1
                        console.log("disabled - ",h.id,iHydroResponse+' '+ $scope.hydrograms.length)
                        if(iHydroResponse == $scope.hydrograms.length)showChart(sectionData.prop);





                    });

                //}


            });

            //setTimeout(function(){ showChart(sectionData.prop); }, 1000);


        }, function (data) {

            alert($translate.instant('ERROR_LOADING_DATA') + ': ' + data.error_message);

        });

    }



    function showChart(hydrogram) {

        //if (workingHydrogram) console.log("hydrogram loaded:" + workingHydrogram)

        //check active hydrogram
        toggleHydrogram(hydrogram)




        if (!chartManager.hasOwnProperty(hydrogram.type)) {

            alert($translate.instant('CHART_NOT_AVAILABLE'));
            return;

        }
        //Maximum

        switch (sectionData.serie){
            case 'po.fews.hydrometers':
                $scope.chartTitle = sectionData.section.NOME+  ' - ' + (sectionData.section.AREA? (sectionData.section.AREA + $sce.trustAsHtml('<span> km<sup>2</sup></span>') + ' - ') : '') + hydrogram.descr;
                break;
            default:
                $scope.chartTitle = '"' + (sectionData.section.SEZIONE? sectionData.section.SEZIONE : sectionData.section.DATI_DA) + (sectionData.section.NOME_BACIN? ('" (' + sectionData.section.NOME_BACIN + ') - ') : '" - ')
                    + (sectionData.section.AREA? (sectionData.section.AREA + $sce.trustAsHtml('<span> km<sup>2</sup></span>') + ' - ') : '') + hydrogram.descr;
                break;
        }



        var from = menuService.getDateFromUTCSecond();
        var to = menuService.getDateToUTCSecond();

        serieService.getSeriesDirect(sectionData.serverId, hydrogram.id, sectionData.section[hydrogram.fidField], from, to, function (data) {

            //se non è un array lo trasformo
            var res = [];

            if (!data[0]) res.push(data);
            else res = data;


            //		Expected: basin;section;procedure;run_data;meteo_model_run_date
            var title_tokens = res[0].title.split(";");
            var values = [];

            $scope.chartSubTitle = moment.utc(title_tokens[3], "YYYYMMDDHHmm").format('DD/MM/YYYY HH:mm');

            res.forEach(function(h) {
                values.push(h.values)
            });

            var thrs = [];
            if (sectionData.section.Q_ALLARME) {

                thrs.push({ name : 'Thr1(ALLARME)', value : sectionData.section.Q_ALLARME })
                thrs.push({ name : 'Thr2(ALLERTA)', value : sectionData.section.Q_ALLERTA })

            } else if (sectionData.section.N80PERCV_M) {

                thrs.push({ name : 'Thr1(80_PERC)', value : sectionData.section.N80PERCV_M })
                thrs.push({ name : 'Thr2(MAX_REGO)', value : sectionData.section.V_MAX_REGO })

            }

            if (hydrogram.type == 'DeterministicLevelHydrogramChart'){//lazio efforts
                if(sectionData.section.THR1){
                    thrs.push({ name : 'THR1', value : sectionData.section.THR1 })
                }
                if(sectionData.section.THR2){
                    thrs.push({ name : 'THR2', value : sectionData.section.THR2 })
                }
                if(sectionData.section.THR3){
                    thrs.push({ name : 'THR3', value : sectionData.section.THR3 })
                }
                if(sectionData.section.THR4){
                    thrs.push({ name : 'THR4', value : sectionData.section.THR4 })
                }

            }


            var hydrogramData = {
                id :hydrogram.id,
                feature:sectionData.section,
                section : sectionData.section.SEZIONE,
                area : sectionData.section.AREA,
                basin : sectionData.section.NOME_BACIN,
                thresholds : thrs,
                section: sectionData.section,
                serverId: sectionData.serverId,
                procedure : '',
                scenario : '',
                dateRef : moment.utc(title_tokens[3], "YYYYMMDDHHmm").valueOf(),
                now : menuService.getDateToUTCSecond() * 1000,
                timeline : res[res.length - 1].timeline,
                values : values,
                isRealTime : menuService.isRealTime(),
                yRuler:null
            };



            if((hydrogram.id.split(".")[2].indexOf("gaugeobservation")> -1)||(hydrogram.id.split(".")[2].indexOf("deterministiclami")> -1)){
                //siamo in osservato quindi carico anche deterministico
                //erg.floodproofs.deterministiclami
                var serie = hydrogram.id.split(".")[0]+"."+hydrogram.id.split(".")[1]+"."+"deterministiclami";
                if (hydrogram.id.indexOf("dams")>-1 )serie+=".dams"
                var fromDayBefore = parseInt(moment(new Date(from*1000)).add(-1, 'days').hour(12).minutes(30).valueOf()/1000);
                var toDayBefore = parseInt(moment(new Date(to*1000)).add(-1, 'days').hour(12).minutes(30).valueOf()/1000);

                serieService.getSeriesDirect(sectionData.serverId, serie, sectionData.section[hydrogram.fidField], fromDayBefore, toDayBefore, function (data1) {

                    //console.log(data1);

                    hydrogramData.deterministicDayBefore =data1;


            //per floodPROOFS ALBANIA MARCHEva calcolatoin questo modo perche nella serie originale manca l'osservato

            if (!hydrogramData.values[1]){
                hydrogramData.values[1] = hydrogramData.values[0];
                try {
                    hydrogramData.values[0].forEach(function (value) {
                        value = -9999;
                    });
                }catch (e) {
                    alert($translate.instant('NO_GAUGE_OBSERVATION'));
                }

            }
            //per floodPROOFS ALBANIA MARCHEva calcolatoin questo modo END

            setTimeout(function() {
                console.log(hydrogram.type);
                var settings = chartSettings[hydrogram.type];
                $scope.isVolumeSeries = (hydrogram.type.indexOf("Probabilistic") >= 0)? null : (settings.isVolume? true : false);

                settings.hydrogramsIndexOffset = (((hydrogram.id.indexOf("erg.") >= 0) && (hydrogram.id.indexOf(".dams") >= 0))? 2 : 0);

                settings.yAxisExtremes = yAxisExtremes[hydrogram.type];


                $scope.chart = chartManager[hydrogram.type](hydrogramData, menuService.oChartSize.m_iFloodProofsChartHeight(), settings, $sce, rasorService, _,$translate);


            }, 0);

                }, function (err) {

                    //se non trova deterministico
                    //per floodPROOFS ALBANIA MARCHEva calcolatoin questo modo perche nella serie originale manca l'osservato

                    if (!hydrogramData.values[1]){
                        hydrogramData.values[1] = hydrogramData.values[0];

                        hydrogramData.values[0].forEach(function (value) {
                            value = -9999;
                        });
                    }
                    //per floodPROOFS ALBANIA MARCHEva calcolatoin questo modo END

                    setTimeout(function() {

                        var settings = chartSettings[hydrogram.type];
                        $scope.isVolumeSeries = (hydrogram.type.indexOf("Probabilistic") >= 0)? null : (settings.isVolume? true : false);
                        settings.hydrogramsIndexOffset = (((hydrogram.id.indexOf("erg.") >= 0) && (hydrogram.id.indexOf(".dams") >= 0))? 2 : 0);
                        settings.yAxisExtremes = yAxisExtremes[hydrogram.type];
                        $scope.chart = chartManager[hydrogram.type](hydrogramData, menuService.oChartSize.m_iFloodProofsChartHeight(), settings, $sce, rasorService, _,$translate);

                        console.log("load: "+hydrogram.type);

                    }, 0);

                });

            }else{

                //per floodPROOFS ALBANIA MARCHEva calcolatoin questo modo perche nella serie originale manca l'osservato

                if (!hydrogramData.values[1]){
                    hydrogramData.values[1] = hydrogramData.values[0];
                    hydrogramData.values[0].forEach(function (value) {
                        value = -9999;
                    });
                }
                //per floodPROOFS ALBANIA MARCHEva calcolatoin questo modo END

                setTimeout(function() {

                    var settings = chartSettings[hydrogram.type];
                    $scope.isVolumeSeries = (hydrogram.type.indexOf("Probabilistic") >= 0)? null : (settings.isVolume? true : false);
                    settings.hydrogramsIndexOffset = (((hydrogram.id.indexOf("erg.") >= 0) && (hydrogram.id.indexOf(".dams") >= 0))? 2 : 0);
                    settings.yAxisExtremes = yAxisExtremes[hydrogram.type];
                    $scope.chart = chartManager[hydrogram.type](hydrogramData, menuService.oChartSize.m_iFloodProofsChartHeight(), settings, $sce, rasorService, _, $translate);

                    console.log("load: "+hydrogram.type);

                }, 0);

            }




        }, function (data) {
            alert($translate.instant('UNAVAILABLE_DATA'));
        });

    }

    function toggleHydrogram(h) {



        $scope.hydrograms.forEach(function(hydrogram) {
            hydrogram.active = ((hydrogram.type === h.type)&&(hydrogram.id === h.id));
            //se è attivo non puo essere disabilitato.. errore su risposta server
            // if(hydrogram.active) hydrogram.disabled = false;

        });

        $scope.HydrogramSelected = $scope.hydrograms.filter(h => h.active == true)[0]

        //console.log((h.type+ "-"+h.id));

    }

    $scope.orderHydrogram = function (item) {
        //ordino gli elementi nell ng repeat per l'indice che hanno nell array orderChartChooser
        var iIndex;
        orderChartChooser.forEach(function(currentValue,index,arr){
            if(item.descr.indexOf(currentValue) > -1) iIndex = index
        })
        return iIndex;
    }

    $scope.formatStringToFixed = function(val){
        // < || >
        if(val.indexOf('<')||val.indexOf('>')){
            return val;
        }else{
            return parseFloat(val).toFixed(2).toString();
        }

    }

    $scope.chartTitleFormatter = function (descr) {
        return descr.toUpperCase().trim().replace(/ /g,"_");
    }

}]);
