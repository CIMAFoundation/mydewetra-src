/**
 * Created by Dario Rubado on 30/09/16.
 */
dewetraApp.controller("reportPrintController", ['$scope', '$uibModalInstance','params', 'mapService',  '$http', 'printService','$interval', '$window', 'reportService' , '$timeout',function ($scope, $uibModalInstance,params, mapService,  $http, printService,$interval, $window, reportService , $timeout) {

    
    $scope.init = function () {
        
        $scope.oConfig = {
            pptx: {
                type: "pptx",
                title: "REPORT DEWETRA 2",
                creator: "CIMA FOUNDATION"
            },
            docx: {
                type: "docx",
                title: "REPORT DEWETRA 2",
                subject: "REPORT DEWETRA 2",
                creator: "CIMA FOUNDATION",
                description: "REPORT DEWETRA 2"
            }
        }

        $scope.data = {
            type: "pptx",
        }

        
    };
    
    
    $scope.loadImagePreview = function () {
        $scope.aPngUrl = reportService.getReportImagePreviewUrl();
        
    };


    $scope.update = function () {
        $uibModalInstance.close();
    };

    $scope.closePopup = function () {
        $uibModalInstance.dismiss()
    };
    
    $scope.buildReport= function(){
        reportService.getReportFile($scope.data.type, $scope.oConfig[$scope.data.type], function (data) {
            // console.log(data);

            //automate download pptx
            var a = document.createElement('a');
            a.href = data;
            document.body.appendChild(a);
            // a.download = true;
            // ritardo lo scaricamento senno me lo restituisce non printo
            $timeout(function () {
                a.click()
            },3000)

        })
    }

    // $scope.downloadReport = function (){
    //
    //
    // }
    
    $scope.init()

}]);
