
var settings = {};

var dewetraApp = angular.module('dewetra', ['acroweb', 'ui.bootstrap','as.sortable','ui.bootstrap.datetimepicker'/*,'uiSwitch'*/,'tmh.dynamicLocale','ui.select','ngSanitize'])
    .config(['tmhDynamicLocaleProvider',function(tmhDynamicLocaleProvider) {
        tmhDynamicLocaleProvider.localeLocationPattern('apps/dewetra2/node_modules/angular-i18n/angular-locale_{{locale}}.js');
    }]);


//declare api base url
acrowebDeclareApiBaseUrl(window.app.url.apiServerURL);
acrowebDeclareApiBaseUrl(window.app.url.dewapiURL);
acrowebDeclareApiBaseUrl(window.app.url.sentinelURL);
acrowebDeclareApiBaseUrl(window.app.url.printerServerURL);
acrowebDeclareApiBaseUrl(window.app.url.propagatorServerUrl);

//load language translation data for current app
acrowebSetApplicationName('dewetra2');

acrowebLoadTranslation(dewetraApp, 'dewetra2');

dewetraApp.factory('_', function() {
    return window._; // assumes underscore has already been loaded on the page
});
//
console.log(" ████████████    ███        ███   ███         ███      █████████");
console.log(" ███       ███    ███          ███           ███     ███       ███");
console.log(" ███       ███     ███        ██████        ███               ███");
console.log(" ███       ███      ███      ███  ███      ███               ███");
console.log(" ███       ███       ███    ███    ███    ███              ███");
console.log(" ███       ███        ███  ███      ███  ███              ███");
console.log(" ███       ███         ██████        ██████             ███     ██");
console.log(" ████████████           ████          ████            ████████████");



dewetraApp.directive('myEsc', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if(event.which === 27) {
                // console.log(event);
                scope.$apply(function (){
                    scope.$eval(attrs.myEsc);
                });
                event.preventDefault();
            }
        });
    };
});
