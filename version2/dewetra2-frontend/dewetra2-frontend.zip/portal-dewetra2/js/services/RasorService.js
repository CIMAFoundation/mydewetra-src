/**
 * Created by Dario Rubado on 27/05/15.
 */

dewetraApp.service('rasorService', ['$uibModal', '$rootScope', '$timeout', '$http', '$window', 'menuService', '$translate', 'mapService','tagService', 'layerService', 'serieService', 'acEvent', 'audioService', 'apiService', 'acLogbook', '_', 'sentinelService', '$interval', 'floodproofsService', '$location', 'iconService', 'thresholdService','acUserResource',function ($uibModal, $rootScope, $timeout, $http, $window, menuService, $translate, mapService,tagService, layerService, serieService, acEvent, audioService, apiService, acLogbook, _, sentinelService, $interval, floodproofsService, $location, iconService, thresholdService,acUserResource) {


    var warningInfo= null;


    return {
        hasWarningInfo :function () {
           return (warningInfo == null)
        },
        setWarningInfo:function (wi) {
            warningInfo = wi
        },
        rasorDamageLayerLoader: function (hydrogram, scenarioIndex) {
            var layer= {
                icon :null,
                descr:"impact_forecast",
                latn:44.45,
                lats:44.35,
                lone:9,
                lonw:8.9,
                server:{id:hydrogram.serverId},
                type:{
                    code:"RASOR_DAMAGE"
                }
            };

            hydrogram.indexOfSeries = scenarioIndex;

            var manager = layerManager_rasor_damage(layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService);
            manager.load(function () {
                //passo la lista layer
                mapService.oLayerList.addLayer(manager);
                manager.disablePros();
                //manager.showProps = {};//disable show props
                if (manager.hasOwnProperty('setWarningInfo')) manager.setWarningInfo(warningInfo);

                // add logbook activity
                setTimeout(function () {
                    acLogbook.logActivity('dewetra2', 'layer added: ' + 'rasor')
                }, 0)

            }, hydrogram);
        }
    }

}]);



