/**
 * Created by Dario Rubado on 13/04/16.
 */
dewetraApp.service('printService', ['$rootScope', '$http','_','$window','menuService','$translate','apiService','$location',
'acAuthSrv',function ($rootScope, $http, _, $window , menuService,$translate,apiService, $location, acAuthSrv) {


    return{

        setMap: function (oMap) {

        },

        getMapEncoded : function (mapService, aDraggable, aUndraggable) {
            const params = this.getMapsSettings(mapService, aDraggable, aUndraggable);
            const jsonParams = JSON.stringify(params);
            return LZString.compressToEncodedURIComponent(jsonParams);
        },

        getMapStateEncodedUrl:function(mapService, aDraggable, aUndraggable){

            const params = this.getMapsSettings(mapService, aDraggable, aUndraggable);
            const jsonParams = JSON.stringify(params);
            const paramString = LZString.compressToEncodedURIComponent(jsonParams);

            let baseURL = $location.absUrl();

            return baseURL.split('?')[0]+ '?' + insertParam('mapstate',paramString);

        },

        getMapStateDecodedUrl:function(){

            let mapState = getQueryVariable('mapstate');

            return JSON.parse(LZString.decompressFromEncodedURIComponent(mapState));

        },


        /**
         * passo l'oggetto mappa e due array di oggetti (layer manager) , il primo è la lista in ordine di profondita dei layer che si possono trasciare
         * nella layer list , il secondo è una lista di quelli della quale non posso gestire la profondita
         * @param mapService
         * @param aDraggable
         * @param aUndraggable
         * @param AdditionalInformation
         * @returns {{center: *, zoom: *, bounds: *, size: *, backgroundType: *, wmsLayers: Array, jsonLayers: Array}}
         */
        getMapsSettings: function (mapService, aDraggable, aUndraggable, AdditionalInformation) {

            var aLayersWms = [];
            var aLayersJson = [];

            var user= $rootScope.acSession.user.id;
            var hat = $rootScope.acSession.hat.descr;

            let token =(acAuthSrv.hasOwnProperty('getToken'))?encodeURIComponent(acAuthSrv.getToken()):undefined;
            if(angular.isUndefined(token)) token = encodeURIComponent($window.localStorage.token)


            if(aDraggable.length >0 ){
                aDraggable.forEach(function(layer){
                    //console.log(layer)
                    var obj ={
                        layerId : layer.mapLayer().wmsParams.layers,
                        server: layer.mapLayer()._url,
                        transparent : layer.mapLayer().wmsParams.transparent,
                        attribution : layer.mapLayer().options.attribution,
                        format : layer.mapLayer().options.format,
                        type:layer.layerObj().type.code.toUpperCase(),
                        name:$translate.instant(layer.layerObj().name),
                        legend:{
                            url:layer.mapLayer()._url,
                            name:$translate.instant(layer.layerObj().name)+"_legend",
                            layers:layer.mapLayer().wmsParams.layers,
                        },

                    };
                    if (angular.isDefined(layer.mapLayer().options.opacity)){
                        obj.opacity =layer.mapLayer().options.opacity;
                    }

                    if(layer.hasOwnProperty('haveDynamicPalette')){
                        if (layer.haveDynamicPalette().haveDynamicPalette == true){
                            obj.dynamicPalette = layer.haveDynamicPalette();
                        }
                    }

                    if(layer.hasOwnProperty('props')){
                        if (layer.props()){
                            obj.props = layer.props();
                        }
                    }

                    if(layer.hasOwnProperty('item')){
                        if (layer.item()){
                            obj.item = layer.item();
                        }
                    }

                    if(layer.hasOwnProperty('layerObj')){
                        if (layer.layerObj()){
                            obj.layerObj = layer.layerObj();
                        }
                    }

                    if(layer.hasOwnProperty('layerTooltip')){
                        if (layer.layerTooltip()){
                            obj.layerTooltip = layer.layerTooltip();
                            obj.layerTooltip.map((ttip) => {
                                ttip.label = $translate.instant(ttip.label);
                                ttip.value = $translate.instant(ttip.value);
                                return ttip
                            })
                        }
                    }

                    if(layer.hasOwnProperty('legend')){
                        layer.legend((data) => {
                            obj.fullLegend = data;
                        });
                    }

                    aLayersWms.push(obj);
                })
            }

            if(aUndraggable.length >0 ){
                aUndraggable.forEach(function(layer){

                    var obj ={
                        layerType : layer.layerObj()['type'].code,
                        name:$translate.instant(layer.layerObj().name),
                        geoJsonLayer : layer.mapLayer().toGeoJSON(),
                        props:(layer.props)?layer.props():null,
                        legend:{
                            type:layer.layerObj()['type'].code,
                            name:$translate.instant(layer.layerObj().name)+"_legend",
                            palette: []
                        }
                    };

                    if(layer.hasOwnProperty('props')){
                        if (layer.props){
                            obj.props = layer.props();
                        }
                    }

                    if(layer.hasOwnProperty('layerObj')){
                        if (layer.layerObj){
                            obj.layerObj = layer.layerObj();
                        }
                    }

                    aLayersJson.push(obj);
                })
            }

            function checkBaseLayerType() {
                if(mapService.getBaseLayer().options) return mapService.getBaseLayer().options.type;
                else if(mapService.getBaseLayer().name) return mapService.getBaseLayer().name;
                else return "HYBRID"
            }

            var backgroundType = checkBaseLayerType();

            var mapObj = {
                center: mapService.getMap().getCenter(),
                zoom: mapService.getMap().getZoom(),
                bounds:mapService.getMap().getBounds(),
                size : mapService.getMap().getSize(),
                dateTo:menuService.getUTCDateTo(),
                dateFrom:menuService.getUTCDateFrom(),
                user:user,
                hat: hat,
                backgroundType: backgroundType,
                wmsLayers: aLayersWms.reverse(),
                jsonLayers: aLayersJson,
                token,
                dewapiURL: window.app.url.dewapiURL
            };

            if (AdditionalInformation){
                mapObj.AdditionalInformation = AdditionalInformation;
            }

            return mapObj;
        },

        /**
         *
         * @param fileType es xlsx,docx,csv
         * @param obj different each type
         * xlsx {
         *         creator:"",
         *         title:"",
         *         data:[] an array of obj one each sheet with prop title:'name of page',and data [] array 2d
         *          }
         * @param callback data in callback {url: "http://sUrlToDownload"}
         */
        getDataToFile:function (fileType, obj,okCallback) {
            apiService.postPrintServer('datatofile/'+fileType+'/',obj,function (data) {
                if(okCallback)okCallback(data);
            })
        },

        renameFileDownload:function ( obj,okCallback) {
            apiService.postPrintServer('document/rename/?printer_url='+window.app.url.printerServerURL,obj,function (data) {
                if(okCallback)okCallback(data);
            })
        },

        getDataToExcel:function ( obj) {
            apiService.postPrintServer('datatofile/xlsx/',obj,function (data) {
                console.log(data)

                var a = document.createElement('a');
                a.href = data.url;
                document.body.appendChild(a);
                // a.download = true;
                // ritardo lo scaricamento senno me lo restituisce non printo
                $timeout(function () {
                    a.click()
                },3000)
            })
        },
        sendImageToDataLogByLink: (url, filename, okCallBack) => {
            let obj = {
                description: "Sent From Dw2 ",
                source: 'dewetra2',
                file:url,
                filename
            }

            apiService.postDataLogServer('v1/cloud/uploadlink/', obj, okCallBack)
        }
    }
}]);
