/**
 * Created by doy on 19/06/15.
 */


dewetraApp.service('layerService', ['$http', '$window', 'apiService', function($http, $window, apiService) {

    var mostUsedTags = null;

    function setTagsActivation(tags) {
        //activate the most used tags
        var tagToActivate = null;
        var tmpRank=0, rank = 9999;
        tags.forEach(function (tag) {
            tag.active = false;
            for(var i=0; i<mostUsedTags.length; i++) {
                if (mostUsedTags[i] == tag.id) {
                    tmpRank=i;
                    break
                }
            }
            if (tagToActivate==null || rank>tmpRank) {
                rank = tmpRank;
                tagToActivate = tag
            }
        });
        if (tagToActivate) tagToActivate.active = true
    }

    function layerHasGroupIn(layer, groups) {
        if (layer.hasOwnProperty('hierarchy'))
            return (groups.indexOf(layer.hierarchy) >= 0)
        else if (layer.hasOwnProperty('hierarchies'))
            return (groups.indexOf(layer.hierarchies[0]) >= 0)
        else return false
    }

    function getLayers(category, bbox, callback) {

        if(bbox == null){
            var url = 'settings/layers/?category__name=' + category + "&limit=0";
        }else {
            //lonW,latS,lonE,latN
            var url = 'settings/layers/?category__name=' + category + '&extent=' + bbox.getWest() + ',' + bbox.getSouth() + ',' + bbox.getEast() + ',' + bbox.getNorth() + "&limit=0";
        }


        apiService.get(url, function (data) {

            // console.log(data)

            //create am array with all the tags declared for the layers
            //and filter the layers with the global variables layerGroupsAllowed and layerGroupsNotAllowed
            data.tags = [];
            allowedLayers = [];
            data.objects.forEach(function (l) {
                if (window.layerGroupsAllowed && window.layerGroupsAllowed.length>0) {
                    if (layerHasGroupIn(l,window.layerGroupsAllowed)) allowedLayers.push(l)
                } else {
                    if (window.layerGroupsNotAllowed && window.layerGroupsNotAllowed.length>0) {
                        if (!layerHasGroupIn(l,window.layerGroupsNotAllowed)) allowedLayers.push(l)
                    } else {
                        allowedLayers.push(l)
                    }
                }
            });
            data.objects = allowedLayers;
            data.objects.forEach(function (l) {
                if (l.tags) {
                    l.tags.forEach(function (t) {
                        var f = data.tags.filter(function( obj ) {
                            return obj.id == t.id;
                        });
                        if (f.length <= 0) data.tags.push(t)
                    })
                }
            });


            //check if statics are already loaded
            if (mostUsedTags == null) {
                apiService.get('statistics/tagsrank/', function (tags) {
                    mostUsedTags = tags;
                    setTagsActivation(data.tags);
                    callback(data)
                })
            } else {
                setTagsActivation(data.tags);
                callback(data)
            }

        })
    }

    return {

        /**
         * retrieve all static layers that intersects a geographic area
         * @param bbox leaflet LatLngBounds object
         * @param callback
         */
        getStaticLayers: function (bbox, callback) {
            getLayers('static', bbox, callback)
        },

        /**
         * retrieve all obseravation layers that intersects a geographic area
         * @param bbox leaflet LatLngBounds object
         * @param callback
         */
        getObservationLayers: function (bbox, callback) {
            getLayers('observation', bbox, callback)
        },

        /**
         * retrieve all forecast layers that intersects a geographic area
         * @param bbox leaflet LatLngBounds object
         * @param callback
         */
        getForecastLayers: function (bbox, callback) {
            getLayers('forecast', bbox, callback)
        },

        /**
         * retrieve all forecast layers that intersects a geographic area
         * @param bbox leaflet LatLngBounds object
         * @param callback
         */
        getEventLayers: function (bbox, callback) {
            getLayers('event', bbox, callback)
        },

        /**
         * retrieve all forecast layers that intersects a geographic area
         * @param category
         * @param bbox leaflet LatLngBounds object
         * @param callback
         */

        getLayers: function (category,bbox, callback) {
            getLayers(category, bbox, callback)
        },


        /**
         * retrieve all events with relative layers
         * @param callback
         */
        getEvents: function (callback) {
            //https://dds.cimafoundation.org/dewetra2/dewapi/events/list/
            apiService.get('events/list/', function (data) {
                if(callback)callback(data);
            })
        },


        /**
         * obtain the publication of a layer.
         * the publication is obtained by applying all the default values in the layer properties
         * @param layer a layer object
         * @param from epoch timestamp of the period start
         * @param to epoch timestamp of the period end
         * @param callback
         */
        publishLayer: function (layer, from, to, callback, koCallback) {

            var obj = {
                layer: layer.id,
                from: from,
                to: to
            };
            apiService.post('ddsmap/layer/', obj, callback, koCallback)
        },

        /**
         * retrieve the properties of a layer
         * @param layer a layer object
         * @param callback
         */
        getLayerProperties: function (layer, callback) {
            apiService.get('ddsmap/' + layer.server.id + '/' + layer.dataid + '/properties/', callback)
        },

        /**
         * retrieve the layer items availables in one period with specific properties
         * @param layer a layer object
         * @param props properties of the layer (...with modified values)
         * @param from epoch timestamp of the period start
         * @param to epoch timestamp of the period end
         * @param callback
         */
        getLayerAvailability: function (layer, props, from, to, callback, onError) {
            var obj = {
                props: props,
                from: from,
                to: to
            };
            apiService.post('ddsmap/' + layer.server.id + '/availability/', obj, callback, onError)
        },

        /**
         * publish a layer with specific properties
         * @param layer a layer object
         * @param props properties of the layer (...with modified values)
         * @param from epoch timestamp of the period start
         * @param to epoch timestamp of the period end
         * @param item one of the availables items of the layer
         * @param callback
         */
        republishLayer: function (layer, props, from, to, item, callback, onError) {

            var modProperties = angular.copy(props)
            if(modProperties.layerProperties.attributes && modProperties.layerProperties.attributes.length >0){
                modProperties.layerProperties.attributes.forEach(function (prop) {
                    if(prop.hasOwnProperty("visible")){
                        delete prop.visible;
                    }
                })
            }


            var obj = {
                props: modProperties,
                data: item,
                from: from,
                to: to
            };

            //console.log(obj)

            apiService.post('ddsmap/' + layer.server.id + '/publish/', obj, callback, onError)
        },

        /**
         * Get all published layers with description
         * //http://127.0.0.1:8000/dewapi/settings/layersdescr/
         * return
         * {
                "descr": "GFS 0.5 deg",
                "id": 1,
                "name": "GFS 0.5",
                "tags": "meteoforecast "
            },
         * @param callback
         */
        getLayersListAndDescription: function (callback) {
            apiService.get('settings/layersdescr/', callback)
        },

        getLayer: function (id, callback) {
            apiService.get('settings/layers/?id=' + id, callback)
        },

        getGeoServers: function (okCallback, koCallback) {
            apiService.get('config/servers/', okCallback, koCallback);
        },

        getWmsLayers: function (data, okCallback, koCallback) {
            apiService.post('configUtils/getWmsLayers/', data, okCallback, koCallback);
        },

        getWmsLayerDetail: function (data, okCallback, koCallback) {
            apiService.post(
                "configUtils/getWmsLayerDetail/",
                data,
                okCallback,
                koCallback);
        },

        toPermanentLayer: function (obj, okCallback, koCallback) {
            var url = 'ddsmap/permanent/' + obj.serverId + '/' + obj.layerId;

            apiService.get(url, okCallback, koCallback);
        },

        //movie

        /**
         * Per ottenere i dati supportati dalla movie
         * @param serverId
         * @param okCallback
         * @param koCallback
         */
        getSupportedMovie : function (serverId, okCallback, koCallback){
            apiService.get('ddsmap/supportedmovie/'+serverId+'/', okCallback, koCallback)
            //apiService.getExt('http://172.16.104.197:8000/dewapi/ddsmap/supportedmovie/'+serverId+'/', okCallback, koCallback)
        },

        /**
         * Per creare la movie di un dato
         * @param serverId
         * @param dataId
         * @param okCallback
         * @param koCallback
         */
        createMovie:function (serverId,dataId ,okCallback, koCallback) {
            apiService.get('ddsmap/createmovie/'+serverId+'/'+ dataId+'/', okCallback, koCallback)
            //apiService.getExt('http://172.16.104.197:8000/dewapi/ddsmap/createmovie/'+serverId+'/'+ dataId+'/', okCallback, koCallback)
        },

        /**
         * Per ricavare la movie già esistente di un dato
         * @param serverId
         * @param dataId
         * @param okCallback
         * @param koCallback
         */
        getMovie: function (serverId,dataId ,okCallback, koCallback) {
            apiService.get('ddsmap/getmovie/'+serverId+'/'+ dataId+'/', okCallback, koCallback)
            //apiService.getExt('http://172.16.104.197:8000/dewapi/ddsmap/getmovie/'+serverId+'/'+ dataId+'/', okCallback, koCallback)
            // es
            var es = {
                "datas": [
                {
                    "attributesEntry": {
                        "entry": [
                            {
                                "key": "variable",
                                "value": "tp;-"
                            },
                            {
                                "key": "aggregation",
                                "value": "1"
                            },
                            {
                                "key": "shp",
                                "value": "NOTHING"
                            }
                        ]
                    },
                    "timelineId": "COSMO_I2_tp;-_1_NOTHING"
                },
                {
                    "attributesEntry": {
                        "entry": [
                            {
                                "key": "variable",
                                "value": "tp;-"
                            },
                            {
                                "key": "aggregation",
                                "value": "12"
                            },
                            {
                                "key": "shp",
                                "value": "NOTHING"
                            }
                        ]
                    },
                    "timelineId": "COSMO_I2_tp;-_12_NOTHING"
                },
                {
                    "attributesEntry": {
                        "entry": [
                            {
                                "key": "variable",
                                "value": "2t;2.0"
                            },
                            {
                                "key": "aggregation",
                                "value": "1"
                            },
                            {
                                "key": "shp",
                                "value": "NOTHING"
                            }
                        ]
                    },
                    "timelineId": "COSMO_I2_2t;2.0_1_NOTHING"
                },
                {
                    "attributesEntry": {
                        "entry": [
                            {
                                "key": "variable",
                                "value": "2t;2.0"
                            },
                            {
                                "key": "aggregation",
                                "value": "12"
                            },
                            {
                                "key": "shp",
                                "value": "NOTHING"
                            }
                        ]
                    },
                    "timelineId": "COSMO_I2_2t;2.0_12_NOTHING"
                },
                {
                    "attributesEntry": {
                        "entry": [
                            {
                                "key": "variable",
                                "value": "2d;2.0"
                            },
                            {
                                "key": "aggregation",
                                "value": "1"
                            },
                            {
                                "key": "shp",
                                "value": "NOTHING"
                            }
                        ]
                    },
                    "timelineId": "COSMO_I2_2d;2.0_1_NOTHING"
                },
                {
                    "attributesEntry": {
                        "entry": [
                            {
                                "key": "variable",
                                "value": "2d;2.0"
                            },
                            {
                                "key": "aggregation",
                                "value": "12"
                            },
                            {
                                "key": "shp",
                                "value": "NOTHING"
                            }
                        ]
                    },
                    "timelineId": "COSMO_I2_2d;2.0_12_NOTHING"
                },
                {
                    "attributesEntry": {
                        "entry": [
                            {
                                "key": "variable",
                                "value": "qv_s;-"
                            },
                            {
                                "key": "aggregation",
                                "value": "1"
                            },
                            {
                                "key": "shp",
                                "value": "NOTHING"
                            }
                        ]
                    },
                    "timelineId": "COSMO_I2_qv_s;-_1_NOTHING"
                },
                {
                    "attributesEntry": {
                        "entry": [
                            {
                                "key": "variable",
                                "value": "qv_s;-"
                            },
                            {
                                "key": "aggregation",
                                "value": "12"
                            },
                            {
                                "key": "shp",
                                "value": "NOTHING"
                            }
                        ]
                    },
                    "timelineId": "COSMO_I2_qv_s;-_12_NOTHING"
                }
            ],
                "dtref": "1612483200000",
                "properties": {
                "attributes": [
                    {
                        "descr": "-",
                        "entries": {
                            "descr": "-",
                            "referredValues": null,
                            "value": "Forecast Models"
                        },
                        "name": "tool",
                        "selectedEntry": {
                            "descr": "-",
                            "referredValues": null,
                            "value": "Forecast Models"
                        },
                        "type": "Text",
                        "visible": "false"
                    },
                    {
                        "descr": "Variable",
                        "entries": [
                            {
                                "descr": "1h cumulated precipitation",
                                "referredValues": {
                                    "entry": [
                                        {
                                            "key": "cumulate",
                                            "value": "1"
                                        },
                                        {
                                            "key": "doDiff",
                                            "value": "1"
                                        },
                                        {
                                            "key": "paletteId",
                                            "value": "ACR4Rain"
                                        },
                                        {
                                            "key": "mu",
                                            "value": "mm"
                                        }
                                    ]
                                },
                                "value": "tp;-"
                            },
                            {
                                "descr": "Temperature at 2 m",
                                "referredValues": {
                                    "entry": {
                                        "key": "paletteId",
                                        "value": "ACR4TemperatureKTriv"
                                    }
                                },
                                "value": "2t;2.0"
                            },
                            {
                                "descr": "Convective Snow",
                                "referredValues": {
                                    "entry": {
                                        "key": "paletteId",
                                        "value": "ACR4TemperatureKTriv"
                                    }
                                },
                                "value": "snoc;-"
                            },
                            {
                                "descr": "Temperature at 500 hPa",
                                "referredValues": {
                                    "entry": {
                                        "key": "paletteId",
                                        "value": "ACR4TemperatureKTriv500hPa"
                                    }
                                },
                                "value": "t;64.0"
                            },
                            {
                                "descr": "Temperature at 850 hPa",
                                "referredValues": {
                                    "entry": {
                                        "key": "paletteId",
                                        "value": "ACR4TemperatureKTriv850hPa"
                                    }
                                },
                                "value": "t;65.0"
                            },
                            {
                                "descr": "Dew point temperature at 2 m",
                                "referredValues": {
                                    "entry": {
                                        "key": "paletteId",
                                        "value": "ACR4TemperatureKTriv"
                                    }
                                },
                                "value": "2d;2.0"
                            },
                            {
                                "descr": "Specific humidity",
                                "referredValues": {
                                    "entry": {
                                        "key": "paletteId",
                                        "value": "ACR4SpecHumidity"
                                    }
                                },
                                "value": "qv_s;-"
                            },
                            {
                                "descr": "Wind at 10 m",
                                "referredValues": {
                                    "entry": [
                                        {
                                            "key": "paletteId",
                                            "value": "ACR4Direction"
                                        },
                                        {
                                            "key": "undef",
                                            "value": "-999"
                                        },
                                        {
                                            "key": "band_v",
                                            "value": "10v"
                                        },
                                        {
                                            "key": "band_u",
                                            "value": "10u"
                                        }
                                    ]
                                },
                                "value": "MULTIBAND_WIND;10.0"
                            }
                        ],
                        "name": "variable",
                        "selectedEntry": {
                            "descr": "1h cumulated precipitation",
                            "referredValues": {
                                "entry": [
                                    {
                                        "key": "cumulate",
                                        "value": "1"
                                    },
                                    {
                                        "key": "doDiff",
                                        "value": "1"
                                    },
                                    {
                                        "key": "paletteId",
                                        "value": "ACR4Rain"
                                    },
                                    {
                                        "key": "mu",
                                        "value": "mm"
                                    }
                                ]
                            },
                            "value": "tp;-"
                        },
                        "type": "List",
                        "visible": "true"
                    },
                    {
                        "descr": "Cumulative Range",
                        "entries": [
                            {
                                "descr": "last 1 h",
                                "referredValues": null,
                                "value": "1"
                            },
                            {
                                "descr": "last 3 h",
                                "referredValues": null,
                                "value": "3"
                            },
                            {
                                "descr": "last 6 h",
                                "referredValues": null,
                                "value": "6"
                            },
                            {
                                "descr": "last 12 h",
                                "referredValues": null,
                                "value": "12"
                            },
                            {
                                "descr": "last 24 h",
                                "referredValues": null,
                                "value": "24"
                            },
                            {
                                "descr": "last 48 h",
                                "referredValues": null,
                                "value": "48"
                            }
                        ],
                        "name": "aggregation",
                        "selectedEntry": {
                            "descr": "last 1 h",
                            "referredValues": null,
                            "value": "1"
                        },
                        "type": "List",
                        "visible": "true"
                    },
                    {
                        "descr": "Spatial Resolution",
                        "entries": [
                            {
                                "descr": "Native",
                                "referredValues": null,
                                "value": "NOTHING"
                            },
                            {
                                "descr": "Region",
                                "referredValues": {
                                    "entry": [
                                        {
                                            "key": "idField",
                                            "value": "COD_REG"
                                        },
                                        {
                                            "key": "paletteField",
                                            "value": "VALUE"
                                        },
                                        {
                                            "key": "localFile",
                                            "value": "italy/regioni_ISTAT2001.shp"
                                        }
                                    ]
                                },
                                "value": "data/shpRisico/regioni_ISTAT2001.shp"
                            },
                            {
                                "descr": "Province",
                                "referredValues": {
                                    "entry": [
                                        {
                                            "key": "idField",
                                            "value": "COD_PRO"
                                        },
                                        {
                                            "key": "paletteField",
                                            "value": "VALUE"
                                        },
                                        {
                                            "key": "localFile",
                                            "value": "italy/province_ISTAT2001.shp"
                                        }
                                    ]
                                },
                                "value": "data/shpRisico/province_ISTAT2001.shp"
                            },
                            {
                                "descr": "Municipality",
                                "referredValues": {
                                    "entry": [
                                        {
                                            "key": "idField",
                                            "value": "PRO_COM"
                                        },
                                        {
                                            "key": "paletteField",
                                            "value": "VALUE"
                                        },
                                        {
                                            "key": "localFile",
                                            "value": "italy/comuni_ISTAT2001.dbf"
                                        }
                                    ]
                                },
                                "value": "data/shpRisico/comuni_ISTAT2001.shp"
                            },
                            {
                                "descr": "Meteo-Vigilance Area",
                                "referredValues": {
                                    "entry": [
                                        {
                                            "key": "idField",
                                            "value": "DGC_CODICE"
                                        },
                                        {
                                            "key": "paletteField",
                                            "value": "VALUE"
                                        },
                                        {
                                            "key": "localFile",
                                            "value": "italy/zone_vigilanza_meteo_wgs84_xsidro.shp"
                                        }
                                    ]
                                },
                                "value": "data/shpRisico/zone_vigilanza_meteo_wgs84_xsidro.shp"
                            },
                            {
                                "descr": "Warning Area",
                                "referredValues": {
                                    "entry": [
                                        {
                                            "key": "idField",
                                            "value": "COD_AREA"
                                        },
                                        {
                                            "key": "paletteField",
                                            "value": "VALUE"
                                        },
                                        {
                                            "key": "localFile",
                                            "value": "italy/Zone_di_Allertamento.shp"
                                        }
                                    ]
                                },
                                "value": "data/shpRisico/Zone_di_Allertamento.shp"
                            },
                            {
                                "descr": "Catchment",
                                "referredValues": {
                                    "entry": [
                                        {
                                            "key": "idField",
                                            "value": "NOME"
                                        },
                                        {
                                            "key": "paletteField",
                                            "value": "VALUE"
                                        },
                                        {
                                            "key": "localFile",
                                            "value": "italy/Catchments-ISPRA.shp"
                                        }
                                    ]
                                },
                                "value": "data/shpRisico/Catchments-ISPRA.shp"
                            }
                        ],
                        "name": "shp",
                        "selectedEntry": {
                            "descr": "Native",
                            "referredValues": null,
                            "value": "NOTHING"
                        },
                        "type": "List",
                        "visible": "true"
                    }
                ],
                    "data": "COSMO_I2",
                    "description": "COSMO_I2",
                    "id": "COSMO_I2",
                    "longDescription": "COSMO_I2"
            }
            }
        },

        /**
         * Per ricavare i valori di una determinata timeline in una movie
         * @param serverId
         * @param timelineId
         * @param okCallback
         * @param koCallback
         */
        getMovieTimeline: function (serverId,dataId,timelineId ,okCallback, koCallback) {
            apiService.get('ddsmap/getmovietimeline/'+ serverId+'/'+dataId+'/'+ timelineId+'/', okCallback, koCallback)
            //apiService.getExt('http://172.16.104.197:8000/dewapi/ddsmap/getmovietimeline/'+serverId+'/'+ dataId+'/'+ timelineId+'/', okCallback, koCallback)
        },

    }

}]);
