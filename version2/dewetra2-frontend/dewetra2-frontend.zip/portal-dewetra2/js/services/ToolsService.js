/**
 * Created by Dario Rubado on 29/08/18.
 */


dewetraApp.service('toolsService', ['$http', '$window','apiService', function($http, $window, apiService) {



    return {
        getTools:function (okCallback, koCallback) {
            apiService.get('settings/tools/',okCallback, koCallback)
        },

        getToolById: function (id, okCallback, koCallback) {
            apiService.get('tools/getToolById/?id='+id,okCallback, koCallback)
        },

        getWFSFilteredFeatures: function (data, okCallback, koCallback) {
            apiService.post('tools/getWFSFilteredFeatures/',data, okCallback,koCallback)
        },

        getScenario: function (data, okCallback, koCallback) {
            apiService.post('tools/getScenario/',data, okCallback,koCallback)
        },


        //exportDataCall

        exportDataFilters: function (data, okCallback, koCallback) {

            data.filters = data.filters.filter(filter => filter.descr != 'Station');

            apiService.post('tools/exportdata_filters/',data, okCallback, koCallback)
        },

        exportDataStations: function (data, okCallback, koCallback) {

            apiService.get('tools/exportdata_stations/?class='+data, okCallback, koCallback)
        },
        //https://dds.cimafoundation.org/dewetra2/dewapi/tools/exportdata_stations/?class=PLUVIOMETRO

        exportData: function (data, okCallback, koCallback) {

            apiService.post('tools/exportdata/',data, okCallback, koCallback)
        }
    }


}]);
