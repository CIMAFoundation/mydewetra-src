/**
 * Created by Dario Rubado on 26/11/15.
 */
dewetraApp.service('thresholdService', ['$http', 'apiService','settingsService', '$rootScope', function($http, apiService, settingsService, $rootScope) {

    var oSensorData = null;

    var nationalThresholdPluvio = null;


    function getNationalThreshold(featureProperties, onSuccess, onError){

        var sensorId = (featureProperties.hasOwnProperty("sensorid")?featureProperties.sensorid:featureProperties.nativeid)

        apiService.getSentinel("layer/thr/"+sensorId+"/"+featureProperties.dbid+"/", function (data) {

           // console.log(data);
            var thr = [];
            for(var i in data){
                if(data[i].group){
                    if(data[i].group.indexOf("national")>-1) thr.push(data[i]);
                }

            }

            if(onSuccess)onSuccess(thr)
        }, onError);

    }

    function getThreshold(featureProperties, onSuccess, onError){

        var sensorId = (featureProperties.hasOwnProperty("sensorid")?featureProperties.sensorid:featureProperties.nativeid)

        apiService.getSentinel("layer/thr/"+sensorId+"/"+featureProperties.dbid+"/", function (data) {



            if(onSuccess)onSuccess(data)
        }, onError);

    }

    function getNationalThresholdArrayBySensorClass(sensorClass, onSuccess, onError){
        if (nationalThresholdPluvio) {
            onSuccess(nationalThresholdPluvio);
        }else{
            apiService.getSentinel('layer/sensorclassthrs/'+sensorClass+'/', function (data) {
                nationalThresholdPluvio = data;
                onSuccess(data);
            }, onError);
        }
    }

    //https://dds.cimafoundation.org/sentinel/sentinelapi/layer/thrmod/514035/ trhid

    function getThresholdLastEditInfo(thrid, onSuccess, onError){
        apiService.getSentinel('layer/thrmod/'+thrid+'/',function (data) {
            onSuccess(data)
        }, onError)
    }

   function saveExistingThreshold(sensorId, dbId, thr, onSuccess, onError) {
       thr.user = $rootScope.acSession.user.id;
        apiService.patchSentinel("layer/thr/"+sensorId+"/"+dbId+"/", thr,function (data) {
           onSuccess(data);
       }, onError);
   }
    function addNewThreshold(sensorId, dbId, thr, onSuccess, onError) {
        thr.user = $rootScope.acSession.user.id;
        apiService.postSentinel("layer/thr/"+sensorId+"/"+dbId+"/", thr,function (data) {
            onSuccess(data);
        }, onError);
    }

    function deleteExistingThreshold(id, onSuccess, onError){

            let url = 'layer/delthr/'+id+'/?user='+$rootScope.acSession.user.id;

            apiService.deleteSentinel(url, onSuccess, onError);



    }

    return{
        getThreshold:getThreshold,
        getNationalThreshold:getNationalThreshold,
        getNationalThresholdArrayBySensorClass:getNationalThresholdArrayBySensorClass,
        addNewThreshold:addNewThreshold,
        saveExistingThreshold:saveExistingThreshold,
        deleteExistingThreshold: deleteExistingThreshold,
        getThresholdLastEditInfo:getThresholdLastEditInfo

    }
}]);
