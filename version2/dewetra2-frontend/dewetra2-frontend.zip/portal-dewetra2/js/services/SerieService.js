


dewetraApp.service('serieService', ['$http', 'apiService', function($http, apiService) {

    var data = null;

    var openChart = null;

    var allMyFeatures = null;

    //precarico le feature cosi nel magic search sono subito pronte
    getAllMyFeatures(function (data) {
        allMyFeatures = data
    });

    function getLayerData(layer, callback, hardCodedProp) {

        apiService.get('ddsserie/' + layer.server.id + '/' + layer.dataid.split('.').join('__') + '/properties/', function (prop) {

            var data = {
                layer: layer,
                prop: prop
            };

            if (hardCodedProp){
                //esempio se ci sono delle proprieta hardcoded le passo e le cambio qui
                for (var p in  data.prop){
                    if (hardCodedProp[p]){
                        data.prop[p] = hardCodedProp[p];
                    }
                }

            }

            callback(data)

        })
    }

    function getWFSUrl(layerData) {
        return layerData.layer.server.url + "/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=" + layerData.prop.layer;
    }

    function getAvailability(server, serieId, from, to, props, onSuccess, onError) {
        var obj = {
            "id": serieId,
            "from" : from,
            "to" : to,
            "props" : props
        };
        apiService.post('ddsserie/' + server + '/serieavailability/', obj, onSuccess, onError)
    }

    function getGeoJson(layerData, onSuccess, onError) {
        if (layerData!=null) {
            $http.get(getWFSUrl(layerData))
                .then(function(data, status, headers, config) {
                    if (onSuccess) onSuccess(data.data);
                },function(data, status, headers, config) {
                    if (onError) onError(data);
                })

        } else {
            if (onError) onError('layer not specified')
        }

    }

    function getSeriesDirect(server, serieId, featureId, from, to, onSuccess, onError) {
        o = {
            id: serieId,
            feature : featureId,
            from : from,
            to : to
        };
        apiService.post('ddsserie/' + server + '/series/', o, onSuccess, onError)
    }

    //
    function getSeriesDirectCombined(series, onSuccess, onError) {

        series.forEach(function (serie) {

        })

        o = {
            server:serie.server,
            id: serie.serieId,
            feature : serie.featureId,
            from : serie.from,
            to : serie.to
        };
        apiService.post('ddsserie/' + o.server + '/series/', o, function (data) {



        }, onError)
    }

    function getSeries(layerData, feature, from, to, onSuccess, onError) {
        if (layerData != null) {
            if (feature.hasOwnProperty(layerData.prop.fidField)) {
                getSeriesDirect(layerData.layer.server.id, layerData.layer.dataid, feature[layerData.prop.fidField], from, to, onSuccess, onError);
            } else {
                if (onError) onError('feature does not contains required field')
            }
        } else {
            if (onError) onError('layer not specified')
        }

    }

    function getAllMyFeatures(onSuccess, onError) {
        if (allMyFeatures) {
            onSuccess(allMyFeatures)
        } else {
            apiService.get('ddsserie/features/', function (data) {
                allMyFeatures = data;
                onSuccess(data)
            }, onError)
        }
    }

    function openChart(chartIdStation){
        if (chartIdStation){
            openChart = chartIdStation;
            return openChart;
            console.log("chart Open: " +openChart)
        }else {
            openChart = null;
            return openChart;
        }
    }

    function punctualSerie(id,props,from, to ,lon, lat, okCallback, koCallback) {


        var o = {
            props:props,
            from:parseInt(from),
            to:parseInt(to),
            lon:lon,
            lat:lat,
        };
        //console.log(o)

        apiService.post('ddsmap/'+id+'/punctualserie/',o, okCallback, koCallback)
    }

    function areaSerie(id,props,from, to ,points, okCallback, koCallback) {

        var o = {
            props:props,
            from:parseInt(from),
            to:parseInt(to),
            points: points
        };
        //console.log(o)

        apiService.post('ddsmap/'+id+'/areaserie/',o, okCallback, koCallback)
    }



    return {
        getPunctualSerie:punctualSerie,
        getAreaSerie : areaSerie,
        openChart : openChart,
        //setLayer: setLayer,
        getLayerData: getLayerData,
        getGeoJson: getGeoJson,
        getSeries: getSeries,
        getSeriesDirect: getSeriesDirect,
        getAllMyFeatures: getAllMyFeatures,
        getAvailability: getAvailability

    }

}]);
