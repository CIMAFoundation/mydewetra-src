/**
 * Created by Dario Rubado on 03/09/15.
 */


dewetraApp.service('settingsService', ['apiService', function(apiService) {

    var settings = null;
    return {
        settings: function (callback) {
            if (settings == null) {
                apiService.get('settings/settings/', function(data) {
                    settings = data.objects[0];
                    callback(settings)
                })
            } else {
                callback(settings)
            }
        }
    }

}]);

