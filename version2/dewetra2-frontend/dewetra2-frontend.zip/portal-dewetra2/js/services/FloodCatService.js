/**
 * Created by Dario Rubado on 27/05/15.
 */

dewetraApp.service('floodCatService', ['acHttpSrv', 'menuService', '_','apiService' ,function( acHttpSrv, menuService, _,apiService) {


    var advancedSearchFilter = {
        geoTypeFilter: '',
        geoValueFilter: '0' ,
        eventTypeFilter: '-1',
        eventSourceFilter: '',
        txtFreeSearch:'',
        eventValidationStatus: '-1',
        startDate:'',
        endDate:''
    };

    return {
        getFloodCatEvents:function (obj, okCallback,koCallback) {


            // (obj.hasOwnProperty('startDate'))?obj.startDate:  obj.startDate=menuService.getDateTo();
            (obj.hasOwnProperty('startDate'))?obj.startDate:  obj.startDate=new Date(2016,10,30);
            (obj.hasOwnProperty('endDate'))?obj.endDate: obj.endDate=new Date(2017,9,30);
            // (obj.hasOwnProperty('endDate'))?obj.endDate: obj.endDate=menuService.getDateFrom();
            // obj.endDate= obj.endDate.setDate(obj.endDate.getDate()-15);
            (obj.hasOwnProperty('eventTypeFilter'))?obj.eventTypeFilter:  obj.eventTypeFilter="-1";
            (obj.hasOwnProperty('eventValidationStatus'))?obj.eventValidationStatus:  obj.eventValidationStatus="-1";
            (obj.hasOwnProperty('eventSourceFilter'))?obj.eventSourceFilter:  obj.eventSourceFilter="";
            (obj.hasOwnProperty('geoTypeFilter'))?obj.geoTypeFilter:  obj.geoTypeFilter="";
            (obj.hasOwnProperty('txtFreeSearch'))?obj.txtFreeSearch:  obj.txtFreeSearch="";
            // (obj.hasOwnProperty('geoValueFilter'))?obj.geoValueFilter:  obj.geoValueFilter="0";
            // (obj.hasOwnProperty('location'))?obj.location:  obj.location=[];
            (obj.hasOwnProperty('pageNum'))?obj.pageNum:obj.pageNum=1;
            (obj.hasOwnProperty('pageDim'))?obj.pageDim:obj.pageDim=0;
            // obj.startDate = new Date($scope.endDate.getTime() - (12*30*24*60*60*1000));
            var _this = this;
            acHttpSrv.acrowebPost(
                "api/floodcat/events/" + obj.pageNum + "/" +obj.pageDim,

                //ORG!!!
                //{
                //    "startDate": startDate,
                //    "endDate": endDate,
                //    "location": area
                //},

                obj,
                okCallback,
                koCallback,
                "Error loading flood events!"
            );
        },
        transformToGeoJson:function (data) {

            var getArrayOfCoordinates = function (arrayOfObj, geomType) {

                switch (geomType){
                    case "Point":
                        return [arrayOfObj[0].item[0].lon,arrayOfObj[0].item[0].lat]
                        break;
                    case "MultiPoint":
                        var array = [];

                        arrayOfObj[0].item.forEach(function (obj) {
                            array.push([obj.lon,obj.lat])
                        })
                        return array;

                    case "LineString":
                        var array = [];
                        arrayOfObj[0].item.forEach(function (obj) {
                            array.push([obj.lon,obj.lat])
                        })
                        return array;

                    case "MultiLineString":
                        var array = [];
                        arrayOfObj[0].item.forEach(function (obj) {
                            array.push([obj.lon,obj.lat])
                        })
                        return array;

                    case "Polygon":

                        var array = [];

                        arrayOfObj[0].item.forEach(function (obj) {
                            array.push([obj.lon,obj.lat])
                        })
                        return [array];
                    case "MultiPolygon":

                        var array = [];

                        arrayOfObj.forEach(function (obj,index,a) {
                            var polygon =[]
                            obj.item.forEach(function (loc) {
                                polygon.push([loc.lon,loc.lat])
                            })
                            array.push([polygon])
                        })

                        return array;
                }


            }

            var aLocalizedEvents = _.filter(data,function (events) {
                return (events.locsList.length > 0);
            })
            var aFeatures = [];

            aLocalizedEvents.forEach(function (event) {

                event.locsList.forEach(function (feature) {
                    aFeatures.push({
                        "type":"Feature",
                        // "properties":{
                        //     "locCode":feature.locCode
                        // },
                        "properties":event.event,
                        "geometry":{
                            "type":feature.geomType,
                            "coordinates":getArrayOfCoordinates(feature.geom, feature.geomType)
                        }
                    })
                });
            });

            var eventsJson = {
                "type": "FeatureCollection",
                // "crs":{
                //     "properties":{
                //         "name":"EPSG:4326"
                //     }
                // },
                "features": [
                    // {
                    //     "type": "Feature",
                    //     "geometry": {"type": "Point", "coordinates": [102.0, 0.5]},
                    //     "properties": {"prop0": "value0"}
                    // },
                    // {
                    //     "type": "Feature",
                    //     "geometry": {
                    //         "type": "LineString",
                    //         "coordinates": [
                    //             [102.0, 0.0], [103.0, 1.0], [104.0, 0.0], [105.0, 1.0]
                    //         ]
                    //     },
                    //     "properties": {
                    //         "prop0": "value0",
                    //         "prop1": 0.0
                    //     }
                    // },
                    // {
                    //     "type": "Feature",
                    //     "geometry": {
                    //         "type": "Polygon",
                    //         "coordinates": [
                    //             [[100.0, 0.0], [101.0, 0.0], [101.0, 1.0],
                    //                 [100.0, 1.0], [100.0, 0.0]]
                    //         ]
                    //     },
                    //     "properties": {
                    //         "prop0": "value0",
                    //         "prop1": {"this": "that"}
                    //     }
                    // }
                ]
            }

            eventsJson.features = aFeatures;
            // apiService.postPrintServer('savemap', eventsJson,function (data) {
            //     console.log(data)
            //     return eventsJson;
            // })
            return eventsJson;



        }
    }

}]);

