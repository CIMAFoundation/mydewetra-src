/**
 * Created by Dario Rubado on 27/02/19.
 */
dewetraApp.service('desinventarService', ['apiService',function (apiService) {

    var desinventarUrl

    return {

    }

}]);
