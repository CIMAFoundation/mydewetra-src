/**
 * Created by Dario Rubado on 24/11/15.
 */

dewetraApp.service('sentinelService', ['$http', 'apiService','settingsService','menuService', function($http, apiService, settingsService, menuService) {



    //ritorna le soglie di un sensore
    //window.app.url.sentinelURL+layer/thr/SENSOR_ID/DB_ID/

    //window.app.url.sentinelURL+lspp/punctual/8.23/44.34/

    function getPluvioLsppPunctual(lat, lon , onSuccess, onError) {

        apiService.getSentinel("lspp/punctual/"+lon+"/"+lat+"/"  , onSuccess, onError);
    }

    function getNationalTermo(onSuccess, onError){

        if (!menuService.isRealTime()) {
            //se è presente una data prendo layer sentinel nel passato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/past/"+data.stationgroup+"/national_TERMOMETRO/5/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
            })
        }else{
            //se non è presente data prendo layer aggiornato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/"+data.stationgroup+"/national_TERMOMETRO/5/", onSuccess, onError);
            })
        }
    }

    /***
     * get pluviometer
     * @param date
     * @param onSuccess
     * @param onError
     */
    function getNationalPluvio(onSuccess, onError,unStandardTimeRange){


        if (unStandardTimeRange){
            settingsService.settings(function (data) {

                let iTimerange = parseInt(menuService.getDateToUTCSecond() - menuService.getDateFromUTCSecond())

                apiService.getSentinel("layer/pluvio/"+data.stationgroup+"/"+parseInt(menuService.getDateToUTCSecond())+"/"+iTimerange+"/", onSuccess, onError);
            })
        }else{
            if (!menuService.isRealTime()) {
                //se è presente una data prendo layer sentinel nel passato
                settingsService.settings(function (data) {
                    apiService.getSentinel("layer/past/"+data.stationgroup+"/national_PLUVIOMETRO/2/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
                })
            }else{
                //se non è presente data prendo layer aggiornato
                settingsService.settings(function (data) {
                    apiService.getSentinel("layer/"+data.stationgroup+"/national_PLUVIOMETRO/2/", onSuccess, onError);
                })
            }
        }



    }

    function getNationalIdro(onSuccess, onError){

        if (!menuService.isRealTime()) {
            //se è presente una data prendo layer sentinel nel passato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/past/"+data.stationgroup+"/national_IDROMETRO/3/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
            })
        }else{
            //se non è presente data prendo layer aggiornato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/"+data.stationgroup+"/national_IDROMETRO/3/", onSuccess, onError);
            })
        }
    }

    function getFloodWave(basin,onSuccess, onError){
        ////window.app.url.sentinelURL+layer/floodwave/?main_basin=42&to=1508068800&from=1508025600
        // layer/floodwave/?main_basin=42&to=1508068800&from=1508025600
        var url = "layer/floodwave/?main_basin="+basin+"&to="+parseInt(menuService.getDateToUTCSecond())+"&from="+parseInt(menuService.getDateFromUTCSecond());
        apiService.getSentinel(url, onSuccess, onError);
    }

    function getNationalIgro(onSuccess, onError){

        if (!menuService.isRealTime()) {
            //se è presente una data prendo layer sentinel nel passato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/past/"+data.stationgroup+"/national_IGROMETRO/9/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
            })
        }else{
            //se non è presente data prendo layer aggiornato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/"+data.stationgroup+"/national_IGROMETRO/9/", onSuccess, onError);
            })
        }
    }

    function getNationalWindDirection(onSuccess, onError){

        if (!menuService.isRealTime()) {
            //se è presente una data prendo layer sentinel nel passato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/past/"+data.stationgroup+"/national_ANEMOMETRO/10/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
            })
        }else{
            //se non è presente data prendo layer aggiornato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/"+data.stationgroup+"/national_ANEMOMETRO/10/", onSuccess, onError);
            })
        }
    }

    function getNationalWindSpeed(onSuccess, onError){

        if (!menuService.isRealTime()) {
            //se è presente una data prendo layer sentinel nel passato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/past/"+data.stationgroup+"/national_ANEMOMETRO/11/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
            })
        }else{
            //se non è presente data prendo layer aggiornato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/"+data.stationgroup+"/national_ANEMOMETRO/11/", onSuccess, onError);
            })
        }
    }

    function getNationalNivometer(onSuccess, onError){

        if (!menuService.isRealTime()) {
            //se è presente una data prendo layer sentinel nel passato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/past/"+data.stationgroup+"/national_NIVOMETRO/4/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
            })
        }else{
            //se non è presente data prendo layer aggiornato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/"+data.stationgroup+"/national_NIVOMETRO/4/", onSuccess, onError);
            })
        }
    }

    // function getNationalRadiometer() {
    //     var past = "";
    //     if (!menuService.isRealTime())past="past/";
    //
    //     //se è presente una data prendo layer sentinel nel passato
    //     settingsService.settings(function (data) {
    //         apiService.getSentinel("layer/"+past+data.stationgroup+"/national/13/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
    //     })
    //
    // }
    //
    // function getNationalBarometer() {
    //     var past = "";
    //     if (!menuService.isRealTime())past="past/"
    //
    //     //se è presente una data prendo layer sentinel nel passato
    //     settingsService.settings(function (data) {
    //         apiService.getSentinel("layer/"+past+data.stationgroup+"/national/12/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
    //     })
    //
    // }
    //
    // function getNationalIgrometer() {
    //     var past = "";
    //     if (!menuService.isRealTime())past="past/"
    //
    //     //se è presente una data prendo layer sentinel nel passato
    //     settingsService.settings(function (data) {
    //         apiService.getSentinel("layer/"+past+data.stationgroup+"/national/9/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
    //     })

    // }

    //window.app.url.sentinelURL+layer/sensor/-2097483367/2/national_PLUVIOMETRO/
    function getNationalPluviometerSensorData(sensorid,dbid,onSuccess, onError) {
        apiService.getSentinel("layer/sensor/"+sensorid+"/"+dbid+"/national/"  , onSuccess, onError);
    }

    function getSensorInfo(sensorid,dbid ,onSuccess, onError){
        apiService.getSentinel("layer/info/"+sensorid+"/"+dbid+"/"  , onSuccess, onError);
    }



    function getSensorGeneric(sensorClass, threshold,onSuccess, onError) {
        var past = "";
        if (!menuService.isRealTime())past="past/";

        if(sensorClass)sensorClass=sensorClass.toString();
        threshold = (threshold)?threshold=threshold.toString():"national/";

        //se è presente una data prendo layer sentinel nel passato
        settingsService.settings(function (data) {
            apiService.getSentinel("layer/"+past+data.stationgroup+"/"+threshold+sensorClass+"/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
        })
    }

    function getNationalDams(onSuccess, onError){

        if (!menuService.isRealTime()) {
            //se è presente una data prendo layer sentinel nel passato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/past/277/national_IDROMETRO/3/"+menuService.getDateToUTCSecond()+"/", onSuccess, onError);
            })
        }else{
            //se non è presente data prendo layer aggiornato
            settingsService.settings(function (data) {
                apiService.getSentinel("layer/277/national_IDROMETRO/3/", onSuccess, onError);
            })
        }
    }


    return{
        getSensorGeneric:getSensorGeneric,
        getNationalTermo :getNationalTermo,
        getNationalPluvio :getNationalPluvio,
        getNationalIdro :getNationalIdro,
        getNationalIgro :getNationalIgro,
        getNationalWindDirection :getNationalWindDirection,
        getNationalWindSpeed :getNationalWindSpeed,
        getNationalNivometer:getNationalNivometer,
        getFloodWave:getFloodWave,
        getNationalPluviometerSensorData:getNationalPluviometerSensorData,
        getSensorInfo : getSensorInfo,
        getPluvioLsppPunctual : getPluvioLsppPunctual,
        getNationalDams: getNationalDams
    }
}]);
