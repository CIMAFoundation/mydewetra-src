/**
 * Created by Dario Rubado on 13/10/15.
 */

dewetraApp.service('audioService', ['$http', '$window', '$interval','mapService','sentinelService', function($http, $window, $interval, mapService, sentinelService) {

    var audio = new Audio('apps/dewetra2/sound/alarm3.wav');
    var audio3 = new Audio('apps/dewetra2/sound/BikeHorn.mp3');
    var audio1 = new Audio('apps/dewetra2/sound/sounds-998-awareness.mp3');
    var audio2 = new Audio('apps/dewetra2/sound/sounds-999-hold-your-horses.mp3');

    var audioEnabled = false;
    var audioCalled = true;
    var audioPromise = [];

    var lastAudioTriggerer={};

    var action={
        zoomTo:function () {
            sentinelService.getSensorInfo(lastAudioTriggerer.properties.sensorid, lastAudioTriggerer.properties.dbid,
                function(sensorInfo){
                    console.log(sensorInfo);
                    mapService.setView(new L.LatLng(sensorInfo.station.lat, sensorInfo.station.lon),11);
                },
                function(err){
                    console.log("error Sentinel service")
                });
        }
    }

    return {


        setAudio : function (status) {
            audioEnabled = status
        },

        getAudioStatus : function () {
            return audioEnabled;
        },

        isPlaying: function () {
            if (audioPromise.length > 0) return true;
            else return false


        },

        playAudio: function (obj) {
            // return;
            if (action[obj.type])lastAudioTriggerer = obj;


            if(audioEnabled){
                var promise = null;
                promise = $interval(function () {
                    audio.play();
                    console.log("playSound")
                }, 2000);
                audioPromise.push(promise)
            }
        },
        stopAudio: function () {

            //se è stata assegnata una azione la eseguo
            if(action[lastAudioTriggerer.type])action[lastAudioTriggerer.type]()

            if(audioPromise){
                audioPromise.forEach(function (promise) {
                    $interval.cancel(promise);
                })
            }
            audioPromise =[]

        }

    }


}]);
