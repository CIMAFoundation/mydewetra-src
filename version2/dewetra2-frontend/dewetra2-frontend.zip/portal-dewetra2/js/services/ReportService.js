/**
 * Created by Dario Rubado on 30/09/16.
 */


dewetraApp.service('reportService', ['$http', 'apiService','settingsService','mapService','printService','$window', function($http, apiService, settingsService, mapService, printService, $window) {

    var reportUUID = null;
    var aUuidMap = []
    
    var downloadUrl= null;

    return{
        downloadUrl:function () {
          return downloadUrl;  
        },
        getReportUUID:function () {
          return reportUUID;
        },
        /**
         * ask for new report and return a data.report == uuid (id of report)
         * @param okCallback
         */
        initializeReport:function (okCallback) {
            downloadUrl =null;
            //il server mi ritorna il report id
            apiService.getPrintServer('report/',function (data) {
                reportUUID = data.report;
                aUuidMap = [];
                okCallback(data.report);
            },function (err) {
                console.log(err)
            })
        },
        
        getReportImagePreviewUrl:function () {

            if(aUuidMap.length == 0){
                alert("no images sended to report")
                return
            }

            var aUrl = [];

            aUuidMap.forEach(function (uuid) {
                aUrl.push(apiService.buildPrintApiURL(uuid));
            })

            return aUrl;
        },

        /**
         * send config object to service and save it to the server return a data.printId == uuid (id of map)
         * @param callback
         */
        sendToReport:function (callback) {
            var params = printService.getMapsSettings(mapService, mapService.oLayerList.aDraggable, mapService.oLayerList.aUndraggable);

            apiService.postPrintServer('savemap/', params,function (data) {
                if(data.printId != null){
                    aUuidMap.push(data.printId);
                    callback(data.printId)
                }
            })
        },

        /**
         * call api for pre build report image post to report/uuid(report) with array of uuid(map)
         * return an array of absolute url of image
         * @param callback
         */
        buildReport:function (callback) {

            apiService.postPrintServer('report/'+reportUUID, aUuidMap,function (data) {
                // data = {
                //      png:[absolute_url_image1,absolute_url_image2]
                // }
                if (callback)callback(data)
            },function (err) {
                console.log(err)
            })
        },

        /**
         *call to docx || pptx '/' reportUUID '/'
         * return a absolute url with token and auth url
         * @param type 'pptx' || 'docx'
         * @param obj pptx or docx config file plus obj.uuid (array of map uuid)
         * @param callback
         */
        getReportFile:function (type, obj,callback) {

            // passo array uuid mappe 
            obj.uuid = aUuidMap;

            apiService.postPrintServer(type+'/'+reportUUID+"/", obj,function (data) {
                // console.log("report/"+data.url)
                downloadUrl = data.url;
                if (callback)callback(downloadUrl)

            },function (err) {
                console.log(err)
            })
        }
    }
}]);