/**
 * Created by Dario Rubado on 08/07/15.
 */
dewetraApp.service('tagService', ['$http', '$rootScope','apiService','$window',  function ($http, $rootScope, apiService, $window) {

    var aTags = [];
    var folderView = false;

    var aTaksIdRank = [];
    apiService.get('statistics/tagsrank/',function(data){
        aTaksIdRank = data;
    });
    function addTags(aoTags){
        var tags = [];
        aoTags.forEach(function (tag) {
            var n;
            n = findIndexByKeyValue(aTags, 'name', tag.name);
            if(n == null){
                tags.push(tag)
            }
        });
        tags.forEach(function (item) {
            aTags.push(item)
        })
    }

    function onSuccessStatistics(data){

        console.log("Tags Statistics Succesfull updated ")
    }
    function onErrorStatistics(data){
        console.log(data)
    }

    function toggleTag(tag){
        var n;
        if(tag.name){
            n = findIndexByKeyValue(aTags, 'name', tag.name);
            if(n!= null){
                aTags[n].active = tag.active
            }
        }
    }

    function checkTags(newTags){

        //controllo se sono tag gia chiamati
        if (newTags.length>0) {

            var p = null;
            p = findIndexByKeyValue(aTags, 'id', newTags[0].id);
            //se sono gia stati chiamati il anche il primo elemento sara gia in aTags

            if (p != null){
                //note
                // se p != null è sicuro aTags.length >0
                if(aTags.length >0) {
                    newTags.forEach(function (tag) {
                        var n;
                        n = findIndexByKeyValue(aTags, 'name', tag.name);
                        if(n!= null){
                            tag.active = aTags[n].active
                        }
                    });
                    return newTags;
                }
            }else{//se p è null devo aggiungere scegliere quali tag attivare secondo il rank e aggiungre i tag a aTags
                for(var tagRank in aTaksIdRank){
                    var n = findIndexByKeyValue(newTags, 'id', aTaksIdRank[tagRank]);
                    if (n!= null ) break;
                    //allaprima occorrenza esco dal ciclo
                }
                if (n == null){//se non sono mai stati cliccati non hanno ancora statistiche possibile baco
                    this.addTags(newTags);
                    return newTags
                }else{
                    //setto tutti non attivi
                    newTags.forEach(function(tag){
                        tag.active = false
                    });
                    //attivo solo il primo trovato
                    newTags[n].active = true
                }
            }
            //aggiungo ad aTags
            this.addTags(newTags)
        }
        return newTags
    }

    function updateTagStatistics(aoTags){
        var aTagsId = [];
        aoTags.forEach(function (oTags) {
            if(oTags.active == true) aTagsId.push(oTags.id)
        });
        try{
            if (aTagsId.length > 0) apiService.post('statistics/tagsupdate/',aTagsId,onSuccessStatistics, onErrorStatistics)
        }catch (a){
            console.log(a);
        }
    }

    function tagsRank(okCallBack){
        apiService.get('statistics/tagsrank/',okCallBack, onErrorStatistics)
    }

    var viewType= 'tag';//could be tag,folder,tree

    return{
        addTags : addTags,
        toggleTag : toggleTag,
        checkTags : checkTags,
        updateTagStatistics : updateTagStatistics,
        tagsRank : tagsRank,



        getView:function(){
            return viewType;
        },

        setView:function(v){
            viewType = v;
        },


    }

}]);

