dewetraApp.service('mapService', ['$rootScope', '$http', '_','$window','iconService','dialogService',function ($rootScope, $http, _,$window, iconService, dialogService) {

    /**
     * base layers
     */
    var osmBasic = L.tileLayer('//{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution:
            '&copy; <a href="//openstreetmap.org">OpenStreetMap</a> contributors',
        maxZoom: 24
    });
    var osmMapquest = L.tileLayer('//otile{s}.mqcdn.com/tiles/1.0.0/osm/{z}/{x}/{y}.png', {
        subdomains: "12",
        attribution:
            '&copy; <a href="//openstreetmap.org">OpenStreetMap</a> contributors. Tiles courtesy of <a href="//www.mapquest.com/" target="_blank">MapQuest</a> <img src="https://developer.mapquest.com/content/osm/mq_logo.png">',
        maxZoom: 24
    });
    var osmHumanitarian = L.tileLayer('//{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', {
        attribution:
            '&copy; <a href="//openstreetmap.org">OpenStreetMap</a> contributors. Tiles courtesy of <a href="//hot.openstreetmap.org/" target="_blank">Humanitarian OpenStreetMap Team</a>',
        maxZoom: 24
    });
    var ocmCycle = L.tileLayer('//{s}.tile.opencyclemap.org/cycle/{z}/{x}/{y}.png', {
        attribution:
            '&copy; <a href="//openstreetmap.org">OpenStreetMap</a> contributors. Tiles courtesy of <a href="//www.thunderforest.com/" target="_blank">Andy Allan</a>',
        maxZoom: 24
    });
    var ocmTransport = L.tileLayer('//{s}.tile2.opencyclemap.org/transport/{z}/{x}/{y}.png', {
        attribution:
            '&copy; <a href="//openstreetmap.org">OpenStreetMap</a> contributors. Tiles courtesy of <a href="//www.thunderforest.com/" target="_blank">Andy Allan</a>',
        maxZoom: 24
    });

    var italyBoundary = L.tileLayer.wms('//geodata.cimafoundation.org/geoserver/wms', {
        layers: "CIMA:mondo_no_polo_sud",
        attribution: '&copy; <a href="//www.cimafoundation.org">cimafoundation</a>Cima Foundation<a href="//www.cimafoundation.org" target="_blank">Cima Foundation</a>',
        maxZoom: 24
    });

    var markerGeoSearch = [];

    var googleHybrid = L.gridLayer.googleMutant({type:'hybrid'});
    var googleMap = L.gridLayer.googleMutant({type:'roadmap'});
    var googleTerrain = L.gridLayer.googleMutant({type:'terrain'});
    var googleSatelite= L.gridLayer.googleMutant({type:'satellite'});
    // var googleMap = new L.Google('ROADMAP');
    // var googleTerrain = new L.Google('TERRAIN');
    // var googleSatelite = new L.Google('SATELLITE');



    var dewetraMap = null;
    var initialBounds = null;

    var LatLngCallback = null;

    var oActiveBaseLayer = googleHybrid;

    // var _thisService = this.oLayerList;


    function initMap(bounds, basemap){

        if (dewetraMap) return

        initialBounds = bounds;

        /**
         * the map
         */

        const baseMapDict = {
            'Google Satellite':googleSatelite,
            'OSM - Standard': osmBasic
        };

        if(basemap != null){
            if(Object.keys(baseMapDict).indexOf(basemap)> -1){
                oActiveBaseLayer = baseMapDict[basemap];
            }else {
                oActiveBaseLayer = osmBasic;
            }
        }



        dewetraMap = L.map('map', {
            zoomControl: false,
            layers: [oActiveBaseLayer],
            preferCanvas:true,
            // maxZoom: 22
        });

        L.control.zoom({
            position:'bottomright'
        }).addTo(dewetraMap);

        /**
         * scale control
         */
        L.control.scale({
            position: "bottomright",
            imperial: false
        }).addTo(dewetraMap);

        /**
         * layers control
         */
        layersControl.addTo(dewetraMap);

        /**
         * measure control
         */
        measureControl.addTo(dewetraMap);
        /**
         * layers group
         */
        oLayersGroup.addTo(dewetraMap);

        // oLayersGroup.on('add',function () {
        //     //_thisService.aLayerList.orderByDrag()
        //     console.log("add layer")
        // });

        /**
         * hard coded layers group
         */
        oHardCodedLayersGroup.addTo(dewetraMap);

        oEditableLayersGroup.addTo(dewetraMap);

        oToolLayersGroup.addTo(dewetraMap);

        /**
         * fitBounds
         */

        dewetraMap.fitBounds(initialBounds)

        //add event on base change
        dewetraMap.on('baselayerchange', function(e){
            // console.log(e);
            try {
                e.layer.bringToBack();
            }catch (err){
                console.log(err);
            }

            oActiveBaseLayer = e;
        })

        //add latlngCallback
        dewetraMap.on('mousemove',function (e) {
            if (LatLngCallback)LatLngCallback(e);
        })


    }

    function fitMap(){
        if (initialBounds)dewetraMap.fitBounds(initialBounds)
    }




    /**
     * layers control
     */
    var layersControl = L.control.layers(
        {
            "OSM - Standard": osmBasic,
            //"OSM - Cycle Map": ocmCycle,
            //"OSM - Transport Map": ocmTransport,
            // "MapQuest Open": osmMapquest,
            "OSM - Humanitarian": osmHumanitarian,
            "Google Hybrid": googleHybrid,
            "Google Map": googleMap,
            "Google Satellite": googleSatelite,
            "Google Terrain": googleTerrain,
            "Coastline": italyBoundary
        },
        {},
        {
            'position' : 'bottomright'
        }
    );


    var test = {
        someNewUnit: {
            factor: 0.001, // Required. Factor to apply when converting to this unit. Length in meters or area in sq meters will be multiplied by this factor.
                display: 'My New Unit', // Required. How to display in results, like.. "300 Meters (0.3 My New Unit)".
                decimals: 2 // Number of decimals to round results when using this unit. `0` is the default value if not specified.
        },
        myOtherNewUnit: {
            factor: 1234,
                display: 'My Other Unit',
                decimals: 0
        }
    }

    var measureOptions = {
        localization: window.app.config.measureLang,
        position: 'topright',
        primaryLengthUnit: 'kilometers',
        secondaryLengthUnit:'miles',
        primaryAreaUnit : 'kilometers',
        secondaryAreaUnit: 'hectares',
        decPoint: ',',
        thousandsSep: '.'
    };

    var measureControl = L.control.measure(measureOptions);


    //group for our static layer
    var oLayersGroup = new L.LayerGroup();


    //group for layer manually added

    var oHardCodedLayersGroup = new L.LayerGroup();

    //layerGroupt for add tool layers
    var oToolLayersGroup = new L.LayerGroup();

    //layergroup for draw

    var oEditableLayersGroup = new L.FeatureGroup();

    //Draw control

    var oDrawControl = {};

    //array for set opacity
    var hiddenLayers = {};

    //boundingBox of LAYER
    var aBBoxLayer =[];

    var layerObjects = {};

    var lastInfoClick = null;

    function setLayerManager(leafletLayer, manager) {
        var lid = leafletLayer._leaflet_id;
        layerObjects[lid] = manager
    }

    function getLayerManager(layer) {
        if (layer._leaflet_id in layerObjects) return layerObjects[layer._leaflet_id];
        return null
    }

    function removeLayerManager(layer){
        if (layer._leaflet_id in layerObjects) delete layerObjects[layer._leaflet_id];
        return null
    }

    /**
     * fro bring the draggable option also if is idden
     * @param layer
     */
    function getLayerManagerAlsoInHidden(layer){

    }

    /**
     * get draggable property
     * @param layer
     * @returns {boolean}
     */
    function getDraggableProperty(layer){
        return layerObjects[layer._leaflet_id].draggable();
        //if (layer._leaflet_id in layerObjects) return layerObjects[layer._leaflet_id].draggable();
        //if (layer._leaflet_id in hiddenLayers) return hiddenLayers[layer._leaflet_id].draggable();
    }

    function changeMapLayerId(oldLayer, newLayer){
        var lid = newLayer._leaflet_id;
        layerObjects[lid] = layerObjects[oldLayer._leaflet_id];
        delete layerObjects[oldLayer._leaflet_id];
    }


    //info tool management

    var infoMarker = new L.marker(new L.LatLng(0, 0), {
        icon: L.icon({
            iconUrl: 'apps/dewetra2/img/target.svg',
            iconSize: [64, 64],
            iconAnchor: [32, 32],
            opacity: 0
        })
    });

    var onLayerInfoReceived = null;

    var startMarker = null;
    var endMarker = null;
    var polyLine = null;
    var measureLayer = L.featureGroup();
    var lastMeasure = null;


    var oToolsDrawControl = null;


    function addMeasureMarker(evt){

        //initialize my measure icon
        var myIcon = L.icon({
            //iconUrl: 'apps/dewetra2/bower_components/leaflet/dist/images/marker-icon.png'
            iconUrl: 'apps/dewetra2/img/marker_gps.svg',
            iconSize: [64, 64],
            iconAnchor: [32, 0],
            opacity: 0
        });

        if(polyLine == null)  polyLine = L.polyline([],{
            color: 'red',
            weight: 3,
            opacity: 0.5,
            smoothFactor: 1

        }).addTo(measureLayer);

        if(startMarker == null ){

            startMarker = L.marker(evt.latlng, {icon:myIcon}).bindPopup('start marker').addTo(measureLayer);



            dewetraMap.on('mousemove', function(e) {
                polyLine.setLatLngs([startMarker._latlng, e.latlng])
            });


        }else if(startMarker!= null && endMarker == null){

            endMarker = L.marker(evt.latlng, {icon:myIcon}).bindPopup('end marker').addTo(measureLayer);

            dewetraMap.off('mousemove');

            var polyPoints = [startMarker._latlng, endMarker._latlng];

            polyLine.setLatLngs(polyPoints);

            var from = startMarker.getLatLng();
            alert((from.distanceTo(evt.latlng)).toFixed(0) + 'm');
            lastMeasure = from.distanceTo(evt.latlng).toFixed(0) + 'm'
        }else {
            measureLayer.removeLayer(endMarker);
            measureLayer.removeLayer(startMarker);
            measureLayer.removeLayer(polyLine);
            polyLine = null;
            endMarker = null;
            startMarker = null

        }




        //L.circleMarker()
    }

    function clickWithInfo(evt) {

        $rootScope.dewetra2LayersInfo = null;

        lastInfoClick = evt;

        if (!onLayerInfoReceived) return;

        infoMarker.setLatLng(new L.LatLng(evt.latlng.lat, evt.latlng.lng));
        infoMarker.setOpacity(1);

        var point = dewetraMap.latLngToContainerPoint(evt.latlng, dewetraMap.getZoom());
        var size = dewetraMap.getSize();

        const element = document.querySelector('.ng-scope');
        const _thisService = angular.element(element).injector().get('mapService');

        dewetraMap.eachLayer(function (layer) {
            if (layer.wmsParams) {

                var infoFormat = 'application/json'
                if (layer.wmsParams.infoFormat) {
                    //console.log('INFO: take format from manager')
                    infoFormat = layer.wmsParams.infoFormat
                }



                var bbox = layer.wmsParams.version === '1.3.0' ?
                    [dewetraMap.getBounds().getSouth(), dewetraMap.getBounds().getWest(), dewetraMap.getBounds().getNorth(), dewetraMap.getBounds().getEast()].join(',') :
                    dewetraMap.getBounds().toBBoxString()

                //bbox = [ dewetraMap.getBounds().getWest(),dewetraMap.getBounds().getSouth(), dewetraMap.getBounds().getEast(), dewetraMap.getBounds().getNorth()].join(',')

                // BBOX=xmin,ymin,xmax,ymax NON-FLIPPED
                //
                // BBOX=ymin,xmin,ymax,xmax FLIPPED



                //-0.0439453125,33.33970700424029,24.63134765625,50.44351305245807
                let params = {
                    request: 'GetFeatureInfo',
                    service: 'WMS',
                    // srs: 'EPSG:4326',
                    // crs: 'EPSG:4326',
                    styles: layer.wmsParams.styles,
                    version: layer.wmsParams.version,
                    format: layer.wmsParams.format,
                    bbox: bbox,
                    height: size.y,
                    width: size.x,
                    // buffer:100,
                    layers: layer.wmsParams.layers,
                    query_layers: layer.wmsParams.layers,
                    info_format: infoFormat,
                    feature_count: 10
                };
                params[params.version === '1.3.0' ? 'i' : 'x'] = Math.round(point.x);
                params[params.version === '1.3.0' ? 'j' : 'y'] = Math.round(point.y);
                params[params.version === '1.3.0' ? 'crs' : 'srs'] = 'EPSG:4326';

                if (layer.wmsParams.time) {
                    params['time'] = layer.wmsParams.time
                }

                const manager = _thisService.oLayerList.getManagerByMapLayer(layer);

                if (manager && manager.getFeatureInfoQueryParams) {
                    params = manager.getFeatureInfoQueryParams();
                }

                const url = layer._url + L.Util.getParamString(params, layer._url, true);

                console.log("GetFeatureInfoUrl");
                console.log(url);

                $http.get(url).then(function (data, status, headers, config) {
                    onLayerInfoReceived(layer, data.data, url);
                },function(){})
            }
        });
    }

    var setInfo = function (active, callback) {

        if(callback)onLayerInfoReceived = callback;

        if (active) {
            dewetraMap.on('click', clickWithInfo);
            dewetraMap.addLayer(infoMarker)

        } else {
            dewetraMap.off('click', clickWithInfo);
            infoMarker.setLatLng(new L.LatLng(0,0));
            infoMarker.setOpacity(0);
            dewetraMap.removeLayer(infoMarker)
        }

        var elem;
        if (document.getElementById && (elem=document.getElementById('map')) ) {
            if (elem.style) {
                elem.style.cursor=active ? 'crosshair' : null;
            }
        }

        if(angular.isUndefined(callback)) return infoMarker;
    };


    var setPunctualSerie = function (active, callback) {

        // if(callback)onLayerInfoReceived = callback;

        if (active) {
            dewetraMap.on('click', function (evt) {

            });
            dewetraMap.addLayer(infoMarker)

        } else {
            dewetraMap.off('click', clickWithInfo);
            infoMarker.setLatLng(new L.LatLng(0,0));
            infoMarker.setOpacity(0);
            dewetraMap.removeLayer(infoMarker)
        }

        var elem;
        if (document.getElementById && (elem=document.getElementById('map')) ) {
            if (elem.style) {
                elem.style.cursor=active ? 'crosshair' : null;
            }
        }

        if(angular.isUndefined(callback)) return infoMarker;
    };


    //info tool management END


    //line drawing management

    function setLineDrawer(active, callback) {
        if (active){
            dewetraMap.on('click', addMeasureMarker);
            dewetraMap.addLayer(measureLayer);
        } else{
            dewetraMap.off('click', addMeasureMarker);
            measureLayer.clearLayers();
            try {
                dewetraMap.off('mousemove');
            }catch (err){console.log(err)}
            dewetraMap.removeLayer(measureLayer);
            endMarker,startMarker = null;

        }

        if(callback) callback(lastMeasure);
    }

    //line drawing management END

    //polygon drawing management

    function setPolygonDrawer(active, callback) {

    }

    //polygon drawing management END

    function addPattern() {
        var diagonalHatch_yellow = new L.PatternRect({fill:"yellow", height:"10", width:"10", y:"0", x:"0"})
        diagonalHatch_yellow.addTo(dewetraMap);
    }

    return {

        dewetraMap : dewetraMap,

        getMap: function(){
            return dewetraMap;
        },

        initMap : initMap,

        fitMap : fitMap,

        layersControl: layersControl,

        layersGroup:oLayersGroup,

        setLatLngCallback:function(c){
            LatLngCallback = c;
        },

        setZoomEndCallback: function () {
          var _this = this;
            dewetraMap.on('zoomend', function() {
                _this.oLayerList.zoomEndCallback()
            });

        },


        getBaseLayer:function(baseLayer){
            if (baseLayer) {
                oActiveBaseLayer = baseLayer
            }else return oActiveBaseLayer

        },

        setBaseLayer:function(baseLayer){
            if (baseLayer) {
                dewetraMap.removeLayer(oActiveBaseLayer)
                oActiveBaseLayer = baseLayer
                dewetraMap.addLayer(baseLayer)
            }

        },

        getLayers : function(){
            var aLayerList = oLayersGroup.getLayers();
            //console.log(aLayerList)
            if (aLayerList.length > 1){
                for(var i = aLayerList.length; i--; ){
                    this.bringToFront(aLayerList[i]);
                }
                return aLayerList;
                }else{
                return aLayerList;
            }
        },

        /**
         * get layer ordered by zIndex
         * @returns {*}
         */
        getLayersByZIndex : function(){

            var aLayerList = oLayersGroup.getLayers();

            if (aLayerList.length > 1){
                for(var i = aLayerList.length; i--; ){
                    this.bringToFront(aLayerList[i]);
                }
                function compare(a, b) {

                    if (a.options.zIndex < b.options.zIndex)
                        return 1;
                    if (a.options.zIndex > b.options.zIndex)
                        return -1;
                    return 0;
                }

                aLayerList.sort(compare);

                return aLayerList;

            }else{
                return aLayerList;
            }
        },

        /**
         * return draggable layer
         * @returns {*}
         */
        getDraggableLayer: function () {
            var aLayerList = oLayersGroup.getLayers();
            var oGroupedLayerList = _.groupBy(aLayerList,function(layer){
                var manager = getLayerManager(layer);
                if(manager && manager.draggable()) {
                    return "draggable"
                }else return "undraggable"
            });
            return oGroupedLayerList.draggable
        },
        /**
         * return undraggable layer
         * @returns {*}
         */
        getUnDraggableLayer: function () {
            var aLayerList = oLayersGroup.getLayers();
            var oGroupedLayerList = _.groupBy(aLayerList,function(layer){
                var manager = getLayerManager(layer);
                if(manager && manager.draggable()) {
                    return "draggable"
                }else return "undraggable"
            });
            return oGroupedLayerList.undraggable;
        },

        /**
         * return layer
         * @returns {*}
         */
        getLayerTest: function () {
            var aLayerList = oLayersGroup.getLayers();

            //Li ordino anche se è statp aggiunto non solo in caso di drag
            //this.orderByDrag(aLayerList)

            var oGroupedLayerList = _.groupBy(aLayerList,function(layer){
                var manager = getLayerManager(layer);
                if(manager && manager.draggable()) {
                    return "draggable"
                }else return "undraggable"
            });
            return oGroupedLayerList;
        },

        orderByDrag: function (array, onFinish) {
            //passo gli array modificati dal drag nello scope e li ordino

            for(var i = array.length-1; i--; i>=0){
                array[i].bringToFront();
            }
            if (onFinish) onFinish();
            //return array;

        },

        addStaticLayer: function(item){
            var url = item['server'].url;

            if(!(angular.isDefined(item.format))){
                item.format = 'image/png';
            }
            if(!(angular.isDefined(item.transparent))){
                item.transparent = true;
            }

            var l = L.tileLayer.wms(url , {
                layers: item.dataid,
                format: item.format,
                transparent: item.transparent,
                attribution: item.attribution
            }).addTo(oLayersGroup).bringToFront();

            setLayerManager(l, item)
        },

        addDynamicLayer: function(item,id) {
            var url = id.serverurl+'/wms';

            if(!(angular.isDefined(item.format))){
                item.format = 'image/png';
            }
            if(!(angular.isDefined(item.transparent))){
                item.transparent = true;
            }

            var l = L.tileLayer.wms(url , {
                layers: id.layerid,
                format: item.format,
                transparent: item.transparent,
                attribution: item.attribution
            }).addTo(oLayersGroup).bringToFront();

            setLayerManager(l, item)
        },

        addWmsLayer: function(serverUrl, layerId, env) {

            var l = L.tileLayer.wms(serverUrl , {
                    layers: layerId,
                    format: 'image/png',
                    transparent: true,
                    maxZoom: 24,
                    env :(env)?env:''
                }).addTo(oLayersGroup).bringToFront();
            return l
        },

        addWmsLayerWithParameters: function(serverUrl, params) {

            const l = L.tileLayer.wms(serverUrl, params);

            l.addTo(oLayersGroup).bringToFront();
            return l

        },

        addHardCodedWmsLayer: function(serverUrl, layerId, env,styles) {

            var l = L.tileLayer.wms(serverUrl , {
                layers: layerId,
                format: 'image/png',
                transparent: true,
                maxZoom: 24,
                styles:(styles)?styles:"",
                env :(env)?env:''
            }).addTo(oHardCodedLayersGroup).bringToFront();
            return l
        },

        removeHardCodedWmsLayer: function(layer) {
            oHardCodedLayersGroup.removeLayer(layer);
        },

        addToolLayerWmsLayer: function(serverUrl, layerId, env,styles) {

            var l = L.tileLayer.wms(serverUrl , {
                layers: layerId,
                format: 'image/png',
                transparent: true,
                maxZoom: 24,
                styles:(styles)?styles:"",
                env :(env)?env:''
            }).addTo(oToolLayersGroup).bringToFront();
            return l
        },

        removeToolLayerWmsLayer: function() {
            if(oToolsDrawControl){
                oToolsDrawControl.removeFrom(dewetraMap);
                oToolsDrawControl = null;
            }

        },

        addToolsDrawControl:function(oDrawOptions){
            oToolsDrawControl = new L.Control.Draw(oDrawOptions);
            oToolsDrawControl.addTo(dewetraMap);
        },

        addSingleTileWmsLayer: function(serverUrl, params) {

            var l = L.singleTile(serverUrl, params);
            l.addTo(oLayersGroup).bringToFront();

            return l

        },

        /**
         * add a vector layer from geojson data
         * @param data geojson
         * @param name name of the layer
         * @param styleFunction function(geojson) called to style a feature
         * @param onFeatureClicked function(event) called when a feature is cliccked (event.target is the object)
         * @param onFeatureMouseOver function(event) called when the mouse entered inside a feature (event.target is the object)
         * @param onFeatureMouseOut function(event) called when the mouse exited from a feature (event.target is the object)
         * @param filterFunction
         * @returns {*}
         */
        addGeoJsonLayer : function(data, name, options, onFeatureClicked, onFeatureMouseOver, onFeatureMouseOut, filterFunction) {

            var layerOn = {};
            if (onFeatureClicked) layerOn.click = onFeatureClicked;
            console.log($window.navigator.userAgent);
            if ($window.navigator.userAgent.indexOf("Chrome") > -1){
                if (onFeatureMouseOver) layerOn.mouseover = onFeatureMouseOver;
                if (onFeatureMouseOut) layerOn.mouseout = onFeatureMouseOut;
            }

            if (!options) options = {};

            options.onEachFeature = function(feature, layer) {
                layer.on(layerOn)
            };

            if (options.featureStyleManager) options.style = options.featureStyleManager;

            if (filterFunction) options.filter = filterFunction
            try{
                var l = L.geoJson(data, options);
            }
            catch (err){
                console.log(err)
            }
            var l = L.geoJson(data, options);
            l.options.name = name;
            oLayersGroup.addLayer(l);

            return l

        },

        addGenericLayer : function(l, name) {

            if (!l.options) {
                l.options = {}
            }
            l.options.name = name;
            oLayersGroup.addLayer(l);

        },

        addGeoJsonLayerCluster : function(data, name, options, onFeatureClicked, onFeatureMouseOver, onFeatureMouseOut, filterFunction, clusterMouseOver) {

            var layerOn = {};
            if (onFeatureClicked) layerOn.click = onFeatureClicked;

            console.log($window.navigator.userAgent);
            if ($window.navigator.userAgent.indexOf("Chrome") > -1){
                if (onFeatureMouseOver) layerOn.mouseover = onFeatureMouseOver;
                if (onFeatureMouseOut) layerOn.mouseout = onFeatureMouseOut;
            }

            if (!options) options = {};

            options.onEachFeature = function(feature, layer) {
                layer.on(layerOn)
            };

            if (options.featureStyleManager) options.style = options.featureStyleManager;

            if (filterFunction) options.filter = filterFunction

            var l = L.geoJson(data, options);

            l.options.name = name;

            var markers = L.markerClusterGroup({
                disableClusteringAtZoom:8
            });

            if(clusterMouseOver)markers.on('clustermouseover', clusterMouseOver);

            markers.addLayer(l)
            // dewetraMap.addLayer(markers)

            oLayersGroup.addLayer(markers);

            return markers

        },

        /**
         * add a vector layer from geojson data
         * @param data mapLayerObj
         * @param data geojson
         * @param name name of the layer
         * @param styleFunction function(geojson) called to style a feature
         * @param onFeatureClicked function(event) called when a feature is cliccked (event.target is the object)
         * @param onFeatureMouseOver function(event) called when the mouse entered inside a feature (event.target is the object)
         * @param onFeatureMouseOut function(event) called when the mouse exited from a feature (event.target is the object)
         * @param filterFunction
         * @returns {*}
         */
        addGeoJsonData : function(layerObj ,data, name,  onFeatureClicked, onFeatureMouseOver, onFeatureMouseOut, filterFunction) {


            var layerOn = {};
            if (onFeatureClicked) layerOn.click = onFeatureClicked;
            if (onFeatureMouseOver) layerOn.mouseover = onFeatureMouseOver;
            if (onFeatureMouseOut) layerOn.mouseout = onFeatureMouseOut;



            if (filterFunction) {
                options.filter = filterFunction
            }

            layerObj.addData(data);
            //if (options) layerObj.setStyle(options())
            layerObj.options.name = name;

            return layerObj

        },

        removeLayer:function(layer){
            oLayersGroup.removeLayer(layer);
            if (layer._leaflet_id in layerObjects) delete layerObjects[layer._leaflet_id];
            if (layer._leaflet_id in hiddenLayers) delete hiddenLayers[layer._leaflet_id];
        },

        hideLayerToggle:function(oManager, callBack){


            if (oManager && oManager.setVisible) {
                oManager.setVisible(!oManager.isVisible())
            }else{
                if(oManager.mapLayer().options.opacity != 0){
                    oManager.mapLayer().setOpacity(0);
                }else oManager.mapLayer().setOpacity(100);
            }

            // if (oManager && oManager.setVisible) {
            //     oManager.setVisible(true, callBack)
            // } else {
            //     oManager.mapLayer().setOpacity(100);
            // }
            //
            // delete hiddenLayers[oManager.mapLayer()._leaflet_id]
            //
            //
            //
            // if (oManager && oManager.setVisible) {
            //     oManager.setVisible(false, callBack)
            // } else {
            //     oManager.mapLayer().setOpacity(0);
            // }

        },



        zoomToLayer : function(layer){
            var manager = this.oLayerList.getManagerByMapLayer(layer);
            if (manager) {
                var bounds = L.latLngBounds(L.latLng(manager.layerObj().lats,manager.layerObj().lonw),
                    L.latLng(manager.layerObj().latn,manager.layerObj().lone));
                dewetraMap.fitBounds(bounds);
            }
        },
        bringToFront : function (layer) {
            layer.bringToFront();


        },
        layerUp : function (layer) {
            var ArrayOfLayer = oLayersGroup.getLayers();
            var index  = ArrayOfLayer.indexOf(layer);
            if (index > 0){
                ArrayOfLayer.move(index, index-1);
            }

        },

        getBounds : function () {
            var oBBox = dewetraMap.getBounds();
            return oBBox
        },

        moveLayer: function(sourceIndex, destinationIndex){

            var ArrayOfLayer = oLayersGroup.getLayers();

            ArrayOfLayer.move(sourceIndex, destinationIndex);

            return ArrayOfLayer

        },
        addMarker: function(oPoint,oIconOption, info){
            if(oIconOption){
                markerGeoSearch.push( L.marker(oPoint, {icon: oIconOption}).addTo(dewetraMap));
                var id = markerGeoSearch.length - 1;
                markerGeoSearch[id].on('click', function(){
                    dewetraMap.removeLayer(markerGeoSearch[id]);
                })
            }else{ markerGeoSearch.push(L.marker(oPoint).addTo(dewetraMap));
                var id = markerGeoSearch.length - 1;
                markerGeoSearch[id].on('click', function(){
                    dewetraMap.removeLayer(markerGeoSearch[id]);
                })
            }
            if(info){
                markerGeoSearch[id].bindPopup(info);
                markerGeoSearch[id].on('mouseover', function(e){
                    this.openPopup();
                });
                markerGeoSearch[id].on('mouseout', function(e){
                    this.closePopup();
                })
            }

        },

        setView: function(latlng, zoom){

            dewetraMap.setView(latlng);


            try {
                dewetraMap.setZoom(zoom);
            }catch (err){
                console.log(err)
            }
        },

        getTriangleIcon : function(size, fillColor, borderColor, opacity) {

            var icon = new L.Icon.Canvas({iconSize: new L.Point(size, size)});
            icon.draw = function(ctx, w, h) {
                ctx.globalAlpha = opacity;
                ctx.beginPath();
                ctx.moveTo(w/2,h);
                ctx.lineTo(w,0);
                ctx.lineTo(0,0);
                ctx.fillStyle= fillColor;
                ctx.fill();

                ctx.beginPath();
                ctx.moveTo(w/2,h);
                ctx.lineTo(w,0);
                ctx.lineTo(0,0);
                ctx.strokeStyle= (borderColor? borderColor : "black");
                ctx.stroke();
            };

            return icon;

        },

        getWindIcon : function(size, fillColor, borderColor, opacity) {

            var icon = new L.Icon.Canvas({iconSize: new L.Point(size, size)});
            icon.draw = function(ctx, w, h) {
                ctx.globalAlpha = opacity;
                ctx.beginPath();
                ctx.moveTo(w/2,h);
                ctx.lineTo(w,0);
                ctx.lineTo(0,0);
                ctx.fillStyle= fillColor;
                ctx.fill();

                ctx.beginPath();
                ctx.moveTo(w/2,h);
                ctx.lineTo(w,0);
                ctx.lineTo(0,0);
                ctx.strokeStyle= (borderColor? borderColor : "black");
                ctx.stroke();
            };

            return icon;

        },

        doHTTPRequest : function(req, onSuccess, onError) {

            var auth = window.btoa("efasJRC:JJdd1919");
            $http.defaults.headers.common['Authorization'] = 'Basic ' + auth;
                //h = {"Authorization": "Basic " + auth};

            $http.get(req.url)
                .then(function(data, status, headers, config) {
                    if (onSuccess) onSuccess(data);
                },
                function(data, status, headers, config) {
                    if (onError) onError();
                });

        },


        oLayerList : {
            init: function(){

                var thisObject = this;

                // dewetraMap.on('addlayer',function () {
                //    thisObject.orderByDrag()
                // });

                this.aDraggable.forEach(function (oLayerList) {
                    thisObject.removeLayer(oLayerList)
                });
                this.aUndraggable.forEach(function (oLayerList) {
                    thisObject.removeLayer(oLayerList)
                })
            },

            zoomEndCallback:function () {
                this.aUndraggable.forEach(function (oLayerManager) {
                    if(oLayerManager.hasOwnProperty("resizeOnZoomEnd")){

                        oLayerManager.resizeOnZoomEnd(dewetraMap.getZoom());
                    }
                })
                console.log("ZOOM FINISHED: "+ dewetraMap.getZoom())
            },

            getManagerByMapLayer:function(oMapLayer){

                var iIndexoMapLayer = _.findIndex(this.aDraggable, function(oLayerManager){
                    return oLayerManager.mapLayer()._leaflet_id == oMapLayer._leaflet_id;
                });
                if (iIndexoMapLayer> -1 ){
                    return this.aDraggable[iIndexoMapLayer]
                }else{
                    var iIndexoMapLayer = _.findIndex(this.aUndraggable, function(oLayerManager){
                        return oLayerManager.mapLayer()._leaflet_id == oMapLayer._leaflet_id;
                    });
                    return this.aUndraggable[iIndexoMapLayer]
                }
            },

            getIndexofManager:function(oManager){
                var iIndexoMapLayer = _.findIndex(this.aDraggable, function(oLayerManager){
                    return oLayerManager.mapLayer()._leaflet_id == oManager.mapLayer()._leaflet_id;
                });
                if (iIndexoMapLayer> -1 ){
                    return iIndexoMapLayer
                }else{
                    iIndexoMapLayer = _.findIndex(this.aUndraggable, function(oLayerManager){
                        return oLayerManager.mapLayer()._leaflet_id == oManager.mapLayer()._leaflet_id;
                    });
                    return iIndexoMapLayer
                }
            },

            addLayer : function(oManager){

                if (oManager.draggable()) {
                    this.addDraggable(oManager)
                }else this.addUndraggable(oManager)
            },

            removeLayer : function(oManager){

                oManager.remove(oManager.mapLayer());

                if(oManager.removeListener) oManager.removeListener();

                if(oManager.draggable()){
                    this.aDraggable = _.filter(this.aDraggable,function(layer){
                        return layer.mapLayer()._leaflet_id != oManager.mapLayer()._leaflet_id
                    })
                }else {
                    this.aUndraggable = _.filter(this.aUndraggable,function(layer){
                        return layer.mapLayer()._leaflet_id != oManager.mapLayer()._leaflet_id
                    })
                }

            },

            updateLayer: function(oManager, index){

                if(index == null){
                    index = this.getIndexofManager(oManager);
                }


                if(oManager.draggable()){
                    this.updateDraggableLayer(oManager, index)
                }else{
                    this.updateUndraggableLayer(oManager, index)
                }
            },

            updateDraggableLayer : function(oManager, index){
                //mapService.setlayerManager(oManager.mapLayer(), oManager);
                this.aDraggable[index] = oManager
                this.orderByDrag();
            },

            updateUndraggableLayer : function(oManager, index){
                //mapService.setlayerManager(oManager.mapLayer(), oManager);
                this.aUndraggable[index] = oManager
            },
            orderByDrag : function(){
                //passo gli array modificati dal drag nello scope e li ordino
                for(var i = this.aDraggable.length-1; i--; i>=0){
                    this.aDraggable[i].mapLayer().bringToFront();
                }
            },
            addDraggable : function (oLayer) {
                this.aDraggable.push(oLayer);
                if (this.aDraggable.length >1){
                    this.aDraggable.move(this.aDraggable.length-1, 0)
                }
            },
            addUndraggable: function (oLayer) {
                this.aUndraggable.push(oLayer);
                if (this.aUndraggable.length >1){
                    this.aUndraggable.move(this.aUndraggable.length-1, 0)
                }
            },
            //geLayer:function(oMapLayer){
            //
            //},
            setLayer:function(){},
            aDraggable : [],
            aUndraggable :[],
        },

        getLayerManager: getLayerManager,
        setlayerManager: setLayerManager,
        getDraggableProperty: getDraggableProperty,
        changeMapLayerId: changeMapLayerId,
        setInfo: setInfo,
        setPunctualSerie: setPunctualSerie,
        setLineDrawer: setLineDrawer,
        setPolygonDrawer: setPolygonDrawer,
        renewLayerInfo:function () {
            clickWithInfo(lastInfoClick)
            // setInfo(true,onLayerInfoReceived);
        },
        exportMapSettings:function(){
            var oLayerList = this.oLayerList;
            var aLayersWms = [];
            var aLayersJson = [];
            var _this = this;

            if(oLayerList.aDraggable.length >0 ){
                oLayerList.aDraggable.forEach(function(layer){
                    console.log(layer);
                    var obj ={
                        layerId : layer.mapLayer().wmsParams.layers,
                        server: layer.mapLayer()._url,
                        transparent : layer.mapLayer().wmsParams.transparent,
                        attribution : layer.mapLayer().options.attribution,
                        format : layer.mapLayer().options.format
                    };
                    aLayersWms.push(obj);
                })
            }

            if(oLayerList.aUndraggable.length >0 ){
                oLayerList.aUndraggable.forEach(function(layer){
                    console.log(layer);
                    var obj ={
                        layerId : layer.mapLayer().wmsParams.layers,
                        server: layer.mapLayer()._url,
                        transparent : layer.mapLayer().wmsParams.transparent,
                        attribution : layer.mapLayer().options.attribution,
                        format : layer.mapLayer().options.format
                    };
                    aLayersWms.push(obj);
                })
            }

            function checkBaseLayerType() {
                if(_this.getBaseLayer()._type) return _this.getBaseLayer()._type;
                else if(_this.getBaseLayer().name) return _this.getBaseLayer().name;
            }

            var backgroundType = checkBaseLayerType();

            var mapObj = {
                center: dewetraMap.getCenter(),
                zoom: dewetraMap.getZoom(),
                bounds:dewetraMap.getBounds(),
                size : dewetraMap.getSize(),
                backgroundType: backgroundType,
                wmsLayers: aLayersWms,
                jsonLayers: aLayersJson
            };
            return mapObj;
        },

        addDrawControl:function () {

            var MyCustomMarker = L.Icon.extend({
                options: {
                    shadowUrl: null,
                    iconAnchor: new L.Point(12, 12),
                    iconSize: new L.Point(24, 24),
                    iconUrl: 'apps/dewetra2/img/target.png'
                }
            });

            var options = {
                position: 'topright',
                draw: {
                    polyline: {
                        shapeOptions: {
                            color: '#f357a1',
                            weight: 10
                        }
                    },
                    polygon: {
                        allowIntersection: false, // Restricts shapes to simple polygons
                        drawError: {
                            color: '#e1e100', // Color the shape will turn when intersects
                            message: '<strong>Oh snap!<strong> you can\'t draw that!' // Message that will show when intersect
                        },
                        shapeOptions: {
                            color: '#bada55'
                        }
                    },
                    circle: false, // Turns off this drawing tool
                    rectangle: {
                        shapeOptions: {
                            clickable: true
                        }
                    },
                    marker: {
                        icon: new MyCustomMarker()
                    }
                },
                edit: {
                    featureGroup: oEditableLayersGroup, //REQUIRED!!
                    remove: false
                }
            };

            oDrawControl = new L.Control.Draw(options);

            var dialog =  dialogService;

            dewetraMap.on(L.Draw.Event.CREATED, function (e) {
                console.log(e)
                oEditableLayersGroup.addLayer(e.layer);

                e.layer.on("click", function (e) {
                    dialog.open(e.target._leaflet_id, 'drawDialog.html', {legend:{},layer:e.target});
                })

                // e.layer.bindPopup("SELECT color insert text").openPopup()
                dialog.open(e.layer._leaflet_id, 'drawDialog.html', {legend:{},layer:e.layer});

            });

            dewetraMap.addControl(oDrawControl);



            return oEditableLayersGroup;
        },
        removeDrawControl:function () {
            oDrawControl.removeFrom(dewetraMap);
        },
        getInfoMarker:function () {
            return infoMarker;
        },

        buildMapState:function (mapState) {
            dewetraMap.fitBounds(mapState.bounds)
        }

    }
}]);


/**
 * canvas icon
 */
L.Icon.Canvas = L.Icon.extend({
    options: {
        iconSize: new L.Point(20, 20), // Have to be supplied
        className: 'leaflet-canvas-icon'
    },

    createIcon: function () {
        var e = document.createElement('canvas');
        this._setIconStyles(e, 'icon');
        var s = this.options.iconSize;
        e.width = s.x;
        e.height = s.y;
        this.draw(e.getContext('2d'), s.x, s.y);
        return e;
    },

    createShadow: function () {
        return null;
    },

    draw: function(canvas, width, height) {
        console.log('eccomi')
    }
});

