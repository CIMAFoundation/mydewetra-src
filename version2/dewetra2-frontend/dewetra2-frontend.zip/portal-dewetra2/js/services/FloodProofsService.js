/**
 * Created by Dario Rubado on 24/11/15.
 */

dewetraApp.service('floodproofsService', ['apiService', 'menuService', function(apiService, menuService) {

    return{
        layer: function(server, serieId, callback) {
            var tNow = Math.ceil(menuService.getDateToUTCSecond());
            if (menuService.isRealTime()){
                var tNow = Math.ceil(menuService.getDateToUTCSecond());
            }


            console.log("Data: "+menuService.getDateToFormatted());
            apiService.get('floodproof/layer/'+server+'/' + serieId + '/' + tNow + '/', callback)
        },

        compatibles: function(server, serieId, callback) {
            apiService.get('floodproof/compatibles/'+server+'/' + serieId + '/', callback)
        }

    }
}]);