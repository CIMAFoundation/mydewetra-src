/**
 * Created by doy on 19/06/15.
 */



dewetraApp.service('apiService', ['$http', '$window', function($http, $window) {

    var absUrl = $window.location.href;


    var dewapiServerURL = "";
    var sentinelServerURL = "";
    var printerServerURL = "";
    var dataLogServerURL = "";
    var printerServerV2URL = "";

    dewapiServerURL = window.app.url.dewapiURL;
    sentinelServerURL = window.app.url.sentinelURL;

    dataLogServerURL = (window.app.url.datalogServerUrl)?(window.app.url.datalogServerUrl):null;

    printerServerURL = window.app.url.printerServerURL;
    printerServerV2URL = (window.app.url.printerServerV2URL)?window.app.url.printerServerV2URL:null;


    function buildDewApiURL(url) {
        var ret = dewapiServerURL + url;
        return ret
    }

    function buildSentinelApiURL(url) {
        var ret = sentinelServerURL + url;
        return ret
    }

    function buildPrintApiURL(url) {
        var ret = printerServerURL + url;
        return ret
    }

    function buildDataLogUrl(url) {
        var ret = dataLogServerURL + url;
        return ret
    }

    function buildPrintApiV2URL(url) {
        var ret = printerServerV2URL + url;
        return ret
    }

    function get(url, onSuccess, onError) {
        console.log(buildDewApiURL(url));

        $http.get(buildDewApiURL(url), ).then(
            function(data, status, headers, config) {
                onSuccess(data.data);
            },
            function(data, status, headers, config) {
                if (onError) onError(data, status, headers, config);
            }
        )

    }




    function getPrintServer(url, onSuccess, onError) {

        $http.get(buildPrintApiURL(url))
            .then(function(data, status, headers, config) {
                if (onSuccess) onSuccess(data.data);
            },function(data, status, headers, config) {
                //acError.errorOnServerRequest(data);
                if (onError) onError(data.data);
            });

    }
    function getPrintServerV2(url, onSuccess, onError) {

        $http.get(buildPrintApiV2URL(url))
            .then(function(data, status, headers, config) {
                if (onSuccess) onSuccess(data.data);
            },function(data, status, headers, config) {
                //acError.errorOnServerRequest(data);
                if (onError) onError(data.data);
            });

    }

    function postPrintServer(url, obj, onSuccess, onError) {

        $http.post(buildPrintApiURL(url), obj)
            .then(function(data, status, headers, config) {
                if (onSuccess) onSuccess(data.data);
            },function(data, status, headers, config) {
                //acError.errorOnServerRequest(data);
                if (onError) onError(data.data);
            });
    }

    function postDataLogServer(url, obj, onSuccess, onError) {

        $http.post(buildDataLogUrl(url+'?acroweb_token=' + encodeURIComponent($window.localStorage.token)), obj)
            .then(function(data, status, headers, config) {
                if (onSuccess) onSuccess(data.data);
            },function(data, status, headers, config) {
                //acError.errorOnServerRequest(data);
                if (onError) onError(data.data);
            });
    }

    function postPrintServerV2(url, obj, onSuccess, onError) {

        $http.post(buildPrintApiV2URL(url), obj)
            .then(function(data, status, headers, config) {
                if (onSuccess) onSuccess(data.data);
            },function(data, status, headers, config) {
                //acError.errorOnServerRequest(data);
                if (onError) onError(data.data);
            });
    }

    function buildBulletinHydroUrl(url) {
        return window.app.url.bulletinHydroUrl+url;
    }

    function buildBulletinFireUrl(url) {
        return window.app.url.bulletinFireUrl+url;
    }

    function getSentinel(url, onSuccess, onError) {

        console.log(buildSentinelApiURL(url))


        $http.get(buildSentinelApiURL(url))
            .then(function(data, status, headers, config) {
                if (onSuccess) onSuccess(data.data);
            },function(data, status, headers, config) {
                //acError.errorOnServerRequest(data);
                if (onError) onError(data.data);
            });
    }

    function postSentinel(url,obj ,onSuccess, onError) {

        console.log(buildSentinelApiURL(url))

        $http.post(buildSentinelApiURL(url), obj)
            .then(function(data, status, headers, config) {
                if (onSuccess) onSuccess(data.data);
            },function(data, status, headers, config) {
                //acError.errorOnServerRequest(data);
                if (onError) onError(data.data);
            });
    }

    function deleteSentinel(url, onSuccess, onError) {

        console.log(buildSentinelApiURL(url))


        $http.delete(buildSentinelApiURL(url))
            .then(function(data, status, headers, config) {
                if (onSuccess) onSuccess(data.data);
            },function(data, status, headers, config) {
                //acError.errorOnServerRequest(data);
                if (onError) onError(data.data);
            });
    }

    function patchSentinel(url,obj ,onSuccess, onError) {

        console.log(buildSentinelApiURL(url))

        $http.patch(buildSentinelApiURL(url), obj)
            .then(function(data, status, headers, config) {
                if (onSuccess) onSuccess(data.data);
            },function(data, status, headers, config) {
                //acError.errorOnServerRequest(data);
                if (onError) onError(data.data);
            });
    }


    function getExt(url, onSuccess, onError) {
        //debugger
        $http.get(url)
            .then(function(data, status, headers, config) {
                if (onSuccess) onSuccess(data.data);
            },function(data, status, headers, config) {
                //acError.errorOnServerRequest(data);
                if (onError) onError(data.data);
            });
    }

    function getPropagator(url){
        return $http
            .get(url)
            .then(function(res){
                return res.data;
            }, function(err){
                return err
            });
    }

    function postExt(url,obj, onSuccess, onError) {

        $http({
            method: 'POST',
            url: url,
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj)
                    str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                return str.join("&");
            },
            data: obj
        }).then(function (data) {
            if(onSuccess) onSuccess(data)
        },function(data){
            if(onError)onError(data)
        });

    }

    function postExtJson(url,obj, onSuccess, onError) {

        $http({
            method: 'POST',
            url: url,
            headers: {'Content-Type': 'application/json'},
            // transformRequest: function(obj) {
            //     var str = [];
            //     for(var p in obj)
            //         str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            //     return str.join("&");
            // },
            data: obj
        }).then(function (data) {
            if(onSuccess) onSuccess(data.data)
        },function(data){
            if(onError)onError(data)
        });

    }



    //$http({
    //    method: 'POST',
    //    url: url,
    //    headers: {'Content-Type': 'application/json;charset=UTF-8'},
    //    data: obj
    //}).then(function (data) {
    //    if (onSuccess) onSuccess(data)
    //},function(data){
    //    if (onError) onError(data)
    //});

    function getFloodis(url,token, onSuccess, onError) {
        $http({
            method: 'GET',
            url: url,
            headers: {
                'Authorization' :"bearer "+token,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
        }).then(function (data) {
            if(onSuccess) onSuccess(data)
        },function(data){
            if(onError)onError(data)
        });
    }

    function postFloodis(url,obj, onSuccess, onError) {
        $http({
            method: 'POST',
            url: url,
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj)
                    str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                return str.join("&");
            },
            data: {username: obj.username, password: obj.password, grant_type: obj.grant_type}
        }).then(function (data) {
            if(onSuccess) onSuccess(data)
        },function(data){
            if(onError)onError(data)
        });
    }

    function post(url, obj, onSuccess, onError) {
        console.log(buildDewApiURL(url));
        //console.log(obj);
        $http.post(buildDewApiURL(url), obj)
            .then(function (data, status, headers, config) {
                if (onSuccess) onSuccess(data.data, data.status);
            },function (data, status, headers, config) {
                //acError.errorOnServerRequest(data)
                if (onError){
                    onError(data.data, data.status)
                }else{
                    alert("Error: DATA UNAVAILABLE");
                }
            });
    }

    function postWithHeaders(url, obj,headers, onSuccess, onError) {
        console.log(buildDewApiURL(url));
        //console.log(obj)

        $http.post(buildDewApiURL(url), obj,headers,)
            .then(function (data, status, headers, config) {
                if (onSuccess) onSuccess(data.data, status);
            },function (data, status, headers, config) {
                //acError.errorOnServerRequest(data)
                if (onError){
                    onError(data.data, status)
                }else{
                    alert("Error: DATA UNAVAILABLE");
                }
            });
    }

    function proxyMe( obj, onSuccess, onError) {

        var proxy_url = dewapiServerURL+'utils/proxy/';

        $http.post(proxy_url+ '?acroweb_token=' + encodeURIComponent($window.localStorage.token), obj)
            .then(function (data, status, headers, config) {
                console.log(data.data)
                if (onSuccess) onSuccess(data.data, status);

            },function (data, status, headers, config) {
                //acError.errorOnServerRequest(data)
                if (onError){
                    onError(data.data, status)
                }else{
                    alert("Error: DATA UNAVAILABLE");
                }
            });
    }

    function proxyGenericUrl(url) {
        return  dewapiServerURL+'utils/genericproxy/?url='+url;
    }

    function proxyGeneric( url, onSuccess, onError) {

        var proxy_url = dewapiServerURL+'utils/genericproxy/';

        $http.get(proxy_url+'?url='+url)
            .then(function (data, status) {
                if (onSuccess) onSuccess(data.data, status);
            },function (data, status) {
                onError(data.data, status)
            })

    }



    return {
        get: get,
        post: post,
        postWithHeaders:postWithHeaders,
        getExt : getExt,
        getPropagator: getPropagator,
        postExt : postExt,
        postExtJson:postExtJson,
        proxyMe:proxyMe,
        proxyGeneric:proxyGeneric,
        proxyGenericUrl:proxyGenericUrl,
        getFloodis: getFloodis,
        postFloodis: postFloodis,
        getSentinel : getSentinel,
        postSentinel : postSentinel,
        deleteSentinel : deleteSentinel,
        patchSentinel : patchSentinel,
        getPrintServer: getPrintServer,
        postPrintServer: postPrintServer,
        buildPrintApiV2URL,
        buildDataLogUrl,
        postDataLogServer,
        getPrintServerV2,
        postPrintServerV2,
        buildPrintApiURL:buildPrintApiURL,
        buildBulletinHydroUrl:buildBulletinHydroUrl,
        buildBulletinFireUrl:buildBulletinFireUrl,
        exportCsv:function (data) {
            var keys = _.keys(data[0]);

            // convert to csv string
            var csv = keys.join(",");
            _(data).each(function(row) {
                csv += "\n";
                csv += _(keys).map(function(k) {
                    return row[k];
                }).join(",");
            });

            // trick browser into downloading file
            var uriContent = "data:application/octet-stream," + encodeURIComponent(csv);
            var myWindow = window.open(uriContent, "Nutrient CSV");
            myWindow.focus();
        }
    }


}]);
