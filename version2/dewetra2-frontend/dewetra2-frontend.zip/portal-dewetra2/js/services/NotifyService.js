/**
 * Created by Dario Rubado on 27/05/15.
 */

dewetraApp.service('notifyService', ['acEvent', function (acEvent) {


    function setAcquisitionListener(callback) {
        acEvent.register('acrotec', 'acquisition', callback)
    }


    return {
        setAcquisitionListener: setAcquisitionListener
    }

}]);

