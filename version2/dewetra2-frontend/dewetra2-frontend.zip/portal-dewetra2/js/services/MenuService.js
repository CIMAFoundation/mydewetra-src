/**
 * Created by Dario Rubado on 15/05/15.
 */

dewetraApp.service('menuService', ['$http','$timeout', '$rootScope', 'layerService','$interval','$window','apiService','toolsService','$translate', function ($http,$timeout, $rootScope, layerService, $interval, $window, apiService,toolsService,$translate) {

    // NB: Date in millisec!!!!!!
    var dateTo;
    var dateFrom;
    var msGap = 86400000; //24 hours

    var isDateFromUpdated = true;

    var followingServerDate = true;

    //DATE start
    function updateDates(now) {


        if (dateFrom) {
            msGap = dateTo - dateFrom;
        }

        dateTo = moment.utc(now).valueOf();

        if(isDateFromUpdated){
            msGap = 86400000;//original 24 h gap
            dateFrom = dateTo - msGap;
            isDateFromUpdated = false;
        }


        if (dateChangedCallback) dateChangedCallback();

    }

    function updateTime(callback) {

        if (followingServerDate) {

            $timeout(function () {
                var serverTime = $rootScope.getServerTime();
                if (serverTime) {
                    console.log("updated time", serverTime)
                    updateDates(serverTime);
                    if (callback)callback();


                } else {
                    console.log('cannot obtain server time... trying again');
                    updateTime()
                }
            }, 500)
        }

    }

    function updateLater() {
        $timeout(function() {
            updateTime();
            updateLater();
        }, 5*60000); //five minutes
    }
    //inizializzo ora server
    updateTime();

    //inizializzo aggiornamento ora server ogni 5 minuti
    updateLater();
    //DATE END

    var dateChangedCallback = null;
    var updateLayerCallback = null;

    function checkAuth(){
        if ($rootScope.acSession){
            if(!$rootScope.acSession.authenticated){
                $window.location.replace("apps/dewetra2/index.html");
                //$window.location.replace("apps/dewetra2/index_mydewetra.html");
            }
        }
    }

    var PromiseCheckAuth = $interval(checkAuth, 300000);

    var debug = true;

    return {

        debug:debug,

        setOnDateChanged: function (callback) {
            dateChangedCallback = callback
        },
        setLayerUpdateOnDateChanged: function(callback){
            updateLayerCallback = callback
        },
        setDateTo : function(d){
            //test
            var tzOffset = d.getTimezoneOffset();

            var p = new Date(d.getTime() - tzOffset * 60000);

            //check se minore di dateFrom sposto datefrom di 24 h indietro
            if (moment(p).isBefore(new Date(dateFrom))){
                console.log("isBefore")
                //this.setDateFrom(moment.utc(new Date(d.getTime())).subtract(1,'days').toDate())

                alert($translate.instant('DATETO_MUSTBE_GT_DATEFROM'));
                //alert("dateTo must be greater than dateFrom")
            }else{
                updateDates(p);

                followingServerDate = false;

                console.log("stop following server time")
                if (updateLayerCallback) updateLayerCallback(); //spostata dalla routine update data senno si azionava anche negli aggiornamenti
            }


        },
        setNow: function () {
            console.log("following server time")
            followingServerDate = true;
            isDateFromUpdated = true
            updateTime(updateLayerCallback)
            // if (updateLayerCallback) updateLayerCallback(); //spostata dalla routine update data senno si azionava anche negli aggiornamenti
        },

        getDateToFormatted:function() {

            return moment(dateTo).utc().format('DD/MM/YYYY HH:mm');
        },
        setDateFrom : function(d){

            //test
            var tzOffset = d.getTimezoneOffset();
            var p = new Date(d.getTime() - tzOffset * 60000);
            //test

            if(p.getTime() > dateTo){

                alert($translate.instant('DATEFROM_MUSTBE_PAST'));

                //alert("From date must be in the past.");
            }else{

                if (dateTo - p.getTime() > 10 * 86400000) {
                    // alert("Period too long. Max allowed: 10 days");



                    alert($translate.instant("TEN_DAYS_DELAY_RISK"));

                    dateFrom = p.getTime();
                    if (dateChangedCallback) dateChangedCallback()

                } else {
                    dateFrom = p.getTime();
                    if (dateChangedCallback) dateChangedCallback()
                }
            }
        },
        getDateTo : function () {
            var dt = (dateTo) ? new Date(dateTo) : new Date();
            return dt;
        },
        getDateFrom : function () {
            var dt = (dateFrom) ? new Date(dateFrom) : new Date(new Date().getTime() - msGap);
            return dt;
        },
        getDateToUTCSecond : function(){
            var nDateNowSecond = dateTo/1000;
            return nDateNowSecond
        },
        getDateFromUTCSecond : function(){
            var nDateFromSecond = dateFrom/1000;
            return nDateFromSecond
        },
        getUTCDateTo: function(){
            var now = new Date(dateTo);
            var dt_utc = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(),  now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
            return dt_utc
        },
        getUTCDateFrom: function(){
            var now = new Date(dateFrom);
            var dt_utc = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(),  now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
            return dt_utc
        },

        getUtcServerDate : function () {
            return($rootScope.getServerTime());
        },

        getUtcServerDateInMillisecond : function () {
            return($rootScope.getServerTime().getTime());
        },

        getUtcServerDateInSecond : function () {
            return($rootScope.getServerTime().getTime()/1000);
        },

        isRealTime : function () {
            return followingServerDate;
        },

        // timeMode : function(d){
        //
        //     //this.setDateFrom(new Date(2016, 10, 20, 10));
        //     //this.setDateTo(new Date(2016, 11, 1, 10));
        //
        //     var tzOffset = d.getTimezoneOffset();
        //
        //     var p = new Date(d.getTime() - tzOffset * 60000);
        //
        //     updateDates(p);
        //
        //     followingServerDate = false;
        //
        //     if (updateLayerCallback) updateLayerCallback();
        // },
        timeModeNew : function(from, to){

            var service = this;

            $timeout(function () {
                service.setDateFrom(from);
            },1000)

            $timeout(function () {
                service.setDateTo(to);
            },4000)

            if (updateLayerCallback) updateLayerCallback();
        },

        getPrimaryMenuLinks: function () {
            var aoPrimaryMenuLinks = [
                {
                    classIcon: "osservazioni2",
                    title: "OBSERVATION",
                    tag: "observation",
                    selected: false,
                    enabled: true,
                    description: "OBSERVATION-DESCRIPTION",
                    loadLayers: layerService.getObservationLayers
                },
                {
                    classIcon: "previsioni3",
                    title: "FORECAST",
                    tag: "forecast",
                    selected: false,
                    enabled: true,
                    description: "FORECAST-DESCRIPTION",
                    loadLayers: layerService.getForecastLayers
                },
                {
                    classIcon: "static",
                    title: "STATIC",
                    tag: "static",
                    selected: false,
                    enabled: true,
                    description: "STATIC-LAYER",
                    loadLayers: layerService.getStaticLayers
                },
                {
                    classIcon: "event",
                    title: "EVENTS",
                    tag: "events",
                    selected: false,
                    enabled: true,
                    description: "STATIC-LAYER",
                    loadLayers: layerService.getEventLayers
                },
                {
                    classIcon: "strumenti",
                    title: "TOOLS",
                    tag: "tools",
                    selected: false,
                    enabled: true,
                    description: "TOOLS-DESCRIPTION",
                    loadLayers: null
                }

            ];
            return aoPrimaryMenuLinks;
        },

        markerWarningOptions: {
            radius : 4,
            weight : 1,
            color : "#000",
            opacity : 1,
            fillOpacity: 0.8
        },

        markerFloodOptions: {
            radius : 4,
            weight : 1,
            color : "#000",
            opacity : 1,
            fillOpacity: 0.8
        },

        oChartSize: {
            m_iSensorChartHeight : function(){
                var sensorChooser = $("#sensorChooser").height();
                var sensorTitle  = $("#sensorTitle").height();
                var header  = $("#header").height();
                var footerApp  = $("#footer_app").height();
                var footerPortal  = $("#footer").height();

                var margin = 100;

                return $(window).height() -  footerPortal- sensorChooser -sensorTitle - margin;
            },
            m_iFloodProofsChartHeight : function(){
                var sensorChooser = $("#sensorChooser").height();
                // var sensorChooser = 159;
                var sensorTitle  = $("#sensorTitle").height();
                var header  = $("#header").height();
                var footerApp  = $("#footer_app").height();
                var footerPortal  = $("#footer").height();

                var margin = 100;

                return $(window).height() -  footerPortal- sensorChooser -sensorTitle - margin;
            },
            m_iFloodProofsChartComponentHeight : function(){
                var sensorChooser = $("#sensorChooser").height();
                // var sensorChooser = 159;
                var sensorTitle  = $("#sensorTitle").height();
                var header  = $("#header").height();
                var footerApp  = $("#footer_app").height();
                var footerPortal  = $("#footer").height();

                var margin = ($(window).height()/100)*15;


                return $(window).height() -  footerPortal- sensorChooser -sensorTitle - margin;
            }
        },

        oLocalStorage:{
            m_oLocalStorageDateValidator:function (sNameFromStore) {
                var now = moment(new Date()).milliseconds();

                try{
                    var lastUpdateDate = JSON.parse(localStorage.getItem("lastUpdate-"+sNameFromStore));
                    if (lastUpdateDate){
                        // 17280000 == 2 giorni
                        if ((parseInt(now) - parseInt(lastUpdateDate)) > 17280000){
                            console.log("older then 2 days");
                            return false;
                        }else {
                            console.log("newest then 2 days");
                            return true;
                        }
                    }else{
                        localStorage.setItem("lastUpdate-"+sNameFromStore, now);
                        return false;
                    }
                }catch (err){
                    console.log("error m_oLocalStorageDateValidator")
                    console.log(err);
                    //localStorage.setItem("lastUpdate-"+sNameFromStore, now);
                    //return false;
                }



            },
            m_oLocalStorageGet : function(sNameFromStore){
                var _this = this;
                try {
                    var localData = JSON.parse(localStorage.getItem(sNameFromStore));
                    if(localData != null && _this.m_oLocalStorageDateValidator(sNameFromStore)){
                        return localData;
                    }else return null
                }catch (err){
                    console.log(err);
                    return null
                }
            },
            m_oLocalStorageSet : function(oToStore, sNameToStore){

                var now = moment(new Date()).milliseconds();



                var dataToStore = JSON.stringify(oToStore);
                try {
                    localStorage.setItem("lastUpdate-"+sNameToStore, now);
                    localStorage.setItem(sNameToStore, dataToStore);
                }catch (err){
                    console.log(err);
                }
            },
        },

        oServiceStorage:{
            m_oWarningRegionFeature : null,
            m_oWarningRegionFeatureLoader : function (localStorage,onFinish) {
                var urlFeature = window.app.url.sentinelURL+"aggr/layer/regions_it/";
                var oLocalStorage = localStorage;
                var sStringInLocalStorage  = "LocalStorage_Warning_Regioni";

                if (this.m_oWarningRegionFeature != null){
                    onFinish(this.m_oWarningRegionFeature)
                }
                // else if(oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage)!= null && oLocalStorage.m_oLocalStorageDateValidator(sStringInLocalStorage)){
                //     try{
                //         this.m_oWarningRegionFeature = oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage);
                //         onFinish(oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage))
                //     }catch(err){
                //         console.log(err)
                //     }
                //
                // }
                else{
                    apiService.getExt(urlFeature, function (data) {
                        try{
                            //oLocalStorage.m_oLocalStorageSet(data, sStringInLocalStorage)
                        }catch(err) {
                            console.log(err);
                        }

                        try{
                            this.m_oWarningRegionFeature = data
                        }catch(err) {
                            console.log(err);
                        }
                        onFinish(data)
                    })
                }

            },
            m_oWarningProvinceFeature : null,
            m_oWarningProvinceFeatureLoader : function (localStorage,onFinish) {
                var urlFeature = window.app.url.sentinelURL+"aggr/layer/districts_it/";
                var oLocalStorage = localStorage;
                var sStringInLocalStorage  = "LocalStorage_Warning_Province";

                if (this.m_oWarningProvinceFeature != null){
                    onFinish(this.m_oWarningProvinceFeature)
                }
                // else if(oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage)!= null){
                //     try{
                //         this.m_oWarningProvinceFeature = oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage);
                //         onFinish(oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage))
                //     }catch(err){
                //         console.log(err)
                //     }
                //
                // }
                else{
                    apiService.getExt(urlFeature, function (data) {
                        try{
                            //oLocalStorage.m_oLocalStorageSet(data, sStringInLocalStorage)
                        }catch(err) {
                            console.log(err);
                        }

                        try{
                            this.m_oWarningProvinceFeature = data
                        }catch(err) {
                            console.log(err);
                        }
                        onFinish(data)
                    })
                }
            },
            m_oWarningComuniFeature : null,
            m_oWarningComuniFeatureLoader : function (localStorage,onFinish) {
                var urlFeature = window.app.url.sentinelURL+"aggr/layer/municipalities_it/";
                var oLocalStorage = localStorage;
                var sStringInLocalStorage  = "LocalStorage_Warning_Comuni";

                if (this.m_oWarningComuniFeature != null){
                    onFinish(this.m_oWarningComuniFeature)
                }
                // else if(oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage)!= null){
                //     try{
                //         this.m_oWarningComuniFeature = oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage);
                //         onFinish(oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage))
                //     }catch(err){
                //         console.log(err)
                //     }
                //
                // }
                else{
                    apiService.getExt(urlFeature, function (data) {
                        try{
                            //oLocalStorage.m_oLocalStorageSet(data, sStringInLocalStorage)
                        }catch(err) {
                            console.log(err);
                        }

                        try{
                            this.m_oWarningComuniFeature = data
                        }catch(err) {
                            console.log(err);
                        }
                        onFinish(data)
                    })
                }
            },
            m_oWarningBaciniFeature : null,
            m_oWarningBaciniFeatureLoader : function (localStorage,onFinish) {
                var urlFeature = window.app.url.sentinelURL+"aggr/layer/catchments_it/";
                var oLocalStorage = localStorage;
                var sStringInLocalStorage  = "LocalStorage_Warning_Bacini";

                if (this.m_oWarningBaciniFeature != null){
                    onFinish(this.m_oWarningBaciniFeature)
                }
                // else if(oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage)!= null){
                //     try{
                //         this.m_oWarningBaciniFeature = oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage);
                //         onFinish(oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage))
                //     }catch(err){
                //         console.log(err)
                //     }
                //
                // }
                else{
                    apiService.getExt(urlFeature, function (data) {
                        try{
                            //oLocalStorage.m_oLocalStorageSet(data, sStringInLocalStorage)
                        }catch(err) {
                            console.log(err);
                        }

                        try{
                            this.m_oWarningBaciniFeature = data
                        }catch(err) {
                            console.log(err);
                        }
                        onFinish(data)
                    })
                }
            },
            m_oWarningWAFeature : null,
            m_oWarningWAFeatureLoader : function (localStorage,onFinish) {
                var urlFeature = window.app.url.sentinelURL+"aggr/layer/warningareas_it/";
                var oLocalStorage = localStorage;
                var sStringInLocalStorage  = "LocalStorage_Warning_Warning_Area";

                if (this.m_oWarningWAFeature != null){
                    onFinish(this.m_oWarningWAFeature)
                }
                // else if(oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage)!= null){
                //     try{
                //         this.m_oWarningWAFeature = oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage);
                //         onFinish(oLocalStorage.m_oLocalStorageGet(sStringInLocalStorage))
                //     }catch(err){
                //         console.log(err)
                //     }
                //
                // }
                else{
                    apiService.getExt(urlFeature, function (data) {
                        try{
                            // oLocalStorage.m_oLocalStorageSet(data, sStringInLocalStorage)
                        }catch(err) {
                            console.log(err);
                        }

                        try{
                            this.m_oWarningWAFeature = data
                        }catch(err) {
                            console.log(err);
                        }
                        onFinish(data)
                    })
                }
            },
            m_oWarningTopoietiFeature : null,
            m_oWarningTopoietiFeatureLoader : function (localStorage,onFinish) {
                //Aggiornare Url TOPOIETI
                var urlFeature = window.app.url.sentinelURL+"aggr/layer/municipalities_it/";

                if (this.m_oWarningWAFeature != null){
                    onFinish(this.m_oWarningTopoietiFeature)
                } else{
                    apiService.getExt(urlFeature, function (data) {
                        try{
                            this.m_oWarningTopoietiFeature = data
                        }catch(err) {
                            console.log(err);
                        }
                        onFinish(data)
                    })
                }
            }
        },

        oLayerList:{

        },

        getProvenienza:function(){
            GDACS:[""]
        },

        getToolsMenuLinks: function (callback) {

            var aoToolsMenuLinks = [
                {
                    classIcon: "addvmslayer",
                    title: "ADD_WMS_LAYER",
                    tag: "add",
                    beta:false,
                    selected: false,
                    description: "ADD_WMS_LAYER_DESCR",
                    manager: "addExternalWMSLayer"
                },
                // {
                //     classIcon: "floodWaveView2",
                //     title: "FLOOD_WAVE_VIEW_2",
                //     tag: "add",
                //     beta:true,
                //     selected: false,
                //     description: "FLOOD_WAVE_VIEW_2",
                //     manager: "floodWaveView2",
                //     loadLayers: "floodWaveView2"
                // },
                // {
                //     classIcon: "dams",
                //     title: "laminazione-chienti",
                //     tag: "laminazione-chienti",
                //     selected: false,
                //     beta:true,
                //     description: "laminazione",
                //     manager: "laminazione_chienti",
                //     config: "laminazione-chienti",
                //     toolId: "laminazione-chienti",
                //     dataId: "laminazione-chienti",
                //     loadLayers: null
                // }
                // {
                //     classIcon: "tools_export",
                //     title: "EXPORT",
                //     tag: "export",
                //     selected: false,
                //     description: "SENSOR-EXPORT",
                //     loadLayers: null
                // },
                // {
                //     classIcon: "tools_scenario",
                //     title: "SCENARI",
                //     tag: "scenari",
                //     selected: false,
                //     description: "SCENARI-DESCRIPTION",
                //     loadLayers: null
                // },
                // {
                //     classIcon: "tools_report",
                //     title: "REPORT",
                //     tag: "report",
                //     selected: false,
                //     description: "REPORT-DESCRIPTION",
                //     loadLayers: null
                // }
            ];

            toolsService.getTools(function (data) {

                data.objects.forEach(function (tool) {

                    var obj = {
                        classIcon: "tools_report",
                        title: tool.name,
                        //tag: "scenari",
                        selected: false,
                        beta:true,
                        description: tool.descr,
                        manager: tool.manager,
                        config: tool.config,
                        toolId: tool.id,
                        dataId: tool.dataid,
                        loadLayers: null
                    }

                    aoToolsMenuLinks.push(obj);
                });

                callback(aoToolsMenuLinks);

            },function (err) {
                alert(err)
            })




        }
    }

}]);

