/**
 * Created by Dario Rubado on 27/02/19.
 */
dewetraApp.service('exportDataService', ['apiService',function (apiService) {

    var exportData

    return {

    }

}]);
