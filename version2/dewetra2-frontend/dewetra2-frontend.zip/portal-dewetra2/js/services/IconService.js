
if (window['iconServiceFunction']){
    dewetraApp.service('iconService', ['$http','$interval','$timeout','$rootScope','$window','_' ,iconServiceFunction])
}else{
    console.log('icon service error')
}
