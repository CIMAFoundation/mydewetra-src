/**
 * Created by Dario Rubado on 26/11/15.
 */

//threshold info
dewetraApp.directive('thresholdInfoPluvio', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: 'apps/dewetra2/views/threshold_info_pluvio.html',
        controller : 'thresholdInfoPluvioController',
        scope: {
            thresholdObjectPluvio: '=?'
        }
    };
}]);
