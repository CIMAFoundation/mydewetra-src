/**
 * Created by Dario Rubado on 29/06/15.
 */


dewetraApp.directive('timeBar', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: window.app.config.timeBarDirective.templateUrl,
        controller : window.app.config.timeBarDirective.controller,
        scope: {
            onDateChange: '=?'
        }
    };
}]);
