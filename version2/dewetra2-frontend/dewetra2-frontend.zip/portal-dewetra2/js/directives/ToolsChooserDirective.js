/**
 * Created by Dario Rubado on 03/06/15.
 */

dewetraApp.directive('toolsChooser', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: window.app.config.toolsChooserDirective.templateUrl,
        controller : window.app.config.toolsChooserDirective.controller,
        scope: {
            onClose: '=?',
            menu: '=?',
            onToolsSelected: '=?'
        }
    };
}]);
