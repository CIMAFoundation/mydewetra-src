/**
 * Created by Dario Rubado on 29/06/15.
 */

dewetraApp.directive('liveIndicator', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: 'apps/dewetra2/views/live_indicator.html',
        controller : 'liveIndicatorController',
        scope: {
            notify: '=?'
        }
    };
}]);