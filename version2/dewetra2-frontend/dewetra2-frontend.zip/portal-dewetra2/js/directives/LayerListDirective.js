/**
 * Created by Dario Rubado on 24/06/15.
 */


dewetraApp.directive('layerList', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: 'apps/dewetra2/views/layer_list.html',
        controller : 'layerListController',
        scope: {
            aLayerList: '=?',
            layerNameForLayerList :'=?',
            onLayerDialogSelected: '=?',
            onLayerVisibilitySelected: '=?',
            onLayerRemoveSelected: '=?',
            onLayerZoomToSelected: '=?',
            onLayerShowPropertiesSelected: '=?',
            onLayerBringToFrontSelected: '=?',
            onLayerMouseOverOutTooltip:'=?'

        }
    };
}]);


//<!--tooltip="{{layerTooltipForLayerList(layer)}}"  tooltip-placement="right">{{layerNameForLayerList(layer)}}</a>-->