/**
 * Created by doy on 24/06/15.
 */




dewetraApp.directive('mapTools', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: window.app.config.mapToolsDirective.templateUrl,
        controller : 'mapToolsController',
        scope: {
            deselectTool: '=?'
        }
    };
}]);


dewetraApp.directive('layersInfo', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: 'apps/dewetra2/views/layers_info.html',
    };
}]);

(function(){

    dewetraApp.component('mapLatLng',{
        template:'<div ><span>Lat:{{$ctrl.lat.toFixed(2)}} - Lng:{{$ctrl.lon.toFixed(2)}}</span></div>',
        bindings: {
            layers: "=",
            onRemove: '&'
        },
        controller: ['mapService',function(mapService){
            var ctrl = this;
            mapService.setLatLngCallback(function (e) {
                ctrl.lat = e.latlng.lat;
                ctrl.lon = e.latlng.lng;

            });
        }]
    });
})();

