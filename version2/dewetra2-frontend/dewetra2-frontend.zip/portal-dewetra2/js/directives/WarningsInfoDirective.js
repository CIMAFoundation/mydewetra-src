/**
 * Created by Dario Rubado on 26/11/15.
 */

//threshold info
dewetraApp.directive('warningsInfo', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: 'apps/dewetra2/views/warnings_info.html',
        controller : 'WarningsInfoController',
        scope: {
            oWarningInfo: '=?'
        }
    };
}]);
