/**
 * Created by Dario Rubado on 03/06/15.
 */

dewetraApp.directive('eventChooser', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: 'apps/dewetra2/views/event_chooser.html',
        controller : 'eventChooserController',
        scope: {
            onClose: '=?',
            menu: '=?',
            onLayerSelected: '=?',
            onDock: '=?'
        }
    };
}]);
