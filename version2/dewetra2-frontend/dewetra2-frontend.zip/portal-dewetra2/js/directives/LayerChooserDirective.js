/**
 * Created by Dario Rubado on 03/06/15.
 */

dewetraApp.directive('layerChooser', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: window.app.config.layerChooserDirective.templateUrl,
        controller : window.app.config.layerChooserDirective.controller,
        scope: {
            onClose: '=?',
            menu: '=?',
            onLayerSelected: '=?',
            onDock: '=?'
        }
    };
}]);
