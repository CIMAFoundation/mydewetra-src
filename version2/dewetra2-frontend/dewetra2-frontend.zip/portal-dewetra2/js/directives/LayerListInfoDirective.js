/**
 * Created by Dario Rubado on 26/11/15.
 */

//threshold info
dewetraApp.directive('layerListInfo', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: 'apps/dewetra2/views/layerList_info.html',
        controller : 'LayerListInfoController',
        scope: {
            oInfo: '=?'
        }
    };
}]);
