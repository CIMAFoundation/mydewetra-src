/**
 * Created by doy on 24/06/15.
 */



dewetraApp.directive('magicSearch', [function() {
    return {
        restrict: 'AE',
        replace: true,
        templateUrl: 'apps/dewetra2/views/magic_search.html',
        controller : 'magicSearchController',
        scope: {
            onLayerSelected: '=?',
            onAddressSelected: '=?',
            onFeatureSelected: '=?',
            onFocusOut: '=?',
        }
    };
}]);