/**
 * Created by dario on 13/05/16.
 */



function showTotalRiverVolumeChartService(sensorInfo, dtFrom, dtTo, iChartHeight, thresholdService, translate, objExtremes) {

    var chart = null;
    var rangeSelected = 2;
    var thrs_colors = ['blue', 'green', 'orange', 'red'];
    //var plotLines = [];
    var undefPlotBands = [];
    //var rainAxis = 0, cumAxis = 1;
    var isDams = false;


    var colorPalette = {
        '0':'#b3c6ff',
        '1':'#99b3ff',
        '2': '#809fff',
        '3': '#668cff',
        '4': '#4d79ff',
        '5': '#3366ff',
        '6': '#1a53ff',
        '7': '#0040ff',
        '8': '#0039e6',
        '9': '#0033cc',
        '10': '#002db3',
        '11':'#002699',
    }



    var initChart = function() {

        if (chart) chart.destroy();


        chart = new Highcharts.StockChart({

            chart: {
                renderTo: 'chart',
                //marginTop: 25,
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },
            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('ORE') + ' ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div>';

                    this.points.forEach(function(item){
                        if (item.y > -9998) {
                            if (item.series.name.indexOf('thr_') < 0) {

                                s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: ' + item.series.color + '">'
                                    + $('<div>' + item.series.name + ' = ' + item.y.toFixed(2) + ((isDams)?'[m slm]':'[m'+'<sup>3</sup>/'+'s]') +' </div>').html() + '</div>';

                            }
                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [{
                id: "Confluenza Valle Baschi",
                name: "Confluenza Valle Baschi",
                type: 'line',
                threshold: null,
                yAxis: 0,
                data: [],
                color: 'blue',
                showInLegend: true
            }],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                }

            },
            navigator: {

                //baseSeries: 1,
                series: {
                    type: 'area',
                    fillOpacity: 0.3
                },
                enabled : true

            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                ordinal: false,
                type: 'datetime',
                // range:  24 * 3600 * 1000,                                    // one day
                minRange: 1 * 3600 * 1000,                                   // one hour
                tickPixelInterval: 50,
                minorTickInterval: 'auto',
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    },
                    formatter: function () {
                        var oDate = new Date(this.value);
                        if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                            return '<b>' + Highcharts.dateFormat('%d %b ', this.value) + '</b>';
                        else
                            return Highcharts.dateFormat('%H:%M ', this.value);
                    }

                },
                plotLines: [
                    {
                        color: 'rgba(69, 163, 202, 1)', // Color value
                        dashStyle: 'Solid',             // Style of the plot line. Default to solid
                        value: new Date().getTime(),    // Value of where the line will appear
                        width: '2',                     // Width of the line
                        zIndex: 4
                    }
                ],
                events: {

                    setExtremes: function(e) {

                        if (e.rangeSelectorButton) {

                            var c = e.rangeSelectorButton.count;

                            if (c == 3) {
                                rangeSelected = 0;
                            } else if (c == 12) {
                                rangeSelected = 1;
                            } else {
                                rangeSelected = 2;
                            }

                            //} else {
                            //    if (!chart.rangeSelector) {
                            //        var subTitle = ('Dati dal ' + moment(e.min/1000, 'X').format('DD/MM/YYYY') + ' al ' + moment(e.max/1000, 'X').format('DD/MM/YYYY'));
                            //        chart.setTitle(null, { text: subTitle });
                            //    }

                        }

                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {

                buttonTheme: { // styles for the buttons
                    width: 50,
                    fill: 'none',
                    stroke: 'none',
                    'stroke-width': 0,
                    r: 3,
                    style: {
                        fontWeight: 'bold',
                        fontSize: '12px',
                        fontFamily: 'Open Sans',
                    },
                    states: {
                        hover: {
                        },
                        select: {
                            fill: '#525052',
                            style: {
                                color: 'white'
                            }
                        }
                    }
                },

                buttons : [{
                        type : 'hour',
                        count : 3,
                        text : 'Last 3h'
                    }, {
                        type : 'hour',
                        count : 12,
                        text : 'Last 12h'
                    },
                    {
                        type : 'all',
                        text : 'Last 24h'
                    }],

                inputEnabled : false,
                enabled : true

            },
            yAxis: [{ // Primary yAxis
                ordinal: false,
                min : 0,
                // max : 1200,
                tickInterval: 5,
                showLastLabel: true,
                allowDecimals: true,
                alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    format: '{value:.1f}',
                    style: {
                        color: 'blue',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    text: "Q [m3/s]",
                    style: {
                        color: 'blue',
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false
            }
            ],

            loading: false

        });

        var orgHighchartsRangeSelectorPrototypeRender = Highcharts.RangeSelector.prototype.render;
        Highcharts.RangeSelector.prototype.render = function (min, max) {
            orgHighchartsRangeSelectorPrototypeRender.apply(this, [min, max]);

            var leftPosition = this.chart.plotLeft,
                topPosition = this.chart.plotTop - 50,
                space = 5;

            this.zoomText.attr({
                text: ''
            });

            for (var i = 0; i < this.buttons.length; i++) {
                this.buttons[i].attr({
                    x: leftPosition,
                    y: topPosition
                });
                leftPosition += this.buttons[i].width + space;
            }

        };

    };


    initChart();

    var seriesArray = chart.series;

    //VALLE BASCHI
    var values= [];

    sensorInfo.t_qdwnstr_main.forEach(function (t, index, array) {

        var date = moment.utc(t, "YYYY-MM-DDTHH:mm:ss").valueOf();

        if(date > 100000000){
            values.push([date, sensorInfo.qdwnstr_main[index]]);
        }



    });
    // console.log(values)
    seriesArray[0].setData(values)


    var count = 0;
    for (var river in sensorInfo.dynamicCharts){
        var values= [];

        sensorInfo.dynamicCharts[river].Time.forEach(function (t, index, array) {
            var date = moment.unix(t).valueOf()
            if(date > 100000000){
                values.push([date, sensorInfo.dynamicCharts[river].Q[index]]);
            }


        });
        count = count+1;
        chart.addSeries({
            id: river,
            name: river,
            yAxis: 0,
            type: 'line',
            threshold: null,
            data: values,
            color: sensorInfo.dynamicCharts[river].PrintColor,
            showInLegend: true
        },true,true)

        // console.log(sensorInfo.dynamicCharts[river])

        // console.log("added :" +river + "color:"+sensorInfo.dynamicCharts[river].PrintColor)



    }


    var dtmin = moment.utc(sensorInfo.t_qdwnstr_main[0], "YYYY-MM-DDTHH:mm:ss").valueOf();

    var dtTo = moment.utc(sensorInfo.t_qdwnstr_main[sensorInfo.t_qdwnstr_main.length -1], "YYYY-MM-DDTHH:mm:ss").valueOf();




    chart.xAxis[0].setExtremes(dtmin, dtTo );




    // var min = _.min(data);
    // var max = _.max(data)

    // chart.yAxis[0].setExtremes((min>0)?min*0.8:min, (max>0)?max*1.3:max+1);






    return{

        chart : chart,

        yAxisUpdate:function (max, min) {

            chart.yAxis[0].setExtremes(min, max);
            // chart.yAxis[0].update({
            //     max: max,
            //     min:min
            // });


        },
    }

}


