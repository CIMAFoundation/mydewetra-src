/**
 * Created by dario on 13/05/16.
 */


/**
 * Hydromenter chart wrapper
 */
function showDynamicRiverVolumeChartService(sensorInfo, dtFrom, dtTo, iChartHeight, thresholdService, translate, objExtremes) {

    var chart = null;
    var rangeSelected = 2;
    var thrs_colors = ['blue', 'green', 'orange', 'red'];
    //var plotLines = [];
    var undefPlotBands = [];
    //var rainAxis = 0, cumAxis = 1;
    var isDams = false;
    // if (sensorInfo.sensor.descr.indexOf("Diga")>-1) {
    //     isDams = true;
    //
    //     thresholdService.getDamsThresholdById(sensorInfo.sensor.sensorid).then(function (data) {
    //         // console.log(data)
    //         loadSoglieInvasi(data);
    //
    //     },function () {
    //         alert("error loading stations!")
    //     })
    // }


    var initChart = function() {

        if (chart) chart.destroy();


        chart = new Highcharts.StockChart({

            chart: {
                renderTo: 'chart',
                //marginTop: 25,
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },
            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('ORE') + ' ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div>';

                    this.points.forEach(function(item){
                        if (item.y > -9998) {
                            if (item.series.name.indexOf('thr_') < 0) {

                                s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: ' + item.series.color + '">'
                                    + $('<div>' + item.series.name + ' = ' + item.y.toFixed(2) + ((isDams)?'[m slm]':'[m'+'<sup>3</sup>/'+'s]') +' </div>').html() + '</div>';

                            }
                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [

                {
                    name: "Portata Modellata",
                    type: 'line',
                    threshold: null,
                    data: [],
                    color: 'blue',
                    showInLegend: true
                },

            ],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                }

            },
            navigator: {

                //baseSeries: 1,
                series: {
                    type: 'area',
                    fillOpacity: 0.3
                },
                enabled : true

            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                ordinal: false,
                type: 'datetime',
                // range:  24 * 3600 * 1000,                                    // one day
                minRange: 1 * 3600 * 1000,                                   // one hour
                tickPixelInterval: 50,
                minorTickInterval: 'auto',
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    },
                    formatter: function () {
                        var oDate = new Date(this.value);
                        if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                            return '<b>' + Highcharts.dateFormat('%d %b', this.value) + '</b>';
                        else
                            return Highcharts.dateFormat('%H:%M', this.value);
                    }

                },
                plotLines: [
                    {
                        color: 'rgba(69, 163, 202, 1)', // Color value
                        dashStyle: 'Solid',             // Style of the plot line. Default to solid
                        value: new Date().getTime(),    // Value of where the line will appear
                        width: '2',                     // Width of the line
                        zIndex: 4
                    }
                ],
                events: {

                    setExtremes: function(e) {

                        if (e.rangeSelectorButton) {

                            var c = e.rangeSelectorButton.count;

                            if (c == 3) {
                                rangeSelected = 0;
                            } else if (c == 12) {
                                rangeSelected = 1;
                            } else {
                                rangeSelected = 2;
                            }

                            //} else {
                            //    if (!chart.rangeSelector) {
                            //        var subTitle = ('Dati dal ' + moment(e.min/1000, 'X').format('DD/MM/YYYY') + ' al ' + moment(e.max/1000, 'X').format('DD/MM/YYYY'));
                            //        chart.setTitle(null, { text: subTitle });
                            //    }

                        }

                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {

                buttonTheme: { // styles for the buttons
                    width: 50,
                    fill: 'none',
                    stroke: 'none',
                    'stroke-width': 0,
                    r: 3,
                    style: {
                        fontWeight: 'bold',
                        fontSize: '12px',
                        fontFamily: 'Open Sans',
                    },
                    states: {
                        hover: {
                        },
                        select: {
                            fill: '#525052',
                            style: {
                                color: 'white'
                            }
                        }
                    }
                },

                buttons : [{
                        type : 'hour',
                        count : 3,
                        text : 'Last 3h'
                    }, {
                        type : 'hour',
                        count : 12,
                        text : 'Last 12h'
                    },
                    {
                        type : 'all',
                        text : 'Last 24h'
                    }],

                inputEnabled : false,
                enabled : true

            },
            yAxis: [{ // Primary yAxis
                ordinal: false,
                min : 0,
                max : 1200,
                tickInterval: 5,
                showLastLabel: true,
                allowDecimals: true,
                alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    format: '{value:.1f}',
                    style: {
                        color: 'blue',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    text: "Q [m3/s]",
                    style: {
                        color: 'blue',
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false
            }
            ],

            loading: false

        });

        var orgHighchartsRangeSelectorPrototypeRender = Highcharts.RangeSelector.prototype.render;
        Highcharts.RangeSelector.prototype.render = function (min, max) {
            orgHighchartsRangeSelectorPrototypeRender.apply(this, [min, max]);

            var leftPosition = this.chart.plotLeft,
                topPosition = this.chart.plotTop - 50,
                space = 5;

            this.zoomText.attr({
                text: ''
            });

            for (var i = 0; i < this.buttons.length; i++) {
                this.buttons[i].attr({
                    x: leftPosition,
                    y: topPosition
                });
                leftPosition += this.buttons[i].width + space;
            }

        };

    };

    // if (!sensorInfo) return;



    /* if (!chart) */ initChart();

    //setto i due oggetti per modificare i dati e le label
    var seriesArray = chart.series;

    // Title
    var station = sensorInfo.selectedDynamicCharts;





    // Data di inizio della timeline
    //var dtmin = moment.utc(sensorInfo.dynamicCharts[sensorInfo.selectedDynamicCharts].Time[0], "YYYY-MM-DDTHH:mm:ss");
    var dtmin = moment.unix(sensorInfo.dynamicCharts[sensorInfo.selectedDynamicCharts].Time[0]);
    // var dtto = moment.utc(sensorInfo.dynamicCharts[sensorInfo.selectedDynamicCharts].Time[sensorInfo.dynamicCharts[sensorInfo.selectedDynamicCharts].Time.length -1], "YYYY-MM-DDTHH:mm:ss");
    var dtto = moment.unix(sensorInfo.dynamicCharts[sensorInfo.selectedDynamicCharts].Time[sensorInfo.dynamicCharts[sensorInfo.selectedDynamicCharts].Time.length -1]);


    var values= [];

    sensorInfo.dynamicCharts[sensorInfo.selectedDynamicCharts].Time.forEach(function (t, index, array) {
        var date = moment.unix(t).valueOf();
        values.push([date, sensorInfo.dynamicCharts[sensorInfo.selectedDynamicCharts].Q[index]]);

    });



    seriesArray[0].id = "Portata Modellata";

    seriesArray[0].setData(values);

    seriesArray[0].name = "Portata Modellata";




    var data = sensorInfo.dynamicCharts[sensorInfo.selectedDynamicCharts].Q;

    var min = _.min(data);
    var max = _.max(data)

    chart.yAxis[0].setExtremes((min>0)?min*0.8:min, (max>0)?max*1.3:max+1);





    return{

        chart : chart,

        yAxisUpdate:function (max, min) {

            chart.yAxis[0].setExtremes(min, max);
            // chart.yAxis[0].update({
            //     max: max,
            //     min:min
            // });


        },
    }

}


