/**
 * Created by Dario Rubado on 05/06/2020.
 */

/**
 * multi Deterministic Hydrograms chart wrapper
 */
function showMultiDeterministicHydrogramsChart(hydrogram, iChartHeight, oChartSettings, $sce,rasorService, _, $translate) {

    var chart = null;
    var thrs_colors = ['yellow', 'red'];
    var plotLines = [];

    var label= 'multi_det';

    var colors = ['blue','red','green'];

    var hasThreshold = true;




    var getMax = function() {

        if(oChartSettings.yAxisExtremes.max) return oChartSettings.yAxisExtremes.max

        let aMax=[]
        if(hydrogram.values.lengh > 0){
            for(let i in hydrogram.values){
                aMax.push(_.max(hydrogram.values[i]))
            }
        }

        if(hydrogram.thresholds.length > 0 ){
            aMax.push(hydrogram.thresholds[0].value)
        }

        return _.max(aMax) *1.05;

    };


    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.StockChart({

            chart: {
                renderTo: 'chart',
                alignTicks: false,
                zoomType: 'xy',
                height : iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },

            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">Ore ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div><br>';

                    this.points.forEach(function(item) {
                        if (item.y > -9998) {

                            s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: ' + item.series.color + '">'
                                + '<div>' + item.series.name + ' = ' + item.y.toFixed(2) + (oChartSettings.isVolume? (' x 10<sup>6</sup>') : '')
                                + ' [' + oChartSettings.unit_of_measure+']</div>' + '</div><br>';

                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [



            ],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                },
                sourceWidth: 1500,
                sourceHeight: 1000,

            },
            navigator: {

                //series: {
                //    type: 'area',
                //    fillOpacity: 0.3
                //},

                enabled : false

            },
            scrollbar: {
                enabled: false
            },

            xAxis: {

                ordinal: false,
                type: 'datetime',
                min : moment.utc(hydrogram.timeline[0]).valueOf(),
                max : moment.utc(hydrogram.timeline[hydrogram.timeline.length - 1]).valueOf(),
                //range:  24 * 3600 * 1000,                                    // one day
                minRange: 1 * 3600 * 1000,                                   // one hour
                tickPixelInterval: 50,
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '14px'
                    },
                    formatter: function () {
                        var oDate = new Date(this.value);
                        if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                            return '<b>' + Highcharts.dateFormat('%d %b', this.value) + '</b>';
                        else
                            return Highcharts.dateFormat('%H:%M', this.value);
                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {
                enabled : false
            },
            yAxis: [{ // Primary yAxis
                ordinal: false,

                min : oChartSettings.yAxisExtremes.min,
                // max : getMax(),
                // min : (oChartSettings.isVolume? null : 0),
                max : getMax(),
                //tickInterval: oChartSettings.yAxis_tickInterval,
                showLastLabel : true,
                allowDecimals: true,
                alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    x: oChartSettings.yAxis_labels_x,
                    y: 5,
                    format: (oChartSettings.isVolume? '{value:.2f}' : '{value:.1f}'),
                    style: {
                        color: 'blue',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '14px'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: (oChartSettings.yAxis_labels_x + 10),
                    useHTML:true,
                    text: oChartSettings.yAxis_title,
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: true

            }],

            loading: false

        });

    };

    if (!hydrogram) return;

    if (!chart) initChart();

    //setto i due oggetti per modificare i dati e le label
    var seriesArray = chart.series;

    chart.xAxis[0].removePlotLine('dtref');
    chart.xAxis[0].removePlotLine('now');
    chart.xAxis[0].addPlotLine(
        {
            id : 'dtref',
            value : hydrogram.dateRef,
            color : '#00C8DC',
            width : 2,
            zIndex: 5,
            label : {
                text : 'DateRef'
            }
        });

    chart.xAxis[0].addPlotLine(
        {
            id : 'now',
            value : hydrogram.now,
            color : '#A52A2A',
            width : 2,
            zIndex: 5,
            label : {
                text : (hydrogram.isRealTime? 'Now' : 'Now deferred')
            }
        });

    // thresholds
    for (var i = 0; i < plotLines.length; i++) {
        chart.yAxis[0].removePlotLine(plotLines[i].id);
    }
    plotLines = [];

    for (var i = 0; i < hydrogram.thresholds.length; i++) {

        if (hydrogram.thresholds[i].value > 0) {

            var p = {
                id : 'thr_' + i,
                value : (oChartSettings.isVolume? hydrogram.thresholds[i].value/1000000 : hydrogram.thresholds[i].value),
                color : thrs_colors[i],
                width : 2,
                zIndex: 4,
                label : {
                    text : hydrogram.thresholds[i].name
                }
            };

            chart.yAxis[0].addPlotLine(p);
            plotLines.push(p);

        }

    }


    hydrogram.values.forEach(function (serie, index) {

        let obj = {
            name: $translate.instant('chartlabel_'+label+'_'+index),
            type: 'line',
            threshold: null,
            data: [],
            //color: '#' + (0x1000000 + (Math.random()) * 0xffffff).toString(16).substr(1, 6),
            color:colors[index],
            dashStyle: 'line',
            showInLegend: true
        }

        for (let t = 0; t < hydrogram.timeline.length; t++) {

            var date = moment.utc(hydrogram.timeline[t]).valueOf();
            var val = parseFloat(serie[t]);

            switch (val) {
                case ( -9999):
                    break;
                case ( -9998):
                    obj.data.push([date, null])
                    break;
                default:
                    obj.data.push([date, val])
                    break;
            }



        }

        chart.addSeries(obj, true)
    })

    chart.redraw();

    // La prima volta imposta quelli generato dal chart
    if (!oChartSettings.yAxisExtremes.min) {

        var volExtremes = chart.yAxis[0].getExtremes();
        oChartSettings.yAxisExtremes.min = volExtremes.min;
        oChartSettings.yAxisExtremes.max = volExtremes.max;

    }

    return{

        chart : chart,

        yAxisUpdate:function (max, min) {

            chart.yAxis[0].setExtremes(min, max);
            // chart.yAxis[0].update({
            //     max: max,
            //     min:min
            // });
        },


    }

}

