/**
 * Created by pynthu on 05/11/2014.
 */

/**
 * Deterministic Hydrograms chart wrapper
 */
function showDeterministicHydrogramsChart(hydrogram, iChartHeight, oChartSettings, $sce,rasorService, _) {

    var chart = null;
    var thrs_colors = ['yellow', 'red'];
    var plotLines = [];


    //var getQMax = function() {
    //
    //    var maxQ = -1, Qmod, Qoss;
    //    // Thresholds
    //    for (var i = 0; i < hydrogram.thresholds.length; i++) {
    //
    //        if (hydrogram.thresholds[i].value > maxQ) maxQ = hydrogram.thresholds[i].value;
    //
    //    }
    //    if ((hydrogram.area > 0) && (maxQ < 0)) maxQ = 20*Math.pow(hydrogram.area, 0.6);
    //    // Q
    //    for (var i = 0; i < hydrogram.timeline.length; i++) {
    //
    //        Qoss = parseFloat(hydrogram.values[oChartSettings.hydrogramsIndexOffset][i]);
    //        if (Qoss > maxQ) maxQ = Qoss;
    //
    //        Qmod = parseFloat(hydrogram.values[oChartSettings.hydrogramsIndexOffset + 1][i]);
    //        if (Qmod > maxQ) maxQ = Qmod;
    //
    //    }
    //
    //    return (maxQ * 1.1);
    //
    //};



    var getMax = function() {

        if(oChartSettings.yAxisExtremes.max) return oChartSettings.yAxisExtremes.max

        let aMax=[]

        hydrogram.values.forEach(function (aVal) {
            try {
                var p = aVal.map(parseFloat);
                // console.log(p)
                aMax.push(_.max(p));
            }catch (e) {
                console.log(e)
            }
        });



        if(hydrogram.thresholds.length > 0 ){
            aMax.push(hydrogram.thresholds[0].value)
        }

        let max = _.max(aMax) *1.05;



        return (oChartSettings.isVolume)?max/1000000:max;

    };


    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.StockChart({

            chart: {
                renderTo: 'chart',
                alignTicks: false,
                zoomType: 'xy',
                height : iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },

            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">Ore ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div><br>';

                    this.points.forEach(function(item) {
                        if (item.y > -9998) {

                            s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: ' + item.series.color + '">'
                               + '<div>' + item.series.name + ' = ' + item.y.toFixed(2) + (oChartSettings.isVolume? (' x 10<sup>6</sup>') : '')
                               + ' [' + oChartSettings.unit_of_measure+']</div>' + '</div><br>';

                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [

                // Q(mod)
                {
                    name: oChartSettings.mod_series_name,
                    type: 'line',
                    color: 'blue',
                    threshold: null,
                    data: [],
                    showInLegend: true
                },
                // Q(oss)
                {
                    name: oChartSettings.obs_series_name,
                    type: 'line',
                    threshold: null,
                    data: [],
                    color: '#000000',
                    dashStyle: 'Dash',
                    showInLegend: true
                }

            ],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                },
                sourceWidth: 1500,
                sourceHeight: 1000,

            },
            navigator: {

                //series: {
                //    type: 'area',
                //    fillOpacity: 0.3
                //},

                enabled : false

            },
            scrollbar: {
                enabled: false
            },

            xAxis: {

                ordinal: false,
                type: 'datetime',
                min : moment.utc(hydrogram.timeline[0]).valueOf(),
                max : moment.utc(hydrogram.timeline[hydrogram.timeline.length - 1]).valueOf(),
                //range:  24 * 3600 * 1000,                                    // one day
                minRange: 1 * 3600 * 1000,                                   // one hour
                tickPixelInterval: 50,
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '14px'
                    },
                    formatter: function () {
                        var oDate = new Date(this.value);
                        if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                            return '<b>' + Highcharts.dateFormat('%d %b', this.value) + '</b>';
                        else
                            return Highcharts.dateFormat('%H:%M', this.value);
                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {
                enabled : false
            },
            yAxis: [{ // Primary yAxis
                ordinal: false,

                min : oChartSettings.yAxisExtremes.min,
                max : getMax(),
                // min : (oChartSettings.isVolume? null : 0),
                //max : getQMax(),
                //tickInterval: oChartSettings.yAxis_tickInterval,
                showLastLabel : true,
                allowDecimals: true,
                alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    x: oChartSettings.yAxis_labels_x,
                    y: 5,
                    format: (oChartSettings.isVolume? '{value:.2f}' : '{value:.1f}'),
                    style: {
                        color: 'blue',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '14px'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: (oChartSettings.yAxis_labels_x + 10),
                    useHTML:true,
                    text: oChartSettings.yAxis_title,
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: true

            }],

            loading: false

        });

    };

    if (!hydrogram) return;

    if (!chart) initChart();

    //setto i due oggetti per modificare i dati e le label
    var seriesArray = chart.series;

    chart.xAxis[0].removePlotLine('dtref');
    chart.xAxis[0].removePlotLine('now');
    chart.xAxis[0].addPlotLine(
            {
                id : 'dtref',
                value : hydrogram.dateRef,
                color : '#00C8DC',
                width : 2,
                zIndex: 5,
                label : {
                    text : 'DateRef'
                }
            });

    chart.xAxis[0].addPlotLine(
            {
                id : 'now',
                value : hydrogram.now,
                color : '#A52A2A',
                width : 2,
                zIndex: 5,
                label : {
                    text : (hydrogram.isRealTime? 'Now' : 'Now deferred')
                }
            });

    // thresholds
    for (var i = 0; i < plotLines.length; i++) {
        chart.yAxis[0].removePlotLine(plotLines[i].id);
    }
    plotLines = [];

    for (var i = 0; i < hydrogram.thresholds.length; i++) {

        if (hydrogram.thresholds[i].value > 0) {

            var p = {
                id : 'thr_' + i,
                value : (oChartSettings.isVolume? hydrogram.thresholds[i].value/1000000 : hydrogram.thresholds[i].value),
                color : thrs_colors[i],
                width : 2,
                zIndex: 4,
                label : {
                    text : hydrogram.thresholds[i].name
                }
            };

            chart.yAxis[0].addPlotLine(p);
            plotLines.push(p);

        }

    }


    var date, val, values = [];
    // Q(mod)
    for (var i = 0; i < hydrogram.timeline.length; i++) {

        date = moment.utc(hydrogram.timeline[i]).valueOf();
        val = parseFloat(hydrogram.values[oChartSettings.hydrogramsIndexOffset + 1][i]);

        if (val > -9998) values.push([date, (oChartSettings.isVolume? val/1000000 : val)])

    }
    seriesArray[0].id = hydrogram.section + '_Q(mod)';
    seriesArray[0].setData(values);

    values = [];
    // Q(oss)
    for (var i = 0; i < hydrogram.timeline.length; i++) {

        date = moment.utc(hydrogram.timeline[i]).valueOf();
        val = parseFloat(hydrogram.values[oChartSettings.hydrogramsIndexOffset][i]);

        if (val > -9998) values.push([date, (oChartSettings.isVolume? val/1000000 : val)])

    }
    seriesArray[1].id = hydrogram.section + '_Q(oss)';
    seriesArray[1].setData(values);

    // La prima volta imposta quelli generato dal chart
    if (!oChartSettings.yAxisExtremes.min) {

        var volExtremes = chart.yAxis[0].getExtremes();
        oChartSettings.yAxisExtremes.min = volExtremes.min;
        oChartSettings.yAxisExtremes.max = volExtremes.max;

    }

    return chart

}

