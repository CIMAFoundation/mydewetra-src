/**
 * Simple GSI chart
 */
function showGSIChart(phenolData, iChartHeight, translate, objExtremes) {
    var chart = null;
    console.log("showGSIChart");
    console.log(phenolData);

    var initChart = function() {
        if (chart) chart.destroy();
        chart = new Highcharts.StockChart({

            chart: {
                renderTo: 'chart',
                //marginTop: 25,
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },
            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('DATE').toUpperCase() + ' ' + moment.utc(this.x/1000, 'X').format('DD/MM') + '</div><br>';

                    //if (!this.points) this.points = [this.point];
                    var points = (this.points)? this.points : [this.point];

                    points.forEach(function(item){
                        if (item.y > -9998) {
                            s += '<div style="font-family:\'Open Sans\', sans-serif; font-size:12px; color:' + item.color + '">' +
                                $('<div>' + item.series.name + ' = ' + item.y.toFixed(1) +  '</div>').html() + '</div><br>';                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                }

            },
            navigator: {
                enabled : false
            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                ordinal: false,
                type: 'datetime',
                range: 365 * 24 * 3600 * 1000,                                       // one year
                minRange: 3 * 24 * 3600 * 1000,                                     // 3 months
                minorTickInterval: 'auto',
                tickInterval: 1 * 15 * 24 * 3600 * 1000,                             // 0.5 months
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    },
                    formatter: function () {
                        return '<b>' + Highcharts.dateFormat('%d/%m', this.value) + '</b>';
                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: false,
                        lineWidth: 0,
                        radius: 4,
                        symbol: "circle"
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {
                enabled : false
            },
            yAxis: [{ // Primary yAxis
                ordinal: false,
                showLastLabel : true,
                allowDecimals: true,
                tickInterval: 5,
                labels: {
                    x: -5,
                    y: 5,
                    format: '{value:.0f}',
                    style: {
                        color: 'red',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 45,
                    useHTML:true,
                    text: '<p style="color:red">' + translate.instant('GSI') + '</p>',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false
            }],

            loading: false

        });

    };

    if (!phenolData) return;

    initChart();

    
    var filteredSeries = phenolData.data.filter(d => !parseInt(d.title));

    for (var i = 0; i < filteredSeries.length; i++) {
        var data = filteredSeries[i];
        var descr = translate.instant(data.title);
        var type =  'line';
        
        var values = data.values;
        var timeline = data.timeline;
        var items = [];
        for (var j = 0; j < timeline.length; j++) {
            var date = moment.utc(timeline[j]).valueOf();
            if (!isNaN(values[j]) && (values[j] > -9998)) {
                items.push([date, parseFloat(values[j])]);
            }
        }

        var series = {
            name: (descr + ' ' + phenolData.data[i].title),
            type: type,
            threshold: null,
            data: items,
            showInLegend: true
        };
        series.id = data.type + '_' + data.title;

        chart.addSeries(series);

    }
    /*
    var y = moment.utc(phenolData.data[0].timeline[0]).year();

    chart.xAxis[0].setExtremes(moment.utc(y + '-01-01T00:00:00+00:00').valueOf(), moment.utc(y + '-12-31T00:00:00+00:00').valueOf());
    */
    return {
        chart : chart
    }


}

