/**
 * Created by Anto on 02/08/2017
 */

/**
 * Thermometer chart wrapper
 */
function showMontlyAccumulatedChart(phenolData, iChartHeight, translate, objExtremes) {

    var chart = null;

    console.log("showMontlyAccumulatedChart");


    console.log(phenolData)



    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.Chart({

            chart: {
                renderTo: 'chart',
                //marginTop: 25,
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            title: {
                text: "",
                margin: 0
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },
            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('MONTH').toUpperCase() + ' ' + this.x + '</div><br>';

                    this.points.forEach(function(item){
                        if (item.y > -9998) {
                            s += '<div style="font-family:\'Open Sans\', sans-serif; font-size:12px; color:' + item.color + '">' +
                                $('<div>' + item.series.name + ' = ' + item.y.toFixed(0) +  '</div>').html() + ' [mm]</div><br>';                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                },
                sourceWidth: 1500,
                sourceHeight: 1000,

            },
            navigator: {
                enabled : false
            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: translate.instant('YEAR'),
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                column: {
                    grouping: true,
                    shadow: false,
                    marker: {
                        enabled: false,
                        radius: 1
                    }
                }
            },
            rangeSelector : {
                enabled : false
            },
            yAxis: [{ // Primary yAxis
                min : 0,
                showLastLabel : true,
                allowDecimals: true,
                tickInterval: 25,
                labels: {
                    x: -5,
                    y: 5,
                    format: '{value:.0f}',
                    style: {
                        color: 'green',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 45,
                    useHTML:true,
                    text: '<p style="color:green">' + translate.instant('Cumulative Rainfall') + ' [mm]</p>',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false
            }],

            loading: false

        });

    };

    if (!phenolData) return;

    initChart();

    var series, items, descr, type;

    for (var i = 0; i < phenolData.data.length; i++) {

        // Temperatura Media
        items = [];

        for (var j = 0; j < phenolData.data[i].timeline.length; j++) {

            var date = moment.utc(phenolData.data[i].timeline[j]);

            date.month()

            if (!isNaN(phenolData.data[i].values[j]) && (phenolData.data[i].values[j] > -9998)) {

                items.push([date.month(), parseFloat(phenolData.data[i].values[j])]);

            }

        }

        series = {
            name: translate.instant('SEASON' + phenolData.data[i].title),
            type: 'line',
            threshold: null,
            data: items,
            pointPadding: 0,
            showInLegend: true
        };
        series.id = phenolData.data[i].type + '_' + phenolData.data[i].title;

        chart.addSeries(series);

    }






    return {
        chart : chart
    }


}



function showSeasonAccumulatedChart(phenolData, iChartHeight, translate, objExtremes) {

    var chart = null;

    console.log("showSeasonAccumulatedChart");

    var getCategories = function() {

        var ymin = moment.utc(phenolData.data[0].timeline[0]).year();
        var ymax = moment.utc(phenolData.data[0].timeline[phenolData.data[0].timeline.length - 1]).year();

        for (var i = 1; i < phenolData.data.length; i++) {

            ymin = Math.min(ymin, moment.utc(phenolData.data[i].timeline[0]).year());
            ymax = Math.max(ymax, moment.utc(phenolData.data[i].timeline[phenolData.data[0].timeline.length - 1]).year());

        }

        return _.range(ymin, ymax + 1);

    }

    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.Chart({

            chart: {
                renderTo: 'chart',
                //marginTop: 25,
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            title: {
                text: "",
                margin: 0
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },
            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('YEAR').toUpperCase() + ' ' + this.x + '</div><br>';

                    this.points.forEach(function(item){
                        if (item.y > -9998) {
                            s += '<div style="font-family:\'Open Sans\', sans-serif; font-size:12px; color:' + item.color + '">' +
                                $('<div>' + item.series.name + ' = ' + item.y.toFixed(0) +  '</div>').html() + ' [mm]</div><br>';                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                },
                sourceWidth: 1500,
                sourceHeight: 1000,

            },
            navigator: {
                enabled : false
            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                categories: getCategories(),
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: translate.instant('YEAR'),
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                column: {
                    grouping: true,
                    shadow: false,
                    marker: {
                        enabled: false,
                        radius: 1
                    }
                }
            },
            rangeSelector : {
                enabled : false
            },
            yAxis: [{ // Primary yAxis
                min : 0,
                showLastLabel : true,
                allowDecimals: true,
                tickInterval: 25,
                labels: {
                    x: -5,
                    y: 5,
                    format: '{value:.0f}',
                    style: {
                        color: 'green',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 45,
                    useHTML:true,
                    text: '<p style="color:green">' + translate.instant('Cumulative Rainfall') + ' [mm]</p>',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false
            }],

            loading: false

        });

    };

    if (!phenolData) return;

    initChart();

    var series, items, descr, type;

    for (var i = 0; i < phenolData.data.length; i++) {

        // Temperatura Media
        items = [];

        for (var j = 0; j < phenolData.data[i].timeline.length; j++) {

            var date = moment.utc(phenolData.data[i].timeline[j]);

            if (!isNaN(phenolData.data[i].values[j]) && (phenolData.data[i].values[j] > -9998)) {

                items.push([date.year(), parseFloat(phenolData.data[i].values[j])]);

            }

        }

        series = {
            name: translate.instant('YEAR_' + phenolData.data[i].title),
            type: 'column',
            threshold: null,
            data: items,
            pointPadding: 0,
            showInLegend: true
        };
        series.id = phenolData.data[i].type + '_' + phenolData.data[i].title;

        chart.addSeries(series);

    }

    return {
        chart : chart
    }


}
