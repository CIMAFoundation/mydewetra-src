/**
 * Created by Anto on 02/08/2017
 */

/**
 * Thermometer chart wrapper
 */
function showSeasonPhenolPhaseChart(phenolData, iChartHeight, translate, objExtremes) {

    var chart = null;
    console.log("showSeasonPhenolPhaseChart");

    // console.log(phenolData)
    var asseX = []

    var dataForPhenoPhase = angular.copy(phenolData.data);

    dataForPhenoPhase.pop();

    dataForPhenoPhase.forEach(function (year) {
            asseX.push(year.title)


    })



    var palette = {1:{
        fase:1,
            label:"FASE_FENOLOGICA_1",
            descr:"FASE_FENOLOGICA_1",
            color:"#FF0000",
    },
    2:{
        fase:2,
            label:"FASE_FENOLOGICA_2",
            descr:"FASE_FENOLOGICA_2",
            color:"#70f5ff",
    },
    3:{
        fase:3,
            label:"FASE_FENOLOGICA_3",
            descr:"FASE_FENOLOGICA_3",
            color:"#00ff00",
    },
    4:{
        fase:4,
            label:"FASE_FENOLOGICA_4",
            descr:"FASE_FENOLOGICA_4",
            color:"#FFFF00",
    },
    5:{
        fase:5,
            label:"FASE_FENOLOGICA_5",
            descr:"FASE_FENOLOGICA_5",
            color:"#ffaf00",
    }}

    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.StockChart({

            chart: {
                renderTo: 'chart',
                type:'column',
                //marginTop: 25,
                // alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },
            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                     var s = '';

                    this.points.forEach(function(item){

                        // s+='<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('DATE').toUpperCase() + ' ' + item.point.date.format('DD/MM/YYYY') + '</div><br>';

                        if (item.y > -9998) {
                            s += '<div style="font-family:\'Open Sans\', sans-serif; font-size:12px; color:' + /*item.color*/'black' + '">' +
                                $('<div>' +  moment.utc(item.point.date).format('DD/MM')+ ' = ' + translate.instant(palette[item.point.phenoPhase].label) +  '</div>').html() + '</div><br>';                        }

                    });
                    return s;
                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: false,
                useHTML: true
            },

            series: [],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                },
                sourceWidth: 1500,
                sourceHeight: 1000,

            },
            navigator: {
                enabled : false
            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                // ordinal: false,
                // type: 'datetime',
                categories:asseX,
                // range: 365 * 24 * 3600 * 1000,                                       // one year
                // minRange: 365 * 24 * 3600 * 1000,                                       // one year
                // minRange: 30 * 24 * 3600 * 1000,                                     // 3 months
                // minorTickInterval: 'auto',
                // tickInterval: 2 * 30 * 24 * 3600 * 1000,                             // 2 months
                // tickInterval: 365 * 24 * 3600 * 1000,                             // one year
                // lineWidth: 2,
                // gridLineWidth: 2,
                // lineColor: 'black',
                // dateTimeLabelFormats: {
                //     year: "%Y"
                // },
                // title: {
                //     margin: 0,
                //     text: 'Time UTC',
                //     style: {
                //         fontWeight : 'bold',
                //         fontFamily: 'Open Sans'
                //     }
                // },
                labels: {
                    formatter: function() {
                        // console.log((this))
                        var labels = asseX;
                        return labels[this.value];
                    },
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    },
                    // formatter: function () {
                    //     return '<b>' + Highcharts.dateFormat('%d/%m', this.value) + '</b>';
                    // }

                }

            },
            plotOptions: {
                columnrange: {
                    grouping: false
                },
                column:{
                    // stacking: 'normal',
                    grouping: false,
                    dataLabels: {
                        enabled: false,
                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                        formatter:function () {

                        }
                    }
                },
                series: {
                    dataGrouping: {
                        // enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: true,
                        lineWidth: 0,
                        radius: 4,
                        symbol: "circle"
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {
                enabled : false
            },
            yAxis: [{ // Primary yAxis
                // ordinal: false,
                // showLastLabel : true,
                // allowDecimals: true,
                // min : 1,
                max : 366,
                endOnTick:true,
                tickInterval:30,
                labels: {
                    x: -5,
                    y: 5,
                    // format: '{value:.0f}',
                    formatter: function() {
                        var labels = ["dormienza", "quiescenza", "ripresa", "maturita'", "senescenza"];
                        var labels = ["gennaio","febbraio","marzo","aprile","maggio","giugno","luglio","agosto","settembre","ottobre","novembre","dicembre"];
                        return labels[parseInt(this.value/30) - 1];
                    },
                    style: {
                        color: 'red',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 55,
                    useHTML:true,
                    text: '<p>' + translate.instant('arbustiva') + '</p>',
                    style: {
                        color: 'red',
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false
            }],

            loading: false

        });

    };

    if (!phenolData) return;

    initChart();

    dataForPhenoPhase.forEach(function (yearData,yearIndex) {

        for (var j = yearData.timeline.length-1; j >= 0 ; j--) {

            var data =  parseInt(yearData.values[j]);
            var date = moment.utc(yearData.timeline[j]);
            var obj ={
                "y":date.dayOfYear(),
                "phenoPhase":data,
                "date":yearData.timeline[j],

            }
            var color = palette[data].color;

            var series = [];

            dataForPhenoPhase.forEach(function (year,index,arr) {
                // if(year.title)obj.yearString=year.title;
                (yearIndex == index)?series.push(obj):series.push(null)
            })

            chart.addSeries({
                data:series,
                color:color
            });

        }
    });

    function gelLabel() {
        var label ='<div><ul style="list-style-type: none; border: 1px solid black;" >';
        label +='<li style="color: black;">Legenda</li>';
        for(var i in palette){
            var item =palette[i];
            label += '<li style="background-color:'+ item.color +'; color: black;">'+ translate.instant(item.label) +'</li>';
        }
        return label+ '</ul></div>';
    }

    //ultimo punto ultima serie

    // var point = chart.series[chart.series.length -1].points[chart.series[chart.series.length -1].points.length -1];


    chart.renderer.label(gelLabel(),chart.chartWidth*0.9,chart.chartHeight*0.1,null, null,null,true,null,null).css({color:'black'}).add();



    // for (var i = 0; i < dataForPhenoPhase.length; i++){
    //
    //     // for (var j = 0; j < phenolData.data[i].timeline.length; j++) {
    //     for (var j = dataForPhenoPhase[i].timeline.length-1; j >= 0 ; j--) {
    //
    //         var data =  parseInt(dataForPhenoPhase[i].values[j]);
    //         var date = moment.utc(dataForPhenoPhase[i].timeline[j]);
    //         var obj ={
    //             "y":date.dayOfYear(),
    //             "phenoPhase":data,
    //             "date":date,
    //
    //         }
    //         var color = palette[data].color;
    //
    //         var series = [];
    //         for(var o = 0; o < dataForPhenoPhase.length; o++){
    //             (i == o)?series.push(obj):series.push(null)
    //         }
    //         chart.addSeries({
    //             data:series,
    //             color:color
    //         });
    //
    //     }
    //
    // }

    return {
        chart : chart
    }


}
