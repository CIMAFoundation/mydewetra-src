/**
 * Created by Anto on 02/08/2017
 */

/**
 * Thermometer chart wrapper
 */
function showPhenolPhaseCfrChart(phenolData, iChartHeight, translate, objExtremes) {

    var labels_feno = ["FASE_FENOLOGICA_1", "FASE_FENOLOGICA_2", "FASE_FENOLOGICA_3", "FASE_FENOLOGICA_4", "FASE_FENOLOGICA_5"];
    var labels_herb = ["FASE_ERBACEE_1", "FASE_ERBACEE_2", "FASE_ERBACEE_3", "FASE_ERBACEE_4"];

    var chart = null;

    console.log("showPhenolPhaseCfrChart");

    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.StockChart({

            chart: {
                renderTo: 'chart',
                //marginTop: 25,
                alignTicks: false,
                zoomType: 'xy',
                animation: false,
                height: iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },
            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {
                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' +
                        translate.instant('DATE').toUpperCase() + ' ' +
                        moment.utc(this.x/1000, 'X').format('DD/MM/YYYY') + '</div><br>';

                    this.points.forEach(function(item){
                        if (item.y > -9998) {
                            s += '<div style="font-family:\'Open Sans\', sans-serif; font-size:12px; color:' + item.color + '">' +
                                $(  '<div>' +
                                        item.series.name + ' = ' +
                                        translate.instant(
                                            item.series.name==translate.instant('Fase fenologica arbustiva')?
                                                labels_feno[item.y-1]:labels_herb[item.y-1]
                                        ) +
                                    '</div>'
                                ).html() +
                                '</div><br>';
                        }

                    });
                    return s;
                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [

                {
                    name: translate.instant('Fase fenologica arbustiva'),
                    type: 'line',
                    color: 'red',
                    yAxis: 0,
                    threshold: null,
                    data: [],
                    showInLegend: true
                },
                {
                    name: translate.instant('Fase fenologica erbacea'),
                    type: 'line',
                    color: 'green',
                    yAxis: 1,
                    threshold: null,
                    data: [],
                    showInLegend: true
                }

            ],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                }

            },
            navigator: {
                enabled : false
            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                ordinal: false,
                type: 'datetime',
                range: 365 * 24 * 3600 * 1000,                                     // one year
                minRange: 30 * 24 * 3600 * 1000,                                   // one month
                minorTickInterval: 'auto',
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    },
                    formatter: function () {
                        return '<b>' + Highcharts.dateFormat('%m %Y', this.value) + '</b>';
                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: true,
                        lineWidth: 0,
                        radius: 4,
                        symbol: "circle"
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {
                enabled : false
            },
            yAxis: [{ // Primary yAxis
                ordinal: false,
                showLastLabel : true,
                allowDecimals: true,
                min : 1,
                max : 5,
                labels: {
                    x: -5,
                    y: 5,
                    format: '{value:.0f}',
                    formatter: function() {
                        return translate.instant(labels_feno[this.value - 1]);
                    },
                    style: {
                        color: 'red',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 55,
                    useHTML:true,
                    text: '<p>' + translate.instant('arbustiva') + '</p>',
                    style: {
                        color: 'red',
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false
            },{ // Secondary yAxis
                ordinal: false,
                showLastLabel : true,
                allowDecimals: true,
                min : 1,
                max : 4,
                labels: {
                    x: 5,
                    y: 5,
                    format: '{value:.0f}',
                    formatter: function() {
                        return translate.instant(labels_herb[this.value - 1]);
                    },
                    style: {
                        color: 'green',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 45,
                    useHTML:true,
                    text: '<p>' + translate.instant('erbacea') + '</p>',
                    style: {
                        color: 'green',
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: true
            }

            ],

            loading: false

        });

    };

    if (!phenolData) return;

    initChart();

    //setto i due oggetti per modificare i dati e le label
    var seriesArray = chart.series;

    var items = [];
    if (phenolData.data[0].timeline) {

        for (var i = 0; i < phenolData.data[0].timeline.length; i++) {

            var date = moment.utc(phenolData.data[0].timeline[i]).valueOf();

            if (!isNaN(phenolData.data[0].values[i]) && (phenolData.data[0].values[i] > -9998)) {

                items.push([date, parseFloat(phenolData.data[0].values[i])])

            }

        }
    }

    seriesArray[0].id = phenolData.data[0].type + '_arbustiva';
    seriesArray[0].setData(items);

    items = [];
    for (var i = 0; i < phenolData.data[1].timeline.length; i++) {

        var date = moment.utc(phenolData.data[1].timeline[i]).valueOf();

        if (!isNaN(phenolData.data[1].values[i]) && (phenolData.data[1].values[i] > -9998)) {

            items.push([date, parseFloat(phenolData.data[1].values[i])])

        }

    }

    seriesArray[1].id = phenolData.data[0].type + '_erbacea';
    seriesArray[1].setData(items);

    var dtMin = Math.min(moment.utc(phenolData.data[0].timeline[0]).valueOf(), moment.utc(phenolData.data[1].timeline[0]).valueOf()) - 86400000;

    var dtMax = Math.max(moment.utc(phenolData.data[0].timeline[phenolData.data[0].timeline.length - 1]).valueOf(), moment.utc(phenolData.data[1].timeline[phenolData.data[1].timeline.length - 1]).valueOf()) + 86400000;

    chart.xAxis[0].setExtremes(dtMin, dtMax);

    return {
        chart : chart
    }


}
