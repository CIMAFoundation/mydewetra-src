/**
 * Created by Dario Rubado on 13/10/2015.
 */

/**
 * Thermometer chart wrapper
 */
function showBarometerChart(sensorInfo, dtFrom, dtTo, iChartHeight, thresholdService, translate, objExtremes) {

    //var hourRange = 24;
    var chart = null;
    var rangeSelected = 2;
    var thrs_colors = ['yellow', 'orange', 'red'];
    //var plotLines = [];
    var undefPlotBands = [];

    var sensor_string = "sensorClassName_"+sensorInfo.sensor.class.toString();

    var initChart = function() {

        if (chart) chart.destroy();

        // var max = getMax(sensorInfo.obs, 40);
        // var min = getMin(sensorInfo.obs, -10);

        chart = new Highcharts.StockChart({

            chart:{
                renderTo: 'chart',
                //marginTop: 25,
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },

            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('ORE') + ' ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div><br>';

                    this.points.forEach(function(item){
                        if (item.y > -9998) {
                            s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: #FF0000">' +
                                 $('<div>' + translate.instant(sensorInfo.sensor.descr) +' = ' + item.y.toFixed(2) +' ('+sensorInfo.sensor.mu +') </div>').html() + '</div><br>';
                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            //title: {
            //    style: {
            //        fontSize: '14px',
            //        fontWeight: 'bold',
            //        fontFamily: 'Open Sans'
            //    }
            //},
            //subtitle: {
            //    style: {
            //        fontSize: '14px',
            //        fontWeight: 'bold',
            //        fontFamily: 'Open Sans'
            //    }
            //},

            series: [

                // T(mean)
                {
                    name: translate.instant(sensor_string),
                    type: 'line',
                    color: 'red',
                    threshold: null,
                    data: [],
                    showInLegend: true
                },

                // flags
                {
                    name: null,
                    type:  'scatter',   //flags',
                    shape: '',
                    data:[],
                    useHTML: true,
                    showInLegend: false
                }

            ],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                },
                sourceWidth: 1500,
                sourceHeight: 1000,

            },
            navigator: {
                series: {
                    type: 'area',
                    fillOpacity: 0.3
                },
                enabled : true

            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                ordinal: false,
                type: 'datetime',
                range:  24 * 3600 * 1000,                                    // one day
                minRange: 1 * 3600 * 1000,                                   // one hour
                tickPixelInterval: 50,
                minorTickInterval: 'auto',
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    },
                    formatter: function () {
                        var oDate = new Date(this.value);
                        if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                            return '<b>' + Highcharts.dateFormat('%d %b', this.value) + '</b>';
                        else
                            return Highcharts.dateFormat('%H:%M', this.value);
                    }

                },
                plotLines: [
                    {
                        color: 'rgba(69, 163, 202, 1)', // Color value
                        dashStyle: 'Solid',             // Style of the plot line. Default to solid
                        value: new Date().getTime(),    // Value of where the line will appear
                        width: '2',                     // Width of the line
                        zIndex: 4
                    }
                ],
                events: {

                    setExtremes: function(e) {

                        if (e.rangeSelectorButton) {

                            var c = e.rangeSelectorButton.count;

                            if (c == 3) {
                                rangeSelected = 0;
                            } else if (c == 12) {
                                rangeSelected = 1;
                            } else {
                                rangeSelected = 2;
                            }

                        //} else {
                        //    if (!chart.rangeSelector) {
                        //        var subTitle = ('Dati dal ' + moment(e.min/1000, 'X').format('DD/MM/YYYY') + ' al ' + moment(e.max/1000, 'X').format('DD/MM/YYYY'));
                        //        chart.setTitle(null, { text: subTitle });
                        //    }

                        }

                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {

                buttonTheme: { // styles for the buttons
                    width: 50,
                    fill: 'none',
                    stroke: 'none',
                    'stroke-width': 0,
                    r: 3,
                    style: {
                        fontWeight: 'bold',
                        fontSize: '12px',
                        fontFamily: 'Open Sans',
                    },
                    states: {
                        hover: {
                        },
                        select: {
                            fill: '#525052',
                            style: {
                                color: 'white'
                            }
                        }
                    }
                },

                buttons : [{
                    type : 'hour',
                    count : 3,
                    text : 'Last 3h'
                }, {
                    type : 'hour',
                    count : 12,
                    text : 'Last 12h'
                },
                    {
                        type : 'all',
                        text : 'Last 24h'
                    }],

                inputEnabled : false,
                enabled : true

            },
            yAxis: [{ // Primary yAxis
                ordinal: false,
                // min : 8000,
                //  max : 100,
                tickInterval: objExtremes.tickInterval,
                showLastLabel : true,
                allowDecimals: true,
                alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    x: 25,
                    y: 5,
                    format: '{value:.0f}',
                    style: {
                        color: 'red',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 45,
                    useHTML:true,
                    text: '<p style="color:red">' + translate.instant(sensor_string)+' ' +sensorInfo.sensor.mu +'</p>',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: true
            }
            ],
            loading: false

        });

        var orgHighchartsRangeSelectorPrototypeRender = Highcharts.RangeSelector.prototype.render;
        Highcharts.RangeSelector.prototype.render = function (min, max) {
            orgHighchartsRangeSelectorPrototypeRender.apply(this, [min, max]);

            var leftPosition = this.chart.plotLeft,
                topPosition = this.chart.plotTop - 50,
                space = 5;

            this.zoomText.attr({
                text: ''
            });

            for (var i = 0; i < this.buttons.length; i++) {
                this.buttons[i].attr({
                    x: leftPosition,
                    y: topPosition
                });
                leftPosition += this.buttons[i].width + space;
            }

        };

    };

    if (!sensorInfo) return;

    /* if (!chart) */ initChart();

    //setto i due oggetti per modificare i dati e le label
    var seriesArray = chart.series;

    // Title
    var station = sensorInfo.station;
    var sensor = sensorInfo.sensor;

    //ORG!!!
    //var chartTitle = (station.aggr_descr.munic? (station.aggr_descr.munic + ' ') : '') + '"' + station.name + '"' +
    //    (station.aggr_descr.supplier? (' (' + station.aggr_descr.supplier.toUpperCase() + ')') : '') + ' - Temperatura Aria';
    //chart.setTitle({ text : chartTitle});

    //var chartTitle = '"' + station.name + '"' + (station.aggr_descr.munic? (' (' + station.aggr_descr.munic + ')') : '') +
    //                 ' - Temperatura Aria dal ' + moment.utc(dtFrom, 'X').format('DD/MM/YYYY HH:mm') + ' al ' + moment.utc(dtTo, 'X').format('DD/MM/YYYY HH:mm');
    //chart.setTitle({ text : chartTitle});

    //// Subtitle
    //var subTitle;
    //subTitle = ('Dati dal ' + moment.utc(dtFrom, 'X').format('DD/MM/YYYY HH:mm') + ' al ' + moment.utc(dtTo, 'X').format('DD/MM/YYYY HH:mm'));
    //chart.setTitle(null, { text: subTitle });

    // Undef
    for (var i = 0; i < undefPlotBands.length; i++) {
        chart.xAxis[0].removePlotBand(undefPlotBands[i].id);
    }
    undefPlotBands = [];
    if (sensorInfo.undef) {

        for (var i = 0; i < sensorInfo.undef.length; i++) {

            var p = {
                id : 'undef_' + i,
                from : sensorInfo.undef[i].from,
                to: sensorInfo.undef[i].to,
                color : 'rgba(128,128,128,0.6)'
            };

            chart.xAxis[0].addPlotBand(p);
            undefPlotBands.push(p);

        }
    }

    // Data di inizio della timeline
    var dtmin = dtFrom * 1000;

    var values = [];

    if (sensorInfo.timeline) {
        for (var i = 0; i < sensorInfo.timeline.length; i++) {

            var date = moment.utc(sensorInfo.timeline[i]).valueOf();

            if ((date >= dtmin) && (sensorInfo.obs[i] > -9998)) {

                //alcuni valori sono per mille invece cher per cento quindi normalizzo cosi
                //if(sensorInfo.obs[i]>100) sensorInfo.obs[i]=sensorInfo.obs[i]/10;

                values.push([date, parseFloat(sensorInfo.obs[i])])

            }

        }
    }

    seriesArray[0].id = station.name + '';
    seriesArray[0].setData(values);

    chart.xAxis[0].setExtremes(dtmin, dtTo * 1000);

    return{
        chart : chart
    }

}

