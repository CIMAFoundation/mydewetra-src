/**
 * Created by pynthu on 05/11/2014.
 */

/**
 * Raingauge chart wrapper
 */
function showRaingaugeChart(sensorInfo, dtFrom, dtTo, iChartHeight, thresholdService, translate, objExtremes) {

    var chart = null;
    var rangeSelected = 2;
    var thrs_colors = ['yellow', 'orange', 'red'];
    //var plotLines = [];
    var undefPlotBands = [];
    var rainAxis = 0, cumAxis = 1, cumH =2;



    var initChart = function() {

        if (chart) chart.destroy();

        // var max = getMax(sensorInfo.obs, 50);
        // var sum = (sensorInfo.obs? sensorInfo.obs.reduce(function(pv, cv) { return (((typeof pv == 'number')? pv : parseFloat(pv)) + ((typeof cv == 'number')? cv : parseFloat(cv))); }, 0) : 0);
        // sum = getMax([sum, max], 100);


        chart = new Highcharts.StockChart({

            chart: {
                renderTo: 'chart',
                //marginTop: 25,
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },
            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('ORE') + ' ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div><br>';

                    this.points.forEach(function(item){
                        if (item.y > -9998) {
                            if (item.series.name.indexOf('thr_') < 0) {

                                s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: ' + item.series.color + '">'
                                     + $('<div>' + item.series.name + ' = ' + item.y.toFixed(2) + ' [mm]</div>').html() + '</div><br>';

                            }
                        }

                    });

                    return s;

                    //ORG!!!
                    //if (this.series.name == 'h' || this.series.name == 'cum')
                    //
                    //    return '<div style="font-weight: bold;font-size: 16px;color: #000000">h = ' + this.y.toFixed(1) + ' mm</div><br>' +
                    //           '<div style="font-weight: bold;font-size: 14px;color: #000000">' + ('Ore ' + moment.utc(this.x/1000, 'X').format('HH:mm')) + '</div>';
                    //
                    //else return '';

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            //title: {
            //    style: {
            //        fontSize: '14px',
            //        fontWeight: 'bold',
            //        fontFamily: 'Open Sans'
            //    }
            //},
            //subtitle: {
            //    style: {
            //        fontSize: '14px',
            //        fontWeight: 'bold',
            //        fontFamily: 'Open Sans'
            //    }
            //},

            series: [

                // Altezza Nativa
                {
                    name: translate.instant('ALTEZZA_PRECIPITAZIONE'),
                    type: 'area',
                    step: 'right',
                    color: 'blue',
                    threshold: null,
                    data: [],
                    yAxis: rainAxis,
                    showInLegend: true
                },
                // cumulata nativa
                {
                    name: translate.instant('PRECIPITAZIONE_CUMULATA'),
                    type: 'line',
                    threshold: null,
                    data: [],
                    yAxis: cumAxis,
                    color: 'green',
                    showInLegend: true
                },
                // Soglia BASSA
                {
                    name: 'thr_1',
                    type: 'line',
                    step: true,
                    color: 'red',
                    threshold: null,
                    data: [],
                    yAxis: cumAxis,
                    showInLegend: false
                },
                // Soglia MEDIA
                {
                    name: 'thr_2',
                    type: 'line',
                    step: true,
                    color: 'red',
                    threshold: null,
                    data: [],
                    yAxis: cumAxis,
                    showInLegend: false
                },
                // Soglia ALTA
                {
                    name: 'thr_3',
                    type: 'line',
                    step: true,
                    threshold: null,
                    data: [],
                    yAxis: cumAxis,
                    color: 'red',
                    showInLegend: false
                },
                // CUMULATA ORARIA
                {
                    name: translate.instant('CUMULATA_ORARIA'),
                    type: 'line',
                    step: 'right',
                    color: 'red',
                    threshold: null,
                    data: [],
                    yAxis: cumH,
                    showInLegend: true,
                    visible: false
                }

            ],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                },

                sourceWidth: 1500,
                sourceHeight: 1000,


            },
            navigator: {

                baseSeries: 1,
                series: {
                    type: 'area',
                    fillOpacity: 0.3
                },
                enabled : true

            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                ordinal: false,
                type: 'datetime',
                range:  24 * 3600 * 1000,                                    // one day
                minRange: 1 * 3600 * 1000,                                   // one hour
                tickPixelInterval: 50,
                minorTickInterval: 'auto',
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    },
                    formatter: function () {
                        var oDate = new Date(this.value);
                        if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                            return '<b>' + Highcharts.dateFormat('%d %b', this.value) + '</b>';
                        else
                            return Highcharts.dateFormat('%H:%M', this.value);
                    }

                },
                plotLines: [
                    {
                        color: 'rgba(69, 163, 202, 1)', // Color value
                        dashStyle: 'Solid',             // Style of the plot line. Default to solid
                        value: new Date().getTime(),    // Value of where the line will appear
                        width: '2',                     // Width of the line
                        zIndex: 4
                    }
                ],
                events: {

                    setExtremes: function(e) {

                        if (e.rangeSelectorButton) {

                            var c = e.rangeSelectorButton.count;

                            if (c == 3) {
                                rangeSelected = 0;
                            } else if (c == 12) {
                                rangeSelected = 1;
                            } else if(c == 24){
                                rangeSelected = 2;
                            }else{
                                rangeSelected = 3;
                            }

                            //} else {
                            //    if (!chart.rangeSelector) {
                            //        var subTitle = ('Dati dal ' + moment(e.min/1000, 'X').format('DD/MM/YYYY') + ' al ' + moment(e.max/1000, 'X').format('DD/MM/YYYY'));
                            //        chart.setTitle(null, { text: subTitle });
                            //    }

                        }

                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false,
                    events: {
                        legendItemClick: function(event) {


                            if (chart.series[this._i].visible){
                                if(this._i == 5){
                                    chart.yAxis[cumH].update({
                                        visible:false
                                    });
                                }else if(this._i == 0){
                                    chart.yAxis[rainAxis].update({
                                        visible:false
                                    });
                                }else if(this._i == 1){
                                    chart.yAxis[cumAxis].update({
                                        visible:false
                                    });
                                }

                            }else{

                                if(this._i == 5){
                                    chart.yAxis[cumH].update({
                                        visible:true
                                    });
                                }else if(this._i == 0){
                                    chart.yAxis[rainAxis].update({
                                        visible:true
                                    });
                                }else if(this._i == 1){
                                    chart.yAxis[cumAxis].update({
                                        visible:true
                                    });
                                }

                            }


                        }
                    }
                },
                line: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {

                buttonTheme: { // styles for the buttons
                    width: 50,
                    fill: 'none',
                    stroke: 'none',
                    'stroke-width': 0,
                    r: 3,
                    style: {
                        fontWeight: 'bold',
                        fontSize: '12px',
                        fontFamily: 'Open Sans',
                    },
                    states: {
                        hover: {
                        },
                        select: {
                            fill: '#525052',
                            style: {
                                color: 'white'
                            }
                        }
                    }
                },

                buttons : [{
                    type : 'hour',
                    count : 3,
                    text : 'Last 3h'
                }, {
                    type : 'hour',
                    count : 12,
                    text : 'Last 12h'
                },
                {
                    type : 'hour',
                    count : 24,
                    text : 'Last 24h'
                },
                {
                    type : 'all',
                    text : 'All Time Range'
                }],

                inputEnabled : false,
                enabled : true

            },
            yAxis: [{ // Primary yAxis
                ordinal: false,
                min : 0,
                max : objExtremes.max,
                tickInterval: 10,
                showLastLabel: true,
                allowDecimals: true,
                alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    format: '{value:.0f}',
                    style: {
                        color: 'blue',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    text: translate.instant('ALTEZZA_PRECIPITAZIONE') + ' [mm] ',
                    style: {
                        color: 'blue',
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false
            },
            { // Secondary y Axys
                ordinal: false,
                min : 0,
                max : objExtremes.sum,
                tickInterval: 20,
                showLastLabel : true,
                allowDecimals: true,
                //alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    format: '{value:.0f}',
                    style: {
                        color: 'green',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    text: translate.instant('PRECIPITAZIONE_CUMULATA') + ' [mm]',
                    style: {
                        color: 'green',
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                }
            }
            ,{ // cumulata oraria
                ordinal: false,
                min : 0,
                max : objExtremes.cumh,
                tickInterval: 10,
                showLastLabel: true,
                allowDecimals: true,
                alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    format: '{value:.0f}',
                    style: {
                        color: 'red',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    text: translate.instant('CUMULATA_ORARIA') + ' [mm]',
                    style: {
                        color: 'red',
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false,
                visible:false
            }
            ],

            loading: false

        });

        var orgHighchartsRangeSelectorPrototypeRender = Highcharts.RangeSelector.prototype.render;

        Highcharts.RangeSelector.prototype.render = function (min, max) {
            orgHighchartsRangeSelectorPrototypeRender.apply(this, [min, max]);

            var leftPosition = this.chart.plotLeft,
                topPosition = this.chart.plotTop - 50,
                space = 5;

            this.zoomText.attr({
                text: ''
            });

            for (var i = 0; i < this.buttons.length; i++) {
                this.buttons[i].attr({
                    x: leftPosition,
                    y: topPosition
                });
                leftPosition += this.buttons[i].width + space;
            }

        };

    };

    if (!sensorInfo) return;

    /* if (!chart) */ initChart();

    //setto i due oggetti per modificare i dati e le label
    var seriesArray = chart.series;

    // Title
    var station = sensorInfo.station;
    var sensor = sensorInfo.sensor;

    //// Title  ORG!!!
    //var chartTitle = (sensor.municipality? (sensor.municipality + ' ') : '') +
    //    '"' + sensor.stationName + '"' +
    //    (sensor.supplier? (' (' + sensor.supplier.toUpperCase() + ')') : '') + ' - Prepicitazione';
    //chart.setTitle({ text : chartTitle});


    //var chartTitle = '"' + station.name + '"' + (station.aggr_descr.munic? (' (' + station.aggr_descr.munic + ')') : '') +
    //    ' - Prepicitazione dal ' + moment.utc(dtFrom, 'X').format('DD/MM/YYYY HH:mm') + ' al ' + moment.utc(dtTo, 'X').format('DD/MM/YYYY HH:mm');
    //chart.setTitle({ text : chartTitle});

    //// Subtitle
    //var subTitle;
    //subTitle = ('Dati dal ' + moment.utc(dtFrom, 'X').format('DD/MM/YYYY HH:mm') + ' al ' + moment.utc(dtTo, 'X').format('DD/MM/YYYY HH:mm'));
    //chart.setTitle(null, { text: subTitle });

    // Undef
    for (var i = 0; i < undefPlotBands.length; i++) {
        chart.xAxis[0].removePlotBand(undefPlotBands[i].id);
    }
    undefPlotBands = [];

    if (sensorInfo.undef) {

        for (var i = 0; i < sensorInfo.undef.length; i++) {

            var p = {
                id : 'undef_' + i,
                from : sensorInfo.undef[i].from,
                to: sensorInfo.undef[i].to,
                color : 'rgba(128,128,128,0.6)'
            };

            chart.xAxis[0].addPlotBand(p);
            undefPlotBands.push(p);

        }
    }

    // Data di inizio della timeline
    var dtmin = dtFrom * 1000;

    var values = [];

    if (sensorInfo.timeline) {
        for (var i = 0; i < sensorInfo.timeline.length; i++) {

            var date = moment.utc(sensorInfo.timeline[i]).valueOf();

            if ((date >= dtmin) && (sensorInfo.obs[i] > -9998)) {

                values.push([date, parseFloat(sensorInfo.obs[i])])

            }

        }
    }

    seriesArray[0].id = station.name + '_Altezza Nativa';
    seriesArray[0].setData(values);

    var maxRainYAxis = (_.max(values,function(item){return item[1]})*1,2);

    var rainDepth = values;

    var cum = 0;
    var cumNativa = [];
    for (var i = 0; i < values.length; i++) {
        if (values[i][1] > 0) {
            cum += values[i][1];
        }
        cumNativa.push([values[i][0], cum]);
    }

    seriesArray[1].id = station.name + '_Cumulata Nativa';
    seriesArray[1].setData(cumNativa);

    var maxCumYAxis = (_.max(cumNativa,function(item){return item[1]})*1,2);

    //cumulata Oraria

    var aCumH =[]

    var aValueByTime = _.groupBy(values,function (oValue) {

        return moment(oValue[0] -1).utc().startOf('hour').format();
    })

    for (var v in aValueByTime){
        if (aValueByTime[v].length > 0){
            var cumValue = 0;
            // console.log(v);
            aValueByTime[v].forEach(function (oValue) {
                var value = parseFloat(oValue[1].toFixed(2))
                cumValue += value;
                // console.log("value: "+value)
            })
            // console.log("CUM: "+cumValue);

            aCumH.push([moment(v).add(moment.duration(60, 'minutes')).valueOf(),  cumValue]);
        }
    }
    seriesArray[5].id = station.name + '_Cumulata ORARIA';
    seriesArray[5].setData(aCumH);

    var maxCumHYAxis = (_.max(aCumH,function(item){return item[1]})*1,2);
    
    //cumulata oraria end

    chart.xAxis[0].setExtremes(dtmin, dtTo * 1000);

    return{
        chart: chart,

        reportThis:function () {


            Highcharts.getOptions().exporting.buttons.contextButton.menuItems.push({
                textKey: 'AddToReport',
                text: 'Add to Report',
                onclick: function() {
                    var $http = angular.injector(["ng"]).get("$http");

                    var options = Highcharts.getOptions();

                    options = this.options.exporting

                    var svg = chart.getSVG({
                        exporting: {
                            sourceWidth: chart.chartWidth,
                            sourceHeight: chart.chartHeight
                        }
                    })

                    var data = {
                        svg:svg ,
                        filename: 'test.png',
                        type: 'image/png',
                        async: true
                    };

                    $http.post("https://export.highcharts.com/",data )
                        .success(function(data, status, headers, config) {
                            // console.log("https://export.highcharts.com/"+data);
                            $http.post("",data )
                                .success(function(data, status, headers, config) {
                                    alert("added")
                                })
                                .error(function(data, status, headers, config) {
                                    //acError.errorOnServerRequest(data);

                                });

                        })
                        .error(function(data, status, headers, config) {
                            //acError.errorOnServerRequest(data);
                            // console.log(data);
                        });


                }
            });
        },

        toggleAltezza: function () {

            if (chart.series[0].visible) {
                chart.series[0].hide();
                chart.yAxis[0].update({
                    visible: false
                });
            } else {
                chart.series[0].show();

                chart.yAxis[0].update({
                    visible: true
                });
            }
        },

        isAltezza:function () {
            return chart.series[0].visible;
        },

        toggleCumOraria: function () {
            if (chart.series[5].visible) {
                chart.series[5].hide();
                chart.yAxis[2].update({
                    visible:false
                });
            } else {
                chart.series[5].show();

                chart.yAxis[2].update({
                    visible: true
                })
            }
        },

        isHourlyAccumulated : function () {
            return chart.series[5].visible;
        },

        maxRainYAxis:function () {
            return chart.yAxis[rainAxis].max;
        },

        maxCumYAxis:function () {
            return chart.yAxis[cumAxis].max;
        },
        maxCumHYAxis:function () {
            return chart.yAxis[cumH].max;
        },

        yAxisUpdate:function (max, sum, cumh) {

            chart.yAxis[rainAxis].update({
                max: max
            });

            chart.yAxis[cumAxis].update({
                max: sum
            });

            chart.yAxis[cumH].update({
                max: cumh
            });
        },

        rainDepth : function () {
            return rainDepth;
        }
    }

}

