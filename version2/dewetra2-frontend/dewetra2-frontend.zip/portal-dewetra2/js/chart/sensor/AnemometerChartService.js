/**
 * Created by Dario Rubado on 13/10/2015.
 */

/**
 * Thermometer chart wrapper
 */
function showAnemometerChart(sensorInfo, dtFrom, dtTo, iChartHeight, thresholdService, translate, objExtremes, serieService) {

    //var hourRange = 24;
    var chart = null;
    var rangeSelected = 2;
    var thrs_colors = ['yellow', 'orange', 'red'];
    //var plotLines = [];
    var undefPlotBands = [];

    function getWindDirection(dir) {

        if ((dir >= 11.25) && (dir < 33.75)) return 'NNE';
        else if ((dir >= 33.75) && (dir < 56.25)) return 'NE';
        else if ((dir >= 56.25) && (dir < 78.75)) return 'ENE';
        else if ((dir >= 78.75) && (dir < 101.25)) return 'E';
        else if ((dir >= 101.25) && (dir < 123.75)) return 'ESE';
        else if ((dir >= 123.75) && (dir < 146.25)) return 'SE';
        else if ((dir >= 146.25) && (dir < 168.75)) return 'SSE';
        else if ((dir >= 168.75) && (dir < 191.25)) return 'S';
        else if ((dir >= 191.25) && (dir < 213.75)) return 'SSW';
        else if ((dir >= 213.75) && (dir < 236.25)) return 'SW';
        else if ((dir >= 236.25) && (dir < 258.75)) return 'WSW';
        else if ((dir >= 258.75) && (dir < 281.25)) return 'W';
        else if ((dir >= 281.25) && (dir < 303.75)) return 'WNW';
        else if ((dir >= 303.75) && (dir < 326.25)) return 'NW';
        else if ((dir >= 326.25) && (dir < 348.75)) return 'NNW';
        else return 'N';

    }

    var initChart = function() {

        if (chart) chart.destroy();

        // var max = getMax(sensorInfo.obs, 40);
        // var min = getMin(sensorInfo.obs, -10);

        chart = new Highcharts.StockChart({

            chart:{
                renderTo: 'chart',
                //marginTop: 25,
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },

            // tooltip: {
            //     useHTML: true,
            //     crosshairs: true,
            //     shared: true,
            //     formatter: function() {
            //
            //         var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('ORE') + ' ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div><br>';
            //
            //         this.points.forEach(function(item){
            //             if (item.y > -9998) {
            //                 if (item.series.name.indexOf('WIND_speed') >= 0) {
            //
            //                     s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: #FF0000">' +
            //                          $('<div>Speed' + ' = ' + item.y.toFixed(2) +  'm/s </div>').html() + '</div><br>';
            //
            //                 }
            //             }
            //
            //         });
            //         return s;
            //     }
            // },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            //title: {
            //    style: {
            //        fontSize: '14px',
            //        fontWeight: 'bold',
            //        fontFamily: 'Open Sans'
            //    }
            //},
            //subtitle: {
            //    style: {
            //        fontSize: '14px',
            //        fontWeight: 'bold',
            //        fontFamily: 'Open Sans'
            //    }
            //},

            series: [

                // T(mean)
                {
                    name: translate.instant('WIND_SPEED'),
                    type: 'line',
                    color: 'red',
                    threshold: null,
                    data: [],
                    showInLegend: true
                },
                {
                    name: translate.instant('WIND_ANGLE'),
                    type:  'scatter',
                    color: '#0000FF',
                    // marker: {
                    //     radius: 3,
                    //     symbol: 'square'
                    // },
                    data:[],
                    // useHTML: true,
                    showInLegend: true
                },
                // {
                //     type: 'windbarb',
                //     data: [
                //         // [9.8, 177.9],
                //         // [10.1, 177.2],
                //         // [11.3, 179.7],
                //         // [10.9, 175.5],
                //         // [9.3, 159.9],
                //         // [8.8, 159.6],
                //         // [7.8, 162.6],
                //         // [5.6, 186.2],
                //         // [6.8, 146.0],
                //         // [6.4, 139.9],
                //         // [3.1, 180.2],
                //         // [4.3, 177.6],
                //         // [5.3, 191.8],
                //         // [6.3, 173.1],
                //         // [7.7, 140.2],
                //         // [8.5, 136.1],
                //         // [9.4, 142.9],
                //         // [10.0, 140.4],
                //         // [5.3, 142.1],
                //         // [3.8, 141.0],
                //         // [3.3, 116.5],
                //         // [1.5, 327.5],
                //         // [0.1, 1.1],
                //         // [1.2, 11.1]
                //     ],
                //     name: 'Wind',
                //     color: "#000",
                //     showInLegend: false,
                //     tooltip: {
                //         valueSuffix: ' m/s'
                //     }
                // }

            ],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                },
                sourceWidth: 1500,
                sourceHeight: 1000,

            },
            navigator: {
                series: {
                    type: 'area',
                    fillOpacity: 0.3
                },
                enabled : true

            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                ordinal: false,
                type: 'datetime',
                range:  24 * 3600 * 1000,                                    // one day
                minRange: 1 * 3600 * 1000,                                   // one hour
                tickPixelInterval: 50,
                minorTickInterval: 'auto',
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    },
                    formatter: function () {
                        var oDate = new Date(this.value);
                        if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                            return '<b>' + Highcharts.dateFormat('%d %b', this.value) + '</b>';
                        else
                            return Highcharts.dateFormat('%H:%M', this.value);
                    }

                },
                plotLines: [
                    {
                        color: 'rgba(69, 163, 202, 1)', // Color value
                        dashStyle: 'Solid',             // Style of the plot line. Default to solid
                        value: new Date().getTime(),    // Value of where the line will appear
                        width: '2',                     // Width of the line
                        zIndex: 4
                    }
                ],
                events: {

                    setExtremes: function(e) {

                        if (e.rangeSelectorButton) {

                            var c = e.rangeSelectorButton.count;

                            if (c == 3) {
                                rangeSelected = 0;
                            } else if (c == 12) {
                                rangeSelected = 1;
                            } else {
                                rangeSelected = 2;
                            }

                        //} else {
                        //    if (!chart.rangeSelector) {
                        //        var subTitle = ('Dati dal ' + moment(e.min/1000, 'X').format('DD/MM/YYYY') + ' al ' + moment(e.max/1000, 'X').format('DD/MM/YYYY'));
                        //        chart.setTitle(null, { text: subTitle });
                        //    }

                        }

                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false,
                    tooltip: {
                        useHTML: true,
                        crosshairs: true,
                        shared: true,
                        formatter: function() {

                            var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('ORE') + ' ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div><br>';

                            this.points.forEach(function(item){
                                if (item.y > -9998) {
                                    if (item.series.name.indexOf('WIND_SPEED') >= 0) {

                                        s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: #FF0000">' +
                                            $('<div>Speed' + ' = ' + item.y.toFixed(2) +  'm/s </div>').html() + '</div><br>';

                                    }
                                }

                            });
                            return s;
                        }
                    },
                },
                line: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                scatter: {
                    marker: {
                        enabled: true,
                        radius: 1
                    },
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    tooltip:{
                        headerFormat: '<b>{series.name}</b><br>',
                        pointFormat: translate.instant('ORE')+' {point.date}, {point.rotate} '+sensorInfo.sensor.mu
                    }
                }
            },
            rangeSelector : {

                buttonTheme: { // styles for the buttons
                    width: 50,
                    fill: 'none',
                    stroke: 'none',
                    'stroke-width': 0,
                    r: 3,
                    style: {
                        fontWeight: 'bold',
                        fontSize: '12px',
                        fontFamily: 'Open Sans',
                    },
                    states: {
                        hover: {
                        },
                        select: {
                            fill: '#525052',
                            style: {
                                color: 'white'
                            }
                        }
                    }
                },

                buttons : [{
                    type : 'hour',
                    count : 3,
                    text : 'Last 3h'
                }, {
                    type : 'hour',
                    count : 12,
                    text : 'Last 12h'
                },
                    {
                        type : 'all',
                        text : 'Last 24h'
                    }],

                inputEnabled : false,
                enabled : true

            },
            yAxis: [{ // Primary yAxis
                ordinal: false,
                min : objExtremes.min,
                max : objExtremes.max,
                // tickInterval: objExtremes.tickInterval,
                showLastLabel : true,
                allowDecimals: true,
                alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    x: 25,
                    y: 5,
                    format: '{value:.0f}',
                    style: {
                        color: 'red',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 45,
                    useHTML:true,
                    text: '<p style="color:red">' + translate.instant('WIND_SPEED') + ' [m/s]</p>',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: true
            }
            ],
            loading: false

        });

        var orgHighchartsRangeSelectorPrototypeRender = Highcharts.RangeSelector.prototype.render;
        Highcharts.RangeSelector.prototype.render = function (min, max) {
            orgHighchartsRangeSelectorPrototypeRender.apply(this, [min, max]);

            var leftPosition = this.chart.plotLeft,
                topPosition = this.chart.plotTop - 50,
                space = 5;

            this.zoomText.attr({
                text: ''
            });

            for (var i = 0; i < this.buttons.length; i++) {
                this.buttons[i].attr({
                    x: leftPosition,
                    y: topPosition
                });
                leftPosition += this.buttons[i].width + space;
            }

        };

    };

    if (!sensorInfo) return;


    if (sensorInfo.sensor.class == 10)
    {
        var featureNativeId =(sensorInfo.sensor.speed)?sensorInfo.sensor.speed.nativeid:sensorInfo.sensor.nativeid
        var dbid = (sensorInfo.sensor.speed)?sensorInfo.sensor.speed.dbid:sensorInfo.sensor.dbid
        var featureId = featureNativeId.toString()+';'+dbid.toString();
        serieService.getSeriesDirect(1,'all.sensor.windspeed',featureId,dtFrom,dtTo, function(data) {
            var speedSensorInfo = {

                station: sensorInfo.station,
                sensor : sensorInfo.sensor.speed,
                timeline : data.timeline,
                obs : data.values,
                undef: getUndefSeries(data.timeline, data.values, dtFrom, dtTo)

            };

            //setto unita di misura
            var measureUnit = data.measure;

            initChart();

            //redefine measure unit

            chart.yAxis[0].update({title: {
                rotation: 270,
                margin: 0,
                offset: 45,
                useHTML:true,
                text: '<p style="color:red">' + translate.instant('SENS_DESCR_11') + ' ' +measureUnit+' </p>',
                style: {
                    fontWeight : 'bold',
                    fontFamily: 'Open Sans'
                }
            }})

            //setto i due oggetti per modificare i dati e le label
            var seriesArray = chart.series;

            // Title
            var station = sensorInfo.station;
            var sensor = sensorInfo.sensor;


            //SPEED
            // Undef
            for (var i = 0; i < undefPlotBands.length; i++) {
                chart.xAxis[0].removePlotBand(undefPlotBands[i].id);
            }
            undefPlotBands = [];
            if (speedSensorInfo.undef) {

                for (var i = 0; i < speedSensorInfo.undef.length; i++) {

                    var p = {
                        id : 'undef_' + i,
                        from : speedSensorInfo.undef[i].from,
                        to: speedSensorInfo.undef[i].to,
                        color : 'rgba(128,128,128,0.6)'
                    };

                    chart.xAxis[0].addPlotBand(p);
                    undefPlotBands.push(p);

                }
            }

            // Data di inizio della timeline
            var dtmin = dtFrom * 1000;

            var values = [];

            if (speedSensorInfo.timeline) {
                for (var i = 0; i < speedSensorInfo.timeline.length; i++) {

                    var date = moment.utc(speedSensorInfo.timeline[i]).valueOf();

                    if ((date >= dtmin) && (speedSensorInfo.obs[i] > -9998)) {

                        values.push([date, parseFloat(speedSensorInfo.obs[i])])

                    }

                }
            }
            var speedArray = values;
            seriesArray[0].id = station.name + '_SPEED';
            seriesArray[0].setData(values);

            var max = _.max(values, function (item) {
                return item[1];
            })

            chart.yAxis[0].update({max:max[1]*1.2})

            chart.xAxis[0].setExtremes(dtmin, dtTo * 1000);

            // END SPEED

            //rotation angle

            var values = [];

            if (sensorInfo.timeline) {
                for (var i = 0; i < sensorInfo.timeline.length; i++) {

                    var date = moment.utc(sensorInfo.timeline[i]).valueOf();

                    if ((date >= dtmin) && (sensorInfo.obs[i] > -9998)) {

                        values.push({x:date, y:(max[1]*0.05), rotate :parseFloat(sensorInfo.obs[i]),
                            marker:{
                                symbol: 'url(portals/commons/img/variabili/windir_'+getWindDirection(parseFloat(sensorInfo.obs[i]))+'.svg)',
                                //symbol: 'url(apps/dewetra2/img/wind/wind_'+getWindDirection(parseFloat(sensorInfo.obs[i]))+'.svg)',
                                width:15,
                                height : 15
                            },
                            toolText:parseFloat(sensorInfo.obs[i]),
                            date: moment.utc(date, 'X').format('HH:mm')
                        });

                    }

                }
            }

            var aValues2 = [];

            
            //se ruota piu di 22 gradi rispetto al precendente uso il dato senno no
            // values.forEach(function (currValue, index, arr) {
            //
            //     if(aValues2.length >0){
            //         if(aValues2[aValues2.length -1].rotate){
            //             (Math.abs(currValue.rotate- aValues2[aValues2.length -1].rotate)> 22)?aValues2.push(currValue):null;
            //         }
            //         arr[index].rotate - arr[index-1].rotate
            //     }else {
            //         aValues2.push(currValue);
            //     }
            // });

            //li metto sulla linea della velocita del vento
            aValues2.forEach(function (currValue) {
                speedArray.forEach(function (curr, index, arr) {
                    if (curr[0] == currValue.x){
                        currValue.y = curr[1];
                    }
                })
            })



            seriesArray[1].id = station.name + 'Rotation';
            seriesArray[1].setData(values);

            // li ruoto a mano invece di scegliere limmagine
            // $.each(seriesArray[1].data,function(i,point){
            //
            //     if(!point.rotate)
            //         point.rotate = 0;
            //
            //     this.graphic.attr({
            //         rotation:point.rotate + ' Z'
            //     })
            //         // .translate(10,-10);
            //
            //
            //
            //
            //
            // });

            chart.xAxis[1].setExtremes(dtmin, dtTo * 1000);

            //rotation angle

            return{
                chart : chart
            }



        })
    }





}

