/**
 * Created by Anto on 18/12/2017
 */

/**
 * Thermometer chart wrapper
 */
function showDustsChart(chartData, iChartHeight, translate, settings) {

    var NO_DATA_VALUE = -9998;

    var chart = null;
    var sampleData = chartData.data;


    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.Chart({

            chart: {
                renderTo: 'chart',
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },

            title: {
                text: "",
                margin: 0
            },

            credits: {
                enabled: false
            },

            legend: {
                verticalAlign: 'top',
                enabled: true,
                useHTML: true
            },

            xAxis: {

                ordinal: false,
                type: 'datetime',
                min: settings.date_start,
                max: settings.date_end,
                minRange: 1 * 3600 * 1000,                                   // one hour
                minorTickInterval: 'auto',
                tickPixelInterval: 50,
                lineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: translate.instant('DATE'),
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans',
                        fontSize: '14px'
                    }
                },
                labels: {
                    rotation: 45,
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '12px'
                    }
                }

            },

            yAxis: [{ // Primary yAxis
                ordinal: false,
                min: 0,
                max: 100,
                showLastLabel : true,
                allowDecimals: true,
                labels: {
                    x: -25,
                    y: 5,
                    format: '{value:.0f}',
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '12px'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 10,
                    useHTML:true,
                    text: 'Polveri sedimentabili [mg/mq*giorno]',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans',
                        fontSize: '14px'
                    }
                }
            },
            { // Secondary yAxis
                ordinal: false,
                opposite: true,
                min: 0,
                max: 100,
                showLastLabel : true,
                allowDecimals: true,
                labels: {
                    x: 25,
                    y: 5,
                    format: '{value:.0f}',
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '12px'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 10,
                    useHTML:true,
                    text: 'Precipitazione [mm]',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans',
                        fontSize: '14px'
                    }
                }
            }],

            tooltip: {
                useHTML: true,
                shared: true,

                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: #000000"><b>Ore ' + Highcharts.dateFormat('%H:%M', this.x) + '</b></div><br>';

                    if (this.points) {

                        this.points.forEach(function(item) {
                            if (item.y > -9998) {

                                s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color:' + item.series.color + '">' +
                                    $('<div><b>' + item.series.name + '</b></div>').html() + '</div><br>';

                            }

                        });

                    } else if (this.point) {

                        s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color:' + this.point.series.color + '">' +
                            $('<div><b>' + this.point.series.name + ' = ' + this.point.y.toFixed(3) + ' mg/mq*giorno</b></div>').html() + '</div><br>';

                    }

                    return s;

                }
            },

            series: [{
                    // id: sampleData.data.type + '_' + sampleData.data.title,
                    name: 'DP1A',
                    type: 'scatter',
                    color: '#00FF00',
                    data:[],
                    useHTML: true,
                    showInLegend: true
                },
                {
                    // id: sampleData.data.type + '_' + sampleData.data.title,
                    name: 'DP1B',
                    type: 'scatter',
                    color: '#AFE01B',
                    data:[],
                    useHTML: true,
                    showInLegend: true
                },
                {
                    // id: sampleData.data.type + '_' + sampleData.data.title,
                    name: 'DP2A',
                    type: 'scatter',
                    color: '#E09B1B',
                    data:[],
                    useHTML: true,
                    showInLegend: true
                },
                {
                    // id: sampleData.data.type + '_' + sampleData.data.title,
                    name: 'DP2B',
                    type: 'scatter',
                    color: '#FF0000',
                    data:[],
                    useHTML: true,
                    showInLegend: true
                },
                {
                    name: "Precip. media",
                    type: 'scatter',
                    color: '#FF00FF',
                    yAxis: 1,
                    data: [],
                    useHTML: true,
                    showInLegend: true
                }
            ]

        });

    };

    if (!sampleData) return;

    initChart();

    var count = sampleData[0].categories.length;

    if (count > 0) {

        var p = null;
        var dt;

        // VALID
        if (chartData.isAdmin || chartData.isMaster) {

            for (var i = 0; i < count; i++) {
                dt = moment(sampleData[0].categories[i], "YYYYMMDDHHmm").valueOf();
                if (sampleData[0].values[i] > 0) {
                    if (p == null) {
                        var p = {
                            id : 'valid_' + i,
                            from : dt,
                            to: dt,
                            color : 'rgba(0,255,0,0.3)'
                        };
                    } else {
                        p.to = dt
                    }
                } else {
                    if (p != null) {
                        chart.xAxis[0].addPlotBand(p);
                        p = null;
                    }
                }
            }
            if (p != null) chart.xAxis[0].addPlotBand(p);

        }

        var vMax = Number.NEGATIVE_INFINITY, vMin = Number.POSITIVE_INFINITY;

        for (var i = 0; i < settings.thrs.length; i++) {

            if (sampleData[6+i].values[0] > vMax) vMax = sampleData[6+i].values[0];
            if (sampleData[6+i].values[0] < vMin) vMin = sampleData[6+i].values[0];

            chart.yAxis[0].addPlotLine({
                color: settings.thrs[i].color,
                dashStyle: 'Solid',
                value: sampleData[6+i].values[0],
                width: '2',
                zIndex: 4,
                label : {
                    text : settings.thrs[i].name + ' = ' + parseFloat(sampleData[6+i].values[0]).toFixed(0) + ' mg/mq*giorno'
                }
            });
        }

        // Deposimetri
        var values = [], v;
        for (var i = 1; i < 5; i++) {
            values.splice(0, values.length);
            for (var j = 0; j < count; j++) {
                dt = moment(sampleData[i].categories[j], "YYYYMMDDHHmm").valueOf();
                v = parseFloat(sampleData[i].values[j]);
                if (v != NO_DATA_VALUE) {
                    if (v > vMax) vMax = v;
                    if (v < vMin) vMin = v;
                    values.push([dt, v]);
                }
            }
            chart.series[i-1].setData(values);
        }

        var maxValue = Math.max(Math.abs(vMin), Math.abs(vMax));
        maxValue = ((maxValue == Infinity)? 100 : (Math.ceil(maxValue / 100) * 100));
        chart.yAxis[0].setExtremes(-maxValue, maxValue);


        vMax = Number.NEGATIVE_INFINITY;
        vMin = Number.POSITIVE_INFINITY;

        // Precipitazione media
        values.splice(0, values.length);
        for (var j = 0; j < count; j++) {
            dt = moment(sampleData[5].categories[j], "YYYYMMDDHHmm").valueOf();
            v = parseFloat(sampleData[5].values[j]);
            if (v != NO_DATA_VALUE) {
                if (v > vMax) vMax = v;
                if (v < vMin) vMin = v;
                values.push([dt, v]);
            }
        }
        chart.series[4].setData(values);

        maxValue = Math.max(Math.abs(vMin), Math.abs(vMax));
        maxValue = ((maxValue == Infinity)? 100 : (Math.ceil(maxValue / 100) * 100));
        chart.yAxis[1].setExtremes(0, maxValue);

        chart.xAxis[0].setExtremes(moment(sampleData[0].categories[0], "YYYYMMDDHHmm").valueOf(), moment(sampleData[0].categories[count - 1], "YYYYMMDDHHmm").valueOf(), true);

    }


    return {
        chart : chart
    }


}

