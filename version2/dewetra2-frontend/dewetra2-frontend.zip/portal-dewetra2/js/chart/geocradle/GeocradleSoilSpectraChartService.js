/**
 * Created by Anto on 02/08/2017
 */

/**
 * Thermometer chart wrapper
 */
function showSoilSpectraChart(sampleData, iChartHeight, translate, objExtremes) {

    var chart = null;

    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.Chart({

            chart: {
                renderTo: 'chart',
                alignTicks: false,
                zoomType: 'xy',
                height: iChartHeight
            },
            title: {
                text: "",
                margin: 0
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },
            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + translate.instant('WAVE_LENGTH') + ': ' + this.x + ' [nm]</div><br>';

                    this.points.forEach(function(item){
                        if (item.y > -9998) {
                            s += '<div style="font-family:\'Open Sans\', sans-serif; font-size:12px; color:' + item.color + '">' +
                                $('<div>' + item.series.name + ' = ' + item.y +  '</div>').html() + '</div><br>';                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [

                // SOIL_RESPONSE
                {
                    name: translate.instant('SOIL_RESPONSE_LABEL'),
                    type: 'line',
                    threshold: null,
                    data: [],
                    pointPadding: 0,
                    showInLegend: true
                }

            ],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                }

            },
            navigator: {
                enabled : false
            },
            scrollbar: {
                enabled: false
            },
            xAxis: {

                min : 350,
                max : 2500,
                tickInterval: 50,
                lineWidth: 2,
                gridLineWidth: 1,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: translate.instant('WAVE_LENGTH') + ' [nm]',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }

                }

            },
            plotOptions: {
                series: {
                    marker: {
                        enabled: false
                    },
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                }
            },
            rangeSelector : {
                enabled : false
            },
            yAxis: [{ // Primary yAxis
                min : 0,
                showLastLabel : true,
                allowDecimals: true,
                tickAmount: 11,
                labels: {
                    x: -5,
                    y: 5,
                    format: '{value:.1f}',
                    style: {
                        color: 'green',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: 45,
                    useHTML:true,
                    text: '<p style="color:green">' + translate.instant('SOIL_RESPONSE_LABEL') + '</p>',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false
            }],

            loading: false

        });

    };

    if (!sampleData) return;

    initChart();

    var items = [];

    for (var j = 0; j < sampleData.data.values.length; j++) {

        if (!isNaN(sampleData.data.values[j]) && (sampleData.data.values[j] > -9998)) {

            items.push([350 + j, parseFloat(sampleData.data.values[j])]);

        }

    }

    var series = chart.series[0];
    series.id = sampleData.s_id + '-' + sampleData.date + '_' + translate.instant('SOIL_RESPONSE_LABEL');
    series.setData(items);


    return {
        chart : chart
    }


}

