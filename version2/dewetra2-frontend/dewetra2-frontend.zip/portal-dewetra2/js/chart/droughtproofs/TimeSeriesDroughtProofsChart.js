/**
 * Created by Dario on 22/06/2020.
 */

/**
 * Deterministic Drought proofs chart wrapper
 */
function showTimeSeriesDroughtProofsChart(hydrogram, iChartHeight, oChartSettings, $sce,rasorService, _, $translate) {

    var chart = null;
    var thrs_colors = ['yellow', 'red'];
    var plotLines = [];




    // hydrogram.id = 'bolivia.droughtproofs.spistations';


    var label;

    var colors = [];

    var hasThreshold = true;

    switch (hydrogram.id) {
        case ('bolivia.droughtproofs.spistations'):
            label = 'SPI';
            colors = ['#000000','#808000','#008080', '#000080', '#800080'];
            break
        case ('bolivia.droughtproofs.speistations'):
            label = 'SPEI';
            colors = ['#000000','#808000','#008080', '#000080', '#800080'];
            break
        case ('bolivia.droughtproofs.lfistations'):
            label = 'LFI';
            colors = ['#000000', '#000080'];
            break
        case ('bolivia.droughtproofs.qlowstations'):
            label = 'QLOW [m3/s]';
            colors = ['#000000', '#000080'];
            hasThreshold = false;
            break
    };





    //var getQMax = function() {
    //
    //    var maxQ = -1, Qmod, Qoss;
    //    // Thresholds
    //    for (var i = 0; i < hydrogram.thresholds.length; i++) {
    //
    //        if (hydrogram.thresholds[i].value > maxQ) maxQ = hydrogram.thresholds[i].value;
    //
    //    }
    //    if ((hydrogram.area > 0) && (maxQ < 0)) maxQ = 20*Math.pow(hydrogram.area, 0.6);
    //    // Q
    //    for (var i = 0; i < hydrogram.timeline.length; i++) {
    //
    //        Qoss = parseFloat(hydrogram.values[oChartSettings.hydrogramsIndexOffset][i]);
    //        if (Qoss > maxQ) maxQ = Qoss;
    //
    //        Qmod = parseFloat(hydrogram.values[oChartSettings.hydrogramsIndexOffset + 1][i]);
    //        if (Qmod > maxQ) maxQ = Qmod;
    //
    //    }
    //
    //    return (maxQ * 1.1);
    //
    //};


    var getMax = function() {

        if(oChartSettings.yAxisExtremes.max) return oChartSettings.yAxisExtremes.max

        let aMax=[]
        if(hydrogram.values.lengh > 0){
            for(let i in hydrogram.values){
                aMax.push(_.max(hydrogram.values[i]))
            }
        }

        if(hydrogram.thresholds.length > 0 ){
            aMax.push(hydrogram.thresholds[0].value)
        }

        return _.max(aMax) *1.05;

    };


    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.StockChart({

            chart: {
                renderTo: 'chart',
                alignTicks: false,
                zoomType: 'xy',
                height : iChartHeight
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },

            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '';

                    this.points.forEach(function(item) {
                        if (item.y > -9998) {

                            s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: ' + item.series.color + '">'
                               + '<div>' + item.series.name + ' = ' + item.y.toFixed(2) +  ' [' + label+']</div>' + '</div><br>';

                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                },
                sourceWidth: 1500,
                sourceHeight: 1000,

            },
            navigator: {

                //series: {
                //    type: 'area',
                //    fillOpacity: 0.3
                //},

                enabled : false

            },
            scrollbar: {
                enabled: false
            },

            xAxis: {

                ordinal: false,
                type: 'datetime',
                min : moment.utc(hydrogram.timeline[0]).valueOf(),
                max : moment.utc(hydrogram.timeline[hydrogram.timeline.length - 1]).valueOf(),
                //range:  24 * 3600 * 1000,                                    // one day
                minRange: 1 * 3600 * 1000,                                   // one hour
                tickPixelInterval: 50,
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '14px'
                    },
                    formatter: function () {
                        var oDate = new Date(this.value);
                        if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                            return '<b>' + Highcharts.dateFormat('%m/%Y', this.value) + '</b>';
                        else
                            return Highcharts.dateFormat('%m/%Y', this.value);
                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {
                enabled : false
            },
            yAxis: [{ // Primary yAxis
                ordinal: false,

                // min : oChartSettings.yAxisExtremes.min,
                // max : getMax(),
                // min : (oChartSettings.isVolume? null : 0),
                //max : getQMax(),
                //tickInterval: oChartSettings.yAxis_tickInterval,
                showLastLabel : true,
                allowDecimals: true,
                alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    x: oChartSettings.yAxis_labels_x,
                    y: 5,
                    format: (oChartSettings.isVolume? '{value:.2f}' : '{value:.1f}'),
                    style: {
                        color: 'blue',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '14px'
                    }
                },
                title: {
                    rotation: 270,
                    margin: 0,
                    offset: (oChartSettings.yAxis_labels_x + 10),
                    useHTML:true,
                    text: label,
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: true

            }],

            loading: false

        });

    }; 

    if (!hydrogram) return;

    if (!chart) initChart(); 

    //setto i due oggetti per modificare i dati e le label
    var seriesArray = chart.series;

    chart.xAxis[0].removePlotLine('dtref');
    chart.xAxis[0].removePlotLine('now');
    chart.xAxis[0].addPlotLine(
            {
                id : 'dtref',
                value : hydrogram.dateRef,
                color : '#00C8DC',
                width : 2,
                zIndex: 5,
                label : {
                    text : 'DateRef'
                }
            });

    chart.xAxis[0].addPlotLine(
            {
                id : 'now',
                value : hydrogram.now,
                color : '#A52A2A',
                width : 2,
                zIndex: 5,
                label : {
                    text : (hydrogram.isRealTime? 'Now' : 'Now deferred')
                }
            });

    // thresholds
    for (var i = 0; i < plotLines.length; i++) {
        chart.yAxis[0].removePlotLine(plotLines[i].id);
    }
    plotLines = [];


    if(hasThreshold == true){
        if(hydrogram.feature.Q_ALLARME){
            var p = {
                id : 'thr',
                value : hydrogram.feature.Q_ALLARME,
                color : 'red',
                width : 2,
                zIndex: 4,
                label : {
                    text : $translate.instant('ALLARME'),
                }
            };

            chart.yAxis[0].addPlotLine(p);
            plotLines.push(p);
        }

        if(hydrogram.feature.Q_ALLERTA){
            var p = {
                id : 'thr',
                value : hydrogram.feature.Q_ALLERTA,
                color : 'yellow',
                width : 2,
                zIndex: 4,
                label : {
                    text : $translate.instant('ALLERTA'),
                }
            };

            chart.yAxis[0].addPlotLine(p);
            plotLines.push(p);
        }
    }







    hydrogram.values.forEach(function (serie, index) {

        let obj = {
            name: $translate.instant('chartlabel_'+label+'_'+index),
            type: 'line',
            threshold: null,
            data: [],
            //color: '#' + (0x1000000 + (Math.random()) * 0xffffff).toString(16).substr(1, 6),
            color:colors[index],
            dashStyle: 'line',
            showInLegend: true
        }

        for (let t = 0; t < hydrogram.timeline.length; t++) {

            var date = moment.utc(hydrogram.timeline[t]).valueOf();
            var val = parseFloat(serie[t]);

            switch (val) {
                case ( -9999):
                    break;
                case ( -9998):
                    obj.data.push([date, null])
                    break;
                default:
                    obj.data.push([date, val])
                    break;
            }



        }

        chart.addSeries(obj, true)
    })

    chart.redraw();






    // La prima volta imposta quelli generato dal chart
    if (!oChartSettings.yAxisExtremes.min) {

        var volExtremes = chart.yAxis[0].getExtremes();
        oChartSettings.yAxisExtremes.min = volExtremes.min;
        oChartSettings.yAxisExtremes.max = volExtremes.max;

    }

}

