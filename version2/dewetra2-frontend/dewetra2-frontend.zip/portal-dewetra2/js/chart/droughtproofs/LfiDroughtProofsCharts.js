/**
 * Created by dario on 21/04/2021.
 */


/**
 * Deterministic Hydrograms chart wrapper
 */
function showLFIDroughtProofsChart(hydrogram, iChartHeight, oChartSettings, $sce,rasorService, _, translate) {

    var chart = null;
    var thrs_colors = ['red', 'yellow'];
    var plotLines = [];





    var initChart = function() {

        if (chart) chart.destroy();

        chart = new Highcharts.StockChart({

            chart: {
                renderTo: 'chart',
                alignTicks: false,
                zoomType: 'xy',
                height : iChartHeight,
                margin: [10,100,100,100]
            },
            options: {
                global: {
                    useUTC: true
                },
                chart : {
                    backgroundColor:'rgba(255, 255, 255, 1)'
                }
            },

            tooltip: {
                useHTML: true,
                crosshairs: true,
                shared: true,
                formatter: function() {

                    var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">Ore ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div><br>';

                    this.points.forEach(function(item) {

                        if (item.y > -9998) {
                            let measureUnit = (item.series.name.indexOf('index')> -1)?'':'['+oChartSettings.unit_of_measure+']'
                            s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: ' + item.series.color + '">'
                                + '<div>' + item.series.name + ' = ' + item.y.toFixed(2) + (oChartSettings.isVolume? (' x 10<sup>6</sup>') : '')
                                 + measureUnit + '</div>' + '</div><br>';

                        }

                    });

                    return s;

                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                useHTML: true
            },

            series: [

                // Q(mod)
                // {
                //     name: oChartSettings.obs_series_name,
                //     type: 'line',
                //     color: 'blue',
                //     threshold: null,
                //     data: [],
                //     showInLegend: false,
                //     visible: false
                // },
                // // Q(oss)
                // {
                //     name: oChartSettings.ref95_series_name,
                //     type: 'line',
                //     threshold: null,
                //     data: [],
                //     color: 'black',
                //     // dashStyle: 'Dash',
                //     showInLegend: false,
                //     visible: false
                // },
                {
                    name: oChartSettings.LFI_index_series_name,
                    type: 'line',
                    threshold: null,
                    data: [],
                    color: 'green',
                    // dashStyle: 'Dash',
                    showInLegend: true,
                    // yAxis: 1,
                    lineWidth: 5
                }

            ],
            exporting: {
                chartOptions: {
                    rangeSelector: {
                        enabled: false
                    },
                    navigator: {
                        enabled: false
                    }
                },
                sourceWidth: 1500,
                sourceHeight: 1000,

            },
            navigator: {

                //series: {
                //    type: 'area',
                //    fillOpacity: 0.3
                //},

                enabled : false

            },
            scrollbar: {
                enabled: false
            },

            xAxis: {

                ordinal: false,
                type: 'datetime',
                min : moment.utc(hydrogram.timeline[0]).valueOf(),
                max : moment.utc(hydrogram.timeline[hydrogram.timeline.length - 1]).valueOf(),
                //range:  24 * 3600 * 1000,                                    // one day
                minRange: 1 * 3600 * 1000,                                   // one hour
                tickPixelInterval: 50,
                lineWidth: 2,
                gridLineWidth: 2,
                lineColor: 'black',
                title: {
                    margin: 0,
                    text: 'Time UTC',
                    style: {
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                labels: {
                    style: {
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '14px'
                    },
                    formatter: function () {
                        var oDate = new Date(this.value);
                        if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                            return '<b>' + Highcharts.dateFormat('%d %b', this.value) + '</b>';
                        else
                            return Highcharts.dateFormat('%H:%M', this.value);
                    }

                }

            },
            plotOptions: {
                series: {
                    dataGrouping: {
                        enabled: true,
                        approximation :"high"
                    },
                    animation: false
                },
                line: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                },
                area: {
                    marker: {
                        enabled: true,
                        radius: 1
                    }
                }
            },
            rangeSelector : {
                enabled : false
            },
            yAxis: [
            //     { // Primary yAxis
            //     ordinal: false,
            //
            //     // min : oChartSettings.yAxisExtremes.min,
            //     // max : getMax(),
            //     // min : (oChartSettings.isVolume? null : 0),
            //     //max : getQMax(),
            //     //tickInterval: oChartSettings.yAxis_tickInterval,
            //     showLastLabel : true,
            //     allowDecimals: true,
            //     alternateGridColor: 'rgba(0, 144, 201, 0.1)',
            //     labels: {
            //         // x: oChartSettings.yAxis_labels_x,
            //         // y: 5,
            //         format: (oChartSettings.isVolume? '{value:.2f}' : '{value:.1f}'),
            //         style: {
            //             color: 'blue',
            //             fontFamily: 'Open Sans',
            //             textTransform: 'lowercase',
            //             fontSize: '14px'
            //         }
            //     },
            //     title: {
            //         x:10,
            //         rotation: 270,
            //         margin: -20,
            //         offset: (oChartSettings.yAxis_labels_x),
            //         useHTML:true,
            //         text: oChartSettings.yAxis_title,
            //         style: {
            //             fontWeight : 'bold',
            //             fontFamily: 'Open Sans'
            //         }
            //     },
            //     opposite: true
            //
            // },
                { // Secondary yAxis
                ordinal: false,

                min : 0,
                max : 1,
                // min : (oChartSettings.isVolume? null : 0),
                //max : getQMax(),
                tickInterval: oChartSettings.yAxis2_tickInterval,
                showLastLabel : true,
                allowDecimals: true,
                alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                labels: {
                    // x: oChartSettings.yAxis2_labels_x,
                    // y: oChartSettings.yAxis2_labels_x,
                    format: '{value:.1f}',
                    style: {
                        color: 'green',
                        fontFamily: 'Open Sans',
                        textTransform: 'lowercase',
                        fontSize: '14px'
                    }
                },
                title: {
                    x: -50,
                    rotation: 270,
                    margin: 20,
                    offset: (oChartSettings.yAxis2_labels_x +10 ),
                    useHTML:true,
                    text: oChartSettings.yAxis2_title,
                    style: {
                        color: 'green',
                        fontWeight : 'bold',
                        fontFamily: 'Open Sans'
                    }
                },
                opposite: false

            }],

            loading: false

        });


        var QrefChart = chart.renderer.button(translate.instant('Q_CHARTS'), 250,10, function (){

            QrefChart.setState(2);

            showDroughtProofsChart(hydrogram, iChartHeight, oChartSettings, $sce,rasorService, _, translate)

        })
        QrefChart.add();
        QrefChart.attr({zIndex: 99999});

    };




    if (!hydrogram) return;

    if (!chart) initChart();

    //setto i due oggetti per modificare i dati e le label
    var seriesArray = chart.series;

    // chart.xAxis[0].removePlotLine('dtref');
    // chart.xAxis[0].removePlotLine('now');
    // chart.xAxis[0].addPlotLine(
    //     {
    //         id : 'dtref',
    //         value : hydrogram.dateRef,
    //         color : '#00C8DC',
    //         width : 2,
    //         zIndex: 5,
    //         label : {
    //             text : 'DateRef'
    //         }
    //     });
    //
    // chart.xAxis[0].addPlotLine(
    //     {
    //         id : 'now',
    //         value : hydrogram.now,
    //         color : '#A52A2A',
    //         width : 2,
    //         zIndex: 5,
    //         label : {
    //             text : (hydrogram.isRealTime? 'Now' : 'Now deferred')
    //         }
    //     });

    // thresholds
    for (var i = 0; i < plotLines.length; i++) {
        chart.yAxis[0].removePlotLine(plotLines[i].id);
    }
    plotLines = [];

    for (var i = 0; i < hydrogram.thresholds.length; i++) {

        if (hydrogram.thresholds[i].value > 0) {

            var p = {
                id : 'thr_' + i,
                value : (oChartSettings.isVolume? hydrogram.thresholds[i].value/1000000 : hydrogram.thresholds[i].value),
                color : thrs_colors[i],
                width : 2,
                zIndex: 4,
                label : {
                    text : translate.instant(hydrogram.thresholds[i].name)
                }
            };

            chart.yAxis[0].addPlotLine(p);
            plotLines.push(p);

        }

    }


    var date, val, values = [];
    // Q(oss)
    // for (var i = 0; i < hydrogram.timeline.length; i++) {
    //
    //     date = moment.utc(hydrogram.timeline[i]).valueOf();
    //     val = parseFloat(hydrogram.chartData[0].values[i]);
    //
    //     if (val > -9998) values.push([date, (oChartSettings.isVolume? val/1000000 : val)])
    //
    // }
    // seriesArray[0].id = hydrogram.section + '_obs';
    // seriesArray[0].setData(values);
    //
    // values = [];
    // // Q(ref)
    // for (var i = 0; i < hydrogram.timeline.length; i++) {
    //
    //     date = moment.utc(hydrogram.timeline[i]).valueOf();
    //     val = parseFloat(hydrogram.chartData[1].values[i]);
    //
    //     if (val > -9998) values.push([date, (oChartSettings.isVolume? val/1000000 : val)])
    //
    // }
    // seriesArray[1].id = hydrogram.section + '_Q(oss)';
    // seriesArray[1].setData(values);

    values = [];
    for (var i = 0; i < hydrogram.timeline.length; i++) {

        date = moment.utc(hydrogram.timeline[i]).valueOf();

        val = isNaN(hydrogram.chartData[2].values[i])?null:parseFloat(hydrogram.chartData[2].values[i]);

        val = (val <= 0)?null:val;


        values.push([date, (oChartSettings.isVolume? val/1000000 : val)])





    }
    seriesArray[0].id = hydrogram.section + '_LFI';
    seriesArray[0].setData(values);


    chart.redraw()

    // La prima volta imposta quelli generato dal chart
    // if (!oChartSettings.yAxisExtremes.min) {
    //
    //     var volExtremes = chart.yAxis[0].getExtremes();
    //     oChartSettings.yAxisExtremes.min = volExtremes.min;
    //     oChartSettings.yAxisExtremes.max = volExtremes.max;
    //
    // }

    return chart

}

