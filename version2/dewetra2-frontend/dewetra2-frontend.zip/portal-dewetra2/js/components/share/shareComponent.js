/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('share', {
        template:'<a href ng-click="$ctrl.copyToClipboard()"><i class="app-tools_share"></i></a>',
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService','$uibModal','printService',function (mapService,$uibModal,printService) {
            var $ctrl = this;


            $ctrl.closePopup = function () {
                $ctrl.close()
            }

            $ctrl.createLink = function () {
                console.log("create link triggered");
                let params = printService.getMapStateEncodedUrl(mapService, mapService.oLayerList.aDraggable, mapService.oLayerList.aUndraggable);

                console.log(params);
                return params;
            };

            $ctrl.copyToClipboard = function(){
                let selBox = document.createElement('textarea');
                selBox.style.position = 'fixed';
                selBox.style.left = '0';
                selBox.style.top = '0';
                selBox.style.opacity = '0';
                selBox.value = $ctrl.createLink();
                document.body.appendChild(selBox);
                selBox.focus();
                selBox.select();
                document.execCommand('copy');
                document.body.removeChild(selBox);
            }

            $ctrl.$onInit = function () {

            };

            $ctrl.update = function () {
                $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

