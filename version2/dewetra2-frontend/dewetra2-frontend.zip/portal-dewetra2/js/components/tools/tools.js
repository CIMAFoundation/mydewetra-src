/**
 * Created by Dario Rubado on 23/07/18.
 */
(function(){

    dewetraApp.component('tool',{
        templateUrl:'apps/dewetra2/js/components/tools/tool.html',
        bindings: {
            tool:'<'
        },
        controller: ['$uibModal', 'acUserResource', '$rootScope',function($uibModal, acUserResource, $rootScope){
            var ctrl = this;

            ctrl.$onInit = function () {

            };



            ctrl.$onChanges=function(change){

            }

        }]
    });
});

