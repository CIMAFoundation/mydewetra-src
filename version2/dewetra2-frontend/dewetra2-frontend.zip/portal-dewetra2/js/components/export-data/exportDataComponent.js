/**
 * Created by Dario Rubado on 18/06/20.
 */
(function () {

    dewetraApp.component('exportDataComponent', {
        templateUrl: 'apps/dewetra2/js/components/export-data/exportDataComponent.html',
        // template:``,
        bindings: {
            resolve: '<',
            close: '&',
            modalInstance:'<',
            dismiss: '&'
        },
        controller: ['mapService','$uibModal','$rootScope','toolsService','$timeout', function (mapService,$uibModal,$rootScope,toolsService,$timeout) {
            var $ctrl = this;

            $ctrl.$rootScope = $rootScope;

            $rootScope.$watch('pendingRequests', function(){
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });

            $ctrl.onDateStart = function  (startDate) {
                console.log("on date start selected in export data");
                $ctrl.oConfig.startDate = startDate;
            }

            $ctrl.onDateEnd = function (endDate) {
                console.log("on date end selected in export data");
                $ctrl.oConfig.endDate = endDate;
            }

            $ctrl.oConfig = {
                validator : {
                    selectedSensorType : true
                },
                config:{},
                startDate : moment.utc(new Date()).subtract(7, "days"),
                endDate : moment.utc(new Date()),
                selectedSensorType: '',
                selectedStation: {},
                selectedCumulatedRange: {},
                selectedFormat:{},
                selectedFilter:{},
                retunedFilters:{},
                stations:[],
                coordinates:{}
            }

            $ctrl.clickOnMap = function(){
                var ele = document.getElementsByClassName("exportDataComponentClass").item(0);
                ele.style.display = 'none';

                mapService.getMap().on('click', function (click) {
                    //console.log(click.latlng)
                    $ctrl.oConfig.coordinates = click.latlng;
                    ele.style.display = 'block';
                    mapService.getMap().off('click');
                    $ctrl.loadExportDataFilters();
                })
            };

            $ctrl.loadExportDataFilters = function(){
                let obj ={
                    "pt_coords": $ctrl.oConfig.coordinates,
                    "filters": $ctrl.oConfig.config.filters
                }
                console.log(obj);
                toolsService.exportDataFilters(obj, function(data){
                    $ctrl.oConfig.retunedFilters = data;
                    $ctrl.oConfig.config.filters = $ctrl.oConfig.config.filters.map(filter => {
                        return {...filter, ...data.filter(d =>  (d.id == filter.id))[0]}
                    });
                })
            }

            $ctrl.loadStations = function(){
                $ctrl.oConfig.selectedStation = {};
                toolsService.exportDataStations($ctrl.oConfig.selectedSensorType.id,data=> $ctrl.oConfig.stations = data)
            }

            $ctrl.closePopup = function () {

                $ctrl.close()
                $ctrl.resolve.params.onClose();
            }

            $ctrl.log = function(item){
                console.log(item)
            }


            $ctrl.$onChanges = function (change){

            }


            $ctrl.$onInit = function () {


                console.log("Export Data init");

                console.log($ctrl.resolve.params.modelData);

                try {
                    $ctrl.oConfig.config = JSON.parse($ctrl.resolve.params.modelData.config);
                    console.log($ctrl.oConfig.config);
                }catch (e) {
                    console.log(e);
                }



            };


            $ctrl.exportData = function(){

                console.log($ctrl.oConfig)



                if($ctrl.oConfig.selectedFilter.hasOwnProperty('descr')){
                    switch ($ctrl.oConfig.selectedFilter.descr) {
                        case('Station'):
                            $ctrl.exportDataStation();
                            break;
                        default:
                            $ctrl.exportDataGeoFiltered();
                            break;
                    }
                }


            };

            $ctrl.exportDataGeoFiltered= function(){


                let obj = {
                    "config":$ctrl.oConfig.config,

                    "time_range": {
                        "start_dt": $ctrl.oConfig.startDate.format('YYYYMMDDHHmm'),
                        "end_dt": $ctrl.oConfig.endDate.format('YYYYMMDDHHmm'),
                    },
                    "sensors": $ctrl.oConfig.selectedSensorType,

                    "filters": $ctrl.oConfig.selectedFilter,

                    "cumulated": $ctrl.oConfig.selectedCumulatedRange,

                    "format": $ctrl.oConfig.selectedFormat,

                    "geo_sel": []

                }
                toolsService.exportData(obj ,function (data) {
                    console.log(data);
                    $ctrl.downloadCSV(data);

                })
            }

            $ctrl.exportDataStation = function(){



                let obj = {
                    "config":$ctrl.oConfig.config,
                    "time_range": {
                        "start_dt": $ctrl.oConfig.startDate.format('YYYYMMDDHHmm'),
                        "end_dt": $ctrl.oConfig.endDate.format('YYYYMMDDHHmm'),
                    },
                    "sensors": $ctrl.oConfig.selectedSensorType,
                    "filters": {...$ctrl.oConfig.selectedStation, ...$ctrl.oConfig.selectedFilter},
                    "cumulated":$ctrl.oConfig.selectedCumulatedRange,
                    "format": $ctrl.oConfig.selectedFormat,
                    "geo_sel": []

                }
                toolsService.exportData(obj ,function (data) {
                    //console.log(data);
                    $ctrl.downloadCSV(data);
                })
            };

            // $ctrl.downloadCSV = function(data){
            //     let csvHeader = "data:text/csv;charset=utf-8,";
            //     let link = document.createElement("a");
            //     var encodedUri = encodeURI(csvHeader+data);
            //
            //     link.setAttribute("href", encodedUri);
            //     link.setAttribute("download", "export.csv");
            //     link.innerHTML= "Click Here to download";
            //     // document.body.appendChild(link); // Required for FF
            //
            //     link.click();
            // }

            $ctrl.downloadCSV = function(data){

                const saving = document.createElement('a');
                //saving.setAttribute('href', 'data:application/zip;base64,' + data);
                saving.setAttribute('href', data.csvUrl);
                // saving.setAttribute('download', "export.zip");
                // Append anchor to body.
                document.body.appendChild(saving);
                saving.click();
                // Remove anchor from body
                document.body.removeChild(saving);
            }

            $ctrl.selectLayer = function(layer){
                //$ctrl.onLayerSelected.apply(this)(layer.layer)
            };


            $ctrl.update = function () {
                // $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                // $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

