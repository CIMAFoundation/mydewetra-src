/**
 * Created by Dario Rubado on 18/06/20.
 */


function tool_export_data(ModelData,  $uibModal, onClose) {

    //console.log(ModelData)

    var modalInstance = $uibModal.open({

        //templateUrl:'apps/dewetra2/js/components/laminazione/laminazioneModalView.html',
        //controller:"laminazioneController",
        component: 'exportDataComponent',
        size: "lg",
        //backdrop:'static',
        backdrop:false,
        windowTopClass:'exportDataComponentClass',
        resolve: {
            params: function() {
                return {
                    modelData: ModelData,
                    onClose : onClose
                }
            }
        }
    });

    return{
        modalIstance : modalInstance
    }
}
