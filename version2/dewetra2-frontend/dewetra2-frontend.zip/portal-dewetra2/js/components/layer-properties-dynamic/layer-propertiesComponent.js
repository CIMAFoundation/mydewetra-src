/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {


    dewetraApp.component('layerPropertiesDynamic', {
        templateUrl: 'apps/dewetra2/js/components/layer-properties-dynamic/layer-propertiesComponent.html',
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['layerService', 'menuService','$translate',function (layerService, menuService, $translate) {
            var $ctrl = this;

            $ctrl.data = {}

            $ctrl.availables, $ctrl.groupedByDateRun, $ctrl.dateRun;


            $ctrl.closePopup = function () {

                $ctrl.close()
            }

            $ctrl.$onInit = function () {
                $ctrl.oManager = $ctrl.resolve.oManager;

                $ctrl.preselectSelectedEntry();

                $ctrl.loadAvailables();


            };

            $ctrl.buildDataId = function(){
                console.log($ctrl.oManager.layerObj().dataid,$ctrl.dateRun,$ctrl.variable,$ctrl.level,$ctrl.instant)


            };



            $ctrl.preselectSelectedEntry = function () {
                if(Array.isArray($ctrl.oManager.props().layerProperties.attributes)){
                    $ctrl.oManager.props().layerProperties.attributes.forEach(function (attr) {
                        if ($ctrl.islist(attr) && attr.entries) {
                            for (var i=0; i<attr.entries.length; i++) {
                                if (attr.entries[i].value == attr.selectedEntry.value) {
                                    attr.selectedEntry = attr.entries[i];
                                    break;
                                }
                            }
                        }
                    });
                }else{
                    if ($ctrl.islist($ctrl.oManager.props().layerProperties.attributes) && $ctrl.oManager.props().layerProperties.attributes.entries) {
                        for (var i=0; i<$ctrl.oManager.props().layerProperties.attributes.entries.length; i++) {
                            if ($ctrl.oManager.props().layerProperties.attributes.entries[i].value == $ctrl.oManager.props().layerProperties.attributes.selectedEntry.value) {
                                $ctrl.oManager.props().layerProperties.attributes.selectedEntry = $ctrl.oManager.props().layerProperties.attributes.entries[i];
                                break;
                            }
                        }
                    }

                }

            }

            preselectDateRun = () => {
                const item = $ctrl.oManager.item();
                //const dateRef= item.id.split(';')[1]
                const dateRun= item.id.split(';')[0]
                //console.log($ctrl.groupedByDateRun);
                $ctrl.dateRun = dateRun
            }
            preselectItem = () => {
                const item = $ctrl.oManager.item();
                const dateRef= item.id.split(';')[1]
                const dateRun= item.id.split(';')[0]

                let index = $ctrl.groupedByDateRun[dateRun].findIndex((itemGrouped)=>{
                    return itemGrouped.id == item.id;
                });

                $ctrl.data.item = $ctrl.groupedByDateRun[dateRun][index];
            }

            preselectAvailables = () => {
                const item = $ctrl.oManager.item();
                let index = $ctrl.availables.findIndex((itemAvailable)=>{
                    return itemAvailable.id == item.id;
                });
                $ctrl.data.item = $ctrl.availables[index];
            }

            $ctrl.loadAvailables = function () {
                const from = menuService.getDateFromUTCSecond();
                const to = menuService.getDateToUTCSecond();

                layerService.getLayerAvailability($ctrl.oManager.layerObj(), $ctrl.oManager.props(), from, to, function (data) {
                    $ctrl.availables = data;

                    //setto la proprieta info availability, mi serve per sapere se sono abilitate la freccia avanti e la freccio indietro
                    if($ctrl.oManager.infoAvaialability){
                        $ctrl.oManager.infoAvaialability(1, $ctrl.availables.length-1);
                    }

                    if($ctrl.haveDateRun()){
                        groupByDateRun();
                        preselectDateRun();
                        preselectItem();
                    }else{
                        preselectAvailables();
                    }


                })
            }

            $ctrl.haveDateRun = () => {
                if($ctrl.availables && $ctrl.availables.length > 0 ){
                    return ($ctrl.availables[0].id.indexOf(';') > 0);
                }
            }

            groupByDateRun = () => {
                if($ctrl.availables.length > 0){
                    $ctrl.groupedByDateRun = $ctrl.availables.reduce((accumulator, currentValue, currentIndex, array) => {
                        const dateRun = currentValue.id.split(';')[0]
                        const dateRef = currentValue.id.split(';')[1]

                        if(!accumulator[dateRun]){
                            accumulator[dateRun] = [];
                        }
                        accumulator[dateRun].push(currentValue)

                        return accumulator;

                    },{})
                }
            }

            $ctrl.isVisible = function(visibleAttr){
                if (visibleAttr == true || visibleAttr == "true") return true
                return false;
            }

            $ctrl.islist = function (attr) {
                return attr.type.toLowerCase() == 'list'
            };

            $ctrl.formatDateRun = function(data){
                return moment.unix(data/1000).utc().format('DD/MM/YYYY HH:mm')
            }
            $ctrl.formatDateRef = function(data){
                const sDateRunDateRef = data.id;
                const aDateRunDateRef = sDateRunDateRef.split(";");

                let diffDate=((parseInt(aDateRunDateRef[1]))-(parseInt(aDateRunDateRef[0])));

                if(diffDate> 0 ) {
                    diffDate = diffDate/ (1000 * 60 * 60);
                    diffDate= "(+"+parseInt(diffDate)+"h)";
                }else if(diffDate < 0){
                    diffDate= "(-"+Math.abs(diffDate) / (1000 * 60 * 60)+"h)";
                }else diffDate= "";

                return moment.unix(sDateRunDateRef.split(';')[1]/1000).utc().format('DD/MM/YYYY HH:mm ')+diffDate
            }

            $ctrl.formatDateDescription = function(data){

                if ($ctrl.oManager.customFormatDateDescription) return $ctrl.oManager.customFormatDateDescription(data);

                const sDateRunDateRef = data.id

                if(sDateRunDateRef.indexOf(";") > -1){
                    //controllo se osservazione o previsione
                    var l = $ctrl.oManager.layerObj();
                    var bLayerType = l.category == "observation";
                    //se osservazione la data di run corrisponde alla dateref e ne visualizzo solo una
                    if(bLayerType){
                        var aDateRunDateRef = sDateRunDateRef.split(";");
                        if(aDateRunDateRef.length >1 ){
                            if ((parseInt(aDateRunDateRef[0])) ==(parseInt(aDateRunDateRef[1]))){
                                return moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm')
                            }else return moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm')
                        }else return moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                        // var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                        //var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm')

                        //return sDateRun
                    }else{
                        //se previsione distinguo le due date

                        var aDateRunDateRef = sDateRunDateRef.split(";");

                        var diffDate=((parseInt(aDateRunDateRef[1]))-(parseInt(aDateRunDateRef[0])));

                        if(diffDate> 0 ) {
                            diffDate = diffDate/ (1000 * 60 * 60);
                            diffDate= "(+"+parseInt(diffDate)+"h)";
                        }else if(diffDate < 0){
                            diffDate= "(-"+Math.abs(diffDate) / (1000 * 60 * 60)+"h)";
                        }else diffDate= "";



                        var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                        var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');

                        var returnString = sDateRef + " "+" (Run:"+ sDateRun+")"+ diffDate;

                        return returnString
                    }
                    //se ha solo una data non mi pongo il problema
                }else{

                    var tsRun = parseInt(sDateRunDateRef);
                    if (!isNaN(tsRun)) return moment(new Date(tsRun)).utc().format('DD/MM/YYYY HH:mm');
                    else return moment(Date.parse(data.date)).utc().format('DD/MM/YYYY HH:mm');

                }
            };

            $ctrl.orderLayers = function (item) {

                if(item.date && moment(new Date(item.date)).isValid()) return item.id;
            }

            $ctrl.translateIt = (attr) =>{

                return $translate.instant(attr);
            }

            $ctrl.debugIt = (t)=>{
                //debugger
            }

            $ctrl.update = function () {
                // oManager.update(obj.props, obj.data, onFinish)

                $ctrl.close({$value:
                        {
                            props: $ctrl.oManager.props(),
                            data: $ctrl.data.item
                        }
                });
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

