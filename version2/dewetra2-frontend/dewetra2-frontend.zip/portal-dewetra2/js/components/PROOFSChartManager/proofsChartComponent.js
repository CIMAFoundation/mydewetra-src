/**
 * Created by Dario Rubado on 01/04/21.
 */
(function () {

    dewetraApp.component('proofsChartComponent', {
        templateUrl: 'apps/dewetra2/js/components/PROOFSChartManager/proofsChartView.html',
        // template: `
        // <div class="modal-body">
        //     <div class="row">
        //     <p>ppppp</p>
        //     </div>
        // </div>
        // `,
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['floodproofsService', '$uibModal', 'menuService', 'serieService', '$timeout', '$sce', '_' , 'rasorService', '$translate', function (floodproofsService, $uibModal, menuService, serieService, $timeout, $sce, _, rasorService, $translate)  {

            const $ctrl = this;

            console.log("proofsChartComponent");



            const chartManager = { // list of available chart manager
                'DeterministicHydrogramChart' : showDeterministicHydrogramsChart,
                'NwpGfsDeterministicHydrogramsChart':showNwpGfsDeterministicHydrogramsChart,
                'NwpGfsProbabilisticHydrogramsChart':showNwpGfsProbabilisticHydrogramsChart,
                'NwpGfsMaximumHydrogramChart' : showNwpGfsMaximumHydrogramChart,
                'FanfarDeterministicHydrogramsChart' : showFanfarDeterministicHydrogramsChart,
                'DeterministicHydrogramLevelChart' : showDeterministicHydrogramsLevelChart,
                'DeterministicLevelHydrogramChart' : showDeterministicLevelHydrogramsChart,// cf lazio
                'DeterministicVolumeHydrogramChart' : showDeterministicHydrogramsChart,
                'DeterministicLevelVolumeHydrogramChart' : showDeterministicLevelVolumeHydrogramChart,
                'MaximumHydrogramChart' : showMaximumHydrogramChart,
                'MaximumLevelHydrogramChart' : showMaximumLevelHydrogramChart,
                'MaximumFewsHydrogramChart' : showMaximumFewsHydrogramChart,
                'MaximumLevelFewsHydrogramChart' : showMaximumLevelFewsHydrogramChart,
                'MaximumVolumeHydrogramChart' : showMaximumHydrogramChart,
                'MaximumLevelVolumeHydrogramChart' : showMaximumLevelVolumeHydrogramChart,
                'ProbabilisticHydrogramChart' : showProbabilisticHydrogramChart,
                'ProbabilisticVolumeHydrogramChart' : showProbabilisticHydrogramChart,
                'TimeSeriesDroughtProofsChart' : showDroughtProofsChart, // bolivia.droughtproofs.lfistations
                'ProbabilisticDamageChart' : showProbabilisticDamageChart
            }

            const chartSettings = {

                'DeterministicHydrogramChart' : {
                    mod_series_name:"Q(mod)",
                    mod_fut_series_name:"Q(mod future)",
                    obs_series_name:"Q(obs)",
                    qmod_forecast_lami:"Q(mod Forecast Lami)",

                    // in deterministic
                    mod_det_fut_series_name:"Q(mod Forecast Lami)",
                    qmod_det_forecast_lami:"Q(mod Forecast Lami -24h)",
                    yAxis_labels_x: 30,
                    yAxis_tickInterval: 100,
                    yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
                    unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>',
                    yAxisExtremes: {
                        min : 0
                    },
                },
                'DeterministicHydrogramLevelChart' : { // FP LEVEL
                    mod_series_name:"L(mod)",
                    obs_fut_series_name:"L(mod assim)",
                    obs_series_name:"L(obs)",
                    qmod_forecast_lami:"L(mod Forecast Lami)",

                    // in deterministic
                    mod_det_fut_series_name:"Q(mod Forecast Lami)",
                    qmod_det_forecast_lami:"Q(mod Forecast Lami -24h)",
                    yAxis_labels_x: 30,
                    yAxis_tickInterval: 100,
                    yAxis_title:'<p style="color: blue">Levels [m]</p>',
                    unit_of_measure:'m',
                    yAxisExtremes: {
                        min : 0
                    },
                },
                'DeterministicLevelHydrogramChart' : { // cf LAZIO
                    mod_series_name:"L(mod)",
                    obs_fut_series_name:"L(mod assim)",
                    obs_series_name:"L(obs)",
                    qmod_forecast_lami:"L(mod Forecast Lami)",

                    // in deterministic
                    mod_det_fut_series_name:"Q(mod Forecast Lami)",
                    qmod_det_forecast_lami:"Q(mod Forecast Lami -24h)",
                    yAxis_labels_x: 30,
                    yAxis_tickInterval: 100,
                    yAxis_title:'<p style="color: blue">Levels [m]</p>',
                    unit_of_measure:'m',
                    yAxisExtremes: {
                        min : 0
                    },
                },
                'DeterministicVolumeHydrogramChart' : {
                    isVolume:true,
                    mod_series_name:"V(mod)",
                    obs_series_name:"V(obs)",
                    yAxis_labels_x: 40,
                    yAxis_title:'<p style="color: blue">V x 10<sup>6</sup> [m<sup>3</sup>]</p>',
                    unit_of_measure:'m<sup>3</sup>'
                    ,yAxisExtremes: {
                        min : 0
                    },
                },
                'DeterministicLevelVolumeHydrogramChart' : {
                    isVolume:true,
                    mod_series_name:"V(mod)",
                    obs_series_name:"V(obs)",
                    mod_fut_series_name:"V(mod future)",
                    mod_forecast_series_name:"V(mod Forecast Lami)",
                    //det
                    mod_det_fut_series_name:"V(mod forecast Lami)",
                    mod_det_forecast_series_name:"V(mod Forecast Lami -24h)",
                    y0Axis_labels_x: -5,
                    y1Axis_labels_x: 40,
                    y0Axis_title:'<p style="color: blue">L [m]</p>',
                    y1Axis_title:'<p style="color: blue">V x 10<sup>6</sup> [m<sup>3</sup>]</p>',
                    y0unit_of_measure:'m',
                    y1unit_of_measure:'m<sup>3</sup>'
                    ,yAxisExtremes: {
                        min : 0
                    },
                },
                'MaximumHydrogramChart' : {
                    envelop_series_name:"Q(env c.i. 100%)",
                    max_series_name:"Q(max)",
                    obs_series_name:"Q(obs)",
                    envelop80_series_name:"Q(env c.i. 80%)",
                    envelop50_series_name:"Q(env c.i. 50%)",
                    envelopMean_series_name:"Q(Median)",
                    yAxis_labels_x: 30,
                    yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
                    unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>',
                    yAxisExtremes: {
                        min : 0
                    },
                },
                'MaximumLevelHydrogramChart' : {
                    envelop_series_name:"H(env c.i. 100%)",
                    max_series_name:"H(max)",
                    obs_series_name:"H(obs)",
                    envelop80_series_name:"H(env c.i. 80%)",
                    envelop50_series_name:"H(env c.i. 50%)",
                    envelopMean_series_name:"H(Median)",
                    yAxis_labels_x: 30,
                    yAxis_title:'<p style="color: blue">H [m]</p>',
                    unit_of_measure:'m',
                    yAxisExtremes: {
                        min : 0
                    },
                },
                'MaximumFewsHydrogramChart' : {
                    envelop_series_name:"Q(env c.i. 100%)",
                    max_series_name:"Q(max)",
                    obs_series_name:"Q(obs)",
                    envelop80_series_name:"Q(env c.i. 80%)",
                    envelop50_series_name:"Q(env c.i. 50%)",
                    envelopMean_series_name:"Q(Median)",
                    yAxis_labels_x: 30,
                    yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
                    unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>',
                    yAxisExtremes: {
                        min : 0
                    },
                },
                'MaximumLevelFewsHydrogramChart' : {
                    envelop_series_name:"H(env c.i. 100%)",
                    max_series_name:"H(max)",
                    obs_series_name:"H(obs)",
                    envelop80_series_name:"H(env c.i. 80%)",
                    envelop50_series_name:"H(env c.i. 50%)",
                    envelopMean_series_name:"H(Median)",
                    yAxis_labels_x: 30,
                    yAxis_title:'<p style="color: blue">H [m]</p>',
                    unit_of_measure:'m',
                    yAxisExtremes: {
                        min : 0
                    },
                },
                'MaximumVolumeHydrogramChart' : {
                    isVolume:true,
                    envelop_series_name:"V(env c.i. 100%)",
                    max_series_name:"V(max)",
                    obs_series_name:"V(obs)",
                    envelop80_series_name:"V(env c.i. 80%)",
                    envelop50_series_name:"V(env c.i. 50%)",
                    envelopMean_series_name:"V(Median)",
                    yAxis_labels_x: 40,
                    yAxis_title:'<p style="color: blue">V x 10<sup>6</sup> [m<sup>3</sup>]</p>',
                    unit_of_measure:'m<sup>3</sup>',
                    yAxisExtremes: {
                        min : 0
                    },
                },
                'MaximumLevelVolumeHydrogramChart' : {
                    isVolume:true,
                    envelop_series_name:"V(env c.i. 100%)",
                    max_series_name:"V(max)",
                    obs_series_name:"V(obs)",
                    envelop80_series_name:"V(env c.i. 80%)",
                    envelop50_series_name:"V(env c.i. 50%)",
                    envelopMean_series_name:"V(Median)",
                    y0Axis_labels_x: -5,
                    y1Axis_labels_x: 40,
                    y0Axis_title:'<p style="color: blue">L [m]</p>',
                    y1Axis_title:'<p style="color: blue">V x 10<sup>6</sup> [m<sup>3</sup>]</p>',
                    y0unit_of_measure:'m',
                    y1unit_of_measure:'m<sup>3</sup>',
                    yAxisExtremes: {
                        min : 0
                    },
                },
                'ProbabilisticHydrogramChart' : {
                    max_series_name:"(Q, P[Qmax > Q])",
                    yAxis_labels_x: 5,
                    yAxis_tickInterval: 0.1,
                    yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
                    unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>',
                    yAxisExtremes: {
                        min : 0
                    },
                },

                'ProbabilisticVolumeHydrogramChart' : {
                    isVolume:true,
                    max_series_name:"(V, P[Vmax > V])",
                    yAxis_labels_x: 5,
                    yAxis_tickInterval: 0.1,
                    yAxis_title:'<p style="color: blue">V x 10<sup>6</sup> [m<sup>3</sup>]</p>',
                    unit_of_measure:'m<sup>3</sup>',
                    yAxisExtremes: {
                        min : 0
                    },
                },

                'TimeSeriesDroughtProofsChart' : {
                    obs_series_name: "Q(obs)",
                    ref95_series_name: "Q(ref Q95)",
                    LFI_index_series_name:"Low Flow Index",
                    yAxis_labels_x: 30,
                    yAxis2_labels_x: -30,
                    yAxis_tickInterval: 100,
                    yAxis2_tickInterval: 0.1,
                    yAxis_title: '<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
                    yAxis2_title: '<p >Low Flow Index</p>',
                    unit_of_measure: 'm<sup>3</sup>s<sup>-1</sup>',
                    yAxisExtremes: {
                        min: 0
                    }

                },
                'ProbabilisticDamageChart' :{
                    max_series_name:"Million $",
                    yAxis_labels_x: 5,
                    yAxis_tickInterval: 0.1,
                    yAxis_title:'Million $',
                    unit_of_measure:'Million $',
                    yAxisExtremes: {
                        min : 0
                    },
                },
                'NwpGfsMaximumHydrogramChart' : {
                    envelop_series_name:"Q(env c.i. 100%)",
                    max_series_name:"Q(max)",
                    obs_series_name:"Q(obs)",
                    envelop80_series_name:"Q(env c.i. 80%)",
                    envelop50_series_name:"Q(env c.i. 50%)",
                    envelopMean_series_name:"Q(Mean)",
                    yAxis_labels_x: 30,
                    yAxis_title:'<p style="color: blue">Q [m<sup>3</sup>s<sup>-1</sup>]</p>',
                    unit_of_measure:'m<sup>3</sup>s<sup>-1</sup>',
                    yAxisExtremes: {
                    min : 0
                    },
                },
            };

            chartSettings['NwpGfsDeterministicHydrogramsChart'] = chartSettings['DeterministicHydrogramChart'];
            chartSettings['FanfarDeterministicHydrogramsChart'] = chartSettings['DeterministicHydrogramChart'];
            chartSettings['NwpGfsProbabilisticHydrogramsChart'] = chartSettings['ProbabilisticHydrogramChart'];

            const orderChartChooser = [
                "Gauge",
                "Deterministic",
                "Probabilistic",
                "Radar",
                "Expert"
            ];

            $ctrl.aCompatibles = [];
            $ctrl.aHydrograms = [];
            $ctrl.hydrogramSelected = {};

            $ctrl.currentHydrogram = null;

            $ctrl.getSectionData = () => {
                return $ctrl.resolve.sectionData;
            };

            // {
            //     section : s.target.feature.properties,
            //     prop : layerData.prop,
            //     serverId: layerObj.server.id,
            //     serieId : layerData.prop.id,
            //     layerObj: layerObj
            // }

            $ctrl.$onInit = () => {

                console.log('PROOFSChartComponent');

                loadHydrograms();
            };

            //$timeout($ctrl.$onInit, 3000);

            $ctrl.$onChanges = () => {

                loadHydrograms();

            };


            const loadHydrograms =  (from, to) => {

                floodproofsService.compatibles($ctrl.getSectionData().serverId, $ctrl.getSectionData().serieId,  (compatibles) => {

                    if (!Array.isArray(compatibles)) compatibles = [compatibles];
                    // array of {
                    //     "categoriesLabel": "dates",
                    //         "descr": "Flood Proofs Italy Probabilistic LAMI",
                    //         "descrField": "DATI_DA",
                    //         "fidField": "DATI_DA",
                    //         "id": "italy.floodproofs.probabilisticlami",
                    //         "layer": "sections_italia_FloodPROOFS",
                    //         "measure": "MCxSEC",
                    //         "type": "MaximumHydrogramChart;ProbabilisticHydrogramChart",
                    //         "valuesLabel": "FOR"
                    // }

                    console.log(compatibles);

                    $ctrl.aCompatibles = compatibles;

                    $ctrl.aHydrograms = compatibles.flatMap(compatible => {
                        return compatible.type.split(';').map(hydrogramType => {
                            let oCompatible = {...compatible};
                            //console.log(hydrogramType);
                            oCompatible.type = hydrogramType;
                            oCompatible.disabled = false
                            return oCompatible;


                        })
                    });

                    var iHydroResponse = 0;
                    var iWorkingHydrogram = 0;

                    $ctrl.aHydrograms.map((hydrogram) => {

                        serieService.getSeriesDirect($ctrl.getSectionData().serverId, hydrogram.id, $ctrl.getSectionData().section[hydrogram.fidField], menuService.getDateFromUTCSecond(), menuService.getDateToUTCSecond(),
                             (data) => {
                                hydrogram.chartData = data;
                                hydrogram.disabled = false;
                                hydrogram.active = false;


                                // let title_tokens = data.title.split(";");
                                // hydrogram.dateRef = moment.utc(data[0].title.split(";")[3], "YYYYMMDDHHmm").valueOf()

                                iHydroResponse = iHydroResponse + 1
                                iWorkingHydrogram = iWorkingHydrogram + 1

                                 console.log('series %s', iHydroResponse);

                                if(iHydroResponse == $ctrl.aHydrograms.length) onLoadedHydrograms()

                                return hydrogram;
                            },
                             (data) => {
                                hydrogram.chartData = data;
                                hydrogram.disabled = true;
                                 hydrogram.active = false;

                                iHydroResponse = iHydroResponse + 1;

                                console.log('series %s', iHydroResponse);

                                if(iHydroResponse == $ctrl.aHydrograms.length) onLoadedHydrograms();

                                return hydrogram;
                            })
                    })


                });
            };

            const toggleChartSerie = (s) => {

                let serie = $ctrl.getSectionData().prop;

                if (s) {
                    serie = s
                }

                $ctrl.aHydrograms.map(hydrogram => {

                    hydrogram.active = ((hydrogram.type === serie.type)&&(hydrogram.id === serie.id));
                })

                $ctrl.hydrogramSelected = $ctrl.aHydrograms.filter(hydrogram =>  hydrogram.active)[0];



            }

            const onLoadedHydrograms = () => {
                console.log('Hydrogram loaded');

                const baseSerieIndex =$ctrl.aHydrograms.findIndex(hydrogram=> hydrogram.id ==$ctrl.getSectionData().serieId);
                // let i = $ctrl.aHydrograms.findIndex(hydrogram=> hydrogram.disabled ==false);
                // $ctrl.getSectionData().serieId
                // debugger
                $ctrl.hydrogramChanged($ctrl.aHydrograms[baseSerieIndex])

            };


            const loadChart = () => {

                if (!chartManager.hasOwnProperty($ctrl.hydrogramSelected.type)) {

                    alert($translate.instant('CHART_NOT_AVAILABLE'));
                    return;

                }

                let oSerieConfiguration = oSerieConfigurations[$ctrl.hydrogramSelected.id]?oSerieConfigurations[$ctrl.hydrogramSelected.id]:oSerieConfigurations["default"];

                // let hydrogramData = oSerieConfiguration[hydrogramDataConfigurationString].hydrogramDataBuilder();

                // let settings = chartSettings[$ctrl.hydrogramSelected.type];

                try {
                    $ctrl.chart = oSerieConfiguration.chartBuilder();
                }catch (e) {
                    $ctrl.chart = oSerieConfigurations["default"].chartBuilder();
                }


                // $ctrl.chart = chartManager[$ctrl.hydrogramSelected.type](hydrogramData, menuService.oChartSize.m_iFloodProofsChartHeight(), settings, $sce, rasorService, _);


            }

            $ctrl.hydrogramChanged = (hydrogram) => {
                if (hydrogram.disabled == true) return

                //$ctrl.hydrogramSelected = hydrogram,
                toggleChartSerie(hydrogram)

                loadChart();

            }

            $ctrl.orderHydrogram = function (item) {
                //ordino gli elementi nell ng repeat per l'indice che hanno nell array orderChartChooser
                let iIndex;
                orderChartChooser.forEach(function(currentValue,index,arr){
                    if(item.descr.indexOf(currentValue) > -1) iIndex = index
                })
                return iIndex;
            }

            $ctrl.closePopup = () => {
                $ctrl.close()
            };

            $ctrl.update = () => {
                $ctrl.close({$value: 'data'});
            };

            $ctrl.cancel =  () => {
                $ctrl.dismiss({$value: 'cancel'});
            };

            const getSerieConfiguration = (serie) => {
                if (oSerieConfiguration.hasOwnProperty(serie)){
                    return oSerieConfiguration[serie];
                }else return oSerieConfiguration['default'];
            }

            $ctrl.title = () => {
                if(!$ctrl.hydrogramSelected.hasOwnProperty('id')) return

                try {
                    return oSerieConfigurations[$ctrl.hydrogramSelected.id].title();
                }catch (e) {
                    return oSerieConfigurations["default"].title();
                }

            }

            $ctrl.subTitle = () => {
                if(!$ctrl.hydrogramSelected.hasOwnProperty('id')) return

                try {
                    return oSerieConfigurations[$ctrl.hydrogramSelected.id].subTitle();
                }catch (e) {
                    return oSerieConfigurations["default"].subTitle();
                }
            }

            $ctrl.getChart = () => {
                if(!$ctrl.chart) return ;

                if($ctrl.chart.hasOwnProperty('chart')){

                    return $ctrl.chart.chart;
                }else{

                    return $ctrl.chart;
                }
            }

            const oSerieConfigurations = {
                'po.fews.hydrometers': {
                    title: () => {
                        return $ctrl.getSectionData.section.NOME + ' - ' + ($ctrl.getSectionData.section.AREA ? ($ctrl.getSectionData.section.AREA + $sce.trustAsHtml('<span> km<sup>2</sup></span>') + ' - ') : '') + hydrogram.descr;
                    }
                },
                "africa.floodproofs2.nwpgfsdet": {
                    title: () => {
                        //let dateRun = ($ctrl.getSectionData().section.run && $ctrl.getSectionData().section.run != '')?' ' + $translate.instant('DATE_RUN')+ ':' + moment($ctrl.getSectionData().section.run , 'YYYYMMDDHHmm').format('LLL'):'';//"202105110000"
                        // return $ctrl.getSectionData().section.SEC_NAME + dateRun;
                        return $ctrl.getSectionData().section.SEC_NAME;
                    },
                    subTitle: () => {
                        let area = ($ctrl.getSectionData().section.AREA && $ctrl.getSectionData().section.AREA != -9999)? ' AREA: ' + $ctrl.getSectionData().section.AREA + ' Km<sup>2</sup>':'';
                        let domain = ' Domain '+ $ctrl.getSectionData().section.DOMAIN ;
                        let dateRun = ($ctrl.getSectionData().section.run && $ctrl.getSectionData().section.run != '')?' ' + $translate.instant('DATE_RUN')+ ': ' + moment($ctrl.getSectionData().section.run , 'YYYYMMDDHHmm').format('LLL'):'';//"202105110000"
                        let run = ' Run '+ $ctrl.getSectionData().section.run ;
                        return $ctrl.getSectionData().section.ADMIN_B_L1 + ' - ' +  area + ' - ' + dateRun ;
                    },
                    thresholds:() => {
                        let thrs = [];

                        // QTHR1: Medium (RP 2 years)
                        // QTHR2: High (RP 5 years)
                        // QTHR3: Severe (RP 20 years)

                        if ($ctrl.getSectionData().section.Q_THR1 && $ctrl.getSectionData().section.Q_THR1 != -9999) {
                            thrs.push({ name : 'QTHR1', value : $ctrl.getSectionData().section.Q_THR1 , color: 'yellow' })
                        }
                        if ($ctrl.getSectionData().section.Q_THR2 && $ctrl.getSectionData().section.Q_THR2 != -9999) {
                            thrs.push({ name : 'QTHR2', value : $ctrl.getSectionData().section.Q_THR2, color: 'orange' })
                        }
                        if ($ctrl.getSectionData().section.Q_THR3 && $ctrl.getSectionData().section.Q_THR3 != -9999) {
                            thrs.push({ name : 'QTHR3', value : $ctrl.getSectionData().section.Q_THR3, color: 'red' })
                        }

                        return thrs

                    },
                },
                'default': {
                    title: () => {

                        let name, section;

                        if ($ctrl.getSectionData().layerObj.hasOwnProperty('name')){
                            name = $ctrl.getSectionData().layerObj.name;
                        }else if ($ctrl.getSectionData().section.hasOwnProperty('DATI_DA')){
                            name = $ctrl.getSectionData().section.DATI_DA;
                        } else {
                            name = '';
                        }

                        if ($ctrl.getSectionData().section.hasOwnProperty('SEZIONE')){
                            section = $ctrl.getSectionData().section.SEZIONE;
                        }else if ($ctrl.getSectionData().section.hasOwnProperty('SEC_NAME')){
                            section = $ctrl.getSectionData().section.SEC_NAME;
                        } else {
                            section = '';
                        }

                        return (name + ' ' + section);

                    },
                    subTitle: () => {
                        try {
                            let title_tokens = $ctrl.hydrogramSelected.data[0].title.split(";");
                            return moment.utc(title_tokens[3], "YYYYMMDDHHmm").format('DD/MM/YYYY HH:mm');
                        }catch (e) {
                            try {
                                let area = ($ctrl.getSectionData().section.AREA && $ctrl.getSectionData().section.AREA != -9999)? ' AREA: ' + $ctrl.getSectionData().section.AREA + ' Km<sup>2</sup>':'';
                                let domain = ' Domain '+ $ctrl.getSectionData().section.DOMAIN ;
                                let dateRun = ($ctrl.getSectionData().section.run && $ctrl.getSectionData().section.run != '')?' ' + $translate.instant('DATE_RUN')+ ': ' + moment($ctrl.getSectionData().section.run , 'YYYYMMDDHHmm').format('LLL'):'';//"202105110000"
                                let run = ' Run '+ $ctrl.getSectionData().section.run ;

                                let section = '';
                                if($ctrl.getSectionData().section.hasOwnProperty('ADMIN_B_L1')){
                                    section = $ctrl.getSectionData().section.ADMIN_B_L1;
                                }

                                return section +  area + ' - ' + dateRun ;
                            }catch (e2) {
                                return  ''
                            }
                        }
                    },
                    hydrogramDataBuilder:() => {
                        let title_tokens = [0,0,0,0]

                        try {
                             title_tokens = $ctrl.hydrogramSelected.chartData[0].title.split(";");
                        }catch (e) {
                        }

                        let thr ;
                        try {
                            thr = oSerieConfigurations[$ctrl.hydrogramSelected.id].thresholds();
                        }catch (e) {
                            thr = oSerieConfigurations["default"].thresholds();
                        }

                        let aSerieToRemoveFromTimeline = [
                            'rasor_damage'
                        ];

                        buildValues = () => {
                            if($ctrl.hydrogramSelected.chartData){

                            }

                            $ctrl.hydrogramSelected.chartData.filter((data) => {return (data.title.indexOf('discharge_simulated')> -1)}).map(d => d.values)
                        }

                        buildTimeline = () => {

                        }

                        let hydrogramData = {
                            id :$ctrl.getSectionData().prop.id,
                            feature:$ctrl.getSectionData().section.DATI_DA,
                            section : $ctrl.getSectionData().section.SEZIONE,
                            area : $ctrl.getSectionData().section.AREA,
                            basin : $ctrl.getSectionData().section.NOME_BACIN,
                            thresholds : thr,
                            section: $ctrl.getSectionData().section,
                            serverId: $ctrl.getSectionData().serverId,
                            procedure : '',
                            scenario : '',
                            dateRef : moment.utc(title_tokens[3], "YYYYMMDDHHmm").valueOf(),
                            now : menuService.getDateToUTCSecond() * 1000,
                            // timeline : $ctrl.hydrogramSelected.chartData[$ctrl.hydrogramSelected.chartData.length - 1].timeline,
                            timeline : $ctrl.hydrogramSelected.chartData.filter(serie => (aSerieToRemoveFromTimeline.indexOf(serie.title) == -1))[$ctrl.hydrogramSelected.chartData.filter(serie => (aSerieToRemoveFromTimeline.indexOf(serie.title) == -1)).length - 1].timeline,
                            // for add a rasor serie the server add a the end one serie that it is not part of the chart and have no timeline.i have to exclude
                            values : $ctrl.hydrogramSelected.chartData.map(d => d.values),
                            chartData: $ctrl.hydrogramSelected.chartData,
                            isRealTime : menuService.isRealTime(),
                            yRuler:null
                        }

                        return hydrogramData;
                    },
                    thresholds:() => {
                        let thrs = [];

                        if ($ctrl.getSectionData().section.Q_ALLARME) {

                            thrs.push({ name : 'FP_THR2', value : $ctrl.getSectionData().section.Q_ALLARME })
                            thrs.push({ name : 'FP_THR1', value : $ctrl.getSectionData().section.Q_ALLERTA })

                        } else if ($ctrl.getSectionData().section.N80PERCV_M) {

                            thrs.push({ name : 'Thr1(80_PERC)', value : $ctrl.getSectionData().section.N80PERCV_M })
                            thrs.push({ name : 'Thr2(MAX_REGO)', value : $ctrl.getSectionData().section.V_MAX_REGO })

                        }

                        if ($ctrl.hydrogramSelected.type == 'DeterministicLevelHydrogramChart'){//lazio efforts
                            if($ctrl.getSectionData().section.THR1){
                                thrs.push({ name : 'THR1', value : $ctrl.getSectionData().section.THR1 })
                            }
                            if($ctrl.getSectionData().section.THR2){
                                thrs.push({ name : 'THR2', value : $ctrl.getSectionData().section.THR2 })
                            }
                            if($ctrl.getSectionData().section.THR3){
                                thrs.push({ name : 'THR3', value : $ctrl.getSectionData().section.THR3 })
                            }
                            if($ctrl.getSectionData().section.THR4){
                                thrs.push({ name : 'THR4', value : $ctrl.getSectionData().section.THR4 })
                            }

                        }

                        if($ctrl.getSectionData().section.hasOwnProperty('Q_THR1')||$ctrl.getSectionData().section.hasOwnProperty('Q_THR2')||$ctrl.getSectionData().section.hasOwnProperty('Q_THR3')){
                            if ($ctrl.getSectionData().section.Q_THR1 && $ctrl.getSectionData().section.Q_THR1 != -9999) {
                                thrs.push({ name : 'QTHR1', value : $ctrl.getSectionData().section.Q_THR1 , color: 'yellow' })
                            }
                            if ($ctrl.getSectionData().section.Q_THR2 && $ctrl.getSectionData().section.Q_THR2 != -9999) {
                                thrs.push({ name : 'QTHR2', value : $ctrl.getSectionData().section.Q_THR2, color: 'orange' })
                            }
                            if ($ctrl.getSectionData().section.Q_THR3 && $ctrl.getSectionData().section.Q_THR3 != -9999) {
                                thrs.push({ name : 'QTHR3', value : $ctrl.getSectionData().section.Q_THR3, color: 'red' })
                            }
                        }



                        return thrs

                    },
                    chartBuilder: () => {

                        let hydrogramData = oSerieConfigurations["default"].hydrogramDataBuilder();

                        let settings = chartSettings[$ctrl.hydrogramSelected.type]; // TimeSeriesDroughtProofsChart

                        try {
                            settings.hydrogramsIndexOffset = 0;
                        }catch (e) {

                        }


                        return chartManager[$ctrl.hydrogramSelected.type](hydrogramData, menuService.oChartSize.m_iFloodProofsChartComponentHeight(), settings, $sce, rasorService, _, $translate);
                    }

                },
                'fanfar.volta.insitu':{},
                'fanfar.volta.noinsitu':{},
                'fanfar.insitu':{
                    title: () => {

                        let name = '', dati_da = '', sec_name = '';

                        if ($ctrl.getSectionData().layerObj.hasOwnProperty('name')){
                            name = $ctrl.getSectionData().layerObj.name;
                        }
                        if ($ctrl.getSectionData().section.hasOwnProperty('DATI_DA')){
                            dati_da = $ctrl.getSectionData().section.DATI_DA;
                        }
                        if ($ctrl.getSectionData().section.hasOwnProperty('DATI_DA')){
                            sec_name = $ctrl.getSectionData().section.SEC_NAME;
                        }

                        return (name + ' - ' + dati_da + ' - ' + sec_name);

                    },
                    subTitle: () => {
                        try {
                            let title_tokens = $ctrl.hydrogramSelected.chartData[0].title.split(";");

                            let run = moment.utc(title_tokens[3], "YYYYMMDDHHmm").format('DD/MM/YYYY HH:mm');

                            let area = ($ctrl.getSectionData().section.AREA && $ctrl.getSectionData().section.AREA != -9999)? ' AREA: ' + $ctrl.getSectionData().section.AREA :'';

                            let dateRun = ($ctrl.getSectionData().section.run && $ctrl.getSectionData().section.run != '')?' ' + $translate.instant('DATE_RUN')+ ': ' + moment($ctrl.getSectionData().section.run , 'YYYYMMDDHHmm').format('LLL'):'';//"202105110000"

                            //return  area + ' - ' + (run)?run:dateRun;
                            return  (area + ' - ' + run);

                        }catch (e) {
                            console.log(e);
                        }
                    }
                },
                'fanfar.noinsitu':{},
                'guyana.floodproofs2.probabilistic':{},
                'guyana.floodproofs2.deterministic':{},
                'mozambique.floodproofs2.probabilistic':{},
                'mozambique.floodproofs2.nwpgfsdet':{},
                'burundi.floodproofs2.nwpgfsdet':{},
                'burundi.floodproofs2.probabilistic':{},
                'volta.floodproofs2.nwpgfsdet':{},
                'volta.floodproofs2.probabilistic':{},
                'africa.floodproofs2.nwpgfsprob':{}

            }
            oSerieConfigurations["fanfar.volta.insitu"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["fanfar.volta.noinsitu"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["fanfar.insitu"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["fanfar.noinsitu"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["fanfar.noinsitu"].title = oSerieConfigurations["fanfar.insitu"].title;
            oSerieConfigurations["fanfar.noinsitu"].subTitle = oSerieConfigurations["fanfar.insitu"].subTitle;
            //AUC PRODUCTS have a different configuration.
            oSerieConfigurations["guyana.floodproofs2.deterministic"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["guyana.floodproofs2.probabilistic"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["mozambique.floodproofs2.probabilistic"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["mozambique.floodproofs2.nwpgfsdet"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["burundi.floodproofs2.probabilistic"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["burundi.floodproofs2.nwpgfsdet"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["volta.floodproofs2.probabilistic"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["volta.floodproofs2.nwpgfsdet"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;
            oSerieConfigurations["africa.floodproofs2.nwpgfsprob"].thresholds = oSerieConfigurations["africa.floodproofs2.nwpgfsdet"].thresholds;


        }]
    });

})();

