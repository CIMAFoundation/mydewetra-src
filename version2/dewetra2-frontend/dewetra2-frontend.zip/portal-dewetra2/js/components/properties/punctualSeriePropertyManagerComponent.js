/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('punctualSeriePropertyManagerComponent', {
        //templateUrl: 'apps/dewetra2/js/components/punctual-serie-chart-manager/punctualSerieChartComponent.html',
        //template:' <i class="i-tools_info"></i>',
        template:` 
                   <div class="flex-container">
                        <div ng-repeat="attribute in $ctrl.oConfig.filteredAttributes " class="flex-item">
                            <label translate>{{attribute.descr}}</label>
                            <punctual-serie-property-component attribute="attribute" selected="attribute.selectedEntry" attribute-updated="$ctrl.attributeUpdated"></punctual-serie-property-component>
                        </div>                      
                   </div>`,
        bindings: {
            manager:'<',
            attributesToSelect:'<',
            attributeChanged: '&',
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService','$rootScope', '$translate',function (mapService,$rootScope, $translate) {
            var $ctrl = this;

            $ctrl.$rootScope = $rootScope;


            $ctrl.oConfig = {
                oManager: null,
                attributes: null,
                filteredAttributes : null
            };

            $ctrl.filterAttribute = (attributes) => {

                attributes = attributes.filter(attr =>{
                    return ($ctrl.attributesToSelect.indexOf(attr.descr.toUpperCase().trim().replace(/ /g, "_")) >-1)
                })

                return attributes;
            }

            $ctrl.attributeUpdated = (attributeFromSubComponent, selectedEntryFromSubcomponent) => {
                let attributeChanged =  false;
                $ctrl.oConfig.props.layerProperties.attributes.map((attr)=>{
                    if(attr.descr ==  attributeFromSubComponent.descr ){
                        if(attr.selectedEntry.descr != selectedEntryFromSubcomponent.descr){
                            attr.selectedEntry =  selectedEntryFromSubcomponent;
                            attributeChanged = true;
                        }

                    }
                });

                if(attributeChanged) $ctrl.attributeChanged.apply(this)($ctrl.oConfig.props)
            }

            $ctrl.translateIt = (item) => {

                return $translate.instant(item);
            }



            $ctrl.closePopup = function () {
                $ctrl.close()
            }

            $ctrl.$onChanges = function (changes) {
                console.log("punctualSeriePropertyManagerComponent");

                if(changes && changes.hasOwnProperty('manager') && changes.manager.hasOwnProperty('currentValue') && changes.manager.currentValue != null){
                    $ctrl.oConfig.oManager = changes.manager.currentValue
                    $ctrl.oConfig.props = Object.assign([], $ctrl.oConfig.oManager.props());
                    $ctrl.oConfig.attributes = Object.assign([], $ctrl.oConfig.oManager.props().layerProperties.attributes);
                    $ctrl.oConfig.filteredAttributes = $ctrl.filterAttribute($ctrl.oConfig.attributes)
                }

            };


            $ctrl.$onInit = function () {
                console.log("punctualSeriePropertyManagerComponent");

            };

            $ctrl.update = function () {
                $ctrl.close({$value: 'id'});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

