/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('punctualSeriePropertyComponent', {
        //templateUrl: 'apps/dewetra2/js/components/punctual-serie-chart-manager/punctualSerieChartComponent.html',
        //template:' <i class="i-tools_info"></i>',
        template:` 
                   <div class="flex-container">
                        <div class="flex-item">
                            <ui-select style=""                                                                  
                                   ng-model="$ctrl.oConfig.selectedEntry"
                                   on-select="$ctrl.toggleEntry($item, $model)"
                                   on-remove="$ctrl.toggleEntry($item, $model)"
                                   close-on-select="true" >
                            
                                <ui-select-match class="dummy" placeholder="{{'VARIABLE' | translate}}">{{$ctrl.translateIt($select.selected.descr)}}</ui-select-match>
                                <ui-select-choices class="dummy" repeat="entry in $ctrl.attribute.entries " position='right'>
                                    <span style="color: whitesmoke" ng-bind-html="''+$ctrl.translateIt(entry.descr)" class="ellipsis"></span>
                                </ui-select-choices>
                            </ui-select>
                        </div>                      
                   </div>`,
        bindings: {
            attribute: '<',
            selected: '<',
            attributeUpdated:'&',
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService','$rootScope', '$translate',function (mapService,$rootScope, $translate) {
            var $ctrl = this;

            $ctrl.$rootScope = $rootScope;

            $ctrl.oConfig = {

            };

            $ctrl.toggleEntry = (item, model) => {
                $ctrl.oConfig.selectedEntry = item;
                $ctrl.attributeUpdated.apply(this)($ctrl.oConfig.attribute, $ctrl.oConfig.selectedEntry)
            }

            $ctrl.translateIt = (item) => {

                return $translate.instant(item);
            }

            $ctrl.translateTest = (item) => {

                return $translate.instant(item);
            }


            $ctrl.closePopup = function () {
                $ctrl.close()
            }

            $ctrl.$onChanges= function () {
                console.log("punctualSeriePropertyManagerComponent");
                $ctrl.oConfig = {
                    selectedEntry: $ctrl.selected,
                    attribute: $ctrl.attribute,
                    entries: $ctrl.attribute.entries
                };
            };

            $ctrl.$onInit = function () {
                console.log("punctualSeriePropertyManagerComponent");
            };

            $ctrl.update = function () {
                $ctrl.close({$value: 'id'});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

