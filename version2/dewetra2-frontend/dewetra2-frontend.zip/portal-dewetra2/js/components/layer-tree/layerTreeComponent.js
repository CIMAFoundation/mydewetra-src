/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('layerTreeComponent', {
        templateUrl: 'apps/dewetra2/js/components/layer-tree/layerTreeView.html',
        // template:' <ui-tree></ui-tree>',
        bindings: {
            folderView:'<',
            resolve: '<',
            close: '&',
            onLayerSelected:'&'

        },
        controller: ['mapService','$uibModal','$rootScope', function (mapService,$uibModal,$rootScope) {
            var $ctrl = this;

            $ctrl.$rootScope = $rootScope;
            $ctrl.oConfig ={
                bGeoFilter:true
            }

            $ctrl.geoFilter = function(){
                return ($ctrl.oConfig.bGeoFilter)?mapService.getBounds():null;
            }

            $ctrl.closePopup = function () {

                $ctrl.close()
            }

            $ctrl.log = function(item){
                console.log(item)
            }

            $ctrl.layerIcon = function(obj){
                if(obj && obj.icon) return obj.icon

                if(obj && obj.layer && obj.layer.icon) return obj.layer.icon

                return "default"

                // return (objcat /et    && obj.icon)?obj.icon:(obj.layer.icon);
            };

            $ctrl.click = function(obj){

                if(obj.id == '__LAYER__'){
                    $ctrl.selectLayer(obj)
                }else{
                    obj.opened = !obj.opened;
                }
            };

            $ctrl.$onInit = function () {

                console.log($ctrl.folderView)


            };


            $ctrl.selectLayer = function(layer){
                $ctrl.onLayerSelected.apply(this)(layer.layer)
            }


            $ctrl.update = function () {
                // $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                // $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

