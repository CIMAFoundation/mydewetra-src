/**
 * Created by Dario Rubado on 01/04/21.
 */
(function () {

    dewetraApp.component('sentinelChartComponent', {
        templateUrl: 'apps/dewetra2/js/components/SENTINELChartManager/sentinelChartView.html',
        // template: `
        // <div class="modal-body">
        //     <div class="row">
        //     <p>ppppp</p>
        //     </div>
        // </div>
        // `,
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['sentinelService', 'thresholdService', '$uibModal', 'menuService', 'serieService', '$timeout', '$sce', '_', 'rasorService', '$translate', function (sentinelService, thresholdService, $uibModal, menuService, serieService, $timeout, $sce, _, rasorService, $translate) {

            const $ctrl = this;

            $ctrl.aSensors = [];
            $ctrl.selectedStation;
            $ctrl.selectedSensor;
            $ctrl.availableSensors;

            $ctrl.chart;

            $ctrl.ddsServerId = 1;

            console.log("sentinelChartComponent");

            const chartSeries = { //default series
                2: 'all.sensor.rainfall',
                3: 'all.sensor.hydrometers',
                30: 'all.sensor.hydrometersflow',
                4: 'all.sensor.snow',
                5: 'all.sensor.thermometers',
                9: 'all.sensor.hygrometers',
                10: 'all.sensor.winddirection',
                11: 'all.sensor.windspeed',
                12: 'all.sensor.barometer',
                13: 'all.sensor.radiometer',
                // 30 : 'all.sensor.hydrometers',
                60: 'all.sensor.soilthermometers',
                90: 'all.sensor.soilmosture',
                98 : 'all.sensor.fuel_moisture',
                99: 'all.sensor.unknow',
                1002: 'all.sensor.turbinate'
            };


            $ctrl.getSensorData = () => {
                return $ctrl.resolve.sensorData;
            };

            // {
            //     section : s.target.feature.properties,
            //     prop : layerData.prop,
            //     serverId: layerObj.server.id,
            //     serieId : layerData.prop.id,
            //     layerObj: layerObj
            // }

            $ctrl.$onInit = () => {

                console.log('SENTINELChartComponent');

                loadSensors();
            };

            //$timeout($ctrl.$onInit, 3000);

            $ctrl.$onChanges = () => {

                // loadSensors();

            };

            const loadInfo = () => {

                if (window.app.url.sentinelURL != undefined) {
                    sentinelService.getSensorInfo($ctrl.getSensorData().sensorid, $ctrl.getSensorData().dbid, function (info) {
                        let ex = {
                            "sensor": {
                                "class": 3,
                                "descr": "Livello Invaso",
                                "id": 223965,
                                "mu": "cm"
                            },
                            "station": {
                                "aggr": {
                                    "catchment": 150,
                                    "district": 55,
                                    "munic": 4998,
                                    "region": 10,
                                    "topoyeti_munic": [],
                                    "wa": 152
                                },
                                "aggr_descr": {
                                    "catchment": "TEVERE",
                                    "district": "Terni",
                                    "munic": "Orvieto",
                                    "region": "Umbria",
                                    "topoyeti_munic": [],
                                    "wa": "Medio Tevere"
                                },
                                "altitude": 52,
                                "district": "UMBRIA",
                                "id": 45394,
                                "lat": 42.70333480834961,
                                "lon": 12.23194408416748,
                                "name": "CORBARA",
                                "nation": "ITA",
                                "region": "",
                                "sensors": [
                                    {
                                        "class": 3,
                                        "dbid": 2,
                                        "descr": "Livello Invaso",
                                        "id": 223965,
                                        "mu": "cm",
                                        "nativeid": 210820521
                                    },
                                    {
                                        "class": 30,
                                        "dbid": 2,
                                        "descr": "Portata Derivata",
                                        "id": 223966,
                                        "mu": "m^3/s",
                                        "nativeid": 210820522
                                    },
                                    {
                                        "class": 30,
                                        "dbid": 2,
                                        "descr": "Portata Scaricata",
                                        "id": 223967,
                                        "mu": "m^3/s",
                                        "nativeid": 210820523
                                    },
                                    {
                                        "class": 30,
                                        "dbid": 2,
                                        "descr": "Portata Adduzione",
                                        "id": 223968,
                                        "mu": "m^3/s",
                                        "nativeid": 210820524
                                    },
                                    {
                                        "class": 99,
                                        "dbid": 2,
                                        "descr": "Volume Invaso",
                                        "id": 223969,
                                        "mu": "mm3",
                                        "nativeid": 210820525
                                    }
                                ]
                            }
                        };

                        $ctrl.selectedStation = info.station;
                        $ctrl.availableSensors = info.station.sensors;
                        $ctrl.availableSensors.map(sensor => {
                            sensor.active = (info.sensor.id == sensor.id)

                        })
                        // debugger
                        // $ctrl.selectedSensor= info.sensor;

                        loadChart()
                    });
                } else {
                    //TODO in case of serie service not sentinel
                }


            };

            const loadSensors = (from, to) => {


                if ($ctrl.resolve.hasOwnProperty('ddsChartSerie')) {
                    chartSeries[$ctrl.getSensorData().sensorClass] = $ctrl.resolve.ddsChartSerie;
                }
                if ($ctrl.resolve.hasOwnProperty('ddsServerId')) {
                    $ctrl.ddsServerId = $ctrl.resolve.ddsServerId;
                }

                loadInfo();


            };

            const toggleChartSerie = (s) => {


            }

            const onLoadedSensor = () => {
                console.log('Sensor loaded');


            };


            const loadChart = () => {

                let sensorSelected = $ctrl.availableSensors.filter((sensor) => sensor.active)[0];

                let from = menuService.getDateFromUTCSecond();
                let to = menuService.getDateToUTCSecond()
                let fid = sensorSelected.nativeid + ';' + sensorSelected.dbid;

                serieService.getSeriesDirect($ctrl.ddsServerId, oSensorConfigurations[sensorSelected.class].serie, fid, from, to, function (data) {

                    let sensorInfo;

                    if (Array.isArray(data)) {
                        sensorInfo = {
                            station: $ctrl.selectedStation,
                            sensor: sensorSelected,
                            timeline: data[0].timeline,
                            obs: data[0].values,
                            undef: getUndefSeries(data[0].timeline, data[0].values, from, to),
                            series: data.map((x) => {
                                console.log(x);
                                return {
                                    timeline: x.timeline,
                                    obs: x.values,
                                    title: x.title,
                                    type: x.type,
                                    undef: getUndefSeries(x.timeline, x.values, from, to)
                                }
                            })
                        };
                    } else {
                        sensorInfo = {
                            station: $ctrl.selectedStation,
                            sensor: sensorSelected,
                            timeline: data.timeline,
                            obs: data.values,
                            undef: getUndefSeries(data.timeline, data.values, from, to)
                        };
                    }


                    $ctrl.chart = oSensorConfigurations[sensorSelected.class].manager(sensorInfo, from, to, menuService.oChartSize.m_iSensorChartHeight(), thresholdService, $translate, oSensorConfigurations[sensorSelected.class]['yAxisExtreme'](sensorInfo), serieService)
                })


            }

            $ctrl.sensorChanged = (sensorSelected) => {
                $ctrl.availableSensors.map(sensor => {
                    sensor.active = (sensorSelected.id == sensor.id)
                })
                loadChart();

            }

            $ctrl.orderSensor = function (item) {
            }

            $ctrl.closePopup = () => {
                $ctrl.close()
            };

            $ctrl.update = () => {
                $ctrl.close({$value: 'data'});
            };

            $ctrl.cancel = () => {
                $ctrl.dismiss({$value: 'cancel'});
            };


            $ctrl.title = () => {
                return $ctrl.getSensorData().stationname;
            }

            $ctrl.subTitle = () => {

            }

            $ctrl.getChart = () => {
                try {
                    if ($ctrl.chart.hasOwnProperty('chart')) {
                        return $ctrl.chart.chart;
                    } else $ctrl.chart;
                } catch (e) {
                    //non ancora inizializzato
                }

            }

            const oSensorConfigurations = {
                '0': {
                    'buildSensorInfo': () => {
                    }
                },
                '2': {
                    'manager': showRaingaugeChart,
                    'serie': 'all.sensor.rainfall'
                },
                '3': {
                    'manager': showHydrometerChart,
                    'serie': 'all.sensor.hydrometers',
                    'buildSensorInfo': () => {
                        return {
                            min: 0,
                            max: 5,
                            tickInterval: 0.5
                        }
                    }
                    ,
                    'yAxisExtreme': () => {
                        return {
                            min: 0,
                            max: 5,
                            tickInterval: 0.5
                        }
                    }
                },
                '30': {
                    'manager': showHydrometerVolumeChart,
                    'serie': 'all.sensor.hydrometersflow',
                    'yAxisExtreme': () => {
                        return {
                            min: 0,
                            max: 5,
                            tickInterval: 0.5
                        }
                    }
                },
                '4': {
                    'manager': showSnowDepthChart,
                    'serie': 'all.sensor.snow',
                },
                '5': {
                    'manager': showThermometerChart,
                    'serie': 'all.sensor.thermometer',
                },
                '9': {
                    'manager': showHygromometerChart,
                    'serie': 'all.sensor.hygrometers',
                },
                '10': {
                    'manager': showAnemometerChart,
                    'serie': 'all.sensor.winddirection',
                },
                '11': {
                    'manager': showAnemometerChart,
                    'serie': 'all.sensor.windspeed',
                },
                '12': {
                    'manager': showBarometerChart,
                    'serie': 'all.sensor.barometer',
                },
                '13': {
                    'manager': showHygromometerChart,
                    'serie': 'all.sensor.radiometer',
                },
                // 30 : {
                //                     'manager': showRaingaugeChart
                //                     },
                '60': {
                    'manager': showHygromometerChart,
                    'serie': 'all.sensor.soilthermometers',
                },
                '90': {
                    'manager': showHygromometerChart,
                    'serie': 'all.sensor.soilmosture',
                },
                '98': {
                    'manager': showFuelMoistureChart,
                    'serie': 'all.sensor.fuel_moisture',
                },
                '99': {
                    'manager': showHydrometerVolumeChart,
                    'serie': 'all.sensor.unknow',
                    'yAxisExtreme': () => {
                        return {
                            min: 0,
                            max: 5,
                            tickInterval: 0.5
                        }
                    }
                },
                // 1002 : showTurbinateChart

            }


        }]
    });

})();

