/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('punctualSerieComponent', {
        //templateUrl: 'apps/dewetra2/js/components/punctual-serie/punctualSerieComponent.html',
        // template:' <i class="i-tools_info"></i>',
        template:'<i ng-click="$ctrl.loadTool()" ng-class="{active: $ctrl.active==true}" class="fa fa-line-chart"></i>',
        bindings: {
            toolSelected:'<',
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService','$uibModal', '$timeout',function (mapService,$uibModal, $timeout) {
            var $ctrl = this;

            // console.log($ctrl)

            $ctrl.closePopup = function () {

                $ctrl.close()
            }

            $ctrl.$onInit = function () {



                $ctrl.active = false;

                $ctrl.oMap = mapService.getMap();
            };



            $ctrl.infoMarker = new L.marker(new L.LatLng(0, 0), {
                icon: L.icon({
                    iconUrl: 'apps/dewetra2/img/target.svg',
                    iconSize: [64, 64],
                    iconAnchor: [32, 32],
                    opacity: 0
                })
            });

            $ctrl.clickFn = function(e){

                if($ctrl.toolSelected &&  $ctrl.toolSelected != 'punctualserie') {
                    $ctrl.active = false;
                    $ctrl.removeMarker();
                    return
                }


                $ctrl.infoMarker.setLatLng(new L.LatLng(e.latlng.lat, e.latlng.lng))
                $ctrl.infoMarker.setOpacity(1);
                $ctrl.infoMarker.addTo($ctrl.oMap)

                if($ctrl.active){
                    $ctrl.loadModalComponentChart(e.latlng.lat, e.latlng.lng)
                }

            }

            $ctrl.loadModalComponentChart = function(lat, lon){

                var modalInstance = $uibModal.open({
                    animation: true,
                    component: 'punctualSerieChartManagerComponent',
                    windowClass : "punctualChart",
                    resolve: {
                        oLatLon: function () {
                            return {
                                lat:lat,
                                lon:lon
                            };
                        },

                    }
                });

                modalInstance.result.then(function (obj) {

                    console.log('modal-component dismissed at: ' + new Date());

                }, function () {
                    console.log('modal-component dismissed at: ' + new Date());
                });
            }

            $ctrl.addMarker = function(){

                $ctrl.oMap = mapService.getMap();

                $ctrl.changeCursor();

                $ctrl.oMap.on('click', $ctrl.clickFn);

            };

            $ctrl.removeMarker = function(){

                // $ctrl.oMap = mapService.getMap();

                $ctrl.oMap.removeLayer($ctrl.infoMarker)

                $ctrl.oMap.off('click', $ctrl.clickFn);
                $ctrl.infoMarker.setLatLng(new L.LatLng(0,0));
                $ctrl.infoMarker.setOpacity(0);
                $ctrl.oMap.removeLayer($ctrl.infoMarker)

            };

            $ctrl.changeCursor = function(){

                if (document.getElementById && (elem=document.getElementById('map')) ) {
                    if (elem.style) {
                        elem.style.cursor=$ctrl.active ? 'crosshair' : null;
                    }
                }
            }

            $ctrl.loadTool = () => {

                $ctrl.active = !$ctrl.active;

                if($ctrl.active){
                    $ctrl.addMarker()
                }else {
                    $ctrl.removeMarker()
                }
            }

            $ctrl.buildDataId = function(){

                return ({
                    dataId:$ctrl.oManager.layerObj().dataid
                })
            };

            $ctrl.update = function () {
                $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

