/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('punctualSerieInputBoxLoaderComponent', {
        //templateUrl: 'apps/dewetra2/js/components/punctual-serie-input-box/punctualSerieInputBoxComponent.html',
        template:' <i ng-click="$ctrl.activatePointer()" ng-class="{active: $ctrl.active==true}" class="fa fa-list"></i>',
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService','$uibModal',function (mapService,$uibModal) {
            var $ctrl = this;

            // console.log($ctrl)

            $ctrl.closePopup = function () {

                $ctrl.close()
            }

            $ctrl.$onInit = function () {

                $ctrl.active = false;

            };

            $ctrl.activatePointer = function(){

                $ctrl.active = !$ctrl.active;

                $ctrl.loadModalComponentChart()


            }


            $ctrl.loadModalComponentChart = function(lat, lon){

                var modalInstance = $uibModal.open({
                    animation: true,
                    component: 'punctualSerieInputBoxComponent',
                    // windowClass : "punctualChart",
                    size: 'md',
                    resolve: {
                        // oLatLon: function () {
                        //     return {
                        //         lat:lat,
                        //         lon:lon
                        //     };
                        // },

                    }
                });

                modalInstance.result.then(function (obj) {

                    console.log('modal-component dismissed at: ' + new Date());

                }, function () {
                    console.log('modal-component dismissed at: ' + new Date());
                });
            }


            $ctrl.update = function () {
                $ctrl.close({$value: ''});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });

    dewetraApp.component('punctualSerieInputBoxComponent', {
        templateUrl: 'apps/dewetra2/js/components/punctual-serie-input-box/punctualSerieInputBoxComponent.html',

        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService','$uibModal','acUserResource', '$rootScope', '$translate' ,function (mapService,$uibModal,acUserResource, $rootScope, $translate) {
            //acUserResource.getResources("widget_list", function(data)
            var $ctrl = this;

            $ctrl.oConfig = {
                points : [],
                editingIndex: 0,
                enableFields: false,
                fields: {
                    label: '',
                    lat: 0,
                    lon: 0
                },
            }

            $ctrl.$rootScope = $rootScope;

            $ctrl.closePopup = function () {

                $ctrl.close()
            }

            const sKeyResource = 'dewetra2-timeseries-selectedpoint';

            $ctrl.$onInit =  () => {
                $ctrl.loadUserResource((data)=>{

                    data = data.filter(obj => {
                        return ((obj.resource ==sKeyResource)&&(obj.user == $rootScope.acSession.user.id))
                    })[0]

                    $ctrl.oConfig.points = JSON.parse(data.value);

                    if(Array.isArray(data)) $ctrl.oConfig.points = data;
                })
            };

            $ctrl.addPoint = ( ) => {
                $ctrl.oConfig.enableFields = true;
                let point = {
                    label: $translate.instant('LABEL'),
                    lon : 0,
                    lat : 0
                }

                $ctrl.oConfig.points.push(point);
                $ctrl.oConfig.editingIndex = $ctrl.oConfig.points.length -1;
            }
            $ctrl.deletePoint = (index) => {
                $ctrl.oConfig.points.splice(index, 1);
            }
            $ctrl.editPoint = ( index) => {
                $ctrl.oConfig.enableFields = true;
                $ctrl.oConfig.editingIndex = index;

            }




            $ctrl.loadUserResource = ( callback) => {
                acUserResource.getResources('dewetra2', callback,function (data) {
                      console.log('ERROR loading lastselected points')
                    });
            }

            $ctrl.saveUserResource = () => {

                acUserResource.saveResource('dewetra2',sKeyResource,JSON.stringify($ctrl.oConfig.points),
                    function (data) {
                        console.log(data)
                        $ctrl.oConfig.enableFields = false;
                    })
            }


            $ctrl.infoMarker = new L.marker(new L.LatLng(0, 0), {
                icon: L.icon({
                    iconUrl: 'apps/dewetra2/img/target.svg',
                    iconSize: [64, 64],
                    iconAnchor: [32, 32],
                    opacity: 0
                })
            });

            $ctrl.setMarkerAndLoadPunctualSerie = function(e){


                $ctrl.addMarker(e.lat, e.lon);


                $ctrl.loadModalComponentChart(e.lat, e.lon);

            }

            $ctrl.loadModalComponentChart = function(lat, lon){

                var modalInstance = $uibModal.open({
                    animation: true,
                    component: 'punctualSerieChartManagerComponent',
                    windowClass : "punctualChart",
                    resolve: {
                        oLatLon: function () {
                            return {
                                lat:lat,
                                lon:lon
                            };
                        },

                    }
                });

                modalInstance.result.then(function (obj) {

                    $ctrl.removeMarker();
                    console.log('modal-component dismissed at: ' + new Date());

                }, function () {
                    $ctrl.removeMarker();
                    console.log('modal-component dismissed at: ' + new Date());
                });
            }

            $ctrl.addMarker = function(lat, lon){



                $ctrl.oMap = mapService.getMap();

                $ctrl.infoMarker.setLatLng(new L.LatLng(lat, lon))
                $ctrl.infoMarker.setOpacity(1);
                $ctrl.infoMarker.addTo($ctrl.oMap)

            };

            $ctrl.removeMarker = function(){

                // $ctrl.oMap = mapService.getMap();

                $ctrl.oMap.removeLayer($ctrl.infoMarker)

                $ctrl.oMap.off('click', $ctrl.clickFn);
                $ctrl.infoMarker.setLatLng(new L.LatLng(0,0));
                $ctrl.infoMarker.setOpacity(0);
                $ctrl.oMap.removeLayer($ctrl.infoMarker)

            };



            $ctrl.update = function () {

                $ctrl.close({$value: 'value'});

            };

            $ctrl.cancel = function () {

                $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

