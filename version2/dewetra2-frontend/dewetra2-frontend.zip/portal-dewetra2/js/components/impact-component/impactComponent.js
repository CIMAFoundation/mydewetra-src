/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('impactComponent', {
        templateUrl: 'apps/dewetra2/js/components/impact-component/impactComponent.html',
        // template:' <ui-tree></ui-tree>',
        bindings: {
            model:'<',
            onClose:'&',
            modelData:'<',
            // featureProperties:'<',
            // thresholdsGroup:'national_IDROMETRO',
            // sensorClass:3,
            resolve: '<',
            close: '&',

        },
        controller: ['$window','$location','$anchorScroll', '$uibModal', '$translate',  'menuService', 'serieService', 'sentinelService', 'thresholdService','_', '$timeout', '$rootScope', '$sce', 'iconService', 'apiService','toolsService', '$location', 'mapService' ,'$anchorScroll','acLogbook', 'printService',function ($window,$location,$anchorScroll, $uibModal, $translate,  menuService, serieService, sentinelService, thresholdService,_, $timeout, $rootScope, $sce, iconService, apiService,toolsService, $location, mapService ,$anchorScroll,acLogbook, printService) {

            var $ctrl = this;


            acLogbook.logActivity('Dewetra2-Scenario', 'Loaded Scenario');

            $rootScope.$watch('pendingRequests', function(){
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });

            var oMap, oFeatureLayer, oWMSLayer,oPolygon, oPost,editableLayers,drawControl,drawControlOnlyEdit;

            $ctrl.bLayerList = true;

            $ctrl.state = 0;


            /**
             * Init Map
             */
            var initMap = function () {


                oFeatureLayer = L.featureGroup();

                oWMSLayer = L.featureGroup();

                var osmBasic = L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    maxZoom: 18
                });
                // oMap = L.map('scenari',
                //     {
                //         //zoomControl:false,
                //         // scrollWheelZoom:false,
                //         //tap:false,
                //         boxZoom:false
                //     }).setView([44, 8], 13);

                oMap =  mapService.getMap();

                // console.log(oMap);

                // osmBasic.addTo(oMap);

                oFeatureLayer.addTo(oMap);

                oWMSLayer.addTo(oMap);

                //Draw
                editableLayers = new L.FeatureGroup();

                editableLayers.addTo(oMap);
                // oFeatureLayer.addLayer(editableLayers);


                var options = {
                    position: 'bottomleft',
                    draw: {
                        polygon: {
                            allowIntersection: false, // Restricts shapes to simple polygons
                            drawError: {
                                color: '#e1111b', // Color the shape will turn when intersects
                                message: '<strong>Oh snap!<strong> you can\'t draw that!' // Message that will show when intersect
                            },
                            shapeOptions: {
                                color: '#2c38f3'
                            }
                        },
                        polyline:false,
                        circle:false,
                        rectangle:false,
                        marker:false,
                    },
                    edit: {
                        featureGroup: editableLayers, //REQUIRED!!
                        remove: true
                    }
                };

                var optionsOnlyEdit = {
                    position: 'bottomleft',
                    draw: false,
                    edit: {
                        featureGroup: editableLayers, //REQUIRED!!
                        remove: true
                    }
                };

                // drawControl = new L.Control.Draw(options);
                // drawControlOnlyEdit = new L.Control.Draw(optionsOnlyEdit);

                // drawControl.getContainer().className +" scenarioDrawControl";
                // drawControlOnlyEdit.getContainer().className +" scenarioDrawControl";



                // oMap.addControl(drawControl);

                // addSpecificClassToDrawControl(drawControl);


                //draw end

                function addSpecificClassToDrawControl (oDrawControl){
                    if(oDrawControl.getContainer().className.indexOf("scenarioDrawControl" )>-1){

                    }else{
                        oDrawControl.getContainer().className +=" scenarioDrawControl";
                    }
                }

                var editToolBar= new L.EditToolbar.Edit(oMap, {
                    featureGroup: editableLayers,
                    selectedPathOptions: optionsOnlyEdit.edit
                });
                var drawToolbar = new L.Draw.Polygon(oMap, options.draw.polygon);

                $ctrl.drawPolygon = function(){

                    drawToolbar.enable();

                };

                $ctrl.editPolygon = function(){

                    // editToolBar.enable()
                };

                $ctrl.stopEdit = function(){
                    // editToolBar.disable();
                };

                $ctrl.deletePolygon = function(){
                    editableLayers.clearLayers();
                    oPolygon = null;
                };


                oMap.on('draw:created', function(e) {
                    var type = e.layerType,
                        layer = e.layer;

                    editableLayers.addLayer(e.layer);

                    oPolygon = e.layer;


                    drawToolbar.disable();


                    // try {
                    //     drawControlOnlyEdit.addTo(oMap);
                    // }catch (e) {
                    //     console.log(e)
                    // }
                    //
                    // addSpecificClassToDrawControl(drawControlOnlyEdit);

                    // $ctrl.loadFilteredFeatures()
                });

                // oMap.on("draw:edited", function(e ){
                //     oPolygon = e.layer;
                //
                //     // oFeatureLayer.clearLayers()
                //
                //     // $ctrl.loadFilteredFeatures()
                // });

                // oMap.on("draw:deleted", function(e ){
                // drawControlOnlyEdit.removeFrom(oMap);
                // drawControl.addTo(oMap);
                // addSpecificClassToDrawControl(drawControl);
                // oFeatureLayer.clearLayers();
                // oPolygon = null;

                // });


                $ctrl.isObjPolygon= function(){
                    return (oPolygon == null)?false:true;
                };


                toolsService.getToolById($ctrl.resolve.model.toolData.toolId, function (data) {

                    var southWest = L.latLng($rootScope.acSession.hat.domain.lats, $rootScope.acSession.hat.domain.lonw),
                        northEast = L.latLng($rootScope.acSession.hat.domain.latn, $rootScope.acSession.hat.domain.lone),
                        bounds = L.latLngBounds(southWest, northEast);
                    oMap.fitBounds(bounds);

                    data.config.layers.forEach(function (o) {
                        o.checked = false;
                    })
                    $ctrl.aoLayers = data.config.layers;

                })


            };





            $ctrl.toggleLayer = function(oLayer){

                oLayer.checked = !oLayer.checked;

                if (oLayer.checked){
                    oLayer.oMapLayer = L.tileLayer.wms(oLayer.wmsServer, {
                        layers: oLayer.wmsId,
                        format: 'image/png',
                        transparent: true,
                        maxZoom: 24,
                    }).addTo(oWMSLayer).bringToFront();

                }else {
                    oWMSLayer.removeLayer(oLayer.oMapLayer);
                }

                // try {
                //     if (oPolygon.hasOwnProperty("_latlngs")){
                //         $ctrl.loadFilteredFeatures();
                //     }
                // }catch (e) {
                //     console.log(e)
                // }

            };

            $ctrl.isUpdateActive = function(){
                try {
                    if (oPolygon.hasOwnProperty("_latlngs")){
                        var hasLayer = false;
                        $ctrl.aoLayers.forEach(function (layer) {
                            if(layer.checked){
                                hasLayer = true;
                            }
                        })
                        return hasLayer;
                    } return false
                }catch (e) {
                    console.log(e);
                    return false
                }

            }

            $ctrl.changeState = function(state){
                $ctrl.state = state;
            };

            $ctrl.buildFeaturesTable = function(){

                $ctrl.aoFeatureLayers = oFeatureLayer.getLayers();

                $ctrl.selectedLayerInTable($ctrl.aoFeatureLayers[0])

            };

            $ctrl.buildArrayForNgTable = function(aoLayers){
                for(var key in aoLayers){
                    aoLayers[key].feature.properties
                }
            };


            $ctrl.counterObj = {};



            $ctrl.selectedLayerInTable = function(oLayerSelected){

                $ctrl.bDisableCountEFilter = false

                if(_.keys(oLayerSelected._layers).length <2){
                    $ctrl.bDisableCountEFilter = true;
                }

                $ctrl.aoFeatureLayers.forEach(function(oLayer){
                    oLayer.active = false;
                });

                oLayerSelected.active = true;

                $ctrl.oFeaturesInTable = oLayerSelected._layers;

                console.log($ctrl.oFeaturesInTable)

                $ctrl.oFeaturesHeadInTable =$ctrl.oFeaturesInTable[Object.keys($ctrl.oFeaturesInTable)[0]].feature.properties;

                $ctrl.counterObj = Object.keys($ctrl.oFeaturesHeadInTable);

                console.log($ctrl.counterObj)

                for(var i in $ctrl.counterObj ){
                    $ctrl.counterObj[i]=0
                }

                console.log($ctrl.counterObj)

                $ctrl.trackingProp = Object.keys($ctrl.oFeaturesHeadInTable)[0];

                oMap.fitBounds(oPolygon.getBounds().pad(0.5));

            };

            $ctrl.countNumberByFeatures = function(key){

                var count = 0;

                for(var i in $ctrl.oFeaturesInTable){

                    if ($ctrl.oFeaturesInTable[i].feature.properties[key]){
                        if (!isNaN(parseFloat($ctrl.oFeaturesInTable[i].feature.properties[key]))){
                            count += parseFloat($ctrl.oFeaturesInTable[i].feature.properties[key]);
                        }
                    }
                }

                // $ctrl.oFeaturesInTable.feature.forEach(function (feature) {
                //     if (feature.properties[key]){
                //         if (!isNaN(parseFloat(feature.properties[key]))){
                //             count += parseFloat(feature.properties[key]);
                //         }
                //     }
                // })
                $ctrl.counterObj[key] = count;

                console.log($ctrl.counterObj[key])
                console.log(count)

            };

            $ctrl.loadFilteredFeatures = function(){

                if(oFeatureLayer)oFeatureLayer.clearLayers();

                var oPost={
                    layers :[],
                    polygonFilter:[]
                };
                // collect active layer
                $ctrl.aoLayers.forEach(function (layer) {
                    if(layer.checked){
                        var l = angular.copy(layer);
                        delete l.oMapLayer;
                        delete l.checked;
                        oPost.layers.push(l);
                    }
                })

                // oPolygon._latlngs.forEach(function (p) {
                //     oPost.polygonFilter.push({lat:parseFloat(p.lat.toFixed(2)),lng:parseFloat(p.lng.toFixed(2))})
                // });

                //ufficiale
                oPost.polygonFilter = oPolygon._latlngs[0];

                oPost.polygonFilter.push(oPolygon._latlngs[0][0]);


                //TEST
                // oPost.polygonFilter = [
                //     {lng: 17.56, lat : 41.18},
                //     {lng: 17.18, lat : 39.49},
                //     {lng: 20.24, lat : 39.55},
                //     {lng: 17.56, lat : 41.18},
                // ];

                var geojsonMarkerOptions = {
                    radius: 8,
                    fillColor: "#ff7800",
                    color: "#000",
                    weight: 1,
                    opacity: 1,
                    fillOpacity: 0.8
                };


                toolsService.getWFSFilteredFeatures(oPost,function (aoLayers) {

                    $ctrl.state = 2;

                    var oPolygon = L.polygon(oPost.polygonFilter)

                    var jsonFeatureFromPolygon = oPolygon.toGeoJSON()

                    if (aoLayers.length> 0){

                        aoLayers.forEach(function (layer, index) {

                            var oLayerToAnalyze = layer;

                            if(oPost.layers[index].isRaster){
                                oPost.layers[index].style = {
                                    opacity:1,
                                    fillColor:"#fff"
                                }
                                jsonFeatureFromPolygon.properties =layer.features[0].properties
                                oLayerToAnalyze = angular.copy(jsonFeatureFromPolygon);

                                oLayerToAnalyze.isRaster = oPost.layers[index].isRaster;
                            }

                            var numberOfFeatures = 0;

                            var oLayer =L.geoJson(oLayerToAnalyze, {
                                style: function (feature) {
                                    return oPost.layers[index].style;
                                },
                                onEachFeature:function (oFeature, layer) {
                                    // console.log(oFeature);
                                    numberOfFeatures++;
                                },
                                pointToLayer:function(geoJsonPoint, latlng) {
                                    var oM =L.circleMarker(latlng, oPost.layers[index].style);
                                    oM.on('mouseover',function (ev) {
                                        $ctrl.swichPageAndHighlight(ev.target._leaflet_id);
                                    });
                                    return oM;
                                },
                                coordsToLatLng: function (coords) {
                                    //                    latitude , longitude, altitude

                                    if(oLayerToAnalyze.isRaster){
                                        return new L.LatLng(coords[1], coords[0], coords[2]);
                                    }else{
                                        return new L.LatLng(coords[0], coords[1], coords[2]);
                                    }

                                    //return new L.LatLng(coords[1], coords[0], coords[2]); //Normal behavior
                                    // return new L.LatLng(coords[0], coords[1], coords[2]);
                                }

                            });
                            oLayer.name = oPost.layers[index].name;
                            oLayer.style = oPost.layers[index].style;
                            oLayer.active = false;
                            oLayer.numberOfFeatures = numberOfFeatures;

                            oFeatureLayer.addLayer(oLayer).bringToFront();
                        })

                        $ctrl.buildFeaturesTable();
                    }


                },function (err) {
                    console.log(err)
                });
            };

            $ctrl.aFilter =[];


            $ctrl.mouseOverFeatureInTable = function(feature){

                feature.bindPopup("You are here").openPopup();

            };

            $ctrl.mouseLeaveFeatureInTable = function(feature){
                feature.closePopup();
            };

            $ctrl.mouseClickFeatureInTable = function(feature){
                var latLngs = [ feature.getLatLng() ];
                var markerBounds = L.latLngBounds(latLngs);
                oMap.fitBounds(markerBounds).setZoom(13);

            };

            $ctrl.swichPageAndHighlight = function(id){
                $ctrl.paginatorConfig.eachPage = 1000;
                $location.hash(id+"_Anchor");
                $ctrl.featureHighlighted = id+"_Anchor";
                $anchorScroll();
            };

            $ctrl.filterObj = {};

            $ctrl.FilterByText = function(oFeatureInTable){

                oFeatureInTable = $ctrl.paginator(oFeatureInTable);

                var oFiltered={};
                if(Object.keys($ctrl.filterObj).length>0){

                    for(var layer in oFeatureInTable){//per ogni layer
                        for(var prop in oFeatureInTable[layer].feature.properties){ //per ogni prop del layer
                            if ($ctrl.filterObj[prop] == ""){
                                //se è stato cancellato non deve più filtrare
                                delete $ctrl.filterObj[prop];
                                break;
                            }
                            if($ctrl.filterObj[prop] ){//se esiste un filtro per quella prop
                                if(oFeatureInTable[layer].feature.properties[prop].toLowerCase().indexOf($ctrl.filterObj[prop].toLowerCase())> -1){//se prop in feature ha parte di prop in filter pusho
                                    oFiltered[layer] = oFeatureInTable[layer];
                                    // oFeatureInTable[layer].inTable = true ;
                                }
                            }else {

                            }

                        }
                    }

                } else return oFeatureInTable;
                return oFiltered;
            };


            $ctrl.paginatorConfig={
                page:0,
                pages:[0],
                eachPage:10000
            }

            $ctrl.paginator=function(oFeatureInTable){
                if (typeof oFeatureInTable != 'object')return oFeatureInTable;
                var oFiltered = {};

                var count = Object.keys(oFeatureInTable).length;
                if ($ctrl.paginatorConfig.eachPage< count){
                    var quotient = Math.floor(count/$ctrl.paginatorConfig.eachPage);
                    var remainder = count % $ctrl.paginatorConfig.eachPage;
                    $ctrl.paginatorConfig.pages = [];
                    for(var i = 0; i<= quotient; i++){
                        $ctrl.paginatorConfig.pages.push(i);
                    }
                    // if (remainder>0)$ctrl.paginatorConfig.pages.push($ctrl.paginatorConfig.pages[$ctrl.paginatorConfig.pages.length-1]+1);

                    var iFeatureCount = 0;
                    var start = $ctrl.paginatorConfig.page *$ctrl.paginatorConfig.eachPage;
                    var end = start +$ctrl.paginatorConfig.eachPage;
                    for(var feat in oFeatureInTable){
                        if (iFeatureCount>= start && iFeatureCount<= end){
                            oFiltered[feat] = oFeatureInTable[feat];
                        }
                        iFeatureCount++;
                    }
                    return oFiltered;
                }else {
                    $ctrl.paginatorConfig.pages = [0];
                    return oFeatureInTable;
                }

            };

            $ctrl.filterBuilder = function(key, value){
                console.log(key)
                return value;
            };

            $ctrl.fromObjToArray = function(obj){

                var result = Object.keys(obj).map(function(key) {
                    return [key, obj[key]];
                });
                return result;
            }

            $ctrl.downloadData = function(){

                if(!$ctrl.aoFeatureLayers) return;

                var objToPost={
                    data:[],
                    creator:"Dewetra2",
                    title:"DW2 report to excel"
                };

                if($ctrl.aoFeatureLayers.length >0){
                    $ctrl.aoFeatureLayers.forEach(function (layer) {
                        var eachLayerObj = {
                            title :layer.name,
                            numberOfFeatures :layer.numberOfFeatures,
                            data:[]
                        }

                        var isIndexBuilded = false;

                        for (var feat in layer._layers){

                            var aFeatProp= [];//featureProp
                            var aFeatKey = [];

                            for(var key in layer._layers[feat].feature.properties){
                                if (!isIndexBuilded){
                                    aFeatKey.push(key)
                                }
                                aFeatProp.push(layer._layers[feat].feature.properties[key])
                            }

                            if(!isIndexBuilded)eachLayerObj.data.push(aFeatKey);

                            eachLayerObj.data.push(aFeatProp);
                            isIndexBuilded = true;

                        }

                        objToPost.data.push(eachLayerObj);

                    });
                }

                // apiService.postPrintServer('datatofile/xlsx/',objToPost,function (data) {
                //     console.log(data)
                //
                //     var a = document.createElement('a');
                //     a.href = data.url;
                //     document.body.appendChild(a);
                //     // a.download = true;
                //     // ritardo lo scaricamento senno me lo restituisce non printo
                //     $timeout(function () {
                //         a.click()
                //     },3000)
                // });

                printService.getDataToFile('xlsx', objToPost,function (data) {
                    var a = document.createElement('a');
                    a.href = data.url;
                    document.body.appendChild(a);
                    a.click()
                });

            };


            $ctrl.loadLayerInDW2 = function(){

                var oFakeLayer= {
                    icon :null,
                    descr:"scenario",
                    latn:44.45,
                    lats:44.35,
                    lone:9,
                    lonw:8.9,
                    server:{id:1},
                    type:{
                        code:"SCENARIO"
                    }
                };



            };


            $ctrl.reset = function () {

                oMap.remove();


                initMap()
            };

            $ctrl.closePopup = function() {

                var r = confirm($translate.instant("LEAVE_IMPACT_SCENARIO"));

                if (r == true) {
                    $uibModalInstance.close();
                    if(model.onClose)model.onClose();

                    oFeatureLayer.clearLayers();

                    editableLayers.clearLayers();

                    oWMSLayer.clearLayers();

                    oMap.removeLayer(oFeatureLayer);

                    oMap.removeLayer(editableLayers);

                    oMap.removeLayer(oWMSLayer);


                    try {
                        oMap.removeControl(drawControl);
                    }catch (e) {
                        console.log(e)
                    }
                    try {
                        oMap.removeControl(drawControlOnlyEdit)
                    }catch (e) {
                        console.log(e)
                    }


                }



            };


            $timeout(initMap, 1000)



        }]
    });
})();

