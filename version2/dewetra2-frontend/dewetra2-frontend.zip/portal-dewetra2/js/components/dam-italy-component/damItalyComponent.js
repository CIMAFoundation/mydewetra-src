/**
 * Created by Dario Rubado on 16/12/19.
 */
(function () {

    dewetraApp.component('damItaly', {
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        template: `<div class="popup">
                        <div class="head" >
                            <div class="flex-container">
                                <!--Title-->
                                <div class="brand flex-item">
                                    <i class="fa app-static animated bounceIn delay-002" ></i>
                                    <p class="animated fadeInDown delay-001" translate>
                                          <span translate> {{$ctrl.resolve.target.properties.diga}} </span> <span translate>properties</span>
                                    </p>
                                </div>
                                
                                <!-- <div class="flex-item">
                                     <i data-title="UPDATE" 
                                        ng-if="$ctrl.pendingRequests != 0 && !$ctrl.iconize"  
                                        style="color: #f59c1a;margin-right: 100px;" 
                                        class="fa fa-refresh fa-spin fa-3x fa-fw" 
                                        aria-hidden="true" ></i>
                                </div> -->
                    
                                <div class="flex-item">
                                    <a class="close" ng-click="$ctrl.close()" href>
                                        <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    
                        <hr>
         
                        <div class="modal-body">
                            <div class="row">
                                <div class="flex-container">
                                    <button class="btn btn-info flex-item m-2 p-2" 
                                            style="color: whitesmoke" 
                                            ng-repeat="variable in $ctrl.VARIABLES" 
                                            ng-click="$ctrl.setVariable(variable)">
                                        {{variable}}
                                    </button>
                                </div>
                            </div>
                            
                            <div class="row" style="width: 100%; margin: auto">
                               <dam-italy-chart-component  serie="$ctrl.serie" variable="$ctrl.selectedVariable" ></dam-italy-chart-component>
                            </div>
                        </div>
                    </div>`,

        controller: ['$uibModal', 'acUserResource', '$rootScope', '_', '$window', 'mapService', 'apiService', 'menuService', 'damService', function ($uibModal, acUserResource, $rootScope, _, $window, mapService, apiService, menuService, damService) {

            const $ctrl = this;

            let VARIABLES = [];

            $ctrl.config = {
                grouped: {},
                selectedVariable: '',
                VARIABLES: [],
            }

            $ctrl.grouped = {};
            $ctrl.selectedVariable = '';
            $ctrl.VARIABLES = [];
            $ctrl.serie = {};

            $ctrl.$onInit = () => {
                //console.log($ctrl.resolve.target);
                //$ctrl.resolve.target.properties.name

                //console.log($ctrl.resolve.oManager);
                //console.log($ctrl.resolve.observation);
                extractObservation($ctrl.resolve.observation);
                //$ctrl.resolve.observation.Envelope.Body.GetObservationResponse
            }

            $ctrl.$onChanges = () => {

            }

            $ctrl.closePopup = () => {
                $ctrl.resolve.close();
            }

            $ctrl.setVariable = (variable) => {
                //console.log(variable)
                $ctrl.selectedVariable = variable;
                $ctrl.serie = $ctrl.grouped[$ctrl.selectedVariable];
            };
            ;
            const extractObservation = (observationObject) => {


                //console.log(observationObject);
                //console.log(observationObject['soap:Envelope']['soap:Body']['sos:GetObservationResponse']['sos:observationData']);

                // Debug
                // observationObject['soap:Envelope']['soap:Body']['sos:GetObservationResponse']['sos:observationData'].map(obs => {
                //     console.log(obs['om:OM_Observation']['om:observedProperty']['@xlink:title']);
                // });

                let grouped = _.groupBy(observationObject['soap:Envelope']['soap:Body']['sos:GetObservationResponse']['sos:observationData'], (obs) => {
                    return obs['om:OM_Observation']['om:observedProperty']['@xlink:title']
                })

                $ctrl.VARIABLES = Object.keys(grouped);


                $ctrl.selectedVariable = $ctrl.VARIABLES[0];

                Object.keys(grouped).map(variable => {
                    grouped[variable].values = [];
                    grouped[variable].timeline = [];
                    grouped[variable].measureUnit = [];

                    grouped[variable].map(observation => {
                        grouped[variable].values.push(observation['om:OM_Observation']['om:result']['#text']);
                        grouped[variable].timeline.push(observation['om:OM_Observation']['om:phenomenonTime']['gml:TimeInstant']['gml:timePosition']);
                        // grouped[variable].measureUnit.push(['om:OM_Observation']['om:result']['@uom'])
                    })
                })

                // grouped = grouped.map(observations => {
                //      observations.data = observations.map(obs => obs['om:OM_Observation']['om:result']['#text']);
                //      observations.timeline = observations.map(obs => obs['om:OM_Observation']['om:phenomenonTime']['gml:TimeInstant']['gml:timePosition']);
                //      return observations;
                // })


                $ctrl.grouped = grouped;

                $ctrl.serie = $ctrl.grouped[$ctrl.selectedVariable];

                //console.log(grouped);

                //console.log($ctrl.grouped);

                // ['om:OM_Observation']['om:result']['#text'] //value
                // ['om:OM_Observation']['om:result']['@uom'] //measure unit
                // ['om:OM_Observation']['om:phenomenonTime']['gml:TimeInstant']['gml:timePosition'] // time
            };
            const extractObservation1 = () => {
            };

        }]
    });

    const obj = {
        "soap:Envelope": {
            "@xmlns:soap": "http://www.w3.org/2003/05/soap-envelope",
            "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
            "@xmlns:sos": "http://www.opengis.net/sos/2.0",
            "@xmlns:om": "http://www.opengis.net/om/2.0",
            "@xmlns:gml": "http://www.opengis.net/gml/3.2",
            "@xmlns:xlink": "http://www.w3.org/1999/xlink",
            "@xsi:schemaLocation": "http://www.opengis.net/om/2.0 http://schemas.opengis.net/om/2.0/observation.xsd http://www.opengis.net/sos/2.0 http://schemas.opengis.net/sos/2.0/sosGetObservation.xsd http://www.opengis.net/gml/3.2 http://schemas.opengis.net/gml/3.2.1/gml.xsd http://www.w3.org/2003/05/soap-envelope http://www.w3.org/2003/05/soap-envelope",
            "soap:Header": null,
            "soap:Body": {
                "sos:GetObservationResponse": {
                    "sos:observationData": [
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_0",
                                "gml:description": "1381_/1/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000001/LivelloInvaso/OSS2019-11-18T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_0",
                                        "gml:timePosition": "2019-11-18T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_0"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/1/2/0/1",
                                    "@xlink:title": "LivelloInvaso"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "LivelloInvaso",
                                    "@xlink:title": "LivelloInvaso"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "mslm",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "336.6"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_1",
                                "gml:description": "1381_/1/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000001/LivelloInvaso/OSS2019-11-19T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_1",
                                        "gml:timePosition": "2019-11-19T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_1"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/1/2/0/1",
                                    "@xlink:title": "LivelloInvaso"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "LivelloInvaso",
                                    "@xlink:title": "LivelloInvaso"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "mslm",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "336.61"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_2",
                                "gml:description": "1381_/1/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000001/LivelloInvaso/OSS2019-11-20T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_2",
                                        "gml:timePosition": "2019-11-20T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_2"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/1/2/0/1",
                                    "@xlink:title": "LivelloInvaso"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "LivelloInvaso",
                                    "@xlink:title": "LivelloInvaso"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "mslm",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "336.62"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_3",
                                "gml:description": "1381_/1/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000001/LivelloInvaso/OSS2019-11-21T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_3",
                                        "gml:timePosition": "2019-11-21T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_3"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/1/2/0/1",
                                    "@xlink:title": "LivelloInvaso"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "LivelloInvaso",
                                    "@xlink:title": "LivelloInvaso"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "mslm",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "336.63"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_4",
                                "gml:description": "1381_/4/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000004/PortataDerivata/OSS2019-11-19T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_4",
                                        "gml:timePosition": "2019-11-19T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_4"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/4/2/0/1",
                                    "@xlink:title": "PortataDerivata"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "PortataDerivata",
                                    "@xlink:title": "PortataDerivata"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "m3-s",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "0.213"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_5",
                                "gml:description": "1381_/4/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000004/PortataDerivata/OSS2019-11-20T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_5",
                                        "gml:timePosition": "2019-11-20T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_5"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/4/2/0/1",
                                    "@xlink:title": "PortataDerivata"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "PortataDerivata",
                                    "@xlink:title": "PortataDerivata"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "m3-s",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "0.213"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_6",
                                "gml:description": "1381_/3/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000003/PortataScaricata/OSS2019-11-19T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_6",
                                        "gml:timePosition": "2019-11-19T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_6"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/3/2/0/1",
                                    "@xlink:title": "PortataScaricata"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "PortataScaricata",
                                    "@xlink:title": "PortataScaricata"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "m3-s",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "0.201"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_7",
                                "gml:description": "1381_/3/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000003/PortataScaricata/OSS2019-11-20T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_7",
                                        "gml:timePosition": "2019-11-20T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_7"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/3/2/0/1",
                                    "@xlink:title": "PortataScaricata"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "PortataScaricata",
                                    "@xlink:title": "PortataScaricata"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "m3-s",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "0.201"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_8",
                                "gml:description": "1381_/2/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000002/VolumeInvaso/OSS2019-11-18T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_8",
                                        "gml:timePosition": "2019-11-18T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_8"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/2/2/0/1",
                                    "@xlink:title": "VolumeInvaso"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "VolumeInvaso",
                                    "@xlink:title": "VolumeInvaso"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "Mm3",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "30.2"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_9",
                                "gml:description": "1381_/2/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000002/VolumeInvaso/OSS2019-11-19T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_9",
                                        "gml:timePosition": "2019-11-19T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_9"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/2/2/0/1",
                                    "@xlink:title": "VolumeInvaso"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "VolumeInvaso",
                                    "@xlink:title": "VolumeInvaso"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "Mm3",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "30.22"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_10",
                                "gml:description": "1381_/2/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000002/VolumeInvaso/OSS2019-11-20T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_10",
                                        "gml:timePosition": "2019-11-20T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_10"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/2/2/0/1",
                                    "@xlink:title": "VolumeInvaso"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "VolumeInvaso",
                                    "@xlink:title": "VolumeInvaso"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "Mm3",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "30.24"
                                }
                            }
                        },
                        {
                            "om:OM_Observation": {
                                "@gml:id": "o_11",
                                "gml:description": "1381_/2/2/0/1",
                                "gml:identifier": {
                                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                                    "#text": "1381_/000000002/VolumeInvaso/OSS2019-11-21T10-00-00Z"
                                },
                                "om:type": {
                                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                                },
                                "om:phenomenonTime": {
                                    "gml:TimeInstant": {
                                        "@gml:id": "phenomenonTime_11",
                                        "gml:timePosition": "2019-11-21T09:00:00Z"
                                    }
                                },
                                "om:resultTime": {
                                    "@xlink:href": "#phenomenonTime_11"
                                },
                                "om:procedure": {
                                    "@xlink:href": "1381_/2/2/0/1",
                                    "@xlink:title": "VolumeInvaso"
                                },
                                "om:parameter": [
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "MotivoAssenza"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "Qualificatore"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "Medio"
                                            }
                                        }
                                    },
                                    {
                                        "om:NamedValue": {
                                            "om:name": {
                                                "@xlink:href": "StatoAllerta"
                                            },
                                            "om:value": {
                                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                                "@xsi:type": "xs:string",
                                                "#text": "VigilanzaOrdinaria"
                                            }
                                        }
                                    }
                                ],
                                "om:observedProperty": {
                                    "@xlink:href": "VolumeInvaso",
                                    "@xlink:title": "VolumeInvaso"
                                },
                                "om:featureOfInterest": {
                                    "@xlink:href": "1381_"
                                },
                                "om:result": {
                                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                                    "@uom": "Mm3",
                                    "@xsi:type": "ns:MeasureType",
                                    "#text": "30.26"
                                }
                            }
                        }
                    ]
                }
            }
        }
    }
//OBSERVATIONS ARRAY IN RESPONSE
    const observations = [
        {
            "om:OM_Observation": {
                "@gml:id": "o_0",
                "gml:description": "1381_/1/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000001/LivelloInvaso/OSS2019-11-18T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_0",
                        "gml:timePosition": "2019-11-18T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_0"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/1/2/0/1",
                    "@xlink:title": "LivelloInvaso"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "LivelloInvaso",
                    "@xlink:title": "LivelloInvaso"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "mslm",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "336.6"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_1",
                "gml:description": "1381_/1/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000001/LivelloInvaso/OSS2019-11-19T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_1",
                        "gml:timePosition": "2019-11-19T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_1"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/1/2/0/1",
                    "@xlink:title": "LivelloInvaso"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "LivelloInvaso",
                    "@xlink:title": "LivelloInvaso"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "mslm",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "336.61"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_2",
                "gml:description": "1381_/1/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000001/LivelloInvaso/OSS2019-11-20T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_2",
                        "gml:timePosition": "2019-11-20T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_2"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/1/2/0/1",
                    "@xlink:title": "LivelloInvaso"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "LivelloInvaso",
                    "@xlink:title": "LivelloInvaso"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "mslm",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "336.62"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_3",
                "gml:description": "1381_/1/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000001/LivelloInvaso/OSS2019-11-21T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_3",
                        "gml:timePosition": "2019-11-21T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_3"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/1/2/0/1",
                    "@xlink:title": "LivelloInvaso"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "LivelloInvaso",
                    "@xlink:title": "LivelloInvaso"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "mslm",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "336.63"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_4",
                "gml:description": "1381_/4/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000004/PortataDerivata/OSS2019-11-19T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_4",
                        "gml:timePosition": "2019-11-19T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_4"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/4/2/0/1",
                    "@xlink:title": "PortataDerivata"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "PortataDerivata",
                    "@xlink:title": "PortataDerivata"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "m3-s",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "0.213"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_5",
                "gml:description": "1381_/4/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000004/PortataDerivata/OSS2019-11-20T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_5",
                        "gml:timePosition": "2019-11-20T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_5"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/4/2/0/1",
                    "@xlink:title": "PortataDerivata"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "PortataDerivata",
                    "@xlink:title": "PortataDerivata"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "m3-s",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "0.213"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_6",
                "gml:description": "1381_/3/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000003/PortataScaricata/OSS2019-11-19T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_6",
                        "gml:timePosition": "2019-11-19T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_6"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/3/2/0/1",
                    "@xlink:title": "PortataScaricata"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "PortataScaricata",
                    "@xlink:title": "PortataScaricata"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "m3-s",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "0.201"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_7",
                "gml:description": "1381_/3/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000003/PortataScaricata/OSS2019-11-20T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_7",
                        "gml:timePosition": "2019-11-20T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_7"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/3/2/0/1",
                    "@xlink:title": "PortataScaricata"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "PortataScaricata",
                    "@xlink:title": "PortataScaricata"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "m3-s",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "0.201"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_8",
                "gml:description": "1381_/2/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000002/VolumeInvaso/OSS2019-11-18T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_8",
                        "gml:timePosition": "2019-11-18T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_8"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/2/2/0/1",
                    "@xlink:title": "VolumeInvaso"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "VolumeInvaso",
                    "@xlink:title": "VolumeInvaso"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "Mm3",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "30.2"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_9",
                "gml:description": "1381_/2/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000002/VolumeInvaso/OSS2019-11-19T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_9",
                        "gml:timePosition": "2019-11-19T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_9"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/2/2/0/1",
                    "@xlink:title": "VolumeInvaso"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "VolumeInvaso",
                    "@xlink:title": "VolumeInvaso"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "Mm3",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "30.22"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_10",
                "gml:description": "1381_/2/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000002/VolumeInvaso/OSS2019-11-20T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_10",
                        "gml:timePosition": "2019-11-20T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_10"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/2/2/0/1",
                    "@xlink:title": "VolumeInvaso"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "VolumeInvaso",
                    "@xlink:title": "VolumeInvaso"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "Mm3",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "30.24"
                }
            }
        },
        {
            "om:OM_Observation": {
                "@gml:id": "o_11",
                "gml:description": "1381_/2/2/0/1",
                "gml:identifier": {
                    "@codeSpace": "http://www.opengis.net/def/nil/OGC/0/unknown",
                    "#text": "1381_/000000002/VolumeInvaso/OSS2019-11-21T10-00-00Z"
                },
                "om:type": {
                    "@xlink:href": "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
                },
                "om:phenomenonTime": {
                    "gml:TimeInstant": {
                        "@gml:id": "phenomenonTime_11",
                        "gml:timePosition": "2019-11-21T09:00:00Z"
                    }
                },
                "om:resultTime": {
                    "@xlink:href": "#phenomenonTime_11"
                },
                "om:procedure": {
                    "@xlink:href": "1381_/2/2/0/1",
                    "@xlink:title": "VolumeInvaso"
                },
                "om:parameter": [
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "MotivoAssenza"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "Qualificatore"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "Medio"
                            }
                        }
                    },
                    {
                        "om:NamedValue": {
                            "om:name": {
                                "@xlink:href": "StatoAllerta"
                            },
                            "om:value": {
                                "@xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                                "@xsi:type": "xs:string",
                                "#text": "VigilanzaOrdinaria"
                            }
                        }
                    }
                ],
                "om:observedProperty": {
                    "@xlink:href": "VolumeInvaso",
                    "@xlink:title": "VolumeInvaso"
                },
                "om:featureOfInterest": {
                    "@xlink:href": "1381_"
                },
                "om:result": {
                    "@xmlns:ns": "http://www.opengis.net/gml/3.2",
                    "@uom": "Mm3",
                    "@xsi:type": "ns:MeasureType",
                    "#text": "30.26"
                }
            }
        }
    ]

})();


