(function() {


    dewetraApp.component('carouselSliderOpener', {
        template : `
<!--           <div class="modal-header">-->
<!--&lt;!&ndash;                <h3 class="modal-title" id="modal-title">I'm a modal!</h3>&ndash;&gt;-->
<!--            </div>-->
            <div class="modal-body" id="modal-body">
                <carousel-slider slides="$ctrl.resolve.slides" interval="$ctrl.resolve.interval" height="$ctrl.resolve.height" width="$ctrl.resolve.width"></carousel-slider>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" ng-click="$ctrl.ok()">OK</button>
                <button class="btn btn-warning" type="button" ng-click="$ctrl.cancel()">Cancel</button>
            </div>
            `,
        bindings: {
            resolve:'<',
            close: '&',
            dismiss: '&'
        },
        controller: ['$uibModal', 'acUserResource', '$rootScope', '_', '$window', function ($uibModal, acUserResource, $rootScope, _, $window) {

            var $ctrl = this;

            $ctrl.ok = function () {
                $ctrl.close();
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss(  );
            };

            $ctrl.$onChanges = (changes) => {
                console.log("carousel components opener changes ");

            };

            $ctrl.$onInit =  () => {

                console.log("carousel components opener init")

            };
        }]
    });
})();



(function() {


    dewetraApp.component('carouselSlider', {
        template : `
            <div style="height: 300px">
               <div class="carousel-item" 
                    active="active" 
                    interval="$ctrl.interval" 
                    no-wrap="noWrapSlides"
                   >
                  <div ng-repeat="slide in $ctrl.slides track by slide.id" index="slide.id" 
                    style="position:absolute; margin:auto;" >
                    <img ng-show="slide.id == $ctrl.enabledId" ng-src="{{slide.image}}" ng-style="$ctrl.options.style" >
                    <div ng-show="slide.id == $ctrl.enabledId" class="carousel-caption">
                      <h4>{{slide.title}} </h4>
                      <p>{{slide.text}}</p>
                    </div>
                  </div>
                  
               </div>
           </div>
           <button ng-show="$ctrl.intervalTimer == null" ng-click="$ctrl.play()" class="btn btn-info m-2" type="button" ><i class="fa fa-play"></i> Play</button>
           <button ng-show="$ctrl.intervalTimer != null" ng-click="$ctrl.pause()"  class="btn btn-info m-2" type="button" ><i class="fa fa-pause"></i> Pause</button>
            `,

        bindings: {
            slides: '<',
            interval: '<',
            height: '<',
            width: '<'
        },
        controller: ['$uibModal', 'acUserResource', '$rootScope', '_', '$window', '$interval', function ($uibModal, acUserResource, $rootScope, _, $window, $interval) {

            var $ctrl = this;

            $ctrl.enabledId = 0;
            $ctrl.intervalTimer = null;

            $ctrl.options = {
                style: {
                    "width" : ($ctrl.width)?$ctrl.width:"500px",
                    "height": ($ctrl.height)?$ctrl.height:"300px",
                    "margin": 'auto'
                }
            };

           $ctrl.intervalTimer = $interval(function (){
                $ctrl.enabledId++;
                if ($ctrl.enabledId >= $ctrl.slides.length) $ctrl.enabledId = 0;
            },2000)

            $ctrl.play = () => {
                $ctrl.intervalTimer = $interval(function (){
                    $ctrl.enabledId++;
                    if ($ctrl.enabledId >= $ctrl.slides.length) $ctrl.enabledId = 0;
                },2000)
            }

            $ctrl.pause = () => {
                if($ctrl.intervalTimer){
                    $interval.cancel($ctrl.intervalTimer);
                    $ctrl.intervalTimer = null;
                }
            };

            $ctrl.$onChanges = (changes) => {
                console.log($ctrl.slides)

                console.log("carousel components changes");

            };

            $ctrl.$onInit =  () => {

                console.log("carousel components init")

            };

            $ctrl.$onDestroy  =  () => {
                if($ctrl.intervalTimer)$interval.cancel($ctrl.intervalTimer);

            };
        }]
    });
})();


