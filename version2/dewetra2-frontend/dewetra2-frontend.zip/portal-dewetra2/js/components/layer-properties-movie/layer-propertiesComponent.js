/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {


    dewetraApp.component('layerPropertiesMovie', {
        templateUrl: 'apps/dewetra2/js/components/layer-properties-movie/layer-propertiesComponent.html',
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['layerService', 'menuService',function (layerService, menuService) {
            var $ctrl = this;

            let debug;

            $ctrl.data = {}

            $ctrl.availables = [];
            $ctrl.currentLoadedTimeline;


            $ctrl.closePopup = function () {

                $ctrl.close()
            }

            $ctrl.$onInit = function () {
                $ctrl.oManager = $ctrl.resolve.oManager;

                $ctrl.preselectSelectedEntry();

                $ctrl.loadAvailables();


            };

            $ctrl.buildDataId = function(){
                console.log($ctrl.oManager.layerObj().dataid,$ctrl.dateRun,$ctrl.variable,$ctrl.level,$ctrl.instant)


            };



            $ctrl.preselectSelectedEntry = function () {
                $ctrl.oManager.props().layerProperties.attributes.forEach(function (attr) {
                    if ($ctrl.islist(attr)) {
                        for (var i=0; i<attr.entries.length; i++) {
                            if (attr.entries[i].value == attr.selectedEntry.value) {
                                attr.selectedEntry = attr.entries[i];
                                break;
                            }
                        }
                    }
                });
            }

            function evaluateAttributeForMovie(attr){
                return (attr.type == "List" && (attr.visible == "true" || typeof attr.visible === "boolean"));

            }

            $ctrl.loadAvailables = function () {

                const layerObj = $ctrl.oManager.layerObj();

                const oServices = $ctrl.oManager.oServices();

                const oManager = $ctrl.oManager;

                            oServices.layerService.getMovie(layerObj.server.id, layerObj.dataid,(data) =>{

                                //data.properties e data.datas
                                //da data.properties devo estrarre le selected entry di tipo list no hidden cobinare il value e in datas prendere il timelineid corretto

                                let attributes = oManager.props().layerProperties.attributes.filter(evaluateAttributeForMovie);

                                //build timelineId
                                let neededTimelineId= layerObj.dataid+'_';
                                attributes.map(( cur, idx ,src)=>{
                                    let sep = (idx < (src.length-1))?'_':'';
                                    if(cur.selectedEntry.value ){
                                        neededTimelineId += cur.selectedEntry.value + sep;
                                    }
                                });

                                let timelineObj = data.datas.filter(obj => obj.timelineId == neededTimelineId)[0];

                                oServices.layerService.getMovieTimeline(layerObj.server.id,layerObj.dataid, timelineObj.timelineId, function(timeline){
                                    if (debug)console.log(timeline); //timelineValues.entry[key value]
                                    $ctrl.currentLoadedTimeline = timeline;
                                    $ctrl.transformTimelineToItems();
                                    if (debug)console.log(oManager.item());


                                })


                            },(data) =>{
                                console.log(data);

                            },)





            }

            $ctrl.transformTimelineToItems = function (){
                $ctrl.availables = [];
                $ctrl.currentLoadedTimeline.timelineValues.entry.map((entry) => {
                    //entry.value entry.key
                    let splittedValue = entry.value.split('_');
                    let sDateRef = splittedValue[splittedValue.length-1];
                    let sDateRun = splittedValue[splittedValue.length-2];
                    let diff = moment(sDateRun).diff(sDateRef, 'hours');

                    let item = {
                        "date": moment.unix(entry.key).format(),
                        "description": moment.unix(sDateRun).format("Run: YYYY-MM-DD HHmm. Progr. +") + diff + " h",
                        "id" : sDateRun+';'+sDateRef,
                        "value" : entry.value,
                        "key" : entry.key

                    };

                    $ctrl.availables.push(item);

                });
                if($ctrl.oManager.item().id){
                    preselectLoadedLayer()
                }

            }

            preselectLoadedLayer = function ( ){
                $ctrl.availables.map((item)=>{
                    if(item.id == $ctrl.oManager.item().id){
                        $ctrl.data.item = item;
                    }
                })
            }

            $ctrl.isVisible = function(visibleAttr){
                if (visibleAttr == true || visibleAttr == "true") return true
                return false;
            }

            $ctrl.islist = function (attr) {
                return attr.type.toLowerCase() == 'list'
            };

            $ctrl.formatDateDescription = function(data){

                $ctrl.oManager

                if ($ctrl.oManager.customFormatDateDescription) return $ctrl.oManager.customFormatDateDescription(data);

                var sDateRunDateRef = data.id

                if(sDateRunDateRef.indexOf(";") > -1){
                    //controllo se osservazione o previsione
                    var l = $ctrl.oManager.layerObj();
                    var bLayerType = l.category == "observation";
                    //se osservazione la data di run corrisponde alla dateref e ne visualizzo solo una
                    if(bLayerType){
                        var aDateRunDateRef = sDateRunDateRef.split(";");
                        if(aDateRunDateRef.length >1 ){
                            if ((parseInt(aDateRunDateRef[0])) ==(parseInt(aDateRunDateRef[1]))){
                                return moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm')
                            }else return moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm')
                        }else return moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                        // var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                        //var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm')

                        //return sDateRun
                    }else{
                        //se previsione distinguo le due date

                        var aDateRunDateRef = sDateRunDateRef.split(";");

                        var diffDate=((parseInt(aDateRunDateRef[1]))-(parseInt(aDateRunDateRef[0])));

                        if(diffDate> 0 ) {
                            diffDate = diffDate/ (1000 * 60 * 60);
                            diffDate= "(+"+parseInt(diffDate)+"h)";
                        }else if(diffDate < 0){
                            diffDate= "(-"+Math.abs(diffDate) / (1000 * 60 * 60)+"h)";
                        }else diffDate= "";



                        var sDateRun = moment(new Date(parseInt(aDateRunDateRef[0]))).utc().format('DD/MM/YYYY HH:mm');
                        var sDateRef = moment(new Date(parseInt(aDateRunDateRef[1]))).utc().format('DD/MM/YYYY HH:mm');

                        var returnString = sDateRef + " "+" (Run:"+ sDateRun+")"+ diffDate;

                        return returnString
                    }
                    //se ha solo una data non mi pongo il problema
                }else{

                    var tsRun = parseInt(sDateRunDateRef);
                    if (!isNaN(tsRun)) return moment(new Date(tsRun)).utc().format('DD/MM/YYYY HH:mm');
                    else return moment(Date.parse(data.date)).utc().format('DD/MM/YYYY HH:mm');

                }
            };

            $ctrl.orderLayers = function (item) {

                if(item.date && moment(new Date(item.date)).isValid()) return item.id;
            }

            $ctrl.update = function () {
                // oManager.update(obj.props, obj.data, onFinish)

                $ctrl.close({$value:
                        {
                            props: $ctrl.oManager.props(),
                            data: $ctrl.data.item
                        }
                });
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

