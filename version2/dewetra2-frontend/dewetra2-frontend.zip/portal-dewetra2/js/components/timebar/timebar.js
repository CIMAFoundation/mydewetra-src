/**
 * Created by Dario Rubado on 23/07/18.
 */

(function() {


    dewetraApp.component('timeBarComponent', {
        templateUrl: 'apps/dewetra2/js/components/timebar/timebar.html',
        bindings: {
            onDateSelected: '&'
        },
        controller: ['$uibModal', 'acUserResource', '$rootScope', '_', '$window', function ($uibModal, acUserResource, $rootScope, _, $window) {

            var $ctrl = this;

            $ctrl.startDate = moment();
            $ctrl.endDate = moment();

            $ctrl.options = {
                locale: {cancelLabel: 'Clear'},
                showDropdowns: true
            };

            $ctrl.setDate = function (d1, d2) {
                console.log()
            };

            $ctrl.$onInit = function () {

                console.log("timebar new")


            };
        }]
    });
})

