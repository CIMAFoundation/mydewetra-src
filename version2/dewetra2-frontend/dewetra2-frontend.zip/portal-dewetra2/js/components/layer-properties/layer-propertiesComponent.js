/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {


    // var modalInstance = $uibModal.open({
    //     animation: $ctrl.animationsEnabled,
    //     component: 'modalComponent',
    //     resolve: {
    //         items: function () {
    //             return $ctrl.items;
    //         }
    //     }
    // });



    // angular.module('ui.bootstrap.demo').component('modalComponent', {
    //     templateUrl: 'myModalContent.html',
    //     bindings: {
    //         resolve: '<',
    //         close: '&',
    //         dismiss: '&'
    //     },
    //     controller: function () {
    //         var $ctrl = this;
    //
    //         $ctrl.$onInit = function () {
    //             $ctrl.items = $ctrl.resolve.items;
    //             $ctrl.selected = {
    //                 item: $ctrl.items[0]
    //             };
    //         };
    //
    //         $ctrl.ok = function () {
    //             $ctrl.close({$value: $ctrl.selected.item});
    //         };
    //
    //         $ctrl.cancel = function () {
    //             $ctrl.dismiss({$value: 'cancel'});
    //         };
    //     }
    // });


    dewetraApp.component('layerProperties', {
        templateUrl: 'apps/dewetra2/js/components/layer-properties/layer-propertiesComponent.html',
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: [function () {
            var $ctrl = this;

            console.log($ctrl)

            $ctrl.closePopup = function () {

                $ctrl.close()
            }

            $ctrl.$onInit = function () {
                $ctrl.oManager = $ctrl.resolve.oManager;

                $ctrl.aConfig = $ctrl.oManager.mapLayer().options.layers.split('-') //"wrfda-201903131200-PBLH-1-201903151500"
                console.log($ctrl.oManager.mapLayer().options.layers)
                $ctrl.dateRun = $ctrl.aConfig[1];
                $ctrl.variable = $ctrl.aConfig[2];
                $ctrl.level = $ctrl.aConfig[3];
                $ctrl.instant = $ctrl.aConfig[4];

            };

            $ctrl.buildDataId = function(){
                console.log($ctrl.oManager.layerObj().dataid,$ctrl.dateRun,$ctrl.variable,$ctrl.level,$ctrl.instant)


                return ({
                    dataId:$ctrl.oManager.layerObj().dataid,
                    dateRun:$ctrl.dateRun,
                    variable:$ctrl.variable,
                    level:$ctrl.level,
                    instant:$ctrl.instant

                })
            };

            $ctrl.update = function () {
                $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

