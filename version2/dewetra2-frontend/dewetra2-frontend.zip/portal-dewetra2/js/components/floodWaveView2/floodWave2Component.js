
/**
 * Created by dario on 27/10/16.
 */



(function() {


    dewetraApp.component('floodWaveView2', {
        templateUrl: 'apps/dewetra2/js/components/floodWaveView2/floodWave2.html',
        bindings: {
            resolve:'<',
            close: '&',
            dismiss: '&'
        },
        controller: ['$rootScope','$timeout', '$translate', 'laminazioneGenericService','menuService','_', 'apiService', '$location', '$anchorScroll', 'sentinelService', 'iconService', function ($rootScope,$timeout, $translate, laminazioneService,timeService,_, apiService, $location, $anchorScroll, sentinelService, iconService) {

            //TODO Doy ha sviluppato una nuova api che mi torna layer e superamenti. Da IMPLEMENTARE PER LE PROSSIME RELEASE

            const $ctrl = this;

            const warningHydroPalette = {
                '-2' : '#8A8787',//undef
                '-1' : '#FFFFFF',
                '0'  : '#00FF00',//safe verde
                '1'  : '#FFFF00',//ordinaria giallo
                '2'  : '#FA8B3C',//moderata arancione
                '3'  : '#FF0000',//alta rossa
                '4'  : '#C13BDB',//alta viola
                '5'  : '#3B46DB' //suparamento massimo storico blu
            }

            const speedInformationMarkersGroup = L.featureGroup();

            const layersGroup = L.featureGroup();

            let floodWaveMap = null;

            $ctrl.oConfig  = {
                astaPrincipale: 'Tevere',
                popUpZoom:9,
                zoom: 10,
                maxZoom: 11,
                pan: false,
                dragging: true,
                zoomControl: true,
                scrollWheelZoom: true,
                doubleClickZoom:true,
                hydrometers: [],
                riverSpeed: 1.5,
                aRiverSpeed: [1,1.5,2,2.5,3],
                nationalHydrometers:[],
                speedInformationMarkersGroup: L.featureGroup(),
                layersGroup: L.featureGroup(),
                floodWaveMap: null,
                chartTypes : [{name:"LIVELLI", id:1},{name:"PORTATE", id:2}],
                chartType : {name:"LIVELLI", id:1},
                layers:[
                    {
                        dataid:'dew:antenna_roto_wgs84',
                        name: 'antenna',
                        json:{},
                        leafletLayer:null,
                        option:{
                            onEachFeature: function (feature, layer) {

                                layer.on({
                                    click: clickOnAntenna,
                                    mouseover: mouseOverOnAntenna,
                                    mouseout: mouseOutOnAntenna
                                });
                            },
                            //style: $ctrl.styleOnAntenna,
                            style: function () {

                                return {
                                    fillColor: 'black',
                                    color : 'black',
                                    opacity : 1,
                                    fillOpacity: 0.6,
                                    weight: 2

                                }
                            }
                        },
                    },
                    {
                        dataid:'dew:confluenze_roto_wgs84',
                        name: 'confluenze',
                        json:{},
                        leafletLayer:null,
                        option:{
                            onEachFeature: function (feature, layer) {
                                layer.on({
                                    click: clickOnConfluenza,
                                    mouseover: mouseOverOnConfluenza,
                                    mouseout: mouseOutOnConfluenza
                                });
                            },
                            pointToLayer: function(feature, latlng) {
                                return L.circleMarker(latlng, geoJsonMarkerConfluenze);
                            }
                        },
                    },
                    {
                        dataid:'dew:idrometri_roto_wgs84',
                        name: 'idrometri',
                        json:{},
                        leafletLayer:null,
                        option:{
                            onEachFeature: function (feature, layer) {
                                layer.on({
                                    click: clickOnIdrometri,
                                    mouseover: mouseOverOnIdrometri,
                                    mouseout: mouseOutOnIdrometri
                                });
                            },
                            pointToLayer: function(feature, latlng) {
                                feature.warning_palette =0;
                                //return iconService.warnings_hydro_Icon(feature, 1)
                                return L.circleMarker(latlng, geoJsonMarkerIdrometri);
                            }
                        },
                    },
                ]
            };

            $ctrl.dateTo = moment(new Date(timeService.getDateTo())).format('lll');

            $ctrl.dateFrom = moment(new Date(timeService.getDateFrom())).format('lll');

            console.log("Flood Wave Component");

            const clickOnAntenna = (s)=>{
            }
            const mouseOverOnAntenna = (s)=>{

                s.target.setStyle({
                    color:'red'
                })
            }
            const mouseOutOnAntenna = (s)=>{
                s.target.setStyle({
                    color:'black'
                })
            }

            $ctrl.styleOnAntenna = (feature) => {

                    if(feature.geometry.type == "MultiLineString"){

                        if(feature.properties.hasOwnProperty("Branch")&&feature.properties.hasOwnProperty("Length_km")){

                            let intermediate = parseInt(feature.geometry.coordinates[0].length/2);

                            let myLabel = speedMarkerMaker(feature.properties.Length_km);

                            let marker = L.marker([feature.geometry.coordinates[0][intermediate][1],feature.geometry.coordinates[0][intermediate][0]],{icon:myLabel});
                            marker.properties = feature.properties;
                            marker.addTo($ctrl.speedInformationMarkersGroup);
                        }

                        return {
                            fillColor: 'black',
                            color : 'black',
                            opacity : 1,
                            fillOpacity: 0.6,
                            weight: 2
                        }

                    }

            }

            const clickOnConfluenza = (s)=>{
                // s.target.setStyle({
                //     color:'black'
                // })
            }
            const mouseOverOnConfluenza = (s)=>{
                s.target.setStyle({
                    color:'red'
                })
            }
            const mouseOutOnConfluenza = (s)=>{
                s.target.setStyle({
                    color:'blue'
                })
            }

            $ctrl.changeSpeedInformationMarker = function () {

                const layer = getLayerByType('idrometri');

                Object.keys(layer.leafletLayer._layers).map(i => {
                    layer.leafletLayer._layers[i].bindPopup(popUpText(layer.leafletLayer._layers[i].feature.properties))
                })

            }

            openAllPopUpUnderCertainView = function () {
                console.log('OpenAllPopUp');
                const layer = getLayerByType('idrometri');




                //layer.leafletLayer.openPopup();
                Object.keys(layer.leafletLayer._layers).map(i => {
                    let LatLng = layer.leafletLayer._layers[i].getLatLng();
                    let popup = L.popup();
                    popup.setContent(popUpText(layer.leafletLayer._layers[i].feature.properties))
                    popup.setLatLng(L.latLng(LatLng.lat, LatLng.lng));

                    //layer.remove(layer.leafletLayer._layers[i])
                    let marker = L.marker()
                    //layer.leafletLayer._layers[i].remove();
                    marker.setLatLng(L.latLng(LatLng.lat, LatLng.lng));
                    marker.setIcon(markerWithInfos(layer.leafletLayer._layers[i].feature.properties));
                    marker.feature = {properties: layer.leafletLayer._layers[i].feature.properties};

                    marker.on({
                        click: clickOnIdrometri,
                        mouseover: mouseOverOnIdrometri,
                        mouseout: mouseOutOnIdrometri
                    });

                    //marker.addTo(speedInformationMarkersGroup)
                    popup.addTo(speedInformationMarkersGroup)

                    //layer.leafletLayer._layers[i].openPopup()
                })
            }

            markerWithInfos = (properties) => {
                return L.divIcon({
                    iconAnchor: [10,10],
                    className: 'floodwave',
                    html: popUpText(properties)

                });

            }

            closeAllPopUpUnderCertainView = function () {
                console.log('CloseAllPopUp');
                speedInformationMarkersGroup.clearLayers();
                // const layer = getLayerByType('idrometri');
                //
                // //layer.leafletLayer.closePopup();
                // Object.keys(layer.leafletLayer._layers).map(i => {
                //     layer.leafletLayer._layers[i].closePopup()
                // })
            }

            const getLayerByType = (string)=>{
                return  $ctrl.oConfig.layers.filter( l => l.name == string)[0];
            }

            const clickOnIdrometri = (s)=>{

                //Enabling idrometer
                const layer = getLayerByType('idrometri');
                layer.json.features.map((f)=> {
                    if(f.properties.nome == s.target.feature.properties.nome){
                        s.target.feature.properties.visible = !s.target.feature.properties.visible;
                    }
                });
                //Reload hydrometer to be shawn
                $ctrl.hydrometerToChart();

                //Difference from hydrometer added by click?

                if(s.target.feature.properties.hasOwnProperty('warning_palette')){
                    let merged = {...colorCirleMarker(s.target.feature.properties),...magnifyCirleMarker()}
                    s.target.setStyle(merged)
                }

                $timeout(()=>{
                    mouseOverOnIdrometri(s)//if an hydrometer is added focus it
                },1000)

            }
            const mouseOverOnIdrometri = (s)=>{

                $location.hash('chart-' + s.target.feature.properties.id_cod + '-anchor');
                $anchorScroll();

                s.target.bindPopup(popUpText(s.target.feature.properties)).openPopup();

                console.log(s.target.feature.properties)

                if(s.target.feature.properties.hasOwnProperty('warning_palette')){
                    let merged = {...colorCirleMarker(s.target.feature.properties),...geoJsonMarkerIdrometriOvering}
                    s.target.setStyle(merged)
                }
            }
            const mouseOutOnIdrometri = (s)=>{
                try {
                    if(s.target.feature.properties.hasOwnProperty('warning_palette')){
                        let merged = {...colorCirleMarker(s.target.feature.properties),...geoJsonMarkerIdrometri}
                        s.target.setStyle(merged)
                    }
                }catch (e) {

                }

            }

            const geoJsonMarkerIdrometri = {
                radius: 5,
                // fillColor: 'white',
                color: 'black',
                weight: 1,
                opacity: 1,
                fillOpacity: 1
            };

            const geoJsonMarkerIdrometriOvering = {
                radius: 10,
                // fillColor: 'white',
                color: 'black',
                weight: 1,
                opacity: 1,
                fillOpacity: 0.5
            };

            const geoJsonMarkerConfluenze = {
                radius: 5,
                fillColor: 'blue',
                //color: 'blue',
                weight: 1,
                opacity: 1,
                fillOpacity: 1
            };

            $rootScope.$watch('pendingRequests', function(){
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });

            // ASTA
            // https://geodata.cimafoundation.org/geoserver/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=CIMA:antenna_utm32wgs84
            // CONFLUENZE
            // https://geodata.cimafoundation.org/geoserver/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=CIMA:antenna_confluenze_utm32wgs84
            // IDROMETRI
            // https://geodata.cimafoundation.org/geoserver/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=CIMA:antenna_idrometri_utm32wgs84

            /**
             * building wfs url
             * @param layerId
             * @returns {string}
             */
            buildApiUrl = (layerId) => {
                // return "https://geodata.cimafoundation.org/geoserver/wfs?srsName=EPSG:4326&request=GetFeature&version=1.0.0&outputFormat=json&typeName=" + layerId;

                return 'https://geoserver.cimafoundation.org/geoserver/dew/ows?service=WFS&version=1.0.0&request=GetFeature&typeName='+ layerId +'&maxFeatures=50&outputFormat=json'
            }

            /**
             * loadLayers wfs service
             */
            const loadLayers = () => {
                let count = 0;
                $ctrl.oConfig.layers.map((layer) => {
                    apiService.getExt(buildApiUrl(layer.dataid),(data)=>{
                        layer.json = data;

                        if(layer.name == 'idrometri'){
                            layer.json.features.map(feat => {
                                feat.properties.visible = (feat.properties.asta == $ctrl.oConfig.astaPrincipale)
                            })
                        }

                        layer.leafletLayer = L.geoJson(data,layer.option).addTo(layersGroup);

                        count++
                        if (count == $ctrl.oConfig.layers.length ){
                            floodWaveMap.fitBounds(layersGroup.getBounds());
                            //init hydrometer to chart
                            $ctrl.hydrometerToChart()
                            console.log('layer loaded');
                        }
                    },()=>{
                        console.log('error');
                        alert('error')
                    })
                })
            }

            /**
             * Init Map
             */
            const initMap = function () {

                if (floodWaveMap) return;

                const osmBasic = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');

                const zoom = $ctrl.oConfig.zoom;
                const maxZoom = $ctrl.oConfig.maxZoom;
                const pan = $ctrl.oConfig.pan;

                floodWaveMap = L.map('floodWaveMap',
                    {
                        // crs: crs,
                        // scale: scale,
                        //'center': [0, 0],
                        attributionControl: false,
                        zoom: zoom,
                        maxZoom: maxZoom,
                        dragging: $ctrl.oConfig.dragging,
                        zoomControl:$ctrl.oConfig.zoomControl,
                        scrollWheelZoom:$ctrl.oConfig.scrollWheelZoom,
                        doubleClickZoom: $ctrl.oConfig.doubleClickZoom,
                        tap:pan,
                        boxZoom:pan
                    })

                //osmBasic.addTo(floodWaveMap);

                speedInformationMarkersGroup.addTo(floodWaveMap);

                layersGroup.addTo(floodWaveMap);

                floodWaveMap.on('zoomend', function() {

                    if( floodWaveMap.getZoom() > $ctrl.oConfig.popUpZoom){
                        $ctrl.zoomUnder();
                    }else {
                        $ctrl.zoomOver();
                    }

                });

            }

            $ctrl.zoomOver = ()=>{
                //closeAllPopUpUnderCertainView()
            };
            $ctrl.zoomUnder = ()=>{
                //openAllPopUpUnderCertainView()
            };

            $ctrl.hydrometerToChart = () => {
                try {
                    const layer = getLayerByType('idrometri');
                    $ctrl.oConfig.hydrometers =  layer.json.features.map((f)=> f.properties).filter(p => p.visible);
                    console.log($ctrl.oConfig.hydrometers)
                }catch (e) {

                }
            };

            $ctrl.loadOnOveringChart = (t) =>{
                const layer = getLayerByType('idrometri');
                Object.keys(layer.leafletLayer._layers).map(i => {
                    if(layer.leafletLayer._layers[i].feature.properties.nome == t.nome){
                        layer.leafletLayer._layers[i].setStyle(geoJsonMarkerIdrometriOvering)
                    }
                })
            }

            $ctrl.loadOnLeavingChart = (t) =>{
                const layer = getLayerByType('idrometri');
                Object.keys(layer.leafletLayer._layers).map(i => {
                    if(layer.leafletLayer._layers[i].feature.properties.nome == t.nome){
                        layer.leafletLayer._layers[i].setStyle(geoJsonMarkerIdrometri)
                    }
                });
            }

            $ctrl.orderHydrometer = (hydrometer) => {
                let splitted = hydrometer.Order_TC_n.match(/.{1,2}/g);
                return parseInt(hydrometer.Order_TC_n);
                //return splitted[0]

                // hydrometer.Order_TC_n.split()

            };

            const loadColors = () => {
                const layer = getLayerByType('idrometri');
                Object.keys(layer.leafletLayer._layers).map(i => {

                    if(layer.leafletLayer._layers[i].feature.properties.nome == t.nome){
                        layer.leafletLayer._layers[i].setStyle(geoJsonMarkerIdrometri)
                    }
                });
            }

            colorCirleMarker = (properties) => {
                try {

                    let index = (properties.warning_palette)?properties.warning_palette:0
                    return {
                        color: warningHydroPalette[index]
                    }
                }catch (e) {
                    console.log(e)
                }

            }

            magnifyCirleMarker = (feature) => {
                return {
                    radius: 8
                }
            }

            deMagnifyCirleMarker = (feature) => {
                return {
                    radius: 5
                }
            }

            const updateMarker2 = () => {
                const layer = getLayerByType('idrometri');

                // debugger
                // layer.leafletLayer.map(l => {
                //     let nationalHydrometer= $ctrl.oConfig.nationalHydrometers.filter( nationalHydrometer => nationalHydrometer.properties.sensorid == l.feature.properties.id_sensor )[0];
                //     l.feature.properties = {...l.feature.properties,...nationalHydrometer.properties};
                //     //l.feature.properties.warning_palette = nationalHydrometer.properties.warning_palette;
                //
                //     debugger
                //     l.setStyle({color: warningHydroPalette[nationalHydrometer.properties.warning_palette]})
                // })

                layer.leafletLayer.eachLayer(l => {
                    let nationalHydrometer= $ctrl.oConfig.nationalHydrometers.filter( nationalHydrometer => nationalHydrometer.properties.sensorid == l.feature.properties.id_sensor )[0];
                    l.feature.properties = {...l.feature.properties,...nationalHydrometer.properties};
                    l.setStyle({fillColor: warningHydroPalette[nationalHydrometer.properties.warning_palette]})
                })
            }
            const updateMarker = () => {
                const layer = getLayerByType('idrometri');

                layer.leafletLayer.eachLayer(l => {
                    let nationalHydrometer= $ctrl.oConfig.nationalHydrometers.filter( nationalHydrometer => nationalHydrometer.properties.sensorid == l.feature.properties.id_sensor )[0];
                    l.setIcon(iconService.warnings_hydro_Icon(nationalHydrometer, 1))
                })
                // Object.keys(layer.leafletLayer._layers).map(i => {
                //     //get national hydrometer
                //     let nationalHydrometer= $ctrl.oConfig.nationalHydrometers.filter( nationalHydrometer => nationalHydrometer.sensorid == i.id_sensor )[0];
                //     layer.leafletLayer._layers[i].setIcon(iconService.warnings_hydro_Icon(nationalHydrometer, 1))
                // })
            }

            const loadHydrometersDataFromSentinel = (onFinish) => {
                sentinelService.getNationalIdro(function(data) {
                    //data.features.properties.sensorid
                    //$ctrl.oConfig.hydrometers.
                    $ctrl.oConfig.nationalHydrometers = data.features;

                    $ctrl.oConfig.nationalHydrometers.map(f => {
                        f.properties.warning_palette = calculateWarning(f.properties);
                        return f;
                    })

                    if (onFinish) onFinish()

                }, function(data) {

                    alert('Error loading layer: ' + data.error_message);

                });
            }
            const calculateWarning = (oProperties) => {
                //if (oProperties.sensorid == -1610577468){
                //    if(debug)console.log("p")
                //}
                let aValori = [];
                //costruisco array di oggetti per i valori
                for (let prop in oProperties) {
                    if (stringStartsWith(prop, 'v_')) {
                        const aValore = prop.split("_");

                        const oValore = {
                            timestamp: parseInt(aValore[1]),
                            period: parseInt(aValore[2]),
                            valore: parseFloat(oProperties[prop])
                        };
                        if (oProperties[prop] == -9999) {
                            return -2;
                        }

                        aValori.push(oValore)
                    }
                }
                //prendo il valore piu recente
                const oMostRecentValue = _.max(aValori, function (valore) {
                    return valore.timestamp;
                });
                const aTreshold = [];
                //cerco le soglie e construisco array per valutarle
                const sHighTreshold = 'e_';
                for (let prop in oProperties){
                    if (stringStartsWith(prop, sHighTreshold)) {
                        const aSoglia = prop.split("_");
                        const oSoglia = {
                            id: aSoglia[1],
                            idSoglia: aSoglia[1],
                            warn_index: parseInt(aSoglia[2]),
                            valore: oProperties[prop]
                        };
                        aTreshold.push(oSoglia)
                    }
                }
                //se ci sono soglie cerco la soglia massima
                const oHightestThreshold = _.max(aTreshold, function (valore) {
                    return valore.warn_index;
                });
                //se array soglie esiste ritorno la soglia maggiore
                if(aTreshold.length > 0){
                    return oHightestThreshold.warn_index;
                }else if(aValori.length > 0){//se non ci sono soglie valuto i valori
                    //costruisco array con valori uguali a 0
                    var values= _.filter(aValori, function (value) {
                        return value.valore == 0
                    });
                    return ((values.length == aValori.length)? -1:0);//se i valori a 0 sono tanti come tutti i valori allora il marker è bianco altrimenti è verde
                } else return -2;
                //se non ci sono valori validi torno grigio

            }

            function popUpText(properties) {
                const time = (parseFloat((properties.meas_m_nd/1000)) / (parseFloat($ctrl.oConfig.riverSpeed)*3.6));
                const color = warningHydroPalette[properties.warning_palette];
                let myLabel = `<div id ="station" class="floodwaveLabel" style="background-color: ${color}" ><div id="" style="line-height: 1;" class= "text-center ">${properties.nome} </div>`;
                let minutesInHour = parseInt(((time %1).toFixed(2)) * 60);
                //minutesInHour= parseInt(minutesInHour*60);
                let hour = Math.floor(time);
                let space = ' ';
                myLabel += '<div id="" style="line-height: 1;" class= "text-center ">'+((time>1)?hour+'h':' ') + space  + minutesInHour +' \'</div>';//if is more then 1h


                return myLabel + '</div>'
            }

            $ctrl.closePopup = function () {
                if ($ctrl.close) $ctrl.close();
            };

            $ctrl.$onChanges = (changes) => {
                console.log("Flood Wave Components changes")
                if(changes.resolve.currentValue ){

                }
            };

            $ctrl.$onInit =  () => {
                console.log("Flood Wave Components Init")
                $timeout(()=>{
                    initMap();
                    loadLayers();
                    loadHydrometersDataFromSentinel(updateMarker2);
                },1000)
            };

            $ctrl.$onDestroy =  () => {
                console.log("Flood Wave Components Destroy");
            };
        }]
    });
})();


//CRS Try
// const crs = new L.Proj.CRS('EPSG:32632', '+proj=utm +zone=32 +ellps=WGS84 +datum=WGS84 +units=m +no_defs', new L.Transformation(1, -432000, -1, 6850000),);

// const crs = new L.Proj.CRS('EPSG:32632', '+proj=utm +zone=32 +ellps=WGS84 +datum=WGS84 +units=m +no_defs',
//     {
//         resolutions: [
//             8192, 4096, 2048, 1024, 512, 256, 128
//         ],
//         origin: [0, 0]
//     }
// );

// const crs2 = L.CRS.proj4js('EPSG:32632', '+proj=utm +zone=32 +ellps=WGS84 +datum=WGS84 +units=m +no_defs',
//     {
//         resolutions: [
//             8192, 4096, 2048, 1024, 512, 256, 128
//         ],
//         origin: [0, 0]
//     }
// )
// const osmBasic = L.tileLayer('http://api.geosition.com/tile/osm-bright-3006/{z}/{x}/{y}.png', {

// $ctrl.oConfig.floodWaveMap = L.map('floodWaveMap',
//     {
//         crs:  L.Proj.CRS('EPSG:32632', '+proj=utm +zone=32 +ellps=WGS84 +datum=WGS84 +units=m +no_defs', new L.Transformation(1, -432000, -1, 6850000)),
//         scale: function(zoom) {
//             return 1 / (234.375 / Math.pow(2, zoom));
//         },
//         layers: [
//             new L.Marker(new L.LatLng(61.636, 8.3135), {
//                 title: 'Galdhøpiggen 2469 m'
//             })
//         ],
//
//         center: new L.LatLng(61.593, 8.397),
//         zoom: 3,
//         continuousWorld: true
//     })


