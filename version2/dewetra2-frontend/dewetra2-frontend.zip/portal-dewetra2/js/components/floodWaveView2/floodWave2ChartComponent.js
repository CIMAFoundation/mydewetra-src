(function() {


    dewetraApp.component('floodWaveView2Chart', {
        // templateUrl: 'apps/dewetra2/js/components/floodWaveView2/floodWave2.html',
        template: `
            <div style="color: whitesmoke;height: 350px;"  id="chart-{{$ctrl.hydrometer.id_cod}}-anchor" ng-mouseleave="$ctrl.onMouseLeave()" ng-mouseover="$ctrl.onMouseOver()" ng-scroll="$ctrl.scroll">
                <h3><i ng-show="$ctrl.config.show" ng-click="$ctrl.config.show = !$ctrl.config.show" class="fa fa-eye-slash"></i><i ng-show="!$ctrl.config.show" ng-click="$ctrl.config.show = !$ctrl.config.show" class="fa fa-eye"></i> {{$ctrl.indexId}} - {{$ctrl.hydrometer.nome}} -> {{$ctrl.hydrometer.asta}} </h3> 
                <div ng-show="$ctrl.config.show" id="chart-{{$ctrl.indexId}}" style="height: 300px;background-color: whitesmoke"></div>
            </div>`,
        bindings: {
            indexId: '<',
            hydrometer: '<',
            riverSpeed:'<',
            onOveringChart: '&',
            onLeavingChart: '&'
        },
        controller: ['$rootScope','$timeout', '$translate', 'laminazioneGenericService','menuService','_', 'apiService','$window', '$interval', 'serieService','thresholdService', function ($rootScope,$timeout, $translate, laminazioneService,menuService,_, apiService, $window, $interval, serieService, thresholdService) {

            const $ctrl = this;

            $ctrl.config = {
                show: true,
                chartAnchor: 'chart-'+$ctrl.indexId+'-anchor',
                chartId: 'chart-'+$ctrl.indexId,
                element:null,
                eventListener:null,
                isInViewport:false,
                isAlreadyLoaded: false
            };
            const interval = $interval(() => {
                ifViewportLoad()
            },1000 )

            $ctrl.onMouseOver = () => {
                $ctrl.onOveringChart.apply(this)($ctrl.hydrometer);
            }
            $ctrl.onMouseLeave = () => {
                $ctrl.onLeavingChart.apply(this)($ctrl.hydrometer)
            }

            const ifViewportLoad = () =>{
                if(isInViewport($ctrl.config.element)){
                    $interval.cancel(interval);
                    loadData()
                }
            }



            const loadData = () => {

                //console.log($ctrl.hydrometer);
                // {
                //     "id_cod": 45000,
                //     "nome": "Ponte del Grillo",
                //     "un": "m",
                //     "Tconc_h": 29.7,
                //     "Order_TC_n": "180000",
                //     "tph_new": 11.208,
                //     "tph_nn": 3.66828,
                //     "id_db_new": 2,
                //     "meas_m_f": 80697.6015625,
                //     "meas_m_np": 9828.719727,
                //     "meas_m_nd": 26411.6152344,
                //     "asta": "Tevere",
                //     "id_tb": 4,
                //     "visible": true,
                //     "$$hashKey": "object:619"
                // }
                //console.log("Load chart : "+ $ctrl.indexId);
                const to = menuService.getDateToUTCSecond();
                const from = menuService.getDateFromUTCSecond()
                //const width = document.getElementById($ctrl.config.chartId).clientWidth * 0.95;
                //const height = 600;
                //7092
                const fid = $ctrl.hydrometer.id_sensor+';'+$ctrl.hydrometer.id_db_new;
                //5969 con portata
                //7092 senza portata

                // const fid = 5969+';'+$ctrl.hydrometer.id_db_new;

                serieService.getSeriesDirect(1, 'all.sensor.hydrometers', fid, from, to, (data) => {
                    console.log(data);
                    let sensorInfo = {};
                    if (!Array.isArray(data)){
                        //has flow
                        data = [data]
                    }

                    $ctrl.hydrometer.sensorid = $ctrl.hydrometer.id_sensor;
                    $ctrl.hydrometer.dbid = $ctrl.hydrometer.id_db_new;

                    sensorInfo = {
                        station: {},
                        sensor : $ctrl.hydrometer,
                        timeline : data[0].timeline,
                        obs : data[0].values,
                        undef: getUndefSeries(data[0].timeline, data[0].values, from, to),
                        series:  data.map((x)=>{
                            console.log(x);
                            return {
                                timeline:x.timeline,
                                obs: x.values,
                                title: x.title,
                                type: x.type,
                                undef: getUndefSeries(x.timeline, x.values, from, to)
                            }
                        })
                    }
                    loadChart(sensorInfo)
                },() => {
                    console.log("Error Loading");
                })

            }

            const loadChart = (sensorInfo) => {
                const to = menuService.getDateToUTCSecond();
                const from = menuService.getDateFromUTCSecond();
                sensorInfo.chart = 'chart-' + $ctrl.indexId;

                showHydrometerFloodWaveChart( sensorInfo, from, to, 300, thresholdService, $translate,{
                    min:0,
                    max: 20,
                    tickInterval: 30,
                })

            }

            $ctrl.uuid

            $ctrl.dateTo = moment(new Date(menuService.getDateTo())).format('lll');

            $ctrl.dateFrom = moment(new Date(menuService.getDateFrom())).format('lll');

            console.log("Flood Wave CHART Component");

            $rootScope.$watch('pendingRequests', function(){
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });

            $ctrl.$onChanges = (changes) => {

                console.log("Flood Wave Components changes")

                if(changes.hydrometer.currentValue ){
                   $timeout(function (){


                       $ctrl.config.element = document.querySelector('#chart-'+ changes.indexId.currentValue);

                       if ($ctrl.config.element) {
                           $ctrl.config.isInViewport = isInViewport($ctrl.config.element)
                           $ctrl.config.element.onscroll =()=>{
                               console.log("scroll")
                           }
                           console.log(changes.hydrometer.currentValue.nome + " -> " + changes.indexId.currentValue + " -> " + $ctrl.config.isInViewport)
                       }
                   },0)



                    // $ctrl.config.eventListener = $window.addEventListener('scroll',function (event) {
                    //     debugger
                    //     if ($ctrl.config.element && isInViewport($ctrl.config.element)) {
                    //         console.log('im in view port %s', $ctrl.hydrometer.nome);
                    //     }
                    // });

                }
            };

            $ctrl.$onInit =  () => {
                console.log("Flood Wave Components Init")

            };

            $ctrl.$onDestroy =  () => {
                console.log("Flood Wave Components Destroy");
            };
        }]
    });
})();
