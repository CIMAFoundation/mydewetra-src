/**
 * Created by Dario Rubado on 24/10/21.
 */
dewetraApp.service('floodWaveService', ['apiService', 'menuService','sentinelService', function (apiService, menuService, sentinelService) {


    let nationalHydrometers;

    const warningHydroPalette = {
        '-2' : '#8A8787',//undef
        '-1' : '#FFFFFF',
        '0'  : '#00FF00',//safe verde
        '1'  : '#FFFF00',//ordinaria giallo
        '2'  : '#FA8B3C',//moderata arancione
        '3'  : '#FF0000',//alta rossa
        '4'  : '#C13BDB',//alta viola
        '5'  : '#3B46DB' //suparamento massimo storico blu
    }

    const calculateWarning = (oProperties) => {
        //if (oProperties.sensorid == -1610577468){
        //    if(debug)console.log("p")
        //}
        let aValori = [];
        //costruisco array di oggetti per i valori
        for (let prop in oProperties) {
            if (stringStartsWith(prop, 'v_')) {
                const aValore = prop.split("_");

                const oValore = {
                    timestamp: parseInt(aValore[1]),
                    period: parseInt(aValore[2]),
                    valore: parseFloat(oProperties[prop])
                };
                if (oProperties[prop] == -9999) {
                    return -2;
                }

                aValori.push(oValore)
            }
        }
        //prendo il valore piu recente
        const oMostRecentValue = _.max(aValori, function (valore) {
            return valore.timestamp;
        });
        const aTreshold = [];
        //cerco le soglie e construisco array per valutarle
        const sHighTreshold = 'e_';
        for (let prop in oProperties){
            if (stringStartsWith(prop, sHighTreshold)) {
                const aSoglia = prop.split("_");
                const oSoglia = {
                    id: aSoglia[1],
                    idSoglia: aSoglia[1],
                    warn_index: parseInt(aSoglia[2]),
                    valore: oProperties[prop]
                };
                aTreshold.push(oSoglia)
            }
        }
        //se ci sono soglie cerco la soglia massima
        const oHightestThreshold = _.max(aTreshold, function (valore) {
            return valore.warn_index;
        });
        //se array soglie esiste ritorno la soglia maggiore
        if(aTreshold.length > 0){
            return oHightestThreshold.warn_index;
        }else if(aValori.length > 0){//se non ci sono soglie valuto i valori
            //costruisco array con valori uguali a 0
            var values= _.filter(aValori, function (value) {
                return value.valore == 0
            });
            return ((values.length == aValori.length)? -1:0);//se i valori a 0 sono tanti come tutti i valori allora il marker è bianco altrimenti è verde
        } else return -2;
        //se non ci sono valori validi torno grigio

    }

    const loadHydrometersDataFromSentinel = (onFinish) => {
        sentinelService.getNationalIdro(function(data) {
            //data.features.properties.sensorid
            nationalHydrometers = data.features;

            nationalHydrometers.map(f => {
                f.properties.warning_palette = calculateWarning(f.properties);
                return f;
            })

            if (onFinish) onFinish(nationalHydrometers)

        }, function(data) {

            alert('Error loading layer: ' + data.error_message);

        });
    }



    return {

        getNationalIdrometer: (onFinish) => {
            loadHydrometersDataFromSentinel(onFinish)
        }


    }
}]);
