(function() {


    dewetraApp.component('chartAxisSetter', {
        //templateUrl: 'apps/dewetra2/js/components/timebar/timebar.html',
        template : `
            <script type="text/ng-template" id="yAxisExtremes.html">
                <div class="form-group">
                    <label translate>MAX_LABEL</label>
                    <input type="numer" ng-model="$ctrl.yAxisExtremes.max" class="form-control">
                    <label translate>MIN_LABEL</label>
                    <input type="numer" ng-model="$ctrl.yAxisExtremes.min" class="form-control">
                </div>
                <button type="button" ng-click="$ctrl.yAxisExtremes.close()" class="btn btn-default" >CLOSE</button>
                <button type="button" ng-click="$ctrl.yAxisExtremes.set()" class="btn btn-default" >SET</button>
            </script>
            
            <script type="text/ng-template" id="yAxisExtremesDual.html">
                <div class="form-group">
                    <label translate>MAX_LABEL</label>
                    <input type="numer" ng-model="$ctrl.yAxisExtremesDual.max" class="form-control">
                    <label translate>MIN_LABEL</label>
                    <input type="numer" ng-model="$ctrl.yAxisExtremesDual.min" class="form-control">
                </div>
                <button type="button" ng-click="$ctrl.yAxisExtremesDual.close()" class="btn btn-default" >CLOSE</button>
                <button type="button" ng-click="$ctrl.yAxisExtremesDual.set()" class="btn btn-default" >SET</button>
            </script>
            
            <button ng-show="$ctrl.chart.yAxis[0] != null" type="button" class="flex-item btn btn-default btn-xs" popover-placement="auto right-top" popover-is-open="$ctrl.yAxisExtremes.isOpen" uib-popover-template="$ctrl.yAxisExtremes.templateUrl" translate>SET_Y_AXIS</button>
            
            <button ng-show="$ctrl.chart.yAxis[1] != null" type="button" class="flex-item btn btn-default btn-xs" popover-placement="auto right-top"  popover-is-open="$ctrl.yAxisExtremesDual.isOpen" uib-popover-template="$ctrl.yAxisExtremesDual.templateUrl" translate>SET_SECONDARY_Y_AXIS</button>
        
            `,
        bindings: {
            chart: '<'
        },
        controller: ['$uibModal', 'acUserResource', '$rootScope', '_', '$interval' ,'$window', function ($uibModal, acUserResource, $rootScope, _, $interval, $window) {

            const $ctrl = this;

            let interval;

            $ctrl.options = {

            };

            $ctrl.yAxisExtremes = {

                isOpen: false,
                templateUrl:"yAxisExtremes.html",
                title:"SET_Y_AXIS",
                enabled: true,
                data: "data",
                edited: false,
                min: 0,
                max: 0,
                set:function(){

                    $ctrl.yAxisExtremes.isOpen = false
                    $ctrl.yAxisExtremes.edited = true
                    $ctrl.chart.yAxis[0].setExtremes($ctrl.yAxisExtremes.min, $ctrl.yAxisExtremes.max)
                },
                close:function(){
                    $ctrl.yAxisExtremes.isOpen = false
                }

            }

            $ctrl.yAxisExtremesDual = {

                isOpen: false,
                templateUrl:"yAxisExtremesDual.html",
                title:"SET_Y_AXIS",
                enabled: true,
                data: "data",
                edited: false,
                min: 0,
                max: 0,
                set:function(){

                    $ctrl.yAxisExtremes.isOpen = false
                    $ctrl.yAxisExtremes.edited = true
                    $ctrl.chart.yAxis[0].setExtremes($ctrl.yAxisExtremes.min, $ctrl.yAxisExtremes.max)
                },
                close:function(){
                    $ctrl.yAxisExtremes.isOpen = false
                }

            }

            $ctrl.checkExtremes = () => {}



            loadConfiguration = () => {



                if($ctrl.chart.yAxis[0]){

                    $ctrl.yAxisExtremes = {
                        isOpen: false,
                        templateUrl:"yAxisExtremes.html",
                        title:"SET_Y_AXIS",
                        enabled: true,
                        data: "data",
                        edited: false,
                        min: $ctrl.chart.yAxis[0].getExtremes().min,
                        max: $ctrl.chart.yAxis[0].getExtremes().max,
                        set:function(){

                            $ctrl.yAxisExtremes.isOpen = false
                            $ctrl.yAxisExtremes.edited = true
                            $ctrl.chart.yAxis[0].setExtremes($ctrl.yAxisExtremes.min, $ctrl.yAxisExtremes.max)
                        },
                        close:function(){
                            $ctrl.yAxisExtremes.isOpen = false
                        }

                    }
                }

                if($ctrl.chart.yAxis[1]){

                    $ctrl.yAxisExtremesDual = {
                        isOpen: false,
                        templateUrl:"yAxisExtremesDual.html",
                        title:"SET_Y_AXIS_DUAL",
                        enabled: true,
                        data: "data",
                        edited: false,
                        min: $ctrl.chart.yAxis[1].getExtremes().min,
                        max: $ctrl.chart.yAxis[1].getExtremes().max,
                        set:function(){

                            $ctrl.yAxisExtremesDual.isOpen = false
                            $ctrl.yAxisExtremesDual.edited = true
                            $ctrl.chart.yAxis[1].setExtremes($ctrl.yAxisExtremesDual.min, $ctrl.yAxisExtremesDual.max)
                        },
                        close:function(){
                            $ctrl.yAxisExtremesDual.isOpen = false
                        }

                    }
                }


            }

            $ctrl.$onChanges = (changes) => {
                if(changes.chart.currentValue != null){
                    loadConfiguration()
                }
                console.log("chartAxysSetter")


            };

            $ctrl.$onInit =  () => {

                console.log("chartAxysSetter");

                interval = $interval(loadConfiguration,15000)

            };

            $ctrl.$onDestroy =  () => {

                interval.cancel()

            };
        }]
    });
})();


