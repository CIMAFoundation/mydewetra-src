/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('thresholdsEditorButton', {
        //templateUrl: 'apps/dewetra2/js/components/thresholds-editor/thresholdsEditorButton.html',
        template: `<button class="btn btn-primary" ng-click="$ctrl.loadEditorThr()" translate>THR_EDITOR</button>`,
        bindings: {
            featureProperties:'<',
            thresholdsGroup:'<',
            sensorClass:'<',

        },
        controller: ['$uibModal', '$rootScope','$translate',function ($uibModal, $rootScope,$translate) {

            var $ctrl = this;

            $ctrl.$onChanges = function(){
                if(window.app.config.threshold && window.app.config.threshold[$ctrl.sensorClass]){
                    $ctrl.thresholdsGroup = window.app.config.threshold[$ctrl.sensorClass].group;
                }

                if($ctrl.featureProperties){
                    console.log($ctrl.featureProperties)
                }
            }

            $ctrl.loadEditorThr = function(){
                if(window.app.config.threshold[$ctrl.sensorClass].authHat.indexOf($rootScope.acSession.hat.descr)>-1 ){
                    var modalInstance = $uibModal.open({
                        animation: true,
                        component: 'thresholdsEditor',
                        size:'lg',
                        resolve: {
                            model: function () {
                                return {
                                    featureProperties:$ctrl.featureProperties,
                                    thresholdsGroup:$ctrl.thresholdsGroup,
                                    sensorClass:$ctrl.sensorClass,

                                };
                            },

                        }
                    });

                    modalInstance.result.then(function (obj) {

                        console.log('modal-component dismissed at: ' + new Date());

                    }, function () {
                        console.log('modal-component dismissed at: ' + new Date());
                    });
                }else {
                    console.log("No Auth to change thresholds")
                }
            }
        }]
    });


    dewetraApp.component('thresholdsEditor', {
        templateUrl: 'apps/dewetra2/js/components/thresholds-editor/thresholdsEditor.html',
        // template:' <ui-tree></ui-tree>',
        bindings: {
            // featureProperties:'<',
            // thresholdsGroup:'<',
            // sensorClass:'<',
            resolve: '<',
            close: '&',
            dismiss: '&',

        },
        controller: ['mapService','$uibModal','$rootScope','mapService','apiService','layerService','thresholdService', '$translate', 'acLogbook',function (mapService,$uibModal,$rootScope,mapService,apiService,layerService,thresholdService, $translate, acLogbook) {
            var $ctrl = this;

            $ctrl.$rootScope = $rootScope;





            // {
            //     "class": 3,
            //     "db": 2,
            //     "group": "national_IDROMETRO",
            //     "id": 407823,
            //     "name": "THR_3",
            //     "period": -1,
            //     "sensor": 50000279,
            //     "severity": 3,
            //     "type": "max",
            //     "value": 4.8,
            //     "$$hashKey": "object:1000"
            // }


            // [
            //     {
            //         "class": 3,
            //         "db": 2,
            //         "group": "national_IDROMETRO",
            //         "id": 409277,
            //         "name": "MAX@23/07/2008 08:00",
            //         "period": -1,
            //         "sensor": 8378,
            //         "severity": 0,
            //         "type": "max",
            //         "value": 368.98,
            //         "color": "#3B46DB",
            //         "$$hashKey": "object:1543"
            //     }
            // ]




            $ctrl.listPossibleThr = [];

            $ctrl.populateListPossibleThr= function(){

                $ctrl.listPossibleThr = []

                var oModelThresholds = $ctrl.THRESHOLDS_MODEL[$ctrl.sensorClass][$ctrl.thresholdsGroup];

                $ctrl.aoThresholds.forEach(function(oThr){
                    for(var i in oModelThresholds){
                        if(oThr.name.indexOf(i)>-1) oModelThresholds[i].count--;
                    }

                });

                for(var i in oModelThresholds){
                    if(oModelThresholds[i].count>0 && $ctrl.listPossibleThr.indexOf(i) == -1)$ctrl.listPossibleThr.push(i)
                }

            };

            $ctrl.thrChangedValue = function(thr){
                thr.changed = true;
            }

            $ctrl.addThr = function(thr){


                var newTHR = angular.copy($ctrl.sensorModelBySensorClass[$ctrl.sensorClass]);

                // $ctrl.THRESHOLDS_MODEL[$ctrl.sensorClass][$ctrl.thresholdsGroup][thr]
                newTHR.name = thr;
                newTHR.sensor = $ctrl.featureProperties.sensorid;
                newTHR.severity = $ctrl.THRESHOLDS_MODEL[$ctrl.sensorClass][$ctrl.thresholdsGroup][thr].severity
                newTHR.new = true;

                if(thr == "MAX") {
                     newTHR.date = new Date();
                    newTHR.name = "MAX@"+moment(newTHR.date).format('DD/MM/YYYY HH:mm');
                }



                $ctrl.aoThresholds.push(angular.copy(newTHR));

                //ripopolo lista togliendo la possibilita appena aggiunta
                $ctrl.populateListPossibleThr();

            }

            $ctrl.editThrToDb =function(thr){
                //PATCH EXISTING THRESHOLDS
                let domanda = confirm($translate.instant("ARE_YOU_SURE_THR"));
                if (domanda === true) {

                    thresholdService.saveExistingThreshold($ctrl.featureProperties.sensorid, $ctrl.featureProperties.dbid, thr,function (data) {


                        acLogbook.logActivity('dewetra2', 'THR_EDITED_EDIT:THR_ID->'+thr.id+':sensor->'+thr.sensor+":old_value->"+thr.oldvalue+":new_value->"+thr.value)

                        console.log('THR_EDITED_EDIT:id->'+thr.id+':sensor->'+thr.sensor+"old_value->"+thr.oldvalue+"new_value->"+thr.value)

                        $ctrl.$onInit();
                        console.log("EDITED")
                    })
                }else{

                }
            };

            $ctrl.addThrToDb =function(thr){
                //PATCH EXISTING THRESHOLDS
                let domanda = confirm($translate.instant("ARE_YOU_SURE_THR"));
                if (domanda === true) {


                    thresholdService.addNewThreshold($ctrl.featureProperties.sensorid, $ctrl.featureProperties.dbid, thr,function (data) {

                        acLogbook.logActivity('dewetra2', 'THR_EDITED_ADD:THR_ID->'+thr.id+':sensor->'+thr.sensor+":old_value->"+thr.oldvalue+":new_value->"+thr.value)

                        console.log('THR_EDITED_ADD:hat->'+$rootScope.acSession.hat.descr+'user->'+$rootScope.acSession.user.id+'id->'+thr.id+'sensor->'+thr.sensor+"old_value->"+thr.oldvalue+"new_value->"+thr.value)

                        console.log("added")

                        $ctrl.$onInit()
                    })

                }else{

                }
            };

            $ctrl.saveThr = function(thr){

                if (thr.new){

                    $ctrl.addThrToDb($ctrl.clearFromAttributes(thr))
                }else if(thr.changed){

                    $ctrl.editThrToDb($ctrl.clearFromAttributes(thr))
                }else {
                    console.log("you shouldnt be here");
                }

            };

            $ctrl.deleteThr = function (thrId){
                thresholdService.deleteExistingThreshold(thrId, function (data){
                    console.log("deleted")
                    $ctrl.$onInit();
                })
            }

            $ctrl.clearFromAttributes = function(thr){
                if(thr.hasOwnProperty("changed"))delete thr.changed
                if(thr.hasOwnProperty("date"))delete thr.date
                if(thr.hasOwnProperty("new"))delete thr.new
                return thr
            }



            //"MAX@10/05/2009 07:00"

            $ctrl.nameMaxFormatter = function(newDate, oldDate, thr){
                thr.changed = true
                thr.name = "MAX@"+moment(thr.date).format('DD/MM/YYYY HH:mm');
            }


            $ctrl.removeThr = function(index){
                $ctrl.aoThresholds.splice(index,1)
            }


            $ctrl.styleThr = function(thrName){

                switch (thrName) {
                    case 'THR_1':
                        return {'background-color': '#f8f334'}
                        break;
                    case 'THR_2':
                        return {'background-color': '#ffc31e'}
                        break;
                    case 'THR_3':
                        return {'background-color': '#ff1e38'}
                        break;
                }
            }

            $ctrl.$onInit = function () {



                if($ctrl.resolve.model.featureProperties){
                    $ctrl.featureProperties =$ctrl.resolve.model.featureProperties
                    console.log('properties from input')
                }else{
                    // $ctrl.featureProperties = {
                    //     "catchment": 208,
                    //     "dbid": 2,
                    //     "district": 9,
                    //     "munic": 1534,
                    //     "region": 7,
                    //     "sensorid": 50000279,
                    //     "sensormu": "m",
                    //     "sensorname": "Hydrometer",
                    //     "seriestate": 0,
                    //     "stationid": 200043176,
                    //     "stationname": "Albenga - Molino Branca",
                    //     "v_1557490500_0": 0.9399999976158142,
                    //     "wa": 36,
                    //     "warning_palette": -1
                    // };
                }




                if ($ctrl.resolve.model.thresholdsGroup){
                    $ctrl.thresholdsGroup = $ctrl.resolve.model.thresholdsGroup
                    console.log('threshold group from input')
                    //$ctrl.thresholdsGroup = 'cima_TESTTHR'; // uncomment for test group
                }else{
                    $ctrl.thresholdsGroup = 'cima_TESTTHR';
                    console.log('threshold group hard coded')
                }


                if($ctrl.resolve.model.sensorClass){
                    $ctrl.sensorClass = $ctrl.resolve.model.sensorClass
                    console.log('sensor class from input')
                }else{
                    $ctrl.sensorClass = 3;
                    console.log('sensor class hard coded')
                }





                //END OF binding test data

                //DEFINEL MODEL TO EDIT

                $ctrl.sensorModelBySensorClass={
                    3:{
                        "class": $ctrl.sensorClass,
                        "db": 2,
                        "group": $ctrl.thresholdsGroup,
                        "name": "",
                        "date":new Date(),
                        "period": -1,
                        "sensor": "",
                        "severity": 0,
                        "type": "max",
                        "value": 0
                    }
                };

                $ctrl.THRESHOLDS_MODEL={
                    3:{
                        'national_IDROMETRO':{
                            "THR_1":{
                                count :1,
                                color :'#fff811',
                                severity:1
                            },
                            "THR_2":{
                                count :1,
                                color :'#ffc31e',
                                severity:2
                            },
                            "THR_3":{
                                count :1,
                                color :'#FF0000',
                                severity:3

                            },
                            "MAX":{
                                count :10,
                                color :'#0d09ff',
                                severity:0
                            },
                        },
                        'cima_TESTTHR':{
                            "THR_1":{
                                count :1,
                                color :'#fff811',
                                severity:1
                            },
                            "THR_2":{
                                count :1,
                                color :'#ffc31e',
                                severity:2
                            },
                            "THR_3":{
                                count :1,
                                color :'#FF0000',
                                severity:3

                            },
                            "MAX":{
                                count :10,
                                color :'#0d09ff',
                                severity:0
                            },
                        }
                    }
                }

                //DEFINE MODEL TO EDIT END





                thresholdService.getThreshold($ctrl.featureProperties,function (data) {


                    $ctrl.aoThresholds = data.filter(function(oThresholds){
                        return oThresholds.group == $ctrl.thresholdsGroup;
                    });

                    $ctrl.aoThresholds.forEach(function (thr) {
                        if(thr.value) thr.oldvalue= thr.value;

                        thresholdService.getThresholdLastEditInfo(thr.id,function (data) {
                            thr.lastMod = data;
                        });

                    })

                    console.log($ctrl.aoThresholds)

                })


                console.log("changes")


            };

            $ctrl.formatDateForLabel = function(x){
                return moment(x).format('DD/MM/YYYY HH : mm')
            }

            $ctrl.formatDateForLabel = function(x){
                return moment(x).format('DD/MM/YYYY HH : mm')
            }

            $ctrl.$onChanges = function () {

                console.log("changes")
            };


            $ctrl.closePopup = function () {

                $ctrl.close()
            }


            $ctrl.update = function () {
                // $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                // $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

