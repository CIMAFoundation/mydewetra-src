/**
 * Created by Dario Rubado on 23/07/18.
 */
(function(){

    dewetraApp.component('eula',{
        templateUrl:'apps/dewetra2/js/components/EULA/eula.html', bindings: {
            layers: "=",
            onRemove: '&'
        },
        controller: ['$uibModal', 'acUserResource', '$rootScope','_', '$window', function($uibModal, acUserResource, $rootScope,_, $window){
            var ctrl = this;





            if(window.app.config.eula.enabled ){

                var sEulaVersion = 'eula-agreement-v1-2018';

                console.log(sEulaVersion);

                acUserResource.getResources('dewetra2',function (data) {

                    var index = _.findIndex(data,function (obj) {
                        return ((obj.resource ==sEulaVersion)&&(obj.user == $rootScope.acSession.user.id)&&(obj.value.indexOf("accepted")>-1))
                    })

                    if (index > -1){
                        console.log("EULA accepted : "+ data[index].value)

                        //debug purpose
                        //  var value= "denied-"+moment.utc($rootScope.getServerTime()).toISOString();

                        // acUserResource.saveResource('dewetra2',sEulaVersion,value,
                        //     function (data) {
                        //         console.log("Modded denied for debug pourpose");
                        //     })
                    }else{
                        //debug purpose
                        // if ($rootScope.acSession.user.id == "p5.campanella"||$rootScope.acSession.user.id == "dar5io.rubado")ctrl.openPopupEula();
                        if($rootScope.acSession.user.id)ctrl.openPopupEula();
                    }


                },function (data) {
                    // alert("No Eu/la Settings")
                });

            }






            ctrl.openPopupEula = function(){
                var modalInstance = $uibModal.open({

                    templateUrl: 'apps/dewetra2/js/components/EULA/eulaPopUp.html',
                    controller: function($scope, $uibModal, $uibModalInstance, $translate,AdvMessage, _, $rootScope, acUserResource) {

                        $scope.onLanguageSelected = function(){

                        };

                        $scope.redirectToHome= function(){
                            try{
                                if($rootScope.acSession.authenticated)
                                {
                                    $window.location.replace("apps/" + $rootScope.acPort.skin + "/dashboard_mydewetra.html#/?skin=3");
                                }
                            }catch(err){
                                console.log(err)
                            }
                        };




                        $scope.AdvMessage = AdvMessage;
                        $scope.closePopup = function () {

                            if ($scope.userAgreement){

                                var value= "accepted-"+moment.utc($rootScope.getServerTime()).toISOString();
                                acUserResource.saveResource('dewetra2',sEulaVersion,value,
                                    function (data) {
                                        $uibModalInstance.close();
                                    })

                            }else {
                                var value= "denied-"+moment.utc($rootScope.getServerTime()).toISOString();
                                acUserResource.saveResource('dewetra2',sEulaVersion,value,
                                    function (data) {
                                        $uibModalInstance.close();
                                    })

                                $uibModalInstance.close();
                            }

                        }
                    },
                    size: 'lg',
                    keyboard: false,
                    backdrop:'static',
                    resolve: {

                        AdvMessage: function () {

                            return {
                                title: "Manuale di RISICO",
                                subtitle: "Nuova pubblicazione manuale di RISICO",
                                messaggio : "E' disponibile il nuovo manuale di Risico presso questo link",
                                link: "#",
                                from:"Comunicazione"
                            };

                        }
                    }
                });
            };


        }]
    });


// dewetraApp.controller("languageCtrlEula",function($rootScope,$scope,$interval,$window,$translate, $controller){
//
//         angular.extend(this,$controller('languageCtrl',{$scope:$scope}));
//
//     });




    dewetraApp.component('languageSwitcher',{
        templateUrl:'apps/dewetra2/js/components/EULA/lang.html',
        bindings: {
            onSelect: '&'
        },
        controller:'languageCtrl'
        // controller: function($uibModal, acUserResource, $rootScope,_, $window){
        //     var ctrl = this;
        //
        //     ctrl
        //
        //
        //
        // }
    });


})();

