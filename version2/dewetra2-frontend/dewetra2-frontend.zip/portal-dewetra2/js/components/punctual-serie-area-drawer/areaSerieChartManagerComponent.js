/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('areaSerieChartManagerComponent', {
        template: `
<div class="popup" id="chartId">

    <div style="width: auto; ">

        <div class="head" id="sensorTitle">
            <div class="flex-container">
                <!--Title-->
                <div class="brand flex-item">
                    <i class="fa fa-line-chart animated bounceIn delay-002" ></i>
                    <p alt="{{ "punctual_serie_chart_title" | translate }}"  class="animated fadeInDown delay-001">
                        {{ "Time Series" | translate}}
                    </p>

                </div>
                <div class="brand flex-item">
                    <p class="animated fadeInLeft delay-003"><small>{{ "Time Series" }}</small></p>
                </div>

                <div class="flex-item">
                    <a class="close" ng-click="$ctrl.closePopup()" href>
                        <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="layer_view flex-container" id="sensorChooser">
            <div ng-repeat="oSerie in $ctrl.aoSerie |filter:allowSensor" class="flex-item" ng-click="$ctrl.changeSerie(oSerie)" >
                <a  href="" ng-class="{'active': oSerie.active}">
                    <p class="animated fadeInDown delay-002">{{(oSerie.title) | translate}}</p>
                </a>
            </div>


        </div>

        <div class="row">

        </div>

        <punctual-serie-chart-component serie="$ctrl.loadedSerie"></punctual-serie-chart-component>

        <div class="row" style="text-align: center">


<!--            <button ng-show="reloadButton.enabled" ng-click="reloadButton.reload()"  style=":not" type="button" class="btn " style="text-align: right" translate>UPDATE</button>-->


            <i data-title="UPDATE" ng-if="$ctrl.$rootScope.pendingRequests != 0"  style="color: #f59c1a;margin-right: 100px;" class="fa fa-refresh fa-spin fa-3x fa-fw" aria-hidden="true"></i>



        </div>








    </div>
</div>
`,
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        size: 'sm',
        controller: ['$uibModal', 'acUserResource', '$rootScope', '_', '$window', 'mapService', 'apiService', 'menuService', '$rootScope', '$translate', function ($uibModal, acUserResource, $rootScope, _, $window, mapService, apiService, menuService, $rootScope, $translate) {

            const $ctrl = this;

            $ctrl.$rootScope = $rootScope;

            $ctrl.oldLoadedSerie = null

            $ctrl.loadedSerie = null

            $ctrl.areaLimit = 200;

            $ctrl.closePopup = function () {
                $ctrl.close()
            }

            $ctrl.aoSerie = [];

            $ctrl.loadSeries = function(points){



                $ctrl.aoManager = mapService.oLayerList.aDraggable.concat(mapService.oLayerList.aUndraggable)

                var iCount = 0;

                if ($ctrl.aoManager.length  <= 0) {
                    return
                }

                $ctrl.aoManager.forEach(function (oManager) {

                    if(oManager.hasOwnProperty("areaSerie")){

                        oManager.areaSerie(points,function (data) {

                            let serieObj = {
                                series:data
                            }
                            serieObj.active = false;
                            serieObj.variable = $translate.instant(oManager.getVariable());
                            serieObj.aggregation = $translate.instant(oManager.getAggregation());
                            serieObj.name = $translate.instant(oManager.name());
                            serieObj.title = serieObj.name + ' ' +serieObj.aggregation + ' ' + serieObj.variable;
                            $ctrl.aoSerie.push(serieObj);

                            iCount++;

                            if($ctrl.aoManager.length== iCount) {
                                $ctrl.changeSerie($ctrl.aoSerie[0])
                            }

                        }, function (data) {
                            console.log(data)
                        })
                    }
                })
            }

            $ctrl.changeSerie = function(oSerie){

                if($ctrl.loadedSerie!= null)$ctrl.loadedSerie.active = false

                $ctrl.loadedSerie = oSerie

                oSerie.active = true

            };

            $ctrl.$onInit = function () {
                console.log("areaSerieChartManagerComponent");
                try {
                    $ctrl.loadSeries($ctrl.resolve.oPolygon.toGeoJSON().geometry.coordinates);
                }catch (e) {
                    console.log(e);
                }


            };




            $ctrl.update = function () {
                $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };


        }]
    });
})();
