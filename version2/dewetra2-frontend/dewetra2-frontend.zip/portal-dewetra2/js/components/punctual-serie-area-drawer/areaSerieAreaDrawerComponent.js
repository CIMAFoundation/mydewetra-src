/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('areaSerieAreaDrawerComponent', {
        template: '<i ng-click="$ctrl.activatePointer()"  class="fa ico-user_draw"></i>',
        // template: '<i ng-click="$ctrl.activatePointer()" ng-class="{active: $ctrl.active==true}" class="fa fa-edit"></i>',
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&',
            setCurrentTool: '&'
        },
        controller: ['mapService', '$uibModal', '$translate', function (mapService, $uibModal, $translate) {

            const $ctrl = this;

            $ctrl.active = false;

            let areaLimitConfig = 300;

            // const oFeatureLayer = L.featureGroup();
            //
            // const oWMSLayer = L.featureGroup();
            let oPolygon = null;

            const editableLayers = new L.FeatureGroup();

            // const options = {
            //     position: 'bottomleft',
            //     draw: {
            //         polygon: false,
            //         // polygon: {
            //         //     allowIntersection: false, // Restricts shapes to simple polygons
            //         //     drawError: {
            //         //         color: '#e1e058', // Color the shape will turn when intersects
            //         //         message: '<strong>Oh snap!<strong> you can\'t draw that!' // Message that will show when intersect
            //         //     },
            //         //     shapeOptions: {
            //         //         color: '#f32727'
            //         //     }
            //         // },
            //         polyline: false,
            //         circle: false,
            //         rectangle: {
            //             shapeOptions:{
            //                 color: '#f32727'
            //                 }
            //             },
            //         marker: false,
            //     },
            //     edit: {
            //         featureGroup: editableLayers, //REQUIRED!!
            //         remove: true
            //     }
            // };
            //
            // const optionsOnlyEdit = {
            //     position: 'bottomleft',
            //     draw: false,
            //     edit: {
            //         featureGroup: editableLayers, //REQUIRED!!
            //         remove: true
            //     }
            // };



            // let drawToolbar, editToolbar;


            $ctrl.closePopup = function () {
                $ctrl.close()
            }

            $ctrl.$onInit = function () {
                $ctrl.active = false;
            };

            $ctrl.activatePointer = function () {

                $ctrl.active = !$ctrl.active;

                if ($ctrl.active) {
                    $ctrl.loadDrawer();
                } else {
                    $ctrl.unLoadDrawer();
                }

            }

            checkPolygon = () => {

                let area;
                try {
                    area = parseInt(turf.area(oPolygon.toGeoJSON())/1000000);
                }catch (e) {
                    console.log(e);
                }
                if (area <= areaLimitConfig){
                    loadComponent();

                    oPolygon.unbindPopup();
                    oPolygon.pm.disable()
                }else {
                    let template = '<div><p>'+$translate.instant('POLYGON_TO_BIG_EDIT_PLEASE')+'</p></div>';
                    oPolygon.bindPopup(template);
                    oPolygon.openPopup();
                }
            }

            $ctrl.loadDrawer = () => {

                mapService.getMap().pm.enableDraw('Polygon',{
                    snappable: false,
                    layerGroup : editableLayers
                });

                mapService.getMap().on('pm:create', e => {
                    if (oPolygon != null) return
                    oPolygon = e.layer;
                    checkPolygon();

                    oPolygon.on('pm:edit',function (l){
                        // console.log(l);
                        oPolygon = l.layer
                        checkPolygon()
                    })
                    e.layer.pm.enable()



                });
            }

            loadComponent = () => {

                let modalInstance = $uibModal.open({
                    animation: true,
                    component: 'areaSerieChartManagerComponent',
                    size: 'lg',
                    resolve: {
                        oPolygon : () => {
                            return oPolygon
                        }
                    }
                });

                modalInstance.result.then((obj) => {
                    // console.log('modal-component dismissed at: ' + new Date());
                    modalInstance = null;
                    $ctrl.unLoadModalContinuingDrawing()

                }, () => {
                    // console.log('modal-component dismissed at: ' + new Date());
                    modalInstance = null;
                    $ctrl.unLoadModalContinuingDrawing()
                });
            }



            $ctrl.unLoadModalContinuingDrawing = () => {
                //callback per rimuovere setcurrent tool
                //$ctrl.close();

                if(oPolygon)oPolygon.unbindPopup();

                mapService.getMap().removeLayer(oPolygon);
                oPolygon = null;

                $ctrl.loadDrawer();

            }

            $ctrl.unLoadDrawer = () => {
                //callback per rimuovere setcurrent tool
                //$ctrl.close();

                if(oPolygon)oPolygon.unbindPopup();
                mapService.getMap().pm.disableDraw();
                mapService.getMap().removeLayer(oPolygon);
                oPolygon = null;
                editableLayers.clearLayers();
                mapService.getMap().removeLayer(editableLayers);

            }


        }]
    });


})();

