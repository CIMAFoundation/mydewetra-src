/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('damItalyChartComponent', {
        // templateUrl: 'apps/dewetra2/js/components/dam-italy-chart/damItalyChartComponent.html',
        template : `<div style="width: 100%">
                        <div style="width: 80vw;  margin:0 auto;" id="damItalyChart" ></div>
                    </div>`,
        bindings: {
            serie:'<',
            variable:'<',
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService','$rootScope','$translate','menuService','_','$timeout',function (mapService,$rootScope,$translate,menuService,_,$timeout) {
            var $ctrl = this;


            $ctrl.closePopup = function () {
                $ctrl.close()
            }



            $ctrl.$onInit = function () {
                console.log("damItalyChartComponent");





            };

            $ctrl.$onChanges = function (value) {

                //console.log(value.serie.currentValue);
                //console.log(value.variable.currentValue);





                $ctrl.height = menuService.oChartSize.m_iSensorChartHeight()

                $ctrl.chart = new Highcharts.StockChart($ctrl.chartOptions);

                // value.serie.previousValue
                //console.log("damItalyChartComponent");

                if(value.serie.currentValue !==value.serie.previousValue && value.serie.currentValue !==null){

                    $ctrl.setSerie()
                }

            };


            // $ctrl.initChart = function(){
            //     if($ctrl.chart){
            //         $ctrl.setSerie()
            //     }else {
            //         $ctrl.chart = new Highcharts.StockChart($ctrl.chartOptions);
            //         $ctrl.setSerie()
            //     }
            //     // $ctrl.chart.destroy();
            //
            //
            //
            //
            //
            // }




            $ctrl.setXAxis = function(dtFrom,dtTo){

            };


            $ctrl.setSerie = function(){

                console.log("setSerie");


                if (angular.isUndefined($ctrl.serie)|| angular.isUndefined($ctrl.chart)) return;


                //sort by timeline
                let list=[];

                for(let i in $ctrl.serie.timeline){

                    let o = {
                        t:$ctrl.serie.timeline[i],
                        v:$ctrl.serie.values[i]
                    }

                    list.push(o)
                }

                //list.sort(function(a, b){return a.t-b.t});

                //se ci sono piu timeline insieme le divido cosi



                // var aoTimeline =[];
                // let n = 0;
                // for (let i in list){
                //     if(list[i+1] && list[i+1].t < list[i].t) {
                //         n++;
                //     }
                //   //  console.log(list[i])
                //     if (list[i] && Number.isInteger(list[i].t) ) {
                //         if(!aoTimeline[n])aoTimeline[n] = [];
                //
                //         aoTimeline[n].push(list[i])// array di oggetti "serie"
                //
                //     }
                // }

                //console.log(aoTimeline)


                // var indexes = _.sortedIndex($ctrl.serie.timeline);
                // var new_timeline = _.map(indexes, i => $ctrl.serie.timeline[i]);
                // var new_values = _.map(indexes,i => $ctrl.serie.values[i]);
                //
                // $ctrl.serie.timeline = new_timeline;
                // $ctrl.serie.values = new_values;

                // var aTimeline = [];
                // var aValues=[];

                // list.forEach(function (x) {
                //     aTimeline.push( x.t)
                //     aValues.push( x.v)
                // })



                // $ctrl.serie.timeline = aTimeline;
                // $ctrl.serie.values = aValues;

                //sort by timeline end


                var max = _.max($ctrl.serie.values)
                var min = _.min($ctrl.serie.values, function (num) {
                    if (num > -9998) return num;
                })

                //$ctrl.serie.timeline = $ctrl.serie.timeline.reverse()
                //$ctrl.serie.values = $ctrl.serie.values.reverse()

                // if ($ctrl.serie.timeline) {
                //     for (var i = 0; i < $ctrl.serie.timeline.length; i++) {
                //
                //         var date = moment.utc($ctrl.serie.timeline[i]).valueOf();
                //
                //
                //
                //         // if ((date >= dtmin) && ($ctrl.serie.values[i] > -9998)) {
                //         if (($ctrl.serie.values[i] > -9998)) {
                //
                //             // values.push([date, parseFloat(sensorInfo.obs[i])])
                //             values.push([date, parseFloat($ctrl.serie.values[i])])
                //         }
                //
                //     }
                // }

                //posso aggiungere una nome alla serie nel campo title
                $ctrl.addSerieToChart(list, '' , $ctrl.variable)


                //aggiorno legenda e setto i valori
                // $ctrl.chart.series[0].update({
                //     name:$ctrl.serie.title + '  -  '+$translate.instant($ctrl.serie.variable),
                //     data: values,
                // },true)

                //aggiorno titolo chart
                // $ctrl.chart.yAxis[0].update({title:{
                //         text: '<p style="color:red">'+$translate.instant($ctrl.serie.variable)+'</p>'}
                // });

                //setto estremi
                $ctrl.chart.yAxis[0].setExtremes(parseFloat(min) *0.5,parseFloat(max)*1.5);

                $ctrl.chart.redraw();


            }

            $ctrl.addSerieToChart= function(aoSeriesData, title, variable){



                var aValues = [];

                if ($ctrl.chart.series.length > 0){
                    for(var i = $ctrl.chart.series.length - 1; i > -1; i--){
                        $ctrl.chart.series[i].remove()
                        }
                }

                if (aoSeriesData && aoSeriesData.length > 0){
                        for(let n in aoSeriesData){
                            let item = aoSeriesData[n]
                            if(item.v > -9998){
                                let date = moment.utc(item.t).valueOf()
                                let value = parseFloat(item.v)
                                aValues.push([date, value])
                            }
                        }

                        let serie = {
                            name: title + '  -  '+$translate.instant(variable),
                            type: 'line',
                            color: 'red',
                            threshold: null,
                            data: aValues,
                            showInLegend: true
                        };

                        console.log(serie)
                        $ctrl.chart.addSeries(serie,true)

                }


                $ctrl.chart.redraw()

            };

            $ctrl.setyAxis = function(dtFrom,dtTo){
                var from = value.serie.currentValue.timeline[0];
                var to = value.serie.currentValue.timeline[value.serie.currentValue.timeline.length-1];

                $ctrl.chart.xAxis[0].setExtremes(from,to)
            };





            $ctrl.update = function () {
                $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };

            $ctrl.chartOptions = {

                chart:{
                    renderTo: 'damItalyChart',
                    //marginTop: 25,
                    alignTicks: false,
                    zoomType: 'xy',
                    height: 600
                },
                options: {
                    global: {
                        useUTC: true
                    },
                    chart : {
                        backgroundColor:'rgba(255, 255, 255, 1)'
                    }
                },

                tooltip: {
                    useHTML: true,
                    crosshairs: true,
                    shared: true,
                    formatter: function() {

                        var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + $translate.instant('ORE') + ' ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div><br>';

                        this.points.forEach(function(item){
                            if (item.y > -9998) {
                                if (item.series.name) {

                                    s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: #FF0000">' +
                                        $('<div>' + '  ' + item.y.toFixed(2) + ' </div>').html() + '</div><br>';

                                }
                            }

                        });

                        return s;

                    }
                },
                credits: {
                    enabled: false
                },
                legend: {
                    enabled: true,
                    useHTML: true
                },

                //title: {
                //    style: {
                //        fontSize: '14px',
                //        fontWeight: 'bold',
                //        fontFamily: 'Open Sans'
                //    }
                //},
                //subtitle: {
                //    style: {
                //        fontSize: '14px',
                //        fontWeight: 'bold',
                //        fontFamily: 'Open Sans'
                //    }
                //},

                series: [
                    // {
                    //     "name": "fake series",
                    //     "type": "line",
                    //     "color": "green",
                    //     "threshold": null,
                    //     "data": [
                    //         [
                    //             1574067600000,
                    //             31.2
                    //         ],
                    //         [
                    //             1574154000000,
                    //             30.92
                    //         ],
                    //         [
                    //             1574240400000,
                    //             30.74
                    //         ],
                    //         [
                    //             1574326800000,
                    //             30.26
                    //         ]
                    //     ],
                    //     "showInLegend": true
                    // }



                ],
                exporting: {
                    chartOptions: {
                        rangeSelector: {
                            enabled: false
                        },
                        navigator: {
                            enabled: false
                        }
                    },
                    sourceWidth: 1500,
                    sourceHeight: 1000,

                },
                navigator: {
                    series: {
                        type: 'area',
                        fillOpacity: 0.3
                    },
                    enabled : true

                },
                scrollbar: {
                    enabled: false
                },
                xAxis: {
                    type: 'datetime',
                    minRange: 12 * 24 * 3600 * 1000,                                   // one day
                    tickPixelInterval: 50,
                    minorTickInterval: 'auto',
                    lineWidth: 2,
                    gridLineWidth: 2,
                    lineColor: 'black',
                    title: {
                        margin: 0,
                        text: 'Time UTC',
                        style: {
                            fontWeight : 'bold',
                            fontFamily: 'Open Sans'
                        }
                    },
                    labels: {
                        style: {
                            fontFamily: 'Open Sans',
                            textTransform: 'lowercase'
                        },
                        formatter: function () {
                            var oDate = new Date(this.value);
                            if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                                return '<b>' + Highcharts.dateFormat('%d %b', this.value) + '</b>';
                            else
                                return Highcharts.dateFormat('%H:%M', this.value);
                        }

                    },
                    plotLines: [
                        {
                            color: 'rgba(69, 163, 202, 1)', // Color value
                            dashStyle: 'Solid',             // Style of the plot line. Default to solid
                            value: new Date().getTime(),    // Value of where the line will appear
                            width: '2',                     // Width of the line
                            zIndex: 4
                        }
                    ],
                    events: {

                        setExtremes: function(e) {
                            //all -> 1 giorno -> 3 giorni
                            if (e.rangeSelectorButton) {

                                var c = e.rangeSelectorButton.count;

                                if (c == 3) {
                                    rangeSelected = 0;
                                } else if (c == 12) {
                                    rangeSelected = 1;
                                } else {
                                    rangeSelected = 2;
                                }

                                //} else {
                                //    if (!chart.rangeSelector) {
                                //        var subTitle = ('Dati dal ' + moment(e.min/1000, 'X').format('DD/MM/YYYY') + ' al ' + moment(e.max/1000, 'X').format('DD/MM/YYYY'));
                                //        chart.setTitle(null, { text: subTitle });
                                //    }

                            }

                        }

                    }

                },
                plotOptions: {
                    series: {
                        dataGrouping: {
                            enabled: true,
                            approximation :"high"
                        },
                        animation: false
                    },
                    line: {
                        marker: {
                            enabled: true,
                            radius: 1
                        }
                    },
                    area: {
                        marker: {
                            enabled: true,
                            radius: 1
                        }
                    }
                },
                rangeSelector : {

                    // buttonTheme: { // styles for the buttons
                    //     width: 50,
                    //     fill: 'none',
                    //     stroke: 'none',
                    //     'stroke-width': 0,
                    //     r: 3,
                    //     style: {
                    //         fontWeight: 'bold',
                    //         fontSize: '12px',
                    //         fontFamily: 'Open Sans',
                    //     },
                    //     states: {
                    //         hover: {
                    //         },
                    //         select: {
                    //             fill: '#525052',
                    //             style: {
                    //                 color: 'white'
                    //             }
                    //         }
                    //     }
                    // },
                    //
                    // buttons : [{
                    //     type : 'hour',
                    //     count : 3,
                    //     text : 'Last 3h'
                    // }, {
                    //     type : 'hour',
                    //     count : 12,
                    //     text : 'Last 12h'
                    // },
                    //     {
                    //         type : 'all',
                    //         text : 'Last 24h'
                    //     }],

                    inputEnabled : false,
                     enabled : false

                },
                yAxis: [{ // Primary yAxis
                    ordinal: false,
                    // min : objExtremes.min,
                    // max : objExtremes.max,
                    // tickInterval: objExtremes.tickInterval,
                    showLastLabel : true,
                    allowDecimals: true,
                    alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                    labels: {
                        x: 25,
                        y: 5,
                        format: '{value:.0f}',
                        style: {
                            color: 'red',
                            fontFamily: 'Open Sans',
                            textTransform: 'lowercase'
                        }
                    },
                    title: {
                        rotation: 270,
                        margin: 0,
                        offset: 45,
                        useHTML:true,
                        // text: '<p style="color:red">' + $translate.instant('$ctrl.serie.valuesLabel') + ' MU</p>',
                        text: '<p style="color:red"></p>',
                        // LivelloInvaso [m], VolumeInvaso [Mil m^3], PortataScaricata [m^3/s], PortataDerviata  [m^3/s] , PortataAdduzione  [m^3/s]



                        // text: '<p style="color:red">' + $translate.instant($ctrl.serie.title+'_'+$ctrl.serie.valuesLabel+'_MU') + '</p>',
                        style: {
                            fontWeight : 'bold',
                            fontFamily: 'Open Sans'
                        }
                    },
                    opposite: true
                }
                ],
                loading: false

            }

        }]
    });


})();

