
/**
 * Created by dario on 27/10/16.
 */



(function() {


    dewetraApp.component('laminazioneGeneric', {
        //templateUrl: 'apps/dewetra2/js/components/timebar/timebar.html',
        template : `
            <div class="laminazione">
    <div class="modal-header">
        <div class="flex-container" id="sensorTitle">
            <!--Title-->
            <div class="brand flex-item">

                <h3 class="modal-title" id="modal-title">Laminazione {{$ctrl.resolve.params.nameDam}}</h3>
            </div>

            <div class=" flex-item">
                <a class="close" ng-click="$ctrl.closePopup()" href>
                    <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                </a>
            </div>
        </div>
    </div>

    <div class="modal-body" id="modal-body">

        <div id="wizard-step-container">
            <ul class="nav nav-pills nav-justified">
                <li ng-repeat="step in $ctrl.steps" ng-class="{'active':step.step == $ctrl.currentStep}">
                    <a ng-click="$ctrl.gotoStep(step.step)" href="">{{step.step}}. {{step.name}}</a>
                </li>
            </ul>
        </div>
        <div id="wizard-content-container" class="">

            <ng-include src="$ctrl.getStepTemplate()"></ng-include>
        </div>


    </div>



    <div class="modal-footer">
        <div ng-show="$ctrl.pendingRequests != 0" class="loader loader--style1" title="0" style="position:fixed; z-index:9999;">
            <svg version="1.1" id="loader-1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                 width="40px" height="40px" viewBox="0 0 40 40" enable-background="new 0 0 40 40" xml:space="preserve">
\t\t    <path opacity="0.2" fill="#000" d="M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946
\ts14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634
\tc0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z"/>
                <path fill="#000" d="M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0
\tC22.32,8.481,24.301,9.057,26.013,10.047z">
\t\t    <animateTransform attributeType="xml"
                              attributeName="transform"
                              type="rotate"
                              from="0 20 20"
                              to="360 20 20"
                              dur="0.5s"
                              repeatCount="indefinite"/>
            </path>
\t        </svg>
        </div>
        <!--<button class="btn btn-primary" type="button" ng-click="update()">OK</button>-->
        <button class="btn btn-warning" ng-class="{'disabled':($ctrl.pendingRequests != 0)}" type="button" ng-click="$ctrl.closePopup()">Cancel</button>
        <button ng-disabled="$ctrl.currentStep <= 1" ng-class="{'disabled':($ctrl.pendingRequests != 0)}" class="btn btn-default" name="previous" type="button" ng-click="$ctrl.gotoStep($ctrl.currentStep - 1)"><i class="fa fa-arrow-left"></i> Previous step</button>
        <button ng-disabled="$ctrl.currentStep >= $ctrl.steps.length ||$ctrl.currentStep == 2" ng-class="{'disabled':($ctrl.pendingRequests != 0)}" class="btn btn-primary" name="next" type="button" ng-click="$ctrl.gotoStep($ctrl.currentStep + 1)">Next step <i class="fa fa-arrow-right"></i></button>
        <!--<button ng-disabled="currentStep != steps.length" class="btn btn-success" name="next" type="button"> <i class="fa fa-floppy-o"></i> Save</button>-->
    </div>

</div>

            `,
        bindings: {
            resolve:'<',
            close: '&',
            dismiss: '&'
        },
        controller: ['$rootScope','$timeout', '$translate', 'laminazioneGenericService','menuService','_', function ($rootScope,$timeout, $translate, laminazioneService,timeService,_) {

            const $ctrl = this;

            $ctrl.options = {
                currentChart :{}
            };

            $ctrl.runStepData = {};

            console.log("laminazione component init");

            $ctrl.currentStep = 1;

            $ctrl.oConfig  = {
                q_turb:0,
                delta_drawdown:0,
                SM:0,
                current_release:0,
                // conf: null
            };



            $rootScope.$watch('pendingRequests', function(){
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });



            $ctrl.summaryData = {};

            $ctrl.steps = [
                {
                    step: 1,
                    name: "Selezione Input di previsione",
                    template: "apps/dewetra2/js/components/laminazione-generic/step/inputPrevBis.html"
                },
                {
                    step: 2,
                    name: "Riepilogo",
                    template: "apps/dewetra2/js/components/laminazione-generic/step/riepilogo.html"
                },
                {
                    step: 3,
                    name: "Input Manovre",
                    template: "apps/dewetra2/js/components/laminazione-generic/step/inputManovre.html"
                },
                {
                    step: 4,
                    name: "Run",
                    template: "apps/dewetra2/js/components/laminazione-generic/step/run.html"
                },
                {
                    step: 5,
                    name: "Chart",
                    template: "apps/dewetra2/js/components/laminazione-generic/step/chart.html"
                },
                {
                    step: 6,
                    name: "Risultati",
                    template: "apps/dewetra2/js/components/laminazione-generic/step/risultati.html"
                },
            ];


            $ctrl.loadForecast = function () {
                return $ctrl.resolve.params.confDams[$ctrl.resolve.params.nameDam].input;
           }

           $ctrl.forecastSelected = function () {
               //console.log($ctrl.oConfig.conf)
               laminazioneService.loadLaminazioneData($ctrl.resolve.params.nameDam, $ctrl.oConfig.conf, function (data) {
                   console.log(data)
                   $ctrl.summaryData = data;
                   $ctrl.oConfig.minDate = moment.utc(new Date($ctrl.summaryData.t_start));
                   $ctrl.oConfig.maxDate = moment.utc(new Date($ctrl.summaryData.t_end));
                   $ctrl.gotoStep(2);
               })
           }


            $ctrl.dateOption = function(index){
                // console.log(index);
                return{
                    dropdownSelector: 'sel'+index,
                    minView:'hour',
                    // minDate:$ctrl.dateToOption.minDate,
                    // maxDate:$ctrl.dateToOption.maxDate,
                }
            }




            //non far accedere al secondo step direttamente
            $ctrl.checkNgClickOnNext = function(newStep, callback){

                if( newStep != 2){
                    callback(newStep)
                }

            }

            // $ctrl.$watch('oConfig.qturb',function () {
            //
            //     if($ctrl.currentStep == 2){<
            //         if($ctrl.oConfig.qturb < 0 || $ctrl.oConfig.qturb >= 200 || $ctrl.oConfig.qturb === undefined) {
            //             alert("qturb should be from 0 to 200")
            //             $ctrl.oConfig.qturb = 0
            //         }
            //     }
            // })

            $ctrl.checkQturb = () => {
                // if($ctrl.currentStep == 2){
                //     if($ctrl.oConfig.qturb < 0 || $ctrl.oConfig.qturb >= 200 || $ctrl.oConfig.qturb === undefined) {
                //         alert("qturb should be from 0 to 200")
                //         $ctrl.oConfig.qturb = 0
                //     }
                // }
            }




            $ctrl.gotoStep = function(newStep, skipCondition) {

                console.log("change step");
                if($ctrl.currentStep ==2){
                    //check the value
                    let condition= true

                    Object.keys($ctrl.oConfig).map((sName) => {
                        if($ctrl.oConfig[sName] == null){
                            alert('check: %s', sName);
                            condition = false
                        }
                    })
                    if (condition)$ctrl.currentStep = newStep;
                }
                $ctrl.currentStep = newStep;
            }


            $ctrl.getStepTemplate = function(){
                for (var i = 0; i < $ctrl.steps.length; i++) {
                    if ($ctrl.currentStep == $ctrl.steps[i].step) {
                        return $ctrl.steps[i].template;
                    }
                }
            }

            // $ctrl.loadData= function(){
            //     // $ctrl.oConfig.conf model data scelta serie input Prev
            //     laminazioneService.loadLaminazioneCorbaraFirstData($ctrl.oConfig.conf, function (data) {
            //         $ctrl.firstScriptResult = data;
            //         $ctrl.updateChartData(data);
            //     },function (data) {
            //         alert("La previsione richiesta non è diponibile");
            //         $ctrl.gotoStep(1);
            //         console.log("error LoadData")
            //     });
            // };

            $ctrl.updateChartData= function(data, string){
                console.log("chartData updated:"+(string)?string:"");
                $ctrl.chartData = data.charts;
                $ctrl.warnings = data.warnings;
                // console.log(data)
            };



            $ctrl.toLocalTimeString = function(date){
                // var tzOffSet = Math.abs(date.getTimezoneOffset())*60000;
                try{
                    var date = new Date(date.getTime());
                    return moment(date).format('lll');
                }catch (e) {
                    // console.log(e)
                }


            };





            $ctrl.loadOptimisationScript = function () {
                laminazioneService.postConfigurazioneOptimisationScript($ctrl.resolve.params.nameDam, $ctrl.oConfig, function (modalObj, data) {

                    $ctrl.runStepData = data.table;

                    $ctrl.resultsData = data.summary;

                    $ctrl.loadManovre(data);

                    $ctrl.updateChartData(data, "Second Script");
                    $ctrl.gotoStep(4,);
                })
            };

            $ctrl.loadManovre = function (data) {

                // date:new Date(newDate.getTime() + tzOffset * 60000),
                //     percentage:100,
                //     level:data["rel_level"][i],
                //     pturb:data["rel_turb"][i],
                //     // pturb:0,
                //     value: data["rel"][i],
                //     name: "Manovra "+i,
                //     descr:"rel"
                $ctrl.modelObject = [];
                if(data.t_rel && data.rel){
                    for(let i in data.t_rel){

                        $ctrl.modelObject.push({
                            date: new Date(data.t_rel[i]), //2021-11-03 16:00:00
                            value: data.rel[i],
                            name: 'Manovra - '+ i
                        })
                    }

                    $ctrl.modelObject = $ctrl.modelObject.filter(m => moment(m.date).isValid())
                    console.log($ctrl.modelObject);
                }else {
                    console.log("Something wrong in " , data);
                }



            }

           $ctrl.loadVerificationScript = function (callback) {
               laminazioneService.postConfigurazioneVerificationScript($ctrl.resolve.params.nameDam, $ctrl.oConfig, function (data) {
                   for(var i in $ctrl.modelObject){
                       $ctrl.modelObject[i].value = data["rel"][i]
                       $ctrl.modelObject[i].date = new Date(data["t_rel"][i])
                   }

                   $ctrl.modelObject = $ctrl.modelObject.filter(m => moment(m.date).isValid())

                   $ctrl.resultsData = data.summary;

                   $ctrl.runStepData = data.table;

                   $ctrl.updateChartData(data,  "third Script");

                   if (callback) callback()
               },function (err) {
                   console.log(err)
               },$ctrl.modelObject,$ctrl.oConfig.q_turb)
           }


            // $ctrl.loadThirdScript= function(callback){
            //
            //     laminazioneService.postConfigurazioneThirdScript($ctrl.oConfig,function (data) {
            //
            //         //rebuild
            //
            //         for(var i in $ctrl.modelObject){
            //             $ctrl.modelObject[i].level = data["rel_level"][i]
            //             $ctrl.modelObject[i].pturb = data["rel_turb"][i]
            //         }
            //
            //
            //
            //         $ctrl.updateChartData(data,  "third Script");
            //
            //         if (callback) callback()
            //
            //
            //     },function (err) {
            //         console.log(err)
            //     },$ctrl.modelObject,$ctrl.oConfig.qturb)
            // };

            $ctrl.run = function () {

                $ctrl.loadVerificationScript(function () {
                    $ctrl.gotoStep(4, true)

                    $timeout(function () {
                        $ctrl.loadChart("level")
                    },1000)
                });


            }

            $ctrl.livelloInvaso = 130;

            $ctrl.dateTo = moment(new Date(timeService.getDateTo())).format('lll');
            $ctrl.dateFrom = moment(new Date(timeService.getDateFrom())).format('lll');




            $ctrl.maxDate =function(dates){
                var iMaxDate = laminazioneService.dateTo().getTime()+ (72*60*60000)

                for(var i=0; i<dates.length;i++) {
                    if(iMaxDate < dates[i].utcDateValue) {
                        dates[i].selectable = false;
                    }
                }
            }

            $ctrl.addManovra = function(){

                if(o) delete o;

                // var diff= 60*($ctrl.modelObject.length+1);//moltiplicavo incrementale per 3 ore

                var diff = 60*3;//moltiplico per 3 ore

                if($ctrl.modelObject.length > 0){//se è presente almeno una manovra imposto la data della manovra precedente + 3 ore
                    try {//serve solo per non generare un errore se vanno all input manovre senza avere un t_start e quindi una prima manovra gia impostata
                        var oDate = new Date($ctrl.modelObject[$ctrl.modelObject.length-1].date.getTime()+ diff*60000);
                    }catch (e) {
                        var oDate = new Date();
                    }


                }else{
                    //altrimenti uso la data t_start

                    if($ctrl.oConfig.minDate.isValid()) {
                        var oDate =new Date($ctrl.oConfig.minDate.utc().toDate())
                        //  console.log(oDate)
                    }

                    // var oDate = new Date(Date.UTC($ctrl.t_start.toDate()));
                }


                // data-before-render="beforeRender($view, $dates, $leftDate, $upDate, $rightDate)"
                var o = {
                    date:oDate,
                    maxDate:function ($dates,oManovraBefore,$view,  $leftDate, $upDate, $rightDate) {
                        // var tzOffSet =Math.abs(oDate.getTimezoneOffset())

                        let iMinDate = $ctrl.oConfig.minDate.valueOf();

                        if(oManovraBefore){
                            iMinDate = oManovraBefore.date.valueOf();
                        }


                        //data max 72 ore dopo
                        var iMaxDate = $ctrl.oConfig.maxDate.valueOf()+ (72*60*60000)

                        for(var i=0; i<$dates.length;i++) {
                            if(iMaxDate < $dates[i].utcDateValue || $dates[i].utcDateValue < iMinDate) {
                                $dates[i].selectable = false;
                            }
                        }
                    },
                    percentage:100,
                    value:0,
                    time:100,
                    name:"Manovra "+(parseInt($ctrl.modelObject.length)+1),
                    descr:"rel"
                };

                // o.date =

                $ctrl.modelObject.push(angular.copy(o));
            };

            $ctrl.removeManovra = function(index){
                $ctrl.modelObject.splice(index,1);

                for(let i in $ctrl.modelObject){
                    let number = parseInt(i);
                    number +=1;
                    $ctrl.modelObject[i].name = "Manovra "+ number;
                }


            };



            $ctrl.dateTimeConfig = function(manovra,index){

                return{
                    // modelType:,
                    dropdownSelector: 'sel'+index,
                    startView:'hour',
                    minView:'hour',
                    // timezone:'utc'
                }
            };

            $ctrl.beforeRender = function($view, $dates, $leftDate, $upDate, $rightDate){
                console.log($view)
                console.log($dates)
            };

            $ctrl.onSetTime = function(newDate, oldDate,paratoia){
                var tzOffset = newDate.getTimezoneOffset();
                // console.log(tzOffset);

                paratoia.date = new Date(newDate.getTime() );

                // console.log(newDate);

                // console.log(paratoia)
            };

            // function

            /* ripristinare in modo differente

            $ctrl.$watch('t_start',function () {

                if($ctrl.modelObject.length == 0){

                    if($ctrl.t_start)$ctrl.addManovra();

                }
            });*/

            $ctrl.modelObject = [];


            $ctrl.downloadManovre = function(){
                var encodedUri = encodeURI(laminazioneService.exportManovreToCsv($ctrl.modelObject));
                var link = document.createElement("a");
                link.setAttribute("href", encodedUri);
                link.setAttribute("download", "manovre.csv");
                link.innerHTML= "Click Here to download";
                // document.body.appendChild(link); // Required for FF

                link.click();
            };

            $ctrl.dateFormatter = function(date){

                // return moment.utc(date).format('DD-MM-YYYY HH:mm')+" Ora locale (UTC"+moment(date).format('Z)');
                return moment.utc(date).format('DD-MM-YYYY HH:mm')+" (UTC)";
                // return date.toISOString()

            };

            $ctrl.ottimizzaManovre = function(){
                $ctrl.loadSecondScript()
            };

            $ctrl.verificaManovre = function(){
                $ctrl.gotoStep(3);

            };

            $ctrl.loadChart = function (chartValue) {
                console.log(chartValue);
                $ctrl.options.currentChart = chartValue;
            }



            $ctrl.onLocationSelected = function (location) {
                if($ctrl.close)$ctrl.dismiss(location);
            };

            $ctrl.update = function () {
                if($ctrl.close)$ctrl.close();

            };

            $ctrl.closePopup = function () {
                // $uibModalInstance.dismiss('cancel')
                if($ctrl.close)$ctrl.close();

            };


            $ctrl.$onChanges = (changes) => {
                // $ctrl.resolve.currentValue.params.confDams.MERCATALE

                if(changes.resolve.currentValue && changes.resolve.currentValue.params && changes.resolve.currentValue.params.confDams && Object.keys(changes.resolve.currentValue.params.confDams).length > 0){

                }

            };

            $ctrl.$onInit =  () => {


            };


        }]
    });
})();
