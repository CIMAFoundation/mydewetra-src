(function(){


    dewetraApp.service('laminazioneGenericService',['serieService', 'menuService', 'apiService','_', function (serieService, timeService, apiService,_) {


        let confDamsObj = {
            'MERCATALE':{
                'input': {
                    'FP Marche Det Cosmoi2':[
                        {
                            server: 1,
                            serie: "marche.floodproofs.deterministiclami",
                            featureId: 'Mercatale, Diga',
                            name: "qin_main"
                        },
                        {
                            server:1,
                            serie:"all.sensor.hydrometers",
                            featureId: "210822514;2",
                            name:"h_current"
                        }
                    ],
                    'FP Marche Det ECMWF': [
                        {
                            server: 1,
                            serie: "marche.floodproofs.deterministicecmwf",
                            featureId: 'Mercatale, Diga',
                            name: "qin_main"
                        },
                        {
                            server:1,
                            serie:"all.sensor.hydrometers",
                            featureId: "210822514;2",
                            name:"h_current"
                        }
                    ]
                }
            }
        };




        var postFirstScript = null;

        var postThirdScript = null

        var lastManovre = null;

        var firstScriptResult =null;
        var secondScriptResult =null;
        var thirdScriptResult =null;

        var fourthScriptInput =null;

        var fourthScriptResult =null;


        var oFrom = moment(new Date(timeService.getDateFrom()));

        var oTo = moment(new Date(timeService.getDateTo()));
//summary, optimisation e verification Propagation(only for some dams like corbara)

        var oInitialData,oOptimisationData, oVerificationData, oPropagationData,oSummaryScriptResult, oOptimisationScriptResult, oVerificationScriptResult, oPropagationScriptResult;

        alertError = (data) => {
            if(data.hasOwnProperty('errors') && data.errors.length == 1 && Object.keys(data.errors[0]).length >= 1){
                Object.keys(data.errors[0]).map(e => {
                    if(data.errors[0][e] != null && data.errors[0][e].hasOwnProperty('label')) {
                        alert(data.errors[0][e].label);
                    }
                })
            }
        };

        return{

            setConfObj: (data)=>{
                confDamsObj = data;
            },

            getConfObj: ()=>{
                return confDamsObj;
            },

            setSummaryScriptResult: (data) => {
                oSummaryScriptResult = data;
            },
            getSummaryScriptResult: () => {
                return oSummaryScriptResult;
            },

            setOptimisationScriptResult: (data) => {
                oOptimisationScriptResult = data;
            },
            getOptimisationScriptResult: () => {
                return oOptimisationScriptResult;
            },

            setVerificationScriptResult: (data) => {
                oVerificationScriptResult = data;
            },
            getVerificationScriptResult: () => {
                return oVerificationScriptResult;
            },

            setPropagationScriptResult: (data) => {
                oPropagationScriptResult = data;
            },
            getPropagationScriptResult: () => {
                return oPropagationScriptResult;
            },

            dateRef:function(){
                return oFrom.toDate();
            },

            dateTo:function(){
                return oTo.toDate();
            },

            getFourthScriptResult:function(){
                return fourthScriptResult;
            },

            getLevelChartData:function(){

                return{
                    hres_a:firstScriptResult.hres_a,
                    hmax:firstScriptResult.hmax,
                    t_qin_main:firstScriptResult.t_qin_main
                }
            },

            loadLaminazioneDataFake: function (sDams, sConfig, okCallback,koCallback) {
                const _Service = this;

                const series = {};

                _Service.postConfigurazioneSummaryScriptFake(sDams, series, okCallback,koCallback);
            },

            loadLaminazioneData: function (sDams, aObjForecast, okCallback, koCallback) {
                const _Service = this;
                const from = timeService.getDateFromUTCSecond();
                const to = timeService.getDateToUTCSecond();

                const series = {};

                let itemProcessed = 0;

                // _Service.postConfigurazioneSummaryScript(sDams, series, okCallback,koCallback);


                aObjForecast.forEach(function (obj, index, array) {

                    serieService.getSeriesDirect(obj.server,obj.serie,obj.featureId,from, to,function (data) {
                        series[obj.name] = data;
                        itemProcessed++;
                        if(array.length == itemProcessed){
                            _Service.postConfigurazioneSummaryScript(sDams, series, okCallback,koCallback);
                        }
                    },koCallback)
                });

            },

            loadLaminanazioneInputData: function (sDams, sConfig, okCallback,koCallback) {
                const _Service = this;
                const from = timeService.getDateFromUTCSecond();
                const to = timeService.getDateToUTCSecond();

                const series = {};

                let itemProcessed = 0;


                confObj[sDams]['input'][sConfig].forEach(function (obj,index, array) {
                    serieService.getSeriesDirect(obj.server,obj.serie,obj.featureId,from, to,function (data) {
                        series[obj.name] = data;
                        itemProcessed++;
                        if(array.length == itemProcessed){
                            _Service.postConfigurazioneSummaryScript(sDams, series, okCallback,koCallback);
                        }
                    },koCallback)
                })
            },

            postConfigurazioneSummaryScriptFake:function (sDams, series, okCallback,koCallback) {


                let obj1 ={
                    "alg": sDams+".laminazione.summary",
                    "input":{
                        "qin_main":[9.50,9.98,9.98,41.96,71.76,81.13,84.50,83.83,59.25,56.00,48.92,40.71,32.68,29.06,27.86,26.67,23.72,23.14,
                            21.40,20.82,19.68,19.11,17.98,18.55, 17.42, 17.42],
                        "t_qin_main":[1612947600, 1612951200, 1612954800, 1612958400, 1612962000, 1612965600, 1612969200,
                            1612972800, 1612976400, 1612980000, 1612983600, 1612987200, 1612990800, 1612994400,
                            1612998000, 1613001600, 1613005200, 1613008800, 1613012400, 1613016000, 1613019600,
                            1613023200, 1613026800, 1613030400, 1613034000,  1613037600],
                        "h_current":["219"],
                        "t_h_current":["2021-02-10T10:00:00Z"],
                        "from_date":1574376242.297,
                        "to_date":1612951200.297
                    }
                };


                oInitialData = obj1;

                apiService.postExtJson(window.app.url.laminazione70Url,obj1,function (data) {
                    oSummaryScriptResult = data;

                    if(okCallback)okCallback(data)
                },function (data ) {
                    alert(data);
                })

            },


            postConfigurazioneOptimisationScript:function (sDam, oConfig, okCallback,koCallback) {
                const _This = this;
                //vuole gli stessi input del primo ritorna 6 manove e portata turbinata
                if(oInitialData){

                    oOptimisationData = angular.copy(oInitialData);

                    //quando carico il secondo script sovrascrivo sempre questi dati inseriti dall'utente?
                    oOptimisationData["alg"] = sDam+".laminazione.optimisation";
                    oOptimisationData["input"]["q_turb"]=oConfig.q_turb;
                    oOptimisationData["input"]["delta_drawdown"]=oConfig.delta_drawdown;
                    oOptimisationData["input"]["SM"]=oConfig.SM;
                    oOptimisationData["input"]["current_release"]=oConfig.current_release;

                    apiService.postExtJson(window.app.url.laminazione70Url,oOptimisationData,function (data) {
                        oOptimisationScriptResult= data;
                        var modalObj =[] ;

                        alertError(data);

                        if(data.hasOwnProperty("t_rel")&&data.hasOwnProperty("rel")) {
                            for(var i in data["t_rel"]){
                                const newDate = new Date(data["t_rel"][i]);




                                var obj = {
                                    date:moment(newDate),
                                    percentage:100,
                                    value: data["rel"][i],
                                    name: "Manovra "+i,
                                    descr:"rel"
                                };
                                // console.log(obj);
                                if(moment(obj.date).isValid())modalObj.push(obj);
                            }
                        }

                        oPropagationData = oOptimisationScriptResult;

                        _This.postConfigurationPropagationScript(sDam,function (data) {
                            console.log("FourthScript")
                            console.log(data);
                            oPropagationScriptResult = data
                        },function (data) {
                            oPropagationScriptResult = data
                        })

                        //edit data to be fitted in modal obj
                        if (okCallback)okCallback(modalObj,data);
                    },function () {
                        alert("error");
                    })
                }
            },

            postConfigurazioneSummaryScript:function (sDams, series, okCallback,koCallback) {
                if(!Array.isArray(series['h_current'] )){
                    series['h_current'] = [series['h_current']]
                }

                const forecastArrayIndex = 1;

                if (series['h_current'] && series['h_current'][0] && !series['h_current'][0].hasOwnProperty('values')  ){
                    alert("**** NO DAM LEVEL! \n" +
                        "Nella finestra temporale indicata il dato di livello diga non è disponibile.\n"+
                    "Provvedere all'aggiunta del dato nel database Marche e rilanciare il tool dopo almeno un'ora!")
                    return
                }



                let obj = {
                        "alg": sDams+".laminazione.summary",
                    "input":{
                        "qin_main": series['qin_main'][forecastArrayIndex].values.map(parseFloat),
                        "t_qin_main": series['qin_main'][forecastArrayIndex].timeline.map(x => moment(x).valueOf()/1000),
                        //"h_current" : [218.5],
                        "h_current" : [parseFloat(series['h_current'][0].values)],
                        //"t_h_current": [moment(timeService.getDateTo()).toISOString()],
                        "t_h_current": [series['h_current'][0].timeline],
                        "from_date" : timeService.getDateFromUTCSecond(),
                        "to_date" : timeService.getDateToUTCSecond()
                    }
                };

                // let obj1 ={
                //     "alg": sDams+".laminazione.summary",
                //     "input":{
                //         "qin_main":[9.50,9.98,9.98,41.96,71.76,81.13,84.50,83.83,59.25,56.00,48.92,40.71,32.68,29.06,27.86,26.67,23.72,23.14,
                //             21.40,20.82,19.68,19.11,17.98,18.55, 17.42, 17.42],
                //         "t_qin_main":[1612947600, 1612951200, 1612954800, 1612958400, 1612962000, 1612965600, 1612969200,
                //             1612972800, 1612976400, 1612980000, 1612983600, 1612987200, 1612990800, 1612994400,
                //             1612998000, 1613001600, 1613005200, 1613008800, 1613012400, 1613016000, 1613019600,
                //             1613023200, 1613026800, 1613030400, 1613034000,  1613037600],
                //         "h_current":["219"],
                //         "t_h_current":["2021-02-10T10:00:00Z"],
                //         "from_date":1574376242.297,
                //         "to_date":1612951200.297
                //     }
                // };

                oInitialData = obj;

                apiService.postExtJson(window.app.url.laminazione70Url,oInitialData,function (data) {
                    oSummaryScriptResult = data;

                    alertError(data);

                    if(okCallback)okCallback(data)
                },function (data ) {
                    alert(data);
                })

            },

            //TODO
            postConfigurazioneVerificationScript:function (sDams, oConfig, okCallback,koCallback, manovre, portata) {
                var _This = this;
                //vuole gli stessi input del primo ritorna 6 manove e portata turbinata
                if(oInitialData && manovre){
                    oVerificationData = angular.copy(oInitialData);

                    lastManovre= manovre;

                    oVerificationData["alg"] = sDams+".laminazione.verification";
                    oVerificationData["input"]["q_turb"]=oConfig.q_turb;
                    oVerificationData["input"]["delta_drawdown"]=oConfig.delta_drawdown;
                    oVerificationData["input"]["SM"]=oConfig.SM;
                    oVerificationData["input"]["current_release"]=oConfig.current_release;


                    oVerificationData["input"]["t_rel"]= [];
                    oVerificationData["input"]["rel"]= [];



                    manovre.forEach(function (manovra,index,array) {
                        // 2021-11-10 14:00:00
                        let sDate = moment( manovra.date).format('YYYY-MM-DD HH:mm:ss');

                        oVerificationData["input"]["t_rel"].push(sDate);
                        oVerificationData["input"]["rel"].push(manovra.value);

                    });

                    oVerificationData["input"]["qturb"]=portata;
                    oVerificationData["input"]["nrel"]=manovre.length;

                    console.log(oVerificationData)

                    apiService.postExtJson(window.app.url.laminazione70Url,oVerificationData,function (data) {
                        oVerificationScriptResult = data;
                        alertError(data);

                        oPropagationData = oVerificationData;
                        try {
                            _This.postConfigurazioneFourthScript(function (data) {

                                oPropagationScriptResult = data
                            },function (data) {
                                oPropagationScriptResult = data
                            })
                        }catch (e) {
                            console.log(e)
                        }


                        okCallback(data);
                    },function (err) {
                        console.log(err)
                    });
                }
            },

            postConfigurationPropagationScript: function (sDam, okCallback,koCallback){

                console.log(oPropagationData);

                var o = angular.copy(oPropagationData);
                o.from_date = timeService.getDateFromUTCSecond();
                o.to_date = timeService.getDateToUTCSecond();

                var obj = {
                    "alg": sDam+".laminazione.propagation",
                    "input":o,
                };

                apiService.postExtJson(window.app.url.laminazione70Url,obj,function (data) {

                    alertError(data);
                    okCallback(data)
                },function () {
                    //var o ={"Stimigliano": {"Q": [8.1, 0.0, 0.05, 0.23, 0.55], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Orte": {"Q": [8.1, 3.5, 5.83, 8.19, 8.33], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Ponte Felice": {"Q": [8.1, 0.0, 0.55, 1.33, 2.24], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Monte Aniene": {"Q": [21.1, 12.2, 9.6, 7.0, 7.0], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Ponte Grillo": {"Q": [8.1, 0.0, 0.0, 0.01, 0.04], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}}
                    okCallback(o)
                })
            },


            exportManovreToCsv:function (manovre) {
                var csvHeader = "data:text/csv;charset=utf-8,";

                manovre.forEach(function (manovra,index, array) {
                    var row = moment(manovra.date).format()+","+manovra.value;
                    csvHeader += row+ "\r\n";
                })
                return csvHeader;
            }

        }

    }])

})();
