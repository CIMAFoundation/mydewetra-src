/**
 * GENERIC LOADER
 * @param ModelData
 * @param $uibModal
 * @param onClose
 * @returns {{modalIstance: *}}
 */
function tool_laminazione_generic(ModelData, $uibModal, onClose) {

    var corbaraFeature = {
        point: [13.231333, 43.699333],
        properties: {
            "catchment": 150,
            "dbid": 2,
            "district": 55,
            "munic": 4982,
            "region": 10,
            "sensorid": 210328104,
            "sensormu": "m",
            "sensorname": "Diga Corbara#Baschi",
            "stationid": 200043955,
            "stationname": "ERG-G",
            "wa": 113,
            "descr": "Baschi",
            "damsname": "Diga Corbara",
            "warning_palette": -2
        }
    };


    let confDamsObj = {
        'MERCATALE': {
            'input': {
                'FP Marche Det Cosmoi2': [
                    {
                        server: 10,
                        serie: "marche.floodproofs.deterministiclami",
                        featureId: 'Mercatale, Diga',
                        name: "qin_main"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822514;2",
                        name: "h_current"
                    }
                ],
                'FP Marche Det ECMWF': [
                    {
                        server: 10,
                        serie: "marche.floodproofs.deterministicecmwf",
                        featureId: 'Mercatale, Diga',
                        name: "qin_main"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822514;2",
                        name: "h_current"
                    }
                ]
            }
        },
        'CHIENTI': {
            'input': {
                'marche.floodproofs.deterministicecmwf_chain': [

                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822518;2",
                        name: "diga_di_borgiano"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822517;2",
                        name: "diga_di_polverina"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822516;2",
                        name: "diga_di_fiastrone"
                    }
                ],
                'marche.floodproofs.deterministiclami_chain': [
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822518;2",
                        name: "diga_di_borgiano"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822517;2",
                        name: "diga_di_polverina"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822516;2",
                        name: "diga_di_fiastrone"
                    }
                ]
            }
        }
    };


    let modalInstance = $uibModal.open({

        // templateUrl:'apps/dewetra2/js/components/laminazione-generic/laminazioneModalView.html',
        // controller:"laminazioneGenericController",
        component: 'laminazioneGeneric',
        size: "lg",
        backdrop: 'static',
        resolve: {
            params: function () {
                return {
                    feature: corbaraFeature,
                    confDams: confDamsObj,
                    nameDam: 'MERCATALE',
                    onClose: onClose
                }
            }
        }
    });

    modalInstance.result.then(function (obj) {

        console.log('modal-component dismissed at: ' + new Date());
        modalInstance = null;

    }, function () {
        console.log('modal-component dismissed at: ' + new Date());
        modalInstance = null;
    });

    return {
        modalIstance: modalInstance
    }
}

/**
 * MERCATALE LOADER
 * @param ModelData
 * @param $uibModal
 * @param onClose
 * @returns {{modalIstance: *}}
 */
function tool_laminazione_mercatale(ModelData, $uibModal, onClose) {

    var corbaraFeature = {
        point: [13.231333, 43.699333],
        properties: {
            "catchment": 150,
            "dbid": 2,
            "district": 55,
            "munic": 4982,
            "region": 10,
            "sensorid": 210328104,
            "sensormu": "m",
            "sensorname": "Diga Corbara#Baschi",
            "stationid": 200043955,
            "stationname": "ERG-G",
            "wa": 113,
            "descr": "Baschi",
            "damsname": "Diga Corbara",
            "warning_palette": -2
        }
    };


    let confDamsObj = {
        'MERCATALE': {
            'input': {
                'FP Marche Det Cosmoi2': [
                    {
                        server: 10,
                        serie: "marche.floodproofs.deterministiclami",
                        featureId: 'Mercatale, Diga',
                        name: "qin_main"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210328104;2",
                        name: "h_current"
                    }
                ],
                'FP Marche Det ECMWF': [
                    {
                        server: 10,
                        serie: "marche.floodproofs.deterministicecmwf",
                        featureId: 'Mercatale, Diga',
                        name: "qin_main"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210328104;2",
                        name: "h_current"
                    }
                ]
            }
        }
    };


    let modalInstance = $uibModal.open({

        // templateUrl:'apps/dewetra2/js/components/laminazione-generic/laminazioneModalView.html',
        // controller:"laminazioneGenericController",
        component: 'laminazioneGeneric',
        size: "lg",
        backdrop: 'static',
        resolve: {
            params: function () {
                return {
                    feature: corbaraFeature,
                    confDams: confDamsObj,
                    nameDam: 'MERCATALE',
                    onClose: onClose
                }
            }
        }
    });

    modalInstance.result.then(function (obj) {

        console.log('modal-component dismissed at: ' + new Date());
        modalInstance = null;

    }, function () {
        console.log('modal-component dismissed at: ' + new Date());
        modalInstance = null;
    });

    return {
        modalIstance: modalInstance
    }
}


/**
 * CHIENTI LOADER
 * @param ModelData
 * @param $uibModal
 * @param onClose
 * @returns {{modalIstance: *}}
 */
function tool_laminazione_chienti(ModelData, $uibModal, onClose) {

    var corbaraFeature = {
        point: [13.231333, 43.699333],
        properties: {
            "catchment": 150,
            "dbid": 2,
            "district": 55,
            "munic": 4982,
            "region": 10,
            "sensorid": 210328104,
            "sensormu": "m",
            "sensorname": "Diga Corbara#Baschi",
            "stationid": 200043955,
            "stationname": "ERG-G",
            "wa": 113,
            "descr": "Baschi",
            "damsname": "Diga Corbara",
            "warning_palette": -2
        }
    };


    let confDamsObj = {
        'MERCATALE': {
            'input': {
                'FP Marche Det Cosmoi2': [
                    {
                        server: 10,
                        serie: "marche.floodproofs.deterministiclami",
                        featureId: 'Mercatale, Diga',
                        name: "qin_main"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210328104;2",
                        name: "h_current"
                    }
                ],
                'FP Marche Det ECMWF': [
                    {
                        server: 10,
                        serie: "marche.floodproofs.deterministicecmwf",
                        featureId: 'Mercatale, Diga',
                        name: "qin_main"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210328104;2",
                        name: "h_current"
                    }
                ]
            }
        },
        'CHIENTI': {
            'input': {
                'FP Marche Det ECMWF': [
                    {
                        chain: 'marche.floodproofs.deterministicecmwf'
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822518;2",
                        name: "diga_di_borgiano"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822517;2",
                        name: "diga_di_polverina"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822516;2",
                        name: "diga_di_fiastrone"
                    }
                ],
                'FP Marche Det Cosmoi2': [
                    {
                        chain: 'marche.floodproofs.deterministiclami'
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822518;2",
                        name: "diga_di_borgiano"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822517;2",
                        name: "diga_di_polverina"
                    },
                    {
                        server: 1,
                        serie: "all.sensor.hydrometers",
                        featureId: "210822516;2",
                        name: "diga_di_fiastrone"
                    }
                ]
            }
        }
    }


    let modalInstance = $uibModal.open({

        // templateUrl:'apps/dewetra2/js/components/laminazione-generic/laminazioneModalView.html',
        // controller:"laminazioneGenericController",
        component: 'laminazioneChienti',
        size: "lg",
        backdrop: 'static',
        resolve: {
            params: function () {
                return {
                    feature: corbaraFeature,
                    confDams: confDamsObj,
                    nameDam: 'CHIENTI',
                    onClose: onClose
                }
            }
        }
    });

    modalInstance.result.then(function (obj) {

        console.log('modal-component dismissed at: ' + new Date());
        modalInstance = null;

    }, function () {
        console.log('modal-component dismissed at: ' + new Date());
        modalInstance = null;
    });

    return {
        modalIstance: modalInstance
    }
}
