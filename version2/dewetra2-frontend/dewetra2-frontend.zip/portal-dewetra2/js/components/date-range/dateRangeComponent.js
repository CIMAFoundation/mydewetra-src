/**
 * Created by Dario Rubado on 18/06/20.
 */
(function () {

    dewetraApp.component('dateRangeComponent', {
        //templateUrl: 'apps/dewetra2/js/components/export-data/exportDataComponent.html',
        template: `<div class="row">
            <div class="col-lg-6 col-md-6 col-lg-6">
                <div class="dropdown form-group dropdown-start-parent">
                    <label>Start Date</label>
                    <a class="dropdown-toggle" id="dropdownStart" role="button" data-toggle="dropdown" data-target=".dropdown-start-parent"
                       href="#">
                        <div class="input-group date">
                            <input type="text" class="form-control" data-ng-model="$ctrl.momentInputFormatter($ctrl.dateRangeStart)">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                        </div>
                    </a>
                    <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                        <datetimepicker data-ng-model="$ctrl.dateRangeStart"
                                        data-datetimepicker-config="{ dropdownSelector: '#dropdownStart', renderOn: 'end-date-changed', modelType: 'moment' }"
                                        data-on-set-time="$ctrl.startDateOnSetTime()"
                                        data-before-render="$ctrl.startDateBeforeRender($dates)"></datetimepicker>
                    </ul>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-lg-6">
                <div class="dropdown form-group dropdown-end-parent">
                    <label>End Date</label>
                    <a class="dropdown-toggle" id="dropdownEnd" role="button" data-toggle="dropdown" data-target=".dropdown-end-parent"
                       href="#">
                        <div class="input-group date">
                            <input type="text" class="form-control" data-ng-model="$ctrl.momentInputFormatter($ctrl.dateRangeEnd)">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                        </div>
                    </a>
                    <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                        <datetimepicker data-ng-model="$ctrl.dateRangeEnd"
                                        data-datetimepicker-config="{ dropdownSelector: '#dropdownEnd', renderOn: 'start-date-changed' , modelType: 'moment' }"
                                        data-on-set-time="$ctrl.endDateOnSetTime()"
                                        data-before-render="$ctrl.endDateBeforeRender($view, $dates, $leftDate, $upDate, $rightDate)"></datetimepicker>
                    </ul>
                </div>
            </div>
        </div>`,
        bindings: {
            startDate: '<',
            endDate: '<',
            onStartDateSelected: '&',
            onEndDateSelected: '&',
            isUtc:'<',
            dateFormat:'<',
            close: '&',
        },
        controller: ['mapService', '$uibModal', '$rootScope', function (mapService, $uibModal, $rootScope) {
            var $ctrl = this;

            $ctrl.$rootScope = $rootScope;

            $rootScope.$watch('pendingRequests', function () {
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });

            momentWrapper = (date) => {
                return ($ctrl.hasOwnProperty('isUtc') && $ctrl.utc == true)?moment.utc(date):moment(date);
            };

            $ctrl.momentWrapper = momentWrapper;

            momentInputFormatter = (momentDate) => {
                let sEndParts = ($ctrl.hasOwnProperty('isUtc') && $ctrl.isUtc == true)?' UTC': ' GMT';
                //let sEndParts = (momentDate._isUtc)?' UTC': ' GMT';

                let sDateFormat = ($ctrl.hasOwnProperty('dateFormat') && $ctrl.dateFormat != '' && $ctrl.dateFormat )?$ctrl.dateFormat: 'DD/MM/YYYY HH:mm';

                return momentWrapper(momentDate).format(sDateFormat ) + sEndParts;
            };

            $ctrl.momentInputFormatter = momentInputFormatter;

            $ctrl.oConfig = {}

            $ctrl.endDateBeforeRender = endDateBeforeRender
            $ctrl.endDateOnSetTime = endDateOnSetTime
            $ctrl.startDateBeforeRender = startDateBeforeRender
            $ctrl.startDateOnSetTime = startDateOnSetTime

            function startDateOnSetTime() {
                console.log('start-date-changed');
                $ctrl.onStartDateSelected.apply(this)($ctrl.dateRangeStart)
                //$ctrl.onStartDateSelected.apply(this)($ctrl.dateRangeStart)

            }

            function endDateOnSetTime() {
                console.log('end-date-changed');
                $ctrl.onEndDateSelected.apply(this)($ctrl.dateRangeEnd)
                //$ctrl.onEndDateSelected.apply(this)($ctrl.dateRangeEnd)
            }

            function startDateBeforeRender($dates) {
                if ($ctrl.dateRangeEnd) {
                    var activeDate = momentWrapper($ctrl.dateRangeEnd);

                    $dates.filter(function (date) {
                        return date.localDateValue() >= activeDate.valueOf()
                    }).forEach(function (date) {
                        date.selectable = false;
                    })
                }
            }

            function endDateBeforeRender($view, $dates) {
                if ($ctrl.dateRangeStart) {

                    var activeDate = momentWrapper($ctrl.dateRangeStart).subtract(1, $view).add(1, 'minute');

                    $dates.filter(function (date) {
                        return date.localDateValue() <= activeDate.valueOf()
                    }).forEach(function (date) {
                        date.selectable = false;
                    })
                }
            }


            $ctrl.closePopup = function () {

                $ctrl.close()
            }

            $ctrl.log = function (item) {
                console.log(item)
            }


            $ctrl.$onInit = function () {


                console.log("Date range component init");


            };

            $ctrl.$onChanges = function (change) {

                $ctrl.dateRangeStart = $ctrl.startDate;
                $ctrl.dateRangeEnd = $ctrl.endDate;

                if (change.startDate) {

                    $ctrl.dateRangeStart = change.startDate.currentValue;

                }

                if (change.endDate) {
                    $ctrl.dateRangeEnd = change.endDate.currentValue;
                }

                console.log("Date range component changes");


            };


            $ctrl.selectLayer = function (layer) {
                //$ctrl.onLayerSelected.apply(this)(layer.layer)
            }


            $ctrl.update = function () {
                // $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                // $ctrl.dismiss({$value: 'cancel'});
            };


        }]
    });


})();

