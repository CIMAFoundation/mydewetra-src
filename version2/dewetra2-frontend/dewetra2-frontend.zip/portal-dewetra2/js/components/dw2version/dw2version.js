/**
 * Created by Dario Rubado on 16/12/19.
 */
(function(){

    dewetraApp.component('dwversion',{
        template:'<span style="font-size: 12px; letter-spacing: -0.02em; font-style:italic ">Version: {{$ctrl.version}}</span>',

        controller: ['$uibModal', 'acUserResource', '$rootScope','_', '$window','mapService','apiService', 'menuService', function($uibModal, acUserResource, $rootScope,_, $window, mapService, apiService, menuService){

            var $ctrl = this;

            var commit =(window.app.version)?window.app.version:'dev';

            $ctrl.version = '2.1.3.'+ commit;

            $ctrl.$onInit = function(){

            }

            $ctrl.$onChanges = function(){


            }


        }]
    });




})();

