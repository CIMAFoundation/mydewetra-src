/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('punctualSerieChartManagerComponent', {
        templateUrl: 'apps/dewetra2/js/components/punctual-serie-chart-manager/punctualSerieChartComponent.html',
        // template:' <i class="i-tools_info"></i>',
        // template:' <i ng-click="$ctrl.activatePointer()" ng-class="{active: $ctrl.active==true}" class="fa fa-line-chart"></i>',
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService', '$rootScope', '$translate', function (mapService, $rootScope, $translate) {
            var $ctrl = this;

            $ctrl.$rootScope = $rootScope;

            $ctrl.oldLoadedSerie = null
            $ctrl.loadedSerie = null

            $ctrl.oConfig={
                attributes: ['VARIABLE', 'CUMULATIVE_RANGE']
            }


            $ctrl.closePopup = function () {
                $ctrl.close()
            }

            $ctrl.aoSerie = [];


            $ctrl.loadSeries = function (lat, lon) {

                $ctrl.aoManager = mapService.oLayerList.aDraggable.concat(mapService.oLayerList.aUndraggable)

                var iCount = 0;

                $ctrl.aoManager.forEach(function (oManager) {


                    if (oManager.hasOwnProperty("punctualSerie")) {

                        let serieObj = {
                            oManager
                        };


                        serieObj.active = false;
                        serieObj.variable = $translate.instant(oManager.getVariable());
                        serieObj.aggregation = $translate.instant(oManager.getAggregation());
                        serieObj.name = $translate.instant(oManager.name());
                        serieObj.title = serieObj.name + ' ' + serieObj.aggregation + ' ' + serieObj.variable;

                        $ctrl.aoSerie.push(serieObj);

                        iCount++;

                        if ($ctrl.aoManager.length == iCount) {
                            $ctrl.changeSerie($ctrl.aoSerie[0])
                        }


                    }
                })
            }

            variableFromProperties = (props)=>{
                let str = "";
                if (Array.isArray(props.layerProperties.attributes)) {
                    props.layerProperties.attributes.forEach(function (prop) {
                        if (prop.name == "operation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                        if (prop.name == "variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                        if (prop.name == "__variable") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                    })
                    return str;
                } else {
                    if (props.layerProperties.attributes.name == "operation") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                    if (props.layerProperties.attributes.name == "variable") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                    if (props.layerProperties.attributes.name == "__variable") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                    ret
                }
            }

            aggregationFromProperties = (props)=>{
                let str = "";

                if (Array.isArray(props.layerProperties.attributes)) {
                    props.layerProperties.attributes.forEach(function (prop) {
                        if (prop.name == "aggregation") str = prop.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
                        if (prop.name == "__aggregation") str = prop.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                    })
                    return str;
                } else {
                    if (props.layerProperties.attributes.name == "aggregation") str = props.layerProperties.attributes.selectedEntry.value.toUpperCase().trim().replace(/ /g, "_") + '_HOURS';
                    if (props.layerProperties.attributes.name == "__aggregation") str = props.layerProperties.attributes.selectedEntry.descr.toUpperCase().trim().replace(/ /g, "_");
                }
            }

            titleFromProperties = (props)=>{

            }

            $ctrl.loadDataForSerie = function (serie, properties, okCallback) {
                if (serie.hasOwnProperty('oManager') && serie.oManager.hasOwnProperty('punctualSerieWithProperties')) {
                    serie.oManager.punctualSerieWithProperties($ctrl.resolve.oLatLon.lat, $ctrl.resolve.oLatLon.lon, (properties) ? properties : serie.oManager.props()
                        , (data) => {
                            if (okCallback) okCallback(data);
                        }, () => {
                            console.log('KO Callback');
                        })
                }
            }

            $ctrl.changeSerie = function (oSerie) {

                if (oSerie.hasOwnProperty('series')) {
                    if ($ctrl.loadedSerie != null) $ctrl.loadedSerie.active = false

                    $ctrl.loadedSerie = oSerie

                    oSerie.active = true
                } else {
                    $ctrl.loadDataForSerie(oSerie, undefined, (data) => {

                        if ($ctrl.loadedSerie != null) $ctrl.loadedSerie.active = false
                        oSerie.series = data;
                        $ctrl.loadedSerie = oSerie

                        oSerie.active = true
                    })
                }

            };

            $ctrl.callbackProperties = (newProperties) => {
                let serieObj = Object.assign({}, $ctrl.loadedSerie);

                serieObj.variable = $translate.instant(variableFromProperties(newProperties));
                serieObj.aggregation = $translate.instant(aggregationFromProperties(newProperties));
                serieObj.title = serieObj.name + ' ' + serieObj.aggregation + ' ' + serieObj.variable;


                $ctrl.loadDataForSerie(serieObj, newProperties, (data) => {
                    serieObj.series = data;
                    $ctrl.loadedSerie = serieObj;

                })
            }

            $ctrl.$onInit = function () {
                console.log("punctualSerieChartManagerComponent");
                $ctrl.loadSeries($ctrl.resolve.oLatLon.lat, $ctrl.resolve.oLatLon.lon)

            };


            $ctrl.update = function () {
                $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };


        }]
    });


})();

