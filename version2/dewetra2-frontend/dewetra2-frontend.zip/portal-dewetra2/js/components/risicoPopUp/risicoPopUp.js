/**
 * Created by Dario Rubado on 23/07/18.
 */
(function(){

    dewetraApp.component('risicoPopUp',{
        templateUrl:'apps/dewetra2/js/components/risicoPopUp/risico.html', bindings: {
            layers: "=",
            onRemove: '&',
            onAdd:'<'
        },
        controller: ['$uibModal', 'acUserResource', '$rootScope',function($uibModal, acUserResource, $rootScope){
            var ctrl = this;



            ctrl.$onInit = function () {
                ctrl.AdvPopup = window.app.config.risicoPopUp.enabled;
                if(ctrl.AdvPopup)console.log("init popUp Ris.i.co.");
            };



            ctrl.$onChanges=function(change){


                if(change.onAdd && ctrl.AdvPopup){
                   ctrl.popUpRisico(change.onAdd.currentValue.name);
                }
            }

            ctrl.popUpRisico = function (name) {

                var serverTime = moment.utc($rootScope.getServerTime());
                var until = moment('2018-31-09','YYYY-DD-MM');



                if (name.indexOf('RISICO')> -1&&ctrl.AdvPopup && serverTime.isBefore(until) &&$rootScope.acSession.user.id!="anywhere"){

                    //se tutto è ok controllo che tu non abbia gia scartato il popup
                    acUserResource.getResources('dewetra2',function (data) {
                        // console.log(data)
                        var index = _.findIndex(data,function (obj) {
                            return ((obj.resource =='risico-manual-v1-2018')&&(obj.user == $rootScope.acSession.user.id)&&(obj.value.indexOf("accepted")>-1))
                        })
                        // console.log(index)
                        if (index > -1){
                            console.log("risico accepted : "+ data[index].value)
                        }else{
                            var modalInstance = $uibModal.open({

                                templateUrl: 'apps/dewetra2/js/components/risicoPopUp/risicoPopUp.html',
                                controller: function($scope, $uibModal, $uibModalInstance, $translate,AdvMessage, _, acUserResource) {

                                    $scope.AdvMessage = AdvMessage;
                                    $scope.closePopup = function () {
                                        if($scope.notShowMore){
                                            ctrl.AdvPopup = false;
                                            var value= "accepted-"+moment.utc($rootScope.getServerTime()).toISOString();
                                            acUserResource.saveResource('dewetra2','risico-manual-v1-2018',value,
                                                function (data) {
                                                    $uibModalInstance.close();
                                                })
                                        }else{
                                            ctrl.AdvPopup = true;
                                            $uibModalInstance.close();
                                        }


                                    }
                                },
                                size: 'lg',
                                keyboard: false,
                                resolve: {

                                    AdvMessage: function () {

                                        return {
                                            title: "Manuale RIS.I.CO.",
                                            subtitle: "Aggiornamento manuale RIS.I.CO.",
                                            messaggio : "E' disponibile il nuovo aggiornamento del manuale d'uso del sistema RIS.I.CO.",
                                            link: "#",
                                            from:"Comunicazione"
                                        };

                                    }
                                }
                            });
                        }


                    },function (data) {
                        alert("No Eula Settings")
                    });

                }

            };


        }]
    });
})();

