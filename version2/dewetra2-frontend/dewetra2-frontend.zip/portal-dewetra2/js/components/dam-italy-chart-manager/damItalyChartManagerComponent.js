/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('damItalyChartManagerComponent', {

        templateUrl: 'apps/dewetra2/js/components/dam-italy-chart-manager/damItalyChartManagerComponent.html',
        // template:' <i class="i-tools_info"></i>',
        // template:' <i ng-click="$ctrl.activatePointer()" ng-class="{active: $ctrl.active==true}" class="fa fa-line-chart"></i>',
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService','$rootScope',function (mapService,$rootScope) {
            var $ctrl = this;

            $ctrl.$rootScope = $rootScope;

            $ctrl.oldLoadedSerie = null
            $ctrl.loadedSerie = null

            $ctrl.closePopup = function () {
                $ctrl.close()
            }

            $ctrl.aoSerie = [];

            $ctrl.loadSeries = function(lat,lon){

                $ctrl.aoManager = mapService.oLayerList.aDraggable.concat(mapService.oLayerList.aUndraggable)

                var iCount = 0;

                $ctrl.aoManager.forEach(function (oManager) {

                    if(oManager.hasOwnProperty("punctualSerie")){

                        oManager.punctualSerie(lat, lon,function (data) {

                            data.active = false;
                            data.variable = oManager.getVariable()
                            data.aggregation = oManager.getAggregation()
                            $ctrl.aoSerie.push(data);

                            iCount++;

                            if($ctrl.aoManager.length== iCount) {
                                $ctrl.changeSerie($ctrl.aoSerie[0])
                            }

                        }, function (data) {
                            console.log(data)
                        })
                    }
                })
            }

            $ctrl.changeSerie = function(oSerie){

                if($ctrl.loadedSerie!= null)$ctrl.loadedSerie.active = false

                $ctrl.loadedSerie = oSerie

                oSerie.active = true

            };

            $ctrl.$onInit = function () {
                console.log("punctualSerieChartManagerComponent");
                $ctrl.loadSeries($ctrl.resolve.oLatLon.lat, $ctrl.resolve.oLatLon.lon)

            };




            $ctrl.update = function () {
                $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };



        }]
    });


})();

