/**
 * Created by dario on 27/04/22.
 */


(function () {


    dewetraApp.component('runGeneric', {

        template: `
            
           <div class="row run">

            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    
                <div class="flex-item" ng-repeat="str in $ctrl.optimisation.dewetra.table.str_above">
                    <h3>{{str}}</h3>
                </div>
    
            </div>
            
            <warnings-generic data="$ctrl.optimisation.dewetra.warnings"></warnings-generic>
    
            <div class="container-fluid">
    
                <table class="table table-bordered">
                    <thead>
                        <tr style="text-align: center">
                            <td ng-repeat=" column in $ctrl.optimisation.dewetra.table.table  "><h2>{{column.label}}</h2></td>
                        </tr>
                    </thead>
                    <tbody>
<!--                    changes.optimisation.dewetra.table.table[0].values-->
                        <tr ng-repeat="(key, column) in $ctrl.optimisation.dewetra.table.table[0].values track by $index">
                        <td>{{$ctrl.optimisation.dewetra.table.table[0].values[$index]}}</td>
                        <td>{{$ctrl.optimisation.dewetra.table.table[1].values[$index]}}</td>
                        <td>{{$ctrl.optimisation.dewetra.table.table[2].values[$index]}}</td>
                        <td>{{$ctrl.optimisation.dewetra.table.table[3].values[$index]}}</td>
                        <td>{{$ctrl.optimisation.dewetra.table.table[4].values[$index]}}</td>
                    </tr>
    
                    </tbody>
                </table>
    
            </div>

        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

            <div class="flex-item flex-container col center p-5" ng-repeat="str in $ctrl.optimisation.dewetra.table.str_below">
                <h3>{{str}}</h3>
            </div>

        </div>




    </div>

            `,
        bindings: {
            optimisation: '<'
        },
        controller: ['$rootScope', '$timeout', '$translate', 'menuService', '_', function ($rootScope, $timeout, $translate, timeService, _) {

            const $ctrl = this;

            $ctrl.valueChanged = function () {

            }

            $rootScope.$watch('pendingRequests', function () {
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });


            $ctrl.$onChanges = (changes) => {
                // $ctrl.resolve.currentValue.params.confDams.MERCATALE

                if (changes.optimisation) {
                    $ctrl.valueChanged()//inizializzo i dati
                }

            };

            $ctrl.$onInit = () => {


            };
        }]
    });
})();
