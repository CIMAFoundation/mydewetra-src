/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('laminazioneChientiChartComponent', {
        template: `

        <div class="row">
            <div class="flex-container">
                <button class="btn btn-primary animated fadeInLeft delay-00{{$index}}" ng-repeat="(key, value) in $ctrl.charts" ng-click="$ctrl.initChart(value, value.title)" >{{value.title}}</button>
            </div>
        </div>

        <div class="row m-t-10 m-r-10 m-l-10">
            <div id="chart" className="animated fadeIn"></div>
            <chart-axis-setter chart="$ctrl.chart"></chart-axis-setter>
        </div>
        `,
        //template:`<div id="chart" className="animated fadeIn"></div>`,
        bindings: {
            charts: '<',
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService', '$rootScope', '$translate', 'menuService', '_', function (mapService, $rootScope, $translate, menuService, _) {
            var $ctrl = this;


            $ctrl.closePopup = function () {
                $ctrl.close()
            }


            $ctrl.$onInit = function () {
                console.log("laminazioneChientiChartComponent");

                $ctrl.height = menuService.oChartSize.m_iSensorChartHeight()

            };

            $ctrl.$onChanges = function (value) {

                console.log("laminazioneChartComponent changes");

                if (value.charts.currentValue !== value.charts.previousValue && value.charts.currentValue !== null) {

                    // $ctrl.chart = new Highcharts.StockChart($ctrl.chartOptions);

                    //$ctrl.initChart($ctrl.charts[Object.keys($ctrl.charts)[0]], Object.keys($ctrl.charts)[0])
                }


            };


            $ctrl.setSeries = function (aLines) {

                while ($ctrl.chart.series.length) {
                    $ctrl.chart.series[0].remove();
                }


                try {
                    aLines.map(serie => {

                        let data = [];

                        for (var i = 0, l = serie.Data.length; i < l; i++) {
                            data[i] = [serie.Time[i] * 1000, serie.Data[i]]
                        }

                        $ctrl.chart.addSeries({
                            name: serie.Legend_Label,
                            type: 'line',
                            color: serie.PrintColor,
                            threshold: null,
                            data: data,
                            showInLegend: true
                        }, true);
                    })


                } catch (e) {
                    console.log(e);
                }

            }


            $ctrl.initChart = function (chart, title) {

                if (!$ctrl.chart) {
                    $ctrl.chart = new Highcharts.StockChart($ctrl.chartOptions);
                }


                if (title) {
                    $ctrl.chart.setTitle(null,
                        {
                            text: title,
                            style: {
                                fontWeight: 'bold',
                                fontSize : '20px'
                            }

                        })
                }

                try {
                    if ($ctrl.chart && chart) {

                        $ctrl.chart.update({
                                yAxis: [
                                    {
                                        min: chart.ylimits[0],
                                        max: chart.ylimits[1],
                                        title: {
                                            text: chart.ylabel
                                        },
                                        style: {
                                            fontWeight: 'bold',
                                            fontSize : '15px'
                                        }
                                    }]
                            },
                            {
                                xAxis: [
                                    {
                                        // tickPositioner: function() {
                                        //     const chart = this.chart,
                                        //         tickPositions = [];
                                        //
                                        //     if (chart.series.length == 0 ) return;
                                        //     debugger
                                        //
                                        //     // if(chart.series.forEach(s => s.data.length == 0))
                                        //
                                        //         chart.series[0].data.forEach((point) => {
                                        //             tickPositions.push(point.x)
                                        //         });
                                        //
                                        //     this.update({
                                        //         tickPositions: tickPositions
                                        //     });
                                        //
                                        // },
                                        min: chart.xlimits[0] * 1000,
                                        max: chart.xlimits[1] * 1000,
                                        title: {
                                            text: chart.xlabel
                                        },
                                        style: {
                                            fontWeight: 'bold',
                                            fontSize : '15px'
                                        }
                                    }]
                            }, true)
                    }
                } catch (e) {
                    console.log(e);
                }

                if (chart && chart.hasOwnProperty('Lines')) {
                    $ctrl.setSeries(chart.Lines);
                }

                $ctrl.chart.redraw();

                // const p ={
                //     "xlabel": "Time UTC",
                //     "ylabel": "Q [m3/s]",
                //     "xlimits": [1636466400, 1636632000],
                //     "ylimits": [
                //     0,
                //     10
                // ],
                //     "Lines": [
                //     {
                //         "Legend_Label": "Portata in ingresso",
                //         "Data": [10.18, 9.97, 9.77, 9.58, 9.39, 9.21, 9.38, 9.96, 10.17, 10.95, 12.38, 11.98, 10.42, 9.27, 8.74, 8.48, 8.28, 8.12, 7.97, 7.83, 7.69, 7.56, 7.43, 7.3, 7.17, 7.05, 6.94, 6.82, 6.71, 6.6, 6.49, 6.39, 6.29, 6.2, 6.1, 6, 5.91, 5.82, 5.73, 5.65, 5.57, 5.48, 5.4, 5.33, 5.26, 5.18,
                //             5.11
                //         ],
                //         "Time": [1636466400, 1636470000, 1636473600, 1636477200, 1636480800, 1636484400, 1636488000, 1636491600, 1636495200, 1636498800, 1636502400, 1636506000, 1636509600, 1636513200, 1636516800, 1636520400, 1636524000, 1636527600, 1636531200, 1636534800, 1636538400, 1636542000, 1636545600, 1636549200, 1636552800, 1636556400, 1636560000, 1636563600, 1636567200, 1636570800, 1636574400, 1636578000, 1636581600, 1636585200, 1636588800, 1636592400, 1636596000, 1636599600, 1636603200, 1636606800, 1636610400, 1636614000, 1636617600, 1636621200, 1636624800, 1636628400,
                //             1636632000
                //         ],
                //         "PrintColor": "#000000",
                //         "InplotString_label": "",
                //         "InplotString_x": [],
                //         "InplotString_y": []
                //     },
                //     {
                //         "Legend_Label": "Portata scaricata",
                //         "Data": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                //             0
                //         ],
                //         "Time": [1636466400, 1636470000, 1636473540, 1636473600, 1636477200, 1636480740, 1636480800, 1636484400, 1636487940, 1636488000, 1636491600, 1636495140, 1636495200, 1636498800, 1636502340, 1636502400, 1636506000, 1636509540, 1636509600, 1636513200, 1636516740, 1636516800, 1636520400, 1636523940, 1636524000, 1636527600, 1636531140, 1636531200, 1636534800, 1636538340, 1636538400, 1636542000, 1636545540, 1636545600, 1636549200, 1636552740, 1636552800, 1636556400, 1636559940, 1636560000, 1636563600, 1636567140, 1636567200, 1636570800, 1636574340, 1636574400, 1636578000, 1636581540, 1636581600, 1636585200, 1636588740, 1636588800, 1636592400, 1636595940, 1636596000, 1636599600, 1636603140, 1636603200, 1636606800, 1636610340, 1636610400, 1636614000, 1636617540, 1636617600, 1636621200, 1636624740, 1636624800, 1636628400,
                //             1636632000
                //         ],
                //         "PrintColor": "#1a8cd9",
                //         "InplotString_label": "",
                //         "InplotString_x": [],
                //         "InplotString_y": []
                //     },
                //     {
                //         "Legend_Label": "Portata turbinata",
                //         "Data": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
                //         ],
                //         "Time": [
                //             1636466400, 1636470000, 1636473600, 1636477200, 1636480800, 1636484400, 1636488000, 1636491600, 1636495200, 1636498800, 1636502400, 1636506000, 1636509600, 1636513200, 1636516800, 1636520400, 1636524000, 1636527600, 1636531200, 1636534800, 1636538400, 1636542000, 1636545600, 1636549200, 1636552800, 1636556400, 1636560000, 1636563600, 1636567200, 1636570800, 1636574400, 1636578000, 1636581600, 1636585200, 1636588800, 1636592400, 1636596000, 1636599600, 1636603200, 1636606800, 1636610400, 1636614000, 1636617600, 1636621200, 1636624800, 1636628400, 1636632000],
                //         "PrintColor": "#ff0000",
                //         "InplotString_label": "",
                //         "InplotString_x": [],
                //         "InplotString_y": []
                //     }
                // ]
                // }

            }


            $ctrl.chartOptions = {

                chart: {
                    renderTo: 'chart',
                    //marginTop: 25,
                    alignTicks: false,
                    zoomType: 'xy',
                    height: 600,
                    events: {
                        beforePrint: function () {
                            $ctrl.chart.setTitle(null,
                                {
                                    text: '$ctrl.serie.title'
                                });

                        },
                        afterPrint: function () {

                            $ctrl.chart.setTitle(null,
                                {
                                    text: null
                                });
                        }
                    }
                },
                title: {},
                options: {
                    global: {
                        useUTC: true
                    },
                    chart: {
                        backgroundColor: 'rgba(255, 255, 255, 1)'
                    }
                },

                tooltip: {
                    useHTML: true,
                    crosshairs: true,
                    shared: true,
                    formatter: function () {
                        let iSec = this.x;
                        const oDate = new Date(parseInt(this.x));
                        let sDate = (oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0)?'<b>' + Highcharts.dateFormat('%d %b', this.x) + '</b>':Highcharts.dateFormat('%H:%M', this.x);
                        // let sDate = moment.utc(iSec, 'X').format('HH:mm');
                        var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + $translate.instant('ORE') + ' ' + sDate + '</div><br>';

                        if (this.hasOwnProperty('point')) {
                            s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: #FF0000">' +
                                $('<div>' + '  ' + this.point.y.toFixed(2) + ' </div>').html() + '</div><br>';
                            return s;
                        } else if (this.hasOwnProperty('points')) {
                            this.points.forEach(function (item) {
                                if (item.y > -9998) {
                                    if (item.series.name) {
                                        s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color:' + item.color + '">' +
                                            $('<div>' + item.series.name + ' : ' + item.y.toFixed(2) + ' </div>').html() + '</div><br>';
                                    }
                                }
                            });
                            return s;
                        }
                    }
                },
                credits: {
                    enabled: false
                },
                legend: {
                    enabled: true,
                    useHTML: true
                },


                series: [],
                exporting: {
                    chartOptions: {
                        rangeSelector: {
                            enabled: false
                        },
                        navigator: {
                            enabled: false
                        }
                    },
                    sourceWidth: 1500,
                    sourceHeight: 1000,

                },
                navigator: {
                    series: {
                        type: 'area',
                        fillOpacity: 0.3
                    },
                    enabled: false

                },
                scrollbar: {
                    enabled: false
                },
                xAxis: {
                    ordinal: false,
                    type: 'datetime',
                    // range:  24 * 3600 * 1000,                                    // one day
                    minRange: 1 * 3600 *1000,                                   // one hour
                    tickPixelInterval: 50,
                    minorTickInterval: 'auto',
                    lineWidth: 2,
                    gridLineWidth: 2,
                    lineColor: 'black',
                    title: {
                        margin: 0,
                        text: 'Time UTC ',
                        style: {
                            fontWeight: 'bold',
                            fontFamily: 'Open Sans',
                            fontSize : '15px'
                        }
                    },
                    labels: {
                        style: {
                            fontFamily: 'Open Sans',
                            textTransform: 'lowercase'
                        },
                        formatter: function () {
                            const val = this.value;
                            const oDate = new Date(parseInt(val));
                            if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                                return '<b>' + Highcharts.dateFormat('%d %b', val) + '</b>';
                            else
                                return Highcharts.dateFormat('%H:%M', val);
                        }

                    },
                    plotLines: [
                        {
                            color: 'rgba(69, 163, 202, 1)', // Color value
                            dashStyle: 'Solid',             // Style of the plot line. Default to solid
                            value: new Date().getTime(),    // Value of where the line will appear
                            width: '2',                     // Width of the line
                            zIndex: 4
                        }
                    ],
                    events: {

                        setExtremes: function (e) {

                            if (e.rangeSelectorButton) {

                                var c = e.rangeSelectorButton.count;

                                if (c == 3) {
                                    rangeSelected = 0;
                                } else if (c == 12) {
                                    rangeSelected = 1;
                                } else {
                                    rangeSelected = 2;
                                }

                                //} else {
                                //    if (!chart.rangeSelector) {
                                //        var subTitle = ('Dati dal ' + moment(e.min/1000, 'X').format('DD/MM/YYYY') + ' al ' + moment(e.max/1000, 'X').format('DD/MM/YYYY'));
                                //        chart.setTitle(null, { text: subTitle });
                                //    }

                            }

                        }

                    }

                },
                plotOptions: {
                    scatter: {
                        lineWidth: 2
                    },
                    series: {
                        dataGrouping: {
                            enabled: true,
                            approximation: "high"
                        },
                        animation: false,
                        lineWidth: 1// adding line to connect scatter chart
                    },
                    line: {
                        marker: {
                            enabled: true,
                            radius: 1
                        }
                    },
                    area: {
                        marker: {
                            enabled: true,
                            radius: 1
                        }
                    }
                },
                rangeSelector: {

                    inputEnabled: false,
                    enabled: false

                },
                yAxis: [{ // Primary yAxis
                    ordinal: false,
                    showLastLabel: true,
                    allowDecimals: true,
                    alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                    labels: {
                        x: -5,
                        y: 5,
                        format: '{value:.0f}',
                        style: {
                            color: 'black',
                            fontFamily: 'Open Sans',
                            textTransform: 'lowercase'
                        }
                    },
                    title: {
                        rotation: 270,
                        margin: 0,
                        offset: 45,
                        useHTML: true,
                        text: '<p style="color:black">VARIABLE</p>',
                        style: {
                            fontWeight: 'bold',
                            fontFamily: 'Open Sans',
                            fontSize : '15px'
                        }
                    },
                    opposite: false
                }],
                loading: false

            }

        }]
    });


})();

