/**
 * Created by dario on 27/04/22.
 */

(function() {


    dewetraApp.component('laminazioneChientiInputGeneric', {

        template : `
            
          
                <table class="">
                    <tbody>
                        
                        <tr>
                            <td colspan="3" style="height: 25px"></td>
                        </tr>

                        <tr>
                            <td>Franco di Sicurezza [m] </td>
                            <td colspan="2"><input class="form-control " style="" type="number"  min="0" ng-model="$ctrl.config.SM" name="sm" ng-change="$ctrl.valueChanged()"></td>
                            <td><p>{{$ctrl.data.description_SM}}</p></td>
                        </tr>
                        <tr>
                            <td>Delta di svaso ammissibile [m/g]  </td>
                            <td colspan="2"><input class="form-control " style=""  type="number" min="0" ng-model="$ctrl.config.delta_drawdown" name="delta_drawdown" ng-change="$ctrl.valueChanged()"></td>
                        </tr>
                        <tr>
                            <td> Portata turbinata richiesta [m<sup>3</sup>/s]    </td>
                            <td colspan="2"><input class="form-control " style=""  type="number"  min="0"  ng-model="$ctrl.config.q_turb" name="q_turb" ng-change="$ctrl.valueChanged()"></td>
                        </tr>
                        <tr>
                            <td>Manovra Attuale [m<sup>3</sup>/s]    </td>
                            <td colspan="2"><input class="form-control " style=""  type="number"  min="0" ng-model="$ctrl.config.current_release" name="current_release" ng-change="$ctrl.valueChanged()"></td>
                        </tr>
                    </tbody>

                </table>
            

            `,
        bindings: {
            data:'<',
            loadconfig: '&',
            oConfig: '<'
        },
        controller: ['$rootScope','$timeout', '$translate','menuService','_', function ($rootScope,$timeout, $translate,timeService,_) {

            const $ctrl = this;

            // $ctrl.summary = $ctrl.summary;



            $ctrl.valueChanged = function () {
                $ctrl.loadconfig.apply(this)( $ctrl.data.name.split(' ').join('_').toLowerCase(), $ctrl.config)
            }


            $rootScope.$watch('pendingRequests', function(){
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });

            $ctrl.loadConfig = ()=>{
                //debugger
                $ctrl.config = $ctrl.oConfig[$ctrl.data.name.split(' ').join('_').toLowerCase()];
            }

            $ctrl.$onChanges = (changes) => {
                // $ctrl.resolve.currentValue.params.confDams.MERCATALE



                if(changes.data){

                    $ctrl.loadConfig();
                }

            };

            $ctrl.$onInit =  () => {

                //$ctrl.oConfig[$ctrl.data.name.split(' ').join('_').toLowerCase()]

            };
        }]
    });
})();
