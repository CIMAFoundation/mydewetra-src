(function () {


    dewetraApp.service('laminazioneChientiService', ['serieService', 'menuService', 'apiService', '_','$translate', function (serieService, timeService, apiService, _,$translate) {


        let confDamsObj = {
            'CHIENTI': {
                'input': {
                    'FloodProof Marche Det Ecmwf': [
                        {
                            chain: 'marche.floodproof.deterministicecmwf'
                        },
                        {
                            server: 1,
                            serie: "all.sensor.hydrometers",
                            featureId: "210822518;2",
                            name: "diga_di_borgiano"
                        },
                        {
                            server: 1,
                            serie: "all.sensor.hydrometers",
                            featureId: "210822517;2",
                            name: "diga_di_polverina"
                        },
                        {
                            server: 1,
                            serie: "all.sensor.hydrometers",
                            featureId: "210822516;2",
                            name: "diga_di_fiastrone"
                        }
                    ],
                    'marche.floodproofs.deterministiclami_chain': [
                        {
                            chain: 'marche.floodproof.deterministicecmwf'
                        },
                        {
                            server: 1,
                            serie: "all.sensor.hydrometers",
                            featureId: "210822518;2",
                            name: "diga_di_borgiano"
                        },
                        {
                            server: 1,
                            serie: "all.sensor.hydrometers",
                            featureId: "210822517;2",
                            name: "diga_di_polverina"
                        },
                        {
                            server: 1,
                            serie: "all.sensor.hydrometers",
                            featureId: "210822516;2",
                            name: "diga_di_fiastrone"
                        }
                    ]
                }
            }
        };


        var postFirstScript = null;

        var postThirdScript = null

        var lastManovre = null;

        var firstScriptResult = null;
        var secondScriptResult = null;
        var thirdScriptResult = null;

        var fourthScriptInput = null;

        var fourthScriptResult = null;

        let hydrometerLoaded;


        var oFrom = moment(new Date(timeService.getDateFrom()));

        var oTo = moment(new Date(timeService.getDateTo()));
//summary, optimisation e verification Propagation(only for some dams like corbara)

        var oInitialData, oOptimisationData, oVerificationData, oPropagationData, oSummaryScriptResult,
            oOptimisationScriptResult, oVerificationScriptResult, oPropagationScriptResult;

        alertErrorOld = (data) => {
            if (data.dewetra.hasOwnProperty('errors') && data.dewetra.errors.length == 1 && Object.keys(data.dewetra.errors[0]).length >= 1) {
                Object.keys(data.dewetra.errors[0]).map(e => {
                    if (data.dewetra.errors[0][e] != null && data.dewetra.errors[0][e].hasOwnProperty('label')) {
                        alert(data.dewetra.errors[0][e].label);
                    }
                })
            }
        };


        alertErrorSummary = (aData) => {

            if(Array.isArray(aData.tables) && aData.tables.length > 0){
                aData.tables.forEach((data) => {
                    if (data.dewetra.hasOwnProperty('errors') && data.dewetra.errors.length == 1 && Object.keys(data.dewetra.errors[0]).length >= 1) {
                        Object.keys(data.dewetra.errors[0]).map(e => {
                            if (data.dewetra.errors[0][e] != null && data.dewetra.errors[0][e].hasOwnProperty('label')) {
                                alert(data.dewetra.errors[0][e].label);
                            }
                        })
                    }
                })
            }
        }

        alertError = (aData) => {

            if(Array.isArray(aData) && aData.length > 0){
                aData.forEach((data) => {
                    if (data.hasOwnProperty('errors') && data.errors.length == 1 && Object.keys(data.errors[0]).length >= 1) {
                        Object.keys(data.errors[0]).map(e => {
                            if (data.errors[0][e] != null && data.errors[0][e].hasOwnProperty('label')) {
                                alert(data.errors[0][e].label);
                            }
                        })
                    }
                })
            }
        }

        alertErrorOptimization = (aData) => {

            if(Array.isArray(aData.tables) && aData.tables.length > 0){
                aData.tables.forEach((data) => {
                    if (data.hasOwnProperty('dewetra') && data.dewetra.hasOwnProperty('errors') && data.dewetra.errors.length == 1 && Object.keys(data.dewetra.errors[0]).length >= 1) {
                        Object.keys(data.dewetra.errors[0]).map(e => {
                            if (data.dewetra.errors[0][e] != null && data.dewetra.errors[0][e].hasOwnProperty('label')) {
                                alert(data.dewetra.errors[0][e].label);
                            }
                        })
                    }
                })
            }
        }

        return {

            setConfObj: (data) => {
                confDamsObj = data;
            },

            getConfObj: () => {
                return confDamsObj;
            },

            setSummaryScriptResult: (data) => {
                oSummaryScriptResult = data;
            },
            getSummaryScriptResult: () => {
                return oSummaryScriptResult;
            },

            setOptimisationScriptResult: (data) => {
                oOptimisationScriptResult = data;
            },
            getOptimisationScriptResult: () => {
                return oOptimisationScriptResult;
            },

            setVerificationScriptResult: (data) => {
                oVerificationScriptResult = data;
            },
            getVerificationScriptResult: () => {
                return oVerificationScriptResult;
            },

            setPropagationScriptResult: (data) => {
                oPropagationScriptResult = data;
            },
            getPropagationScriptResult: () => {
                return oPropagationScriptResult;
            },

            dateRef: function () {
                return oFrom.toDate();
            },

            dateTo: function () {
                return oTo.toDate();
            },

            getFourthScriptResult: function () {
                return fourthScriptResult;
            },

            getLevelChartData: function () {

                return {
                    hres_a: firstScriptResult.hres_a,
                    hmax: firstScriptResult.hmax,
                    t_qin_main: firstScriptResult.t_qin_main
                }
            },

            loadLaminazioneDataFake: function (sDams, sConfig, okCallback, koCallback) {
                const _Service = this;

                const series = {};

                _Service.postConfigurazioneSummaryScriptFake(sDams, series, okCallback, koCallback);
            },

            loadLaminazioneData: function (sDams, aObjForecast, okCallback, koCallback) {
                const _Service = this;
                const from = timeService.getDateFromUTCSecond();
                const to = timeService.getDateToUTCSecond();

                const series = {};

                let itemProcessed = 0;

                let aObjForecastFiltered = aObjForecast.filter(e => e.hasOwnProperty('name') && e.name != null && e.name != '');

                aObjForecastFiltered.forEach(function (obj, index, array) {
                    //from less on month
                    serieService.getSeriesDirect(obj.server, obj.serie, obj.featureId, from, to, function (data) {
                        series[obj.name] = data;
                        itemProcessed++;
                        if (array.length == itemProcessed) {
                            _Service.postConfigurazioneSummaryScript(sDams, series, aObjForecast, okCallback, koCallback);
                        }
                    }, koCallback)
                });

            },


            postConfigurazioneSummaryScript: function (sDams, series, aObjForecast, okCallback, koCallback) {

                let chain = aObjForecast.filter(e => e.hasOwnProperty('chain'))[0].chain;
                const from = timeService.getDateFromUTCSecond();
                const to = timeService.getDateToUTCSecond();

                hydrometerLoaded = series;

                let obj = {
                    "alg": sDams + ".laminazione.summary",
                    "input": {
                        "selected_chain": chain,
                        "from_date": from,
                        "to_date": to,
                        series
                    }
                }


                oInitialData = obj;

                apiService.postExtJson(window.app.url.laminazione70Url, oInitialData, function (data) {
                    // apiService.postExtJson('http://130.251.104.70:10000/runscript/' , oInitialData,function (data) {
                    oSummaryScriptResult = data;

                    alertErrorSummary(data.summaryList);

                    if (okCallback) okCallback(data)
                }, function (data) {
                    if(data.message){

                        alert(decodeURI(data.message.split('=')[1]))
                    }



                })

            },

            postConfigurazioneOptimisationScript: function (sDam, oConfig, okCallback, koCallback) {

                const _This = this;
                //vuole gli stessi input del primo ritorna 6 manove e portata turbinata
                if (oInitialData) {

                    oOptimisationData = angular.copy(oInitialData);

                    //quando carico il secondo script sovrascrivo sempre questi dati inseriti dall'utente?
                    oOptimisationData["alg"] = sDam + ".laminazione.optimisation";

                    oOptimisationData["input"] = {...oConfig, ...oOptimisationData["input"]}
                    //oOptimisationData["input"]["series"] = hydrometerLoaded;
                    //oOptimisationData["input"]["from_date"] = 1654842000;
                    //oOptimisationData["input"]["to_date"] = 1654844400;

                    apiService.postExtJson(window.app.url.laminazione70Url, oOptimisationData, function (data) {
                        //apiService.postExtJson('http://130.251.104.70:10000/runscript/' , oOptimisationData,function (data) {
                        oOptimisationScriptResult = data.optimisationList;
                        const modalObj = {};

                        alertErrorOptimization(data.optimisationList);

                        // oOptimisationScriptResult.map((optimisationObj) => {
                        //     if(optimisationObj.dewetra.hasOwnProperty("rel") && optimisationObj.dewetra.hasOwnProperty("t_rel")){
                        //         optimisationObj.dewetra.modelObj = optimisationObj.dewetra.t_rel.map((t_rel,index) => {
                        //             let newDate = new Date(t_rel);
                        //             let obj = {
                        //                 date:moment(newDate),
                        //                 percentage:100,
                        //                 value: optimisationObj.dewetra["rel"][index],
                        //                 name: "Manovra "+index,
                        //                 descr:"rel"
                        //             };
                        //             // console.log(obj);
                        //             if(moment(obj.date).isValid()) return obj;
                        //         })
                        //     }
                        //     return optimisationObj
                        // });


                        oPropagationData = oOptimisationScriptResult;

                        // _This.postConfigurationPropagationScript(sDam,function (data) {
                        //     console.log("FourthScript")
                        //     console.log(data);
                        //     oPropagationScriptResult = data
                        // },function (data) {
                        //     oPropagationScriptResult = data
                        // })

                        //edit data to be fitted in modal obj
                        if (okCallback) okCallback(modalObj, oOptimisationScriptResult);
                    }, function () {

                        alert("error");
                    })
                }
            },


            postConfigurazioneVerificationScript: function (sDams, oConfig, okCallback, koCallback) {

                var _This = this;
                //vuole gli stessi input del primo ritorna 6 manove e portata turbinata
                if (oOptimisationData|| oInitialData) {

                    oVerificationData =(oOptimisationData)? angular.copy(oOptimisationData):angular.copy(oInitialData);

                    oVerificationData["alg"] = sDams + ".laminazione.verification";

                    oVerificationData["input"] = { ...oVerificationData["input"],...oConfig}

                    apiService.postExtJson(window.app.url.laminazione70Url, oVerificationData, function (data) {
                        oVerificationScriptResult = data.verificationList;
                        alertErrorOptimization(data.verificationList);

                        oPropagationData = oVerificationData;

                        okCallback(data.verificationList);

                        try {
                            _This.postConfigurazioneFourthScript(function (data) {

                                oPropagationScriptResult = data
                            }, function (data) {
                                oPropagationScriptResult = data
                            })
                        }catch (e) {
                            console.log(e);
                        }




                    }, function (err) {
                        console.log(err)
                    });
                }
            },

            postConfigurationPropagationScript: function (sDam, okCallback, koCallback) {

                console.log(oPropagationData);

                var o = angular.copy(oPropagationData);
                o.from_date = timeService.getDateFromUTCSecond();
                o.to_date = timeService.getDateToUTCSecond();

                var obj = {
                    "alg": sDam + ".laminazione.propagation",
                    "input": o,
                };

                apiService.postExtJson(window.app.url.laminazione70Url, obj, function (data) {

                    alertError(data);
                    okCallback(data)
                }, function () {
                    //var o ={"Stimigliano": {"Q": [8.1, 0.0, 0.05, 0.23, 0.55], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Orte": {"Q": [8.1, 3.5, 5.83, 8.19, 8.33], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Ponte Felice": {"Q": [8.1, 0.0, 0.55, 1.33, 2.24], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Monte Aniene": {"Q": [21.1, 12.2, 9.6, 7.0, 7.0], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Ponte Grillo": {"Q": [8.1, 0.0, 0.0, 0.01, 0.04], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}}
                    okCallback(o)
                })
            },


            exportManovreToCsv: function (manovre) {
                var csvHeader = "data:text/csv;charset=utf-8,";

                manovre.forEach(function (manovra, index, array) {
                    var row = moment(manovra.date).format() + "," + manovra.value;
                    csvHeader += row + "\r\n";
                })
                return csvHeader;
            }

        }

    }])


})();
