(function () {


    dewetraApp.component('warningsGeneric', {

        template: `
            
            <div class="row flex-container col" >
                <div class="flex-item" ng-repeat="(key,value) in $ctrl.data[0]">{{value.label}}</div>
            </div>          

            `,
        bindings: {
                data: '<',
        },
        controller: ['$rootScope', '$timeout', '$translate', 'menuService', '_', function ($rootScope, $timeout, $translate, timeService, _) {

            const $ctrl = this;

            $rootScope.$watch('pendingRequests', function () {
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });

            $ctrl.$onChanges = (changes) => {

                if (changes.data) {

                }

            };

            $ctrl.$onInit = () => {

            };
        }]
    });
})();
