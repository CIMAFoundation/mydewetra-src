/**
 * Created by dario on 27/10/16.
 */


(function () {


    dewetraApp.component('laminazioneChienti', {
        //templateUrl: 'apps/dewetra2/js/components/timebar/timebar.html',
        template: `
            <div class="laminazione">
    <div class="modal-header">
        <div class="flex-container" id="sensorTitle">
            <!--Title-->
            <div class="brand flex-item">

                <h3 class="modal-title" id="modal-title">Laminazione {{$ctrl.resolve.params.nameDam}}</h3>
            </div>

            <div class=" flex-item">
                <a class="close" ng-click="$ctrl.closePopup()" href>
                    <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                </a>
            </div>
        </div>
    </div>

    <div class="modal-body" id="modal-body">

        <div id="wizard-step-container">
            <ul class="nav nav-pills nav-justified">
                <li ng-repeat="step in $ctrl.steps" ng-class="{'active':step.step == $ctrl.currentStep}">
                    <a ng-click="$ctrl.gotoStep(step.step)" href="">{{step.step}}. {{step.name}}</a>
                </li>
            </ul>
        </div>
        <div id="wizard-content-container" class="">

            <ng-include src="$ctrl.getStepTemplate()"></ng-include>
        </div>


    </div>



    <div class="modal-footer">
        <div ng-show="$ctrl.pendingRequests != 0" class="loader loader--style1" title="0" style="position:fixed; z-index:9999;">
            <svg version="1.1" id="loader-1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                 width="40px" height="40px" viewBox="0 0 40 40" enable-background="new 0 0 40 40" xml:space="preserve">
\t\t    <path opacity="0.2" fill="#000" d="M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946
\ts14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634
\tc0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z"/>
                <path fill="#000" d="M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0
\tC22.32,8.481,24.301,9.057,26.013,10.047z">
\t\t    <animateTransform attributeType="xml"
                              attributeName="transform"
                              type="rotate"
                              from="0 20 20"
                              to="360 20 20"
                              dur="0.5s"
                              repeatCount="indefinite"/>
            </path>
\t        </svg>
        </div>
        <!--<button class="btn btn-primary" type="button" ng-click="update()">OK</button>-->
        <button class="btn btn-warning" ng-class="{'disabled':($ctrl.pendingRequests != 0)}" type="button" ng-click="$ctrl.closePopup()">Cancel</button>
        <button ng-disabled="$ctrl.currentStep <= 1" ng-class="{'disabled':($ctrl.pendingRequests != 0)}" class="btn btn-default" name="previous" type="button" ng-click="$ctrl.gotoStep($ctrl.currentStep - 1)"><i class="fa fa-arrow-left"></i> Previous step</button>
        <button ng-disabled="$ctrl.currentStep >= $ctrl.steps.length ||$ctrl.currentStep == 2" ng-class="{'disabled':($ctrl.pendingRequests != 0)}" class="btn btn-primary" name="next" type="button" ng-click="$ctrl.gotoStep($ctrl.currentStep + 1)">Next step <i class="fa fa-arrow-right"></i></button>
        <!--<button ng-disabled="currentStep != steps.length" class="btn btn-success" name="next" type="button"> <i class="fa fa-floppy-o"></i> Save</button>-->
    </div>

</div>

            `,
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['$rootScope', '$timeout', '$translate', 'laminazioneChientiService', 'menuService', '_', function ($rootScope, $timeout, $translate, laminazioneService, timeService, _) {


            const $ctrl = this;

            $ctrl.options = {
                currentChart: {},
                optimisationSelected: {}
            };

            $ctrl.optimisationResults = {};
            $ctrl.verificationResults = {};
            $ctrl.tableData = {};

            $ctrl.resultsData = {};

            $ctrl.runStepData = {};

            console.log("laminazione component Chienti init");

            $ctrl.currentStep = 1;

            $ctrl.oConfig = {};


            $rootScope.$watch('pendingRequests', function () {
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });


            $ctrl.summaryData = {};

            $ctrl.steps = [
                {
                    step: 1,
                    name: "Selezione Input di previsione",
                    template: "apps/dewetra2/js/components/laminazione-chienti/step/inputPrevBis.html"
                },
                {
                    step: 2,
                    name: "Riepilogo",
                    template: "apps/dewetra2/js/components/laminazione-chienti/step/riepilogo.html"
                },
                {
                    step: 3,
                    name: "Input Manovre",
                    template: "apps/dewetra2/js/components/laminazione-chienti/step/inputManovre.html"
                },
                {
                    step: 4,
                    name: "Run",
                    template: "apps/dewetra2/js/components/laminazione-chienti/step/run.html"
                },
                {
                    step: 5,
                    name: "Chart",
                    template: "apps/dewetra2/js/components/laminazione-chienti/step/chart.html"
                },
                {
                    step: 6,
                    name: "Risultati",
                    template: "apps/dewetra2/js/components/laminazione-chienti/step/risultati.html"
                },
            ];


            $ctrl.loadForecast = function () {
                return $ctrl.resolve.params.confDams[$ctrl.resolve.params.nameDam].input;
            }

            $ctrl.forecastSelected = function () {

                laminazioneService.loadLaminazioneData($ctrl.resolve.params.nameDam, $ctrl.oConfig.conf, function (data) {

                    $ctrl.summaryData = data;

                    $ctrl.summaryData.summaryList.tables.map(table => { // inizializzo una manovra iniziale a 0
                        table.dewetra.rel = [0];
                        table.dewetra.t_rel = [table.dewetra.t_start]
                    })


                    $ctrl.updateTableData($ctrl.summaryData.summaryList.tables)

                    $ctrl.loadoConfig();
                    $ctrl.oConfig.minDate = moment(new Date($ctrl.summaryData.summaryList.tables[0].dewetra.t_start));
                    $ctrl.oConfig.maxDate = moment(new Date($ctrl.summaryData.summaryList.tables[0].dewetra.t_end));
                    $ctrl.gotoStep(2);
                })
            }

            $ctrl.loadoConfig = () => {

                $ctrl.summaryData.summaryList.tables.map(summary =>{

                    $ctrl.oConfig[summary.dewetra.name.split(' ').join('_').toLowerCase()] = {
                        SM: 0,
                        delta_drawdown: 0,
                        q_turb: 0,
                        current_release: 0,
                        rel : summary.dewetra.rel,
                        t_rel : summary.dewetra.t_rel,
                    };

                })

            }



            $ctrl.dateOption = function (index) {
                // console.log(index);
                return {
                    dropdownSelector: 'sel' + index,
                    minView: 'hour',
                    // minDate:$ctrl.dateToOption.minDate,
                    // maxDate:$ctrl.dateToOption.maxDate,
                }
            }


            //non far accedere al secondo step direttamente
            $ctrl.checkNgClickOnNext = function (newStep, callback) {

                if (newStep != 2) {
                    callback(newStep)
                }

            }

            // $ctrl.$watch('oConfig.qturb',function () {
            //
            //     if($ctrl.currentStep == 2){
            //         if($ctrl.oConfig.qturb < 0 || $ctrl.oConfig.qturb >= 200 || $ctrl.oConfig.qturb === undefined) {
            //             alert("qturb should be from 0 to 200")
            //             $ctrl.oConfig.qturb = 0
            //         }
            //     }
            // })

            $ctrl.checkQturb = () => {
                // if($ctrl.currentStep == 2){
                //     if($ctrl.oConfig.qturb < 0 || $ctrl.oConfig.qturb >= 200 || $ctrl.oConfig.qturb === undefined) {
                //         alert("qturb should be from 0 to 200")
                //         $ctrl.oConfig.qturb = 0
                //     }
                // }
            }


            $ctrl.gotoStep = function (newStep, skipCondition) {

                console.log("change step");
                if ($ctrl.currentStep == 2) {
                    //check the value
                    let condition = true

                    Object.keys($ctrl.oConfig).map((sName) => {
                        if ($ctrl.oConfig[sName] == null) {
                            alert('check: %s', sName);
                            condition = false
                        }
                    })
                    if (condition) $ctrl.currentStep = newStep;
                }
                $ctrl.currentStep = newStep;
            }


            $ctrl.getStepTemplate = function () {
                for (var i = 0; i < $ctrl.steps.length; i++) {
                    if ($ctrl.currentStep == $ctrl.steps[i].step) {
                        return $ctrl.steps[i].template;
                    }
                }
            }


            $ctrl.updateChartData = function (data, string) {
                console.log("chartData updated:" + (string) ? string : "");
                $ctrl.chartData = data;
            };

            $ctrl.updateTableData = function (data, string) {
                console.log("chartData updated:" + (string) ? string : "");
                $timeout(function () {
                    $ctrl.tableData = data;
                    if($ctrl.tableData[0])$ctrl.optimisationSelected = $ctrl.tableData[0]
                    if($ctrl.tableData[1])$ctrl.optimisationSelected = $ctrl.tableData[1]
                    if($ctrl.tableData[2])$ctrl.optimisationSelected = $ctrl.tableData[2]
                    if($ctrl.tableData[0])$ctrl.optimisationSelected = $ctrl.tableData[0]
                },0)

            };


            $ctrl.toLocalTimeString = function (date) {
                // var tzOffSet = Math.abs(date.getTimezoneOffset())*60000;
                try {
                    var date = new Date(date.getTime());
                    return moment(date).format('lll');
                } catch (e) {
                    // console.log(e)
                }


            };


            $ctrl.loadConfigurationFromComponent = function (dam, config) {
                $ctrl.oConfig[dam] = {...$ctrl.oConfig[dam], ...config};
            }

            $ctrl.loadManovreFromComponent = function (dam, manovre) {

                $ctrl.oConfig[dam] = {...$ctrl.oConfig[dam], ...manovre};

            }

            $ctrl.manovre = function (dam, manovre) {
                $ctrl.optimisationResults.tables[0].dewetra.name
            }

            initManovrePostOptimization = () => {
                debugger
                $ctrl.optimisationResults.tables.map((tableObj) => {
                    let diga = tableObj.dewetra.name.toLowerCase().split(' ').join('_');
                    let rel = tableObj.dewetra.rel;
                    let t_rel = tableObj.dewetra.t_rel;
                    $ctrl.loadManovreFromComponent(diga,{t_rel,rel})
                })
            }



            $ctrl.loadOptimisationScript = function () {

                laminazioneService.postConfigurazioneOptimisationScript($ctrl.resolve.params.nameDam, $ctrl.oConfig, function (modalObj, data) {
                    $ctrl.optimisationResults = data
                    $ctrl.updateTableData(data.tables, 'Data Updated from Optimization script');
                    $ctrl.updateChartData(data.charts, "Optimization");
                    //put rel and t rel in client request
                    initManovrePostOptimization();
                    $ctrl.gotoStep(4,);
                })
            };


            $ctrl.loadVerificationScript = function (callback) {

                laminazioneService.postConfigurazioneVerificationScript($ctrl.resolve.params.nameDam, $ctrl.oConfig, function (data) {
                    $ctrl.verificationResults = data;
                    // for(var i in $ctrl.modelObject){
                    //     $ctrl.modelObject[i].value = data["rel"][i]
                    //     $ctrl.modelObject[i].date = new Date(data["t_rel"][i])
                    // }
                    //
                    // $ctrl.modelObject = $ctrl.modelObject.filter(m => moment(m.date).isValid())

                    $ctrl.resultsData = data.summary;

                    $ctrl.updateTableData(data.tables, 'Data Updated from Verification script');

                    $ctrl.updateChartData(data.charts, "Verification");

                    if (callback) callback()
                }, function (err) {
                    console.log(err)
                })
            }


            $ctrl.run = function () {

                $ctrl.loadVerificationScript(function () {
                    $ctrl.gotoStep(4, true)

                    $timeout(function () {
                        $ctrl.loadChart("level")
                    }, 1000)
                });


            }

            $ctrl.livelloInvaso = 130;

            $ctrl.dateTo = moment(new Date(timeService.getDateTo())).format('lll');
            $ctrl.dateFrom = moment(new Date(timeService.getDateFrom())).format('lll');


            $ctrl.maxDate = function (dates) {
                var iMaxDate = laminazioneService.dateTo().getTime() + (72 * 60 * 60000)

                for (var i = 0; i < dates.length; i++) {
                    if (iMaxDate < dates[i].utcDateValue) {
                        dates[i].selectable = false;
                    }
                }
            }


            $ctrl.dateTimeConfig = function (manovra, index) {

                return {
                    // modelType:,
                    dropdownSelector: 'sel' + index,
                    startView: 'hour',
                    minView: 'hour',
                    // timezone:'utc'
                }
            };


            $ctrl.modelObject = [];


            $ctrl.downloadManovre = function () {
                var encodedUri = encodeURI(laminazioneService.exportManovreToCsv($ctrl.modelObject));
                var link = document.createElement("a");
                link.setAttribute("href", encodedUri);
                link.setAttribute("download", "manovre.csv");
                link.innerHTML = "Click Here to download";
                // document.body.appendChild(link); // Required for FF

                link.click();
            };

            $ctrl.dateFormatter = function (date) {

                // return moment.utc(date).format('DD-MM-YYYY HH:mm')+" Ora locale (UTC"+moment(date).format('Z)');
                return moment.utc(date).format('DD-MM-YYYY HH:mm') + " (UTC)";
                // return date.toISOString()

            };

            $ctrl.ottimizzaManovre = function () {
                $ctrl.loadSecondScript()
            };

            $ctrl.verificaManovre = function () {
                $ctrl.gotoStep(3);

            };

            $ctrl.loadChart = function (chartValue) {
                console.log(chartValue);
                $ctrl.options.currentChart = chartValue;
            }


            $ctrl.onLocationSelected = function (location) {
                if ($ctrl.close) $ctrl.dismiss(location);
            };

            $ctrl.update = function () {
                if ($ctrl.close) $ctrl.close();

            };

            $ctrl.closePopup = function () {
                // $uibModalInstance.dismiss('cancel')
                if ($ctrl.close) $ctrl.close();

            };


            $ctrl.$onChanges = (changes) => {
                // $ctrl.resolve.currentValue.params.confDams.MERCATALE

                if (changes.resolve.currentValue && changes.resolve.currentValue.params && changes.resolve.currentValue.params.confDams && Object.keys(changes.resolve.currentValue.params.confDams).length > 0) {

                }

            };

            $ctrl.$onInit = () => {


            };


        }]
    });
})();
