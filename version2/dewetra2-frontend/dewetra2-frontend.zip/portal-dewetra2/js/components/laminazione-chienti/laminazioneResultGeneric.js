(function () {


    dewetraApp.component('resultGeneric', {

        template: `
            
            <div class="row">
        
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <h4>{{$ctrl.data.name}}</h4>
                        <ul style="font-size: 110%">
                <li ng-repeat="(key, value) in $ctrl.data.summary track by $index">{{value}}</li>
            </ul>
        </div>
        
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="flex-item p-5">
                <h5 class="text-left" >
                    {{$ctrl.summary.description}}
                </h5>
            </div>
        </div>
    </div>            

            `,
        bindings: {
            data: '<',
        },
        controller: ['$rootScope', '$timeout', '$translate', 'menuService', '_', function ($rootScope, $timeout, $translate, timeService, _) {

            const $ctrl = this;

            $rootScope.$watch('pendingRequests', function () {
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });

            $ctrl.$onChanges = (changes) => {

                if (changes.data) {
                }

            };

            $ctrl.$onInit = () => {

            };
        }]
    });
})();
