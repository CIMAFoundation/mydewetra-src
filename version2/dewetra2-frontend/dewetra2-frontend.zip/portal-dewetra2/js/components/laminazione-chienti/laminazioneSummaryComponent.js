/**
 * Created by dario on 27/04/22.
 */


(function () {


    dewetraApp.component('summaryGeneric', {

        template: `
            
            <div class="row">
        
        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
            <h4>{{$ctrl.data.name}}</h4>
                        <ul style="font-size: 110%">
                <li ng-repeat="(key, value) in $ctrl.data.summary track by $index">{{value}}</li>
            </ul>
        </div>
        <div  class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
            <div class="col-xs-12 col-sm-9 col-md-9 col-lg-8">

            <laminazione-chienti-input-generic data="$ctrl.data" loadconfig="$ctrl.callback" o-config="$ctrl.oConfig"></laminazione-chienti-input-generic>

            </div>
            



        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="flex-item p-5">
                <h5 class="text-left" >
                    {{$ctrl.summary.description}}
                </h5>
            </div>
        </div>
    </div>            

            `,
        bindings: {
            data: '<',
            loadconfig: '&',
            oConfig: '<'
        },
        controller: ['$rootScope', '$timeout', '$translate', 'menuService', '_', function ($rootScope, $timeout, $translate, timeService, _) {

            const $ctrl = this;


            $ctrl.callback = (diga, data) => {
                $ctrl.loadconfig.apply(this)(diga, data);
            }
            // $ctrl.valueChanged = function () {
            //     try {
            //         $ctrl.loadconfig.apply(this)($ctrl.data.name.split(' ').join('_').toLowerCase(), $ctrl.oConfig)
            //     }catch (e) {
            //         console.log(e)
            //     }
            //
            // }


            $rootScope.$watch('pendingRequests', function () {
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });


            $ctrl.$onChanges = (changes) => {

                if (changes.data) {
                    //$ctrl.valueChanged()//inizializzo i dati
                }

            };

            $ctrl.$onInit = () => {
                //$ctrl.valueChanged()//inizializzo i dati

            };
        }]
    });
})();


