/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('laminazioneChientiManovreComponent', {
        template: `

        <style>
    .dropdown-menu {top:inherit!important; border-color:#144e86; border-width:2px;}
</style>
<div class="container">
    <div class="row ">
</div>
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
            <div class="flex-item flex-container col center p-5 animated fadeIn delay-001">
                <div class="input-group-prepend">
                    <!--<span class="input-group-text">Data minima: {{$ctrl.t_start.format('lll')}} UTC</span>-->
                    <span class="input-group-text">Data minima: {{$ctrl.oConfig.minDate.format('LLL')}}</span>

                </div>
            </div>
            <div class="flex-item flex-container col center p-5 animated fadeIn delay-001">
                <div class="input-group-prepend">
                    <!--<span class="input-group-text">Data massima: {{ $ctrl.t_end.format('lll')}} UTC</span>-->
                    <span class="input-group-text">Data Massima: {{$ctrl.oConfig.maxDate.format('LLL')}}</span>
                </div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
            <laminazione-chienti-input-generic data="$ctrl.data.dewetra" loadconfig="$ctrl.callback" o-config="$ctrl.oConfig"></laminazione-chienti-input-generic>
        </div>





        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

            <div ng-if="$ctrl.modelObject.length == 0" class="flex-item flex-container col center p-" style="flex-direction: row">
                <div  ng-click="$ctrl.addManovra()" class="flex-item"><i class="fa fa-2x fa-plus" > </i></div>
                <div class="flex-item"><h5>Aggiungi manovra</h5></div>
            </div>
            <div  ng-repeat="paratoia in $ctrl.modelObject" class="flex-container col center">

                <div class="flex-item flex-container " ng-mouseleave="$ctrl.trigManovre()">


                <div class="flex-item  flex-container col center p-5">
                    <h3 style="" class="infoTitle text-center" translate >
                        {{paratoia.name}}
                    </h3>
                    <i class="fa fa-close fa-2x" ng-click="$ctrl.removeManovra($index)"></i>
                </div>
                <div class="flex-item  p-5">
                    <div class=" dateFrom flex-container col center">
                        <div class="dropdown-menu animated tada" role="menu">
                            <!--<datetimepicker data-ng-model="paratoia.date"  data-datetimepicker-config="{dropdownSelector: 'sel'+$index,-->
                        <!--minView:'hour',maxDate:paratoia.maxDate}"/>-->
                            <datetimepicker data-ng-model="paratoia.date"  
                                            data-datetimepicker-config="dateTimeConfig(paratoia, $index)" 
                                            data-before-render="paratoia.maxDate($dates,$ctrl.modelObject[$index -1],$view,  $leftDate, $upDate, $rightDate)" 
                                            data-on-set-time="$ctrl.onSetTime(newDate, oldDate, paratoia)" />
                        </div>
                        <a href class="dropdown-toggle titip-top" 
                                id="sel{{$index}}" 
                                role="button" 
                                data-toggle="dropdown" >
                            <i style="" class="fa fa-calendar fa-3x">
                                <span class="titip-content">DATE_TO: {{paratoia.date.toUTCString()}}</span>
                            </i>
                        </a>
                        <h6>{{$ctrl.maneuverDateFormatter(paratoia)}}</h6>
                    </div>
                </div>

                <div class="flex-item flex-container col center p-5">
                    <h3 class="infoTitle text-center" translate >
                        Portata da Scaricare:
                    </h3>
                    <input ng-change="$ctrl.trigManovre()" type="number" ng-model="paratoia.value" step="1" min="0" class="form-control" aria-label="Amount ">
                    <div class="input-group-append">
                        <span class="input-group-text label">m<sup>3</sup>/s</span>
                    </div>
                    <!--<div ng-if="$last"  ng-click="addManovra()" class="flex-item">-->
                        <!--<i class="fa fa-2x fa-plus" > </i><p>Aggiungi manovra</p>-->
                    <!--</div>-->
                </div>

            </div>
                <div ng-if="$last" class="flex-item flex-container col center p-" style="flex-direction: row">
                    <div  ng-click="$ctrl.addManovra()" class="flex-item"><i class="fa fa-2x fa-plus" > </i></div>
                    <div class="flex-item"><h5>Aggiungi manovra</h5></div>
                </div>


            </div>

        </div>
        

        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="flex-item flex-container col center p-5">
                <h3  class="text-center"  >
                    <span style="">L'ultima manovra termina a fine intervallo di analisi</span>

                </h3>
            </div>
        </div>




    </div>
</div>



        `,
        //template:`<div id="chart" className="animated fadeIn"></div>`,
        bindings: {
            minDate: '<',
            maxDate: '<',
            data:'<',
            loadconfig: '&',
            loadmanovre: '&',
            oConfig: '<'

        },
        controller: ['mapService', '$rootScope', '$translate', 'menuService', '_', function (mapService, $rootScope, $translate, menuService, _) {
            const $ctrl = this;

            $ctrl.oConfig = {
                alreadyInited: false
            };

            $ctrl.closePopup = function () {
                $ctrl.close();
            }

            $ctrl.$onInit = function () {
                console.log("laminazioneChientiInputManovreComponent");
                try {
                    $ctrl.extractManovre();
                    $ctrl.initManovre();

                }catch (e) {
                    console.log(e);
                }
            };

            $ctrl.$onChanges = function (value) {

                console.log("laminazioneChientiInputManovreComponent changes");

                if (value.data.currentValue !== value.data.previousValue && value.data.currentValue !== null) {
                    $ctrl.initManovre();
                    $ctrl.trigManovre();
                }
            };

            $ctrl.callback = (diga, data) => {
                $ctrl.loadconfig.apply(this)(diga, data);
            }

            $ctrl.extractManovre = function () {
                let t_rel = $ctrl.modelObject.map(manovra => moment(manovra.date).format('YYYY-MM-DD HH:mm:ss'))
                //let t_rel = $ctrl.modelObject.map(manovra => moment(manovra.date).unix())
                let rel = $ctrl.modelObject.map(manovra => manovra.value)
                let diga = $ctrl.data.dewetra.name.toLowerCase().split(' ').join('_');
                $ctrl.data.dewetra.t_rel = t_rel;
                $ctrl.data.dewetra.rel = rel;

                $ctrl.loadmanovre.apply(this)(diga, {t_rel,rel});
            }

            $ctrl.trigManovre = function () {
                $ctrl.extractManovre();
            }


            $ctrl.addManovra = function(){

                if(o) delete o;

                // var diff= 60*($ctrl.modelObject.length+1);//moltiplicavo incrementale per 3 ore

                var diff = 60*3;//moltiplico per 3 ore

                if($ctrl.modelObject.length > 0){//se è presente almeno una manovra imposto la data della manovra precedente + 3 ore
                    try {//serve solo per non generare un errore se vanno all input manovre senza avere un t_start e quindi una prima manovra gia impostata
                        var oDate = new Date($ctrl.modelObject[$ctrl.modelObject.length-1].date.getTime()+ diff*60000);
                    }catch (e) {
                        var oDate = new Date();
                    }


                }else{
                    //altrimenti uso la data t_start

                    if($ctrl.oConfig.minDate) {
                        var oDate =new Date($ctrl.oConfig.minDate.toDate())
                        console.log(oDate)
                    }

                    // var oDate = new Date(Date.UTC($ctrl.t_start.toDate()));
                }


                // data-before-render="beforeRender($view, $dates, $leftDate, $upDate, $rightDate)"
                var o = {
                    date:oDate,
                    maxDate:function ($dates,oManovraBefore,$view,  $leftDate, $upDate, $rightDate) {
                        // var tzOffSet =Math.abs(oDate.getTimezoneOffset())

                        let iMinDate = $ctrl.oConfig.minDate.valueOf();

                        if(oManovraBefore){
                            iMinDate = oManovraBefore.date.valueOf();
                        }


                        //data max 72 ore dopo
                        var iMaxDate = $ctrl.oConfig.maxDate.valueOf()+ (72*60*60000)

                        for(var i=0; i<$dates.length;i++) {
                            if(iMaxDate < $dates[i].utcDateValue || $dates[i].utcDateValue < iMinDate) {
                                $dates[i].selectable = false;
                            }
                        }
                    },
                    percentage:100,
                    value:0,
                    time:100,
                    name:"Manovra "+(parseInt($ctrl.modelObject.length)+1),
                    descr:"rel"
                };

                // o.date =

                $ctrl.modelObject.push(angular.copy(o));
            };

            $ctrl.removeManovra = function(index){
                $ctrl.modelObject.splice(index,1);

                for(let i in $ctrl.modelObject){
                    let number = parseInt(i);
                    number +=1;
                    $ctrl.modelObject[i].name = "Manovra "+ number;
                }
            };


            $ctrl.maneuverDateFormatter = (maneuver)=>{
                return maneuver.date.getDate()  + "-" + (maneuver.date.getMonth()+1) + "-" + maneuver.date.getFullYear() + " " + maneuver.date.getHours() + ":" + maneuver.date.getMinutes() + '(UTC)'
            }



            $ctrl.dateTimeConfig = function(manovra,index){

                return{
                    // modelType:,
                    dropdownSelector: 'sel'+index,
                    startView:'hour',
                    minView:'hour',
                    // timezone:'utc'
                }
            };

            $ctrl.beforeRender = function($view, $dates, $leftDate, $upDate, $rightDate){
                console.log($view)
                console.log($dates)
            };

            $ctrl.onSetTime = function(newDate, oldDate,paratoia){
                var tzOffset = newDate.getTimezoneOffset();
                paratoia.date = new Date(newDate.getTime() );
                $ctrl.trigManovre();
            };

            $ctrl.modelObject = [];


            $ctrl.downloadManovre = function(){
                var encodedUri = encodeURI(laminazioneService.exportManovreToCsv($ctrl.modelObject));
                var link = document.createElement("a");
                link.setAttribute("href", encodedUri);
                link.setAttribute("download", "manovre.csv");
                link.innerHTML= "Click Here to download";
                // document.body.appendChild(link); // Required for FF

                link.click();
            };

            $ctrl.dateFormatter = function(date){
                return moment.utc(date).format('DD-MM-YYYY HH:mm')+" (UTC)";
            };

            $ctrl.initManovre = function () {

                if($ctrl.data.dewetra.hasOwnProperty("rel") && $ctrl.data.dewetra.hasOwnProperty("t_rel")){
                    $ctrl.modelObject = $ctrl.data.dewetra.t_rel.map((t_rel,index) => {
                        let newDate = new Date(t_rel);
                        let obj = {
                            //date:moment(newDate),
                            date:newDate,
                            percentage:100,
                            value: $ctrl.data.dewetra["rel"][index],
                            name: "Manovra "+index,
                            descr:"rel"
                        };
                        // console.log(obj);
                        if(moment(obj.date).isValid()) return obj;
                    })
                }
            }




        }]
    });


})();

