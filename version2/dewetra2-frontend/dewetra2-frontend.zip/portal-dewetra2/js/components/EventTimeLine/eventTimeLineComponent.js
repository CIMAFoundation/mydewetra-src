/**
 * Created by Dario Rubado on 01/04/21.
 */

(function () {

    dewetraApp.component('eventTimeLineComponent', {
        // templateUrl: 'apps/dewetra2/js/components/EventTimeLine/eventTimeLineView.html',
        template: `
        
            <script type="text/ng-template" id="popOverYearTemplate.html">
                <div>{{dynamicPopover.content}}</div>
                <div class="form-group">
                  <label translate>EVENT - {{item.date.format('YYYY')}} </label>
                  <h5 ng-show="$ctrl.filterEventsByYear(item.date).length == 0" translate>NO_EVENTS</h5>
                  <ul>
                    <li ng-repeat="event in $ctrl.oConfig.popOverYearContent" ng-click="$ctrl.closeYearPopUp()"> {{event.name + ' : ' + event.name}}</a>
                  </ul>
                </div>
            </script>
            
            <script type="text/ng-template" id="popOverMonthTemplate.html">
                <div>{{dynamicPopover.content}}</div>
                <div class="form-group">
                  <label translate>EVENT - {{item.date.format('MM/YYYY')}} </label>
                  <div class="flex-container col start">
                  <h5 ng-show="$ctrl.filterEventsByYearMonth(item.date).length == 0" translate>NO_EVENTS</h5>
<!--                    <a class="badge badge-warning m-1 w-100"-->
<!--                        ng-repeat="event in $ctrl.oConfig.popOverMonthContent" -->
<!--                        ng-click="$ctrl.selectEventOnMonth(event)"-->
<!--                        > {{event.customprops.event_properties.properties.event_id + ' : ' + event.name}}</a>-->
                        
                        <span class="m-1 w-100 flex-container col"
                        ng-repeat="event in $ctrl.oConfig.popOverMonthContent" 
                        > {{event.name}}: {{event.layers.length}}
                            <a class="badge badge-warning m-1 w-100" ng-repeat="layer in event.layers" ng-show="layer.visible" ng-click="$ctrl.selectEventOnMonth(layer)">{{layer.name}}</a>
                        </span>
                  </div>
                </div>
            </script>

            <div class="timelinebar">
                <div class="flex-item flex-container row">
                    <div class="flex-item disabled" style="margin-left: 1em">
                        <a ng-click="$ctrl.slideLeft()">
                            <i class="fa fa-angle-left fa-2x" ></i>
                        </a>
                    </div> 
                    <div class="flex-item  "
                            uib-tooltip="Indietro"
                            tooltip-placement="top"
                            tooltip-class="tooltip-dewetra" 
                         style="margin-left: 1em; 
                         margin-right: 1em">
                        <a ng-show="$ctrl.oConfig.selectedYear > 0" 
                           ng-click="$ctrl.selectYear(0)" 
                          >
                            <i class="fa fa-angle-up fa-2x " ></i>
                        </a>
                    </div>
                    <div class="timelinebar-group timelinebar-line">
                        <div class=" first block" ng-show="$ctrl.oConfig.selectedYear == 0">
   
                      <!-- 1st line-->           
                        <!--  uib-popover-html="htmlPopover" -->
                            <div 
                                ng-repeat="item in $ctrl.oConfig.timeBarLiv1 "   
                                uib-popover-template="'popOverYearTemplate.html'" 
                                popover-append-to-body="true"
                                popover-is-open="item.popUp"
                                ng-mouseover="item.popUp = true; $ctrl.oConfig.popOverYearContent = $ctrl.filterEventsByYear(item.date)"
                                ng-mouseleave="item.popUp = false;"
                                ng-click="$ctrl.selectYear(item.date.year())" 
                                class=""
                                ng-class="
                                       item.events.length >= 5 ? 'event size-1': (
                                       item.events.length >= 3 ? 'event size-2': (
                                       item.events.length >= 2 ? 'event size-3': (
                                       item.events.length >= 1 ? 'event size-4': 'stepper'
                                )))
                                " 
                                type="button"
                                >
<!--                                ng-class="(item.events.length > 0)?'event big':'stepper'" -->
                                <span   ng-show="$ctrl.filterEventsByYear(item.date).length > 0"
                                        class="event--text">
                                    <span>{{$ctrl.DateConverter(item.date).format('YYYY')}}</span>
<!--                                    <span>{{$ctrl.filterEventsByYear(item.date).length}}</span>-->
                                    <span>{{$ctrl.getListOfEventsId($ctrl.filterEventsByYear(item.date)).length}}</span>
                                </span>      
                            </div>
                          
                         
                        </div> 
                        <!-- 2nd line-->
                        <div class=" second block" ng-show="$ctrl.oConfig.selectedYear > 0 ">
                            <div ng-repeat="item in $ctrl.oConfig.timeBarLiv2 | filter: $ctrl.filterTimeBarLiv2ByYear"
                                uib-popover-template="'popOverMonthTemplate.html'" 
                                popover-is-open="item.popUp"
                                popover-append-to-body="true"
                                ng-mouseover="$ctrl.openThisPopUpClosingOthers(item); $ctrl.oConfig.popOverMonthContent = $ctrl.filterEventsByYearMonthGrupedByEvent(item.date)"
                                class="flex-item"
                                ng-class="
                                       $ctrl.filterEventsByYearMonth(item.date).length >= 4 ? 'event size-1 small': (
                                       $ctrl.filterEventsByYearMonth(item.date).length >= 3 ? 'event size-2 small': (
                                       $ctrl.filterEventsByYearMonth(item.date).length >= 2 ? 'event size-3 small': (
                                       $ctrl.filterEventsByYearMonth(item.date).length >= 1 ? 'event size-4 small': 'stepper'
                                       )))
                                " 
                                >
<!--                                $ctrl.filterEventsByYearMonth(item.date).length > 0?'event small':'stepper'-->
<!--                               ng-class="(item.events.length > 0)?'stepper':'event small'"-->
                                <span  ng-show="$ctrl.filterEventsByYearMonth(item.date).length > 0" 
                                       class="event--text" 
                                       >
<!--                                <span>-->
                                    <span>{{item.date.format('MM/YYYY')}}</span>
<!--                                    <span>{{$ctrl.filterEventsByYearMonth(item.date).length}}</span>-->
                                    <span>{{$ctrl.getListOfEventsId($ctrl.filterEventsByYearMonth(item.date)).length}}</span>
                                </span>
                            </div>
                        </div>  
                    </div>
                    <div class="flex-item disabled" style="margin-right: 1em">
                        <a ng-click="$ctrl.slideRight()">
                            <i class="fa fa-angle-right fa-2x"  ></i>
                        </a>
                    </div>
                </div>
            </div>
        `,
        bindings: {
            events: '<',
            dateFrom: '<',
            dateTo: '<',
            filterByYearTimeline: '&',
            loadLayer: '&',
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['sentinelService', 'thresholdService', '$uibModal', 'menuService', 'serieService', '$timeout', '$sce', '_', 'rasorService', '$translate', 'layerService', 'mapService', 'acEvent', 'audioService', 'tagService', 'apiService', '$interval', 'floodproofsService', 'iconService', '$rootScope', 'floodCatService', function (sentinelService, thresholdService, $uibModal, menuService, serieService, $timeout, $sce, _, rasorService, $translate, layerService, mapService, acEvent, audioService, tagService, apiService, $interval, floodproofsService, iconService, $rootScope, floodCatService) {


            const $ctrl = this;

            $ctrl.oConfig = {
                yearlyRange: 12,
                yearlyIndex: null,
                monthlyRange: 12,
                monthlylyIndex: null,
                selectedYear: 0,
                deltaDateTimeLiv1: null,
                deltaDateTimeLiv2: null,
                timeBarLiv1: [],
                timeBarLiv2: [],
                deltaDateTime: null,
                popOverYearContent: null,
                popOverMonthContent: null
                // maxDate: null,
                // minDate: null
            };


            const dataFormatString = 'YYYYMMDDHHmm';

            console.log("eventTimeLineComponent");


            $ctrl.$onInit = () => {

                console.log('eventTimeLineComponent');

            };

            $ctrl.$onChanges = (changes) => {
                if (changes && changes.events && changes.events.currentValue != changes.events.previousValue) {
                    $ctrl.dateTriggered();
                }

                if (changes && changes.dateFrom && changes.dateFrom.currentValue != changes.dateFrom.previousValue) {
                    $ctrl.dateTriggered();
                }
                if (changes && changes.dateTo && changes.dateTo.currentValue != changes.dateTo.previousValue) {
                    $ctrl.dateTriggered();
                }


            };

            // $ctrl.dataTriggered = () => {};

            $ctrl.dateTriggered = () => {
                //debugger
                // let n = moment($ctrl.dateTo).diff($ctrl.dateFrom, 'months');
                if (Math.abs(getDateDiffByString('months')) > 24) {
                    //loadYearViews
                    loadTimeBarLiv1()
                    loadTimeBarLiv2()
                } else {

                    //loadMonthViews

                }
            };

            $ctrl.slideLeftYear = () => {

            };

            $ctrl.slideRightYear = () => {

            };

            $ctrl.slideLeftMonth = () => {

            };

            $ctrl.slideRightMonth = () => {

            };

            $ctrl.filterYearlyTimeLine = () => {

            };
            $ctrl.filterMonthlyTimeLine = () => {

            };

            $ctrl.openThisPopUpClosingOthers = (item) => {
                $ctrl.closeMonthPopUp();
                item.popUp = true;
            };

            $ctrl.closeYearPopUp = () => {
                $ctrl.oConfig.timeBarLiv1.map((e) => {
                    e.popUp = false;
                })
            }

            $ctrl.closeMonthPopUp = () => {
                $ctrl.oConfig.timeBarLiv2.map(e => e.popUp = false);
            }

            $ctrl.selectYear = (year) => {
                // console.log(year)
                $ctrl.filterByYearTimeline.apply(this)(year);
                $ctrl.oConfig.selectedYear = year;
            };

            $ctrl.selectEventOnMonth = (event) => {
                // debugger
                $ctrl.loadLayer.apply(this)(event)
                // loadLayer(event)
                $ctrl.closeMonthPopUp();
            };

            $ctrl.filterTimeBarLiv2ByYear = (item) => {
                return (item.date.year() == $ctrl.oConfig.selectedYear);
            };

            const getDateDiffByString = (string) => {
                if (moment($ctrl.dateTo).isValid() && moment($ctrl.dateFrom).isValid()) {
                    // console.log(moment($ctrl.dateTo).diff($ctrl.dateFrom, string));
                    return moment($ctrl.dateTo).diff($ctrl.dateFrom, string);
                }

            }

            DateConverter = (sDate) => {
                return moment(sDate);
            }
            $ctrl.DateConverter = DateConverter;

            $ctrl.filterEventsByYear = (date) => {

                let events = $ctrl.events.filter((event, index, array) => {
                    if (event && event.date) {
                        return (DateConverter(event.date).isSame(DateConverter(date), 'year'))
                    }
                });

                return events
            }
            $ctrl.filterEventsByYearMonth = (date) => {

                let events = $ctrl.events.filter((event, index, array) => {
                    if (event && event.date) {
                        return (DateConverter(event.date).isSame(DateConverter(date), 'year') && DateConverter(event.date).isSame(DateConverter(date), 'months'))
                    }
                });

                return events
            }

            $ctrl.filterEventsByYearMonthGrupedByEvent = (date) => {

                let events = $ctrl.events.filter((event) => {
                    if (event && event.date) {
                        //debugger
                        return (DateConverter(event.date).isSame(date, 'year') && DateConverter(event.date).isSame(date, 'months'))
                    }
                });

                //debugger
                return events


                // let eventIdList = {};
                //
                // events.map(e => {
                //     let eventId = e.name
                //     if (eventIdList.hasOwnProperty(eventId)){
                //         eventIdList[eventId].push(e);
                //     }else{
                //         eventIdList[eventId] = [e]
                //     }
                // });
                // console.log(eventIdList)
                //
                // return eventIdList;
            }

            $ctrl.getListOfEventsIdDictWithLayer = (events) => {

                let aoListOfEventList = [];

                events.map((event) => {
                    let eventId = event.customprops.event_properties.properties.event_id;
                    if (eventId in aoListOfEventList) {
                        aoListOfEventList[eventId].push(event);
                    } else {
                        aoListOfEventList[eventId] = [];
                        aoListOfEventList[eventId].push(event);
                    }
                });

                return aoListOfEventList;

            }

            $ctrl.getListOfEventsId = (events) => {

                let aoListOfEventList = [];

                events.map((event) => {
                    let eventId = event.name;
                    if (!aoListOfEventList.includes(eventId)) {
                        aoListOfEventList.push(eventId);
                    }
                });

                return aoListOfEventList;

            }

            const loadTimeBarLiv1 = () => {

                $ctrl.oConfig.timeBarLiv1 = new Array(getDateDiffByString('years'));
                for (let i = 0; i <= getDateDiffByString('years'); i++) {
                    let date = moment($ctrl.dateFrom)
                    date.add(i, 'years');
                    $ctrl.oConfig.timeBarLiv1[i] = {
                        date: date,
                        events: $ctrl.filterEventsByYear(date),
                        popUp: false
                    }

                }
                //console.log("TimeBar: "+ $ctrl.oConfig.timeBarLiv1);
            };

            const loadTimeBarLiv2 = () => {
                $ctrl.oConfig.timeBarLiv2 = new Array(getDateDiffByString('months'));
                for (let i = 0; i <= getDateDiffByString('months'); i++) {
                    let date = moment($ctrl.dateFrom)
                    date.add(i, 'months')
                    $ctrl.oConfig.timeBarLiv2[i] = {
                        date: date,
                        events: [],
                        popUp: false
                    }
                }
            };

            // function loadLayer(event) {
            //
            //     const manager = buildLayerManager(event);
            //
            //     manager.load(function () {
            //
            //         //passo la lista layer
            //         try{
            //             mapService.oLayerList.addLayer(manager);
            //
            //         }catch (err){
            //             console.log(err)
            //         }
            //
            //
            //     });
            //
            // }
            //
            // function buildLayerManager(layer) {
            //
            //     var mangerName = 'layerManager_' + layer['type'].code;
            //
            //     console.log("Manager:"+mangerName);
            //     console.log("Id Layer:"+layer.dataid)
            //
            //     var manager = window[mangerName](layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService, floodCatService);
            //     return manager;
            // }


        }]
    });

})();

