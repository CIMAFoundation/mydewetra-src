/**
 * Created by Dario Rubado on 01/04/21.
 */
(function () {

    dewetraApp.component('eventTimeLineModalComponentOLD', {
        templateUrl: 'apps/dewetra2/js/components/EventTimeLine/eventTimeLineView.html',
        bindings: {
            loadLayer: '&',
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['sentinelService', 'thresholdService', '$uibModal','menuService', 'serieService', '$timeout', '$sce', '_', 'rasorService', '$translate', 'layerService', 'mapService','acEvent','audioService', 'tagService', 'apiService', '$interval', 'floodproofsService', 'iconService','$rootScope','floodCatService', function (sentinelService, thresholdService, $uibModal,  menuService, serieService, $timeout, $sce, _, rasorService, $translate, layerService, mapService,acEvent,audioService,tagService, apiService, $interval, floodproofsService, iconService,$rootScope,floodCatService) {

            const $ctrl = this;

            $ctrl.oConfig = {
                eventLayers:[],
                eventLayersFiltered:[],
                deltaDateTimeLiv1: null,
                deltaDateTimeLiv2: null,
                timeBarLiv1:[],
                timeBarLiv2:[],
                deltaDateTime: null,
                maxDate: null,
                minDate: null,
                tags: [],
                selectedTags:[],
                events: [],
                hazards: [],
                dataTypes: [],
                selectedEvents: [],
                selectedHazard: [],
                selectedDataType: [],
                // eventMarkerGroup:L.featureGroup(),
                eventMarkerGroup : L.markerClusterGroup({
                    disableClusteringAtZoom:8
                })
            };

            $ctrl.filterByYearTimeline = (year) => {

                if(year > 0){
                    $ctrl.oConfig.eventLayersFiltered = $ctrl.oConfig.eventLayersFiltered.filter((event) => {
                        return event.customprops.event_properties.properties.date.year() == year;
                    });

                    reloadFilteredEvents()
                }else {

                }


            };

            $ctrl.onLayerSelected = (event) =>{

                try {
                    $ctrl.loadLayer.apply(this)(event)
                }catch (e) {
                    console.log(e)
                }

                try {
                   loadLayer(event)
                }catch (e) {
                    console.log(e)
                }

            };

            let zoomend = mapService.getMap().on('zoomend', function() {
                console.log("zoom");
                filteringMap()
            });

            let moveend = mapService.getMap().on('moveend', function() {
                console.log("move");
                filteringMap()
            });

            //console.log(zoomend);

            //console.log(moveend);

            const dataFormatString = 'YYYYMMDDHHmm';

            console.log("eventTimeLineModalComponent");


            $ctrl.$onInit = () => {

                console.log('eventTimeLineModalComponent');
                loadEventLayers();
            };

            $ctrl.$onChanges = () => {

            };

            $ctrl.$onDestroy = () => {

            };

            loadEventLayers = () => {

                let p = {
                    "event_properties": {
                        "properties": {
                            "date" : "202106031200",
                            "point" : ["44", "8"]
                        }
                    }
                };

                layerService.getLayers('event', null, function (data) {
                    $ctrl.oConfig.eventLayers = data.objects.map((l, index)=>{

                        if(l.hasOwnProperty("customprops")){

                            try {
                                //return l.customprops = JSON.parse(l.customprops);

                                //set random date
                                //let lTemp = angular.copy(p);
                                //lTemp.event_properties.properties.date = moment(randomDate(new Date(2012, 0, 1), new Date()), dataFormatString);

                                //set random point
                                //let point = getRandomLatLng(mapService.getMap());
                                //lTemp.event_properties.properties.point = [point.lat, point.lng];
                                //lTemp.event_properties.properties.event_id = 'id ';

                                //l.customprops = lTemp;
                                l.customprops = JSON.parse(l.customprops);
                                l.customprops.event_properties.properties.date = moment(l.customprops.event_properties.properties.date, dataFormatString)


                                return l;
                            }catch (e) {
                                console.log(e)
                            }
                        }
                    });

                    $ctrl.oConfig.eventLayers = $ctrl.oConfig.eventLayers.filter((l) => {
                       if(l.customprops.hasOwnProperty("event_properties") && l.customprops.event_properties.hasOwnProperty("properties") && l.customprops.event_properties.properties.hasOwnProperty("data_type") &&l.customprops.event_properties.properties.hasOwnProperty("hazard")) return l;
                    });


                    initialLoading();

                });
            }

            initialLoading = () => {

                orderLayersByDate();

                loadMinAndMax();

                deltaTime();

                $ctrl.oConfig.eventLayersFiltered = $ctrl.oConfig.eventLayers;

                reloadFilteredEvents()
            }

            reloadFilteredEvents = () => {

                loadDataTypes();

                loadHazards();

                loadPointOnMap();
            };


            filteringMap = () => {

                try {
                    $ctrl.oConfig.eventLayersFiltered = $ctrl.oConfig.eventLayers.filter(e => {
                        if (e === undefined) return false;
                        if(e.customprops && e.customprops.event_properties && e.customprops.event_properties.properties && e.customprops.event_properties.properties.point){
                            let latlng = L.latLng(e.customprops.event_properties.properties.point[1], e.customprops.event_properties.properties.point[0]);
                            return mapService.getMap().getBounds().contains(latlng);
                        }
                    });

                    loadDataTypes();

                    loadHazards();

                }catch (e) {
                    console.log(e)
                }


            }

            filterByTag = () => {
                try {
                    $ctrl.oConfig.eventLayersFiltered = $ctrl.oConfig.eventLayers.filter(e => {
                        if (e === undefined) return false;
                        if(e.customprops && e.customprops.event_properties &&
                            e.customprops.event_properties.properties &&
                            e.customprops.event_properties.properties.hasOwnProperty("data_type") &&
                            e.customprops.event_properties.properties.hasOwnProperty("hazard")){

                                let indexOfDataType = $ctrl.oConfig.selectedDataType.findIndex((SD_T) => {
                                    return(e.customprops.event_properties.properties.data_type == SD_T.name)
                                });
                                let indexOfHazard = $ctrl.oConfig.selectedHazard.findIndex((SH) => {
                                    return(e.customprops.event_properties.properties.hazard == SH.name)
                                });

                            return (indexOfDataType >-1 || indexOfHazard > -1) //TODO scegliere funzionamento dei tag


                        }

                    })

                    loadPointOnMap()
                    console.log($ctrl.oConfig.eventLayersFiltered);
                }catch (e) {
                    console.log(e);
                }
            }

            $ctrl.title = () => {
                return '';
            }

            $ctrl.subTitle = () => {
                return '';
            }

            $ctrl.closePopup = () => {
                beforeCloseModal();
                $ctrl.close()
            };

            $ctrl.update = () => {
                beforeCloseModal();
                $ctrl.close({$value: 'data'});
            };

            $ctrl.cancel = () => {
                beforeCloseModal();
                $ctrl.dismiss({$value: 'cancel'});
            };

            $ctrl.onDateFromSelected = (date) => {
                console.log(date)
            };

            $ctrl.onDateToSelected = (date) => {
                console.log(date)
            };

            $ctrl.onFilterSelected = ($item, $model) => {
                filterByTag()
                console.log($ctrl.oConfig)

            }

            orderLayersByDate = () => {

                try {

                    $ctrl.oConfig.eventLayers.sort((l1, l2) =>{
                        return moment(l1.customprops.event_properties.properties.date).valueOf() - moment(l2.customprops.event_properties.properties.date).valueOf();
                    });

                }catch (e) {
                    console.log(e)
                }
            };

            loadMinAndMax = () => {
                $ctrl.oConfig.minDate = $ctrl.getMinDate();
                $ctrl.oConfig.maxDate = $ctrl.getMaxDate();
            };

            deltaTime = () => {

                $ctrl.oConfig.deltaDateTime = moment($ctrl.oConfig.maxDate).diff($ctrl.oConfig.minDate, 'months');

                console.log($ctrl.oConfig.deltaDateTime);

            };

            loadTags = () =>{
                $ctrl.oConfig.tags = [];

                $ctrl.oConfig.eventLayers.map(e => {
                    // debugger
                    if( e && e.tags.length > 0 ){
                        e.tags.map(tagToCheck => {
                            let i = $ctrl.oConfig.tags.findIndex((alreadyAddedTag) => {
                                return alreadyAddedTag.id == tagToCheck.id
                            })
                            if (i == -1) $ctrl.oConfig.tags.push(tagToCheck);
                        })
                    }

                })
                // initialize Tag
                $ctrl.oConfig.selectedTags = $ctrl.oConfig.tags;
            };

            loadDataTypes = () =>{
                $ctrl.oConfig.dataTypes = [];

                $ctrl.oConfig.eventLayersFiltered.map(e => {
                    if(e && e.customprops && e.customprops.event_properties && e.customprops.event_properties.properties && e.customprops.event_properties.properties.data_type){
                        let dataTypeId = {name: e.customprops.event_properties.properties.data_type}
                        // if ($ctrl.oConfig.events.indexOf(eventsId) == -1){
                        if ($ctrl.oConfig.dataTypes.findIndex(alreadyAddedDataType => alreadyAddedDataType.name == dataTypeId.name) == -1){
                            $ctrl.oConfig.dataTypes.push(dataTypeId);
                        }
                    }

                })
                // initialize Tag
                $ctrl.oConfig.selectedDataType = $ctrl.oConfig.dataTypes;
            };

            loadHazards = () =>{
                $ctrl.oConfig.hazards = [];

                $ctrl.oConfig.eventLayersFiltered.map(e => {
                    if(e && e.customprops && e.customprops.event_properties && e.customprops.event_properties.properties && e.customprops.event_properties.properties.hazard){
                        let hazardId = {name: e.customprops.event_properties.properties.hazard}
                        // if ($ctrl.oConfig.events.indexOf(eventsId) == -1){
                        if ($ctrl.oConfig.hazards.findIndex(alreadyAddHazard => alreadyAddHazard.name == hazardId.name) == -1){
                            $ctrl.oConfig.hazards.push(hazardId);
                        }
                    }

                })
                // initialize Tag
                $ctrl.oConfig.selectedHazard = $ctrl.oConfig.hazards;
            };

            loadEvents = () =>{
                $ctrl.oConfig.events = [];

                $ctrl.oConfig.eventLayers.map(e => {
                    if(e && e.customprops && e.customprops.event_properties && e.customprops.event_properties.properties && e.customprops.event_properties.properties.event_id){
                        let eventsId = {name: e.customprops.event_properties.properties.event_id}
                        // if ($ctrl.oConfig.events.indexOf(eventsId) == -1){
                        if ($ctrl.oConfig.events.findIndex(alreadyAddedEvent => alreadyAddedEvent.name == eventsId.name) == -1){
                            $ctrl.oConfig.events.push(eventsId);
                        }
                    }

                })

                // initialize Tag
                $ctrl.oConfig.selectedEvents = $ctrl.oConfig.events;
            };

            loadPointOnMap = () => {

                $ctrl.oConfig.eventMarkerGroup.clearLayers();
                $ctrl.oConfig.eventMarkerGroup.addTo(mapService.getMap());
                // $ctrl.oConfig.eventMarkerGroup.addLayer(marker)
                //var marker = L.marker([node.lat, node.lon], {icon:iconService.warnings_hydro_Icon(stationFromLayer, 1)}).addTo($ctrl.floodWaveMap);

                $ctrl.oConfig.eventLayersFiltered.map(e => {

                    let hazardType = e.customprops.event_properties.properties.hazard;

                    let oIconOption = L.icon({
                        iconUrl: 'apps/dewetra2/img/icons/'+hazardType+'.svg',
                        iconSize:     [38, 95],
                        //iconAnchor:   [39, 95]
                        popupAnchor:  [0, -20]
                    });

                    if(e && e.customprops && e.customprops.event_properties && e.customprops.event_properties.properties && e.customprops.event_properties.properties.point){
                        let point = {lon: e.customprops.event_properties.properties.point[0],lat: e.customprops.event_properties.properties.point[1]}
                        e.customprops.event_properties.marker = L.marker([point.lat, point.lon],{icon: oIconOption});
                        e.customprops.event_properties.marker.addTo($ctrl.oConfig.eventMarkerGroup);
                    }

                })
            }


            isLayerInBoundingBox = (marker) => {
                mapService.getMap().getBounds().contains(marker.getLatLng())
                // map.getBounds().contains(myMarker.getLatLng())
            }

            beforeCloseModal = () => {
                //remove map
                $ctrl.oConfig.eventMarkerGroup.clearLayers();
                mapService.getMap().removeLayer($ctrl.oConfig.eventMarkerGroup)
            }

            $ctrl.getMinDate = () => {

                if($ctrl.oConfig.eventLayers[0] != undefined){
                    try {
                        return $ctrl.oConfig.eventLayers[0].customprops.event_properties.properties.date.toDate();

                    }catch (e) {
                        console.log(e)
                    }
                }

            };

            $ctrl.getMaxDate = () => {

                if($ctrl.oConfig.eventLayers && $ctrl.oConfig.eventLayers[$ctrl.oConfig.eventLayers.length -1] != undefined){
                    try {
                        return $ctrl.oConfig.eventLayers[$ctrl.oConfig.eventLayers.length - 1].customprops.event_properties.properties.date.toDate();

                    } catch (e) {
                        console.log(e)
                    }
                }

            };


            randomDate = (start, end) => {
                let d = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
                console.log( moment(d).format( dataFormatString));
                return moment(d).format( dataFormatString);
            };


            function loadLayer(event) {

                const manager = buildLayerManager(event);

                manager.load(function () {

                    //passo la lista layer
                    try{
                        mapService.oLayerList.addLayer(manager);

                    }catch (err){
                        console.log(err)
                    }


                });

            }

            function buildLayerManager(layer) {

                var mangerName = 'layerManager_' + layer['type'].code;

                console.log("Manager:"+mangerName);
                console.log("Id Layer:"+layer.dataid)

                var manager = window[mangerName](layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService, floodCatService);
                return manager;
            }


        }]
    });

})();

