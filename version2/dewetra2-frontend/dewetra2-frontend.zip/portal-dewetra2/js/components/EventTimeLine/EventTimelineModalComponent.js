/**
 * Created by Dario Rubado on 01/04/21.
 */
(function () {

    dewetraApp.component('eventTimeLineModalComponent', {
        templateUrl: 'apps/dewetra2/js/components/EventTimeLine/eventTimeLineView.html',
        bindings: {
            loadLayer: '&',
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['sentinelService', 'thresholdService', '$uibModal','menuService', 'serieService', '$timeout', '$sce', '_', 'rasorService', '$translate', 'layerService', 'mapService','acEvent','audioService', 'tagService', 'apiService', '$interval', 'floodproofsService', 'iconService','$rootScope','floodCatService', function (sentinelService, thresholdService, $uibModal,  menuService, serieService, $timeout, $sce, _, rasorService, $translate, layerService, mapService,acEvent,audioService,tagService, apiService, $interval, floodproofsService, iconService,$rootScope,floodCatService) {

            const $ctrl = this;

            const debug = true;

            $ctrl.oConfig = {
                eventLayers:[],
                eventLayersFiltered:[],
                selectedYear: 0,
                deltaDateTimeLiv1: null,
                deltaDateTimeLiv2: null,
                timeBarLiv1:[],
                timeBarLiv2:[],
                deltaDateTime: null,
                maxDate: null,
                minDate: null,
                tags: [],
                selectedTags:[],
                events: [],
                hazards: [],
                dataTypes: [],
                selectedEvents: [],
                selectedHazard: [],
                selectedDataType: [],
                eventMarkerGroup:L.featureGroup().addTo(mapService.getMap()),
                // eventMarkerGroup : L.markerClusterGroup({
                //     disableClusteringAtZoom:8
                // }),
                overlappingMarkerSpiderfier: new OverlappingMarkerSpiderfier(mapService.getMap(),{keepSpiderfied:true})
            };



            //CALLBACK
            $ctrl.filterByYearTimeline = (year) => {
                if(debug)console.log("filterByYearTimeline");
                $ctrl.oConfig.selectedYear = year;
                filterRoutine();
            };

            $ctrl.onLayerSelected = (event) =>{

                try {
                    $ctrl.loadLayer.apply(this)(event)
                }catch (e) {
                    console.log(e)
                }

                try {
                   loadLayer(event)
                }catch (e) {
                    console.log(e)
                }

            };

            let zoomend = mapService.getMap().on('zoomend', function() {
                console.log("zoom");
                filteringMap()
            });

            let moveend = mapService.getMap().on('moveend', function() {
                console.log("move");
                filteringMap()
            });

            //console.log(zoomend);

            //console.log(moveend);

            const dataFormatString = 'YYYYMMDDHHmm';

            console.log("eventTimeLineModalComponent");


            $ctrl.$onInit = () => {

                console.log('eventTimeLineModalComponent');
                loadEventLayers();
            };

            $ctrl.$onChanges = () => {

            };

            $ctrl.$onDestroy = () => {

            };

            DateConverter = (sDate) => {
                return moment(sDate)
            };

            $ctrl.DateConverter = DateConverter;

            loadEventLayers = () => {

                let p = {
                    "event_properties": {
                        "properties": {
                            "date" : "202106031200",
                            "point" : ["44", "8"]
                        }
                    }
                };

                layerService.getEvents( (events) => {
                    if(debug)console.log(events)

                    try {
                        events.map((events) =>{
                            if (events.layers.length > 0){
                                events.layers = events.layers.map((l) => {
                                    l.visible = true;
                                    return l;
                                })
                            }
                        })
                    }catch (e) {
                        if(debug)console.log(e)
                    }

                    $ctrl.oConfig.eventLayers = events;

                    // eventLayers.map(event => {
                    //     event.layers = event.layers.map(e => e.date = DateConverter(e.date));
                    // })

                    initialLoading();
                });

                // layerService.getLayers('event', null, function (data) {
                //     $ctrl.oConfig.eventLayers = data.objects.map((l, index)=>{
                //
                //         if(l.hasOwnProperty("customprops")){
                //
                //             try {
                //                 //return l.customprops = JSON.parse(l.customprops);
                //
                //                 //set random date
                //                 //let lTemp = angular.copy(p);
                //                 //lTemp.event_properties.properties.date = moment(randomDate(new Date(2012, 0, 1), new Date()), dataFormatString);
                //
                //                 //set random point
                //                 //let point = getRandomLatLng(mapService.getMap());
                //                 //lTemp.event_properties.properties.point = [point.lat, point.lng];
                //                 //lTemp.event_properties.properties.event_id = 'id ';
                //
                //                 //l.customprops = lTemp;
                //                 l.customprops = JSON.parse(l.customprops);
                //                 l.customprops.event_properties.properties.date = moment(l.customprops.event_properties.properties.date, dataFormatString)
                //
                //
                //                 return l;
                //             }catch (e) {
                //                 console.log(e)
                //             }
                //         }
                //     });
                //
                //     $ctrl.oConfig.eventLayers = $ctrl.oConfig.eventLayers.filter((l) => {
                //        if(l && l.hasOwnProperty("customprops") && l.customprops.hasOwnProperty("event_properties") && l.customprops.event_properties.hasOwnProperty("properties") && l.customprops.event_properties.properties.hasOwnProperty("data_type") &&l.customprops.event_properties.properties.hasOwnProperty("hazard")) return l;
                //     });
                //
                //
                //     initialLoading();
                //
                // });
            }

            initialLoading = () => {

                orderLayersByDate();//done

                loadMinAndMax();//done

                deltaTime();//already done

                $ctrl.oConfig.eventLayersFiltered = $ctrl.oConfig.eventLayers;

                loadTagsLists()//done

                loadPointOnMap();

            }

            loadTagsLists = () => {
                loadDataTypes();

                loadHazards();
            }




            filteringMap = () => {



                try {
                    $ctrl.oConfig.eventLayersFiltered = $ctrl.oConfig.eventLayers.filter(e => {
                        //if undefined out
                        if (e === undefined) return false;

                        //if year selected rules are stronger than bounding box
                        if ($ctrl.oConfig.selectedYear > 0 && DateConverter(e.date).year() != $ctrl.oConfig.selectedYear) return false

                        if(e.lat && e.lon){
                            let latlng = L.latLng(e.lat, e.lon);
                            return mapService.getMap().getBounds().contains(latlng);
                        }
                    });

                    loadDataTypes();

                    loadHazards();

                    loadPointOnMap()

                }catch (e) {
                    if(debug)console.log(e)
                }


            }


            $ctrl.toggleLayers = () => {
                if(debug)console.log("toggle layers");

                $ctrl.oConfig.eventLayersFiltered = $ctrl.oConfig.eventLayersFiltered.map((event) => {
                        event.layers = event.layers.map((layer)=>{
                            let aHasTag = layer.tags.filter(tag => {
                                let i = $ctrl.oConfig.selectedDataType.findIndex(SelectedDataType => {
                                    return SelectedDataType.id == tag.id
                                });
                                return (i > 0 )
                            } );
                            layer.visible = (aHasTag.length > 0);

                            return layer
                        });
                        return event
                    });



            }

            // filterByYear = () => {
            //     $ctrl.oConfig.eventLayersFiltered = $ctrl.oConfig.eventLayers.filter(e => {
            //         if (e === undefined) return false;
            //         //If Yearly filter is activated
            //         if ($ctrl.oConfig.selectedYear > 0 && DateConverter(e.date).year() != $ctrl.oConfig.selectedYear) return true
            //
            //     })
            // }


            filterRoutine = () => {
                if(debug)console.log("filterRoutine");

                try {
                    $ctrl.oConfig.eventLayersFiltered = $ctrl.oConfig.eventLayers.filter(e => {
                        if (e === undefined) return false;

                        //If Yearly filter is activated
                        if ($ctrl.oConfig.selectedYear > 0 && DateConverter(e.date).year() != $ctrl.oConfig.selectedYear) return false

                        if( e.hazard ){
                                let indexOfHazard = $ctrl.oConfig.selectedHazard.findIndex((SelectedHazard) => {
                                    return(e.hazard == SelectedHazard.name)
                                });
                            return ( indexOfHazard > -1)
                        }

                    })

                    loadPointOnMap()

                    if(debug)console.log($ctrl.oConfig.eventLayersFiltered);
                }catch (e) {
                    console.log(e);
                }
            }

            $ctrl.title = () => {
                return '';
            }

            $ctrl.subTitle = () => {
                return '';
            }

            $ctrl.closePopup = () => {
                beforeCloseModal();
                $ctrl.close()
            };

            $ctrl.update = () => {
                beforeCloseModal();
                $ctrl.close({$value: 'data'});
            };

            $ctrl.cancel = () => {
                beforeCloseModal();
                $ctrl.dismiss({$value: 'cancel'});
            };

            $ctrl.onDateFromSelected = (date) => {
                if(debug)console.log(date)
            };

            $ctrl.onDateToSelected = (date) => {
                if(debug)console.log(date)
            };

            $ctrl.onFilterSelected = ($item, $model) => {
                filterRoutine()
                console.log($ctrl.oConfig)

            }

            orderLayersByDate = () => {
                try {
                    $ctrl.oConfig.eventLayers.sort((l1,l2) => {
                        return (DateConverter(l1.date).valueOf() - DateConverter(l2.date).valueOf());
                    });
                }catch (e){
                    console.log(e);
                }
            };

            loadMinAndMax = () => {

                $ctrl.oConfig.minDate = $ctrl.getMinDate();
                $ctrl.oConfig.maxDate = $ctrl.getMaxDate();
                //debugger
            };

            deltaTime = () => {


                $ctrl.oConfig.deltaDateTime = moment($ctrl.oConfig.maxDate).diff($ctrl.oConfig.minDate, 'months');

                // console.log($ctrl.oConfig.deltaDateTime);

            };

            loadTags = () =>{
                $ctrl.oConfig.tags = [];

                $ctrl.oConfig.eventLayers.map(e => {
                    // debugger
                    if( e && e.tags.length > 0 ){
                        e.tags.map(tagToCheck => {
                            let i = $ctrl.oConfig.tags.findIndex((alreadyAddedTag) => {
                                return alreadyAddedTag.id == tagToCheck.id
                            })
                            if (i == -1) $ctrl.oConfig.tags.push(tagToCheck);
                        })
                    }

                })
                // initialize Tag
                $ctrl.oConfig.selectedTags = $ctrl.oConfig.tags;
            };

            loadDataTypes = () =>{
                $ctrl.oConfig.dataTypes = [];
                /**
                 * data_types retrieved by tags
                 */
                $ctrl.oConfig.eventLayersFiltered.map((event) => {
                    if(event.layers.length > 0 ){
                        event.layers.map((layer) => {
                            layer.tags.map((tag) =>{
                                if ($ctrl.oConfig.dataTypes.findIndex(alreadyAddedDataType => alreadyAddedDataType.name == tag.name) == -1){
                                    $ctrl.oConfig.dataTypes.push(tag);
                                }
                            })
                        })
                    }

                    });

                // $ctrl.oConfig.eventLayersFiltered.map(e => {
                //     if(e && e.data_type){
                //         let dataTypeId = {name: e.data_type}
                //         // if ($ctrl.oConfig.events.indexOf(eventsId) == -1){
                //         if ($ctrl.oConfig.dataTypes.findIndex(alreadyAddedDataType => alreadyAddedDataType.name == dataTypeId.name) == -1){
                //             $ctrl.oConfig.dataTypes.push(dataTypeId);
                //         }
                //     }
                //
                // })
                // initialize Tag
                $ctrl.oConfig.selectedDataType = $ctrl.oConfig.dataTypes;
            };

            $ctrl.translateIt = (item) => {
                return $translate.instant(item);
            }

            loadHazards = () =>{
                $ctrl.oConfig.hazards = [];

                $ctrl.oConfig.eventLayersFiltered.map(e => {
                    if(e && e.hazard){
                        let hazardId = {name: e.hazard}
                        // if ($ctrl.oConfig.events.indexOf(eventsId) == -1){
                        if ($ctrl.oConfig.hazards.findIndex(alreadyAddHazard => alreadyAddHazard.name == hazardId.name) == -1){
                            $ctrl.oConfig.hazards.push(hazardId);
                        }
                    }

                })
                // initialize Tag
                $ctrl.oConfig.selectedHazard = $ctrl.oConfig.hazards;
            };

            loadEvents = () =>{
                $ctrl.oConfig.events = [];

                $ctrl.oConfig.eventLayers.map(e => {
                    if(e && e.name){
                        let eventsId = {name: e.name}
                        // if ($ctrl.oConfig.events.indexOf(eventsId) == -1){
                        if ($ctrl.oConfig.events.findIndex(alreadyAddedEvent => alreadyAddedEvent.name == eventsId.name) == -1){
                            $ctrl.oConfig.events.push(eventsId);
                        }
                    }

                })

                // initialize Tag
                $ctrl.oConfig.selectedEvents = $ctrl.oConfig.events;
            };

            loadListener = () => {


                // $ctrl.oConfig.overlappingMarkerSpiderfier.addListener('click', function(marker) {
                //     let popup = new L.Popup();
                //
                //     popup.setContent(marker.options.icon.options.properties.name);
                //
                //     popup.setLatLng(marker.getLatLng());
                //     marker.bindPopup(popup)
                //
                //     marker.on('click',(m)=>{
                //
                //         m.target.openPopup();
                //     });
                //     marker.on('mouseover',(m)=>{
                //
                //         m.target.openPopup();
                //     });
                //     marker.on('mouseout',(m)=>{
                //
                //         m.target.closePopup();
                //     });
                //
                //     console.log('click');
                // });



                // $ctrl.oConfig.overlappingMarkerSpiderfier.addListener('mouseover', function(marker) {
                //     marker.openPopup();
                //     console.log('over');
                // });
                //
                // $ctrl.oConfig.overlappingMarkerSpiderfier.addListener('mouseout', function(marker) {
                //     marker.closePopup();
                //     console.log('close');
                // });

                // $ctrl.oConfig.overlappingMarkerSpiderfier.addListener('spiderfy', function(markers) {
                //     markers.map(m => {
                //         m.openPopup()
                //     })
                // });
            }

            loadPointOnMap = () => {

                if(debug)console.log("loadPointOnMap");


                $ctrl.oConfig.eventMarkerGroup.clearLayers();

                $ctrl.oConfig.eventLayersFiltered.map(event => {

                    let hazardType = event.hazard;

                    let prop = {
                        name: event.name
                    };

                    let oIconOption = L.icon({
                        iconUrl: 'apps/dewetra2/img/icons/'+hazardType+'.svg',
                        iconSize:     [38, 95],
                        //iconAnchor:   [39, 95]
                        popupAnchor:  [0, -20],
                        properties: prop
                    });

                    if(debug) console.log(hazardType);

                    if(event && event.lat && event.lon){
                        let point = {lon: event.lon, lat: event.lat}
                        event.marker = L.marker([point.lat, point.lon],{icon: oIconOption});

                        //PopUp
                        let popup = new L.Popup();
                        popup.setContent($translate.instant(event.name ));

                        event.marker.bindPopup(popup)

                        event.marker.addTo($ctrl.oConfig.eventMarkerGroup);

                        $ctrl.oConfig.overlappingMarkerSpiderfier.addMarker(event.marker);

                        event.marker.on('mouseover',(m)=>{

                            m.target.openPopup();
                        });
                        event.marker.on('mouseout',(m)=>{

                            m.target.closePopup();
                        });



                    }

                })
            }




            isLayerInBoundingBox = (marker) => {
                mapService.getMap().getBounds().contains(marker.getLatLng())
                // map.getBounds().contains(myMarker.getLatLng())
            }

            beforeCloseModal = () => {
                //remove map
                $ctrl.oConfig.eventMarkerGroup.clearLayers();
                mapService.getMap().removeLayer($ctrl.oConfig.eventMarkerGroup)
            }

            $ctrl.getMinDate = () => {

                if($ctrl.oConfig.eventLayers.length > 0 && $ctrl.oConfig.eventLayers[0]){
                    try {
                        return DateConverter($ctrl.oConfig.eventLayers[0].date).toDate();

                    }catch (e) {
                        console.log(e)
                    }
                }

            };

            $ctrl.getMaxDate = () => {

                if($ctrl.oConfig.eventLayers.length > 0 && $ctrl.oConfig.eventLayers[$ctrl.oConfig.eventLayers.length -1] ){
                    try {
                        return DateConverter($ctrl.oConfig.eventLayers[$ctrl.oConfig.eventLayers.length -1].date).toDate();

                    }catch (e) {
                        console.log(e)
                    }
                }

            };



            randomDate = (start, end) => {
                let d = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
                console.log( moment(d).format( dataFormatString));
                return moment(d).format( dataFormatString);
            };


            function loadLayer(event) {

                const manager = buildLayerManager(event);

                manager.load(function () {

                    //passo la lista layer
                    try{
                        mapService.oLayerList.addLayer(manager);

                    }catch (err){
                        console.log(err)
                    }


                });

            }

            function buildLayerManager(layer) {

                var mangerName = 'layerManager_' + layer['type'].code;

                console.log("Manager:"+mangerName);
                console.log("Id Layer:"+layer.dataid)

                var manager = window[mangerName](layer, mapService, layerService, serieService, menuService, $uibModal, acEvent,audioService,tagService,apiService, _, sentinelService,  $interval, floodproofsService, $translate,iconService, $timeout, $rootScope,thresholdService, floodCatService);
                return manager;
            }


        }]
    });

})();

