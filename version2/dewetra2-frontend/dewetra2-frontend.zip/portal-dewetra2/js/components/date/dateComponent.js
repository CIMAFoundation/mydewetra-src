/**
 * Created by Dario Rubado on 18/06/20.
 */
(function () {
    dewetraApp.component('dateComponent', {
        template: `
                <div class="dropdown dropdown{{$ctrl.oConfig.dropdownId}}-parent">
                    <a
                            class="dropdown-toggle text-wrap"
                            id="sel{{$ctrl.oConfig.dropdownId}}"
                            role="button"
                            data-toggle="dropdown"
                            data-target=".dropdown{{$ctrl.oConfig.dropdownId}}-parent"
                            href="#">
                                <i ng-class="($ctrl.class)?$ctrl.class:'app-calendar fa-2x'"></i>
                                         
                    </a>
                    <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                        <datetimepicker
                                data-before-render="$ctrl.dateBeforeRender($view, $dates, $leftDate, $upDate, $rightDate)"
                                data-datetimepicker-config="$ctrl.dropDownConfig"
                                data-ng-model="$ctrl.oConfig.oDate"
                                data-on-set-time="$ctrl.dateOnSetTime(newDate, oldDate)"/>
                    </ul>
                </div>
        `,
        bindings: {
            startDate: '<',
            endDate: '<',
            class: '<',
            onDateSelected: '&',
            close: '&',
        },
        controller: ['mapService', '$uibModal', '$rootScope', function (mapService, $uibModal, $rootScope) {
            var $ctrl = this;

            $ctrl.oConfig = {
                dropdownId: makeid(8),
                oDate: moment()
            };

            $ctrl.$rootScope = $rootScope;

            $rootScope.$watch('pendingRequests', function () {
                $ctrl.pendingRequests = $rootScope.pendingRequests
            });

            $ctrl.dropDownConfig = {
                dropdownSelector: '#sel'+$ctrl.oConfig.dropdownId,
                renderOn: 'end-date-changed',
                modelType: 'moment',
                screenReader: { 'previous': 'go previous', 'next': 'go next' },
                startView: 'day',
                minView: 'minute',
                minuteStep: 5
            };

            // $ctrl.oDate = moment();

            $ctrl.dateBeforeRender = dateBeforeRender
            $ctrl.dateOnSetTime = dateOnSetTime

            function dateOnSetTime(newDate, oldDate) {
                console.log('start-date-changed');

                $ctrl.onDateSelected.apply(this)($ctrl.oConfig.oDate);

            }

            function dateBeforeRender($view, $dates, $leftDate, $upDate, $rightDate) {

                if ($ctrl.startDate && $ctrl.endDate) {
                    let startDate = moment($ctrl.startDate);
                    let endDate = moment($ctrl.endDate);

                    $dates.filter(function (date) {
                        return ((startDate.valueOf() >= date.localDateValue()) || (date.localDateValue() >= endDate.valueOf()))
                    }).forEach(function (date) {
                        date.selectable = false;
                    })
                }
            }




            $ctrl.closePopup = function () {

                $ctrl.close()
            }

            $ctrl.log = function (item) {
                console.log(item)
            }


            $ctrl.$onInit = function () {
                console.log("Date component init");
                // $ctrl.oConfig.dropdownId = makeid(8);
            };

            $ctrl.$onChanges = function (change) {

                $ctrl.oDate = $ctrl.startDate;

                if (change.startDate) {
                    $ctrl.dateRangeStart = change.startDate.currentValue
                }
                if (change.endDate) {
                    $ctrl.dateRangeEnd = change.endDate.currentValue
                }
                if (change.class) {
                    $ctrl.class = change.class.currentValue
                }

                console.log("Date component changes");


            };


            $ctrl.selectLayer = function (layer) {
                //$ctrl.onLayerSelected.apply(this)(layer.layer)
            }


            $ctrl.update = function () {
                // $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                // $ctrl.dismiss({$value: 'cancel'});
            };


        }]
    });


})();

