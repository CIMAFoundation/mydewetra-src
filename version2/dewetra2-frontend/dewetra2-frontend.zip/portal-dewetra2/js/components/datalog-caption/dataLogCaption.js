/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('datalogcaption', {
        template: `<div class="popup">
                        <div class="head" >
                            <div class="flex-container">
                                <!--Title-->
                                <div class="brand flex-item">
                                    <i class="fa app-static animated bounceIn delay-002" ></i>
                                    <p class="animated fadeInDown delay-001" translate>
                                          <span translate>CAPTION</span> <span translate>properties</span>
                                    </p>
                                </div>
                                 <div class="flex-item">
                                    <a class="close" ng-click="$ctrl.closePopup()" href>
                                        <i class="fa fa-times fa-2x animated bounceIn delay-003"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    
                        <hr>
         
                        <div class="modal-body">
                            <div class="row">
                                <div class="flex-container">
                                    <button class="btn btn-info flex-item m-2 p-2" style="color: whitesmoke" ng-click="$ctrl.saveMapState()" translate>SEND_TO_DATALOG_BUTTON</button>
                                </div>
                            </div>
                            
                            <div class="row" style="width: 100%; margin: auto">
                                <div class="flex-container">
                                    <div class="flex-item">
                                        <div class="form-group">
                                            <label translate>FILENAME</label>
                                            <input type="text" ng-model="$ctrl.filename" class="form-control">
                                            <label translate>CAPTION_DATALOG</label>
                                            <textarea rows="10" ng-model="$ctrl.txtCaption" class="form-control" maxlength="2400" ></textarea>
                                            <label ng-style="($ctrl.txtCaption.length >=2399)?{color:'red'}:{color:'white'}">Caratteri rimanenti : {{2400 -$ctrl.txtCaption.length}}</label>                                          
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`,
        bindings: {
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService', '$uibModal', 'printService', '$translate','apiService', function (mapService, $uibModal, printService, $translate, apiService) {
            var $ctrl = this;

            $ctrl.txtTitle = '';
            $ctrl.txtCaption =  '';
            $ctrl.filename =  'filename';


            $ctrl.closePopup = function () {
                $ctrl.close()
            }

            $ctrl.getMapState = function () {
                let additionalInformation = [{
                    type:'PARAGRAPH',
                    //title: $ctrl.txtTitle,
                    text: $ctrl.txtCaption
                }];
                const mapState =  printService.getMapsSettings(mapService, mapService.oLayerList.aDraggable, mapService.oLayerList.aUndraggable, additionalInformation)
                mapState.wmsLayers = mapState.wmsLayers.filter(layer => (layer.layerId == $ctrl.resolve.oManager.mapLayer().wmsParams.layers) || (layer.hasOwnProperty('type') && (layer.type == 'STATIC')));
                return mapState;
            };



            $ctrl.saveMapState = function () {
                console.log('Save Map STATE');
                apiService.postPrintServerV2('id/', $ctrl.getMapState(),function (data) {
                    let url = apiService.buildPrintApiV2URL('printurl/?urltoprint=')+ apiService.buildPrintApiV2URL('paintmap/'+data.id+'/datalog&format=png&elementtoprint=#printarea')
                    printService.sendImageToDataLogByLink(url, $ctrl.filename,(data)=>{
                        //console.log(data)
                        alert($translate.instant("IMAGE_UPLODED"));
                        //$ctrl.closePopup();
                    });
                    $ctrl.closePopup();
                })
            }

            $ctrl.checkLength = () => {
                if ($ctrl.txtCaption && $ctrl.txtCaption.length && $ctrl.txtCaption.length > 0){
                    alert()
                }
            }

            $ctrl.$onInit = function () {
                console.log('init DataLogCaption');
            };

            $ctrl.$onChanges = function (change) {
                console.log('on CHANGE DataLogCaption');
                if (change.resolve && change.resolve.currentValue.hasOwnProperty('oManager')) {
                    $ctrl.txtTitle = $translate.instant($ctrl.resolve.oManager.name());
                }

            }

            $ctrl.update = function () {
                $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };


        }]
    });


})();

