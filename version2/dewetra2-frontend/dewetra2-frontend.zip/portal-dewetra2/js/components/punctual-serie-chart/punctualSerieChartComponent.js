/**
 * Created by Dario Rubado on 23/07/18.
 */
(function () {

    dewetraApp.component('punctualSerieChartComponent', {
        templateUrl: 'apps/dewetra2/js/components/punctual-serie-chart/punctualSerieChartComponent.html',
        // template:' <i class="i-tools_info"></i>',
        // template:' <i ng-click="$ctrl.activatePointer()" ng-class="{active: $ctrl.active==true}" class="fa fa-line-chart"></i>',
        bindings: {
            serie:'<',
            resolve: '<',
            close: '&',
            dismiss: '&'
        },
        controller: ['mapService','$rootScope','$translate','menuService','_',function (mapService,$rootScope,$translate,menuService,_) {
            var $ctrl = this;


            $ctrl.closePopup = function () {
                $ctrl.close()
            }


            $ctrl.$onInit = function () {
                console.log("punctualSerieChartComponent");

                $ctrl.height = menuService.oChartSize.m_iSensorChartHeight()



            };

            $ctrl.$onChanges = function (value) {
                // console.log(value.serie.currentValue);
                // value.serie.previousValue
                console.log("punctualSerieChartComponent");

                $ctrl.chart = new Highcharts.StockChart($ctrl.chartOptions);

                if(value.serie.currentValue !==value.serie.previousValue &&value.serie.currentValue !==null){

                    setYAxisTitle()
                    $ctrl.setSerie()
                }


            };

            const setYAxisTitle = () => {
                if($ctrl.serie.variable){
                    $ctrl.chart.yAxis[0].setTitle({text: $translate.instant($ctrl.serie.variable)})
                }

            }


            $ctrl.initChart = function(){
                if($ctrl.chart){
                    $ctrl.setSerie()
                }else {
                    $ctrl.chart = new Highcharts.StockChart($ctrl.chartOptions);
                    $ctrl.setSerie()
                }
                // $ctrl.chart.destroy();





            }




            $ctrl.setXAxis = function(dtFrom,dtTo){

            };


            $ctrl.setSerie = function(){

                console.log("setSerie");

                while ($ctrl.chart.series.length) {
                    $ctrl.chart.series[0].remove();
                }

                if ($ctrl.serie.length == 0 ||angular.isUndefined($ctrl.serie)|| angular.isUndefined($ctrl.chart)) return;


                $ctrl.serie.series.forEach((serie) =>{

                    var list = [];

                    for(let i in serie.timeline){

                        let o = {
                            t: serie.timeline[i],
                            v: serie.values[i]
                        }

                        list.push(o)
                    }
                    let run ='Run:' + moment.unix(parseInt(serie.title.split('_')[serie.title.split('_').length -1]/1000)).format('YYYY-MM-DD HH:mm');

                    // $ctrl.addSerieToChart(list, run, $ctrl.serie.variable)
                    $ctrl.addSerieToChart(list, run, ($ctrl.serie.variable)?$ctrl.serie.variable:'');

                });

                let meanList = [];

                $ctrl.serie.series.forEach((serie) => {

                    for(let i in serie.timeline){

                        let o = {
                            t: serie.timeline[i],
                            v: serie.values[i]
                        }

                        meanList.push(o)
                    }

                })
                $ctrl.addMeanToChart(meanList, 'MEAN:' + meanList.length + ' VALUES', ($ctrl.serie.variable)?$ctrl.serie.variable:'');




            }

            $ctrl.addSerieToChart= function(aSeriesData, title, variable){


                if(angular.isUndefined(aSeriesData)) return ;

                aSeriesData = aSeriesData.filter(x =>  (x.v > -9998 && typeof x.v !== "function"))
                aSeriesData = aSeriesData.map((x) => [ moment.utc(x.t).valueOf(), parseFloat(x.v) ]);

                // console.log(aSeriesData)

                let serie;

                if(aSeriesData.length == 1){
                     serie = {
                        name: title + '  -  '+$translate.instant(variable),
                        type: 'scatter',
                        color: '#' + (0x1000000 + (Math.random()) * 0xffffff).toString(16).substr(1, 6),
                        threshold: null,
                        data: aSeriesData,
                        showInLegend: true
                    };
                }else {
                     serie = {
                        name: title ,
                        type: 'line',
                        color: '#' + (0x1000000 + (Math.random()) * 0xffffff).toString(16).substr(1, 6),
                        threshold: null,
                        data: aSeriesData,
                        showInLegend: true
                    };
                }

                $ctrl.chart.addSeries(serie,true)

                $ctrl.chart.redraw()

            };

            $ctrl.addMeanToChart= function(aSeriesData, title, variable){

                if($ctrl.chart.yAxis[0]){
                    $ctrl.chart.yAxis[0].removePlotLine('MEAN')

                }


                if(angular.isUndefined(aSeriesData)) return ;

                let mean=0;

                aSeriesData = aSeriesData.filter(x =>  (x.v > -9998 && typeof x.v !== "function"))

                aSeriesData = aSeriesData.map(x => {
                    x.v = parseFloat(x.v);
                    mean = mean+ x.v;
                    return x;
                })


                mean = mean.toFixed(2)

                let plotline = {
                    id : 'MEAN' ,
                    value : parseFloat(mean)/aSeriesData.length,
                    color : 'red',
                    width : 2,
                    zIndex: 4,
                    label : {
                        text : 'MEAN: '+ (parseFloat(mean)/aSeriesData.length).toFixed(1) + '  (' + aSeriesData.length + ' VALUES)'
                    }
                };

                $ctrl.chart.yAxis[0].addPlotLine(plotline);


                $ctrl.chart.redraw()

            };

            $ctrl.setyAxis = function(dtFrom,dtTo){
                var from = value.serie.currentValue.timeline[0];
                var to = value.serie.currentValue.timeline[value.serie.currentValue.timeline.length-1];

                $ctrl.chart.xAxis[0].setExtremes(from,to)
            };





            $ctrl.update = function () {
                $ctrl.close({$value: $ctrl.buildDataId()});
            };

            $ctrl.cancel = function () {
                $ctrl.dismiss({$value: 'cancel'});
            };

            $ctrl.chartOptions = {

                chart:{
                    renderTo: 'punctualSerieChart',
                    //marginTop: 25,
                    alignTicks: false,
                    zoomType: 'xy',
                    height: 600,
                    events:{
                        beforePrint: function () {
                            $ctrl.chart.setTitle(null,
                                {
                                    text: $ctrl.serie.title
                                });

                        },
                        afterPrint: function () {

                            $ctrl.chart.setTitle(null,
                                {
                                    text: null
                                });
                        }
                    }
                },
                title : {},
                options: {
                    global: {
                        useUTC: true
                    },
                    chart : {
                        backgroundColor:'rgba(255, 255, 255, 1)'
                    }
                },

                tooltip: {
                    useHTML: true,
                    crosshairs: true,
                    shared: true,
                    formatter: function() {

                        var s = '<div style="font-family:\'Open Sans\', sans-serif;font-size: 11px;color: #000000">' + $translate.instant('ORE') + ' ' + moment.utc(this.x/1000, 'X').format('HH:mm') + '</div><br>';

                        if(this.hasOwnProperty('point')){
                            s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: #FF0000">' +
                                $('<div>' + '  ' + this.point.y.toFixed(2) + ' </div>').html() + '</div><br>';
                            return s;
                        }else if (this.hasOwnProperty('points')){
                            this.points.forEach(function(item){
                                if (item.y > -9998) {
                                    if (item.series.name) {

                                        s += '<div style="font-family:\'Open Sans\', sans-serif;font-size: 12px;color: #FF0000">' +
                                            $('<div>' + '  ' + item.y.toFixed(2) + ' </div>').html() + '</div><br>';
                                    }
                                }
                            });
                            return s;
                        }
                    }
                },
                credits: {
                    enabled: false
                },
                legend: {
                    enabled: true,
                    useHTML: true
                },

                //title: {
                //    style: {
                //        fontSize: '14px',
                //        fontWeight: 'bold',
                //        fontFamily: 'Open Sans'
                //    }
                //},
                //subtitle: {
                //    style: {
                //        fontSize: '14px',
                //        fontWeight: 'bold',
                //        fontFamily: 'Open Sans'
                //    }
                //},

                series: [

                    // {
                    //     name: 'series',
                    //     type: 'line',
                    //     color: 'red',
                    //     threshold: null,
                    //     data: [],
                    //     showInLegend: true
                    // },

                    // flags
                    // {
                    //     name: null,
                    //     type:  'scatter',   //flags',
                    //     shape: '',
                    //     data:[],
                    //     useHTML: true,
                    //     showInLegend: false
                    // }

                ],
                exporting: {
                    chartOptions: {
                        rangeSelector: {
                            enabled: false
                        },
                        navigator: {
                            enabled: false
                        }
                    },
                    sourceWidth: 1500,
                    sourceHeight: 1000,

                },
                navigator: {
                    series: {
                        type: 'area',
                        fillOpacity: 0.3
                    },
                    enabled : true

                },
                scrollbar: {
                    enabled: false
                },
                xAxis: {
                    type: 'datetime',
                    minRange: 12 * 24 * 3600 * 1000,                                   // one day
                    tickPixelInterval: 50,
                    minorTickInterval: 'auto',
                    lineWidth: 2,
                    gridLineWidth: 2,
                    lineColor: 'black',
                    title: {
                        margin: 0,
                        text: 'Time UTC',
                        style: {
                            fontWeight : 'bold',
                            fontFamily: 'Open Sans'
                        }
                    },
                    labels: {
                        style: {
                            fontFamily: 'Open Sans',
                            textTransform: 'lowercase'
                        },
                        formatter: function () {
                            var oDate = new Date(this.value);
                            if ((oDate.getUTCHours() == 0) && (oDate.getUTCMinutes() == 0))
                                return '<b>' + Highcharts.dateFormat('%d %b', this.value) + '</b>';
                            else
                                return Highcharts.dateFormat('%H:%M', this.value);
                        }

                    },
                    plotLines: [
                        {
                            color: 'rgba(69, 163, 202, 1)', // Color value
                            dashStyle: 'Solid',             // Style of the plot line. Default to solid
                            value: new Date().getTime(),    // Value of where the line will appear
                            width: '2',                     // Width of the line
                            zIndex: 4
                        }
                    ],
                    events: {

                        setExtremes: function(e) {
                            //all -> 1 giorno -> 3 giorni
                            if (e.rangeSelectorButton) {

                                var c = e.rangeSelectorButton.count;

                                if (c == 3) {
                                    rangeSelected = 0;
                                } else if (c == 12) {
                                    rangeSelected = 1;
                                } else {
                                    rangeSelected = 2;
                                }

                                //} else {
                                //    if (!chart.rangeSelector) {
                                //        var subTitle = ('Dati dal ' + moment(e.min/1000, 'X').format('DD/MM/YYYY') + ' al ' + moment(e.max/1000, 'X').format('DD/MM/YYYY'));
                                //        chart.setTitle(null, { text: subTitle });
                                //    }

                            }

                        }

                    }

                },
                plotOptions: {
                    scatter:{
                        lineWidth: 2
                    },
                    series: {
                        dataGrouping: {
                            enabled: true,
                            approximation :"high"
                        },
                        animation: false,
                        lineWidth: 1// adding line to connect scatter chart
                    },
                    line: {
                        marker: {
                            enabled: true,
                            radius: 1
                        }
                    },
                    area: {
                        marker: {
                            enabled: true,
                            radius: 1
                        }
                    }
                },
                rangeSelector : {

                    // buttonTheme: { // styles for the buttons
                    //     width: 50,
                    //     fill: 'none',
                    //     stroke: 'none',
                    //     'stroke-width': 0,
                    //     r: 3,
                    //     style: {
                    //         fontWeight: 'bold',
                    //         fontSize: '12px',
                    //         fontFamily: 'Open Sans',
                    //     },
                    //     states: {
                    //         hover: {
                    //         },
                    //         select: {
                    //             fill: '#525052',
                    //             style: {
                    //                 color: 'white'
                    //             }
                    //         }
                    //     }
                    // },
                    //
                    // buttons : [{
                    //     type : 'hour',
                    //     count : 3,
                    //     text : 'Last 3h'
                    // }, {
                    //     type : 'hour',
                    //     count : 12,
                    //     text : 'Last 12h'
                    // },
                    //     {
                    //         type : 'all',
                    //         text : 'Last 24h'
                    //     }],

                    inputEnabled : false,
                     enabled : false

                },
                yAxis: [{ // Primary yAxis
                    ordinal: false,
                    // min : objExtremes.min,
                    // max : objExtremes.max,
                    // tickInterval: objExtremes.tickInterval,
                    showLastLabel : true,
                    allowDecimals: true,
                    alternateGridColor: 'rgba(0, 144, 201, 0.1)',
                    labels: {
                        x: 25,
                        y: 5,
                        format: '{value:.0f}',
                        style: {
                            color: 'red',
                            fontFamily: 'Open Sans',
                            textTransform: 'lowercase'
                        }
                    },
                    title: {
                        rotation: 270,
                        margin: 0,
                        offset: 45,
                        useHTML:true,
                        text: '<p style="color:red">VARIABLE</p>',
                        style: {
                            fontWeight : 'bold',
                            fontFamily: 'Open Sans'
                        }
                    },
                    opposite: true
                }
                ],
                loading: false

            }

        }]
    });


})();

