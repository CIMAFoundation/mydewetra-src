
/**
 * Created by dario on 27/10/16.
 */




(function(){

dewetraApp.controller('laminazioneController',['$scope','$rootScope', '$uibModalInstance','params','$timeout', '$translate', 'laminazioneService','menuService','_',function($scope,$rootScope, $uibModalInstance,params,$timeout, $translate, laminazioneService,timeService,_){


    console.log("laminazione controller init");

    $scope.currentStep = 1;

    $scope.oConfig  = {
        qturb:0,
        delta:0,
        fsic:0,
        manact:0
    };

    $rootScope.$watch('pendingRequests', function(){
        $scope.pendingRequests = $rootScope.pendingRequests
    });



    $scope.firstScriptResult = {};

    $scope.steps = [
        {
            step: 1,
            name: "Selezione Input di previsione",
            template: "apps/dewetra2/js/components/laminazione/step/inputPrevBis.html"
        },
        {
            step: 2,
            name: "Riepilogo",
            template: "apps/dewetra2/js/components/laminazione/step/riepilogo.html"
        },
        {
            step: 3,
            name: "Input Manovre",
            template: "apps/dewetra2/js/components/laminazione/step/inputManovre.html"
        },
        {
            step: 4,
            name: "Run",
            template: "apps/dewetra2/js/components/laminazione/step/run.html"
        },
        {
            step: 5,
            name: "Chart",
            template: "apps/dewetra2/js/components/laminazione/step/chart.html"
        },
        {
            step: 6,
            name: "Risultati",
            template: "apps/dewetra2/js/components/laminazione/step/risultati.html"
        },
    ];

    // $scope.dateToOption = {
    //     'dropdownSelector': 'sel+$index',
    //     'minView':'hour',
    //     // minuteStep: 5,
    //     // modelType:'moment'
    //     'maxDate':new Date(),
    //     'minDate':new Date(),
    // };

    $scope.dateOption = function(index){
        console.log(index);
        return{
            dropdownSelector: 'sel'+index,
            minView:'hour',
            // minDate:$scope.dateToOption.minDate,
            // maxDate:$scope.dateToOption.maxDate,
        }
    }

    $scope.$watch('firstScriptResult',function () {


        // $scope.dateToOption.minDate = moment.utc(new Date($scope.firstScriptResult.t_qin_main[0]));
        // $scope.dateToOption.maxDate = moment.utc(new Date($scope.firstScriptResult.t_qin_main[$scope.firstScriptResult.t_qin_main.length -1]));
    });


    //non far accedere al secondo step direttamente
    $scope.checkNgClickOnNext = function(newStep, callback){

        if( newStep != 2){
            callback(newStep)
        }

    }

    $scope.$watch('oConfig.qturb',function () {

        if($scope.currentStep == 2){
            if($scope.oConfig.qturb < 0 || $scope.oConfig.qturb >= 200 || $scope.oConfig.qturb === undefined) {
                alert("qturb should be from 0 to 200")
                $scope.oConfig.qturb = 0
            }
        }
    })





    $scope.gotoStep = function(newStep, skipCondition) {

        $scope.dynamicCharts = laminazioneService.getFourthScriptResult()

        if(newStep == 2 && $scope.currentStep == 1 ){
            $scope.loadFirstScript();
        }

        // if($scope.currentStep == 3 && newStep==4)$scope.loadThirdScript();

        // if($scope.currentStep != 2 || skipCondition){
        //     $scope.currentStep = newStep;
        // }


        if($scope.pendingRequests == 0 || skipCondition)$scope.currentStep = newStep;
    }
    //debug



    // $scope.gotoStep(3)
    //
    // $scope.t_start = moment.utc(new Date()).subtract(2,'hours');
    //
    // $scope.t_end = moment.utc(new Date()).add(72,'hours');

    //end debug

    $scope.getStepTemplate = function(){
        for (var i = 0; i < $scope.steps.length; i++) {
            if ($scope.currentStep == $scope.steps[i].step) {
                return $scope.steps[i].template;
            }
        }
    }

    $scope.loadData= function(){
        // $scope.oConfig.conf model data scelta serie input Prev
        laminazioneService.loadLaminazioneCorbaraFirstData($scope.oConfig.conf, function (data) {
            $scope.firstScriptResult = data;
            $scope.updateChartData(data);
        },function (data) {
            alert("La previsione richiesta non è diponibile");
            $scope.gotoStep(1);
            console.log("error LoadData")
        });
    };

    $scope.updateChartData= function(data, string){
        console.log("chartData updated:"+(string)?string:"");
        $scope.chartData = data;
        console.log(data)
    };

    $scope.loadFirstScript=function(){
        // $scope.oConfig.conf model data scelta serie input Prev
        laminazioneService.loadLaminazioneCorbaraFirstData($scope.oConfig.conf,function (data) {

            $scope.firstScriptResult = data;



            if(data.hasOwnProperty("t_start")&&data.hasOwnProperty("t_end")){
                $scope.t_start = moment.utc(data.t_start);
                $scope.t_end = moment.utc(data.t_end);
                // console.log($scope.t_start)
                // console.log($scope.t_end)
                // console.log(data.t_start)
                // console.log(data.t_end)

            }

            $scope.updateChartData(data, "First Script");
        },function (data) {
            alert("La previsione richiesta non è diponibile");
            $scope.gotoStep(1);
            console.log("error LoadData")
        });
    };

    $scope.toLocalTimeString = function(date){
        // var tzOffSet = Math.abs(date.getTimezoneOffset())*60000;
        try{
            var date = new Date(date.getTime());
            return moment(date).format('lll');
        }catch (e) {
            // console.log(e)
        }


    };

    $scope.fromStringToCet = function(stringDate){
        // stringDate time_qmax_main 2018-12-18T15:00:00
        var oMDate = moment.utc(stringDate)


        return $scope.toLocalTimeString(oMDate.toDate());

    }


    $scope.popSomething = function(data){
        //for debug pourpose
        data.t_qout_a.pop();
        data.qout_a.pop();
        data.t_qin_main.pop();
        data.qin_main.pop();
        data.qconfl_main.pop();
        data.qin_trib.pop();
        data.qconfl_merge.pop();
        data.t_qdwnstr_main.pop();
        data.qdwnstr_main.pop();
        data.qdwnstr_main_noDam.pop();

        return data
    }

    $scope.loadSecondScript= function(){


        laminazioneService.postConfigurazioneSecondScript($scope.oConfig, function (modalObj, data) {
            data = $scope.popSomething(data);
            $scope.modelObject = modalObj;

            if(data.hmax) data.hmax= data.hmax-1;

            if (data.qturb.length>1){

                var sum = 0;
                data.qturb.pop();
                data.t_qturb.pop();

                data.qturb.forEach(function(n){
                    sum =sum+n;
                })

                // var sum =data.qturb.reduce(function (total, currentValue) {
                //     return total + currentValue;
                // },0)


                // console.log(sum)
                // console.log(data.qturb.length)

                data.qturbMean = sum/data.qturb.length;

            }
            $scope.updateChartData(data, "Second Script");
            $scope.gotoStep(4, true);
        })
    };


    $scope.loadThirdScript= function(callback){

        laminazioneService.postConfigurazioneThirdScript($scope.oConfig,function (data) {

            //rebuild

            for(var i in $scope.modelObject){
                $scope.modelObject[i].level = data["rel_level"][i]
                $scope.modelObject[i].pturb = data["rel_turb"][i]
            }


            data = $scope.popSomething(data);

            $scope.updateChartData(data,  "third Script");

            if (callback) callback()


        },function (err) {
            console.log(err)
        },$scope.modelObject,$scope.oConfig.qturb)
    };

    $scope.run = function () {

        $scope.loadThirdScript(function () {
            $scope.gotoStep(4, true)

            $timeout(function () {
                $scope.loadChart("level")
            },1000)
        });


    }

    $scope.livelloInvaso = 130;

    $scope.dateTo = moment(new Date(timeService.getDateTo())).format('lll');
    $scope.dateFrom = moment(new Date(timeService.getDateFrom())).format('lll');




    $scope.maxDate =function(dates){
        var iMaxDate = laminazioneService.dateTo().getTime()+ (72*60*60000)

        for(var i=0; i<dates.length;i++) {
            if(iMaxDate < dates[i].utcDateValue) {
                dates[i].selectable = false;
            }
        }
    }

    $scope.addManovra = function(){

        if(o) delete o;

        // var diff= 60*($scope.modelObject.length+1);//moltiplicavo incrementale per 3 ore

        var diff = 60*3;//moltiplico per 3 ore

        if($scope.modelObject.length > 0){//se è presente almeno una manovra imposto la data della manovra precedente + 3 ore
            try {//serve solo per non generare un errore se vanno all input manovre senza avere un t_start e quindi una prima manovra gia impostata
                var oDate = new Date($scope.modelObject[$scope.modelObject.length-1].date.getTime()+ diff*60000);
            }catch (e) {
                var oDate = new Date();
            }


        }else{
            //altrimenti uso la data t_start

            if($scope.t_start) {
                var oDate =new Date($scope.t_start.utc().toDate())
                console.log(oDate)
            }

            // var oDate = new Date(Date.UTC($scope.t_start.toDate()));
        }


        // data-before-render="beforeRender($view, $dates, $leftDate, $upDate, $rightDate)"
        var o = {
            date:oDate,
            maxDate:function ($dates,oManovraBefore,$view,  $leftDate, $upDate, $rightDate) {
                var tzOffSet =Math.abs(oDate.getTimezoneOffset())

                var iMinDate = $scope.t_start.toDate().getTime()+tzOffSet*60000

                if(oManovraBefore){
                    iMinDate = oManovraBefore.date.getTime()+(3*60*60000);
                }


                //data max 72 ore dopo
                var iMaxDate = $scope.t_end.toDate().getTime()+ (72*60*60000)

                for(var i=0; i<$dates.length;i++) {
                    if(iMaxDate < $dates[i].utcDateValue || $dates[i].utcDateValue < iMinDate) {
                        $dates[i].selectable = false;
                    }
                }
            },
            percentage:100,
            value:0,
            time:100,
            name:"Manovra "+(parseInt($scope.modelObject.length)+1),
            descr:"rel"
        };

        // o.date =

        $scope.modelObject.push(angular.copy(o));
    };

    $scope.removeManovra = function(index){
        $scope.modelObject.splice(index,1);

        for(var i in $scope.modelObject){
            $scope.modelObject[i].name = "Manovra "+parseInt(i+1).toString();
        }


    };



    $scope.dateTimeConfig = function(manovra,index){

        return{
            // modelType:,
            dropdownSelector: 'sel'+index,
            startView:'hour',
            minView:'hour',
            // timezone:'utc'
        }
    };

    $scope.beforeRender = function($view, $dates, $leftDate, $upDate, $rightDate){
        console.log($view)
        console.log($dates)
    };

    $scope.onSetTime = function(newDate, oldDate,paratoia){
        var tzOffset = newDate.getTimezoneOffset();
        // console.log(tzOffset);

        paratoia.date = new Date(newDate.getTime() );

        // console.log(newDate);

        // console.log(paratoia)
    };

    // function

    $scope.$watch('t_start',function () {
        if($scope.modelObject.length == 0){

            // console.log($scope.t_start);

            if($scope.t_start)$scope.addManovra();
            // var o  = {
            //         date : $scope.t_start.toDate(),
            //         // date:new Date(laminazioneService.dateTo().getTime()+ 60*60000),
            //         // date :new Date($scope.firstScriptResult.t_qin_main[0]),
            //         maxDate:function ($dates,oManovraBefore) {
            //
            //             var iMinDate = $scope.t_start.utc().toDate().getTime()
            //
            //             if(oManovraBefore){
            //                 iMinDate = oManovraBefore.date.getTime()+(2*60*60000);
            //             }
            //
            //
            //             //data max 72 ore dopo
            //             var iMaxDate = $scope.t_end.toDate().getTime()+ (72*60*60000)
            //
            //             for(var i=0; i<$dates.length;i++) {
            //                 if(iMaxDate < $dates[i].utcDateValue || $dates[i].utcDateValue < iMinDate) {
            //                     $dates[i].selectable = false;
            //                 }
            //             }
            //         },
            //         percentage:100,
            //         value:0,
            //         time:100,
            //         name:"Manovra 1",
            //         descr:"rel"
            //     };


            // $scope.modelObject.push(o);



        }
    });

    $scope.modelObject = [];


    $scope.downloadManovre = function(){
        var encodedUri = encodeURI(laminazioneService.exportManovreToCsv($scope.modelObject));
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "manovre.csv");
        link.innerHTML= "Click Here to download";
        // document.body.appendChild(link); // Required for FF

        link.click();
    };

    $scope.dateFormatter = function(date){

        // return moment.utc(date).format('DD-MM-YYYY HH:mm')+" Ora locale (UTC"+moment(date).format('Z)');
        return moment.utc(date).format('DD-MM-YYYY HH:mm')+" (UTC)";
        // return date.toISOString()

    };

    $scope.ottimizzaManovre = function(){
        $scope.loadSecondScript()
    };

    $scope.verificaManovre = function(){
        $scope.gotoStep(3);

    };

    $scope.loadChart = function (str, dynChartKey) {
        var chartData = $scope.chartData;

        // console.log("chartData");
        // console.log(chartData);

        if(str== "level")showLaminazioneLevelChartService(chartData, null, null, 600, null, $translate, null)
        if(str== "volume")showLaminazioneVolumeChartService(chartData, null, null, 600, null, $translate, null)
        if(str=="confluenza")showLaminazioneConfluenzaPagliaTevereChartService(chartData, null, null, 600, null, $translate, null);
        if(str=="confluenza-2")showLaminazioneConfluenzaValleBaschiChartService(chartData, null, null, 600, null, $translate, null);



        if(str=="dynCharts" && $scope.dynamicCharts[dynChartKey]){
            chartData.dynamicCharts = $scope.dynamicCharts;
            chartData.selectedDynamicCharts = dynChartKey;
            showDynamicRiverVolumeChartService(chartData, null, null, 600, null, $translate, null);
        }

        if(str=="totalCharts"){
            chartData.dynamicCharts = $scope.dynamicCharts;
            showTotalRiverVolumeChartService(chartData, null, null, 600, null, $translate, null);
        }

        // if(str=="confluenza-2")showLaminazioneConfluenzaPagliaTevereChartService(chartData, null, null, 600, null, $translate, null)
    }



    $scope.onLocationSelected = function (location) {
        $uibModalInstance.dismiss(location)
    };

    $scope.update = function () {
        $uibModalInstance.close()

    };

    $scope.closePopup = function () {
        $uibModalInstance.dismiss('cancel')
        if(params.onClose)params.onClose();

    };

}]);


})();
