



function tool_laminazione_corbara(ModelData,  $uibModal, onClose) {

    var corbaraFeature = {
        point:[12.231333, 42.699333],
        properties:{
            "catchment": 150,
            "dbid": 2,
            "district": 55,
            "munic": 4982,
            "region": 10,
            "sensorid": 210328104,
            "sensormu": "m",
            "sensorname": "Diga Corbara#Baschi",
            "stationid": 200043955,
            "stationname": "ERG-G",
            "wa": 113,
            "descr": "Baschi",
            "damsname": "Diga Corbara",
            "warning_palette": -2
        }
    };





    function f() {

    }


    var modalInstance = $uibModal.open({

        templateUrl:'apps/dewetra2/js/components/laminazione/laminazioneModalView.html',
        controller:"laminazioneController",
        size: "lg",
        backdrop:'static',
        resolve: {
            params: function() {
                return {
                    feature: corbaraFeature,
                    onClose : onClose
                }
            }
        }
    });

    return{
        modalIstance : modalInstance
    }
}
