(function(){


    dewetraApp.service('laminazioneService',['serieService', 'menuService', 'apiService','_', function (serieService, timeService, apiService,_) {



        var confObj={
            laminazioneCorbaraFP:[
                {
                    server:1,
                    serie:"erg.floodproofs.deterministiclami",
                    featureId:"Tevere, Corbara",
                    name:"qin_main"
                },
                {
                    server:1,
                    serie:"erg.floodproofs.deterministiclami",
                    featureId:"Paglia, Confluenza",
                    name:"qin_trib"
                },
                {
                    server:1,
                    serie:"all.sensor.hydrometers",
                    featureId:"210328104;2",
                    name:"h_current"
                }],
            laminazioneCorbaraCFU:[
                {
                    server:1,
                    serie:"erg.floodproofs.umbria.deterministiclami",
                    featureId:"Tevere, Monte Molino",
                    name:"qin_main"
                },
                {
                    server:1,
                    serie:"erg.floodproofs.umbria.deterministiclami",
                    featureId:"Carcaione, Orvieto Scalo",
                    name:"qin_trib"
                },
                {
                    server:1,
                    serie:"all.sensor.hydrometers",
                    featureId:"210328104;2",
                    name:"h_current"
                }],
            laminazioneCorbaraCFUECMWF:[
                {
                    server:1,
                    serie:"erg.floodproofs.umbria.deterministicecmwf",
                    featureId:"Tevere, Monte Molino",
                    name:"qin_main"
                },
                {
                    server:1,
                    serie:"erg.floodproofs.umbria.deterministicecmwf",
                    featureId:"Carcaione, Orvieto Scalo",
                    name:"qin_trib"
                },
                {
                    server:1,
                    serie:"all.sensor.hydrometers",
                    featureId:"210328104;2",
                    name:"h_current"
                }]
        };

        var postFirstScript = null;

        var postThirdScript = null

        var lastManovre = null;

        var firstScriptResult =null;
        var secondScriptResult =null;
        var thirdScriptResult =null;

        var fourthScriptInput =null;

        var fourthScriptResult =null;


        var oFrom = moment(new Date(timeService.getDateFrom()));

        var oTo = moment(new Date(timeService.getDateTo()));

        return{

            dateRef:function(){
                return oFrom.toDate();
            },

            dateTo:function(){
                return oTo.toDate();
            },

            setFirstScriptResult:function(data){
                firstScriptResult = data;
            },

            getFirstScriptResult:function(){
                return firstScriptResult;
            },
            setSecondScriptResult:function(data){
                secondScriptResult = data;
            },

            getSecondScriptResult:function(){
                return secondScriptResult;
            },
            setThirdScriptResult:function(data){
                thirdScriptResult = data;
            },

            getThirdScriptResult:function(){
                return thirdScriptResult;
            },

            getFourthScriptResult:function(){
                return fourthScriptResult;
            },

            getLevelChartData:function(){

                return{
                    hres_a:firstScriptResult.hres_a,
                    hmax:firstScriptResult.hmax,
                    t_qin_main:firstScriptResult.t_qin_main
                }
            },

            loadLaminazioneCorbaraFirstData:function (sConfig, okCallback,koCallback) {
                var _Service = this;
                var from =timeService.getDateFromUTCSecond();
                var to = timeService.getDateToUTCSecond();

                var series = {};

                var itemProcessed = 0;

                confObj[sConfig].forEach(function (obj,index, array) {
                    serieService.getSeriesDirect(obj.server,obj.serie,obj.featureId,from, to,function (data) {
                        series[obj.name] = data;
                        itemProcessed++;
                        if(array.length == itemProcessed){
                            _Service.postConfigurazioneFirstData(okCallback,koCallback,series);
                        }
                    },koCallback)
                })
            },
            postConfigurazioneFirstData:function (okCallback,koCallback, series) {



                // console.log(series);

                // var oTo = moment.utc(timeService.getDateToUTCSecond());
                var forecastArrayIndex = 1;

                var dateRef= moment.utc(series['qin_main'][forecastArrayIndex].title.split(";")[3],"YYYYMMDDHHmm");

                console.log("dateRef: " +dateRef);

                oFrom = dateRef;

                //servono 6 ore di dati prina della dateref
                var sixHourBeforeDateRef = moment(dateRef.subtract({hours:6}).valueOf());

                // sixHourBeforeDateRef.subtract(6 ,'hour');

                //array of last six hour oh damns high
                var indexOfDamsLevelTimeline = _.findLastIndex(series['h_current'].timeline,function (date) {
                    return moment(date).isBefore(sixHourBeforeDateRef);
                });


                console.log(series)


                var h_current = _.rest(series['h_current'].values, indexOfDamsLevelTimeline);
                var t_h_current = _.rest(series['h_current'].timeline, indexOfDamsLevelTimeline);

                function parseToInt(s){
                    return parseInt(s);
                }

                function toMillisenconds(x){
                    return moment(x).valueOf()/1000;
                }

                h_current = h_current.map(parseToInt);

                //END array of last six hour oh damns high


                //array of main contrib forecast
                var indexOfQinMainForecastFromDateRef =_.findLastIndex(series['qin_main'][forecastArrayIndex].timeline,function (date) {
                    return moment(date).isBefore(sixHourBeforeDateRef);
                });

                //indexOfQinMainForecastFromDateRef se è -1 non passa valori al post
                if (indexOfQinMainForecastFromDateRef == -1){
                    alert('Error loading DATA, no data before dateref');

                }

                var qin_main = _.rest(series['qin_main'][forecastArrayIndex].values, indexOfQinMainForecastFromDateRef);

                qin_main = qin_main.map(parseToInt);

                var t_qin_main = _.rest(series['qin_main'][forecastArrayIndex].timeline, indexOfQinMainForecastFromDateRef);

                t_qin_main = t_qin_main.map(toMillisenconds);
                //END array of main contrib forecast

                //array of main contrib forecast
                var indexOfQinTribForecastFromDateRef =_.findLastIndex(series['qin_trib'][forecastArrayIndex].timeline,function (date) {
                    return moment(date).isBefore(sixHourBeforeDateRef);
                });

                var qin_trib = _.rest(series['qin_trib'][forecastArrayIndex].values, indexOfQinTribForecastFromDateRef);

                qin_trib = qin_trib.map(parseToInt);

                var t_qin_trib = _.rest(series['qin_trib'][forecastArrayIndex].timeline, indexOfQinTribForecastFromDateRef);

                t_qin_trib = t_qin_trib.map(toMillisenconds);



                // if(qin_main.length > qin_trib.length){ //serviva per avere array  uguali
                //     while (qin_main.length != qin_trib.length){
                //         qin_main.shift();
                //         t_qin_main.shift();
                //     }
                // }else{
                //     while (qin_main.length != qin_trib.length){
                //         qin_trib.shift();
                //         t_qin_trib.shift();
                //     }
                // }


                // for (var i in qin_main){
                //     qin_main[i] =qin_main[i]*1000
                // }

                //END array of main contrib forecast

                if(indexOfQinMainForecastFromDateRef&& indexOfQinTribForecastFromDateRef && indexOfDamsLevelTimeline){
                    var obj = {
                            "alg":"laminazione.laminazione_first",
                        "input":{
                            "qin_main": qin_main,
                            "t_qin_main": t_qin_main,
                            "qin_trib": qin_trib,
                            "t_qin_trib": t_qin_trib,
                            // "h_current": h_current,
                            "h_current": series['h_current'].values,
                            // "t_h_current":t_h_current
                            "t_h_current": series['h_current'].timeline,
                            "from_date" : timeService.getDateFromUTCSecond(),
                            "to_date" : timeService.getDateToUTCSecond()
                        }
                    };

                    postFirstScript = obj;

                    console.log(obj);

                    apiService.postExtJson(window.app.url.laminazione67Url,obj,function (data) {
                        firstScriptResult = data;
                        console.log("result first script");
                        console.log(firstScriptResult)

                        if(okCallback)okCallback(data)
                    },function () {
                        alert("error from post first script");
                    })
                }else alert("missing index")


            },

            postConfigurazioneSecondScript:function (oConfig, okCallback,koCallback) {
                var _This = this;
                //vuole gli stessi input del primo ritorna 6 manove e portata turbinata
                if(postFirstScript){

                    var postSecondScript = angular.copy(postFirstScript);

                    //quando carico il secondo script sovrascrivo sempre questi dati inseriti dall'utente?
                    postSecondScript["alg"] = "laminazione.laminazione_second";
                    postSecondScript["input"]["qturb"]=oConfig.qturb;
                    postSecondScript["input"]["delta"]=oConfig.delta;
                    postSecondScript["input"]["fsic"]=oConfig.fsic;
                    postSecondScript["input"]["manact"]=oConfig.manact;

                    apiService.postExtJson(window.app.url.laminazione67Url,postSecondScript,function (data) {
                        secondScriptResult= data;
                        var modalObj =[] ;

                        if(data.hasOwnProperty("t_rel")&&data.hasOwnProperty("rel")) {
                            for(var i in data["t_rel"]){
                                var newDate = new Date(data["t_rel"][i]);

                                var tzOffset = Math.abs(newDate.getTimezoneOffset());


                                var obj = {
                                    date:new Date(newDate.getTime() + tzOffset * 60000),
                                    percentage:100,
                                    level:data["rel_level"][i],
                                    pturb:data["rel_turb"][i],
                                    // pturb:0,
                                    value: data["rel"][i],
                                    name: "Manovra "+i,
                                    descr:"rel"
                                };
                                // console.log(obj);
                                if(moment(obj.date).isValid())modalObj.push(obj);
                            }
                        }

                        fourthScriptInput = secondScriptResult;

                        _This.postConfigurazioneFourthScript(function (data) {
                            console.log("FourthScript")
                            console.log(data);
                            fourthScriptResult = data
                        },function (data) {
                            fourthScriptResult = data
                        })

                        //edit data to be fitted in modal obj
                        if (okCallback)okCallback(modalObj,data);
                    },function () {
                        alert("error");
                    })
                }
            },
            postConfigurazioneThirdScript:function (oConfig,okCallback,koCallback,manovre, portata) {
                var _This = this;
                //vuole gli stessi input del primo ritorna 6 manove e portata turbinata
                if(postFirstScript && manovre){
                    postThirdScript = angular.copy(postFirstScript);

                    lastManovre= manovre;

                    postThirdScript["alg"] = "laminazione.laminazione_third";
                    postThirdScript["input"]["qturb"]=oConfig.qturb;
                    postThirdScript["input"]["delta"]=oConfig.delta;
                    postThirdScript["input"]["fsic"]=oConfig.fsic;
                    postThirdScript["input"]["manact"]=oConfig.manact;


                    postThirdScript["input"]["t_rel"]= [];
                    postThirdScript["input"]["rel"]= [];

                    manovre.forEach(function (manovra,index,array) {
                        // var indexN = index+1;
                        // postThirdScript["input"][manovra.descr+indexN.toString()]=manovra.value;
                        // postThirdScript["input"]["t_"+manovra.descr+indexN.toString()]=parseInt(moment(manovra.date).valueOf()/1000);

                        postThirdScript["input"]["t_rel"].push(parseInt(manovra.date.getTime()/1000));
                        postThirdScript["input"]["rel"].push(manovra.value);

                    });

                    postThirdScript["input"]["qturb"]=portata;
                    postThirdScript["input"]["nrel"]=manovre.length;

                    console.log(postThirdScript)

                    apiService.postExtJson(window.app.url.laminazione67Url,postThirdScript,function (data) {
                        thirdScriptResult = data;

                        fourthScriptInput = thirdScriptResult;

                        _This.postConfigurazioneFourthScript(function (data) {

                            fourthScriptResult = data
                        },function (data) {
                            fourthScriptResult = data
                        })

                        okCallback(data);
                    },function (err) {
                        console.log(err)
                    });
                }
            },

            postConfigurazioneFourthScript:function(okCallback,koCallback){

                console.log(fourthScriptInput);

                var o = angular.copy(fourthScriptInput);
                    o.from_date = timeService.getDateFromUTCSecond();
                    o.to_date = timeService.getDateToUTCSecond()

                var obj = {
                    "alg":"laminazione.laminazione_fourth",
                    "input":o,
                };


                apiService.postExtJson(window.app.url.laminazione67Url,obj,function (data) {
                    console.log(data)
                    okCallback(data)
                },function () {
                    //var o ={"Stimigliano": {"Q": [8.1, 0.0, 0.05, 0.23, 0.55], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Orte": {"Q": [8.1, 3.5, 5.83, 8.19, 8.33], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Ponte Felice": {"Q": [8.1, 0.0, 0.55, 1.33, 2.24], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Monte Aniene": {"Q": [21.1, 12.2, 9.6, 7.0, 7.0], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}, "Ponte Grillo": {"Q": [8.1, 0.0, 0.0, 0.01, 0.04], "Time": [1540704600, 1540706400, 1540708200, 1540710000, 1540711800]}}
                    okCallback(o)
                })
            },
            exportManovreToCsv:function (manovre) {
                var csvHeader = "data:text/csv;charset=utf-8,";

                manovre.forEach(function (manovra,index, array) {
                    var row = moment(manovra.date).format()+","+manovra.value;
                    csvHeader += row+ "\r\n";
                })
                return csvHeader;
            }

        }

    }])

})();
